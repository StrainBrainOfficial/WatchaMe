# -*- coding: utf-8 -*-

'''
********************************************************cm*
* The Crew Add-on
*
* @file smart_resolve_queue.py
* @package script.module.thecrew
*
* @copyright (c) 2026, The Crew
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*
Pure queue logic for smart source resolution (no Kodi imports).

'''


from __future__ import annotations

import re

QUALITY_RANK = {
    '4k': 0,
    '1440p': 1,
    '1080p': 2,
    'hd': 3,
    '720p': 3,
    'sd': 4,
    'scr': 5,
    'cam': 6,
}

_CACHE_KEYS = ('cached', 'is_cached', 'debrid_cached', 'cached_rd', 'cache')


def normalize_debrid(name):
    if not name:
        return ''
    return re.sub(r'[^a-z0-9]+', '', str(name).lower())


def is_realdebrid(name):
    n = normalize_debrid(name)
    return n in ('realdebrid', 'rd')


def quality_rank(quality):
    return QUALITY_RANK.get(str(quality or 'sd').lower(), 4)


def source_key(item):
    return (item.get('url') or '', normalize_debrid(item.get('debrid')))


def is_cached(item):
    for key in _CACHE_KEYS:
        if item.get(key) in (True, 'true', 1, '1', 'cached'):
            return True
    return False


def episode_score(item, season, episode):
    score = 0
    if season is None or episode is None:
        return score
    try:
        s_int = int(season)
        e_int = int(episode)
    except (TypeError, ValueError):
        return score
    combined = ' '.join(
        str(item.get(k) or '') for k in ('name', 'label', 'info')
    ).lower()
    exact = f's{s_int:02d}e{e_int:02d}'
    if exact in combined:
        score += 80
    elif f'episode {e_int}' in combined:
        score += 30
    if any(t in combined for t in ('complete', 'season pack', 'full season', 's01-s')):
        score -= 20
    return score


def build_smart_queue(all_items, primary, season=None, episode=None, debrid_mod=None):
    """Build a debrid- and quality-aware resolve queue from the full visible source list."""
    if not all_items:
        return [primary] if primary else []

    if debrid_mod is None:
        try:
            from resources.lib.modules import debrid as debrid_mod
        except Exception:
            debrid_mod = None

    primary_key = source_key(primary)
    primary_q = quality_rank(primary.get('quality'))

    def score_item(item):
        if source_key(item) == primary_key:
            return 10_000_000

        score = 0
        q = quality_rank(item.get('quality'))
        if q == primary_q:
            score += 5000
        elif q > primary_q:
            score += 3000 - (q - primary_q) * 200
        else:
            score += 1000 - (primary_q - q) * 100

        if is_cached(item):
            score += 400
        if item.get('debrid'):
            score += 50
        score += episode_score(item, season, episode)

        if debrid_mod is not None:
            if debrid_mod.is_rd_in_cooldown() and is_realdebrid(item.get('debrid')):
                score -= 8000
            elif debrid_mod.rd_451_was_hit() and is_realdebrid(item.get('debrid')):
                score -= 500

        return score

    ranked = sorted(all_items, key=score_item, reverse=True)
    seen = set()
    queue = []
    for item in ranked:
        key = source_key(item)
        if key in seen:
            continue
        seen.add(key)
        queue.append(item)
    return queue
