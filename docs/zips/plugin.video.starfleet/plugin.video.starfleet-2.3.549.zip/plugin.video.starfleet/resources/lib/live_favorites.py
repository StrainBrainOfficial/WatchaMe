# -*- coding: utf-8 -*-
"""
resources/lib/live_favorites.py
Favorites store for Live TV channels — keyed by channel 'key' (from
unified_live.get_all_channels()), separate from main favorites.json and
adult_favorites.json the same way those two are separate from each other.
"""
import json
import os
import time
import urllib.parse as _up

import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

_PROFILE = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.starfleet/')
_FPATH   = os.path.join(_PROFILE, 'live_favorites.json')


def _load():
    try:
        with open(_FPATH, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}


def _save(data):
    try:
        os.makedirs(_PROFILE, exist_ok=True)
        with open(_FPATH, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False)
    except Exception as e:
        xbmc.log('[LiveFav] save error: %s' % e, xbmc.LOGWARNING)


def add(ch_key, title, thumb, fanart='', direct_url=''):
    """direct_url is set for channels with no unified_live ch_key concept —
    the per-country json_data catalogue channels, which already carry a
    pre-resolved playable URL directly rather than needing live_unified_play
    to look one up. When set, playback uses it directly instead."""
    data = _load()
    data[str(ch_key)] = {
        'ch_key':     str(ch_key),
        'title':      title,
        'thumb':      thumb,
        'fanart':     fanart or thumb,
        'direct_url': direct_url,
        'ts':         int(time.time()),
    }
    _save(data)


def remove(ch_key):
    data = _load()
    data.pop(str(ch_key), None)
    _save(data)


def is_favorite(ch_key):
    return str(ch_key) in _load()


def get_all():
    """Return all Live TV favorites sorted newest-added first."""
    return sorted(_load().values(), key=lambda x: x.get('ts', 0), reverse=True)


# ── Action handlers called by dispatcher ─────────────────────────────────────

def live_favorites_add_action(ch_key, title, thumb='', fanart='', direct_url=''):
    add(ch_key, title, thumb, fanart, direct_url)
    xbmcgui.Dialog().notification(
        'Live TV Favorites', 'Added: %s' % title,
        xbmcgui.NOTIFICATION_INFO, 2000
    )


def live_favorites_remove_action(ch_key, title=''):
    remove(ch_key)
    xbmcgui.Dialog().notification(
        'Live TV Favorites', 'Removed' + (' : %s' % title if title else ''),
        xbmcgui.NOTIFICATION_INFO, 2000
    )


# ── Directory view ────────────────────────────────────────────────────────────

def live_favorites_list(handle, build_url):
    xbmcplugin.setPluginCategory(handle, '❤️ Live TV Favorites')
    xbmcplugin.setContent(handle, 'videos')

    favs = get_all()
    if not favs:
        xbmcgui.Dialog().notification(
            'Live TV Favorites', 'No favorites yet — long-press a channel to add one',
            xbmcgui.NOTIFICATION_INFO, 3000
        )
        xbmcplugin.endOfDirectory(handle, succeeded=True)
        return

    for f in favs:
        ch_key     = str(f['ch_key'])
        title      = f.get('title', '')
        thumb      = f.get('thumb', '')
        fanart     = f.get('fanart', thumb)
        title_enc  = _up.quote(title)

        li = xbmcgui.ListItem(label=title)
        li.setInfo('video', {'title': title})
        li.setArt({'thumb': thumb, 'fanart': fanart})
        li.setProperty('IsPlayable', 'true')
        li.addContextMenuItems([
            ('Remove from Live TV Favorites',
             'RunPlugin(plugin://plugin.video.starfleet/'
             '?action=live_favorites_remove&ch_key=%s&title=%s)' % (_up.quote(ch_key), title_enc))
        ])
        # UPDATE 2026-09-05 — confirmed live via a direct report + kodi.log
        # that this used to prefer the stored `direct_url` (whenever add()
        # was called with one) over a fresh live_unified_play resolve, and
        # that's exactly what broke daddylive-family favorites (CBSNY, USA
        # Network, CTV Canada, all confirmed live): their `direct_url` is a
        # signed, short-lived CDN URL captured the moment they were
        # favorited, and every one of them still 403'd when actually
        # replayed later, same as this codebase's own already-documented
        # reason DLHD/Sports/Adult all re-resolve fresh per click instead
        # of trusting a cached URL (see play_daddylive_catalog's own
        # docstring for the identical precedent). ch_key is unconditionally
        # stored for every favorite (see add() above), so live_unified_play
        # can always be tried — a real "no live stream" failure from that
        # is strictly better than confidently handing the player a URL
        # already known to be capable of going stale, matching this
        # codebase's established "clean failure over stale playback"
        # policy everywhere else this exact problem shows up.
        play_url = build_url({'action': 'live_unified_play', 'ch_key': ch_key, 'ch_title': title})
        xbmcplugin.addDirectoryItem(handle, play_url, li, False)

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(handle, succeeded=True)
