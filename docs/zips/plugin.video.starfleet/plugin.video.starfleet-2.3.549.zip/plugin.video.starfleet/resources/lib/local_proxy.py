# -*- coding: utf-8 -*-
"""
resources/lib/local_proxy.py — a tiny loopback-only HTTP relay built to
close the real, live-confirmed gap behind OK.ru replays failing to play:
Kodi's own inputstream.ffmpegdirect/cURL layer doesn't reliably send back
the exact header a signed OK.ru CDN URL needs (see sports_router.
_resolve_okru's own docstring for the live investigation) — instead of an
instant rejection, the connection just stalls for ~30s and then fails,
confirmed live on both Windows and Firestick alike, so it was never
device-specific the way it first looked.

v2.3.478 shipped this as a per-request server, started lazily inside
whatever short-lived `plugin://` invocation happened to be resolving a
stream — and immediately proved broken via a real kodi.log: this addon
declares <reuselanguageinvoker>false</reuselanguageinvoker>, so Kodi tears
down that entire Python process once the resolving call returns control,
killing the background thread serving the relay right as the player was
starting to stream from it. Same ~30s hang-then-fail as before, just one
layer further in.

Fixed properly here by moving the server into service.py (at the addon
root, registered via addon.xml's xbmc.python.service extension point), a
real Kodi background service (start="startup") that lives for the whole
Kodi session, independent of any single plugin:// call. Since the
resolving call and the service are separate OS processes, they can't
share Python objects directly — they agree on one FIXED port instead
(_PORT below). The resolving side does a fast loopback health-check before
building a relay URL and falls back to the pre-existing direct-URL
behavior if the service isn't up yet (e.g. right after this update, before
the next Kodi restart — services only start at Kodi startup, not
retroactively for an addon that just updated mid-session).

UPDATE 2026-09-05 — confirmed live via a real kodi.log this was built and
never actually finished: addon.xml never declared the xbmc.python.service
extension point at all (so this file's own run_service() never ran, ever
— no "[Starfleet/LocalProxy] service started" line has ever appeared in
any log), AND sports_router._resolve_okru() never called
build_relay_url() below, still handing Kodi's player the direct CDN URL
regardless. Both gaps are fixed alongside this update.

UPDATE 2026-09-05 (later same day) — with the relay actually running and
wired in, a fresh kodi.log (this file's own new per-request logging,
added the same update) showed something the direct-URL failures never
could: Kodi opened SIX separate connections to the relay for the exact
same target URL within about 2 seconds (the first couple with no Range
header at all, the rest with "Range: bytes=0-") — and every one of them
except the last got an upstream TCP reset from okcdn.ru after almost
exactly one 65536-byte chunk; the one connection that got further only
made it to ~8MB before the whole thing still gave up around 32s. That
shape — many near-simultaneous connections to the identical signed URL,
all but one cut short almost immediately — is consistent with okcdn.ru
enforcing (loosely) one live connection per signed URL and punishing the
others, and this relay was making that worse: each of Kodi's own
retry/probe connections got its own brand-new, fully independent upstream
fetch with zero coordination between them. Serializing same-target
requests through a per-URL lock (below) stops the relay from ever having
more than one connection open to okcdn.ru for a given URL at a time,
regardless of how many overlapping requests Kodi itself makes — closing
off that specific way of provoking the CDN's own connection limit,
whatever that limit's exact rule turns out to be.
"""
import threading
import xbmc

_PORT = 51621

# Per-target-URL locks so overlapping requests for the identical upstream
# URL (Kodi's own probe/retry connections landing on this relay at close
# to the same moment — see the docstring update above for why that
# happens and why it matters) are serialized into one upstream connection
# at a time instead of each opening its own independently. Plain dict of
# locks, never pruned — this addon only ever relays a small, short-lived
# number of distinct URLs per session (one active stream at a time in
# practice), so unbounded growth here isn't a real concern.
_target_locks = {}
_target_locks_guard = threading.Lock()


def _lock_for(target):
    with _target_locks_guard:
        lock = _target_locks.get(target)
        if lock is None:
            lock = threading.Lock()
            _target_locks[target] = lock
        return lock

_server = None
_lock = threading.Lock()


def _make_handler():
    import http.server
    import requests as _req

    class _Handler(http.server.BaseHTTPRequestHandler):
        # One response per connection — this only ever serves a whole
        # video or one Range chunk, so HTTP/1.1 keep-alive buys nothing on
        # loopback but does trip a noisy (harmless) ConnectionResetError in
        # socketserver's own next-request read whenever the player
        # disconnects mid-stream (pause/seek/stop) — confirmed live.
        protocol_version = 'HTTP/1.0'

        def log_message(self, fmt, *args):
            pass  # default logs every request to stderr — real errors already go through xbmc.log below

        def do_GET(self):
            from urllib.parse import urlparse, parse_qs, unquote
            q = parse_qs(urlparse(self.path).query)
            target = unquote(q.get('url', [''])[0])
            ua = unquote(q.get('ua', [''])[0])
            if not target:
                self.send_response(400)
                self.end_headers()
                return

            headers = {}
            if ua:
                headers['User-Agent'] = ua
            rng = self.headers.get('Range')
            if rng:
                headers['Range'] = rng

            # Confirmed live 2026-09-05 this relay had NO visibility at all
            # into its own success path — only the upstream-connect
            # exception and the swallowed player-disconnect exception ever
            # logged anything, so a real kodi.log capture of an actual
            # failure (playback hanging ~32s then failing at the demuxer,
            # after the relay itself had already accepted the connection)
            # gave zero signal on whether the relay ever reached upstream,
            # what status it got, or how many bytes it actually served
            # before things went wrong. Logging the request in and the
            # outcome out closes that blind spot for next time.
            xbmc.log('[Starfleet/LocalProxy] GET %s (range=%s)' % (target, rng or '-'), xbmc.LOGINFO)

            # Serialize overlapping requests for the identical target URL —
            # see this module's own docstring (2026-09-05 update) for the
            # live evidence this matters: Kodi's own probe/retry behavior
            # opened up to 6 near-simultaneous connections to this relay
            # for the exact same URL, each spawning its own independent
            # upstream fetch with no coordination, and okcdn.ru cut all but
            # one of them short almost immediately. Only one thread at a
            # time gets to hold an upstream connection to a given target;
            # everyone else queues here first.
            lock = _lock_for(target)
            with lock:
                try:
                    upstream = _req.get(target, headers=headers, stream=True, timeout=20)
                except Exception as e:
                    xbmc.log('[Starfleet/LocalProxy] upstream connect error: %s' % e, xbmc.LOGWARNING)
                    self.send_response(502)
                    self.end_headers()
                    return

                xbmc.log('[Starfleet/LocalProxy] upstream status=%s content-type=%s content-length=%s '
                          'accept-ranges=%s content-range=%s'
                          % (upstream.status_code, upstream.headers.get('Content-Type'),
                             upstream.headers.get('Content-Length'), upstream.headers.get('Accept-Ranges'),
                             upstream.headers.get('Content-Range')), xbmc.LOGINFO)
                sent = 0
                try:
                    self.send_response(upstream.status_code)
                    for h in ('Content-Type', 'Content-Length', 'Content-Range', 'Accept-Ranges'):
                        v = upstream.headers.get(h)
                        if v:
                            self.send_header(h, v)
                    self.end_headers()
                    it = upstream.iter_content(chunk_size=65536)
                    while True:
                        # Split so the log can tell WHICH side actually
                        # dropped the connection — upstream (okcdn.ru
                        # itself resetting the fetch) vs downstream (Kodi
                        # closing its connection to this relay, e.g. a
                        # real seek/stop/exit) look identical as a bare
                        # exception otherwise, and that distinction is
                        # exactly what's still unresolved after the first
                        # round of logging added here.
                        try:
                            chunk = next(it)
                        except StopIteration:
                            break
                        except Exception as e:
                            xbmc.log('[Starfleet/LocalProxy] UPSTREAM dropped connection after %d bytes: %s'
                                      % (sent, e), xbmc.LOGWARNING)
                            return
                        if chunk:
                            try:
                                self.wfile.write(chunk)
                            except Exception as e:
                                xbmc.log('[Starfleet/LocalProxy] downstream (player) closed connection '
                                          'after %d bytes: %s' % (sent, e), xbmc.LOGINFO)
                                return
                            sent += len(chunk)
                    xbmc.log('[Starfleet/LocalProxy] relay complete, %d bytes served' % sent, xbmc.LOGINFO)
                finally:
                    upstream.close()

    return _Handler


def run_service(monitor):
    """Called once from resources/service.py's main thread at Kodi startup.
    Binds _PORT and serves until Kodi asks the service to stop. If the
    port's already taken (another instance already bound it — services
    only start once per Kodi session, but a same-machine multi-instance or
    unclean-restart edge case could still leave one behind), that's
    treated as "already being served, nothing more to do" rather than a
    fatal error."""
    import http.server
    global _server

    try:
        handler = _make_handler()
        _server = http.server.ThreadingHTTPServer(('127.0.0.1', _PORT), handler)
    except OSError as e:
        xbmc.log('[Starfleet/LocalProxy] port %d unavailable (%s) — assuming '
                  'another instance is already serving it' % (_PORT, e), xbmc.LOGINFO)
        _server = None
    else:
        t = threading.Thread(target=_server.serve_forever, daemon=True)
        t.start()
        xbmc.log('[Starfleet/LocalProxy] service started on 127.0.0.1:%d' % _PORT, xbmc.LOGINFO)

    while not monitor.abortRequested():
        if monitor.waitForAbort(5):
            break

    if _server is not None:
        _server.shutdown()
        xbmc.log('[Starfleet/LocalProxy] service stopped', xbmc.LOGINFO)


def _service_reachable():
    import socket
    try:
        with socket.create_connection(('127.0.0.1', _PORT), timeout=0.4):
            return True
    except OSError:
        return False


def build_relay_url(target_url, user_agent=''):
    """Returns a http://127.0.0.1:<_PORT>/relay?url=...&ua=... URL — see
    module docstring for why this is the real fix and not a workaround.
    Raises RuntimeError if the background service isn't reachable (not
    started yet, e.g. right after this update before a Kodi restart), so
    callers can fall back to their pre-existing direct-URL behavior."""
    if not _service_reachable():
        raise RuntimeError('local proxy service not reachable on port %d '
                            '(Kodi may need a restart after this update)' % _PORT)
    from urllib.parse import quote as _uq
    url = 'http://127.0.0.1:%d/relay?url=%s' % (_PORT, _uq(target_url, safe=''))
    if user_agent:
        url += '&ua=%s' % _uq(user_agent, safe='')
    return url
