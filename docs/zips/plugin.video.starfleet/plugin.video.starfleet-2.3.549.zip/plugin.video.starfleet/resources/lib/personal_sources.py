# -*- coding: utf-8 -*-
"""
resources/lib/personal_sources.py

Search the user's personal cloud storage libraries for a matching title.
Credentials come from Settings > Personal Sources (per-installer, never
hardcoded here — a previous version of this file did hardcode a real
MixDrop key/email and Streamtape login/key directly in source, which
shipped in every public addon zip for many versions before being caught
and moved here 2026-08-15).

Both MixDrop and Streamtape use the same folder layout:
  Home/Movies/       — files named "tt1234567 Title (Year) Quality.mp4"
  Home/TV Shows/     — subfolders "tt1234567 Show Name"
                         → subfolders "tt1234567 Season N"  (or "Season N")
                           → episode files named with S01E01
  Home/Porn/         — adult files, matched by title or tt-prefix

Three more real, confirmed-live bugs fixed 2026-09-04, found while wiring
up real credentials for the first time: (1) _md_list_folder() sent a
subfolder's id as the query param `ref=`, but MixDrop's /folderlist only
recognizes `id=` — every subfolder lookup silently got the ROOT listing
back instead (folder navigation never actually worked past the top
level). (2) MixDrop stream resolution called a `/fileref2` endpoint that
doesn't exist (403 at the nginx level, not even reaching the app).
(3) Streamtape's dlticket→dl ticket flow is real but requires waiting out
its own `wait_time` (typically 5s) between the two calls, which this file
never did, so `dl` always failed with "You need to wait N more seconds".
Both hosts' stream resolution now goes through ResolveURL on the plain
watch-page url the folder listing already returns (_resolve()) — same
approach request_sources.py's own resolve_request_stream() already used
— rather than either host's own raw-stream API.
"""

import re
import xbmc
from resources.lib import cache as _cache

try:
    import requests as _req
except ImportError:
    _req = None

# ── shared helpers ─────────────────────────────────────────────────────────────

_RE_IMDB = re.compile(r'\btt(\d{7,8})\b', re.IGNORECASE)
_RE_SxEx = re.compile(r'\bS(\d{1,2})E(\d{1,2})\b', re.IGNORECASE)
_RE_ADE  = re.compile(r'^(\d{4,8})\s+(.+)$')

# Streamtape Porn folder has subfolders — search all of these for adult content
_ST_PORN_SUBFOLDERS = ['movies', 'scenes', '3d porn']
_MD_PORN_SUBFOLDERS = ['movies', 'scenes', '3d porn']

_session = None


def _resolve(url):
    """Hand a Streamtape/MixDrop watch-page URL to ResolveURL for a real
    playable link. Replaces this module's old MixDrop /fileref2 call
    (confirmed live: that endpoint 403s at the nginx level - it doesn't
    exist) and Streamtape's dlticket+dl ticket flow (real, but requires
    waiting out its own `wait_time` - typically 5s - between the two
    calls, which this module never did, so `dl` always failed with "You
    need to wait N more seconds"). Both hosts are standard
    ResolveURL-supported embed sites - same approach request_sources.py's
    own resolve_request_stream() already uses - so there's no need for
    either host's own raw-stream API at all."""
    if not url:
        return ''
    try:
        import resolveurl
        hmf = resolveurl.HostedMediaFile(url)
        if hmf.valid_url():
            r = hmf.resolve()
            if r:
                return r
    except ImportError:
        pass
    except Exception as e:
        xbmc.log('[Personal] resolveurl error: %s' % e, xbmc.LOGWARNING)
    return url


def _sess():
    global _session
    if _session is None and _req:
        _session = _req.Session()
        a = _req.adapters.HTTPAdapter(
            pool_connections=2, pool_maxsize=4,
            max_retries=_req.adapters.Retry(total=2, backoff_factor=0.5)
        )
        _session.mount('https://', a)
        _session.mount('http://', a)
    return _session


def _imdb_from_name(name):
    """Extract numeric IMDB ID from 'tt1234567 Title ...' → '1234567'."""
    m = _RE_IMDB.search(name)
    return m.group(1) if m else ''


def _ade_from_name(name):
    """Extract ADE product ID from '4796444 THR3E #4.mp4' → '4796444'."""
    clean = re.sub(r'\.[a-z0-9]{2,5}$', '', name, flags=re.IGNORECASE).strip()
    m = _RE_ADE.match(clean)
    return m.group(1) if m else ''


def _title_matches(filename, title, year=None):
    """Fuzzy match title against a filename, stripping tt/ADE prefix and quality tags."""
    fname = re.sub(r'\.[a-z0-9]{2,5}$', '', filename, flags=re.IGNORECASE)
    fname = re.sub(r'^tt\d{7,8}\s+', '', fname).strip()    # strip tt-prefix
    fname = re.sub(r'^\d{4,8}\s+', '', fname).strip()      # strip ADE prefix
    fname = re.sub(r'\(\d{4}\).*$', '', fname).strip()     # strip (Year) onwards
    fname = re.sub(r'[._\-]', ' ', fname).lower().strip()
    title_clean = title.lower().strip()
    if title_clean in fname:
        return True
    words = [w for w in title_clean.split() if len(w) > 2]
    return bool(words and all(w in fname for w in words))


# ── MixDrop ───────────────────────────────────────────────────────────────────

_MD_API = 'https://api.mixdrop.ag'


def _md_credentials():
    """(email, key) from Settings > Personal Sources, or ('', '') if the
    user hasn't enabled/filled this in — previously hardcoded directly in
    this file (a real credential, publicly exposed in every shipped addon
    zip); moved to per-installer Settings storage, same pattern already
    used for MegaDebrid/SimplyDebrid.

    Real bug fixed 2026-09-04: xbmcaddon.Addon() with no id relies on
    Kodi's own "current addon" context, which only resolves correctly
    when the calling code is genuinely running AS that addon (a plugin://
    directory listing, a registered service, etc). gui/home.py's own
    Requests screens run through run_home.py's separate script invocation
    - confirmed live via kodi.log: "Script invoked without an addon.
    Adding all addon modules installed to python path as fallback." -
    under which the bare Addon() call silently fails to resolve
    plugin.video.starfleet's own settings at all, so this returned ('','')
    (credentials "not configured") even with real values saved and
    md_personal_enabled genuinely true, showing "No requested movies/
    adult titles yet" instead of the real list. Every other module in
    this addon already names the addon explicitly (e.g. request_sources.py's
    own module-level ADDON = xbmcaddon.Addon('plugin.video.starfleet')) -
    this was the one place still relying on the implicit, context-
    dependent form."""
    try:
        import xbmcaddon
        addon = xbmcaddon.Addon('plugin.video.starfleet')
        if addon.getSetting('md_personal_enabled') != 'true':
            return '', ''
        return (addon.getSetting('md_personal_email').strip(),
                addon.getSetting('md_personal_key').strip())
    except Exception:
        return '', ''


def _md_get(endpoint, params=None, timeout=10):
    s = _sess()
    email, key = _md_credentials()
    if not s or not email or not key:
        return {}
    p = {'email': email, 'key': key}
    if params:
        p.update(params)
    r = s.get(_MD_API + endpoint, params=p, timeout=timeout)
    r.raise_for_status()
    return r.json()


def _md_list_folder(ref=''):
    """List a MixDrop folder → (subfolders, files). Cached 1h.

    Real bug fixed 2026-09-04: this sent the folder id as `ref=<id>`, but
    MixDrop's actual /folderlist endpoint only recognizes `id=<id>` -
    confirmed live (a `ref=` call returns the exact same payload as no
    folder param at all, i.e. the root listing every time). Every
    subfolder lookup in this module - Movies, TV Shows' show/season
    folders, Porn's subfolders - was silently getting the root listing
    back instead, so nothing below the root ever actually matched."""
    ck = 'md_folder_%s' % (ref or 'root')
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        params = {'id': ref} if ref else {}
        data   = _md_get('/folderlist', params)
        result = data.get('result', {})
        if isinstance(result, dict):
            subfolders = result.get('folders', []) or []
            files      = result.get('files',   []) or []
        elif isinstance(result, list):
            subfolders, files = [], result
        else:
            subfolders, files = [], []
        out = (subfolders, files)
        _cache.set(ck, out, 3600)
        return out
    except Exception as e:
        xbmc.log('[Personal/MixDrop] listfolder %r error: %s' % (ref, e), xbmc.LOGWARNING)
        _cache.set(ck, ([], []), 3600)
        return [], []


def _md_root_folders():
    """Return {name_lower: ref} for root-level folders. Cached 7 days —
    but only when it actually found something. Real bug fixed 2026-08-17:
    this used to cache an EMPTY mapping for the full 7 days too, so a
    transient API hiccup or credentials not being configured yet at the
    moment this first ran would keep "root folder not found" showing for
    a week even after the user fixed their Settings - confirmed live this
    exact site (Movies/Porn/TV Shows all present and correctly named) had
    nothing wrong with the folder structure itself, only with how long a
    bad first read could linger."""
    ck = 'md_root_folders'
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    subfolders, _ = _md_list_folder('')
    mapping = {}
    for f in subfolders:
        name = (f.get('title') or f.get('name') or '').strip()
        ref  = f.get('ref') or f.get('id') or ''
        if name and ref:
            mapping[name.lower()] = ref
    _cache.set(ck, mapping, 7 * 24 * 3600 if mapping else 10 * 60)
    return mapping


def _md_find_episode(season_ref, season_num, episode_num):
    """Return the public watch-page URL of the episode file matching
    S{season}E{episode} - see _resolve()'s own docstring for why this is
    a plain url, not a file ref that still needs a separate "resolve"
    call."""
    _, files = _md_list_folder(season_ref)
    ts, te = int(season_num), int(episode_num)
    for f in files:
        fname = f.get('title') or f.get('name') or ''
        m = _RE_SxEx.search(fname)
        if m and int(m.group(1)) == ts and int(m.group(2)) == te:
            return f.get('url', '')
    return ''


def search_mixdrop(title, year=None, media_type='movie', imdb_id=None,
                   season=None, episode=None):
    """
    Search the user's MixDrop personal library.
    - Movies  → Home/Movies/   matched by IMDB ID or title
    - TV      → Home/TV Shows/ → show subfolder → season subfolder → episode file
    - Adult   → Home/Porn/     matched by IMDB ID or title
    """
    if not _req:
        return []

    roots = _md_root_folders()

    if media_type == 'tv':
        target_roots = ['tv shows']
    elif media_type == 'adult':
        target_roots = ['porn']
    else:
        target_roots = ['movies']

    clean_imdb = ''
    if imdb_id:
        m = _RE_IMDB.search(str(imdb_id))
        clean_imdb = m.group(1) if m else str(imdb_id).lstrip('t')

    sources = []

    for root_name in target_roots:
        root_ref = roots.get(root_name)
        if not root_ref:
            xbmc.log('[Personal/MixDrop] root folder "%s" not found' % root_name, xbmc.LOGWARNING)
            continue

        if media_type == 'tv':
            # navigate: TV Shows → show folder → season folder → episode file
            show_folders, _ = _md_list_folder(root_ref)
            show_ref = ''
            for sf in show_folders:
                sf_name = sf.get('title') or sf.get('name') or ''
                if clean_imdb and _imdb_from_name(sf_name) == clean_imdb:
                    show_ref = sf.get('ref') or sf.get('id') or ''
                    break
                if not clean_imdb and _title_matches(sf_name, title):
                    show_ref = sf.get('ref') or sf.get('id') or ''
                    break
            if not show_ref:
                continue

            season_folders, _ = _md_list_folder(show_ref)
            target_s = int(season) if season else 1
            season_ref = ''
            for sf in season_folders:
                sf_name = sf.get('title') or sf.get('name') or ''
                if re.search(r'\bSeason\s+%d\b' % target_s, sf_name, re.IGNORECASE):
                    season_ref = sf.get('ref') or sf.get('id') or ''
                    break
            if not season_ref:
                continue

            ep_url = _md_find_episode(season_ref, target_s, episode or 1)
            if not ep_url:
                continue
            url = _resolve(ep_url)
            if url:
                sources.append({
                    'label': '[MixDrop] %s S%02dE%02d' % (title, target_s, episode or 1),
                    'url':   url,
                })

        elif media_type == 'adult':
            # Porn/ has subfolders (Movies, Scenes, 3D porn) — search each
            porn_subfolders, porn_files = _md_list_folder(root_ref)
            # collect files both directly in Porn/ and in its subfolders
            file_candidates = list(porn_files)
            for psf in porn_subfolders:
                psf_name = (psf.get('title') or psf.get('name') or '').lower()
                if any(psf_name == s for s in _MD_PORN_SUBFOLDERS):
                    psf_ref = psf.get('ref') or psf.get('id') or ''
                    if psf_ref:
                        _, sub_files = _md_list_folder(psf_ref)
                        file_candidates.extend(sub_files)
            for f in file_candidates:
                fname = f.get('title') or f.get('name') or ''
                if not fname or not _title_matches(fname, title):
                    continue
                url = _resolve(f.get('url', ''))
                if not url:
                    continue
                sources.append({'label': '[MixDrop] %s' % fname, 'url': url})

        else:
            # movies: match by IMDB ID or title
            _, files = _md_list_folder(root_ref)
            for f in files:
                fname = f.get('title') or f.get('name') or ''
                if not fname:
                    continue
                f_imdb = _imdb_from_name(fname)
                matched = (clean_imdb and f_imdb and f_imdb == clean_imdb) or \
                          _title_matches(fname, title, year)
                if not matched:
                    continue
                url = _resolve(f.get('url', ''))
                if not url:
                    continue
                sources.append({'label': '[MixDrop] %s' % fname, 'url': url})

    if sources:
        xbmc.log('[Personal/MixDrop] Found %d match(es) for "%s"' % (len(sources), title),
                 xbmc.LOGINFO)
    return sources


# ── Streamtape ────────────────────────────────────────────────────────────────

_ST_API = 'https://api.streamtape.com'


def _st_credentials():
    """(login, key) from Settings > Personal Sources — see
    _md_credentials's own docstring for why this is no longer hardcoded,
    and for why this must name the addon explicitly rather than relying
    on xbmcaddon.Addon()'s implicit "current addon" context (the exact
    same real bug, fixed the same way, here too)."""
    try:
        import xbmcaddon
        addon = xbmcaddon.Addon('plugin.video.starfleet')
        if addon.getSetting('st_personal_enabled') != 'true':
            return '', ''
        return (addon.getSetting('st_personal_login').strip(),
                addon.getSetting('st_personal_key').strip())
    except Exception:
        return '', ''


def _st_get(endpoint, params=None, timeout=10):
    s = _sess()
    login, key = _st_credentials()
    if not s or not login or not key:
        return {}
    p = {'login': login, 'key': key}
    if params:
        p.update(params)
    r = s.get(_ST_API + endpoint, params=p, timeout=timeout)
    r.raise_for_status()
    return r.json()


def _st_list_folder(folder_id=''):
    """List a Streamtape folder → (subfolders, files). Cached 1h."""
    ck = 'st_folder_%s' % (folder_id or 'root')
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        params = {'folder': folder_id} if folder_id else {}
        data   = _st_get('/file/listfolder', params)
        result = data.get('result', {})
        if not isinstance(result, dict):
            raise ValueError('unexpected result: %r' % result)
        folders = result.get('folders', []) or []
        files   = result.get('files',   []) or []
        out = (folders, files)
        _cache.set(ck, out, 3600)
        return out
    except Exception as e:
        xbmc.log('[Personal/Streamtape] listfolder %r error: %s' % (folder_id, e), xbmc.LOGWARNING)
        _cache.set(ck, ([], []), 3600)
        return [], []


def _st_root_folders():
    """Return {name_lower: folder_id} for root-level folders. Cached 7 days
    — same fix as _md_root_folders() above: only when non-empty, otherwise
    a short 10 min negative cache so a credentials fix (or the _ST_PASS
    bug fix) takes effect quickly instead of being stuck behind a week-old
    empty result."""
    ck = 'st_root_folders'
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    folders, _ = _st_list_folder('')
    mapping = {(f.get('name') or '').strip().lower(): f.get('id') or ''
               for f in folders if f.get('name') and f.get('id')}
    _cache.set(ck, mapping, 7 * 24 * 3600 if mapping else 10 * 60)
    return mapping


def _st_find_episode(season_folder_id, season_num, episode_num):
    """Return the public streamtape.com watch-page URL of the episode file
    matching S{season}E{episode} - see _resolve()'s own docstring for why
    this is a plain url now, not a linkid that still needs a separate
    ticket-flow "resolve" call."""
    _, files = _st_list_folder(season_folder_id)
    ts, te = int(season_num), int(episode_num)
    for f in files:
        fname = f.get('name') or ''
        m = _RE_SxEx.search(fname)
        if m and int(m.group(1)) == ts and int(m.group(2)) == te:
            return f.get('link', '')
    return ''


def search_streamtape(title, year=None, media_type='movie', imdb_id=None,
                      season=None, episode=None):
    """
    Search the user's Streamtape personal library.
    - Movies  → Home/Movies/   matched by IMDB ID or title
    - TV      → Home/TV Shows/ → show subfolder → season subfolder → episode file
    - Adult   → Home/Porn/     matched by IMDB ID or title
    """
    # Real bug fixed 2026-08-17: this referenced _ST_PASS, a name that was
    # never defined anywhere in this file (leftover from before credentials
    # moved to Settings-based storage) - a plain NameError on every single
    # call, silently caught by search_personal()'s own try/except and
    # logged as "[Personal] Streamtape error: name '_ST_PASS' is not
    # defined" - confirmed live via a real kodi.log. Streamtape search
    # never actually ran even once before this fix, regardless of whether
    # credentials were configured; _st_get()/_st_root_folders() already
    # check credentials properly via _st_credentials() on every call, so
    # this early-out only ever needed the _req availability check.
    if not _req:
        return []

    roots = _st_root_folders()

    if media_type == 'tv':
        target_roots = ['tv shows']
    elif media_type == 'adult':
        target_roots = ['porn']
    else:
        target_roots = ['movies']

    clean_imdb = ''
    if imdb_id:
        m = _RE_IMDB.search(str(imdb_id))
        clean_imdb = m.group(1) if m else str(imdb_id).lstrip('t')

    sources = []

    for root_name in target_roots:
        root_id = roots.get(root_name)
        if not root_id:
            xbmc.log('[Personal/Streamtape] root folder "%s" not found' % root_name, xbmc.LOGWARNING)
            continue

        if media_type == 'tv':
            show_folders, _ = _st_list_folder(root_id)
            show_id = ''
            for sf in show_folders:
                sf_name = sf.get('name') or ''
                if clean_imdb and _imdb_from_name(sf_name) == clean_imdb:
                    show_id = sf.get('id') or ''
                    break
                if not clean_imdb and _title_matches(sf_name, title):
                    show_id = sf.get('id') or ''
                    break
            if not show_id:
                continue

            season_folders, _ = _st_list_folder(show_id)
            target_s = int(season) if season else 1
            season_id = ''
            for sf in season_folders:
                sf_name = sf.get('name') or ''
                if re.search(r'\bSeason\s+%d\b' % target_s, sf_name, re.IGNORECASE):
                    season_id = sf.get('id') or ''
                    break
            if not season_id:
                continue

            ep_url = _st_find_episode(season_id, target_s, episode or 1)
            if not ep_url:
                continue
            url = _resolve(ep_url)
            if url:
                sources.append({
                    'label': '[Streamtape] %s S%02dE%02d' % (title, target_s, episode or 1),
                    'url':   url,
                })

        elif media_type == 'adult':
            # Porn/ has subfolders (Movies, Scenes, 3D porn) — search each
            porn_subfolders, porn_files = _st_list_folder(root_id)
            file_candidates = list(porn_files)
            for psf in porn_subfolders:
                psf_name = (psf.get('name') or '').lower()
                if any(psf_name == s for s in _ST_PORN_SUBFOLDERS):
                    psf_id = psf.get('id') or ''
                    if psf_id:
                        _, sub_files = _st_list_folder(psf_id)
                        file_candidates.extend(sub_files)
            for f in file_candidates:
                fname = f.get('name') or ''
                if not fname or not _title_matches(fname, title):
                    continue
                url = _resolve(f.get('link', ''))
                if not url:
                    continue
                sources.append({'label': '[Streamtape] %s' % fname, 'url': url})

        else:
            # movies: match by IMDB ID or title
            _, files = _st_list_folder(root_id)
            for f in files:
                fname = f.get('name') or ''
                if not fname:
                    continue
                f_imdb = _imdb_from_name(fname)
                matched = (clean_imdb and f_imdb and f_imdb == clean_imdb) or \
                          _title_matches(fname, title, year)
                if not matched:
                    continue
                url = _resolve(f.get('link', ''))
                if not url:
                    continue
                sources.append({'label': '[Streamtape] %s' % fname, 'url': url})

    if sources:
        xbmc.log('[Personal/Streamtape] Found %d match(es) for "%s"' % (len(sources), title),
                 xbmc.LOGINFO)
    return sources


# ── Unified personal library search ──────────────────────────────────────────

def search_personal(title, year=None, media_type='movie', imdb_id=None,
                    season=None, episode=None):
    """Search all personal library services and return combined source list."""
    sources = []
    try:
        sources += search_mixdrop(title, year=year, media_type=media_type,
                                  imdb_id=imdb_id, season=season, episode=episode)
    except Exception as e:
        xbmc.log('[Personal] MixDrop error: %s' % e, xbmc.LOGWARNING)
    try:
        sources += search_streamtape(title, year=year, media_type=media_type,
                                     imdb_id=imdb_id, season=season, episode=episode)
    except Exception as e:
        xbmc.log('[Personal] Streamtape error: %s' % e, xbmc.LOGWARNING)
    return sources
