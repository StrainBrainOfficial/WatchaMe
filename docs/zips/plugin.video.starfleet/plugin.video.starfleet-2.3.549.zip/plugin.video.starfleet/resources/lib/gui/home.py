"""
Starfleet Home Window.
Data is pre-loaded before doModal() so onInit populates on the GUI thread safely.
Rows swap based on which nav button is focused: Movies → New/Popular/Top Rated,
TV Shows → Popular TV Shows (3 rows), default → New Releases/TV Shows/Trending.
"""
import time
import xbmc
import xbmcgui
import xbmcaddon
from resources.lib.gui.select_dialog import select as _select_dialog
from resources.lib.gui import progress_dialog as _pdlg

try:
    _ADDON = xbmcaddon.Addon('plugin.video.starfleet')
except Exception:
    _ADDON = None

# Genre icons — only the genres we have custom art for get one; every other
# genre keeps the previous behaviour (blank thumb, same as before this
# existed). TMDB's TV genre list uses combined names ("Action & Adventure")
# where the movie list splits them ("Action", "Adventure"), so both map to
# the closest single icon we have.
_GENRE_ICON_MAP = {
    'action':              'action.png',
    'action & adventure':  'action.png',
    'adventure':           'adventure.png',
    'animation':           'animation.png',
    'comedy':              'comedy.png',
    'crime':               'crime.png',
    'documentary':         'documentary.png',
}

def _genre_icon(genre_name):
    try:
        filename = _GENRE_ICON_MAP.get((genre_name or '').strip().lower())
        if not filename:
            return ''
        addon_path = _ADDON.getAddonInfo('path') if _ADDON else \
            xbmcaddon.Addon('plugin.video.starfleet').getAddonInfo('path')
        import os as _os
        import xbmcvfs as _xbmcvfs
        local_path = _os.path.join(addon_path, 'resources', 'skins', 'Default',
                                   'media', 'genres', filename)
        if _xbmcvfs.exists(local_path):
            return local_path
    except Exception as e:
        xbmc.log('[Starfleet/Home] _genre_icon(%s): %s' % (genre_name, e), xbmc.LOGWARNING)
    return ''

def _annotate_watch_status(items):
    """Populate 'watched'/'progress_pct' on each item in-place for the
    CategoryList watched/in-progress indicator. Movies/TV list items only
    ever carry a tmdb_id (TMDB's list endpoints don't expose imdb_id), so
    this checks the 'tmdb:<id>' bridge key watch_history.mark_played()/
    toggle_watched() dual-write alongside the real imdb_id-keyed entry —
    zero extra network calls needed at list-render time."""
    try:
        from resources.lib import watch_history as _wh
    except Exception:
        return items
    for it in items:
        tmdb_id = it.get('tmdb_id')
        if not tmdb_id:
            continue
        try:
            watched, _resume, pct = _wh.get_progress('tmdb:%s' % tmdb_id)
            it['watched'] = watched
            it['progress_pct'] = pct
        except Exception:
            pass
    return items


_ID_PLAY    = 20
_ID_INFO    = 21
_ID_NAV_MOV = 41
_ID_NAV_TV  = 42
_ID_NAV_SPT = 43
_ID_NAV_LIV = 44
_ID_NAV_ADU = 45
_ID_SETTINGS = 46
_ID_NAV_RAD = 47
_ID_ROW0    = 100
_ID_ROW1    = 200
_ID_ROW2    = 300
_ID_ROW3    = 400
_ID_CURSOR  = 90

_NAV_IDS = (_ID_NAV_MOV, _ID_NAV_TV, _ID_NAV_SPT, _ID_NAV_LIV, _ID_NAV_RAD, _ID_NAV_ADU)

# Row list geometry (must match Starfleet-Home.xml) — used to hand-position
# the id=90 focus cursor, since the lists' own <focusedlayout> border does
# not render on some Kodi builds/devices (confirmed on Fire TV / Kodi 21.2).
_ROW_TOP     = {_ID_ROW0: 408, _ID_ROW1: 646, _ID_ROW2: 884}
_ROW_LEFT    = 48
_ITEM_WIDTH  = 120
_CURSOR_MAX_POS = 14  # only the first ~15 unscrolled items have a known pixel position

# Row labels per context (4 rows)
_CONTEXT_LABELS = {
    'default': ['New Releases', 'TV Shows',           'Trending',     'Popular Movies'],
    'movies':  ['New Releases', 'Popular Movies',     'Top Rated',    'Upcoming'],
    'tv':      ['Popular TV',   'Top Rated TV',       'Airing Today', 'On The Air'],
    'sports':  ['Soccer Today', 'NBA & NHL Today',    'MLB & NFL Today', ''],
    'live':    ['Favorite Movies', 'Favorite TV Shows', '', ''],
    'adult':   ['New Releases', 'Recently Added',     'Adult Favorites', ''],
    'trakt_anticipated': ['Anticipated Movies', 'Anticipated Shows', '', ''],
    'radio':   ['Continue Watching', '', '', ''],
}


class HomeWindow(xbmcgui.WindowXML):

    def __init__(self, *args, **kwargs):
        # Accept either old film_rows= or new contexts=
        self._contexts   = kwargs.pop('contexts', None)
        self._close_event = kwargs.pop('close_event', None)
        film_rows        = kwargs.pop('film_rows', None)
        if self._contexts is None:
            rows = film_rows or [[], [], [], []]
            self._contexts = {'default': rows, 'movies': rows, 'tv': rows}
        self._current_ctx = 'default'
        self._film_rows   = self._contexts.get('default', [[], [], [], []])
        self._hero_row    = 0
        self._hero_pos    = 0
        self.pending_nav  = None
        self._navigating  = False
        self._playing     = False
        self._initialized = False
        super(HomeWindow, self).__init__(*args, **kwargs)

    # ---------------------------------------------------------------- lifecycle

    def onInit(self):
        try:
            try:
                _adult_on = xbmcaddon.Addon('plugin.video.starfleet').getSetting('adult_enabled') == 'true'
            except Exception:
                _adult_on = False
            self.setProperty('sf_adult_enabled', 'true' if _adult_on else 'false')
            try:
                self.getControl(_ID_CURSOR).setVisible(False)
            except Exception:
                pass
            if not self._initialized:
                # True first show only — every later onInit() call is a
                # REACTIVATION (Kodi calls this again whenever the window
                # regains focus, including right after xbmc.Player().play()
                # finishes and control returns here), not a fresh open.
                # Confirmed live: unconditionally resetting to 'default'
                # here snapped every nav context — Live/Favorites, Adult,
                # TV, Sports, not just the one Adult-focus bug already
                # fixed separately — straight back to Home's own default
                # view the instant you backed out of anything you'd just
                # played, regardless of which section you were actually
                # browsing beforehand.
                self._initialized = True
                self._apply_context('default')
                if self._film_rows and self._film_rows[0]:
                    self._set_hero(self._film_rows[0][0])
                else:
                    self.setProperty('sf_hero_title', 'Welcome to Starfleet')
        except Exception as e:
            xbmc.log('[Starfleet/Home] onInit: %s' % e, xbmc.LOGERROR)
            import traceback
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

    def onAction(self, action):
        aid = action.getId()
        if aid in (xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK,
                   xbmcgui.ACTION_STOP, xbmcgui.ACTION_PARENT_DIR):
            if self._close_event:
                self._close_event.set()
            self.close()
        elif aid in (xbmcgui.ACTION_MOVE_LEFT, xbmcgui.ACTION_MOVE_RIGHT,
                     xbmcgui.ACTION_MOVE_UP, xbmcgui.ACTION_MOVE_DOWN):
            self._update_hero_from_focus()
        elif aid == 117:  # ACTION_CONTEXT_MENU — long-press OK/Select, same
                          # convention already established in category_list.py
            self._show_row_context_menu()

    def onFocus(self, cid):
        try:
            if cid == _ID_NAV_MOV:
                self._switch_context('movies')
            elif cid == _ID_NAV_TV:
                self._switch_context('tv')
            elif cid == _ID_NAV_SPT:
                self._switch_context('sports')
            elif cid == _ID_NAV_LIV:
                self._switch_context('live')
            elif cid == _ID_NAV_ADU:
                self._switch_context('adult')
            elif cid == _ID_NAV_RAD:
                # Radio itself has no poster/thumbnail-driven browsing to
                # show here (station lists aren't carousel material), so
                # this slot shows Continue Watching instead of reusing
                # 'default' — a real destination rather than a placeholder.
                self._switch_context('radio')
            elif cid == _ID_SETTINGS:
                # This button's onClick has always just opened Kodi's settings
                # dialog directly — there was never a case here for it, so
                # focusing it left _current_ctx (and the carousel underneath)
                # stuck on whatever nav button was focused right before it.
                # Confirmed live: that's 'adult' (Settings sits right after
                # the Adult nav button), so the carousel behind Settings
                # showed adult content instead of anything Settings-specific.
                self._switch_context('trakt_anticipated')
            self._update_hero_from_focus()
        except Exception as e:
            xbmc.log('[Starfleet/Home] onFocus %d: %s' % (cid, e), xbmc.LOGERROR)

    def onClick(self, cid):
        xbmc.log('[Starfleet/Home] onClick cid=%d' % cid, xbmc.LOGINFO)
        try:
            if cid == _ID_PLAY:
                self._play_hero()
            elif cid == _ID_INFO:
                self._show_info()
            elif cid == _ID_NAV_MOV:
                # First custom-skin category grid (proof of concept) —
                # opened in-process via doModal() instead of the
                # ActivateWindow/Videos handoff every other nav button below
                # still uses. Home never closes for this hop, so none of the
                # refused-activation / Container.Update-didn't-land failure
                # modes chased all session even apply. Shows the top-level
                # New Releases/Popular/Top Rated/etc choice first (matches
                # the real native menu) rather than collapsing straight into
                # Popular.
                self._open_movies_menu()
            elif cid == _ID_NAV_TV:
                self._open_tv_menu()
            elif cid == _ID_NAV_SPT:
                self._open_sports_category()
            elif cid == _ID_NAV_LIV:
                self._open_live_tv_menu()
            elif cid == _ID_NAV_ADU:
                # PIN check happens HERE, synchronously, while Home is still
                # the open/active window — not inside dispatcher's adult_menu
                # action. That action also runs its own check as a general
                # entry-point guard, but doing it only there meant the PIN
                # keyboard's modal doModal() was popping up in the middle of
                # the ActivateWindow-driven plugin call this button's click
                # triggers — confirmed in the field to break the transition
                # exactly like the Sports crash-out (any blocking dialog
                # shown mid-ActivateWindow can make Kodi abandon it), except
                # here it wasn't occasional — a PIN prompt fires on every
                # single click once adult_pin_enabled is on.
                try:
                    from resources.lib.pin_lock import pin_required, prompt_pin
                    if pin_required() and not prompt_pin():
                        return
                except Exception as e:
                    xbmc.log('[Starfleet/Home] adult PIN check failed: %s' % e, xbmc.LOGERROR)
                self._open_adult_menu()
            elif cid == _ID_NAV_RAD:
                self._open_radio_menu()
            elif cid == _ID_SETTINGS:
                try:
                    xbmcaddon.Addon('plugin.video.starfleet').openSettings()
                except Exception:
                    xbmc.executebuiltin('RunPlugin(plugin://plugin.video.starfleet/?action=open_settings)')
                try:
                    _adult_on = xbmcaddon.Addon('plugin.video.starfleet').getSetting('adult_enabled') == 'true'
                    self.setProperty('sf_adult_enabled', 'true' if _adult_on else 'false')
                except Exception:
                    pass
            elif cid in (_ID_ROW0, _ID_ROW1, _ID_ROW2, _ID_ROW3):
                self._play_row_item(cid)
        except Exception as e:
            xbmc.log('[Starfleet/Home] onClick %d: %s' % (cid, e), xbmc.LOGERROR)

    # ---------------------------------------------------------------- context

    def _switch_context(self, ctx):
        if ctx == self._current_ctx:
            return
        self._current_ctx = ctx
        self._film_rows   = self._contexts.get(ctx, self._contexts.get('default', [[], [], [], []]))
        self._hero_row    = 0
        self._hero_pos    = 0
        self._apply_context(ctx)

    def _live_favorites_rows(self):
        """Re-read favorites.json fresh every time the Live carousel is
        shown, instead of trusting the snapshot cached in self._contexts
        from Home's last background refresh. A favorite added mid-session
        (favorites_add runs via RunPlugin in its own separate Python
        process — it has no way to reach into this already-open window)
        would otherwise stay invisible here until the addon fully
        restarts, which read as "the carousel is missing shows" even
        though get_movies()/get_tv() themselves have no cap at all."""
        try:
            from resources.lib import favorites as _fav
            def _row(items, media_type):
                return [{'id': str(f.get('tmdb_id', '')), 'tmdb_id': str(f.get('tmdb_id', '')),
                         'title': f.get('title', ''), 'thumb': f.get('thumb', ''),
                         'fanart': f.get('fanart', '') or f.get('thumb', ''),
                         'source': 'tmdb', 'media_type': media_type}
                        for f in items]
            return [_row(_fav.get_movies(), 'movie'), _row(_fav.get_tv(), 'tv'), [], []]
        except Exception as e:
            xbmc.log('[Starfleet/Home] _live_favorites_rows: %s' % e, xbmc.LOGERROR)
            return self._contexts.get('live', [[], [], [], []])

    def _apply_context(self, ctx):
        labels = _CONTEXT_LABELS.get(ctx, _CONTEXT_LABELS['default'])
        for i, lbl in enumerate(labels):
            self.setProperty('sf_row%d_label' % i, lbl)
        if ctx == 'live':
            self._film_rows = self._live_favorites_rows()
        else:
            self._film_rows = self._contexts.get(ctx, self._contexts.get('default', [[], [], [], []]))
        self._populate_carousels()
        if self._film_rows and self._film_rows[0]:
            self._set_hero(self._film_rows[0][0])
        else:
            # Every row in this context is empty (e.g. Live TV with no
            # favorites saved yet) — clear the hero instead of leaving it
            # showing whatever the previously-focused context's item was.
            # Confirmed in the field: switching Sports -> Live TV left the
            # hero banner stuck on a Sports game because this branch didn't
            # exist, so sf_hero_* properties were simply never touched.
            self.setProperty('sf_hero_title', '')
            self.setProperty('sf_hero_meta', '')
            self.setProperty('sf_hero_plot', '')
            self.setProperty('sf_hero_fanart', '')
            self.setProperty('sf_hero_badge', '')

    # ---------------------------------------------------------------- populate

    def _populate_carousels(self):
        for row_idx, list_id in enumerate([_ID_ROW0, _ID_ROW1, _ID_ROW2, _ID_ROW3]):
            films = self._film_rows[row_idx] if row_idx < len(self._film_rows) else []
            ctrl  = self.getControl(list_id)
            ctrl.reset()
            for film in films:
                li = xbmcgui.ListItem(label=film.get('title', ''))
                li.setArt({
                    'thumb':  film.get('thumb', ''),
                    'fanart': film.get('fanart', film.get('thumb', '')),
                })
                li.setProperty('film_id',    str(film.get('id', film.get('tmdb_id', ''))))
                li.setProperty('film_source', film.get('source', 'tmdb'))
                li.setProperty('film_media',  film.get('media_type', 'movie'))
                ctrl.addItem(li)

    def _set_hero(self, film):
        title  = film.get('title', '')
        year   = str(film.get('year', ''))
        rating = str(film.get('rating', ''))
        media  = film.get('media_type', 'movie')
        if film.get('cw_kind') == 'tv_upcoming':
            # Continue Watching's "next episode hasn't aired yet" card —
            # red italic + the air date, per direct request, instead of the
            # usual year/rating line. Kodi labels support [COLOR]/[I] markup
            # tags directly in the text, so this needs no skin XML changes -
            # sf_hero_meta (label id 12 in Starfleet-Home.xml) already
            # renders whatever this property contains as-is.
            air_date = film.get('cw_air_date', '')
            meta = '[COLOR FFFF3B30][I]New episode airs %s[/I][/COLOR]' % (air_date or 'soon')
            badge = 'UPCOMING'
        else:
            meta  = '  |  '.join(p for p in [year, '★ ' + rating if rating else ''] if p)
            badge = 'TV SHOW' if media == 'tv' else 'MOVIE'
        self.setProperty('sf_hero_title',  title)
        self.setProperty('sf_hero_meta',   meta)
        self.setProperty('sf_hero_plot',   film.get('plot', film.get('overview', '')))
        self.setProperty('sf_hero_fanart', film.get('fanart', film.get('thumb', '')))
        self.setProperty('sf_hero_badge',  badge)

    def _update_hero_from_focus(self):
        try:
            rmap = {_ID_ROW0: 0, _ID_ROW1: 1, _ID_ROW2: 2, _ID_ROW3: 3}
            cid  = self.getFocusId()
            if cid in rmap:
                row   = rmap[cid]
                ctrl  = self.getControl(cid)
                pos   = ctrl.getSelectedPosition()
                films = self._film_rows[row] if row < len(self._film_rows) else []
                if films and 0 <= pos < len(films):
                    if row != self._hero_row or pos != self._hero_pos:
                        self._hero_row = row
                        self._hero_pos = pos
                        self._set_hero(films[pos])
                self._update_cursor(cid, pos)
            else:
                self._update_cursor(None, None)
        except Exception:
            pass

    def _update_cursor(self, cid, pos):
        """Position/show the id=90 focus-highlight overlay over the currently
        selected carousel item. Falls back to hiding it once the row has
        scrolled past the first screen of items, since pixel position for
        scrolled-past items isn't available from the container API."""
        try:
            cursor = self.getControl(_ID_CURSOR)
            if cid not in _ROW_TOP or pos is None or pos > _CURSOR_MAX_POS:
                cursor.setVisible(False)
                return
            x = _ROW_LEFT + pos * _ITEM_WIDTH - 6
            y = _ROW_TOP[cid] - 9
            cursor.setPosition(x, y)
            cursor.setVisible(True)
        except Exception:
            pass

    # ---------------------------------------------------------------- actions

    def _play_hero(self):
        films = self._film_rows[self._hero_row] if self._film_rows else []
        if not films:
            return
        pos = self._hero_pos if self._hero_pos < len(films) else 0
        self._play_film(films[pos])

    def _play_row_item(self, cid):
        rmap = {_ID_ROW0: 0, _ID_ROW1: 1, _ID_ROW2: 2, _ID_ROW3: 3}
        row  = rmap[cid]
        try:
            ctrl  = self.getControl(cid)
            pos   = ctrl.getSelectedPosition()
            films = self._film_rows[row] if row < len(self._film_rows) else []
            if films and 0 <= pos < len(films):
                self._play_film(films[pos])
        except Exception as e:
            xbmc.log('[Starfleet/Home] _play_row_item: %s' % e, xbmc.LOGERROR)

    def _show_row_context_menu(self):
        """Long-press on any Home carousel item — Favorites add/remove and
        Mark Watched/Unwatched, the same two actions every CategoryListWindow
        screen's own long-press menu already offers, now reachable straight
        from the home carousel too instead of only after drilling into a
        full category screen. li.addContextMenuItems() doesn't apply here
        (same reason documented in category_list.py's _show_context_menu —
        that auto-display behavior belongs to Kodi's native video window
        classes, not a bespoke WindowXML), so this is handled manually.

        Calls the same favorites.py/adult_favorites.py/watch_history.py
        functions dispatcher.py's RunPlugin actions call — but directly,
        in-process, synchronously — instead of firing an async RunPlugin
        (a brand new headless Python process dispatcher.py runs in, with
        no way to signal this already-open window when it's done). That
        lets the carousel force-refresh immediately after, reflecting the
        change right away instead of only after the next full Home reopen."""
        try:
            rmap  = {_ID_ROW0: 0, _ID_ROW1: 1, _ID_ROW2: 2, _ID_ROW3: 3}
            cid   = self.getFocusId()
            if cid not in rmap:
                return
            row   = rmap[cid]
            pos   = self.getControl(cid).getSelectedPosition()
            films = self._film_rows[row] if row < len(self._film_rows) else []
            if not (films and 0 <= pos < len(films)):
                return
            film = films[pos]

            title  = film.get('title', '')
            thumb  = film.get('thumb', '')
            fanart = film.get('fanart', '') or thumb
            source = film.get('source', 'tmdb')

            if source == 'ade':
                # Adult items key favorites/watched by ade_id, not tmdb_id —
                # same wh_key convention ('ade:<id>') used by every other
                # Adult long-press menu in this addon (see _open_adult_search
                # and the Adult category grids above).
                fid = str(film.get('ade_id', '') or film.get('id', ''))
                if not fid:
                    return
                from resources.lib import adult_favorites as _afav
                try:
                    is_fav = _afav.is_favorite(fid)
                except Exception:
                    is_fav = False
                fav_label = 'Remove from Adult Favorites' if is_fav else 'Add to Adult Favorites'

                def _toggle_fav(fid=fid, title=title, thumb=thumb, fanart=fanart, is_fav=is_fav):
                    if is_fav:
                        _afav.adult_favorites_remove_action(fid, title=title)
                    else:
                        _afav.adult_favorites_add_action(fid, title, thumb=thumb, fanart=fanart)

                def _toggle_watched(fid=fid, title=title):
                    from resources.lib import watch_history as _wh
                    new_state = _wh.toggle_watched('ade:%s' % fid, title=title)
                    xbmcgui.Dialog().notification(
                        'Starfleet', 'Marked Watched' if new_state else 'Marked Unwatched',
                        xbmcgui.NOTIFICATION_INFO, 1500)

                actions = [(fav_label, _toggle_fav), ('Mark as Watched / Unwatched', _toggle_watched)]
            else:
                # Everything else on the carousel (Movies/TV rows, Trakt
                # Anticipated widgets, favorited-items rows, and Continue
                # Watching cards) all carry a real tmdb_id + media_type
                # regardless of their own 'source' label, so one generic
                # path covers all of them. Rows with neither (today's live
                # sports games, which have no tmdb_id at all) fall through
                # to the guard below and simply get no long-press menu —
                # there's nothing meaningful to favorite/mark-watched there.
                tmdb_id = str(film.get('tmdb_id', '') or film.get('id', ''))
                if not tmdb_id:
                    return
                media_type = film.get('media_type', 'movie')
                year = str(film.get('year', '') or '')
                from resources.lib import favorites as _fav
                try:
                    is_fav = _fav.is_favorite(media_type, tmdb_id)
                except Exception:
                    is_fav = False
                fav_label = 'Remove from Favorites' if is_fav else 'Add to Favorites'

                def _toggle_fav(tmdb_id=tmdb_id, media_type=media_type, title=title,
                                year=year, thumb=thumb, fanart=fanart, is_fav=is_fav):
                    if is_fav:
                        _fav.favorites_remove_action(media_type, tmdb_id)
                    else:
                        _fav.favorites_add_action(media_type, tmdb_id, title,
                                                  year=year, thumb=thumb, fanart=fanart)

                # Continue Watching cards carry the show's own NEXT episode
                # as cw_season/cw_episode (see continue_watching.py) — a real,
                # confirmed bug: marking one of these "Watched" used to always
                # toggle_watched() the bare movie-style key (season=0,
                # episode=0) instead of that specific episode, because season/
                # episode were never passed through here at all. _shows_in_
                # progress()'s own local-history scan skips any entry missing
                # BOTH season and episode, so that write was a complete no-op
                # for TV — the show kept reappearing in Continue Watching no
                # matter how many times "Mark as Watched" was used on it
                # (confirmed live: a show already gone from SIMKL's own
                # account data still kept showing here from a genuine local
                # per-device watch_history.json entry that this action could
                # never actually clear). Every other TV row's own Mark
                # Watched (Popular/Favorites/etc, no cw_season on those film
                # dicts) is unaffected — this only changes behavior when
                # cw_season is actually present.
                cw_season  = film.get('cw_season', 0)
                cw_episode = film.get('cw_episode', 0)

                def _toggle_watched(tmdb_id=tmdb_id, media_type=media_type, title=title,
                                    cw_season=cw_season, cw_episode=cw_episode):
                    from resources.lib import watch_history as _wh
                    imdb_id = ''
                    try:
                        from resources.lib import metadata as _md
                        detail = _md.get_tv_detail(tmdb_id) if media_type == 'tv' else _md.get_movie_detail(tmdb_id)
                        imdb_id = detail.get('imdb_id', '') if detail else ''
                    except Exception:
                        imdb_id = ''
                    if not imdb_id:
                        return
                    if cw_season and cw_episode:
                        # A Continue Watching card's "Mark as Watched" means
                        # "dismiss this show" — not "I watched this ONE
                        # episode", which would just advance the pointer to
                        # whatever's unwatched right after it and leave the
                        # card sitting there. dismiss_show marks EVERY
                        # remaining episode in the whole catalog watched in
                        # one pass, so there's nothing left to anchor a new
                        # "next episode" on.
                        from resources.lib import continue_watching as _cw
                        _cw.dismiss_show(tmdb_id, imdb_id, title=title)
                        xbmcgui.Dialog().notification(
                            'Starfleet', 'Removed from Continue Watching',
                            xbmcgui.NOTIFICATION_INFO, 1500)
                    else:
                        new_state = _wh.toggle_watched(imdb_id, title=title, tmdb_id=tmdb_id)
                        xbmcgui.Dialog().notification(
                            'Starfleet', 'Marked Watched' if new_state else 'Marked Unwatched',
                            xbmcgui.NOTIFICATION_INFO, 1500)

                watched_label = ('Remove from Continue Watching' if (cw_season and cw_episode)
                                 else 'Mark as Watched / Unwatched')
                actions = [(fav_label, _toggle_fav), (watched_label, _toggle_watched)]

            labels = [label for label, _ in actions]
            choice = xbmcgui.Dialog().contextmenu(labels)
            if choice < 0:
                return
            actions[choice][1]()
            self._refresh_carousel_after_toggle()
        except Exception as e:
            xbmc.log('[Starfleet/Home] _show_row_context_menu: %s' % e, xbmc.LOGERROR)

    def _adult_favorites_row(self):
        """Re-read adult_favorites.json fresh — same reasoning as
        _live_favorites_rows() above, for the 'adult' context's own
        'Adult Favorites' row (index 2), which get_home_carousel_data()
        only ever builds once per background refresh otherwise."""
        try:
            from resources.lib import adult_favorites as _af
            return [{'id': f['ade_id'], 'ade_id': f['ade_id'], 'ade_slug': '',
                     'title': f.get('title', ''), 'thumb': f.get('thumb', ''),
                     'fanart': f.get('fanart', f.get('thumb', '')),
                     'source': 'ade', 'media_type': 'movie'}
                    for f in _af.get_all()]
        except Exception as e:
            xbmc.log('[Starfleet/Home] _adult_favorites_row: %s' % e, xbmc.LOGERROR)
            return self._film_rows[2] if len(self._film_rows) > 2 else []

    def _continue_watching_row(self):
        """Re-read watch_history.json fresh for the 'radio' context's own
        'Continue Watching' row (index 0) — same reasoning as
        _live_favorites_rows() above. Marking something watched/unwatched
        should make it disappear/reappear here immediately."""
        try:
            from resources.lib import continue_watching as _cw
            return _cw.get_continue_watching(20)
        except Exception as e:
            xbmc.log('[Starfleet/Home] _continue_watching_row: %s' % e, xbmc.LOGERROR)
            return self._film_rows[0] if self._film_rows else []

    def _refresh_carousel_after_toggle(self):
        """Re-render the current context's rows right after a Favorites/
        Watched toggle from the carousel's own long-press menu — re-fetches
        whichever row(s) that context actually derives from favorites.json/
        adult_favorites.json/watch_history.json (Live's Favorite Movies/TV,
        Adult's own Adult Favorites row, Radio's Continue Watching row),
        since get_home_carousel_data() otherwise only rebuilds those once
        per background refresh — a toggle just now would silently not show
        up until the next one. Movies/TV/Sports/Trakt-Anticipated contexts
        have no such user-state-driven row, so they're left as-is. Then
        re-populates the list controls either way. Deliberately does NOT
        call _apply_context() — that always snaps the hero banner back to
        row 0 item 0, a jarring jump right after a long-press action the
        user expects to stay exactly where they are for."""
        if self._current_ctx == 'live':
            self._film_rows = self._live_favorites_rows()
        elif self._current_ctx == 'adult':
            if len(self._film_rows) < 3:
                self._film_rows = list(self._film_rows) + [[]] * (3 - len(self._film_rows))
            self._film_rows[2] = self._adult_favorites_row()
        elif self._current_ctx == 'radio':
            if not self._film_rows:
                self._film_rows = [[]]
            self._film_rows[0] = self._continue_watching_row()
        self._populate_carousels()

    def _play_film(self, film):
        if self._playing:
            return
        self._playing = True
        import threading as _t
        def _reset_playing():
            import time; time.sleep(4)
            self._playing = False
        _t.Thread(target=_reset_playing, daemon=True).start()

        import urllib.parse as _up
        source  = film.get('source', 'tmdb')
        media   = film.get('media_type', 'movie')
        tmdb_id = str(film.get('tmdb_id', film.get('id', '')))
        title   = _up.quote(film.get('title', ''))
        year    = _up.quote(str(film.get('year', '')))

        # Continue Watching cards (Radio nav's carousel — see
        # continue_watching.py): 'tv_next' plays the actual next unwatched
        # episode directly, skipping the season picker every other TV
        # carousel click opens — clicking a Continue Watching card should
        # resume the show, not make the user re-navigate to find where they
        # left off. 'movie_resume' deliberately falls through to the normal
        # tmdb/movie branch below — resuming a movie is just a normal play.
        cw_kind = film.get('cw_kind', '')
        if cw_kind == 'tv_upcoming':
            # Nothing to actually play yet — see continue_watching.py's own
            # comment for why this card is shown at all now instead of
            # being hidden until the air date passes.
            self._playing = False
            air_date = film.get('cw_air_date', '')
            xbmcgui.Dialog().notification(
                'Starfleet', 'Not aired yet — check back %s' % (air_date or 'later'),
                xbmcgui.NOTIFICATION_INFO, 4000)
            return
        if cw_kind == 'tv_next':
            season_num  = film.get('cw_season', 1)
            episode_num = film.get('cw_episode', 1)
            ep_title = _up.quote('%s S%02dE%02d' % (film.get('title', ''), season_num, episode_num))
            self._playing = False  # this path doesn't use the li/Player() flow below
            url = ('plugin://plugin.video.starfleet/?action=meta_ep_play'
                   '&tmdb_id=%s&season_num=%s&episode_num=%s&title=%s' % (
                       tmdb_id, season_num, episode_num, ep_title))
            li = xbmcgui.ListItem(film.get('title', ''))
            li.setProperty('IsPlayable', 'true')
            xbmc.Player().play(url, li)
            return

        if source in ('tmdb', 'anticipated_trailer'):
            # Per direct request: EVERY movie/TV carousel (not just Home's
            # own "Upcoming" widget, which is where this screen started)
            # now opens the same rich detail view instead of jumping
            # straight to season-picker (TV) or straight to play (movie).
            # _open_anticipated_detail was already fully generic — its own
            # _on_play already branches on media_type to reach
            # _open_tv_seasons for a show or a direct play for a movie —
            # so this is a routing change only, no new detail logic needed
            # here. See anticipated_detail.py's own docstring for why the
            # window is no longer scoped to the 'anticipated_trailer' name.
            self._open_anticipated_detail(tmdb_id, media)
            return

        # All playback actions: use xbmc.Player().play() so the home window stays in doModal().
        # ActivateWindow(Videos,...) must NOT be used from within doModal — when setResolvedUrl(False)
        # is returned, Kodi navigates to the parent plugin URL which re-opens the home window.
        li = xbmcgui.ListItem(film.get('title', ''))
        li.setProperty('IsPlayable', 'true')

        if source == 'ade':
            # Call directly in a thread — never go through the plugin URL resolver
            # because setResolvedUrl(False) causes Kodi to navigate to plugin:// root
            # which re-opens the home window in a cascade.
            ade_id_raw   = str(film.get('ade_id', film.get('id', '')))
            ade_slug_raw = str(film.get('ade_slug', ''))
            film_title   = film.get('title', '')
            import threading
            def _ade_thread(aid=ade_id_raw, aslug=ade_slug_raw, t=film_title):
                try:
                    from resources.lib.afdb_router import adult_ade_play_direct
                    adult_ade_play_direct(aid, aslug, t)
                except Exception as exc:
                    xbmc.log('[Starfleet/Home] ade direct play error: %s' % exc, xbmc.LOGERROR)
            threading.Thread(target=_ade_thread, daemon=True).start()
            return

        if source == 'tmdb':
            url = 'plugin://plugin.video.starfleet/?action=meta_movie_play&tmdb_id=%s&title=%s&year=%s' % (tmdb_id, title, year)
        elif source == 'sports':
            event_id   = _up.quote(str(film.get('event_id', '')))
            event_path = _up.quote(str(film.get('event_path', '')))
            sport_slug = film.get('sport_slug', '')
            url = 'plugin://plugin.video.starfleet/?action=sports_event_play&event_id=%s&event_path=%s&sport_slug=%s&title=%s' % (event_id, event_path, sport_slug, title)
        elif source == 'pandamovies':
            slug = film.get('slug', '')
            film_url = _up.quote(film.get('url', ''))
            url = 'plugin://plugin.video.starfleet/?action=adult_panda_play&slug=%s&film_url=%s&title=%s' % (slug, film_url, title)
        elif source == 'hqporner':
            slug = film.get('slug', '')
            film_url = _up.quote(film.get('url', ''))
            url = 'plugin://plugin.video.starfleet/?action=adult_hqp_play&slug=%s&film_url=%s&title=%s' % (slug, film_url, title)
        else:
            film_id = str(film.get('id', ''))
            slug    = film.get('slug', '')
            url = 'plugin://plugin.video.starfleet/?action=afdb_play_search&film_id=%s&film_slug=%s&film_title=%s' % (film_id, slug, title)

        xbmc.Player().play(url, li)

    def _show_info(self):
        films = self._film_rows[self._hero_row] if self._film_rows else []
        if not films:
            return
        film = films[self._hero_pos] if self._hero_pos < len(films) else films[0]
        xbmcgui.Dialog().textviewer(
            film.get('title', 'Info'),
            film.get('plot', film.get('overview', 'No description available.'))
        )

    def _open_anticipated_detail(self, tmdb_id, media):
        """Detail view for Home's own 'Upcoming' widget carousel specifically
        (source='anticipated_trailer') — NOT a general movie/TV detail
        screen. Opened in-process the same way as every other custom window
        here. Play only does something once the real release date has
        passed: for a movie that means the same direct scrape+play call
        _play_film's own 'tmdb' branch already uses; a TV show still needs a
        season/episode picked regardless of release status, so that goes to
        the existing native show page instead, matching how every other TV
        item in this addon already works."""
        try:
            from resources.lib.gui.anticipated_detail import AnticipatedDetailWindow
            from resources.lib import metadata as meta

            dlg = _pdlg.DialogProgress()
            dlg.create('Starfleet', 'Loading details...')
            try:
                # 'mpaa' is already fully resolved here (TMDB's own
                # certification, with metadata.py's SIMKL fallback for
                # titles TMDB has nothing for — see
                # metadata._fill_mpaa_from_simkl) — no separate network
                # call needed in this screen at all.
                detail = meta.get_tv_detail(tmdb_id) if media == 'tv' else meta.get_movie_detail(tmdb_id)
            finally:
                dlg.close()
            if not detail:
                xbmcgui.Dialog().notification('Starfleet', 'Could not load details', xbmcgui.NOTIFICATION_ERROR)
                return

            def _on_play():
                if media == 'tv':
                    # _open_tv_seasons nests another CategoryListWindow, not
                    # a native _nav() transition — don't close this window
                    # first, or Back from the season list drops to Home
                    # instead of back here (same close-before-nesting bug
                    # fixed for Sports/Adult/TV browse list this session).
                    self._open_tv_seasons(tmdb_id, detail.get('title', ''), detail.get('fanart', ''))
                else:
                    import urllib.parse as _up
                    title_q = _up.quote(detail.get('title', ''))
                    year_q  = _up.quote(str(detail.get('year', '')))
                    li = xbmcgui.ListItem(detail.get('title', ''))
                    li.setProperty('IsPlayable', 'true')
                    url = ('plugin://plugin.video.starfleet/?action=meta_movie_play'
                           '&tmdb_id=%s&title=%s&year=%s' % (tmdb_id, title_q, year_q))
                    xbmc.Player().play(url, li)

            def _on_trailer(trailer_url):
                li = xbmcgui.ListItem(detail.get('title', '') + ' - Trailer')
                li.setProperty('IsPlayable', 'true')
                xbmc.Player().play(trailer_url, li)

            def _on_cast_click(name):
                self._detail_win.close()
                self._open_person_films(name, media)

            self._detail_win = AnticipatedDetailWindow(
                'Starfleet-AnticipatedDetail.xml',
                xbmcaddon.Addon('plugin.video.starfleet').getAddonInfo('path'),
                'Default', '1080i',
                tmdb_id=tmdb_id,
                media_type=media,
                detail=detail,
                on_play=_on_play,
                on_trailer=_on_trailer,
                on_cast_click=_on_cast_click,
            )
            self._detail_win.doModal()
            del self._detail_win
        except Exception as e:
            xbmc.log('[Starfleet/Home] _open_anticipated_detail: %s' % e, xbmc.LOGERROR)
            import traceback
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

    def _open_person_films(self, name, media_type='movie'):
        """In-process replacement for the old self._nav('meta_person...')
        route every actor-click callback in this file used to take —
        confirmed live that dropped out of our own custom skin into a
        plain native Kodi Videos listing (keyboard-search look, no
        breadcrumb/subheader styling, no cast strip Info), same class of
        bug already fixed for the Movies/TV Search screens themselves by
        switching them to search_movies_and_people()/search_tv_and_people()
        + a CategoryListWindow. This does the same thing for a name-only
        click (an actor's filmography, not a title+person merge) and stays
        entirely within our own skin, including if the user clicks another
        cast member from inside the resulting list — that recurses back
        into this same method instead of falling back to _nav()."""
        try:
            from resources.lib.gui.category_list import CategoryListWindow
            from resources.lib import metadata as meta
            from urllib.parse import quote

            dlg = _pdlg.DialogProgress()
            dlg.create('Starfleet', 'Searching for %s...' % name)
            try:
                people = meta.search_person(name)
                if people:
                    items = (meta.get_person_movie_credits(people[0]['person_id'])
                              if media_type == 'movie' else
                              meta.get_person_tv_credits(people[0]['person_id']))
                else:
                    items = []
            finally:
                dlg.close()
            if not items:
                xbmcgui.Dialog().notification('Starfleet', 'No results for: %s' % name,
                                              xbmcgui.NOTIFICATION_INFO)
                return
            _annotate_watch_status(items)

            def _detail_fetch(film, _meta=meta):
                tmdb_id = film.get('tmdb_id')
                if not tmdb_id:
                    return {}
                full = (_meta.get_movie_detail(tmdb_id) if media_type == 'movie'
                        else _meta.get_tv_detail(tmdb_id))
                return {
                    'overview': full.get('overview', ''),
                    'cast': [{'name': c.get('name', ''), 'photo': c.get('photo', '')}
                             for c in full.get('cast', [])[:4]],
                }

            def _on_play(film):
                if media_type == 'tv':
                    self._open_tv_seasons(film.get('tmdb_id', ''), film.get('title', ''), film.get('fanart', ''))
                    return
                tmdb_id = film.get('tmdb_id', '')
                title_q = quote(film.get('title', ''))
                year_q  = quote(str(film.get('year', '')))
                li = xbmcgui.ListItem(film.get('title', ''))
                li.setProperty('IsPlayable', 'true')
                url = ('plugin://plugin.video.starfleet/?action=meta_movie_play'
                       '&tmdb_id=%s&title=%s&year=%s' % (tmdb_id, title_q, year_q))
                xbmc.Player().play(url, li)

            def _on_actor_click(actor_name):
                win.close()
                self._open_person_films(actor_name, media_type)

            def _context_menu(film):
                tmdb_id = str(film.get('tmdb_id', ''))
                title   = film.get('title', '')
                year    = str(film.get('year', '') or '')
                thumb   = film.get('thumb', '')
                fanart  = film.get('fanart', '') or thumb
                try:
                    from resources.lib import favorites as _fav
                    is_fav = _fav.is_favorite(media_type, tmdb_id)
                except Exception:
                    is_fav = False
                fav_label  = 'Remove from Favorites' if is_fav else 'Add to Favorites'
                fav_action = 'favorites_remove' if is_fav else 'favorites_add'
                return [
                    (fav_label, 'RunPlugin(plugin://plugin.video.starfleet/'
                     '?action=%s&media_type=%s&tmdb_id=%s&title=%s&year=%s&thumb=%s&fanart=%s)'
                     % (fav_action, media_type, tmdb_id, quote(title), year, quote(thumb), quote(fanart))),
                    ('Mark as Watched / Unwatched',
                     'RunPlugin(plugin://plugin.video.starfleet/'
                     '?action=meta_toggle_watched&media_type=%s&tmdb_id=%s&title=%s)'
                     % (media_type, tmdb_id, quote(title))),
                ]

            win = CategoryListWindow(
                'Starfleet-CategoryList.xml',
                xbmcaddon.Addon('plugin.video.starfleet').getAddonInfo('path'),
                'Default', '1080i',
                items=items,
                breadcrumb='👤 %s' % name,
                subheader='%d titles' % len(items),
                media_type=media_type,
                select_opens_info=True,
                on_play=_on_play,
                detail_fetch=_detail_fetch,
                on_actor_click=_on_actor_click,
                context_menu=_context_menu,
                on_info=lambda film: self._open_anticipated_detail(
                    film.get('tmdb_id') or film.get('id', ''), media_type),
            )
            win.doModal()
            del win
        except Exception as e:
            xbmc.log('[Starfleet/Home] _open_person_films: %s' % e, xbmc.LOGERROR)
            import traceback
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

    def _open_movies_menu(self):
        """Movies' top-level choice, shown as an in-process select dialog
        instead of collapsing straight into Popular — mirrors the real
        native movies_menu items (New Releases/Popular/Top Rated/Now
        Playing/Trending Now are simple sort variants, all opening the
        custom category list; Favorites/Genre/Search have different shapes
        and stay on their existing native pages, same split already used
        for Adult). Dialog().select() here is safe to call whether or not
        another custom window is currently open underneath — it doesn't
        nest a doModal() the way another CategoryListWindow would, so
        there's nothing to close first."""
        try:
            from resources.lib import metadata as meta
            options = ['New Releases', 'Popular', 'Top Rated', 'Now Playing', 'Trending Now',
                       'Favorites', 'Requests', 'Browse by Genre', 'Search']
            # A tiny settling delay before opening the dialog — confirmed live
            # via kodi.log that this button's own OK/select keypress can
            # bleed straight through into a Dialog().select() opened
            # synchronously inside the same onClick handler, auto-selecting
            # whatever's default-focused (index 0) before the dialog is even
            # visible for a frame, so it looks like "no dialog appeared" even
            # though idx came back as a valid selection. Adult's identical
            # picker never showed this because its PIN-entry dialog already
            # absorbs that same keypress first; Movies/TV have no such
            # intervening dialog, so they need their own explicit settle time.
            xbmc.sleep(150)
            idx = _select_dialog('Movies', options)
            if idx == 0:
                self._open_movies_category(meta.get_movies_by_date, 'New Releases')
            elif idx == 1:
                self._open_movies_category(meta.get_movies_popular, 'Popular')
            elif idx == 2:
                self._open_movies_category(meta.get_movies_top_rated, 'Top Rated')
            elif idx == 3:
                self._open_movies_category(meta.get_movies_new, 'Now Playing')
            elif idx == 4:
                self._open_movies_category(meta.get_movies_upcoming, 'Trending Now')
            elif idx == 5:
                self._open_favorites_movies()
            elif idx == 6:
                self._open_requests_movies()
            elif idx == 7:
                self._open_movie_genre_list()
            elif idx == 8:
                self._open_movies_search()
        except Exception as e:
            xbmc.log('[Starfleet/Home] _open_movies_menu: %s' % e, xbmc.LOGERROR)

    def _open_movie_genre_list(self):
        """Genre picker — three-panel skin. Reuses CategoryListWindow's
        on_play callback purely as "item activated" (same convention
        _open_sports_category already uses for its own non-playable
        category picker) to open the chosen genre's paginated movie list."""
        try:
            from resources.lib.gui.category_list import CategoryListWindow
            from resources.lib import metadata as meta

            dlg = _pdlg.DialogProgress()
            dlg.create('Starfleet', 'Loading genres...')
            try:
                genres = meta.get_movie_genres()
            finally:
                dlg.close()
            if not genres:
                xbmcgui.Dialog().notification('Starfleet', 'Could not load genres', xbmcgui.NOTIFICATION_ERROR)
                return

            items = [{'title': g.get('name', ''), 'genre_id': g.get('id', ''),
                      'year': '', 'thumb': _genre_icon(g.get('name', '')),
                      'fanart': '', 'overview': ''} for g in genres]

            def _on_play(g):
                # _open_movies_by_genre nests another CategoryListWindow
                # under this one — don't close win first (close-before-
                # nesting bug, same fix as everywhere else this session).
                self._open_movies_by_genre(g.get('genre_id', ''), g.get('title', ''), 1)

            def _on_more():
                win.close()
                self._open_movies_menu()

            win = CategoryListWindow(
                'Starfleet-CategoryList.xml',
                xbmcaddon.Addon('plugin.video.starfleet').getAddonInfo('path'),
                'Default', '1080i',
                items=items,
                breadcrumb='Movies — Genres',
                subheader='%d genres' % len(items),
                media_type='movie',
                on_play=_on_play,
                on_more=_on_more,
            )
            win.doModal()
            del win
        except Exception as e:
            xbmc.log('[Starfleet/Home] _open_movie_genre_list: %s' % e, xbmc.LOGERROR)
            import traceback
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

    def _open_movies_by_genre(self, genre_id, genre_name, page):
        """Paginated movie list for one genre — same play/detail/actor/
        context-menu wiring as _open_movies_category, but on_more paginates
        deeper into this SAME genre (TMDB /discover/movie genuinely has
        many pages) instead of reopening the Movies sort picker, since a
        genre isn't a fixed-size list the way New Releases/Popular are."""
        try:
            from resources.lib.gui.category_list import CategoryListWindow
            from resources.lib import metadata as meta
            from urllib.parse import quote

            dlg = _pdlg.DialogProgress()
            dlg.create('Starfleet', 'Loading %s...' % genre_name)
            try:
                items = meta.get_movies_by_genre(genre_id, page=page)
            finally:
                dlg.close()
            if not items:
                xbmcgui.Dialog().notification('Starfleet', 'No movies found for %s' % genre_name,
                                              xbmcgui.NOTIFICATION_INFO)
                return
            _annotate_watch_status(items)

            def _detail_fetch(film, _meta=meta):
                tmdb_id = film.get('tmdb_id')
                if not tmdb_id:
                    return {}
                full = _meta.get_movie_detail(tmdb_id)
                return {
                    'overview': full.get('overview', ''),
                    'cast': [{'name': c.get('name', ''), 'photo': c.get('photo', '')}
                             for c in full.get('cast', [])[:4]],
                }

            def _on_play(film):
                tmdb_id = film.get('tmdb_id', '')
                title_q = quote(film.get('title', ''))
                year_q  = quote(str(film.get('year', '')))
                li = xbmcgui.ListItem(film.get('title', ''))
                li.setProperty('IsPlayable', 'true')
                url = ('plugin://plugin.video.starfleet/?action=meta_movie_play'
                       '&tmdb_id=%s&title=%s&year=%s' % (tmdb_id, title_q, year_q))
                xbmc.Player().play(url, li)

            def _on_actor_click(name):
                win.close()
                self._open_person_films(name, 'movie')

            def _on_more():
                win.close()
                self._open_movies_by_genre(genre_id, genre_name, page + 1)

            def _context_menu(film):
                tmdb_id = str(film.get('tmdb_id', ''))
                title   = film.get('title', '')
                year    = str(film.get('year', '') or '')
                thumb   = film.get('thumb', '')
                fanart  = film.get('fanart', '') or thumb
                try:
                    from resources.lib import favorites as _fav
                    is_fav = _fav.is_favorite('movie', tmdb_id)
                except Exception:
                    is_fav = False
                fav_label  = 'Remove from Favorites' if is_fav else 'Add to Favorites'
                fav_action = 'favorites_remove' if is_fav else 'favorites_add'
                return [
                    (fav_label, 'RunPlugin(plugin://plugin.video.starfleet/'
                     '?action=%s&media_type=movie&tmdb_id=%s&title=%s&year=%s&thumb=%s&fanart=%s)'
                     % (fav_action, tmdb_id, quote(title), year, quote(thumb), quote(fanart))),
                    ('Mark as Watched / Unwatched',
                     'RunPlugin(plugin://plugin.video.starfleet/'
                     '?action=meta_toggle_watched&media_type=movie&tmdb_id=%s&title=%s)'
                     % (tmdb_id, quote(title))),
                ]

            win = CategoryListWindow(
                'Starfleet-CategoryList.xml',
                xbmcaddon.Addon('plugin.video.starfleet').getAddonInfo('path'),
                'Default', '1080i',
                items=items,
                breadcrumb='Movies — %s' % genre_name,
                subheader='%d titles  ·  page %d' % (len(items), page),
                media_type='movie',
                select_opens_info=True,
                on_play=_on_play,
                detail_fetch=_detail_fetch,
                on_more=_on_more,
                on_actor_click=_on_actor_click,
                context_menu=_context_menu,
                on_info=lambda film: self._open_anticipated_detail(
                    film.get('tmdb_id') or film.get('id', ''), 'movie'),
            )
            win.doModal()
            del win
        except Exception as e:
            xbmc.log('[Starfleet/Home] _open_movies_by_genre: %s' % e, xbmc.LOGERROR)
            import traceback
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

    def _open_movies_category(self, fetch_fn, label):
        """Custom-skin category grid, opened in-process (doModal() nested
        inside this window's own doModal()) instead of handing off to
        Kodi's native Videos window. fetch_fn is whichever metadata.py
        get_movies_* function _open_movies_menu picked. Play/Person clicks
        from inside it fall back to the existing native _nav() — those
        targets (detail pages, person listings) are out of scope for the
        custom skin per the agreed 'just the top-level grids' plan, so they
        still use the proven ActivateWindow path. Uses a LOCAL window
        variable, not a shared self.* attribute — this window can itself
        open another one (via More Sections re-showing the picker above),
        and a shared attribute would get silently overwritten/deleted out
        from under the outer call once nesting like that is possible."""
        try:
            from resources.lib.gui.category_list import CategoryListWindow
            from resources.lib import metadata as meta
            from urllib.parse import quote

            dlg = _pdlg.DialogProgress()
            dlg.create('Starfleet', 'Loading movies...')
            try:
                items = fetch_fn()
            finally:
                dlg.close()
            if not items:
                xbmcgui.Dialog().notification('Starfleet', 'Could not load movies', xbmcgui.NOTIFICATION_ERROR)
                return
            _annotate_watch_status(items)

            def _detail_fetch(film, _meta=meta):
                tmdb_id = film.get('tmdb_id')
                if not tmdb_id:
                    return {}
                full = _meta.get_movie_detail(tmdb_id)
                return {
                    'overview': full.get('overview', ''),
                    'cast': [{'name': c.get('name', ''), 'photo': c.get('photo', '')}
                             for c in full.get('cast', [])[:4]],
                }

            def _on_play(film):
                # Reuses the exact same direct-play mechanism the Home
                # carousel already uses for 'tmdb' films (xbmc.Player().play
                # on a plugin:// URL, not ActivateWindow/_nav) — meta_movie_play
                # scrapes sources and shows the same pick-a-source dialog
                # every other item in this addon uses, then plays directly.
                tmdb_id = film.get('tmdb_id', '')
                title_q = quote(film.get('title', ''))
                year_q  = quote(str(film.get('year', '')))
                li = xbmcgui.ListItem(film.get('title', ''))
                li.setProperty('IsPlayable', 'true')
                url = ('plugin://plugin.video.starfleet/?action=meta_movie_play'
                       '&tmdb_id=%s&title=%s&year=%s' % (tmdb_id, title_q, year_q))
                xbmc.Player().play(url, li)

            def _on_actor_click(name):
                win.close()
                self._open_person_films(name, 'movie')

            def _on_more():
                # Re-opens the same in-process top-level picker rather than
                # hopping to a native page — lets you jump straight to a
                # different sort (Top Rated, Now Playing, etc) without
                # leaving the reliable in-process path. Only closes THIS
                # window, not before showing the picker — cancelling it
                # leaves this list exactly as it was instead of dumping out
                # to Home (confirmed live as a real bug when the close
                # happened unconditionally, before the picker even showed).
                win.close()
                self._open_movies_menu()

            def _context_menu(film):
                # Restores the long-press Favorites/Mark-Watched options
                # that Kodi/Estuary used to add automatically to native
                # ActivateWindow(Videos,...) listings — lost entirely once
                # this screen moved to a bespoke WindowXML, since that
                # automatic menu is part of the native skin's video window,
                # not something any custom window inherits. imdb_id is
                # blank here (a full detail fetch per list item would be too
                # slow) — meta_toggle_watched resolves it server-side from
                # tmdb_id, same as movie_play() already does before playback.
                tmdb_id = str(film.get('tmdb_id', ''))
                title   = film.get('title', '')
                year    = str(film.get('year', '') or '')
                thumb   = film.get('thumb', '')
                fanart  = film.get('fanart', '') or thumb
                try:
                    from resources.lib import favorites as _fav
                    is_fav = _fav.is_favorite('movie', tmdb_id)
                except Exception:
                    is_fav = False
                fav_label  = 'Remove from Favorites' if is_fav else 'Add to Favorites'
                fav_action = 'favorites_remove' if is_fav else 'favorites_add'
                return [
                    (fav_label, 'RunPlugin(plugin://plugin.video.starfleet/'
                     '?action=%s&media_type=movie&tmdb_id=%s&title=%s&year=%s&thumb=%s&fanart=%s)'
                     % (fav_action, tmdb_id, quote(title), year, quote(thumb), quote(fanart))),
                    ('Mark as Watched / Unwatched',
                     'RunPlugin(plugin://plugin.video.starfleet/'
                     '?action=meta_toggle_watched&media_type=movie&tmdb_id=%s&title=%s)'
                     % (tmdb_id, quote(title))),
                ]

            win = CategoryListWindow(
                'Starfleet-CategoryList.xml',
                xbmcaddon.Addon('plugin.video.starfleet').getAddonInfo('path'),
                'Default', '1080i',
                items=items,
                breadcrumb='Movies',
                subheader='%d titles  ·  %s' % (len(items), label),
                media_type='movie',
                select_opens_info=True,
                on_play=_on_play,
                detail_fetch=_detail_fetch,
                on_more=_on_more,
                on_actor_click=_on_actor_click,
                context_menu=_context_menu,
                on_info=lambda film: self._open_anticipated_detail(
                    film.get('tmdb_id') or film.get('id', ''), 'movie'),
            )
            win.doModal()
            del win
        except Exception as e:
            xbmc.log('[Starfleet/Home] _open_movies_category: %s' % e, xbmc.LOGERROR)
            import traceback
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

    def _open_favorites_movies(self):
        """Custom-skin equivalent of the native favorites_movies() page —
        reads the same local favorites.json store directly (not a live TMDB
        fetch), so it's a flat, already-complete list with no on_more/
        pagination, same as _open_live_tv_country. Play/detail/actor-click/
        context-menu wiring is otherwise identical to _open_movies_by_genre,
        since a favourited movie is just another movie. Context menu offers
        Remove (not Add — everything here already IS a favourite)."""
        try:
            from resources.lib.gui.category_list import CategoryListWindow
            from resources.lib import favorites as _fav
            from urllib.parse import quote

            movies = _fav.get_movies()
            if not movies:
                xbmcgui.Dialog().notification('Starfleet', 'No favourite movies yet',
                                              xbmcgui.NOTIFICATION_INFO)
                return

            items = [{'title': m.get('title', ''), 'year': m.get('year', ''),
                      'thumb': m.get('thumb', ''), 'fanart': m.get('fanart', '') or m.get('thumb', ''),
                      'overview': '', 'tmdb_id': m.get('tmdb_id', '')} for m in movies]

            def _detail_fetch(film):
                tmdb_id = film.get('tmdb_id')
                if not tmdb_id:
                    return {}
                try:
                    from resources.lib import metadata as meta
                    full = meta.get_movie_detail(tmdb_id)
                    return {
                        'overview': full.get('overview', ''),
                        'cast': [{'name': c.get('name', ''), 'photo': c.get('photo', '')}
                                 for c in full.get('cast', [])[:4]],
                    }
                except Exception:
                    return {}

            def _on_play(film):
                tmdb_id = film.get('tmdb_id', '')
                title_q = quote(film.get('title', ''))
                year_q  = quote(str(film.get('year', '')))
                li = xbmcgui.ListItem(film.get('title', ''))
                li.setProperty('IsPlayable', 'true')
                url = ('plugin://plugin.video.starfleet/?action=meta_movie_play'
                       '&tmdb_id=%s&title=%s&year=%s' % (tmdb_id, title_q, year_q))
                xbmc.Player().play(url, li)

            def _on_actor_click(name):
                win.close()
                self._open_person_films(name, 'movie')

            def _context_menu(film):
                tmdb_id = str(film.get('tmdb_id', ''))
                title   = film.get('title', '')
                return [
                    ('Remove from Favorites',
                     'RunPlugin(plugin://plugin.video.starfleet/'
                     '?action=favorites_remove&media_type=movie&tmdb_id=%s&refresh=1)' % tmdb_id),
                    ('Mark as Watched / Unwatched',
                     'RunPlugin(plugin://plugin.video.starfleet/'
                     '?action=meta_toggle_watched&media_type=movie&tmdb_id=%s&title=%s)'
                     % (tmdb_id, quote(title))),
                ]

            win = CategoryListWindow(
                'Starfleet-CategoryList.xml',
                xbmcaddon.Addon('plugin.video.starfleet').getAddonInfo('path'),
                'Default', '1080i',
                items=items,
                breadcrumb='Movies — Favourites',
                subheader='%d titles' % len(items),
                media_type='movie',
                select_opens_info=True,
                on_play=_on_play,
                detail_fetch=_detail_fetch,
                on_actor_click=_on_actor_click,
                context_menu=_context_menu,
                on_info=lambda film: self._open_anticipated_detail(
                    film.get('tmdb_id') or film.get('id', ''), 'movie'),
            )
            win.doModal()
            del win
        except Exception as e:
            xbmc.log('[Starfleet/Home] _open_favorites_movies: %s' % e, xbmc.LOGERROR)
            import traceback
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

    def _open_requests_movies(self):
        """"Requests" — resources/lib/request_sources.py's hand-curated
        movie list (fed by the scraper-PC orchestrator's own manual
        uploads, not TMDB browsing). Flat, already-complete list, same
        shape as _open_favorites_movies but simpler: no context menu
        (nothing to Remove/mark-watched here), and play goes straight to
        the request's own url via action=request_play instead of the
        normal meta_movie_play -> source-picker flow, since there's
        exactly one source per entry, already known up front.

        Enriched with real TMDB poster/fanart/overview via the imdb_id
        each entry already carries (metadata.find_movie_by_imdb) — per
        direct request, since these were shipped with blank thumbs
        originally. Looked up in parallel (one TMDB call per entry) rather
        than sequentially, same reasoning as every other multi-source
        parallel fetch in this codebase; falls back to a blank thumb per
        entry (not a failure for the whole list) if TMDB has no match for
        that particular imdb_id."""
        try:
            from resources.lib.gui.category_list import CategoryListWindow
            from resources.lib import request_sources as _reqsrc
            from resources.lib import metadata as meta
            from urllib.parse import quote
            from concurrent.futures import ThreadPoolExecutor

            requests_list = _reqsrc.get_requested_movies()
            if not requests_list:
                xbmcgui.Dialog().notification('Starfleet', 'No requested movies yet',
                                              xbmcgui.NOTIFICATION_INFO)
                return

            def _enrich(r):
                tmdb = meta.find_movie_by_imdb(r.get('imdb_id', '')) or {}
                return {
                    'title':        tmdb.get('title') or r.get('title', ''),
                    'year':         tmdb.get('year', ''),
                    'thumb':        tmdb.get('thumb', ''),
                    'fanart':       tmdb.get('fanart', ''),
                    'overview':     tmdb.get('overview', ''),
                    'tmdb_id':      tmdb.get('tmdb_id', ''),
                    'request_urls': _reqsrc.entry_urls(r),
                }

            with ThreadPoolExecutor(max_workers=max(len(requests_list), 1)) as pool:
                items = list(pool.map(_enrich, requests_list))

            def _on_play(item):
                urls = item.get('request_urls') or []
                if not urls:
                    return
                if len(urls) > 1:
                    idx = _select_dialog('%s — Choose source' % item.get('title', ''),
                                         ['Source %d' % (i + 1) for i in range(len(urls))])
                    if idx < 0:
                        return
                    chosen = urls[idx]
                else:
                    chosen = urls[0]
                li = xbmcgui.ListItem(item.get('title', ''))
                li.setProperty('IsPlayable', 'true')
                url = ('plugin://plugin.video.starfleet/?action=request_play'
                       '&url=%s&title=%s' % (quote(chosen, safe=''),
                                              quote(item.get('title', ''))))
                xbmc.Player().play(url, li)

            win = CategoryListWindow(
                'Starfleet-CategoryList.xml',
                xbmcaddon.Addon('plugin.video.starfleet').getAddonInfo('path'),
                'Default', '1080i',
                items=items,
                breadcrumb='Movies — Requests',
                subheader='%d titles' % len(items),
                media_type='movie',
                select_opens_info=True,
                on_play=_on_play,
                on_info=lambda film: self._open_anticipated_detail(
                    film.get('tmdb_id', ''), 'movie') if film.get('tmdb_id') else None,
            )
            win.doModal()
            del win
        except Exception as e:
            xbmc.log('[Starfleet/Home] _open_requests_movies: %s' % e, xbmc.LOGERROR)
            import traceback
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

    def _open_movies_search(self):
        """Custom-skin equivalent of the native meta_movies_search page —
        same reason as everything else migrated this session: the native
        version drops out of our own skin into a plain Kodi Videos listing,
        keyboard included. Uses the themed on-screen keyboard for the
        query, then search_movies_and_people() instead of plain
        search_movies() — TMDB's /search/movie only matches titles, so a
        query that's actually an actor/actress's name (e.g. "Tom Cruise")
        used to silently return zero results; search_movies_and_people()
        also resolves the query against TMDB's person search and merges in
        that person's own filmography."""
        try:
            # Kodi's native keyboard — the custom on-screen replacement
            # built for this earlier was confirmed live to have real,
            # hard-to-fully-verify bugs (a physical keypress could fall
            # through to the system keymap instead of typing), so this uses
            # the actual, proven Estuary keyboard implementation directly
            # rather than continuing to reinvent it.
            kb = xbmc.Keyboard('', 'Search Movies')
            kb.doModal()
            if not kb.isConfirmed() or not kb.getText().strip():
                return
            query = kb.getText().strip()

            from resources.lib.gui.category_list import CategoryListWindow
            from resources.lib import metadata as meta
            from urllib.parse import quote

            dlg = _pdlg.DialogProgress()
            dlg.create('Starfleet', 'Searching...')
            try:
                items = meta.search_movies_and_people(query)
            finally:
                dlg.close()
            if not items:
                xbmcgui.Dialog().notification('Starfleet', 'No results for: %s' % query,
                                              xbmcgui.NOTIFICATION_INFO)
                return
            _annotate_watch_status(items)

            def _detail_fetch(film, _meta=meta):
                tmdb_id = film.get('tmdb_id')
                if not tmdb_id:
                    return {}
                full = _meta.get_movie_detail(tmdb_id)
                return {
                    'overview': full.get('overview', ''),
                    'cast': [{'name': c.get('name', ''), 'photo': c.get('photo', '')}
                             for c in full.get('cast', [])[:4]],
                }

            def _on_play(film):
                tmdb_id = film.get('tmdb_id', '')
                title_q = quote(film.get('title', ''))
                year_q  = quote(str(film.get('year', '')))
                li = xbmcgui.ListItem(film.get('title', ''))
                li.setProperty('IsPlayable', 'true')
                url = ('plugin://plugin.video.starfleet/?action=meta_movie_play'
                       '&tmdb_id=%s&title=%s&year=%s' % (tmdb_id, title_q, year_q))
                xbmc.Player().play(url, li)

            def _on_actor_click(name):
                win.close()
                self._open_person_films(name, 'movie')

            def _on_more():
                win.close()
                self._open_movies_search()

            def _context_menu(film):
                tmdb_id = str(film.get('tmdb_id', ''))
                title   = film.get('title', '')
                year    = str(film.get('year', '') or '')
                thumb   = film.get('thumb', '')
                fanart  = film.get('fanart', '') or thumb
                try:
                    from resources.lib import favorites as _fav
                    is_fav = _fav.is_favorite('movie', tmdb_id)
                except Exception:
                    is_fav = False
                fav_label  = 'Remove from Favorites' if is_fav else 'Add to Favorites'
                fav_action = 'favorites_remove' if is_fav else 'favorites_add'
                return [
                    (fav_label, 'RunPlugin(plugin://plugin.video.starfleet/'
                     '?action=%s&media_type=movie&tmdb_id=%s&title=%s&year=%s&thumb=%s&fanart=%s)'
                     % (fav_action, tmdb_id, quote(title), year, quote(thumb), quote(fanart))),
                    ('Mark as Watched / Unwatched',
                     'RunPlugin(plugin://plugin.video.starfleet/'
                     '?action=meta_toggle_watched&media_type=movie&tmdb_id=%s&title=%s)'
                     % (tmdb_id, quote(title))),
                ]

            win = CategoryListWindow(
                'Starfleet-CategoryList.xml',
                xbmcaddon.Addon('plugin.video.starfleet').getAddonInfo('path'),
                'Default', '1080i',
                items=items,
                breadcrumb='Movies — Search',
                subheader='%d results  ·  "%s"' % (len(items), query),
                media_type='movie',
                select_opens_info=True,
                on_play=_on_play,
                detail_fetch=_detail_fetch,
                on_more=_on_more,
                on_actor_click=_on_actor_click,
                context_menu=_context_menu,
                on_info=lambda film: self._open_anticipated_detail(
                    film.get('tmdb_id') or film.get('id', ''), 'movie'),
            )
            win.doModal()
            del win
        except Exception as e:
            xbmc.log('[Starfleet/Home] _open_movies_search: %s' % e, xbmc.LOGERROR)
            import traceback
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

    def _open_tv_menu(self):
        """TV Shows' top-level choice, shown as an in-process select dialog
        instead of collapsing straight into Popular — same reasoning and
        pattern as _open_movies_menu."""
        try:
            from resources.lib import metadata as meta
            options = ['Popular', 'Top Rated', 'Airing Today', 'Favorites', 'Requests',
                       'Browse by Genre', 'Search']
            xbmc.sleep(150)  # see _open_movies_menu for why this settling delay is needed
            idx = _select_dialog('TV Shows', options)
            if idx == 0:
                self._open_tv_category(meta.get_tv_popular, 'Popular')
            elif idx == 1:
                self._open_tv_category(meta.get_tv_top_rated, 'Top Rated')
            elif idx == 2:
                self._open_tv_category(meta.get_tv_airing_today, 'Airing Today')
            elif idx == 3:
                self._open_favorites_tv()
            elif idx == 4:
                self._open_requests_tv()
            elif idx == 5:
                self._open_tv_genre_list()
            elif idx == 6:
                self._open_tv_search()
        except Exception as e:
            xbmc.log('[Starfleet/Home] _open_tv_menu: %s' % e, xbmc.LOGERROR)

    def _open_tv_genre_list(self):
        """Genre picker — three-panel skin, same shape as
        _open_movie_genre_list. on_play here just means "genre activated",
        same convention _open_sports_category already established."""
        try:
            from resources.lib.gui.category_list import CategoryListWindow
            from resources.lib import metadata as meta

            dlg = _pdlg.DialogProgress()
            dlg.create('Starfleet', 'Loading genres...')
            try:
                genres = meta.get_tv_genres()
            finally:
                dlg.close()
            if not genres:
                xbmcgui.Dialog().notification('Starfleet', 'Could not load genres', xbmcgui.NOTIFICATION_ERROR)
                return

            items = [{'title': g.get('name', ''), 'genre_id': g.get('id', ''),
                      'year': '', 'thumb': _genre_icon(g.get('name', '')),
                      'fanart': '', 'overview': ''} for g in genres]

            def _on_play(g):
                # _open_tv_by_genre nests another CategoryListWindow under
                # this one — don't close win first (close-before-nesting
                # bug, same fix as everywhere else this session).
                self._open_tv_by_genre(g.get('genre_id', ''), g.get('title', ''), 1)

            def _on_more():
                win.close()
                self._open_tv_menu()

            win = CategoryListWindow(
                'Starfleet-CategoryList.xml',
                xbmcaddon.Addon('plugin.video.starfleet').getAddonInfo('path'),
                'Default', '1080i',
                items=items,
                breadcrumb='TV Shows — Genres',
                subheader='%d genres' % len(items),
                media_type='tv',
                on_play=_on_play,
                on_more=_on_more,
            )
            win.doModal()
            del win
        except Exception as e:
            xbmc.log('[Starfleet/Home] _open_tv_genre_list: %s' % e, xbmc.LOGERROR)
            import traceback
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

    def _open_tv_by_genre(self, genre_id, genre_name, page):
        """Paginated TV list for one genre — same wiring as
        _open_tv_category (Play routes to _open_tv_seasons, a show isn't
        directly playable), but on_more paginates deeper into this SAME
        genre instead of reopening the TV Shows sort picker."""
        try:
            from resources.lib.gui.category_list import CategoryListWindow
            from resources.lib import metadata as meta
            from urllib.parse import quote

            dlg = _pdlg.DialogProgress()
            dlg.create('Starfleet', 'Loading %s...' % genre_name)
            try:
                items = meta.get_tv_by_genre(genre_id, page=page)
            finally:
                dlg.close()
            if not items:
                xbmcgui.Dialog().notification('Starfleet', 'No TV shows found for %s' % genre_name,
                                              xbmcgui.NOTIFICATION_INFO)
                return
            _annotate_watch_status(items)

            def _detail_fetch(show, _meta=meta):
                tmdb_id = show.get('tmdb_id')
                if not tmdb_id:
                    return {}
                full = _meta.get_tv_detail(tmdb_id)
                return {
                    'overview': full.get('overview', ''),
                    'cast': [{'name': c.get('name', ''), 'photo': c.get('photo', '')}
                             for c in full.get('cast', [])[:4]],
                }

            def _on_play(show):
                self._open_tv_seasons(show.get('tmdb_id', ''), show.get('title', ''), show.get('fanart', ''))

            def _on_actor_click(name):
                win.close()
                self._open_person_films(name, 'tv')

            def _on_more():
                win.close()
                self._open_tv_by_genre(genre_id, genre_name, page + 1)

            def _context_menu(show):
                tmdb_id = str(show.get('tmdb_id', ''))
                title   = show.get('title', '')
                year    = str(show.get('year', '') or '')
                thumb   = show.get('thumb', '')
                fanart  = show.get('fanart', '') or thumb
                try:
                    from resources.lib import favorites as _fav
                    is_fav = _fav.is_favorite('tv', tmdb_id)
                except Exception:
                    is_fav = False
                fav_label  = 'Remove from Favorites' if is_fav else 'Add to Favorites'
                fav_action = 'favorites_remove' if is_fav else 'favorites_add'
                return [
                    (fav_label, 'RunPlugin(plugin://plugin.video.starfleet/'
                     '?action=%s&media_type=tv&tmdb_id=%s&title=%s&year=%s&thumb=%s&fanart=%s)'
                     % (fav_action, tmdb_id, quote(title), year, quote(thumb), quote(fanart))),
                    ('Mark as Watched / Unwatched',
                     'RunPlugin(plugin://plugin.video.starfleet/'
                     '?action=meta_toggle_watched&media_type=tv&tmdb_id=%s&title=%s)'
                     % (tmdb_id, quote(title))),
                ]

            win = CategoryListWindow(
                'Starfleet-CategoryList.xml',
                xbmcaddon.Addon('plugin.video.starfleet').getAddonInfo('path'),
                'Default', '1080i',
                items=items,
                breadcrumb='TV Shows — %s' % genre_name,
                subheader='%d shows  ·  page %d' % (len(items), page),
                media_type='tv',
                select_opens_info=True,
                on_play=_on_play,
                detail_fetch=_detail_fetch,
                on_more=_on_more,
                on_actor_click=_on_actor_click,
                context_menu=_context_menu,
                on_info=lambda film: self._open_anticipated_detail(
                    film.get('tmdb_id') or film.get('id', ''), 'tv'),
            )
            win.doModal()
            del win
        except Exception as e:
            xbmc.log('[Starfleet/Home] _open_tv_by_genre: %s' % e, xbmc.LOGERROR)
            import traceback
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

    def _open_tv_category(self, fetch_fn, label):
        """Same in-process doModal() pattern as _open_movies_category,
        sourced from TMDB TV data instead of movies (_slim_tv already
        normalizes to the same title/year/thumb/fanart/overview shape, so
        this is otherwise a straight copy). fetch_fn is whichever
        metadata.py get_tv_* function _open_tv_menu picked. Play is NOT a
        direct scrape+play call like Movies/Adult — a TV show isn't itself
        playable, it needs a season/episode picked first, so this correctly
        routes to the same meta_tv_show native season/episode listing
        Home's own carousel already uses for 'tv' media_type items. That's
        a real, necessary exception to the 'no separate page' rule, not the
        meta_movie_detail mistake from before — a show genuinely needs
        hierarchical navigation a movie doesn't. Uses a LOCAL window
        variable — see _open_movies_category for why a shared self.*
        attribute isn't safe once a window can re-open the picker above it."""
        try:
            from resources.lib.gui.category_list import CategoryListWindow
            from resources.lib import metadata as meta
            from urllib.parse import quote

            dlg = _pdlg.DialogProgress()
            dlg.create('Starfleet', 'Loading TV shows...')
            try:
                items = fetch_fn()
            finally:
                dlg.close()
            if not items:
                xbmcgui.Dialog().notification('Starfleet', 'Could not load TV shows', xbmcgui.NOTIFICATION_ERROR)
                return
            _annotate_watch_status(items)

            def _detail_fetch(show, _meta=meta):
                tmdb_id = show.get('tmdb_id')
                if not tmdb_id:
                    return {}
                full = _meta.get_tv_detail(tmdb_id)
                return {
                    'overview': full.get('overview', ''),
                    'cast': [{'name': c.get('name', ''), 'photo': c.get('photo', '')}
                             for c in full.get('cast', [])[:4]],
                }

            def _on_play(show):
                # _open_tv_seasons nests another CategoryListWindow under
                # this one — don't close win first (close-before-nesting
                # bug, same fix as Sports/Adult).
                self._open_tv_seasons(show.get('tmdb_id', ''), show.get('title', ''), show.get('fanart', ''))

            def _on_actor_click(name):
                win.close()
                self._open_person_films(name, 'tv')

            def _on_more():
                win.close()
                self._open_tv_menu()

            def _context_menu(show):
                tmdb_id = str(show.get('tmdb_id', ''))
                title   = show.get('title', '')
                year    = str(show.get('year', '') or '')
                thumb   = show.get('thumb', '')
                fanart  = show.get('fanart', '') or thumb
                try:
                    from resources.lib import favorites as _fav
                    is_fav = _fav.is_favorite('tv', tmdb_id)
                except Exception:
                    is_fav = False
                fav_label  = 'Remove from Favorites' if is_fav else 'Add to Favorites'
                fav_action = 'favorites_remove' if is_fav else 'favorites_add'
                return [
                    (fav_label, 'RunPlugin(plugin://plugin.video.starfleet/'
                     '?action=%s&media_type=tv&tmdb_id=%s&title=%s&year=%s&thumb=%s&fanart=%s)'
                     % (fav_action, tmdb_id, quote(title), year, quote(thumb), quote(fanart))),
                    ('Mark as Watched / Unwatched',
                     'RunPlugin(plugin://plugin.video.starfleet/'
                     '?action=meta_toggle_watched&media_type=tv&tmdb_id=%s&title=%s)'
                     % (tmdb_id, quote(title))),
                ]

            win = CategoryListWindow(
                'Starfleet-CategoryList.xml',
                xbmcaddon.Addon('plugin.video.starfleet').getAddonInfo('path'),
                'Default', '1080i',
                items=items,
                breadcrumb='TV Shows',
                subheader='%d shows  ·  %s' % (len(items), label),
                media_type='tv',
                select_opens_info=True,
                on_play=_on_play,
                detail_fetch=_detail_fetch,
                on_more=_on_more,
                on_actor_click=_on_actor_click,
                context_menu=_context_menu,
                on_info=lambda film: self._open_anticipated_detail(
                    film.get('tmdb_id') or film.get('id', ''), 'tv'),
            )
            win.doModal()
            del win
        except Exception as e:
            xbmc.log('[Starfleet/Home] _open_tv_category: %s' % e, xbmc.LOGERROR)
            import traceback
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

    def _open_requests_tv(self):
        """"Requests" — resources/lib/request_sources.py's hand-curated TV
        episode list, grouped by show (one row per distinct show, not one
        row per uploaded episode) per direct request — keeps the listing
        clean even when a show only has e.g. S02E03 sitting in the
        account so far. Selecting a show opens the same rich detail
        screen (poster/cast/plot, Play → Seasons/Trailer/Content Advisory/
        Favorites) every other TV entry point in this addon uses, via the
        exact same select_opens_info + on_info(_open_anticipated_detail)
        pattern _open_requests_movies already uses just above — "Seasons"
        from there drills into the normal season/episode picker, whose own
        per-episode source list already surfaces this exact upload as a
        "[Request]" row via request_sources.find_tv_request() (unaffected
        by this change — that matching was already working and isn't
        touched here, this only changes how the flat list is BROWSED).

        Enriched with real TMDB data via metadata.find_tv_episode_by_title,
        called once per distinct SHOW rather than once per uploaded
        episode — this schema has no imdb_id the way movies do (scene-
        release filenames don't embed one), so this resolves by show
        title instead, using whichever uploaded episode was seen first for
        that show as the season/episode hint."""
        try:
            from resources.lib.gui.category_list import CategoryListWindow
            from resources.lib import request_sources as _reqsrc
            from resources.lib import metadata as meta
            from concurrent.futures import ThreadPoolExecutor
            import re as _re

            requests_list = _reqsrc.get_requested_tv()
            if not requests_list:
                xbmcgui.Dialog().notification('Starfleet', 'No requested TV episodes yet',
                                              xbmcgui.NOTIFICATION_INFO)
                return

            def _norm(t):
                return _re.sub(r'[^a-z0-9]', '', (t or '').lower())

            shows = {}
            for r in requests_list:
                key = _norm(r.get('title', ''))
                if key:
                    shows.setdefault(key, r)

            def _enrich(r):
                season, episode = r.get('season', ''), r.get('episode', '')
                tmdb = meta.find_tv_episode_by_title(r.get('title', ''), season, episode) or {}
                return {
                    'title':    tmdb.get('title') or r.get('title', ''),
                    'year':     '',
                    'thumb':    tmdb.get('thumb', ''),
                    'fanart':   tmdb.get('fanart', ''),
                    'overview': tmdb.get('overview', ''),
                    'tmdb_id':  tmdb.get('tmdb_id', ''),
                }

            with ThreadPoolExecutor(max_workers=max(len(shows), 1)) as pool:
                items = list(pool.map(_enrich, shows.values()))

            win = CategoryListWindow(
                'Starfleet-CategoryList.xml',
                xbmcaddon.Addon('plugin.video.starfleet').getAddonInfo('path'),
                'Default', '1080i',
                items=items,
                breadcrumb='TV Shows — Requests',
                subheader='%d shows' % len(items),
                media_type='tv',
                select_opens_info=True,
                on_info=lambda film: self._open_anticipated_detail(
                    film.get('tmdb_id', ''), 'tv') if film.get('tmdb_id') else None,
            )
            win.doModal()
            del win
        except Exception as e:
            xbmc.log('[Starfleet/Home] _open_requests_tv: %s' % e, xbmc.LOGERROR)
            import traceback
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

    def _open_favorites_tv(self):
        """Custom-skin equivalent of the native favorites_tv() page — same
        local favorites.json store, flat/complete list (no on_more), same
        shape as _open_favorites_movies. Play routes to _open_tv_seasons
        (a show isn't directly playable), same as _open_tv_category/
        _open_tv_by_genre."""
        try:
            from resources.lib.gui.category_list import CategoryListWindow
            from resources.lib import favorites as _fav
            from urllib.parse import quote

            shows = _fav.get_tv()
            if not shows:
                xbmcgui.Dialog().notification('Starfleet', 'No favourite TV shows yet',
                                              xbmcgui.NOTIFICATION_INFO)
                return

            items = [{'title': s.get('title', ''), 'year': s.get('year', ''),
                      'thumb': s.get('thumb', ''), 'fanart': s.get('fanart', '') or s.get('thumb', ''),
                      'overview': '', 'tmdb_id': s.get('tmdb_id', '')} for s in shows]

            def _detail_fetch(show):
                tmdb_id = show.get('tmdb_id')
                if not tmdb_id:
                    return {}
                try:
                    from resources.lib import metadata as meta
                    full = meta.get_tv_detail(tmdb_id)
                    return {
                        'overview': full.get('overview', ''),
                        'cast': [{'name': c.get('name', ''), 'photo': c.get('photo', '')}
                                 for c in full.get('cast', [])[:4]],
                    }
                except Exception:
                    return {}

            def _on_play(show):
                self._open_tv_seasons(show.get('tmdb_id', ''), show.get('title', ''), show.get('fanart', ''))

            def _on_actor_click(name):
                win.close()
                self._open_person_films(name, 'tv')

            def _context_menu(show):
                tmdb_id = str(show.get('tmdb_id', ''))
                title   = show.get('title', '')
                return [
                    ('Remove from Favorites',
                     'RunPlugin(plugin://plugin.video.starfleet/'
                     '?action=favorites_remove&media_type=tv&tmdb_id=%s&refresh=1)' % tmdb_id),
                    ('Mark as Watched / Unwatched',
                     'RunPlugin(plugin://plugin.video.starfleet/'
                     '?action=meta_toggle_watched&media_type=tv&tmdb_id=%s&title=%s)'
                     % (tmdb_id, quote(title))),
                ]

            win = CategoryListWindow(
                'Starfleet-CategoryList.xml',
                xbmcaddon.Addon('plugin.video.starfleet').getAddonInfo('path'),
                'Default', '1080i',
                items=items,
                breadcrumb='TV Shows — Favourites',
                subheader='%d shows' % len(items),
                media_type='tv',
                select_opens_info=True,
                on_play=_on_play,
                detail_fetch=_detail_fetch,
                on_actor_click=_on_actor_click,
                context_menu=_context_menu,
                on_info=lambda film: self._open_anticipated_detail(
                    film.get('tmdb_id') or film.get('id', ''), 'tv'),
            )
            win.doModal()
            del win
        except Exception as e:
            xbmc.log('[Starfleet/Home] _open_favorites_tv: %s' % e, xbmc.LOGERROR)
            import traceback
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

    def _open_tv_search(self):
        """Custom-skin equivalent of the native meta_tv_search page — same
        themed keyboard + search_tv_and_people() fix as _open_movies_search,
        so an actor/actress's name surfaces their TV credits instead of
        nothing."""
        try:
            # See _open_movies_search for why this uses Kodi's native
            # keyboard directly instead of the custom on-screen rebuild.
            kb = xbmc.Keyboard('', 'Search TV Shows')
            kb.doModal()
            if not kb.isConfirmed() or not kb.getText().strip():
                return
            query = kb.getText().strip()

            from resources.lib.gui.category_list import CategoryListWindow
            from resources.lib import metadata as meta
            from urllib.parse import quote

            dlg = _pdlg.DialogProgress()
            dlg.create('Starfleet', 'Searching...')
            try:
                items = meta.search_tv_and_people(query)
            finally:
                dlg.close()
            if not items:
                xbmcgui.Dialog().notification('Starfleet', 'No results for: %s' % query,
                                              xbmcgui.NOTIFICATION_INFO)
                return
            _annotate_watch_status(items)

            def _detail_fetch(show, _meta=meta):
                tmdb_id = show.get('tmdb_id')
                if not tmdb_id:
                    return {}
                full = _meta.get_tv_detail(tmdb_id)
                return {
                    'overview': full.get('overview', ''),
                    'cast': [{'name': c.get('name', ''), 'photo': c.get('photo', '')}
                             for c in full.get('cast', [])[:4]],
                }

            def _on_play(show):
                self._open_tv_seasons(show.get('tmdb_id', ''), show.get('title', ''), show.get('fanart', ''))

            def _on_actor_click(name):
                win.close()
                self._open_person_films(name, 'tv')

            def _on_more():
                win.close()
                self._open_tv_search()

            def _context_menu(show):
                tmdb_id = str(show.get('tmdb_id', ''))
                title   = show.get('title', '')
                year    = str(show.get('year', '') or '')
                thumb   = show.get('thumb', '')
                fanart  = show.get('fanart', '') or thumb
                try:
                    from resources.lib import favorites as _fav
                    is_fav = _fav.is_favorite('tv', tmdb_id)
                except Exception:
                    is_fav = False
                fav_label  = 'Remove from Favorites' if is_fav else 'Add to Favorites'
                fav_action = 'favorites_remove' if is_fav else 'favorites_add'
                return [
                    (fav_label, 'RunPlugin(plugin://plugin.video.starfleet/'
                     '?action=%s&media_type=tv&tmdb_id=%s&title=%s&year=%s&thumb=%s&fanart=%s)'
                     % (fav_action, tmdb_id, quote(title), year, quote(thumb), quote(fanart))),
                    ('Mark as Watched / Unwatched',
                     'RunPlugin(plugin://plugin.video.starfleet/'
                     '?action=meta_toggle_watched&media_type=tv&tmdb_id=%s&title=%s)'
                     % (tmdb_id, quote(title))),
                ]

            win = CategoryListWindow(
                'Starfleet-CategoryList.xml',
                xbmcaddon.Addon('plugin.video.starfleet').getAddonInfo('path'),
                'Default', '1080i',
                items=items,
                breadcrumb='TV Shows — Search',
                subheader='%d results  ·  "%s"' % (len(items), query),
                media_type='tv',
                select_opens_info=True,
                on_play=_on_play,
                detail_fetch=_detail_fetch,
                on_more=_on_more,
                on_actor_click=_on_actor_click,
                context_menu=_context_menu,
                on_info=lambda film: self._open_anticipated_detail(
                    film.get('tmdb_id') or film.get('id', ''), 'tv'),
            )
            win.doModal()
            del win
        except Exception as e:
            xbmc.log('[Starfleet/Home] _open_tv_search: %s' % e, xbmc.LOGERROR)
            import traceback
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

    def _open_tv_seasons(self, tmdb_id, show_title='', show_fanart=''):
        """Custom-skin season picker — same CategoryListWindow used for every
        browse list in this addon, just fed season items instead of
        movies/shows. Replaces the native meta_tv_show season-list page.
        Season click still goes to the native meta_tv_episodes page (not
        built out with this skin yet — one hierarchy level at a time,
        matching how this whole custom-skin rollout has proceeded all
        session). Called from three places (Home's own TV carousel click,
        the Anticipated-widget detail Play button, and the TV Shows browse
        list's Play) — none of them may close their own window before this
        one opens, same close-before-nesting bug already fixed for Sports/
        Adult: this window nests UNDER whichever one opened it, so Back
        correctly lands back there instead of dropping to Home."""
        try:
            from resources.lib.gui.category_list import CategoryListWindow
            from resources.lib import metadata as meta
            from urllib.parse import quote

            dlg = _pdlg.DialogProgress()
            dlg.create('Starfleet', 'Loading seasons...')
            try:
                show = meta.get_tv_detail(tmdb_id)
            finally:
                dlg.close()
            if not show:
                xbmcgui.Dialog().notification('Starfleet', 'Could not load show', xbmcgui.NOTIFICATION_ERROR)
                return
            seasons = show.get('seasons', [])
            if not seasons:
                xbmcgui.Dialog().notification('Starfleet', 'No seasons found', xbmcgui.NOTIFICATION_INFO)
                return

            title  = show_title or show.get('title', '')
            fanart = show_fanart or show.get('fanart', '')
            # Resolved ONCE for the whole show, same reasoning as
            # _open_tv_episodes' own _wh_key — every per-episode toggle
            # already writes/reads under this exact key (real imdb_id, or
            # the tvdb_id/tmdb_id fallback for a show without one), so the
            # new season-level bulk toggle below has to match it exactly
            # or it'd silently write to a key nothing else ever checks.
            _wh_key = show.get('imdb_id') or show.get('tvdb_id') or tmdb_id or ''

            items = []
            for s in seasons:
                items.append({
                    'tmdb_id':       tmdb_id,
                    'season_num':    s.get('season', 0),
                    'title':         s.get('name', 'Season %s' % s.get('season', '')),
                    'year':          '',
                    'thumb':         s.get('thumb', '') or show.get('thumb', ''),
                    'fanart':        fanart,
                    'overview':      s.get('overview', '') or show.get('overview', ''),
                    'episode_count': s.get('episode_count', 0),
                })

            def _on_play(season):
                # _open_tv_episodes nests another CategoryListWindow under
                # this one — don't close win first (close-before-nesting
                # bug, same fix as everywhere else this session).
                self._open_tv_episodes(
                    tmdb_id, season.get('season_num', ''), title,
                    show.get('thumb', ''), fanart, show.get('tvdb_id', ''))

            def _context_menu(season):
                # Per direct request: mark a whole season watched/unwatched
                # from the season picker itself, instead of one episode at
                # a time in the episode list. meta_toggle_season_watched
                # (dispatcher.py) does the actual bulk write.
                return [
                    ('Mark Season as Watched / Unwatched',
                     'RunPlugin(plugin://plugin.video.starfleet/'
                     '?action=meta_toggle_season_watched&media_type=tv&wh_key=%s'
                     '&tmdb_id=%s&tvdb_id=%s&season=%s&title=%s)'
                     % (quote(str(_wh_key)), quote(str(tmdb_id)),
                        quote(str(show.get('tvdb_id', ''))),
                        season.get('season_num', ''), quote(title)))
                ]

            win = CategoryListWindow(
                'Starfleet-CategoryList.xml',
                xbmcaddon.Addon('plugin.video.starfleet').getAddonInfo('path'),
                'Default', '1080i',
                items=items,
                breadcrumb=title,
                subheader='%d seasons' % len(items),
                media_type='tv',
                on_play=_on_play,
                context_menu=_context_menu,
            )
            win.doModal()
            del win
        except Exception as e:
            xbmc.log('[Starfleet/Home] _open_tv_seasons: %s' % e, xbmc.LOGERROR)
            import traceback
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

    def _open_tv_episodes(self, tmdb_id, season_num, show_title='', show_poster='',
                          show_fanart='', tvdb_id=''):
        """Custom-skin episode list — reuses CategoryListWindow with
        show_left_thumb=True (episode still image where cast would go,
        metadata text moved below it) and static_poster=show_poster (right
        panel stays the show's own poster instead of changing per episode,
        since an episode doesn't have its own poster art). Play uses the
        same direct scrape-and-play mechanism as every other play action in
        this addon (meta_ep_play), not a native page."""
        try:
            from resources.lib.gui.category_list import CategoryListWindow
            from resources.lib import metadata as meta
            from urllib.parse import quote

            dlg = _pdlg.DialogProgress()
            dlg.create('Starfleet', 'Loading episodes...')
            try:
                episodes = meta.get_episodes(tmdb_id, season_num, tvdb_id or None)
            finally:
                dlg.close()
            # Same air-date guard as metadata_router.py's tv_season_episodes()
            # (the native episode-list page) — confirmed live this custom-skin
            # window is a completely separate code path that calls
            # meta.get_episodes() directly, so it never picked up that fix at
            # all: Favorites, the Home TV carousel, the Anticipated widget,
            # and the TV Shows browse list all route through here (see this
            # method's own docstring for the full list of callers) and were
            # still showing TMDB-listed-but-not-yet-aired episodes as playable.
            # Unaired episodes stay excluded except for exactly one: the
            # single nearest upcoming episode is now kept and shown at the
            # end of the list (styled distinctly by _label_for, gated off
            # from playback below) so the user can see what's coming and
            # when, instead of the season just silently ending early.
            _today = time.strftime('%Y-%m-%d')
            aired_episodes = [ep for ep in episodes if ep.get('aired') and ep.get('aired') <= _today]
            upcoming = sorted(
                (ep for ep in episodes if ep.get('aired') and ep.get('aired') > _today),
                key=lambda e: e['aired']
            )
            next_unaired = upcoming[0] if upcoming else None
            episodes = aired_episodes + ([next_unaired] if next_unaired else [])
            if not episodes:
                xbmcgui.Dialog().notification('Starfleet', 'No episodes found', xbmcgui.NOTIFICATION_INFO)
                return

            # Resolve the show's real imdb_id ONCE (not per-episode) — must
            # match the exact key episode_play() writes watch_history under
            # (it resolves and uses the real imdb_id too, needed for SIMKL
            # sync). Checking under tvdb_id/tmdb_id instead — a totally
            # different id than what's actually written — was confirmed
            # live as the reason the native episode list never showed
            # watched status either; fixed there the same way.
            _wh_key = None
            show = {}
            try:
                from resources.lib import watch_history as _wh
                show = meta.get_tv_detail(tmdb_id) or {}
                _wh_key = show.get('imdb_id') or None
            except Exception:
                _wh = None
            _wh_key = _wh_key or tvdb_id or tmdb_id or ''
            # Same show-level cast (with photos) Movies/Adult already show —
            # TMDB's per-episode endpoint doesn't carry its own guest-star
            # list in what get_episodes() returns, so this is the show's
            # main cast, fetched once above (not per-episode). Full list,
            # not capped to 4 — the cast strip itself scrolls now (see
            # Starfleet-CategoryList.xml's cast list control) instead of
            # only ever showing the first 4 with no way to see the rest.
            _show_cast = show.get('cast', [])

            def _fmt_overview(ep):
                lines = []
                if ep.get('aired'):
                    lines.append('[COLOR FFFF8C00]Air Date: [COLOR FFFFFFFF]%s[/COLOR]' % ep['aired'])
                if ep.get('rating'):
                    lines.append('[COLOR FFFF8C00]Rating: [COLOR FFFFFFFF]%s/10[/COLOR]' % ep['rating'])
                if ep.get('runtime'):
                    lines.append('[COLOR FFFF8C00]Runtime: [COLOR FFFFFFFF]%s min[/COLOR]' % ep['runtime'])
                header = '\n'.join(lines)
                body = ep.get('overview', '') or 'No description available.'
                return '%s\n\n%s' % (header, body) if header else body

            items = []
            for ep in episodes:
                is_upcoming = next_unaired is not None and ep is next_unaired
                ep_label = '%sx%02d. %s' % (season_num, ep.get('episode', 0), ep.get('title', ''))
                # Structured watched/in-progress state (dedicated checkmark/
                # percent slot in the row + meta line) instead of the old
                # text-suffix appended straight onto this fixed-width,
                # non-wrapping label — a long episode title plus " [47%]"
                # risked silently clipping the very indicator meant to be
                # visible. Not applicable to the one upcoming episode —
                # nothing to have watched/resumed yet.
                watched, pct = False, 0
                if _wh is not None and not is_upcoming:
                    try:
                        watched, _resume, pct = _wh.get_progress(_wh_key, season_num, ep.get('episode', 0))
                    except Exception:
                        pass
                items.append({
                    'tmdb_id':     tmdb_id,
                    'season_num':  season_num,
                    'episode_num': ep.get('episode', 0),
                    'title':       ep_label,
                    'year':        '',
                    'meta':        ('Releases: %s' % ep['aired'] if is_upcoming
                                     else ('Aired: %s' % ep['aired']) if ep.get('aired') else ''),
                    'not_aired':   is_upcoming,
                    'ep_air_date': ep.get('aired', '') if is_upcoming else '',
                    'thumb':       ep.get('still', '') or show_poster,
                    'fanart':      show_fanart,
                    'overview':    _fmt_overview(ep),
                    'watched':     watched,
                    'progress_pct': pct,
                })

            def _detail_fetch(ep, _cast=_show_cast):
                return {'cast': _cast}

            def _on_actor_click(name):
                win.close()
                self._open_person_films(name, 'tv')

            def _on_play(ep):
                if ep.get('not_aired'):
                    xbmcgui.Dialog().notification(
                        'Starfleet', 'Not aired yet — check back %s' % (ep.get('ep_air_date') or 'later'),
                        xbmcgui.NOTIFICATION_INFO, 4000)
                    return
                ep_title_q = quote('%s S%02dE%02d' % (
                    show_title, int(season_num), ep.get('episode_num', 0)))
                li = xbmcgui.ListItem(ep.get('title', ''))
                li.setProperty('IsPlayable', 'true')
                url = ('plugin://plugin.video.starfleet/?action=meta_ep_play'
                       '&tmdb_id=%s&season_num=%s&episode_num=%s&title=%s' % (
                           tmdb_id, season_num, ep.get('episode_num', 0), ep_title_q))
                xbmc.Player().play(url, li)

            def _context_menu(ep):
                # This episode list never had a context menu wired at all —
                # long-press here could never do anything regardless of
                # whether the long-press gesture itself works, since
                # CategoryListWindow._show_context_menu() no-ops when
                # self._context_menu is None. wh_key is passed through as
                # the exact identifier _wh_key above already resolved (real
                # imdb_id, or the tvdb_id/tmdb_id fallback for shows without
                # one) — meta_toggle_watched writes under that same key
                # instead of re-deriving its own from tmdb_id alone, so a
                # manual toggle always lands under the identical key this
                # list's own read side (_wh.get_progress(_wh_key, ...))
                # checks. Nothing to mark watched/unwatched on the one
                # not-yet-aired row.
                if ep.get('not_aired'):
                    return []
                return [
                    ('Mark as Watched / Unwatched',
                     'RunPlugin(plugin://plugin.video.starfleet/'
                     '?action=meta_toggle_watched&media_type=tv&wh_key=%s&season=%s&episode=%s&title=%s)'
                     % (quote(str(_wh_key)), season_num, ep.get('episode_num', 0),
                        quote(ep.get('title', ''))))
                ]

            win = CategoryListWindow(
                'Starfleet-CategoryList.xml',
                xbmcaddon.Addon('plugin.video.starfleet').getAddonInfo('path'),
                'Default', '1080i',
                items=items,
                breadcrumb='%s — Season %s' % (show_title, season_num),
                subheader='%d episodes' % len(items),
                media_type='tv',
                on_play=_on_play,
                detail_fetch=_detail_fetch,
                on_actor_click=_on_actor_click,
                context_menu=_context_menu,
                static_poster=show_poster,
                show_left_thumb=True,
            )
            win.doModal()
            del win
        except Exception as e:
            xbmc.log('[Starfleet/Home] _open_tv_episodes: %s' % e, xbmc.LOGERROR)
            import traceback
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

    def _open_sports_category(self):
        """Same three-panel custom skin as Movies/TV/Adult. The league icon
        (already present as c['icon'] on every category — ESPN's own
        official league-logo CDN for the majors, e.g. MLB/NBA/NHL/NFL, a
        sport-type icon for the rest) now fills the poster/backdrop panels
        instead of staying blank. Two levels: this is the sport picker;
        picking a sport opens _open_sports_events for that sport's actual
        games — WITHOUT closing this window first, so it stays open,
        nested underneath. Confirmed live as a real bug when this closed
        itself before opening events: Back from the events list had nothing
        left to return to but Home, since the sport picker was already
        gone. Uses a LOCAL window variable, not a shared self.* attribute,
        for the same reason — see _open_movies_category."""
        try:
            from resources.lib.gui.category_list import CategoryListWindow
            from resources.lib import json_data as _jd
            import os as _os

            dlg = _pdlg.DialogProgress()
            dlg.create('Starfleet', 'Loading sports...')
            try:
                cats = _jd.get_all_categories()
            finally:
                dlg.close()
            if not cats:
                xbmcgui.Dialog().notification('Starfleet', 'Could not load sports categories', xbmcgui.NOTIFICATION_ERROR)
                return

            # Same shared backdrop behind every item here — unlike Movies/TV
            # (where each item's own poster/fanart genuinely differs), every
            # sport picked its own league icon as its "backdrop" before,
            # which just looked like a blown-up version of the icon already
            # shown as the thumb. A single themed backdrop image reads as
            # this menu's own identity instead.
            addon_path = xbmcaddon.Addon('plugin.video.starfleet').getAddonInfo('path')
            _sports_backdrop = _os.path.join(addon_path, 'resources', 'skins', 'Default',
                                             'media', 'sports_backdrop.jpg')
            items = [{'title': c.get('label', c.get('slug', '')), 'slug': c.get('slug', ''),
                      'tsdb_sport': c.get('tsdb_sport', ''),
                      'thumb': c.get('icon', ''), 'fanart': _sports_backdrop} for c in cats]

            # Replay — PAST events (full fight/game replays with real
            # dates), architecturally separate from every entry above
            # (which are all live/upcoming). A synthetic pseudo-category
            # rather than one more json_data slug, since it opens a
            # different 3-deep menu (sport -> dates -> events), not the
            # live sports_events flow. Reuses UFC's own icon (a replay
            # button reads clearly against it) rather than adding a new
            # icon asset for one menu entry.
            _replay_icon = next((c.get('icon', '') for c in cats if c.get('slug') == 'ufc'), '')
            items.append({'title': '🔁 Replay (Past Events)', 'slug': '__replay__',
                          'tsdb_sport': '', 'thumb': _replay_icon, 'fanart': _sports_backdrop})

            def _on_play(cat):
                # Do NOT close this window — _open_sports_events/
                # _open_replay_menu nest on top of it, so Back from
                # whatever they open naturally lands back here instead of
                # at Home.
                if cat.get('slug') == '__replay__':
                    self._open_replay_menu()
                else:
                    self._open_sports_events(cat.get('slug', ''), cat.get('title', ''), cat.get('tsdb_sport', ''))

            win = CategoryListWindow(
                'Starfleet-CategoryList.xml',
                xbmcaddon.Addon('plugin.video.starfleet').getAddonInfo('path'),
                'Default', '1080i',
                items=items,
                breadcrumb='Sports',
                subheader='%d categories' % len(items),
                media_type='movie',
                on_play=_on_play,
            )
            win.doModal()
            del win
        except Exception as e:
            xbmc.log('[Starfleet/Home] _open_sports_category: %s' % e, xbmc.LOGERROR)
            import traceback
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

    def _open_sports_events(self, sport_slug, sport_label, tsdb_sport=''):
        """Second level — today's/upcoming events for one sport. Team badges
        (already fetched by get_sport_events) fill the icon/poster; the
        backdrop is the actual venue photo, looked up lazily per-focus
        (real network call — same lazy pattern already used for movie
        cast) via sports_sources.get_venue_image, which uses the event's
        own venue id when available (TSDB-sourced events) or looks it up
        from the home team's name otherwise (MLB/NBA/NHL's own official
        schedules only carry a bare venue name, no id) — verified live
        end-to-end before wiring this in. Clicking an event does NOT
        navigate anywhere; it plays directly through the exact same
        stream-fetch-and-pick-a-source flow every other sport listing in
        this addon already uses (sports_event_play), via the same direct
        xbmc.Player().play() mechanism already proven for TMDB movies and
        Adult — this is a play action, not a browse page, so it must not go
        through _nav()/ActivateWindow. No More Sections button here — Back
        already returns to the (still-open, nested-underneath) sport
        picker, so a button doing the same thing would be redundant. Uses a
        LOCAL window variable — see _open_movies_category."""
        try:
            from resources.lib.gui.category_list import CategoryListWindow
            from resources.lib import sports_sources as _ss
            from urllib.parse import quote

            dlg = _pdlg.DialogProgress()
            dlg.create('Starfleet', 'Loading %s events...' % sport_label)
            try:
                events = _ss.get_sport_events(sport_slug, tsdb_sport=tsdb_sport)
            finally:
                dlg.close()
            if not events:
                xbmcgui.Dialog().notification('Starfleet', 'No events found for %s' % sport_label, xbmcgui.NOTIFICATION_INFO)
                return

            # Local-time display, not the raw scraped 'datetime' string —
            # confirmed live this window was showing that field as-is, which
            # for most sources is either genuinely blank (no date parsed at
            # all) or a UTC-labeled string ('Aug 03 14:30 UTC') baked in at
            # scrape time with no conversion to the device's own timezone.
            # sports_router.py's native events page already solved this by
            # converting the numeric start_ts (present on nearly every event
            # — official league APIs, TSDB, ESPN, and most scrapers all
            # compute it even when they don't also format a display string)
            # through time.localtime(), which uses the OS/device timezone —
            # this window just never picked up that fix since it's a
            # completely separate rendering path.
            from resources.lib.sports_router import _fmt_local_time
            items = []
            for ev in events:
                badge = ev.get('home_badge') or ev.get('away_badge') or ''
                local_time = _fmt_local_time(ev.get('start_ts', 0))
                if ev.get('is_live'):
                    time_part = 'LIVE NOW'
                elif local_time:
                    time_part = local_time
                else:
                    # No source had a parseable date/time for this one —
                    # say so honestly rather than showing nothing (same
                    # "TBD" convention as the native events page).
                    time_part = 'TBD'
                items.append({
                    'title': ev.get('title', ''), 'event_id': ev.get('id', ''),
                    'event_path': ev.get('path', ''),
                    'overview': time_part + ((' • ' + ev['venue']) if ev.get('venue') else ''),
                    'thumb': badge, 'fanart': badge,
                    'venue_id': ev.get('venue_id', ''), 'home_team': ev.get('home_team', ''),
                })

            def _detail_fetch(ev, _ss=_ss):
                venue_id  = ev.get('venue_id', '')
                home_team = ev.get('home_team', '')
                if not venue_id and not home_team:
                    return {}
                venue = _ss.get_venue_image(venue_id=venue_id, team_name=home_team)
                if not venue:
                    return {}
                return {'poster': venue.get('thumb', ''), 'backdrop': venue.get('fanart', '')}

            def _on_play(ev, _slug=sport_slug):
                title_q = quote(ev.get('title', ''))
                path_q  = quote(str(ev.get('event_path', '')))
                li = xbmcgui.ListItem(ev.get('title', ''))
                li.setProperty('IsPlayable', 'true')
                url = ('plugin://plugin.video.starfleet/?action=sports_event_play'
                       '&event_id=%s&event_path=%s&sport_slug=%s&title=%s'
                       % (ev.get('event_id', ''), path_q, _slug, title_q))
                xbmc.Player().play(url, li)

            win = CategoryListWindow(
                'Starfleet-CategoryList.xml',
                xbmcaddon.Addon('plugin.video.starfleet').getAddonInfo('path'),
                'Default', '1080i',
                items=items,
                breadcrumb='Sports / %s' % sport_label,
                subheader='%d events' % len(items),
                media_type='movie',
                on_play=_on_play,
                detail_fetch=_detail_fetch,
            )
            win.doModal()
            del win
        except Exception as e:
            xbmc.log('[Starfleet/Home] _open_sports_events: %s' % e, xbmc.LOGERROR)
            import traceback
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

    # Sport keys resources/lib/replay_sources.py actually has real data
    # for (see that module's own docstring) — UFC/Boxing/MLB/NFL/NBA/NHL, in
    # this display order, each carrying its icon from the same league-icon
    # set _open_sports_category already uses so Replay's sport picker looks
    # like the same family as the live one, not a bolted-on extra.
    _REPLAY_SPORTS = ('ufc', 'boxing', 'mlb', 'nfl', 'nba', 'nhl')

    def _open_replay_menu(self):
        """Replay's first level — UFC / Boxing / MLB / NFL / NBA / NHL. Same
        three-panel skin and nested-window convention as
        _open_sports_category (local `win`, not self.*, so Back from the
        dates list two levels down naturally unwinds one level at a time
        instead of jumping to Home).
        """
        try:
            from resources.lib.gui.category_list import CategoryListWindow
            from resources.lib import json_data as _jd
            import os as _os

            cats = {c.get('slug'): c for c in _jd.get_all_categories()}
            addon_path = xbmcaddon.Addon('plugin.video.starfleet').getAddonInfo('path')
            _sports_backdrop = _os.path.join(addon_path, 'resources', 'skins', 'Default',
                                             'media', 'sports_backdrop.jpg')

            items = []
            for slug in self._REPLAY_SPORTS:
                c = cats.get(slug, {})
                items.append({'title': c.get('label', slug.upper()), 'sport': slug,
                              'thumb': c.get('icon', ''), 'fanart': _sports_backdrop})

            def _on_play(item):
                self._open_replay_dates(item.get('sport', ''), item.get('title', ''), item.get('thumb', ''))

            win = CategoryListWindow(
                'Starfleet-CategoryList.xml',
                xbmcaddon.Addon('plugin.video.starfleet').getAddonInfo('path'),
                'Default', '1080i',
                items=items,
                breadcrumb='Sports / Replay',
                subheader='%d categories' % len(items),
                media_type='movie',
                on_play=_on_play,
            )
            win.doModal()
            del win
        except Exception as e:
            xbmc.log('[Starfleet/Home] _open_replay_menu: %s' % e, xbmc.LOGERROR)
            import traceback
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

    def _open_replay_dates(self, sport, sport_label, sport_icon):
        """Replay's second level — real dates that have at least one
        event, most recent first (resources/lib/replay_sources.py's
        get_replay_dates, live-verified against all 3 sports before this
        was wired in). A date has no art of its own, so every item just
        carries the sport's own icon/backdrop for visual consistency with
        the level above rather than showing blank panels."""
        try:
            from resources.lib.gui.category_list import CategoryListWindow
            from resources.lib import replay_sources as _rs
            import os as _os

            dlg = _pdlg.DialogProgress()
            dlg.create('Starfleet', 'Loading %s replay dates...' % sport_label)
            try:
                dates = _rs.get_replay_dates(sport)
            finally:
                dlg.close()
            if not dates:
                xbmcgui.Dialog().notification('Starfleet', 'No %s replays found' % sport_label,
                                              xbmcgui.NOTIFICATION_INFO)
                return

            addon_path = xbmcaddon.Addon('plugin.video.starfleet').getAddonInfo('path')
            _sports_backdrop = _os.path.join(addon_path, 'resources', 'skins', 'Default',
                                             'media', 'sports_backdrop.jpg')
            items = [{'title': d['label'], 'date_key': d['date_key'],
                      'thumb': sport_icon, 'fanart': _sports_backdrop} for d in dates]

            def _on_play(item):
                self._open_replay_events(sport, item.get('date_key', ''), item.get('title', ''),
                                         sport_label, sport_icon)

            win = CategoryListWindow(
                'Starfleet-CategoryList.xml',
                xbmcaddon.Addon('plugin.video.starfleet').getAddonInfo('path'),
                'Default', '1080i',
                items=items,
                breadcrumb='Sports / Replay / %s' % sport_label,
                subheader='%d dates' % len(items),
                media_type='movie',
                on_play=_on_play,
            )
            win.doModal()
            del win
        except Exception as e:
            xbmc.log('[Starfleet/Home] _open_replay_dates: %s' % e, xbmc.LOGERROR)
            import traceback
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

    def _open_replay_events(self, sport, date_key, date_label, sport_label, sport_icon):
        """Replay's third level — real events on one date. Initial thumb/
        fanart is whatever the scraper already has on the event dict
        (fullfightreplays.com/mlblive.net's own real per-event thumbnail,
        or box.live's per-fighter photos for boxing entries with no card
        image — see replay_sources.py's module docstring for exactly what
        each source provides) so nothing shows blank while the real cover
        art loads; detail_fetch then lazily tries TMDB per event on focus
        (get_replay_poster, confirmed live to have real posters for UFC/
        boxing events but never MLB games) and upgrades to that when found,
        same lazy-enrichment pattern _open_sports_events already uses for
        venue photos. Clicking an event does NOT navigate — it fetches
        every real source for it (individual fight links AND full-card/
        section links together, never one or the other) and either plays
        the one result directly or shows the themed picker for multiple,
        exactly like every other multi-source play in this addon."""
        try:
            from resources.lib.gui.category_list import CategoryListWindow
            from resources.lib import replay_sources as _rs
            from urllib.parse import quote

            dlg = _pdlg.DialogProgress()
            dlg.create('Starfleet', 'Loading %s events...' % date_label)
            try:
                events = _rs.get_replay_events(sport, date_key)
            finally:
                dlg.close()
            if not events:
                xbmcgui.Dialog().notification('Starfleet', 'No events found for %s' % date_label,
                                              xbmcgui.NOTIFICATION_INFO)
                return

            items = []
            for ev in events:
                thumb = ev.get('thumb') or ev.get('fighter1_photo') or sport_icon
                fanart = ev.get('fanart') or ev.get('fighter2_photo') or ''
                items.append({
                    'title': ev.get('title', ''), 'thumb': thumb, 'fanart': fanart,
                    'overview': date_label, '_event': ev,
                })

            def _detail_fetch(item, _sport=sport):
                if _sport == 'mlb':
                    # Confirmed live (replay_sources.py's own TMDB feasibility
                    # check) — individual MLB games are never TMDB/IMDb
                    # entries, so skip the lookup entirely rather than pay a
                    # network round-trip that can only ever come back empty.
                    return {}
                poster = _rs.get_replay_poster(item.get('title', ''))
                if not poster or not poster.get('thumb'):
                    return {}
                return {'poster': poster.get('thumb', ''), 'backdrop': poster.get('fanart', '')}

            def _on_play(item, _sport=sport):
                ev = item.get('_event', {})
                title = ev.get('title', '')
                dlg2 = _pdlg.DialogProgress()
                dlg2.create('Starfleet', 'Finding sources for %s...' % title)
                try:
                    sources = _rs.get_replay_sources(_sport, ev)
                finally:
                    dlg2.close()
                if not sources:
                    xbmcgui.Dialog().notification('Starfleet', 'No playable sources found for %s' % title,
                                                  xbmcgui.NOTIFICATION_INFO)
                    return
                if len(sources) == 1:
                    chosen = sources[0]
                else:
                    labels = [s['label'] for s in sources]
                    idx = _select_dialog('%s — Choose source' % title, labels)
                    if idx < 0:
                        return
                    chosen = sources[idx]
                li = xbmcgui.ListItem(chosen['label'])
                li.setProperty('IsPlayable', 'true')
                url = ('plugin://plugin.video.starfleet/?action=replay_play'
                       '&url=%s&title=%s' % (quote(chosen['url'], safe=''), quote(title)))
                xbmc.Player().play(url, li)

            win = CategoryListWindow(
                'Starfleet-CategoryList.xml',
                xbmcaddon.Addon('plugin.video.starfleet').getAddonInfo('path'),
                'Default', '1080i',
                items=items,
                breadcrumb='Sports / Replay / %s / %s' % (sport_label, date_label),
                subheader='%d events' % len(items),
                media_type='movie',
                on_play=_on_play,
                detail_fetch=_detail_fetch,
            )
            win.doModal()
            del win
        except Exception as e:
            xbmc.log('[Starfleet/Home] _open_replay_events: %s' % e, xbmc.LOGERROR)
            import traceback
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

    # ISO 3166-1 alpha-2 -> display name, for whatever country codes actually
    # show up in json_data's live_tv_by_country dict (data-driven — the
    # picker itself never hardcodes a country list, this is just cosmetics
    # for the codes that appear; an unrecognized future code still shows,
    # just as its bare code instead of a nice name).
    _COUNTRY_NAMES = {
        'US': 'United States', 'CA': 'Canada', 'GB': 'United Kingdom',
        'IL': 'Israel', 'NZ': 'New Zealand', 'ES': 'Spain', 'SE': 'Sweden',
        'ZA': 'South Africa', 'NL': 'Netherlands', 'FR': 'France',
        'MY': 'Malaysia', 'TR': 'Turkey', 'BR': 'Brazil', 'AU': 'Australia',
        'IE': 'Ireland', 'RS': 'Serbia', 'HR': 'Croatia', 'QA': 'Qatar',
        'MX': 'Mexico', 'HU': 'Hungary', 'AO': 'Angola', 'IT': 'Italy',
        'IN': 'India', 'DE': 'Germany',
    }

    def _sinclair_country_items(self):
        """Sinclair Broadcast Group US local stations, shaped as
        ch_key-tagged items for _open_live_tv_country's lazy-play branch —
        merged into the 'US' country entry so they're reachable from
        Live TV > United States, not just buried in All Channels."""
        try:
            from resources.lib import unified_live
            from resources.lib import api as _api
            tva_channels = _api.get_live_channels()
            channels = unified_live.get_all_channels(tva_channels=tva_channels)
            return [{'title': ch.get('title', ''), 'thumb': ch.get('thumbnail', ''),
                     'ch_key': ch.get('key', '')}
                    for ch in channels
                    if any(s.get('source') == 'Sinclair' for s in ch.get('sources', []))]
        except Exception as e:
            xbmc.log('[Starfleet/Home] _sinclair_country_items: %s' % e, xbmc.LOGERROR)
            return []

    def _canada_country_items(self):
        """TVA, Global News (all regions), and Noovo — the addon-native
        'TVA+' source (api.py's DAI_LIVE_CHANNELS, merged into unified_live
        under that source label) — merged into the 'CA' country entry the
        same way _sinclair_country_items merges Sinclair into 'US'. None of
        these are part of json_data's daddylive-scraped catalogue at all,
        so without this the Canada entry only ever showed whatever few
        Canadian channels daddylive.json happens to carry, with these
        entirely missing. (TVA Sports/TVA Sports 2 were removed from
        api.py's TVA_CHANNELS entirely — TVA Sports Direct now requires a
        paid subscriber login, confirmed live, so there's no anonymous
        stream to merge in for them anymore.)"""
        try:
            from resources.lib import unified_live
            from resources.lib import api as _api
            tva_channels = _api.get_live_channels()
            channels = unified_live.get_all_channels(tva_channels=tva_channels)
            return [{'title': ch.get('title', ''), 'thumb': ch.get('thumbnail', ''),
                     'ch_key': ch.get('key', '')}
                    for ch in channels
                    if any(s.get('source') == 'TVA+' for s in ch.get('sources', []))]
        except Exception as e:
            xbmc.log('[Starfleet/Home] _canada_country_items: %s' % e, xbmc.LOGERROR)
            return []

    def _open_live_tv_menu(self):
        """Live TV's top-level choice, in-process Dialog().select() — All
        Channels / Favorites / Search, then every country actually present
        in the merged per-country catalogue (data-driven, not a hardcoded
        Canada/USA pair). Sinclair's US local stations aren't part of that
        catalogue (they're a separate, addon-native source) — merged into
        the 'US' entry's count/list here so United States means ALL US
        channels.

        The DaddyLive slice of this catalogue is now fetched live
        (live_sources.get_daddylive_channels_by_country(), name + guessed
        country only) rather than trusted from the weekly scraper's own
        daddylive_channels.json — per direct request, since the scraper's
        pre-baked playable_url per channel goes stale/dead well before
        anyone clicks play, and some channels' own resolve chains now need
        real JS execution the scraper's Playwright fallback increasingly
        can't keep up with either (see live_sources's own docstring for
        the live-vs-scraped tradeoff this replaces). timstreams.json is
        untouched — a separate, actively-maintained source unaffected by
        any of this — so this still merges json_data's own catalogue in
        alongside the live one rather than replacing it outright; a
        channel present in both just shows up twice in the rare case a
        future scraper run succeeds, cosmetic at worst."""
        try:
            from resources.lib import json_data
            from resources.lib import live_sources as _ls
            by_country = json_data.get_live_tv_channels_by_country()
            for country, chans in _ls.get_daddylive_channels_by_country().items():
                by_country.setdefault(country, []).extend(chans)
            sinclair_items = self._sinclair_country_items()
            canada_items = self._canada_country_items()
            codes = sorted(by_country.keys(),
                           key=lambda c: (-len(by_country[c]), self._COUNTRY_NAMES.get(c, c)))

            def _count(c):
                n = len(by_country[c])
                if c == 'US':
                    n += len(sinclair_items)
                elif c == 'CA':
                    n += len(canada_items)
                return n

            options = ['All Channels', 'Favorites', 'Search', '📺 TV Guide (export)'] + [
                '%s (%d)' % (self._COUNTRY_NAMES.get(c, c), _count(c)) for c in codes
            ]
            xbmc.sleep(150)  # same settling delay as Movies/TV/Adult pickers
            idx = _select_dialog('Live TV', options)
            if idx == 0:
                self._open_live_tv_category()
            elif idx == 1:
                self._open_live_tv_favorites()
            elif idx == 2:
                self._open_live_tv_search()
            elif idx == 3:
                self._export_live_tv_guide()
            elif idx >= 4:
                code = codes[idx - 4]
                if code == 'US':
                    extra = sinclair_items
                elif code == 'CA':
                    extra = canada_items
                else:
                    extra = None
                self._open_live_tv_country(code, self._COUNTRY_NAMES.get(code, code), by_country[code],
                                            extra_lazy=extra)
        except Exception as e:
            xbmc.log('[Starfleet/Home] _open_live_tv_menu: %s' % e, xbmc.LOGERROR)
            import traceback
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

    def _export_live_tv_guide(self):
        """Build the M3U + point pvr.iptvsimple at it, then hand off to
        Kodi's native TV Guide window — an explicit, on-demand action (not
        triggered automatically by browsing All Channels/a country), so
        normal in-app browsing never restarts the PVR client."""
        try:
            from resources.lib import pvr_export

            if not pvr_export.is_pvr_addon_installed():
                install_dlg = _pdlg.DialogProgress()
                install_dlg.create('Starfleet', 'Installing IPTV Simple Client...')
                try:
                    installed = pvr_export.install_pvr_addon()
                finally:
                    install_dlg.close()
                if not installed:
                    xbmcgui.Dialog().ok(
                        'TV Guide',
                        'Couldn\'t install IPTV Simple Client automatically — '
                        'install it yourself from Add-ons > PVR clients > '
                        'IPTV Simple Client, then try TV Guide again.')
                    return

            dlg = _pdlg.DialogProgress()
            dlg.create('Starfleet', 'Building channel list...')
            try:
                count, epg_count, ok = pvr_export.export_and_configure()
            finally:
                dlg.close()

            if not ok:
                xbmcgui.Dialog().notification('TV Guide', 'Export failed — see log',
                                              xbmcgui.NOTIFICATION_ERROR, 4000)
                return

            xbmcgui.Dialog().notification(
                'TV Guide',
                '%d channels exported, %d EPG sources — loading guide...' % (count, epg_count),
                xbmcgui.NOTIFICATION_INFO, 4000)
            # Give pvr.iptvsimple a moment to finish reloading before jumping
            # to the guide window.
            xbmc.sleep(2000)
            xbmc.executebuiltin('ActivateWindow(TVGuide)')
        except Exception as e:
            xbmc.log('[Starfleet/Home] _export_live_tv_guide: %s' % e, xbmc.LOGERROR)
            import traceback
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

    def _open_live_tv_category(self):
        """Same three-panel custom skin, plot/poster/cast blank for now —
        All Channels (Unified) as the one flat list, matching the native
        Live TV menu's own primary entry. Every other native destination
        (GEOlocked Canada, Samsung TV+, Plex FAST, Pluto TV Canada, ICI
        Noovo, Free Worldwide News, per-country browsing, M3U export,
        Refresh All) stays reachable via More Sections rather than adapting
        each one into this skin in the same pass."""
        try:
            from resources.lib.gui.category_list import CategoryListWindow
            from resources.lib import unified_live
            from resources.lib import api as _api

            dlg = _pdlg.DialogProgress()
            dlg.create('Starfleet', 'Loading channels...')
            try:
                tva_channels = _api.get_live_channels()
                channels = unified_live.get_all_channels(tva_channels=tva_channels)
            finally:
                dlg.close()
            if not channels:
                xbmcgui.Dialog().notification('Starfleet', 'Could not load channels', xbmcgui.NOTIFICATION_ERROR)
                return

            items = [{'title': ch.get('title', ''), 'ch_key': ch.get('key', ''),
                      'thumb': ch.get('thumbnail', '')} for ch in channels]

            def _on_play(ch):
                from urllib.parse import quote
                li = xbmcgui.ListItem(ch.get('title', ''))
                li.setProperty('IsPlayable', 'true')
                url = ('plugin://plugin.video.starfleet/?action=live_unified_play'
                       '&ch_key=%s&ch_title=%s' % (quote(ch.get('ch_key', '')), quote(ch.get('title', ''))))
                xbmc.Player().play(url, li)

            def _on_more():
                # A native ActivateWindow transition, not another nested
                # CategoryListWindow — safe to close first here, same as
                # Movies/TV's _on_actor_click.
                win.close()
                self._nav('live_menu')

            def _context_menu(ch):
                from urllib.parse import quote
                ch_key = str(ch.get('ch_key', ''))
                title  = ch.get('title', '')
                thumb  = ch.get('thumb', '')
                try:
                    from resources.lib import live_favorites as _lfav
                    is_fav = _lfav.is_favorite(ch_key)
                except Exception:
                    is_fav = False
                if is_fav:
                    label_, action_ = 'Remove from Live TV Favorites', 'live_favorites_remove'
                else:
                    label_, action_ = 'Add to Live TV Favorites', 'live_favorites_add'
                return [(label_, 'RunPlugin(plugin://plugin.video.starfleet/'
                         '?action=%s&ch_key=%s&title=%s&thumb=%s)'
                         % (action_, quote(ch_key), quote(title), quote(thumb)))]

            win = CategoryListWindow(
                'Starfleet-CategoryList.xml',
                xbmcaddon.Addon('plugin.video.starfleet').getAddonInfo('path'),
                'Default', '1080i',
                items=items,
                breadcrumb='Live TV',
                subheader='%d channels  ·  All Channels' % len(items),
                media_type='movie',
                on_play=_on_play,
                on_more=_on_more,
                context_menu=_context_menu,
            )
            win.doModal()
            del win
        except Exception as e:
            xbmc.log('[Starfleet/Home] _open_live_tv_category: %s' % e, xbmc.LOGERROR)
            import traceback
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

    def _open_live_tv_country(self, country_code, display_name, channels, extra_lazy=None):
        """One country's channels from json_data's pre-resolved catalogue —
        each entry already carries a direct playable_url (no ch_key/
        live_unified_play lookup needed, unlike the Samsung/Plex/Pluto/
        Sinclair sources in _open_live_tv_category). extra_lazy adds items
        from that OTHER, addon-native side instead (currently just
        Sinclair, merged into 'US' by _open_live_tv_menu) — those carry a
        ch_key and need the live_unified_play lookup/dispatch, same as
        _open_live_tv_favorites' own direct_url-vs-ch_key branch below."""
        try:
            from resources.lib.gui.category_list import CategoryListWindow

            items = [{'title': ch.get('title', ''), 'thumb': ch.get('logo', ''),
                      'direct_url': ch.get('playable_url', '')} for ch in channels]
            if extra_lazy:
                items += [{'title': ch.get('title', ''), 'thumb': ch.get('thumb', ''),
                           'ch_key': ch.get('ch_key', '')} for ch in extra_lazy if ch.get('ch_key')]
            if not items:
                xbmcgui.Dialog().notification('Starfleet', 'No channels for %s' % display_name,
                                              xbmcgui.NOTIFICATION_INFO)
                return

            def _on_play(ch):
                from urllib.parse import quote
                url = ch.get('direct_url', '')
                li = xbmcgui.ListItem(ch.get('title', ''))
                li.setProperty('IsPlayable', 'true')
                if url:
                    # Routed through the play_direct action (not a bare
                    # Player().play(url)) so the |Referer=... headers these
                    # URLs carry get extracted properly by router.py's
                    # _hls_item() — same path play_direct-sourced unified_live
                    # channels already use, just reused here directly.
                    play_url = ('plugin://plugin.video.starfleet/?action=play_direct'
                               '&stream_url=%s&title=%s' % (quote(url, safe=''), quote(ch.get('title', ''))))
                elif ch.get('ch_key'):
                    play_url = ('plugin://plugin.video.starfleet/?action=live_unified_play'
                               '&ch_key=%s&ch_title=%s' % (quote(ch['ch_key'], safe=''), quote(ch.get('title', ''))))
                else:
                    # No baked url and no ch_key — a live_sources.
                    # get_daddylive_channels_by_country() entry (name +
                    # country only, no scraper involved). Fresh-resolves
                    # by title-matching against the dlive.sx 24/7 directory
                    # this addon already scrapes and resolves correctly —
                    # see router.play_daddylive_catalog's own docstring.
                    play_url = ('plugin://plugin.video.starfleet/?action=play_daddylive_catalog'
                               '&title=%s' % quote(ch.get('title', '')))
                xbmc.Player().play(play_url, li)

            def _context_menu(ch):
                from urllib.parse import quote
                title = ch.get('title', '')
                thumb = ch.get('thumb', '')
                url   = ch.get('direct_url', '')
                if ch.get('ch_key'):
                    ch_key = ch['ch_key']
                elif url:
                    ch_key = 'jsontv_%s_%s' % (country_code, abs(hash(title)))
                else:
                    # live_sources.get_daddylive_channels_by_country() entry
                    # — no baked url to favorite by, see this screen's own
                    # _on_play; 'dltv_' prefix tells _open_live_tv_favorites
                    # to fresh-resolve by title instead of live_unified_play.
                    ch_key = 'dltv_%s_%s' % (country_code, abs(hash(title)))
                try:
                    from resources.lib import live_favorites as _lfav
                    is_fav = _lfav.is_favorite(ch_key)
                except Exception:
                    is_fav = False
                if is_fav:
                    label_, action_ = 'Remove from Live TV Favorites', 'live_favorites_remove'
                else:
                    label_, action_ = 'Add to Live TV Favorites', 'live_favorites_add'
                return [(label_, 'RunPlugin(plugin://plugin.video.starfleet/'
                         '?action=%s&ch_key=%s&title=%s&thumb=%s&direct_url=%s)'
                         % (action_, quote(str(ch_key)), quote(title), quote(thumb), quote(url)))]

            win = CategoryListWindow(
                'Starfleet-CategoryList.xml',
                xbmcaddon.Addon('plugin.video.starfleet').getAddonInfo('path'),
                'Default', '1080i',
                items=items,
                breadcrumb='Live TV',
                subheader='%d channels  ·  %s' % (len(items), display_name),
                media_type='movie',
                on_play=_on_play,
                context_menu=_context_menu,
            )
            win.doModal()
            del win
        except Exception as e:
            xbmc.log('[Starfleet/Home] _open_live_tv_country: %s' % e, xbmc.LOGERROR)
            import traceback
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

    def _open_live_tv_favorites(self):
        """Browse saved Live TV favorites — each entry plays back via
        live_unified_play (ch_key, older Samsung/Plex/Pluto/Sinclair-sourced
        favorites), directly (direct_url, json_data country-channel
        favorites), or by fresh title-resolve (a 'dltv_' synthesized key —
        live_sources.get_daddylive_channels_by_country() entries have
        neither a real ch_key nor a baked url to favorite by, see
        _open_live_tv_country/_open_live_tv_search's own context menus),
        matching whichever mode it was saved under."""
        try:
            from resources.lib.gui.category_list import CategoryListWindow
            from resources.lib import live_favorites as _lfav

            favs = _lfav.get_all()
            if not favs:
                xbmcgui.Dialog().notification('Starfleet', 'No Live TV favorites yet — long-press a channel to add one',
                                              xbmcgui.NOTIFICATION_INFO, 3000)
                return

            items = [{'title': f.get('title', ''), 'thumb': f.get('thumb', ''),
                      'ch_key': f.get('ch_key', ''), 'direct_url': f.get('direct_url', '')}
                     for f in favs]

            def _on_play(ch):
                from urllib.parse import quote
                li = xbmcgui.ListItem(ch.get('title', ''))
                li.setProperty('IsPlayable', 'true')
                if ch.get('direct_url'):
                    # play_direct extracts the |Referer=... headers these
                    # URLs carry — same reasoning as _open_live_tv_country.
                    play_url = ('plugin://plugin.video.starfleet/?action=play_direct'
                               '&stream_url=%s&title=%s' % (quote(ch['direct_url'], safe=''), quote(ch.get('title', ''))))
                elif str(ch.get('ch_key', '')).startswith('dltv_'):
                    play_url = ('plugin://plugin.video.starfleet/?action=play_daddylive_catalog'
                               '&title=%s' % quote(ch.get('title', '')))
                else:
                    play_url = ('plugin://plugin.video.starfleet/?action=live_unified_play'
                           '&ch_key=%s&ch_title=%s' % (quote(ch.get('ch_key', '')), quote(ch.get('title', ''))))
                xbmc.Player().play(play_url, li)

            def _context_menu(ch):
                from urllib.parse import quote
                return [('Remove from Live TV Favorites',
                         'RunPlugin(plugin://plugin.video.starfleet/'
                         '?action=live_favorites_remove&ch_key=%s&title=%s)'
                         % (quote(str(ch.get('ch_key', ''))), quote(ch.get('title', ''))))]

            win = CategoryListWindow(
                'Starfleet-CategoryList.xml',
                xbmcaddon.Addon('plugin.video.starfleet').getAddonInfo('path'),
                'Default', '1080i',
                items=items,
                breadcrumb='Live TV',
                subheader='%d channels  ·  Favorites' % len(items),
                media_type='movie',
                on_play=_on_play,
                context_menu=_context_menu,
            )
            win.doModal()
            del win
        except Exception as e:
            xbmc.log('[Starfleet/Home] _open_live_tv_favorites: %s' % e, xbmc.LOGERROR)
            import traceback
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

    def _open_live_tv_search(self):
        """Type-to-search across every channel this addon knows about —
        both the unified_live sources (Samsung/Plex/Pluto/Sinclair/TVA/etc)
        and every country in json_data's catalogue — matched by a plain
        case-insensitive substring on title (e.g. typing 'tva' jumps
        straight to TVA's channels without knowing which country menu
        they're filed under)."""
        try:
            # See _open_movies_search for why this uses Kodi's native
            # keyboard directly instead of the custom on-screen rebuild.
            kb = xbmc.Keyboard('', 'Search Live TV channels')
            kb.doModal()
            if not kb.isConfirmed() or not kb.getText().strip():
                return
            query = kb.getText().strip()
            q = query.lower()

            from resources.lib.gui.category_list import CategoryListWindow
            from resources.lib import unified_live
            from resources.lib import api as _api
            from resources.lib import json_data
            from resources.lib import live_sources as _ls

            dlg = _pdlg.DialogProgress()
            dlg.create('Starfleet', 'Searching channels...')
            try:
                tva_channels = _api.get_live_channels()
                unified_channels = unified_live.get_all_channels(tva_channels=tva_channels)
                by_country = json_data.get_live_tv_channels_by_country()
                for country, chans in _ls.get_daddylive_channels_by_country().items():
                    by_country.setdefault(country, []).extend(chans)
            finally:
                dlg.close()

            items = []
            for ch in unified_channels:
                if q in ch.get('title', '').lower():
                    items.append({'title': ch.get('title', ''), 'ch_key': ch.get('key', ''),
                                  'thumb': ch.get('thumbnail', '')})
            for code, chans in by_country.items():
                for ch in chans:
                    if q in ch.get('title', '').lower():
                        items.append({'title': ch.get('title', ''), 'thumb': ch.get('logo', ''),
                                      'direct_url': ch.get('playable_url', ''),
                                      '_country': code})

            if not items:
                xbmcgui.Dialog().notification('Starfleet', 'No channels matching "%s"' % query,
                                              xbmcgui.NOTIFICATION_INFO)
                return

            def _on_play(ch):
                from urllib.parse import quote
                li = xbmcgui.ListItem(ch.get('title', ''))
                li.setProperty('IsPlayable', 'true')
                if ch.get('direct_url'):
                    play_url = ('plugin://plugin.video.starfleet/?action=play_direct'
                               '&stream_url=%s&title=%s' % (quote(ch['direct_url'], safe=''), quote(ch.get('title', ''))))
                elif ch.get('ch_key'):
                    play_url = ('plugin://plugin.video.starfleet/?action=live_unified_play'
                           '&ch_key=%s&ch_title=%s' % (quote(ch.get('ch_key', '')), quote(ch.get('title', ''))))
                else:
                    # No baked url and no ch_key — a live_sources.
                    # get_daddylive_channels_by_country() entry, same
                    # fresh-resolve-by-title fallback as _open_live_tv_country.
                    play_url = ('plugin://plugin.video.starfleet/?action=play_daddylive_catalog'
                               '&title=%s' % quote(ch.get('title', '')))
                xbmc.Player().play(play_url, li)

            def _context_menu(ch):
                from urllib.parse import quote
                title = ch.get('title', '')
                thumb = ch.get('thumb', '')
                if ch.get('direct_url'):
                    ch_key = 'jsontv_%s_%s' % (ch.get('_country', 'xx'), abs(hash(title)))
                    extra  = '&direct_url=%s' % quote(ch['direct_url'])
                elif ch.get('ch_key'):
                    ch_key = str(ch['ch_key'])
                    extra  = ''
                else:
                    ch_key = 'dltv_%s_%s' % (ch.get('_country', 'xx'), abs(hash(title)))
                    extra  = ''
                try:
                    from resources.lib import live_favorites as _lfav
                    is_fav = _lfav.is_favorite(ch_key)
                except Exception:
                    is_fav = False
                if is_fav:
                    label_, action_ = 'Remove from Live TV Favorites', 'live_favorites_remove'
                else:
                    label_, action_ = 'Add to Live TV Favorites', 'live_favorites_add'
                return [(label_, 'RunPlugin(plugin://plugin.video.starfleet/'
                         '?action=%s&ch_key=%s&title=%s&thumb=%s%s)'
                         % (action_, ch_key, quote(title), quote(thumb), extra))]

            win = CategoryListWindow(
                'Starfleet-CategoryList.xml',
                xbmcaddon.Addon('plugin.video.starfleet').getAddonInfo('path'),
                'Default', '1080i',
                items=items,
                breadcrumb='Live TV',
                subheader='%d results  ·  Search: %s' % (len(items), query),
                media_type='movie',
                on_play=_on_play,
                context_menu=_context_menu,
            )
            win.doModal()
            del win
        except Exception as e:
            xbmc.log('[Starfleet/Home] _open_live_tv_search: %s' % e, xbmc.LOGERROR)
            import traceback
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

    def _open_radio_menu(self):
        """Radio's top-level choice — quick-access country shortcuts (the
        same SHORTCUTS list radio_router.py's own native menu already used)
        plus All Countries / Search, matching _open_live_tv_menu's shape.
        Radio's own backend (radio.py / radio_router.py) was never touched
        by any of the custom-skin migration work — it just never got a nav
        button once Home's custom skin replaced the native main_menu()
        listing entirely, so it silently became unreachable even though
        every bit of it still works."""
        try:
            from resources.lib.radio_router import SHORTCUTS
            from resources.lib.radio import flag as _flag

            options = ['🌍  All Countries (160+)', '🔍  Search Stations'] + [
                '%s  %s' % (_flag(iso), short) for iso, _full, short in SHORTCUTS
            ]
            xbmc.sleep(150)  # same settling delay as Movies/TV/Adult/Live TV pickers
            idx = _select_dialog('Radio', options)
            if idx == 0:
                self._open_radio_countries()
            elif idx == 1:
                self._open_radio_search()
            elif idx >= 2:
                iso, full, short = SHORTCUTS[idx - 2]
                self._open_radio_states(full, short)
        except Exception as e:
            xbmc.log('[Starfleet/Home] _open_radio_menu: %s' % e, xbmc.LOGERROR)
            import traceback
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

    def _open_radio_countries(self):
        """All 160+ countries with station counts — three-panel custom
        skin list, same treatment as Movies/TV genre lists and Sports
        categories."""
        try:
            from resources.lib.gui.category_list import CategoryListWindow
            from resources.lib import radio as rb
            from resources.lib.radio import flag as _flag

            dlg = _pdlg.DialogProgress()
            dlg.create('Radio', 'Loading countries...')
            try:
                countries = rb.get_countries()
            finally:
                dlg.close()

            if not countries:
                xbmcgui.Dialog().notification('Starfleet', 'Could not load countries',
                                              xbmcgui.NOTIFICATION_ERROR)
                return

            items = [{'title': '%s  %s  (%d)' % (_flag(c['iso']), c['name'], c['count']),
                      'year': '', 'thumb': '', 'fanart': '', 'overview': '',
                      'country': c['name']} for c in countries]

            def _on_play(c):
                self._open_radio_states(c.get('country', ''))

            def _on_more():
                win.close()
                self._open_radio_menu()

            win = CategoryListWindow(
                'Starfleet-CategoryList.xml',
                xbmcaddon.Addon('plugin.video.starfleet').getAddonInfo('path'),
                'Default', '1080i',
                items=items,
                breadcrumb='Radio — Countries',
                subheader='%d countries' % len(items),
                media_type='movie',
                on_play=_on_play,
                on_more=_on_more,
            )
            win.doModal()
            del win
        except Exception as e:
            xbmc.log('[Starfleet/Home] _open_radio_countries: %s' % e, xbmc.LOGERROR)
            import traceback
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

    def _open_radio_states(self, country, display_name=None):
        """States/provinces/regions for one country — falls straight
        through to that country's own top station list if Radio Browser
        has no state breakdown for it (matches radio_router.py's own
        radio_states() fallback exactly)."""
        try:
            from resources.lib.gui.category_list import CategoryListWindow
            from resources.lib import radio as rb
            from resources.lib.radio_router import _state_label

            display_name = display_name or country

            dlg = _pdlg.DialogProgress()
            dlg.create('Radio', 'Loading %s...' % display_name)
            try:
                states = rb.get_states(country)
            finally:
                dlg.close()

            if not states:
                self._open_radio_stations_for(
                    lambda: rb.get_stations_by_country(country),
                    'Radio — %s' % display_name)
                return

            region_label = _state_label(country)
            items = [{'title': '%s  (%d)' % (s['name'], s['count']),
                      'year': '', 'thumb': '', 'fanart': '', 'overview': '',
                      'state': s['name']} for s in states]

            def _on_play(s):
                self._open_radio_cities(country, s.get('state', ''), display_name)

            def _on_more():
                win.close()
                self._open_radio_menu()

            win = CategoryListWindow(
                'Starfleet-CategoryList.xml',
                xbmcaddon.Addon('plugin.video.starfleet').getAddonInfo('path'),
                'Default', '1080i',
                items=items,
                breadcrumb='Radio — %s' % display_name,
                subheader='%d %s' % (len(items), region_label.lower()),
                media_type='movie',
                on_play=_on_play,
                on_more=_on_more,
            )
            win.doModal()
            del win
        except Exception as e:
            xbmc.log('[Starfleet/Home] _open_radio_states: %s' % e, xbmc.LOGERROR)
            import traceback
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

    def _open_radio_cities(self, country, state, country_display=None):
        """Cities within one state/province — falls through to the
        state-level station list if there's no city breakdown, or
        straight to that single city's stations if there's only one
        (matches radio_router.py's own radio_cities() fallback exactly)."""
        try:
            from resources.lib.gui.category_list import CategoryListWindow
            from resources.lib import radio as rb

            country_display = country_display or country

            dlg = _pdlg.DialogProgress()
            dlg.create('Radio', 'Loading %s...' % state)
            try:
                cities = rb.get_cities(country, state)
            finally:
                dlg.close()

            if not cities:
                self._open_radio_stations_for(
                    lambda: rb._fetch_stations_by_state(country, state),
                    'Radio — %s' % state)
                return

            if len(cities) == 1:
                only_city = cities[0]['name']
                self._open_radio_stations_for(
                    lambda: rb.get_stations_by_city(country, state, only_city),
                    'Radio — %s' % only_city)
                return

            items = [{'title': '%s  (%d)' % (c['name'], c['count']),
                      'year': '', 'thumb': '', 'fanart': '', 'overview': '',
                      'city': c['name']} for c in cities]

            def _on_play(c):
                city_name = c.get('city', '')
                self._open_radio_stations_for(
                    lambda: rb.get_stations_by_city(country, state, city_name),
                    'Radio — %s' % city_name)

            def _on_more():
                win.close()
                self._open_radio_states(country, country_display)

            win = CategoryListWindow(
                'Starfleet-CategoryList.xml',
                xbmcaddon.Addon('plugin.video.starfleet').getAddonInfo('path'),
                'Default', '1080i',
                items=items,
                breadcrumb='Radio — %s' % state,
                subheader='%d cities' % len(items),
                media_type='movie',
                on_play=_on_play,
                on_more=_on_more,
            )
            win.doModal()
            del win
        except Exception as e:
            xbmc.log('[Starfleet/Home] _open_radio_cities: %s' % e, xbmc.LOGERROR)
            import traceback
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

    def _open_radio_stations_for(self, fetch_fn, breadcrumb):
        """Final playable station list — fetch_fn is called lazily under a
        progress dialog (so callers can pass a plain lambda without hitting
        the network before this actually needs it). Playback is routed
        through the existing radio_play plugin action instead of
        reimplementing stream resolution here — same reuse-the-router's-
        own-resolve-logic approach _open_live_tv_country uses for its
        ch_key branch (fresh URL resolution via Radio Browser, HLS
        inputstream handling — all of that stays in radio_router.py)."""
        try:
            from resources.lib.gui.category_list import CategoryListWindow

            dlg = _pdlg.DialogProgress()
            dlg.create('Radio', 'Loading stations...')
            try:
                stations = fetch_fn()
            finally:
                dlg.close()

            if not stations:
                xbmcgui.Dialog().notification('Starfleet', 'No stations found',
                                              xbmcgui.NOTIFICATION_INFO)
                return
            stations = sorted(stations, key=lambda s: (s.get('name') or '').lower())

            def _label(s):
                codec   = s.get('codec', '')
                bitrate = s.get('bitrate', 0)
                if codec and bitrate:
                    return '%s  [%s %dk]' % (s['name'], codec, bitrate)
                elif codec:
                    return '%s  [%s]' % (s['name'], codec)
                return s['name']

            items = [{'title': _label(s), 'year': '', 'thumb': s.get('thumbnail', ''),
                      'fanart': '', 'overview': (s.get('genre') or '').replace(',', ' · ')[:80],
                      'uuid': s.get('uuid', ''), 'url': s.get('url', ''),
                      'name': s.get('name', '')} for s in stations]

            def _on_play(s):
                from urllib.parse import quote
                li = xbmcgui.ListItem(s.get('name', ''))
                li.setProperty('IsPlayable', 'true')
                play_url = ('plugin://plugin.video.starfleet/?action=radio_play'
                           '&station_uuid=%s&stream_url=%s&title=%s'
                           % (quote(s.get('uuid', '')), quote(s.get('url', ''), safe=''),
                              quote(s.get('name', ''))))
                xbmc.Player().play(play_url, li)

            win = CategoryListWindow(
                'Starfleet-CategoryList.xml',
                xbmcaddon.Addon('plugin.video.starfleet').getAddonInfo('path'),
                'Default', '1080i',
                items=items,
                breadcrumb=breadcrumb,
                subheader='%d stations' % len(items),
                media_type='movie',
                on_play=_on_play,
            )
            win.doModal()
            del win
        except Exception as e:
            xbmc.log('[Starfleet/Home] _open_radio_stations_for: %s' % e, xbmc.LOGERROR)
            import traceback
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

    def _open_radio_search(self):
        """Native keyboard (see _open_movies_search's own note on why not
        the themed on-screen one) → search_stations() → three-panel
        results list."""
        try:
            kb = xbmc.Keyboard('', 'Search Radio Stations')
            kb.doModal()
            if not kb.isConfirmed() or not kb.getText().strip():
                return
            query = kb.getText().strip()

            from resources.lib import radio as rb
            self._open_radio_stations_for(
                lambda: rb.search_stations(query, limit=100),
                'Radio — "%s"' % query)
        except Exception as e:
            xbmc.log('[Starfleet/Home] _open_radio_search: %s' % e, xbmc.LOGERROR)
            import traceback
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

    def _open_adult_menu(self):
        """Adult's top-level choice (Movies/Scenes/Channels/Search) shown as
        a simple in-process select dialog — NOT the native adult_menu
        directory page. Unlike Movies, where New/Popular/Top Rated/Upcoming
        are just sort variants of the same underlying thing (safe to
        collapse into one default list), Adult's four top choices are
        genuinely different destinations, so jumping straight into New
        Releases (as originally shipped) skipped real, distinct
        functionality rather than just a sort preference. Dialog().select()
        is a safe in-process modal — same category as the PIN-entry dialog
        already used safely elsewhere in this window — so this doesn't
        reintroduce any ActivateWindow/doModal risk; only 'Movies' goes on
        to open the custom in-process category list, the other three route
        to their existing native destinations exactly as adult_menu always
        has."""
        try:
            options = ['Movies', 'Scenes', 'Channels', 'Requests', 'Search', 'JAV']
            # Only naturally safe today because the PIN-entry dialog (when
            # enabled) absorbs the triggering keypress first — see
            # _open_movies_menu's note. Sleeping here too so this doesn't
            # break if the user ever disables the Adult PIN.
            xbmc.sleep(150)
            idx = _select_dialog('Adult', options)
            if idx == 0:
                self._open_adult_movies_menu()
            elif idx == 1:
                self._open_adult_scenes_select()
            elif idx == 2:
                self._open_adult_tvnow_channels()
            elif idx == 3:
                self._open_adult_requests()
            elif idx == 4:
                self._open_adult_search()
            elif idx == 5:
                self._open_jav_menu()
        except Exception as e:
            xbmc.log('[Starfleet/Home] _open_adult_menu: %s' % e, xbmc.LOGERROR)

    def _open_adult_requests(self):
        """"Requests" — resources/lib/request_sources.py's hand-curated
        adult title list. This custom in-process Adult menu never falls
        through to afdb_router.py's plain xbmcplugin adult_requests_list()
        (confirmed live: every other option here — Movies/Scenes/Channels
        — already has its own in-process equivalent, same reason this one
        needs its own rather than reusing that dead-for-this-path
        function). Cover art via ade._cover_url(adc_id) (pure CDN-URL
        template, no network round trip) is shown immediately for every
        item; full description/cast/trailer come from
        request_sources.enrich_adult_metadata() lazily on focus via
        detail_fetch — same background-thread pattern Movies/Favorites
        already use for cast photos, since it needs a real ADE search+
        detail round trip (validated against our own known adc_id first,
        so a title-search miss never attaches the wrong film's data —
        see enrich_adult_metadata()'s own docstring)."""
        try:
            from resources.lib.gui.category_list import CategoryListWindow
            from resources.lib import request_sources as _reqsrc
            from resources.lib import ade as _ade
            from urllib.parse import quote

            requests_list = _reqsrc.get_requested_adult()
            if not requests_list:
                xbmcgui.Dialog().notification('Starfleet', 'No requested adult titles yet',
                                              xbmcgui.NOTIFICATION_INFO)
                return

            items = []
            for r in requests_list:
                adc_id = r.get('adc_id', r.get('ade_id', ''))
                cover = _ade._cover_url(adc_id) if adc_id else ''
                items.append({
                    'title':        r.get('title', ''),
                    'year':         '',
                    'thumb':        cover,
                    'fanart':       _ade._cover_url(adc_id, 'bh') if adc_id else '',
                    'overview':     '',
                    'adc_id':       adc_id,
                    'request_urls': _reqsrc.entry_urls(r),
                })

            def _detail_fetch(item):
                meta = _reqsrc.enrich_adult_metadata(item.get('title', ''), item.get('adc_id', ''))
                if not meta:
                    return {}
                cast = _ade.get_cast_with_photos(meta.get('cast', []), limit=4) if meta.get('cast') else []
                out = {'overview': meta.get('description', ''), 'cast': cast}
                # The eager _cover_url(adc_id) formula 404s/415s for some
                # real films (confirmed live) - the real detail page's own
                # og:image (already fetched above for description/cast)
                # is a more reliable cover, so override the poster/backdrop
                # once it's actually in hand, same lazy-override mechanism
                # CategoryListWindow already uses for Sports' venue photos.
                if meta.get('thumb'):
                    out['poster'] = meta['thumb']
                if meta.get('fanart'):
                    out['backdrop'] = meta['fanart']
                return out

            def _on_play(item):
                urls = list(item.get('request_urls') or [])
                meta = _reqsrc.enrich_adult_metadata(item.get('title', ''), item.get('adc_id', ''))
                trailer = meta.get('trailer', '') if meta else ''
                labels = ['Source %d' % (i + 1) for i in range(len(urls))]
                if trailer:
                    labels.append('Play Trailer')
                if not labels:
                    return
                if len(labels) > 1:
                    idx = _select_dialog('%s — Choose source' % item.get('title', ''), labels)
                    if idx < 0:
                        return
                else:
                    idx = 0
                chosen = trailer if (trailer and idx == len(urls)) else urls[idx]
                li = xbmcgui.ListItem(item.get('title', ''))
                li.setProperty('IsPlayable', 'true')
                url = ('plugin://plugin.video.starfleet/?action=request_play'
                       '&url=%s&title=%s' % (quote(chosen, safe=''),
                                              quote(item.get('title', ''))))
                xbmc.Player().play(url, li)

            win = CategoryListWindow(
                'Starfleet-CategoryList.xml',
                xbmcaddon.Addon('plugin.video.starfleet').getAddonInfo('path'),
                'Default', '1080i',
                items=items,
                breadcrumb='Adult — Requests',
                subheader='%d titles' % len(items),
                media_type='movie',
                on_play=_on_play,
                detail_fetch=_detail_fetch,
            )
            win.doModal()
            del win
        except Exception as e:
            xbmc.log('[Starfleet/Home] _open_adult_requests: %s' % e, xbmc.LOGERROR)
            import traceback
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

    def _open_adult_search(self):
        """Custom-skin equivalent of the native adult_search_unified page —
        reported live as a real bug: it was the one remaining Adult screen
        that still dropped out of our own three-panel skin into a plain
        native Kodi listing (system-skin styled, not ours) instead of
        staying in-process like every other Adult category already does.
        Reuses afdb_router._adult_unified_search_data(query) — the exact
        same category/actor/title/torrent/stream search+merge logic the
        native page already had, just returning plain data now instead of
        rendering xbmcgui.ListItems directly, so nothing about what a
        search actually finds changes, only where it's displayed.

        Just the one-time keyboard prompt — actual fetch/render/pagination
        lives in _open_adult_search_page (page 1, empty accumulator), which
        that page's own on_more re-invokes itself for page 2, 3, ... the
        same recursive-self-call pattern _open_adult_scene_movies already
        uses for its own Next Page."""
        try:
            kb = xbmc.Keyboard('', 'Search movies, performers, scenes...')
            kb.doModal()
            if not kb.isConfirmed() or not kb.getText().strip():
                return
            query = kb.getText().strip()
            self._open_adult_search_page(query, 1, [])
        except Exception as e:
            xbmc.log('[Starfleet/Home] _open_adult_search: %s' % e, xbmc.LOGERROR)
            import traceback
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

    def _open_adult_search_page(self, query, page, items):
        """Page N of the unified Adult search screen. `items` carries every
        result already accumulated from earlier pages — page 1's films +
        torrents + Rintor + first stream batch, plus each subsequent page's
        stream batch on top. Unlike _open_adult_scene_movies' own on_more
        (which reopens with a wholly fresh page of the SAME kind of
        content, since a single-site Latest listing is homogeneous), only
        stream_results is genuinely paginated here (see
        afdb_router._adult_unified_search_data's own docstring for exactly
        which of its ~26 underlying sites got real, live-confirmed search
        pagination) — afdb/actor/torrent results are one-shot page-1 data,
        so replacing `items` outright on every More click would silently
        drop them instead of the list actually growing.

        Raw XXXClub/Rintor torrent hits and free-stream results aren't
        "browsable films" with their own id/slug the way ADE/AFDB results
        are — each is already one specific playable candidate — so they're
        added as their own pseudo-items carrying a '_play_url' the shared
        _on_play below plays directly via adult_stream_play(), instead of
        routing through adult_ade_play_direct's own fresh title search
        (which would just search all over again for something already
        found)."""
        try:
            from resources.lib.gui.category_list import CategoryListWindow
            from resources.lib.afdb_router import _adult_unified_search_data
            import html as _html_lib

            dlg = _pdlg.DialogProgress()
            dlg.create('Starfleet', 'Searching "%s"...' % query)
            try:
                films, torrent_results, rintor_results, stream_results = _adult_unified_search_data(query, page)
            finally:
                dlg.close()

            new_items = []
            if page <= 1:
                # afdb/actor/torrent results are page-1-only data (see this
                # method's own docstring) — only fetched/shown once, never
                # re-added on a later More click.
                for f in films:
                    f = dict(f)
                    f['title']    = _html_lib.unescape(f.get('title', ''))
                    f['overview'] = _html_lib.unescape(f.get('description', f.get('overview', '')))
                    new_items.append(f)
                for t in torrent_results:
                    src = t.get('source', 'Torrent')
                    new_items.append({
                        'id': '', 'slug': '', 'source': src.lower(), 'title': t.get('title', ''),
                        'thumb': '', 'fanart': '',
                        'overview': '[%s torrent] %s  ·  seeds %d' % (src, t.get('size', ''), t.get('seeds', 0)),
                        '_play_url': t.get('magnet', ''),
                    })
                for t in rintor_results:
                    new_items.append({
                        'id': '', 'slug': '', 'source': 'rintor', 'title': t.get('title', ''),
                        'thumb': '', 'fanart': '',
                        'overview': '[Rintor torrent] %s' % t.get('size', ''),
                        '_play_url': t.get('magnet', ''),
                    })
            for s in stream_results:
                new_items.append({
                    'id': '', 'slug': '', 'source': 'freestream', 'title': s.get('label') or query,
                    'thumb': '', 'fanart': '', 'overview': '[Free stream]',
                    '_play_url': s.get('url', ''),
                })

            if not new_items and not items:
                xbmcgui.Dialog().notification('Starfleet', 'No results for: %s' % query,
                                              xbmcgui.NOTIFICATION_INFO)
                return
            if not new_items and page > 1:
                # Nothing new on this page (e.g. a paginated site simply ran
                # out of results) — tell the user rather than silently
                # reopening the exact same list a More click just produced.
                xbmcgui.Dialog().notification('Starfleet', 'No more results for: %s' % query,
                                              xbmcgui.NOTIFICATION_INFO)

            items = items + new_items

            try:
                from resources.lib import watch_history as _wh
            except Exception:
                _wh = None
            if _wh is not None:
                # Only the newly-added rows need this — everything already
                # on screen from an earlier page was enriched the first
                # time it was added.
                for it in new_items:
                    if it.get('id'):
                        try:
                            watched, _resume, pct = _wh.get_progress('ade:%s' % it['id'])
                            it['watched'] = watched
                            it['progress_pct'] = pct
                        except Exception:
                            pass

            def _detail_fetch(film):
                # Same source-routed fetch _open_adult_info uses — only
                # meaningful for real ADE/AFDB films (id+slug present);
                # torrent/stream pseudo-items have neither, so this
                # naturally returns {} for them (their stub's own
                # title/overview already shows as-is, nothing to enrich).
                source = film.get('source', 'ade')
                fid, fslug = film.get('id', ''), film.get('slug', '')
                if not fid or not fslug:
                    return {}
                if source == 'afdb':
                    try:
                        from resources.lib import afdb as _afdb_mod
                        full = _afdb_mod.get_film_detail(fid, fslug)
                        cast = _afdb_mod.get_cast_with_photos(full.get('cast', []), limit=4)
                        return {'overview': _html_lib.unescape(full.get('description', '')), 'cast': cast}
                    except Exception:
                        return {}
                if source != 'ade':
                    return {}
                try:
                    from resources.lib import ade as _ade
                    full = _ade.get_film_detail(fid, fslug)
                    cast = _ade.get_cast_with_photos(full.get('cast', []), limit=4)
                    return {'overview': _html_lib.unescape(full.get('description', '')), 'cast': cast}
                except Exception:
                    return {}

            def _on_play(film):
                import threading as _t
                title = film.get('title', '')
                play_url = film.get('_play_url', '')
                if play_url:
                    def _play_direct(u=play_url, t=title):
                        try:
                            from resources.lib.afdb_router import adult_stream_play
                            resolved = adult_stream_play(u, t)
                            if not resolved:
                                xbmcgui.Dialog().notification('Starfleet', 'Could not resolve stream',
                                                              xbmcgui.NOTIFICATION_ERROR, 3000)
                                return
                            li = xbmcgui.ListItem(path=resolved)
                            li.setContentLookup(False)
                            li.setInfo('video', {'title': t, 'mediatype': 'movie'})
                            _url_lc = resolved.lower()
                            if '.m3u8' in _url_lc:
                                li.setMimeType('application/x-mpegURL')
                            elif '.mp4' in _url_lc:
                                li.setMimeType('video/mp4')
                            xbmc.Player().play(resolved, li)
                        except Exception as exc:
                            xbmc.log('[Starfleet/Home] adult search direct play error: %s' % exc, xbmc.LOGERROR)
                    _t.Thread(target=_play_direct, daemon=True).start()
                    return
                fid   = str(film.get('id', ''))
                fslug = str(film.get('slug', ''))
                def _play(aid=fid, aslug=fslug, t=title):
                    try:
                        from resources.lib.afdb_router import adult_ade_play_direct
                        adult_ade_play_direct(aid, aslug, t)
                    except Exception as exc:
                        xbmc.log('[Starfleet/Home] adult search play error: %s' % exc, xbmc.LOGERROR)
                _t.Thread(target=_play, daemon=True).start()

            def _context_menu(film):
                # Favorites/Watched only make sense for real ADE/AFDB films
                # with a stable id — a raw torrent/stream hit has nothing
                # meaningful to key a favorite or watched-status against.
                fid = str(film.get('id', ''))
                if not fid:
                    return []
                from urllib.parse import quote
                title  = film.get('title', '')
                thumb  = film.get('thumb', '')
                fanart = film.get('fanart', '') or thumb
                try:
                    from resources.lib import adult_favorites as _afav
                    is_fav = _afav.is_favorite(fid)
                except Exception:
                    is_fav = False
                if is_fav:
                    label_, action_ = 'Remove from Adult Favorites', 'adult_favorites_remove'
                else:
                    label_, action_ = 'Add to Adult Favorites', 'adult_favorites_add'
                return [
                    (label_, 'RunPlugin(plugin://plugin.video.starfleet/'
                     '?action=%s&ade_id=%s&title=%s&thumb=%s&fanart=%s)'
                     % (action_, fid, quote(title), quote(thumb), quote(fanart))),
                    ('Mark as Watched / Unwatched',
                     'RunPlugin(plugin://plugin.video.starfleet/'
                     '?action=meta_toggle_watched&media_type=adult&wh_key=%s&title=%s)'
                     % (quote('ade:%s' % fid), quote(title))),
                ]

            def _on_more():
                win.close()
                self._open_adult_search_page(query, page + 1, items)

            win = CategoryListWindow(
                'Starfleet-CategoryList.xml',
                xbmcaddon.Addon('plugin.video.starfleet').getAddonInfo('path'),
                'Default', '1080i',
                items=items,
                breadcrumb='Adult — Search',
                subheader='%d results  ·  "%s"' % (len(items), query),
                media_type='movie',
                on_play=_on_play,
                on_more=_on_more,
                detail_fetch=_detail_fetch,
                context_menu=_context_menu,
                on_info=lambda film: self._open_adult_info(film, play_fn=_on_play),
            )
            win.doModal()
            del win
        except Exception as e:
            xbmc.log('[Starfleet/Home] _open_adult_search_page: %s' % e, xbmc.LOGERROR)
            import traceback
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

    # Each JAV source's module exposes the same three-function shape
    # (browse_<x>_latest(page), get_<x>_detail(vid, slug),
    # resolve_<x>_stream via afdb_router's <x>_play_direct) so
    # _render_jav_category below can stay source-agnostic — adding a third
    # source later is just another entry here, no other changes needed.
    _JAV_SOURCES = {
        'javseen': {'label': 'javseen.tv', 'module': 'javseen_sources',
                   'browse': 'browse_javseen_latest', 'detail': 'get_javseen_detail',
                   'play_direct': 'javseen_play_direct'},
        'javhd':   {'label': 'javhd.today', 'module': 'javhd_sources',
                   'browse': 'browse_javhd_latest', 'detail': 'get_javhd_detail',
                   'play_direct': 'javhd_play_direct'},
        'javleak': {'label': 'javleak.com', 'module': 'javleak_sources',
                   'browse': 'browse_javleak_latest', 'detail': 'get_javleak_detail',
                   'play_direct': 'javleak_play_direct'},
        'mythav':  {'label': 'mythav.org', 'module': 'mythav_sources',
                   'browse': 'browse_mythav_latest', 'detail': 'get_mythav_detail',
                   'play_direct': 'mythav_play_direct'},
    }

    def _open_jav_menu(self):
        """Goes straight to a merged 'New/Latest' listing across every JAV
        source at once instead of making the user pick a site first — see
        _open_jav_all's own docstring for why that's viable now (every
        source carries its own 'source' tag per item plus real upfront
        artwork, see each module's own _populate_artwork)."""
        self._open_jav_all(1)

    def _open_jav_all(self, page=1):
        """Merged 'New/Latest' listing across every JAV streaming source at
        once. Each browse_X_latest() already tags its own items with
        'source', and _render_jav_category below already resolves the
        right module's detail/play functions per item rather than once for
        the whole list — so merging is just fetching every source's page
        concurrently and interleaving them, no new per-item plumbing
        needed. Round-robin interleaved (one item from each source in
        turn) so a single site's whole batch doesn't dominate the front of
        the page."""
        try:
            import importlib
            from concurrent.futures import ThreadPoolExecutor

            def _load(key):
                try:
                    cfg = self._JAV_SOURCES[key]
                    mod = importlib.import_module('resources.lib.%s' % cfg['module'])
                    browse_fn = getattr(mod, cfg['browse'])
                    return browse_fn(page) or []
                except Exception as e:
                    xbmc.log('[Starfleet/Home] _open_jav_all load %s: %s' % (key, e), xbmc.LOGWARNING)
                    return []

            dlg = _pdlg.DialogProgress()
            dlg.create('Starfleet', 'Loading JAV...')
            try:
                keys = list(self._JAV_SOURCES.keys())
                with ThreadPoolExecutor(max_workers=len(keys)) as pool:
                    per_source = list(pool.map(_load, keys))
            finally:
                dlg.close()

            merged = []
            max_len = max((len(lst) for lst in per_source), default=0)
            for i in range(max_len):
                for lst in per_source:
                    if i < len(lst):
                        merged.append(lst[i])

            has_more = any(lst for lst in per_source)
            self._render_jav_category(None, merged, 'New / Latest',
                                      next_page=page + 1 if has_more else None)
        except Exception as e:
            xbmc.log('[Starfleet/Home] _open_jav_all: %s' % e, xbmc.LOGERROR)

    def _open_jav_category(self, source, page, label):
        """JAV custom-skin category grid for whichever source was picked.
        Only one listing mode per source exists (New/Latest, sitemap-based)
        — both sites' own search/browse grids are JS-rendered and not
        scrapable without a real browser (same limitation missav.ws had),
        so there's no separate search picker here."""
        try:
            import importlib
            cfg = self._JAV_SOURCES[source]
            mod = importlib.import_module('resources.lib.%s' % cfg['module'])
            browse_fn = getattr(mod, cfg['browse'])

            dlg = _pdlg.DialogProgress()
            dlg.create('Starfleet', 'Loading JAV — %s...' % label)
            try:
                items = browse_fn(page)
            finally:
                dlg.close()
            self._render_jav_category(source, items, label, next_page=page + 1 if items else None)
        except Exception as e:
            xbmc.log('[Starfleet/Home] _open_jav_category: %s' % e, xbmc.LOGERROR)

    def _render_jav_category(self, source, items, label, next_page=None):
        try:
            import importlib
            from resources.lib.gui.category_list import CategoryListWindow

            if not items:
                xbmcgui.Dialog().notification('JAV', 'No titles found for %s' % label,
                                              xbmcgui.NOTIFICATION_INFO)
                return

            # source is None for the merged "all sources" listing (see
            # _open_jav_all) — every item still carries its own 'source'
            # tag, so cfg/detail_fn/play_fn are resolved per item below
            # instead of once for the whole list, which is what makes
            # merging different sources into one grid possible at all.
            _mod_cache = {}

            def _detail_fn_for(src):
                if src not in _mod_cache:
                    cfg = self._JAV_SOURCES.get(src)
                    _mod_cache[src] = None
                    if cfg:
                        try:
                            mod = importlib.import_module('resources.lib.%s' % cfg['module'])
                            _mod_cache[src] = getattr(mod, cfg['detail'])
                        except Exception:
                            pass
                return _mod_cache[src]

            try:
                from resources.lib import watch_history as _wh
            except Exception:
                _wh = None
            for it in items:
                it.setdefault('overview', it.get('description', ''))
                if _wh is not None:
                    try:
                        # Structured watched/in-progress state (dedicated
                        # checkmark/percent slot) rather than appending text
                        # onto this fixed-width, non-wrapping title label —
                        # see the same fix applied to TV episodes.
                        watched, _resume, pct = _wh.get_progress(
                            '%s:%s' % (it.get('source', source), it.get('id', '')))
                        it['watched'] = watched
                        it['progress_pct'] = pct
                    except Exception:
                        pass

            def _detail_fetch(film):
                vid  = film.get('id', '')
                slug = film.get('slug', '')
                detail_fn = _detail_fn_for(film.get('source', source))
                if not vid or not slug or not detail_fn:
                    return {}
                detail = detail_fn(vid, slug)
                out = {}
                if detail.get('description'):
                    out['overview'] = detail['description']
                # CategoryListWindow._update_side_panels only applies a lazy
                # per-focus image override via detail['poster']/detail['backdrop']
                # (the same keys Sports' venue-photo lookup uses) — it never
                # looks at 'fanart'. This is a supplementary refresh on
                # focus; the grid's own list icon is already populated
                # up front by each module's own _populate_artwork now.
                if detail.get('fanart'):
                    out['poster']   = detail['fanart']
                    out['backdrop'] = detail['fanart']
                return out

            def _on_play(film):
                import threading as _t
                src   = film.get('source', source)
                cfg   = self._JAV_SOURCES.get(src)
                if not cfg:
                    return
                vid   = film.get('id', '')
                slug  = film.get('slug', '')
                title = film.get('title', '')
                def _play(v=vid, s=slug, t=title, cfg=cfg):
                    try:
                        import resources.lib.afdb_router as _ar
                        play_fn = getattr(_ar, cfg['play_direct'])
                        play_fn(v, s, t)
                    except Exception as exc:
                        xbmc.log('[Starfleet/Home] jav direct play error: %s' % exc, xbmc.LOGERROR)
                _t.Thread(target=_play, daemon=True).start()

            def _on_more():
                # Same close-only-right-before-a-confirmed-transition
                # pattern as _open_adult_category's own _on_more — avoids
                # nesting a second CategoryListWindow's doModal() before
                # this one has finished unwinding.
                win.close()
                if next_page:
                    if source is None:
                        self._open_jav_all(next_page)
                    else:
                        self._open_jav_category(source, next_page, 'New / Latest')
                else:
                    self._open_jav_menu()

            breadcrumb_label = self._JAV_SOURCES[source]['label'] if source else 'All Sources'
            win = CategoryListWindow(
                'Starfleet-CategoryList.xml',
                xbmcaddon.Addon('plugin.video.starfleet').getAddonInfo('path'),
                'Default', '1080i',
                items=items,
                breadcrumb='JAV — %s' % breadcrumb_label,
                subheader='%d titles  ·  %s' % (len(items), label),
                media_type='movie',
                on_play=_on_play,
                detail_fetch=_detail_fetch,
                on_more=_on_more,
            )
            win.doModal()
            del win
        except Exception as e:
            xbmc.log('[Starfleet/Home] _render_jav_category: %s' % e, xbmc.LOGERROR)
            import traceback
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

    def _fetch_adult_full_library(self, page=1):
        """fetch_fn-shaped wrapper (matches ade.py's browse_*(page) shape)
        around afdb_router's shared, 2h-cached full-library builder — `page`
        is accepted but ignored since the whole merged list is already
        locally paginated by the caller/skin, not fetched page-by-page like
        the ADE browse_* endpoints. Same cache the native adult_movies_library
        page uses, so switching between the two UI paths never rebuilds the
        (expensive, real per-title stream-source verification) list twice
        in the same 2h window."""
        from resources.lib.afdb_router import get_full_library_cached
        return get_full_library_cached()

    def _open_adult_movies_menu(self):
        """Movies submenu — the same real items the native adult_movies_menu
        page has (New Releases/Recently Added/Best Sellers/Adult Favorites/
        Full Library), also as an in-process select dialog. The first three
        all come from ade.py's shared _browse() helper, so they're
        guaranteed identical in shape to New Releases (already proven to
        work) and open the custom category list. Full Library now also opens
        the custom category list via _fetch_adult_full_library (confirmed
        live: it was falling through to the native Estuary-skinned page,
        which is what "isn't our three panel skin" was reporting). Adult
        Favorites (its own saved-favorites storage) has a different enough
        data shape that it isn't adapted yet — still goes to its existing
        native page."""
        try:
            from resources.lib import ade as _ade
            options = ['New Releases', 'Recently Added', 'Best Sellers', 'Adult Favorites', 'Full Library']
            xbmc.sleep(150)  # see _open_movies_menu for why this settling delay is needed
            idx = _select_dialog('Adult — Movies', options)
            if idx == 0:
                self._open_adult_category(_ade.browse_new_release_movies, 'New Releases')
            elif idx == 1:
                self._open_adult_category(_ade.browse_recently_added_videos, 'Recently Added')
            elif idx == 2:
                self._open_adult_category(_ade.browse_bestseller_videos, 'Best Sellers')
            elif idx == 3:
                self._nav('adult_favorites_list')
            elif idx == 4:
                self._open_adult_category(self._fetch_adult_full_library, 'Full Library')
        except Exception as e:
            xbmc.log('[Starfleet/Home] _open_adult_movies_menu: %s' % e, xbmc.LOGERROR)

    def _open_adult_info(self, film, play_fn=None):
        """'Info' long-press action for any Adult browsing screen — the same
        rich detail screen (AnticipatedDetailWindow) Home's Upcoming widget
        uses, in its 'adult' favorites_mode (see anticipated_detail.py):
        favoriting goes through adult_favorites.py instead of favorites.py,
        and Play is never gated on a release date (nothing in these
        listings is ever "not out yet"). Source-routed the same way
        _detail_fetch inside _open_adult_category is (ADE vs AFDB vs
        free-stream stubs each have incompatible id/slug namespaces and
        different detail-fetch capabilities — see that method's own
        comment for the full explanation), since Full Library mixes all
        three and this needs to work from there too, not just the
        single-source ADE lists.

        play_fn: optional callable(film) -> None overriding the default
        adult_ade_play_direct(id, slug, title) routing — every non-ADE
        Adult screen (HQ Porner, MyPornClub, etc) plays through its own
        different function with its own argument shape (HQP needs
        slug+url, not an ADE id/slug pair), so those callers pass their
        own already-built _on_play here instead of getting a wrong-site
        play attempt from Info's own Play button."""
        try:
            from resources.lib.gui.anticipated_detail import AnticipatedDetailWindow
            import html as _html_lib

            source = film.get('source', 'ade')
            fid, fslug = str(film.get('id', '')), str(film.get('slug', ''))
            title = _html_lib.unescape(film.get('title', ''))

            dlg = _pdlg.DialogProgress()
            dlg.create('Starfleet', 'Loading details...')
            cast, description, year, runtime, director, rating, genres, studios, trailer_url = \
                [], film.get('overview', ''), film.get('year', ''), 0, '', 0, [], [], ''
            try:
                if source == 'afdb' and fid and fslug:
                    from resources.lib import afdb as _afdb_mod
                    full = _afdb_mod.get_film_detail(fid, fslug)
                    description = full.get('description', '') or description
                    year = full.get('year', '') or year
                    runtime = full.get('runtime', 0)
                    director = full.get('director', '') or ''
                    rating = full.get('rating', 0) or 0
                    genres = full.get('categories', []) or []
                    studios = [full.get('studio', '')] if full.get('studio') else []
                    cast = [dict(c, character='') for c in
                            _afdb_mod.get_cast_with_photos(full.get('cast', []), limit=5)]
                elif source == 'ade' and fid and fslug:
                    from resources.lib import ade as _ade
                    full = _ade.get_film_detail(fid, fslug)
                    description = full.get('description', '') or description
                    year = full.get('year', '') or year
                    runtime = full.get('runtime', 0)
                    director = full.get('director', '') or ''
                    rating = full.get('rating', 0) or 0
                    genres = full.get('categories', []) or []
                    studios = [full.get('studio', '')] if full.get('studio') else []
                    cast = _ade.get_cast_with_photos(full.get('cast', []), limit=5)
                    try:
                        trailer_url = _ade.trailer_url(fid) or ''
                    except Exception:
                        pass
                # else: free-stream stub sources (panda/hqporner/freeo/etc)
                # have no per-title detail endpoint — shows just what the
                # stub already carries, same honest degradation as the
                # side-panel's own _detail_fetch for these.
            finally:
                dlg.close()

            detail = {
                'title': title, 'tagline': '', 'overview': _html_lib.unescape(description),
                'thumb': film.get('thumb', ''), 'fanart': film.get('fanart') or film.get('thumb', ''),
                'director': director, 'writers': [], 'rating': rating, 'votes': 0,
                'genres': genres, 'studios': studios, 'year': year,
                'release_date': '%s-01-01' % year if str(year).isdigit() else '',
                'status': 'Released', 'trailer': trailer_url, 'cast': cast,
            }

            def _on_play():
                if play_fn:
                    play_fn(film)
                    return
                import threading as _t
                def _play(aid=fid, aslug=fslug, t=title):
                    try:
                        from resources.lib.afdb_router import adult_ade_play_direct
                        adult_ade_play_direct(aid, aslug, t)
                    except Exception as exc:
                        xbmc.log('[Starfleet/Home] adult info play error: %s' % exc, xbmc.LOGERROR)
                _t.Thread(target=_play, daemon=True).start()

            def _on_trailer(trailer_url):
                li = xbmcgui.ListItem(title + ' - Trailer')
                li.setProperty('IsPlayable', 'true')
                xbmc.Player().play(trailer_url, li)

            def _on_cast_click(name):
                self._detail_win.close()
                self._open_adult_performer(name)

            self._detail_win = AnticipatedDetailWindow(
                'Starfleet-AnticipatedDetail.xml',
                xbmcaddon.Addon('plugin.video.starfleet').getAddonInfo('path'),
                'Default', '1080i',
                tmdb_id=fid, media_type='movie', detail=detail,
                favorites_mode='adult',
                on_play=_on_play, on_trailer=_on_trailer,
                on_cast_click=_on_cast_click,
            )
            self._detail_win.doModal()
            del self._detail_win
        except Exception as e:
            xbmc.log('[Starfleet/Home] _open_adult_info: %s' % e, xbmc.LOGERROR)
            import traceback
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

    def _open_adult_performer(self, name):
        """In-process replacement for self._nav('adult_performer_films...')
        — same fix as _open_person_films, for Adult. Reuses the existing
        Adult category grid (_open_adult_category) entirely rather than
        building a separate window, since ADE's performer-filtered search
        (search_by_talent) returns the exact same film-stub shape as every
        other Adult browse list this screen already renders."""
        from resources.lib import ade as _ade
        self._open_adult_category(lambda page, _n=name: _ade.search_by_talent(_n), '👤 %s' % name)

    def _open_adult_category(self, fetch_fn, label, page=1):
        """Second custom-skin category grid — same in-process doModal()
        pattern as _open_movies_category, sourced from Adult DVD Empire
        instead of TMDB. fetch_fn is whichever ade.py browse_* function the
        caller picked (New Releases/Recently Added/Best Sellers all share
        the same stub shape). Cast strip pulls each performer's own ADE
        profile photo (ade.get_cast_with_photos), not just a name. Play must
        NOT go through _nav()/ActivateWindow here — it reuses
        adult_ade_play_direct, the exact same doModal-safe direct-call path
        _play_film's 'ade' branch already uses for the Home carousels,
        called in a background thread with neither Home nor this window
        closing (Kodi's player takes over the screen the same way it does
        for a carousel click).

        page: local pagination over the already-fetched list (NOT passed to
        fetch_fn — Full Library's fetch_fn ignores its own page arg and
        always returns the whole 2h-cached merged catalog regardless).
        Confirmed live this catalog is genuinely huge (~9,500+ titles) —
        CategoryListWindow.onInit() builds one xbmcgui.ListItem per item in
        a single synchronous GUI-thread loop, so dumping all of them in at
        once was still enough to back up Kodi's input queue for seconds
        (misapplied Up/Down, unresponsive Back) even after removing the
        separately-diagnosed dead eager-context-menu computation and
        threading the per-focus detail fetch in earlier releases — those
        were both real fixes for real bugs, just not the one actually
        responsible for Full Library specifically, since it's the only
        category anywhere near this size. Small ADE stub pages (New
        Releases/Recently Added/Best Sellers, typically a few dozen items)
        never exceed _PAGE_SIZE so they render exactly as before, unpaged."""
        try:
            from resources.lib.gui.category_list import CategoryListWindow
            from resources.lib import ade as _ade

            dlg = _pdlg.DialogProgress()
            dlg.create('Starfleet', 'Loading Adult — %s...' % label)
            try:
                # fetch_fn(1) used to be a single blocking call with no way
                # to check dlg.iscanceled() during the wait — same real bug
                # as every "Grab a tissue"/browse-loading dialog fixed in
                # afdb_router.py, just in this custom-skin grid's own copy.
                # Full Library's own fetch_fn can genuinely take a while
                # (~9,500+ title catalogue build on a cold cache), so this
                # was the single worst offender for a Cancel press doing
                # nothing.
                from resources.lib.afdb_router import _run_cancelable
                raw_items, _canceled = _run_cancelable(dlg, lambda: fetch_fn(1), 90)
                if _canceled:
                    return
                # Same no-source filter the native adult_browse_* menus use
                # (afdb_router._ade_browse_page) — this custom-skin grid used
                # to skip it entirely, so titles already confirmed dead by a
                # real play attempt (trailer+XXXClub+Rintor+free all empty)
                # kept reappearing here even after being hidden everywhere
                # else.
                if raw_items:
                    from resources.lib.afdb_router import _filter_films_with_sources
                    raw_items = _filter_films_with_sources(raw_items)
            finally:
                dlg.close()
            if not raw_items:
                xbmcgui.Dialog().notification('Starfleet', 'Could not load Adult listing', xbmcgui.NOTIFICATION_ERROR)
                return

            # category_list.py reads plot from film['overview'] — ADE stubs
            # carry it as 'description' instead, so alias it here rather than
            # teaching the (source-agnostic) skin controller a second key name.
            # Titles/descriptions off ADE's own pages carry raw HTML entities
            # (e.g. "Sister&#39;s") — afdb_router.py's own listing renderer
            # already unescapes these; this path didn't, so apostrophes in
            # titles showed up literally as "&#39;".
            import html as _html_lib
            try:
                from resources.lib import watch_history as _wh
            except Exception:
                _wh = None
            # Confirmed live 2026-08-28 (real user report: titles like "A
            # Hairy Cougar &038; Her Toy" instead of "... & Her Toy") — one
            # of Full Library's merged sources has a real "&" in its raw
            # title correctly encoded as the numeric entity "&#038;", but
            # something upstream of here (whichever scraper's own regex)
            # drops the "#" specifically before this file ever sees it,
            # then re-escapes the resulting bare "&" back into "&amp;" —
            # net effect "&amp;038;", which a single html.unescape() call
            # (already applied below) can only partially resolve: "&amp;"
            # decodes fine, but the leftover "038;" isn't a valid entity
            # without its "#" so it's correctly left as literal text,
            # producing exactly the "&038;" seen live. A second unescape
            # pass doesn't help (confirmed live) since "&038;" was never a
            # real entity to begin with. This regex targets that exact
            # leftover shape directly — a bare "&<digits>;" with no "#" —
            # and finishes what the missing "#" prevented unescape from
            # doing, regardless of which of the merged sources produced it.
            import re as _re_ent
            def _fix_leftover_entity(t):
                return _re_ent.sub(r'&(\d+);', lambda m: chr(int(m.group(1))), t)

            # Confirmed live 2026-08-29: calling _wh.get_progress() once PER
            # item here (up to ~9,500 for Full Library) means that many
            # separate file reads/JSON parses — get_progress() deliberately
            # re-reads the watch-history file every call (see its own
            # docstring), which is correct for a single lookup but not for
            # a bulk loop like this one, and it all runs AFTER the loading
            # dialog above has already closed, i.e. a real multi-second
            # stall with nothing on screen — reported back as "there is a
            # delay on showing the content page it makes users think it
            # failed". get_progress_bulk() reads the file exactly once.
            _progress_map = {}
            if _wh is not None:
                try:
                    _progress_map = _wh.get_progress_bulk(
                        'ade:%s' % f['id'] for f in raw_items if f.get('id'))
                except Exception:
                    pass
            items = []
            for f in raw_items:
                f = dict(f)
                f['title']    = _fix_leftover_entity(_html_lib.unescape(f.get('title', '')))
                f['overview'] = _fix_leftover_entity(_html_lib.unescape(f.get('description', '')))
                if f.get('id'):
                    prog = _progress_map.get('ade:%s' % f['id'])
                    if prog:
                        f['watched'], _resume, f['progress_pct'] = prog
                items.append(f)

            _PAGE_SIZE = 300
            total_items = len(items)
            total_pages = max(1, -(-total_items // _PAGE_SIZE))  # ceil div
            # Mutable holder (not a plain int) so _on_more() below can
            # advance it across repeated "Next Page" clicks — a plain
            # closed-over local can't be rebound from a nested function
            # without 'nonlocal', and this needs to work the same way in
            # both this file's Python 2-compatible spots and here.
            _page_box = [max(1, min(page, total_pages))]

            def _slice_page(pg):
                if total_items > _PAGE_SIZE:
                    p_items = items[(pg - 1) * _PAGE_SIZE: pg * _PAGE_SIZE]
                    subhdr  = '%d titles  ·  Page %d/%d  ·  %s' % (total_items, pg, total_pages, label)
                else:
                    p_items = items
                    subhdr  = '%d titles  ·  %s' % (total_items, label)
                more_lbl = ('Next Page (%d/%d) >' % (pg + 1, total_pages)) \
                    if (total_items > _PAGE_SIZE and pg < total_pages) else 'More Sections >'
                return p_items, subhdr, more_lbl

            page = _page_box[0]
            page_items, subheader, _more_label_initial = _slice_page(page)

            def _detail_fetch(film, _ade=_ade, _html=_html_lib):
                # Full Library merges THREE distinct sources with different
                # id/slug namespaces (see _build_full_library): real ADE
                # items, AFDB items (adultfilmdatabase.com — a totally
                # different site from ade.py's adultdvdempire.com, despite
                # the similar name), and free-stream-source stubs (panda/
                # hqporner/etc, tagged with their own 'source'). This used
                # to always call ade.get_film_detail() regardless, which
                # silently returned nothing for every non-ADE item — an
                # AFDB id queried against ADE's site just doesn't exist
                # there. New Releases/Recently Added/Best Sellers are pure
                # single-source ADE lists and were never affected; only
                # Full Library merges more than one source at all.
                source = film.get('source', 'ade')
                fid, fslug = film.get('id', ''), film.get('slug', '')
                if not fid or not fslug:
                    return {}
                if source == 'afdb':
                    try:
                        from resources.lib import afdb as _afdb_mod
                        full = _afdb_mod.get_film_detail(fid, fslug)
                    except Exception:
                        return {}
                    # The FILM detail page's own cast links never carry a
                    # photo (that part of the old comment here was right),
                    # but each actor's OWN detail page does have a real one
                    # — get_cast_with_photos() fetches those in parallel,
                    # same as ade.py already does for ADE content.
                    cast = _afdb_mod.get_cast_with_photos(full.get('cast', []), limit=4)
                    return {'overview': _html.unescape(full.get('description', '')), 'cast': cast}
                def _enrich_from_detail(full):
                    # Shared by every free-stream source below that DOES
                    # have its own per-title detail page (unlike the
                    # true stub-only sources further down) — each one's
                    # own _*_film_detail() already returns this same
                    # {description, thumb, cast} shape (see their own
                    # docstrings for what each site's page actually
                    # exposes and how cast names get extracted).
                    if not full:
                        return {}
                    result = {}
                    if full.get('description'):
                        result['overview'] = full['description']
                    if full.get('thumb'):
                        result['poster'] = full['thumb']
                    if full.get('cast'):
                        result['cast'] = full['cast']
                    return result

                if source == 'pandamovies':
                    # PandaMovies is ~75% of Full Library's total items
                    # (confirmed live) — by far the biggest of the "no
                    # detail endpoint" sources below, but it DOES actually
                    # have one (its own per-title page, already fetched for
                    # streams elsewhere) — it just wasn't being read for
                    # plot/cast before. See _panda_film_detail's own
                    # docstring for exactly what's extracted (og:description
                    # for a real synopsis + "Starring:" names for cast,
                    # no per-performer photos exist on this site at all).
                    try:
                        from resources.lib import adult_streams as _pastr
                        return _enrich_from_detail(_pastr._panda_film_detail(fslug, film.get('url', '')))
                    except Exception:
                        return {}
                if source == 'freeomovie':
                    # Same idea as PandaMovies above — freeomovie.to also
                    # has its own per-title detail page (confirmed live: a
                    # clean "<strong>Cast:</strong> Name1, Name2..." line,
                    # plus a real og:description synopsis already extracted
                    # here for streams; only cast/poster enrichment for
                    # Full Library specifically was missing before).
                    try:
                        from resources.lib import adult_streams as _fastr
                        return _enrich_from_detail(_fastr._freeo_film_detail(fslug, film.get('url', '')))
                    except Exception:
                        return {}
                if source != 'ade':
                    # Free-stream stub sources (hqporner/etc — every OTHER
                    # merged source besides ADE/AFDB/PandaMovies/freeomovie
                    # above) have no per-title detail endpoint at all — the
                    # stub already carries everything that will ever be
                    # known about it, so there's nothing to enrich.
                    return {}
                full = _ade.get_film_detail(fid, fslug)
                cast = _ade.get_cast_with_photos(full.get('cast', []), limit=4)
                return {'overview': _html.unescape(full.get('description', '')), 'cast': cast}

            def _on_play(film):
                import threading as _t
                fid    = str(film.get('id', ''))
                fslug  = str(film.get('slug', ''))
                ftitle = film.get('title', '')
                def _play(aid=fid, aslug=fslug, t=ftitle):
                    try:
                        from resources.lib.afdb_router import adult_ade_play_direct
                        adult_ade_play_direct(aid, aslug, t)
                    except Exception as exc:
                        xbmc.log('[Starfleet/Home] adult direct play error: %s' % exc, xbmc.LOGERROR)
                _t.Thread(target=_play, daemon=True).start()

            def _on_actor_click(name):
                win.close()
                self._open_adult_performer(name)

            has_next = total_items > _PAGE_SIZE and page < total_pages

            def _on_more():
                # Recomputed against _page_box[0] (the CURRENT page, which
                # advances each time this fires) rather than the 'has_next'
                # captured above — that one reflects only the page this
                # window originally opened on, so without this a user
                # paging from e.g. page 28 to the real last page (29) would
                # still see 'Next Page' offered as if stuck on page 1's
                # answer instead of correctly falling through to the
                # submenu picker once there's genuinely nothing further.
                has_next = total_items > _PAGE_SIZE and _page_box[0] < total_pages
                # When paginated, the button's own label already says
                # "Next Page (X/Y) >" (see more_label below) — clicking it
                # should just go there directly, not open a picker with that
                # same option buried inside it. Burying it there originally
                # was reported back as "doesn't have a next page feature" —
                # a real "it works but nobody would ever find it" bug, not
                # a functional one. Only falls through to the submenu
                # picker (jump to New Releases/Recently Added/etc) when
                # there's no next page, i.e. every list this small already
                # behaved exactly like before this feature existed.
                #
                # Confirmed live 2026-08-28 (real user reports): the old
                # win.close() + _open_adult_category(...) recursion here had
                # two real, separate problems. It briefly revealed Home
                # (paused underneath this modal, not actually closed — see
                # this file's own architecture notes) before the new page's
                # window opened, reported back as "reverts to the widget
                # home page and loads a new page" — a real, visible glitch,
                # not a misunderstanding. And the brand-new window's own
                # onInit() re-ran _set_asset_paths() a second time, which
                # silently failed to resolve sf_asset_focus_row on that
                # second pass — reported back as "the next page highlight
                # is black" (the focused row's texture was simply missing,
                # not mis-colored). Since 'items' here is already the full,
                # already-fetched-and-filtered list for this whole category
                # (page is just a LOCAL slice into it — see docstring above
                # 'page:'), advancing to the next page needs nothing from
                # fetch_fn or _filter_films_with_sources at all; just slide
                # the window forward over the same list and refresh this
                # SAME already-open window in place (win.set_items) instead
                # of tearing the whole thing down and rebuilding it.
                if has_next:
                    _page_box[0] += 1
                    new_items, new_subheader, new_more_label = _slice_page(_page_box[0])
                    win.set_items(new_items, subheader=new_subheader, more_label=new_more_label)
                    return
                # Shows the Movies-submenu picker while THIS window stays
                # open underneath (Dialog.select() doesn't nest a doModal()
                # the way another CategoryListWindow would, so that's safe)
                # and only closes it if the user actually picks something —
                # cancelling leaves this list open exactly as it was.
                # Previously this closed the window unconditionally before
                # even showing the picker, then called
                # _open_adult_movies_menu() separately, which could open yet
                # another CategoryListWindow while THIS one's own .doModal()
                # hadn't finished unwinding — the same close-before-nesting
                # bug confirmed live for Sports' Back button, fixed here the
                # same way (close only right before a confirmed transition).
                from resources.lib import ade as _ade
                options = ['New Releases', 'Recently Added', 'Best Sellers', 'Adult Favorites', 'Full Library']
                xbmc.sleep(150)  # see _open_movies_menu for why this settling delay is needed
                idx = _select_dialog('Adult — Movies', options)
                if idx == 0:
                    win.close()
                    self._open_adult_category(_ade.browse_new_release_movies, 'New Releases')
                elif idx == 1:
                    win.close()
                    self._open_adult_category(_ade.browse_recently_added_videos, 'Recently Added')
                elif idx == 2:
                    win.close()
                    self._open_adult_category(_ade.browse_bestseller_videos, 'Best Sellers')
                elif idx == 3:
                    win.close()
                    self._nav('adult_favorites_list')
                elif idx == 4:
                    win.close()
                    self._open_adult_category(self._fetch_adult_full_library, 'Full Library')

            def _context_menu(film):
                from urllib.parse import quote
                fid    = str(film.get('id', ''))
                title  = film.get('title', '')
                thumb  = film.get('thumb', '')
                fanart = film.get('fanart', '') or thumb
                try:
                    from resources.lib import adult_favorites as _afav
                    is_fav = _afav.is_favorite(fid)
                except Exception:
                    is_fav = False
                if is_fav:
                    label_, action_ = 'Remove from Adult Favorites', 'adult_favorites_remove'
                else:
                    label_, action_ = 'Add to Adult Favorites', 'adult_favorites_add'
                return [
                    (label_, 'RunPlugin(plugin://plugin.video.starfleet/'
                     '?action=%s&ade_id=%s&title=%s&thumb=%s&fanart=%s)'
                     % (action_, fid, quote(title), quote(thumb), quote(fanart))),
                    # Reuses the generic meta_toggle_watched action with
                    # wh_key='ade:<id>' — the exact key this list's own read
                    # side already checks (_wh.get_progress('ade:%s' % f['id'])
                    # above), so a manual toggle always lands where the
                    # checkmark render actually looks. Movies/TV had this
                    # option; Adult's browsing categories never did.
                    ('Mark as Watched / Unwatched',
                     'RunPlugin(plugin://plugin.video.starfleet/'
                     '?action=meta_toggle_watched&media_type=adult&wh_key=%s&title=%s)'
                     % (quote('ade:%s' % fid), quote(title))),
                ]

            win = CategoryListWindow(
                'Starfleet-CategoryList.xml',
                xbmcaddon.Addon('plugin.video.starfleet').getAddonInfo('path'),
                'Default', '1080i',
                items=page_items,
                breadcrumb='Adult',
                subheader=subheader,
                media_type='movie',
                on_play=_on_play,
                detail_fetch=_detail_fetch,
                on_actor_click=_on_actor_click,
                on_more=_on_more,
                more_label=_more_label_initial,
                context_menu=_context_menu,
                on_info=self._open_adult_info,
            )
            win.doModal()
            del win
        except Exception as e:
            xbmc.log('[Starfleet/Home] _open_adult_category: %s' % e, xbmc.LOGERROR)
            import traceback
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

    def _open_adult_scenes_select(self):
        """Scenes' own source picker — custom-skin equivalent of the native
        adult_scenes_select() themed dialog. Previously this slot jumped
        straight to HQPorner's category browse, skipping the 18 tube sites
        (XVideos, XNXX, PornHub, YouPorn, xHamster, Xerotica, RedTube,
        Tube8, Thumbzilla, Porntrex, NoodleMagazine, LetMeJizz, Eporner,
        Beeg, TNAFlix, TXXX, HDZog, 6XTube) that were built and shipped in
        the native path but never wired into this custom-skin one."""
        try:
            from resources.lib.afdb_router import _adult_scene_site_registry
            registry = _adult_scene_site_registry()
            labels = ['HQPorner (browse by category)'] + [v['label'] for v in registry.values()]
            xbmc.sleep(150)
            idx = _select_dialog('Scenes — Choose Source', labels)
            if idx < 0:
                return
            if idx == 0:
                self._open_adult_hqp_categories()
                return
            site_key = list(registry.keys())[idx - 1]
            site_label = registry[site_key]['label']
            self._open_adult_scene_movies(site_key, site_label, 1)
        except Exception as e:
            xbmc.log('[Starfleet/Home] _open_adult_scenes_select: %s' % e, xbmc.LOGERROR)
            import traceback
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

    def _open_adult_scene_movies(self, site_key, site_label, page):
        """Paginated movie grid for one Scenes tube site — same
        _verify_stream_sources filter and no-handle direct-play pattern as
        _open_adult_hqp_movies, generalized across the site registry
        instead of hardcoded to HQ Porner."""
        try:
            from resources.lib.gui.category_list import CategoryListWindow
            from resources.lib.afdb_router import (_adult_scene_site_registry,
                                                     _verify_stream_sources,
                                                     adult_scene_play_direct)

            registry = _adult_scene_site_registry()
            site_info = registry.get(site_key)
            if not site_info:
                return

            dlg = _pdlg.DialogProgress()
            dlg.create('Starfleet', 'Loading %s...' % site_label)
            try:
                films = site_info['movies'](page)
                films = _verify_stream_sources(
                    films, lambda f, d=site_info['detail']: d(f['slug'], f['url']))
            finally:
                dlg.close()
            if not films:
                xbmcgui.Dialog().notification(site_label, 'No videos found', xbmcgui.NOTIFICATION_INFO)
                return

            try:
                from resources.lib import watch_history as _wh
            except Exception:
                _wh = None
            items = []
            for f in films:
                it = dict(f)
                it.setdefault('overview', '')
                it.setdefault('fanart', f.get('thumb', ''))
                if _wh is not None and it.get('slug'):
                    try:
                        watched, _resume, pct = _wh.get_progress('%s:%s' % (site_key, it['slug']))
                        it['watched'] = watched
                        it['progress_pct'] = pct
                    except Exception:
                        pass
                items.append(it)

            def _on_play(film):
                import threading as _t
                slug     = film.get('slug', '')
                film_url = film.get('url', '')
                title    = film.get('title', '')
                def _play(s=slug, u=film_url, t=title):
                    try:
                        adult_scene_play_direct(site_key, s, u, t)
                    except Exception as exc:
                        xbmc.log('[Starfleet/Home] scene direct play error: %s' % exc, xbmc.LOGERROR)
                _t.Thread(target=_play, daemon=True).start()

            def _on_more():
                win.close()
                self._open_adult_scene_movies(site_key, site_label, page + 1)

            win = CategoryListWindow(
                'Starfleet-CategoryList.xml',
                xbmcaddon.Addon('plugin.video.starfleet').getAddonInfo('path'),
                'Default', '1080i',
                items=items,
                breadcrumb='Adult — Scenes — %s' % site_label,
                subheader='%d titles  ·  page %d' % (len(items), page),
                media_type='movie',
                on_play=_on_play,
                on_more=_on_more,
                on_info=lambda film: self._open_adult_info(film, play_fn=_on_play),
            )
            win.doModal()
            del win
        except Exception as e:
            xbmc.log('[Starfleet/Home] _open_adult_scene_movies: %s' % e, xbmc.LOGERROR)
            import traceback
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

    def _open_adult_tvnow_channels(self):
        """Custom-skin equivalent of the native adult_tvnow_channels() page
        — 18+ live channels via tvnow247's channel_id scheme. Each click
        resolves fresh (resolve_tvnow_stream, never cached — tokens
        expire), same as the native afdb_router path."""
        try:
            from resources.lib.gui.category_list import CategoryListWindow
            from resources.lib import live_sources as _ls

            dlg = _pdlg.DialogProgress()
            dlg.create('Starfleet', 'Loading 18+ channels...')
            try:
                channels = _ls.get_tvnow_adult_channels()
            finally:
                dlg.close()
            if not channels:
                xbmcgui.Dialog().notification('Starfleet', 'No 18+ channels available right now',
                                              xbmcgui.NOTIFICATION_INFO)
                return

            items = [{'title': ch['title'], 'thumb': '', 'channel_id': ch['id'],
                      'overview': '', 'fanart': ''} for ch in channels]

            def _on_play(ch):
                import threading as _t
                channel_id = ch.get('channel_id', '')
                title = ch.get('title', '')
                def _play(cid=channel_id, t=title):
                    try:
                        pdlg = _pdlg.DialogProgress()
                        pdlg.create('Starfleet', 'Resolving %s...' % t)
                        try:
                            # get_tvnow_adult_channels() now sources most ids
                            # from dlstreams.st (not tvnow247.top) plus one
                            # static direct-URL channel (Vivid TV) —
                            # resolve_adult_channel() dispatches to the
                            # right one per channel.
                            stream_url = _ls.resolve_adult_channel(cid)
                        finally:
                            pdlg.close()
                        if not stream_url:
                            xbmcgui.Dialog().notification('Starfleet', 'Stream unavailable right now',
                                                          xbmcgui.NOTIFICATION_ERROR)
                            return
                        li = xbmcgui.ListItem(label=t, path=stream_url)
                        li.setProperty('IsPlayable', 'true')
                        xbmc.Player().play(stream_url, li)
                    except Exception as exc:
                        xbmc.log('[Starfleet/Home] adult tvnow channel play error: %s' % exc, xbmc.LOGERROR)
                _t.Thread(target=_play, daemon=True).start()

            win = CategoryListWindow(
                'Starfleet-CategoryList.xml',
                xbmcaddon.Addon('plugin.video.starfleet').getAddonInfo('path'),
                'Default', '1080i',
                items=items,
                breadcrumb='Adult — Channels',
                subheader='%d channels' % len(items),
                media_type='movie',
                on_play=_on_play,
            )
            win.doModal()
            del win
        except Exception as e:
            xbmc.log('[Starfleet/Home] _open_adult_tvnow_channels: %s' % e, xbmc.LOGERROR)
            import traceback
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

    def _open_adult_hqp_categories(self):
        """Custom-skin equivalent of the native adult_hqp_categories() page —
        two-level hierarchy (categories → movies within a category), same
        on_play-as-'activated' convention _open_sports_category/
        _open_movie_genre_list already use. Does NOT close this window
        before opening a category's movie list — same nest-underneath
        pattern as every other picker→sub-list transition this session."""
        try:
            from resources.lib.gui.category_list import CategoryListWindow
            from resources.lib import adult_streams as _as

            dlg = _pdlg.DialogProgress()
            dlg.create('Starfleet', 'Loading HQ Porner categories...')
            try:
                cats = _as.get_hqporner_categories()
            finally:
                dlg.close()
            if not cats:
                xbmcgui.Dialog().notification('Starfleet', 'No categories found', xbmcgui.NOTIFICATION_ERROR)
                return

            items = [{'title': c.get('name', ''), 'cat_url': c.get('url', ''),
                      'year': '', 'thumb': '', 'fanart': '', 'overview': ''} for c in cats]

            def _on_play(c):
                self._open_adult_hqp_movies(c.get('cat_url', ''), c.get('title', ''), 1)

            def _on_more():
                win.close()
                self._open_adult_menu()

            win = CategoryListWindow(
                'Starfleet-CategoryList.xml',
                xbmcaddon.Addon('plugin.video.starfleet').getAddonInfo('path'),
                'Default', '1080i',
                items=items,
                breadcrumb='Adult — Scenes',
                subheader='%d categories' % len(items),
                media_type='movie',
                on_play=_on_play,
                on_more=_on_more,
            )
            win.doModal()
            del win
        except Exception as e:
            xbmc.log('[Starfleet/Home] _open_adult_hqp_categories: %s' % e, xbmc.LOGERROR)
            import traceback
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

    def _open_adult_hqp_movies(self, cat_url, cat_name, page):
        """Paginated movie grid for one HQ Porner category — same
        _verify_stream_sources filter the native adult_hqp_movies() page
        uses (list-page stubs always carry empty streams:[] until a detail
        fetch happens, so without this every card would show regardless of
        whether a real stream is actually found). on_more paginates deeper
        into this SAME category (HQ Porner's own category pages are
        genuinely multi-page) instead of reopening the category picker.
        Play calls adult_hqp_play_direct in a background thread — the
        no-handle, Player().play()-based twin of the native adult_hqp_play,
        same pattern as adult_ade_play_direct/javseen_play_direct."""
        try:
            from resources.lib.gui.category_list import CategoryListWindow
            from resources.lib import adult_streams as _as

            dlg = _pdlg.DialogProgress()
            dlg.create('Starfleet', 'Loading %s...' % cat_name)
            try:
                films = _as.get_hqporner_movies(cat_url, page=page)
                from resources.lib.afdb_router import _verify_stream_sources
                films = _verify_stream_sources(
                    films, lambda f: _as.get_hqporner_movie_detail(f['slug'], f['url']))
            finally:
                dlg.close()
            if not films:
                xbmcgui.Dialog().notification('Starfleet', 'No movies found for %s' % cat_name,
                                              xbmcgui.NOTIFICATION_INFO)
                return

            try:
                from resources.lib import watch_history as _wh
            except Exception:
                _wh = None
            items = []
            for f in films:
                it = dict(f)
                it.setdefault('overview', '')
                it.setdefault('fanart', f.get('thumb', ''))
                if _wh is not None and it.get('slug'):
                    try:
                        watched, _resume, pct = _wh.get_progress('hqp:%s' % it['slug'])
                        it['watched'] = watched
                        it['progress_pct'] = pct
                    except Exception:
                        pass
                items.append(it)

            def _on_play(film):
                import threading as _t
                slug     = film.get('slug', '')
                film_url = film.get('url', '')
                title    = film.get('title', '')
                def _play(s=slug, u=film_url, t=title):
                    try:
                        from resources.lib.afdb_router import adult_hqp_play_direct
                        adult_hqp_play_direct(s, u, t)
                    except Exception as exc:
                        xbmc.log('[Starfleet/Home] hqp direct play error: %s' % exc, xbmc.LOGERROR)
                _t.Thread(target=_play, daemon=True).start()

            def _on_more():
                win.close()
                self._open_adult_hqp_movies(cat_url, cat_name, page + 1)

            win = CategoryListWindow(
                'Starfleet-CategoryList.xml',
                xbmcaddon.Addon('plugin.video.starfleet').getAddonInfo('path'),
                'Default', '1080i',
                items=items,
                breadcrumb='HQ Porner — %s' % cat_name,
                subheader='%d titles  ·  page %d' % (len(items), page),
                media_type='movie',
                on_play=_on_play,
                on_more=_on_more,
                on_info=lambda film: self._open_adult_info(film, play_fn=_on_play),
            )
            win.doModal()
            del win
        except Exception as e:
            xbmc.log('[Starfleet/Home] _open_adult_hqp_movies: %s' % e, xbmc.LOGERROR)
            import traceback
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

    def _nav(self, action):
        # Guard: ignore rapid repeated clicks while a nav is in progress.
        if self._navigating:
            return
        self._navigating = True
        # Signal background threads to stop FIRST, before any other work —
        # confirmed live that run_home.py's _push_when_ready background
        # thread (pushes freshly-fetched TMDB/Sports data into this window
        # once its initial load finishes) has a real, narrow race: it checks
        # this same event before touching the window, but there's a gap
        # between that check and its actual getControl()/_apply_context()
        # call. If a nav click landed in that exact gap, _apply_context ran
        # against a window already mid-close and threw "Non-Existent Control
        # 100" — seen in the field right before a nav transition otherwise
        # failed, matching reports that it "works on retry." Setting this
        # as early as possible (before nav.lock I/O, before logging) shrinks
        # that window as much as this side can control.
        if self._close_event:
            self._close_event.set()
        xbmc.log('[Starfleet/Home] nav → %s' % action, xbmc.LOGINFO)
        self.pending_nav = action
        # Write nav.lock BEFORE closing so dispatcher's main_menu (fired by
        # Kodi/the skin re-querying the addon root in the background during
        # this transition) knows a nav is in progress and doesn't relaunch
        # Home on top of it.
        try:
            import xbmcvfs as _xbmcvfs, os as _os
            _dd = _xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.starfleet/')
            open(_os.path.join(_dd, 'nav.lock'), 'w').write(action)
        except Exception:
            pass
        self.close()
        # Single direct ActivateWindow straight to the target category.
        #
        # A previous two-step design (ActivateWindow to the bare root, wait,
        # then Container.Update into the category) was tried specifically to
        # preserve Back-button history — jumping straight to ?action=X makes
        # that URL the base of this window's own back-history, so Back from
        # X exits Kodi's addon context entirely instead of returning to Home.
        # That two-step approach was confirmed live (Firestick, 2026-07-23)
        # to fail outright under real conditions: ActivateWindow to the empty
        # root can get silently refused ("Activate of window '10025' refused
        # because there are active modal dialogs"), and even when it lands,
        # the follow-up Container.Update to the real category can silently
        # no-op, leaving the user stuck on a permanently empty Videos window
        # with no error and no way back into the addon short of relaunching
        # it. A working category page with imperfect Back behavior beats a
        # perfectly-historied page that never loads.
        import threading as _threading
        def _wait_for_busy_dialog():
            # Confirmed live: this only checking the two named busydialog
            # IDs wasn't enough — "Activate of window refused" kept
            # recurring even with this wait in place, right after a video
            # player closed (leftover OSD/notification/etc., not a
            # busydialog specifically). System.HasModalDialog is Kodi's own
            # general-purpose "is ANY modal dialog on top" check, not
            # limited to a fixed list of window IDs — use that instead.
            _waited = 0
            while _waited < 6000 and (
                xbmc.getCondVisibility('Window.IsActive(busydialog)') or
                xbmc.getCondVisibility('Window.IsActive(busydialognocancel)') or
                xbmc.getCondVisibility('System.HasModalDialog')
            ):
                xbmc.sleep(100)
                _waited += 100
        def _fire_nav(a=action):
            try:
                _wait_for_busy_dialog()
                xbmc.sleep(200)

                # REVERTED (v2.3.240 -> v2.3.241): tried a two-step nav here
                # (bare root, then Container.Update into the category) to fix
                # Back exiting the addon from a top-level category. Confirmed
                # live within hours of shipping: Container.Update onto the
                # target action was silently not landing on EVERY attempt
                # (Movies, Sports — not an occasional race), leaving the
                # container stuck on the empty bare root with no working
                # retry — i.e. clicking Movies/TV/Sports/etc from Home simply
                # stopped working at all. That's the exact failure mode this
                # two-step design was already reverted for once before
                # (2026-07-23); this attempt only fixed the OTHER failure mode
                # (a refused root ActivateWindow), not this one. Back on a
                # working category beats a correctly-historied one that
                # doesn't load — reverted to the single direct jump.
                xbmc.executebuiltin(
                    'ActivateWindow(Videos,plugin://plugin.video.starfleet/?action=%s)' % a
                )
                # ActivateWindow doesn't give Python any success/failure
                # signal directly — "refused because there are active modal
                # dialogs" only ever shows up as a Kodi-side log line, never
                # an exception here. Confirmed live it can still get refused
                # even after the wait above (a NEW dialog can appear in the
                # gap between the check and this call). Verify it actually
                # landed on WINDOW_VIDEO_NAV (10025, the id named in that
                # exact log message) and retry once if not, rather than
                # silently leaving the user stuck on Home with no feedback.
                xbmc.sleep(400)
                _landed = xbmcgui.getCurrentWindowId() == 10025
                if not _landed:
                    xbmc.log('[Starfleet/Home] nav → %s: ActivateWindow did not land '
                              '(likely refused by a modal dialog) — retrying once' % a,
                              xbmc.LOGWARNING)
                    _wait_for_busy_dialog()
                    xbmc.sleep(200)
                    xbmc.executebuiltin(
                        'ActivateWindow(Videos,plugin://plugin.video.starfleet/?action=%s)' % a
                    )
                    xbmc.sleep(400)
                    _landed = xbmcgui.getCurrentWindowId() == 10025

                # nav.lock has done its job (stopped a stray root-relaunch
                # during the transition above); remove it so a genuine later
                # Back-to-root visit is treated as one by dispatcher.
                try:
                    import xbmcvfs as _xv, os as _o
                    _dd = _xv.translatePath('special://userdata/addon_data/plugin.video.starfleet/')
                    _o.remove(_o.join(_dd, 'nav.lock'))
                except Exception:
                    pass

                if not _landed:
                    # Both attempts refused — this Home window already closed
                    # itself before we ever got here, so at this point NOTHING
                    # is showing (not the target category, not Home). Reported
                    # live: this is exactly what needed a full addon
                    # relaunch to recover from — clicking anything further did
                    # nothing at all, because the retry above never verified
                    # itself, so no code path noticed the failure or did
                    # anything about it. Relaunch Home directly (the same
                    # RunScript call dispatcher.py's main_menu uses) rather
                    # than leave the user on a blank window — a fresh Home
                    # object also means a fresh _navigating flag, so this
                    # doesn't need a separate reset of that on its own.
                    xbmc.log('[Starfleet/Home] nav → %s: failed twice — relaunching Home' % a,
                              xbmc.LOGERROR)
                    try:
                        import os as _os2
                        _addon_path = xbmcaddon.Addon('plugin.video.starfleet').getAddonInfo('path')
                        _run_script = _os2.path.join(_addon_path, 'resources', 'lib', 'gui', 'run_home.py')
                        xbmc.executebuiltin('RunScript(%s)' % _run_script)
                    except Exception as _re:
                        xbmc.log('[Starfleet/Home] recovery relaunch failed: %s' % _re, xbmc.LOGERROR)
            except Exception as e:
                xbmc.log('[Starfleet/Home] _fire_nav exception for action=%s: %s' % (a, e), xbmc.LOGERROR)
                import traceback
                xbmc.log(traceback.format_exc(), xbmc.LOGERROR)
        # Non-daemon so run_home.py's main() waits for this thread before exiting —
        # daemon threads are killed when the main thread returns, which would prevent
        # ActivateWindow from ever firing.
        _threading.Thread(target=_fire_nav, daemon=False).start()
