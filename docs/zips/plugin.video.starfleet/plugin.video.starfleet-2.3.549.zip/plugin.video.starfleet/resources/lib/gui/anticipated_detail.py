"""
Starfleet Detail Window — rich single-item detail screen (poster, cast
strip with character names, plot + metadata, Play/Trailer/Content
Advisory/Favorite buttons), opened in-process via doModal() the same way
CategoryListWindow is.

Despite the "Anticipated" name (its original use was Home's own "Upcoming"
widget carousel specifically), this is the general-purpose movie/TV/adult
detail screen used throughout home.py — every browsing list's own
on_info callback (Trending/Favorites/Search/Genre/etc, see the many
`on_info=lambda film: self._open_anticipated_detail(...)` call sites)
opens this same window. Previously those clicks routed to the native
meta_movie_detail/meta_tv_show browse page (cast shown as separate
navigable folders, trailer as a separate playable row); this replaces
that with a single screen matching Kodi's own native Info dialog layout.
"""
import os
import datetime
import xbmc
import xbmcgui
import xbmcaddon
from resources.lib.gui import progress_dialog as _pdlg

_ID_CAST     = (4601, 4602, 4603, 4604, 4605)
_ID_BTN_PLAY = 470
_ID_BTN_TRAILER = 471
_ID_BTN_ADVISORY = 473
_ID_BTN_FAV  = 472

_ASSET_FILES = {
    'sf_asset_focus_row': 'sf_focus_row.png',
    'sf_asset_dark_wash': 'sf_dark_wash.png',
}


class AnticipatedDetailWindow(xbmcgui.WindowXML):

    def __init__(self, *args, **kwargs):
        self._tmdb_id    = str(kwargs.pop('tmdb_id', ''))
        self._media_type = kwargs.pop('media_type', 'movie')
        self._detail     = kwargs.pop('detail', {})
        self._on_play        = kwargs.pop('on_play', None)        # callable() -> None
        self._on_trailer      = kwargs.pop('on_trailer', None)     # callable(trailer_url) -> None
        self._on_cast_click   = kwargs.pop('on_cast_click', None)  # callable(actor_name) -> None
        # 'tmdb' (default): Favorites toggle uses favorites.py keyed on
        # (media_type, tmdb_id), and Play is gated on a real release_date/
        # first_air_date having passed — both correct for TMDB-sourced
        # Movies/TV. 'adult': this same rich detail screen reused for
        # Adult's ADE/AFDB-sourced browsing (the "long-press -> Info" this
        # was generalized for) — Adult content has no tmdb_id and nothing
        # here is ever a future release, and favoriting goes through the
        # separate adult_favorites.py store keyed by ade_id (passed in
        # place of tmdb_id — same field, different meaning by mode).
        self._favorites_mode = kwargs.pop('favorites_mode', 'tmdb')
        self._cast_shown = []
        super(AnticipatedDetailWindow, self).__init__(*args, **kwargs)

    # ---------------------------------------------------------------- lifecycle

    def onInit(self):
        try:
            self._set_asset_paths()
            d = self._detail

            self.setProperty('sf_md_title',    d.get('title', ''))
            self.setProperty('sf_md_tagline',  d.get('tagline', ''))
            self.setProperty('sf_md_plot',     d.get('overview', ''))
            self.setProperty('sf_md_poster',   d.get('thumb', ''))
            self.setProperty('sf_md_backdrop', d.get('fanart') or d.get('thumb', ''))

            # TV detail dicts don't have 'director'/'writers' at all (TMDB
            # models a show's creators separately, and doesn't track
            # writers per-show the way it does per-movie) — fall back to
            # 'creators' for the director row on TV, and show N/A rather
            # than a misleading "Unknown" for a field that just doesn't
            # apply to this media type.
            if self._media_type == 'tv':
                creators = d.get('creators') or []
                self.setProperty('sf_md_director', ', '.join(creators) if creators else 'Unknown')
                self.setProperty('sf_md_writer', 'N/A')
            else:
                self.setProperty('sf_md_director', d.get('director') or 'Unknown')
                writers = d.get('writers') or []
                self.setProperty('sf_md_writer', ', '.join(writers) if writers else 'Unknown')
            rating = d.get('rating') or 0
            votes  = d.get('votes') or 0
            self.setProperty('sf_md_rating', ('%.1f (%s votes)' % (rating, votes)) if rating else 'N/A')
            genres = d.get('genres') or []
            self.setProperty('sf_md_genre', ' / '.join(genres) if genres else 'Unknown')
            studios = d.get('studios') or []
            self.setProperty('sf_md_studio', ', '.join(studios[:2]) if studios else 'Unknown')
            premiered = d.get('release_date') or d.get('first_air_date') or ''
            self.setProperty('sf_md_premiered', premiered if premiered else 'TBA')
            self.setProperty('sf_md_status', d.get('status') or 'Unknown')
            self.setProperty('sf_md_type', 'TV Show' if self._media_type == 'tv' else 'Movie')
            # 'mpaa' comes straight from metadata.py's own detail dict —
            # TMDB's own certification, with a same-cache-window SIMKL
            # fallback for titles TMDB has nothing for (see
            # metadata._fill_mpaa_from_simkl) — no separate fetch needed
            # here, so onInit() stays free of network calls like every
            # other field on this screen.
            self.setProperty('sf_md_parental_guide', d.get('mpaa') or 'Not Rated')
            # Content Advisory (itemized IMDb Parents Guide — Sex & Nudity/
            # Violence & Gore/Profanity/etc, see metadata.get_parental_guide)
            # needs a real imdb_id, which Adult-mode detail dicts never
            # carry (ADE/AFDB have no IMDb cross-reference at all, and
            # itemized nudity/violence detail makes no sense for adult
            # content anyway) — hide the button entirely rather than show
            # it and always fail.
            self.setProperty('sf_md_has_advisory', 'true' if d.get('imdb_id') else '')

            cast = (d.get('cast') or [])[:5]
            self._cast_shown = cast
            for i in range(1, 6):
                self.setProperty('sf_md_cast%d_name' % i, '')
                self.setProperty('sf_md_cast%d_photo' % i, '')
                self.setProperty('sf_md_cast%d_char' % i, '')
            for i, actor in enumerate(cast, 1):
                self.setProperty('sf_md_cast%d_name' % i, actor.get('name', ''))
                self.setProperty('sf_md_cast%d_photo' % i, actor.get('photo', ''))
                self.setProperty('sf_md_cast%d_char' % i, actor.get('character', ''))

            released = self._is_released()
            # Per direct request: a TV show's button opens the season
            # picker, not a direct play — labeling it "Play" was misleading
            # about what actually happens on click. Movies are unaffected.
            if not released:
                play_label = 'Not Yet Released'
            elif self._media_type == 'tv':
                play_label = 'Seasons'
            else:
                play_label = 'Play'
            self.setProperty('sf_md_play_label', play_label)
            self.setProperty('sf_md_has_trailer', 'true' if d.get('trailer') else '')

            self._update_fav_label()
            self.setFocusId(_ID_BTN_PLAY if released else (
                _ID_BTN_TRAILER if d.get('trailer') else _ID_BTN_FAV))
        except Exception as e:
            xbmc.log('[Starfleet/AnticipatedDetail] onInit: %s' % e, xbmc.LOGERROR)
            import traceback
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

    def _set_asset_paths(self):
        try:
            addon_path = xbmcaddon.Addon('plugin.video.starfleet').getAddonInfo('path')
            media_dir = os.path.join(addon_path, 'resources', 'skins', 'Default', 'media')
            for prop, filename in _ASSET_FILES.items():
                self.setProperty(prop, os.path.join(media_dir, filename))
        except Exception as e:
            xbmc.log('[Starfleet/AnticipatedDetail] _set_asset_paths: %s' % e, xbmc.LOGERROR)

    def _is_released(self):
        if self._favorites_mode == 'adult':
            # Adult browsing (New Releases/Recently Added/Best Sellers/Full
            # Library/HQ Porner/etc) never lists something not out yet —
            # unlike the TMDB Anticipated widget this screen was built for,
            # there's no "upcoming" concept in these listings at all.
            return True
        # A show's own 'status' field is a second, independent signal —
        # added 2026-08-16 after a real report of a long-running show
        # showing "Not Yet Released" here on one device but not another.
        # 'Returning Series'/'Ended'/'Canceled' can only ever be true for a
        # show that has already aired at least one episode, so trusting it
        # even when release_date/first_air_date is empty (a partially-
        # written or otherwise malformed cached detail dict, plausible
        # given this exact cache is shared across concurrent processes —
        # see run_home.py's own race-condition history this same day) is
        # strictly safer than the old behavior, which treated a missing
        # date field as proof of "not released" with no other signal
        # checked at all.
        status = (self._detail.get('status') or '').strip().lower()
        if status in ('returning series', 'ended', 'canceled', 'cancelled', 'released'):
            return True
        date_str = self._detail.get('release_date') or self._detail.get('first_air_date') or ''
        if not date_str:
            return False
        try:
            rel = datetime.datetime.strptime(date_str[:10], '%Y-%m-%d').date()
            return rel <= datetime.date.today()
        except Exception:
            return False

    def _update_fav_label(self):
        try:
            if self._favorites_mode == 'adult':
                from resources.lib import adult_favorites as _afav
                is_fav = _afav.is_favorite(self._tmdb_id)
            else:
                from resources.lib import favorites as _fav
                is_fav = _fav.is_favorite(self._media_type, self._tmdb_id)
            self.setProperty('sf_md_fav_label', 'Remove Favorite' if is_fav else 'Add to Favorites')
        except Exception as e:
            xbmc.log('[Starfleet/AnticipatedDetail] _update_fav_label: %s' % e, xbmc.LOGWARNING)

    # ---------------------------------------------------------------- events

    def onAction(self, action):
        aid = action.getId()
        if aid in (xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK,
                   xbmcgui.ACTION_STOP, xbmcgui.ACTION_PARENT_DIR):
            self.close()

    def onClick(self, cid):
        try:
            if cid == _ID_BTN_PLAY:
                if self._is_released() and self._on_play:
                    self._on_play()
            elif cid == _ID_BTN_TRAILER:
                trailer = self._detail.get('trailer', '')
                if trailer and self._on_trailer:
                    self._on_trailer(trailer)
            elif cid == _ID_BTN_ADVISORY:
                self._show_content_advisory()
            elif cid == _ID_BTN_FAV:
                self._toggle_favorite()
            elif cid in _ID_CAST and self._on_cast_click:
                idx = _ID_CAST.index(cid)
                if idx < len(self._cast_shown):
                    name = self._cast_shown[idx].get('name', '')
                    if name:
                        self._on_cast_click(name)
        except Exception as e:
            xbmc.log('[Starfleet/AnticipatedDetail] onClick: %s' % e, xbmc.LOGERROR)

    def _show_content_advisory(self):
        """Itemized IMDb Parents Guide (Sex & Nudity/Violence & Gore/
        Profanity/Alcohol-Drugs-Smoking/Frightening & Intense Scenes, each
        with a crowd-voted severity and specific example bullets) — same
        data and formatting as dispatcher.py's meta_content_advisory
        action, just called in-process here since this window never
        leaves Python to begin with (no need for the plugin:// URL round
        trip that action exists for). See metadata.get_parental_guide's
        own docstring for why this needs no API key/login at all."""
        try:
            from resources.lib import metadata as meta
            imdb_id = self._detail.get('imdb_id', '')
            dlg = _pdlg.DialogProgress()
            dlg.create('Starfleet', 'Loading content advisory...')
            try:
                guide = meta.get_parental_guide(imdb_id)
            finally:
                dlg.close()
            if not guide:
                xbmcgui.Dialog().notification('Content Advisory',
                                               'No parents-guide data found for this title',
                                               xbmcgui.NOTIFICATION_INFO, 4000)
                return
            lines = []
            for cat in guide:
                header = cat['name']
                if cat.get('severity'):
                    header += '  —  %s' % cat['severity']
                lines.append(header)
                for it in cat.get('items', []):
                    bullet = '  • ' + it['text']
                    if it.get('spoiler'):
                        bullet += '  [SPOILER]'
                    lines.append(bullet)
                lines.append('')
            xbmcgui.Dialog().textviewer(
                'Content Advisory — %s' % self._detail.get('title', ''),
                '\n'.join(lines).strip()
            )
        except Exception as e:
            xbmc.log('[Starfleet/AnticipatedDetail] _show_content_advisory: %s' % e, xbmc.LOGERROR)

    def _toggle_favorite(self):
        try:
            d = self._detail
            if self._favorites_mode == 'adult':
                from resources.lib import adult_favorites as _afav
                if _afav.is_favorite(self._tmdb_id):
                    _afav.remove(self._tmdb_id)
                else:
                    _afav.add(self._tmdb_id, d.get('title', ''),
                             d.get('thumb', ''), d.get('fanart', ''))
            else:
                from resources.lib import favorites as _fav
                if _fav.is_favorite(self._media_type, self._tmdb_id):
                    _fav.remove(self._media_type, self._tmdb_id)
                else:
                    _fav.add(self._media_type, self._tmdb_id, d.get('title', ''),
                             year=str(d.get('year', '')), imdb_id=d.get('imdb_id', ''),
                             thumb=d.get('thumb', ''), fanart=d.get('fanart', ''))
            self._update_fav_label()
        except Exception as e:
            xbmc.log('[Starfleet/AnticipatedDetail] _toggle_favorite: %s' % e, xbmc.LOGERROR)
