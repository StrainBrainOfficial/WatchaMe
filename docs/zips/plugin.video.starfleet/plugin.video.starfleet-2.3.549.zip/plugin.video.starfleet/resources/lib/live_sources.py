﻿# -*- coding: utf-8 -*-
"""
resources/lib/live_sources.py  — Unified free live TV channel loader

Sources:
  Starfleet / Québecor  — Google DAI session tokens (handled in api.py)
  Samsung TV+      — community M3U  i.mjh.nz/SamsungTVPlus/ca.m3u8   (24h cache)
  Plex FAST        — community M3U  i.mjh.nz/Plex/all.m3u8            (24h cache)
  Pluto TV         — boot.pluto.tv JWT API + channel list              (1h cache)

Performance optimisations applied:
  ✓ Pre-compiled regex patterns (compiled once at import time)
  ✓ Persistent SQLite connection via cache.py (single connect per process)
  ✓ In-memory hot cache for same-session repeated reads
  ✓ Pluto: metadata cached separately from stream URL (JWT not baked into cache)
  ✓ Progress dialog suppressed on cache hits
  ✓ Lazy session creation
  ✓ Compact JSON serialisation (no whitespace)
  ✓ Differentiated timeouts: 4s cache probe, 12s network fetch, 6s stream resolve
"""

import re
import time
import uuid
import threading
import html as _html_mod

import xbmc
import xbmcaddon
import xbmcvfs
import requests

ADDON    = xbmcaddon.Addon('plugin.video.starfleet')
ADDON_ID = ADDON.getAddonInfo('id')

# Initialise cache (done once; subsequent calls are no-ops)
import xbmc as _xbmc
_PROFILE  = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
_CACHE_DB = _PROFILE + '/cache.db'

from resources.lib import cache as _cache
_cache.init(_CACHE_DB)

# ── Pre-compiled M3U regex ────────────────────────────────────────────────────
_RE_NAME  = re.compile(r',(.+)$')
_RE_LOGO  = re.compile(r'tvg-logo="([^"]*)"')
_RE_GROUP = re.compile(r'group-title="([^"]*)"')
_RE_ID    = re.compile(r'tvg-id="([^"]*)"')

# ── Community M3U endpoints ───────────────────────────────────────────────────
# Primary: BuddyChewChew/app-m3u-generator — daily-updated GitHub-hosted M3U
#   Samsung 288 ch, Plex 460 ch — confirmed working 2026-06-27
_BUDDY_BASE = 'https://raw.githubusercontent.com/BuddyChewChew/app-m3u-generator/main/playlists'

SAMSUNG_CA_URLS = [
    _BUDDY_BASE + '/samsungtvplus_ca.m3u',
    'https://raw.githubusercontent.com/iptv-org/iptv/master/streams/ca.m3u',
]
PLEX_ALL_URLS = [
    _BUDDY_BASE + '/plex_ca.m3u',
    'https://raw.githubusercontent.com/iptv-org/iptv/master/streams/ca.m3u',
]
MJH_SAMSUNG_EPG = 'https://i.mjh.nz/SamsungTVPlus/ca.xml'
MJH_PLEX_EPG    = 'https://i.mjh.nz/Plex/ca.xml'

# ── Pluto TV ─────────────────────────────────────────────────────────────────
PLUTO_BOOT = (
    'https://boot.pluto.tv/v4/start'
    '?appName=web&appVersion=9.19.0&deviceVersion=126.0.0'
    '&deviceType=web&deviceMake=chrome&deviceModel=web'
    '&clientID={cid}&clientModelNumber=1.0.0'
    '&serverSideAds=false&marketingRegion=CA'
)
PLUTO_STITCH = (
    'https://cfd-v4-service-channel-stitcher-use1-1.prd.pluto.tv'
    '/v2/stitch/hls/channel/{ch_id}/master.m3u8'
    '?appName=web&appVersion=9.19.0&deviceVersion=126.0.0'
    '&deviceType=web&deviceMake=chrome&deviceModel=web'
    '&clientID={cid}&clientModelNumber=1.0.0'
    '&country=CA&marketingRegion=CA&serverSideAds=false&jwt={jwt}'
)

HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/126.0.0.0 Safari/537.36'
    ),
    'Accept': 'application/json, text/plain, */*',
    'Accept-Language': 'en-CA,en;q=0.9,fr-CA;q=0.8',
}

# ── HTTP session (lazy, thread-safe) ─────────────────────────────────────────
_session     = None
_session_lock = threading.Lock()

def _sess():
    global _session
    if _session is None:
        with _session_lock:
            if _session is None:
                s = requests.Session()
                s.headers.update(HEADERS)
                a = requests.adapters.HTTPAdapter(
                    pool_connections=4, pool_maxsize=10,
                    max_retries=requests.adapters.Retry(total=2, backoff_factor=0.3)
                )
                s.mount('https://', a)
                _session = s
    return _session


# ── M3U parser (optimised) ────────────────────────────────────────────────────

def _parse_m3u(text, source_label):
    channels = []
    lines    = text.splitlines()
    n        = len(lines)
    i        = 0
    while i < n:
        line = lines[i]
        if line.startswith('#EXTINF:'):
            m_name  = _RE_NAME.search(line)
            m_logo  = _RE_LOGO.search(line)
            m_group = _RE_GROUP.search(line)
            m_id    = _RE_ID.search(line)

            name  = m_name.group(1).strip()  if m_name  else 'Unknown'
            logo  = m_logo.group(1)          if m_logo  else ''
            group = m_group.group(1)         if m_group else source_label
            ch_id = m_id.group(1)            if m_id    else name

            # Next non-comment line is the stream URL
            i += 1
            while i < n and lines[i].startswith('#'):
                i += 1
            url = lines[i].strip() if i < n else ''

            if url and not url.startswith('#') and url.startswith('http'):
                channels.append({
                    'id':         ch_id,
                    'title':      name,
                    'group':      group,
                    'source':     source_label,
                    'thumbnail':  logo,
                    'stream_url': url,
                })
        i += 1
    return channels


# ── Samsung TV+ ───────────────────────────────────────────────────────────────

def get_samsung_channels():
    cached = _cache.get('samsung_ca')
    if cached is not None:
        return cached

    for url in SAMSUNG_CA_URLS:
        try:
            r = _sess().get(url, timeout=12)
            if r.status_code == 200 and '#EXTINF' in r.text:
                channels = _parse_m3u(r.text, 'Samsung TV+')
                if channels:
                    _cache.set('samsung_ca', channels, 24 * 3600)
                    xbmc.log('[Starfleet] Samsung: %d channels' % len(channels), xbmc.LOGINFO)
                    return channels
        except Exception as e:
            xbmc.log('[Starfleet] Samsung error (%s): %s' % (url, e), xbmc.LOGERROR)
    xbmc.log('[Starfleet] Samsung TV+: all M3U sources unavailable', xbmc.LOGWARNING)
    return []


def get_samsung_epg_url():
    return MJH_SAMSUNG_EPG


# ── Plex FAST ─────────────────────────────────────────────────────────────────

def get_plex_channels():
    cached = _cache.get('plex_all')
    if cached is not None:
        return cached

    for url in PLEX_ALL_URLS:
        try:
            r = _sess().get(url, timeout=12)
            if r.status_code == 200 and '#EXTINF' in r.text:
                channels = _parse_m3u(r.text, 'Plex')
                if channels:
                    _cache.set('plex_all', channels, 24 * 3600)
                    xbmc.log('[Starfleet] Plex: %d channels' % len(channels), xbmc.LOGINFO)
                    return channels
        except Exception as e:
            xbmc.log('[Starfleet] Plex error (%s): %s' % (url, e), xbmc.LOGERROR)
    xbmc.log('[Starfleet] Plex FAST: all M3U sources unavailable', xbmc.LOGWARNING)
    return []


def get_plex_epg_url():
    return MJH_PLEX_EPG


# ── Pluto TV ──────────────────────────────────────────────────────────────────

def _get_pluto_cid():
    cached = _cache.get('pluto_cid')
    if cached:
        return cached
    cid = str(uuid.uuid4())
    _cache.set('pluto_cid', cid, 365 * 24 * 3600)
    return cid


PLUTO_CHANNELS_URL = 'https://api.pluto.tv/v2/channels.json'


def _boot_pluto():
    """
    Fetch Pluto boot response to obtain JWT session token.
    Returns (jwt, []) — channel list is now fetched separately.
    Caches JWT independently.
    """
    cid = _get_pluto_cid()
    try:
        r = _sess().get(PLUTO_BOOT.format(cid=cid), timeout=12)
        r.raise_for_status()
        data = r.json()

        jwt = (data.get('sessionToken') or
               data.get('stitcherParams', {}).get('jwt', ''))
        if jwt:
            _cache.set('pluto_jwt', jwt, 20 * 3600)
        return jwt, []
    except Exception as e:
        xbmc.log('[Starfleet] Pluto boot error: %s' % e, xbmc.LOGERROR)
        return None, []


def _fetch_pluto_channel_list():
    """
    Fetch the Pluto TV channel list from the v2 JSON API.
    Returns list of channel dicts or [] on failure.
    The boot EPG field now only returns the current/starting channel;
    the dedicated channel list endpoint returns all ~200 channels.
    """
    try:
        r = _sess().get(PLUTO_CHANNELS_URL, timeout=12)
        r.raise_for_status()
        raw = r.json()
        meta = []
        for ch in raw:
            ch_id = ch.get('_id') or ch.get('id', '')
            name  = ch.get('name') or ch.get('title', '')
            if not ch_id or not name:
                continue
            # Logo: v2 API uses featuredImage or thumbnail dict
            logo = (
                (ch.get('featuredImage') or {}).get('path', '') or
                (ch.get('thumbnail') or {}).get('path', '') or
                ''
            )
            group = ch.get('category') or ch.get('genre', 'General')
            meta.append({
                'id':        ch_id,
                'title':     name,
                'group':     group,
                'thumbnail': logo,
                'source':    'Pluto TV',
            })
        xbmc.log('[Starfleet] Pluto: %d channels from v2 API' % len(meta), xbmc.LOGINFO)
        return meta
    except Exception as e:
        xbmc.log('[Starfleet] Pluto channel list error: %s' % e, xbmc.LOGERROR)
        return []


def get_pluto_channels():
    """
    Return Pluto channel metadata. Stream URLs built at play time using
    current JWT (not baked into cache), so stale JWT only breaks playback
    not the channel listing.
    """
    meta = _cache.get('pluto_meta')
    if meta is None:
        meta = _fetch_pluto_channel_list()
        if not meta:
            return []
        _cache.set('pluto_meta', meta, 6 * 3600)

    # Attach stream URLs using current (possibly cached) JWT
    cid = _get_pluto_cid()
    jwt = _cache.get('pluto_jwt')
    if not jwt:
        jwt, _ = _boot_pluto()

    channels = []
    for ch in meta:
        stream = PLUTO_STITCH.format(ch_id=ch['id'], cid=cid, jwt=jwt or '') if jwt else ''
        channels.append(dict(ch, stream_url=stream))
    return channels


def get_pluto_stream(channel_id):
    """Build a fresh Pluto stream URL — called at play time."""
    cid = _get_pluto_cid()
    jwt = _cache.get('pluto_jwt')
    if not jwt:
        jwt, _ = _boot_pluto()
    if not jwt:
        return None
    return PLUTO_STITCH.format(ch_id=channel_id, cid=cid, jwt=jwt)


def refresh_pluto():
    _cache.delete(['pluto_jwt', 'pluto_meta', 'pluto_cid'])
    return get_pluto_channels()


def refresh_pluto_channels():
    """Alias kept for backwards compatibility."""
    return refresh_pluto()


# ── OnHockey.tv Live Channels (NHL Network + other hockey TV) ────────────────

_ONHOCKEY_BASE = 'https://onhockey.tv'

# Paths to try for the live-channels section of the site
_ONHOCKEY_LIVE_PATHS = ['/nhl-network', '/live', '/channels', '/live-tv', '/network']

# Regex: find offsite stream/embed links on an onhockey.tv live channel page
_RE_OHK_IFRAME = re.compile(
    r'<iframe[^>]+src="(https?://(?!onhockey\.tv)[^"]{10,300})"',
    re.IGNORECASE
)
_RE_OHK_STREAM = re.compile(
    r'(?:src|href|file|source)\s*[:=]\s*["\']?(https?://[^"\'>\s]{15,300}\.m3u8[^"\'>\s]*)',
    re.IGNORECASE
)
_RE_OHK_CHAN_LINK = re.compile(
    r'<a[^>]+href="(https?://onhockey\.tv/([^"#\s]{3,80}))"[^>]*>\s*([^<]{3,80}?)\s*</a>',
    re.IGNORECASE
)

_LIVE_CHAN_SKIP = {
    'home', 'schedule', 'scores', 'standings', 'news', 'about', 'contact',
    'privacy', 'faq', 'login', 'register', 'reddit', 'discord', 'nhl', 'ahl',
}


def _onhockey_scrape_stream(page_url):
    """Fetch an onhockey.tv channel page and return the first usable stream URL."""
    try:
        r = requests.get(page_url, timeout=12, headers={
            'User-Agent': HEADERS['User-Agent'],
            'Referer': _ONHOCKEY_BASE + '/',
        })
        if r.status_code >= 400:
            return None
        html = r.text
    except Exception:
        return None

    # Priority 1: direct HLS .m3u8 in JS/JSON
    m = _RE_OHK_STREAM.search(html)
    if m:
        return m.group(1).strip()

    # Priority 2: iframe src (player embed)
    m = _RE_OHK_IFRAME.search(html)
    if m:
        return m.group(1).strip()

    return None


def get_onhockey_live_channels():
    """
    Scrape onhockey.tv for live TV channel streams (NHL Network, etc.).
    Returns list of channel dicts compatible with the unified live TV system.
    """
    ck = 'onhockey_live_ch'
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    channels = []

    # Strategy 1: try dedicated live-TV section paths
    html = None
    for path in _ONHOCKEY_LIVE_PATHS:
        try:
            r = requests.get(_ONHOCKEY_BASE + path, timeout=10, headers={
                'User-Agent': HEADERS['User-Agent'],
                'Referer': 'https://www.google.com/',
            })
            if r.status_code < 400 and len(r.text) > 500:
                html = r.text
                break
        except Exception:
            pass

    if html:
        # Collect all internal channel links from the live page
        seen = set()
        for m in _RE_OHK_CHAN_LINK.finditer(html):
            href, slug, label = m.group(1).strip(), m.group(2).strip('/'), m.group(3).strip()
            if not label or slug.split('/')[0].lower() in _LIVE_CHAN_SKIP:
                continue
            if href in seen:
                continue
            seen.add(href)
            stream = _onhockey_scrape_stream(href)
            if stream:
                channels.append({
                    'id':         'onhockey_' + re.sub(r'\W+', '_', slug),
                    'title':      label,
                    'group':      'Hockey',
                    'source':     'OnHockey.tv',
                    'thumbnail':  '',
                    'stream_url': stream,
                })

    # Strategy 2: always try the NHL Network page directly if not already found
    already_have_nhl_net = any(
        c['title'].lower().replace(' ', '') in {'nhlnetwork', 'nhlnet'}
        for c in channels
    )
    if not already_have_nhl_net:
        # Try onhockey.tv's dedicated NHL Network paths first
        for path in ('/nhl-network', '/nhlnetwork', '/nhl-network-live', '/channels/nhl-network'):
            stream = _onhockey_scrape_stream(_ONHOCKEY_BASE + path)
            if stream:
                channels.append({
                    'id':         'onhockey_nhl_network',
                    'title':      'NHL Network',
                    'group':      'Hockey',
                    'source':     'OnHockey.tv',
                    'thumbnail':  'https://upload.wikimedia.org/wikipedia/en/thumb/1/1f/NHL_Network_logo.svg/200px-NHL_Network_logo.svg.png',
                    'stream_url': stream,
                })
                break
        # onhockey.tv's own pages now gate the real player behind a nested
        # same-domain iframe (welcome.html / daddylive.php?channel=663) that a
        # single-page regex scrape can't follow — confirmed live: neither the
        # dedicated NHL Network page nor the old daddylive-wrapper page expose
        # an .m3u8 or cross-domain iframe src anymore. Resolve directly via the
        # same daddylive.mov channel-id resolver used elsewhere (tvnow247 has
        # already confirmed id 663 = "NHL Network USA" on that source) instead
        # of depending on onhockey.tv's fragile wrapper page.
        if not any(c['id'] == 'onhockey_nhl_network' for c in channels):
            try:
                from resources.lib import sports_sources as _ss
                fallback = _ss._dlchan_stream_url('663', channel_name='NHL Network USA')
            except Exception:
                fallback = None
            if fallback:
                channels.append({
                    'id':         'onhockey_nhl_network',
                    'title':      'NHL Network',
                    'group':      'Hockey',
                    'source':     'DaddyLive',
                    'thumbnail':  'https://upload.wikimedia.org/wikipedia/en/thumb/1/1f/NHL_Network_logo.svg/200px-NHL_Network_logo.svg.png',
                    'stream_url': fallback,
                })

    xbmc.log('[Starfleet] OnHockey.tv live channels: %d' % len(channels), xbmc.LOGINFO)
    _cache.set(ck, channels, 30 * 60)
    return channels


# ── Radio-Canada / ICI Tou.tv Live Channels ──────────────────────────────────

# Official Akamaized HLS streams for Radio-Canada's free OTA channels.
# ICI Tele main feed moved to rcavlive-dai subdomain (iptv-org confirmed 2026).
# ICI RDI slug changed from xcanrdifr → xcanrdi.
# Noovo.ca shut down May 2026 (moved to Crave) — live stream removed.
_RCAV_BASE     = 'https://rcavlive.akamaized.net/hls/live'
_RCAV_DAI_BASE = 'https://rcavlive-dai.akamaized.net/hls/live'

_TOUTV_LIVE_CHANNELS = [
    {
        'id': 'ici-tele',
        'title': 'ICI Radio-Canada Télé',
        'group': 'Tou.tv / Radio-Canada',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/thumb/2/2a/ICI_Radio-Canada_T%C3%A9l%C3%A9.png/200px-ICI_Radio-Canada_T%C3%A9l%C3%A9.png',
        'stream_url': _RCAV_DAI_BASE + '/696614/cancbftprem/master.m3u8',
    },
    {
        'id': 'ici-rdi',
        'title': 'ICI RDI',
        'group': 'Tou.tv / Radio-Canada',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/thumb/5/55/Logo_ICIRDI.png/200px-Logo_ICIRDI.png',
        'stream_url': _RCAV_DAI_BASE + '/704025/xcanrdi/master.m3u8',
    },
    {
        'id': 'ici-artv',
        'title': 'ICI Artv',
        'group': 'Tou.tv / Radio-Canada',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/thumb/6/6c/ICI_Artv_Logo.png/200px-ICI_Artv_Logo.png',
        'stream_url': _RCAV_BASE + '/704026/xcanartvfr/master.m3u8',
    },
    {
        'id': 'ici-explora',
        'title': 'ICI Explora',
        'group': 'Tou.tv / Radio-Canada',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/thumb/2/28/ICI_Explora_logo_2014.png/200px-ICI_Explora_logo_2014.png',
        'stream_url': _RCAV_BASE + '/704027/xcanexplorafr/master.m3u8',
    },
    {
        'id': 'ici-tele-reg-mtl',
        'title': 'ICI Télé (Montréal)',
        'group': 'Tou.tv / Radio-Canada',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/thumb/2/2a/ICI_Radio-Canada_T%C3%A9l%C3%A9.png/200px-ICI_Radio-Canada_T%C3%A9l%C3%A9.png',
        'stream_url': 'https://amdici.akamaized.net/hls/live/873426/ICI-Live-Stream/master.m3u8',
    },
    {
        'id': 'ici-tele-reg-qc',
        'title': 'ICI Télé (Québec régional)',
        'group': 'Tou.tv / Radio-Canada',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/thumb/2/2a/ICI_Radio-Canada_T%C3%A9l%C3%A9.png/200px-ICI_Radio-Canada_T%C3%A9l%C3%A9.png',
        'stream_url': _RCAV_BASE + '/704052/xquebtelefr/master.m3u8',
    },
]


def get_toutv_live_channels():
    """Return Radio-Canada / ICI Tou.tv live channel list (static HLS streams)."""
    results = []
    for ch in _TOUTV_LIVE_CHANNELS:
        results.append(dict(ch, source='Tou.tv'))
    return results


# ── Free Worldwide News & Channels ───────────────────────────────────────────

_NEWS_CHANNELS = [
    # ── Global News ──────────────────────────────────────────────────────────
    {
        'id': 'aljazeera-en', 'title': 'Al Jazeera English', 'group': 'News',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/en/thumb/f/f2/AJE_Logo.svg/200px-AJE_Logo.svg.png',
        'stream_url': 'https://live-hls-web-aje.getaj.net/AJE/index.m3u8',
    },
    {
        'id': 'france24-en', 'title': 'France 24 English', 'group': 'News',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/thumb/b/b8/France_24_logo.svg/200px-France_24_logo.svg.png',
        'stream_url': 'https://f24hls-i.akamaihd.net/hls/live/221147/F24_EN_HI_HLS/master.m3u8',
    },
    {
        'id': 'dw-news', 'title': 'DW News (English)', 'group': 'News',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/thumb/7/75/Deutsche_Welle_symbol_2012.svg/200px-Deutsche_Welle_symbol_2012.svg.png',
        'stream_url': 'https://dwamdstream104.akamaized.net/hls/live/2015530/dwstream104/index.m3u8',
    },
    {
        'id': 'france24-fr', 'title': 'France 24 Français', 'group': 'News',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/thumb/b/b8/France_24_logo.svg/200px-France_24_logo.svg.png',
        'stream_url': 'https://f24hls-i.akamaihd.net/hls/live/221143/F24_FR_HI_HLS/master.m3u8',
    },
    {
        'id': 'france24-ar', 'title': 'France 24 Arabic', 'group': 'News',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/thumb/b/b8/France_24_logo.svg/200px-France_24_logo.svg.png',
        'stream_url': 'https://f24hls-i.akamaihd.net/hls/live/221149/F24_AR_HI_HLS/master.m3u8',
    },
    {
        'id': 'dw-arabic', 'title': 'DW Arabic', 'group': 'News',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/thumb/7/75/Deutsche_Welle_symbol_2012.svg/200px-Deutsche_Welle_symbol_2012.svg.png',
        'stream_url': 'https://dwamdstream106.akamaized.net/hls/live/2015534/dwstream106/index.m3u8',
    },
    {
        'id': 'dw-spanish', 'title': 'DW Español', 'group': 'News',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/thumb/7/75/Deutsche_Welle_symbol_2012.svg/200px-Deutsche_Welle_symbol_2012.svg.png',
        'stream_url': 'https://dwamdstream108.akamaized.net/hls/live/2015536/dwstream108/index.m3u8',
    },
    {
        'id': 'nasa-tv', 'title': 'NASA TV', 'group': 'Science & Space',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/e5/NASA_logo.svg/200px-NASA_logo.svg.png',
        'stream_url': 'https://ntv1.akamaized.net/hls/live/2014075/NASA-NTV1-HLS/master.m3u8',
    },
    {
        'id': 'bloomberg-us', 'title': 'Bloomberg Television', 'group': 'Business News',
        'thumbnail': 'https://assets.bbhub.io/company/sites/51/2019/08/bloomberg-square-logo.png',
        'stream_url': 'https://bloomberg-bloomberg.d.pluto.tv/hls/live/2038009/bloomberg/master.m3u8',
    },
    {
        'id': 'cgtn-en', 'title': 'CGTN (China Global TV)', 'group': 'News',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/thumb/b/b3/CGTN_logo_2016.svg/200px-CGTN_logo_2016.svg.png',
        'stream_url': 'https://livenews.cgtn.com/media_live/W010096/playlist.m3u8',
    },
    {
        'id': 'abc-australia', 'title': 'ABC News Australia', 'group': 'News',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a1/ABC_News_%28Australia%29_logo_2014.svg/200px-ABC_News_%28Australia%29_logo_2014.svg.png',
        'stream_url': 'https://abcnewslive.akamaized.net/hls/live/2038056/abcnews/master.m3u8',
    },
    {
        'id': 'euronews-en', 'title': 'Euronews English', 'group': 'News',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/0/0e/Euronews_logo.svg',
        'stream_url': 'https://euronews-euronews-1-gb.samsung.wurl.com/manifest/playlist.m3u8',
    },
    {
        'id': 'ntn24', 'title': 'NTN24 (Latinoamérica)', 'group': 'News',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/thumb/0/07/NTN24.svg/200px-NTN24.svg.png',
        'stream_url': 'https://ntn24web.ultrastream.tv/ntn24/smil:live.smil/playlist.m3u8',
    },
    # ── Free Entertainment ────────────────────────────────────────────────────
    {
        'id': 'pluto-tv-movies', 'title': 'Pluto TV Movies', 'group': 'Movies',
        'thumbnail': 'https://images.pluto.tv/channels/5b2ebbc17f9b1c1e34c71063/colorLogoPNG.png',
        'stream_url': 'https://pluto-tv-movies.d.pluto.tv/hls/live/2038010/pluto-tv-movies/master.m3u8',
    },
    {
        'id': 'classic-tv', 'title': 'Classic TV (Shout! Factory)', 'group': 'Entertainment',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/thumb/d/d3/Shout_Factory_TV_logo.png/200px-Shout_Factory_TV_logo.png',
        'stream_url': 'https://shout-sftvfastprimary.samsung.wurl.com/manifest/playlist.m3u8',
    },
    {
        'id': 'looney-tunes', 'title': 'Boomerang (Classic Cartoons)', 'group': 'Kids',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/thumb/5/59/Boomerang_2015_logo.svg/200px-Boomerang_2015_logo.svg.png',
        'stream_url': 'https://boomerang-fastonly.warnermediacdn.com/hls/live/2023800/boomerang_fastonly/master.m3u8',
    },
    {
        'id': 'bbc-reel', 'title': 'BBC World Service Radio', 'group': 'Radio/Audio',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/41/BBC_Logo_2021.svg/200px-BBC_Logo_2021.svg.png',
        'stream_url': 'https://stream.live.vc.bbcmedia.co.uk/bbc_world_service',
    },
    {
        'id': 'nasa-public', 'title': 'NASA TV Public', 'group': 'Science & Space',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/e5/NASA_logo.svg/200px-NASA_logo.svg.png',
        'stream_url': 'https://ntv2.akamaized.net/hls/live/2014076/NASA-NTV2-HLS/master.m3u8',
    },
]


def get_news_channels():
    """Return hardcoded list of free worldwide news and entertainment channels."""
    results = []
    for ch in _NEWS_CHANNELS:
        results.append(dict(ch, source='Free News'))
    return results


def prewarm_news():
    pass  # static list, no prewarm needed


# ── Free Live Sports (watch.freelivesports.tv) ───────────────────────────────
#
# Investigated live 2026-08-19 per direct request. The site's own Angular
# bundle (unreel-fullscreen) defines a "urfsLiveChannels" service with a
# single real endpoint that returns EVERYTHING at once - no separate EPG
# call, no per-channel session/auth step:
#
#   GET https://ga-prod-api.powr.tv/v2/sites/<siteUid>/live-channels
#
# Confirmed live: 124 real, legitimate FAST channels (Red Bull TV, NASCAR,
# PFL, Sports Illustrated TV, Eurovision Sport, Big 12 Network, beIN Sports
# Xtra, etc.) - not the movie/VOD "channel" categories the site's separate
# on-demand catalogue uses (a different, unrelated endpoint that was
# investigated and correctly ruled out first). Each entry already carries:
#   - a direct, pre-resolved Amagi CDN .m3u8 URL (no session/token step -
#     confirmed live it's playable as-is; a 403 hit while testing from this
#     dev environment was a genuine CloudFront country geo-block, not a
#     URL-construction problem - the bracketed ad-tracking placeholders
#     ([US_PRIVACY], [GDPR], [DEVICE_ID], etc.) are inert if left literal,
#     only used server-side for Amagi's own ad analytics)
#   - a real embedded EPG schedule (epg.entries: title/description/start/
#     stop), unlike every other source in this file, which either has no
#     EPG at all or points at a separate third-party XMLTV feed URL.
_FLS_SITE_ID = '664f9cfe1eb297fa1d65b5bb'
_FLS_API = 'https://ga-prod-api.powr.tv/v2/sites/%s/live-channels' % _FLS_SITE_ID


def _fls_fetch_raw():
    ck = 'free_live_sports_raw_v1'
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        r = requests.get(_FLS_API, headers={
            'User-Agent': ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
                            '(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'),
            'Accept': 'application/json',
        }, timeout=20)
        r.raise_for_status()
        data = r.json()
    except Exception as e:
        xbmc.log('[Starfleet/LiveTV] Free Live Sports fetch error: %s' % e, xbmc.LOGWARNING)
        return []
    _cache.set(ck, data, 24 * 3600 if data else 10 * 60)
    return data


def get_free_live_sports_channels():
    """Real, legitimate FAST channels from watch.freelivesports.tv — see
    module comment above for the investigation. Each returned dict adds an
    'epg_entries' key (raw title/description/start/stop list) on top of the
    usual id/title/group/thumbnail/stream_url shape, consumed by
    pvr_export.py to build a real XMLTV guide from this source's own
    embedded schedule instead of a third-party feed."""
    raw = _fls_fetch_raw()
    results = []
    for ch in raw:
        if ch.get('status') != 'live' or ch.get('accessType') != 'public':
            continue
        url = ch.get('url') or ''
        if not url:
            continue
        thumbs = ch.get('thumbnails') or {}
        thumb = thumbs.get('landscape') or thumbs.get('square') or ch.get('thumbnail') or ''
        results.append({
            'id':          'fls-%s' % ch.get('_id', ''),
            'title':       ch.get('name', 'Unknown Channel'),
            'group':       'Free Live Sports',
            'thumbnail':   thumb,
            'stream_url':  url,
            'source':      'Free Live Sports',
            'epg_entries': (ch.get('epg') or {}).get('entries') or [],
        })
    return results


def prewarm_free_live_sports():
    _fls_fetch_raw()


# ── DLHD / DaddyLive (dlstreams.st) — 24/7 channel directory ─────────────────
#
# Investigated live 2026-08-20 per direct request. dlstreams.st is
# DaddyLive/DLHD's current domain (confirmed by its own site branding and
# public API docs at dlstreams.st/api.php) — the same DaddyLive family
# this addon already has extensive scraper support for elsewhere, just a
# different current mirror. Its clean JSON API (daddyapi.php) needs a
# real, individually-registered API key ("Contact support to get your API
# key") this addon doesn't have and won't fabricate/bypass — so this
# scrapes the site's own public /24-7-channels.php directory page
# instead, same no-key-needed approach already used for every other
# scraped source in this file. Confirmed live: ~900 real channels (ABC
# USA, AMC USA, Animal Planet, international sports channels, and several
# reality-TV live camera feeds — e.g. Big Brother's own 4 individual
# camera angles plus a quadview, all real and currently airing).
#
# Playback: each channel's /watch.php?id=<N> page is just a redirect
# wrapper whose own iframe points at /stream/stream-<N>.php — the exact
# same page structure already reverse-engineered for sports_sources.py's
# livetv902/903 fix (dlstreams.st turned out to be the shared backend
# both places route through): the real master m3u8 is embedded as a plain
# base64 string passed to Clappr.Player({source: window.atob('...')}),
# no JS execution needed. Reuses that fix's own resolver function instead
# of duplicating it, since it's the identical mechanism.
# UPDATE 2026-09-05 — dlstreams.st now 301-redirects everything to dlive.sx
# (confirmed live via a direct raw-socket request bypassing this machine's
# own DNS, which couldn't resolve dlstreams.st at all while dns.google
# could — and independently confirmed by direct user report of the same
# domain). `requests` follows the redirect fine on its own, so this alone
# was likely never a hard failure, but every Referer this file builds from
# the literal `_DLSTREAMS_BASE` string (the channel-list fetch, the
# stream-<id>.php iframe fetch) was still carrying the OLD pre-redirect
# domain instead of the site's actual current one — pointing this at the
# real current domain directly removes that mismatch instead of relying on
# a redirect + a stale Referer to somehow still work. Channel-list scrape
# re-verified live against the new domain directly: real 899-channel
# listing, same page structure, same regex match.
_DLSTREAMS_BASE = 'https://dlive.sx'
_RE_DLSTREAMS_CARD = re.compile(
    r'href="/watch\.php\?id=(\d+)"[^>]*>\s*<div class="card__title">([^<]+)</div>'
)


def _dlstreams_channels_raw():
    ck = 'dlstreams_channels_v1'
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        html_text = requests.get(_DLSTREAMS_BASE + '/24-7-channels.php', headers={
            'User-Agent': ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
                            '(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'),
        }, timeout=20).text
    except Exception as e:
        xbmc.log('[Starfleet/LiveTV] dlstreams channels fetch error: %s' % e, xbmc.LOGWARNING)
        return []
    channels = [{'id': cid, 'name': _html_mod.unescape(name).strip()}
                for cid, name in _RE_DLSTREAMS_CARD.findall(html_text)]
    _cache.set(ck, channels, 24 * 3600 if channels else 10 * 60)
    return channels


def get_dlstreams_channels():
    """Return the dlstreams.st 24/7 channel directory in the usual
    id/title/group/thumbnail/stream_url shape. stream_url is a lazy-resolve
    marker ('dlstreams:<id>') resolved at play time by
    resolve_dlstreams_channel() below — pre-resolving all ~900 channels
    up front just to build a menu listing would be far too slow."""
    raw = _dlstreams_channels_raw()
    return [{
        'id':         'dlstreams-%s' % ch['id'],
        'title':      ch['name'],
        'group':      'DLHD 24/7 Channels',
        'thumbnail':  '',
        'stream_url': 'dlstreams:%s' % ch['id'],
        'source':     'DLHD',
    } for ch in raw]


def resolve_dlstreams_channel(channel_id):
    """Resolve one dlstreams.st channel id to a real playable URL at play
    time — see this module's own comment above for the chain reused here
    (/stream/stream-<id>.php's embedded base64 m3u8, no JS execution)."""
    from resources.lib import sports_sources as _ss
    iframe_url = '%s/stream/stream-%s.php' % (_DLSTREAMS_BASE, channel_id)
    return _ss._livetv902_resolve_dlstreams(iframe_url)


def prewarm_dlstreams():
    _dlstreams_channels_raw()


# Big Brother's own live camera feeds are real entries inside the flat
# ~900-channel DLHD directory above (confirmed live: "Big Brother 28 Live
# Feeds Cam 1-4" + "Quadview") but that directory has zero sub-grouping in
# its own UI (list_live_dlstreams renders every channel in one flat, sorted
# list) — added per direct request for a dedicated, easy-to-find Live TV
# section instead of scrolling ~900 channels to find these 5. Reuses the
# exact same channel ids/resolve path (resolve_dlstreams_channel) as the
# main DLHD directory, just pre-filtered — no new resolver needed.
_RE_BIGBROTHER = re.compile(r'big\s*brother', re.IGNORECASE)


def get_bigbrother_channels():
    return [ch for ch in get_dlstreams_channels() if _RE_BIGBROTHER.search(ch['title'])]


# ── DaddyLive's own "regular TV" channel directory (daddylive.li/api/channels) ─
#
# Country-grouped "Live Channels by Country" used to come entirely from
# daddylive_channels.json — a weekly, ~1200-channel, Playwright-assisted
# scraper run on a separate PC (scraper_daddylive_channels.py). Real gap
# found live 2026-09-05: some channels' own embed pages have moved to a
# JS-obfuscated wrapper the scraper's plain-HTTP chain can't crack anymore,
# and Kodi addons can't bundle/run Playwright at all (no room for a
# downloaded Chromium binary, no native browser automation on the FireTV/
# Android boxes this addon actually runs on) — so a scraper run hitting
# enough of these now produces an empty catalogue outright, and even a
# healthy run's baked-in playable_url only reflects a moment the scraper
# happened to run, already stale by the time anyone clicks play (same
# staleness class documented in router.py's own play_daddylive_catalog()).
#
# Per direct request: this only needs the CHANNEL LIST (name + guessed
# country) to build the browsable menu instantly, live, no scraper
# involved — router.play_daddylive_catalog() already does the actual
# fresh-resolve-at-play-time step, by fuzzy-matching this same title
# against the dlstreams.st/dlive.sx 24/7 directory this file already
# scrapes and resolves correctly (confirmed live: a channel whose own
# daddylive.li embed chain is now broken, "#Vamos Spain", still resolves
# to a real playable stream this way, since dlive.sx's OWN copy of it
# never went through daddylive.li's broken chain at all).
_DL_CHANNELS_URL = 'https://daddylive.li/api/channels'
_DL_CHANNELS_HEADERS = {
    'User-Agent': ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
                    '(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'),
    'Accept': 'application/json, text/plain, */*',
    'Referer': 'https://daddylive.li/',
}

# Same non-sport/adult block list as daddylive_common.py's own _ADULT_BLOCK
# (the scraper's twin of this function) — Adult already has its own,
# separate, dedicated scrapers in this addon; this catalogue is Live TV
# only.
_RE_DL_ADULT = re.compile(
    r'pornhub|xvideos|xhamster|beeg|motherless|naughtyamerica|sexvid|tnaflix|'
    r'realitykings|drtuber|youporn|tube8|pornhd|porntrex|bangbros|brazzers|'
    r'spankbang|eporner|18\+|xxx|adult', re.IGNORECASE)

_DL_COUNTRY_HINTS = [
    (r'\bUSA\b|\bUS\b|\bNY\b', 'US'), (r'\bUK\b|\bBritain\b', 'GB'),
    (r'\bCanada\b|\bCA\b', 'CA'), (r'\bSpain\b|\bES\b', 'ES'),
    (r'\bFrance\b|\bFR\b', 'FR'), (r'\bGermany\b|\bDE\b|\bDeutsch', 'DE'),
    (r'\bItaly\b|\bItalia\b', 'IT'), (r'\bPortugal\b', 'PT'),
    (r'\bBrazil\b|\bBrasil\b', 'BR'), (r'\bMexico\b|\bMX\b', 'MX'),
    (r'\bTurkey\b', 'TR'), (r'\bPoland\b', 'PL'), (r'\bRomania\b', 'RO'),
    (r'\bSerbia\b', 'RS'), (r'\bCroatia\b', 'HR'), (r'\bGreece\b', 'GR'),
    (r'\bNetherlands\b|\bNL\b', 'NL'), (r'\bAustralia\b|\bAU\b', 'AU'),
    (r'\bIndia\b', 'IN'), (r'\bIsrael\b', 'IL'), (r'\bUAE\b', 'AE'),
    (r'\bUkraine\b', 'UA'), (r'\bDenmark\b', 'DK'), (r'\bSweden\b', 'SE'),
    (r'\bNorway\b', 'NO'), (r'\bArgentina\b', 'AR'),
]


def _dl_guess_country(name):
    for pat, code in _DL_COUNTRY_HINTS:
        if re.search(pat, name or '', re.IGNORECASE):
            return code
    return 'Other'


def get_daddylive_channels_by_country():
    """Live daddylive.li channel directory, grouped by guessed country —
    name only, no per-channel resolve (that happens lazily at play time
    via router.play_daddylive_catalog's title-match against dlive.sx).
    Cached 24h, same convention as the DLHD 24/7 directory above."""
    ck = 'dl_channels_by_country_v1'
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        from resources.lib import dns_fallback as _dnsf
        r = _dnsf.get(_DL_CHANNELS_URL, timeout=15, headers=_DL_CHANNELS_HEADERS)
        rows = r.json()
    except Exception as e:
        xbmc.log('[Starfleet/LiveTV] daddylive channels fetch error: %s' % e, xbmc.LOGWARNING)
        rows = []
    grouped = {}
    if isinstance(rows, list):
        for row in rows:
            name = (row.get('channel_name') or '').strip()
            if not name or _RE_DL_ADULT.search(name.lower().replace(' ', '')):
                continue
            grouped.setdefault(_dl_guess_country(name), []).append({
                'title': name, 'logo': '', 'playable_url': '',
            })
    _cache.set(ck, grouped, 24 * 3600 if grouped else 600)
    return grouped


# ── USTVNow — U.S. channel EPG + live stream API ─────────────────────────────
#
# Investigated live 2026-08-20 per direct request. ustvnow.com/tvguide's own
# jQuery page calls a plain, unauthenticated POST endpoint (ustvnow.com/
# epg2) with {dt, tz, tz2, offset, limit} — offset paginates 20 channels
# at a time (limit affects something else, not channel count — confirmed
# live by paginating offset 0/20/40/... instead and seeing different
# channels each time). Confirmed live: 141 real US channels (ABC, NBC,
# CBS, Fox News, A&E, TLC, BYU TV, and many smaller niche/international
# ones), each with a real day's schedule (start/end times, title,
# description) AND a direct playable .m3u8 URL per individual show slot —
# not one static per-channel URL, since this service time-shifts each
# program's own encode rather than serving one persistent live feed.
_USTVNOW_BASE = 'https://ustvnow.com'
_USTVNOW_TZ_OFFSET_MIN = -240  # America/New_York, EDT — see module comment


def _ustvnow_channels_raw():
    ck = 'ustvnow_channels_v1'
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    import datetime as _dt
    today = _dt.date.today().isoformat()
    req_headers = {
        'User-Agent': ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
                        '(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'),
        'Referer': _USTVNOW_BASE + '/tvguide',
        'X-Requested-With': 'XMLHttpRequest',
    }
    channels = []
    offset = 0
    try:
        while offset <= 400:  # safety cap — confirmed live real count is 141
            data = {'dt': today, 'tz': 'America/New_York', 'tz2': str(_USTVNOW_TZ_OFFSET_MIN), 'offset': offset, 'limit': 20}
            r = requests.post(_USTVNOW_BASE + '/epg2', data=data, headers=req_headers, timeout=15)
            batch = r.json()
            if not batch:
                break
            channels.extend(batch)
            offset += 20
    except Exception as e:
        xbmc.log('[Starfleet/LiveTV] ustvnow channels fetch error: %s' % e, xbmc.LOGWARNING)
        if not channels:
            return []
    _cache.set(ck, channels, 3600 if channels else 600)  # 1h — "now playing" changes throughout the day
    return channels


def get_ustvnow_channels():
    """Return the USTVNow channel list in the usual shape. stream_url is a
    lazy-resolve marker ('ustvnow:<link>') resolved at play time by
    resolve_ustvnow_channel() below, since the right URL depends on
    whatever's airing at that exact moment, not whenever the list was
    built."""
    raw = _ustvnow_channels_raw()
    out = []
    for ch in raw:
        link = ch.get('link')
        if not link:
            continue
        icon = ch.get('icon') or ''
        if icon.startswith('//'):
            icon = 'https:' + icon
        elif icon.startswith('/'):
            icon = _USTVNOW_BASE + icon
        out.append({
            'id':         'ustvnow-%s' % (ch.get('id') or link),
            'title':      (ch.get('name') or '').strip(),
            'group':      'USTVNow',
            'thumbnail':  icon,
            'stream_url': 'ustvnow:%s' % link,
            'source':     'USTVNow',
        })
    return out


def resolve_ustvnow_channel(channel_link):
    """Resolve a USTVNow channel to whatever's airing right now — its EPG
    entries are per-timeslot, each with its own direct .m3u8 (see module
    comment above for why), so this picks the show whose start/end window
    contains the current time in the same fixed America/New_York offset
    the schedule itself was requested in, rather than trusting the
    playing device's own local clock/timezone."""
    import datetime as _dt
    now_str = (_dt.datetime.utcnow() + _dt.timedelta(minutes=_USTVNOW_TZ_OFFSET_MIN)).strftime('%H:%M')
    for ch in _ustvnow_channels_raw():
        if ch.get('link') != channel_link:
            continue
        shows = ch.get('shows') or []
        for show in shows:
            if show.get('start', '') <= now_str < show.get('end', '99:99'):
                return show.get('url') or None
        return shows[0].get('url') if shows else None
    return None


def prewarm_ustvnow():
    _ustvnow_channels_raw()


# ── FilmOn — free (non-paywalled) live linear channels ───────────────────────
#
# Investigated live 2026-08-20 from a real browser DevTools capture of
# filmon.com/groups/?with-special=true and filmon.com/group/<alias>. Full
# chain (no key/auth needed for any of it):
#   1. GET /groups/?with-special=true          -> 83 category groups
#   2. GET /group/<alias>                      -> each group's full channel
#      list (id, title, alias, logo, is_free, type) in one response
#   3. POST /ajax/getChannelInfo {channel_id}   -> real signed HD/SD .m3u8
#      URLs in a `streams[]` array, but ONLY once a guest session cookie
#      (ftv_token/PHPSESSID, issued by any normal filmon.com page load) is
#      attached — a fully cookieless POST returns `streams: []`.
#   4. The resulting .m3u8 itself needs a `Referer: https://www.filmon.com/`
#      header on the CDN fetch or it 403s ("Channel id does not match") —
#      confirmed live this does NOT need to be a session-bearing request,
#      just any filmon.com referer, and does NOT need matching cookies.
# Most of FilmOn's catalogue is either subscription-gated (is_free=false,
# e.g. BBC One) or actually VOD/podcast content masquerading as a channel
# (type='vod', e.g. "Expats TV") — confirmed live only 13 channels across
# all 83 groups are genuinely free AND genuinely live linear TV. Small but
# real; added as its own group same as the other sources.
_FILMON_BASE = 'https://www.filmon.com'


def _filmon_session():
    s = requests.Session()
    s.headers.update({
        'User-Agent': ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
                        '(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'),
    })
    try:
        s.get(_FILMON_BASE + '/tvguide/', timeout=12)
    except Exception:
        pass
    return s


def _filmon_channels_raw():
    ck = 'filmon_channels_v1'
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    channels = []
    try:
        s = _filmon_session()
        groups = s.get(_FILMON_BASE + '/groups/?with-special=true',
                        headers={'X-Requested-With': 'XMLHttpRequest'}, timeout=15).json()
        for g in groups:
            alias = g.get('alias')
            if not alias:
                continue
            try:
                gd = s.get('%s/group/%s' % (_FILMON_BASE, alias),
                           headers={'X-Requested-With': 'XMLHttpRequest'}, timeout=15).json()
            except Exception:
                continue
            for c in gd.get('channels', []) or []:
                if not c.get('is_free') or c.get('type') != 'standard':
                    continue
                channels.append({
                    'id':    c.get('id'),
                    'title': c.get('title') or '',
                    'group': g.get('title') or gd.get('title') or 'FilmOn',
                    'logo':  c.get('logo') or '',
                })
    except Exception as e:
        xbmc.log('[Starfleet/LiveTV] filmon channels fetch error: %s' % e, xbmc.LOGWARNING)
    _cache.set(ck, channels, 12 * 3600 if channels else 10 * 60)
    return channels


def get_filmon_channels():
    """Return FilmOn's free live channel list in the usual shape. stream_url
    is a lazy-resolve marker ('filmon:<id>') resolved at play time by
    resolve_filmon_channel() below, since each signed .m3u8 is single-use
    and tied to the session that requested it."""
    raw = _filmon_channels_raw()
    return [{
        'id':         'filmon-%s' % ch['id'],
        'title':      ch['title'],
        'group':      ch['group'],
        'thumbnail':  ch['logo'],
        'stream_url': 'filmon:%s' % ch['id'],
        'source':     'FilmOn',
    } for ch in raw]


def resolve_filmon_channel(channel_id):
    """Resolve one FilmOn channel id to a real playable .m3u8 at play time —
    see this module's own comment above for the session+POST chain."""
    try:
        s = _filmon_session()
        r = s.post(_FILMON_BASE + '/ajax/getChannelInfo', data={'channel_id': channel_id},
                    headers={'Referer': _FILMON_BASE + '/tvguide/', 'X-Requested-With': 'XMLHttpRequest'},
                    timeout=15)
        d = r.json()
        streams = d.get('streams') or []
        if not streams:
            return None
        # prefer the 'high'/HD quality entry, fall back to whatever's first
        chosen = next((st for st in streams if st.get('quality') == 'high'), streams[0])
        url = chosen.get('url')
        if not url:
            return None
        from urllib.parse import quote as _uq
        return '%s|Referer=%s' % (url, _uq(_FILMON_BASE + '/', safe=''))
    except Exception as e:
        xbmc.log('[Starfleet/LiveTV] filmon resolve error: %s' % e, xbmc.LOGWARNING)
        return None


def prewarm_filmon():
    _filmon_channels_raw()


# ── smotru.tv — Russian/international live TV channels ───────────────────────
#
# Investigated live 2026-08-20 per direct request. Real channel directory
# split across 8 category pages (/kategorii/<slug>.html) — confirmed live,
# 239 real channels total (kids/movies/music/news/general/documentary/
# entertainment/sports). Each channel's own page (/<slug>.html) embeds one
# or more mirror iframes pointing at cdntvmedia.com/public/<name>[-hd|-N]
# .php — a SHARED backend also serving several sibling rebrand sites
# (tvix.live, televizo.live, tvline.live, etc, per its own CSP
# frame-ancestors header). That endpoint 403s a plain fetch regardless of
# Referer/Origin — the real gate turned out to be the Sec-Fetch-Dest/Mode/
# Site headers a genuine cross-site iframe load carries (confirmed live:
# adding Sec-Fetch-Dest: iframe / Sec-Fetch-Mode: navigate / Sec-Fetch-Site:
# cross-site flips the same request from 403 to 200), which then returns
# one more nested iframe whose src is a plain playerjs.php?file=<real
# .m3u8 URL> query param — no further JS execution needed.
_SMOTRU_BASE = 'https://smotru.tv'
_SMOTRU_CATEGORIES = {
    'detskie-telekanaly':      'Kids',
    'kinokanaly':              'Movies',
    'muzykalnye-telekanaly':   'Music',
    'novostnye-telekanaly':    'News',
    'obshchestvennye-telekanaly': 'General',
    'poznavatelnye-telekanaly':   'Documentary',
    'razvlekatelnye-telekanaly':  'Entertainment',
    'sportivnye-telekanaly':      'Sports',
}
_RE_SMOTRU_CARD = re.compile(
    r'href="(/[a-z0-9-]+\.html)"[^>]*>\s*<img[^>]+src="([^"]+)"[^>]+alt="([^"]+?)\s*'
    r'смотреть онлайн"',
    re.IGNORECASE
)
_RE_SMOTRU_IFRAME = re.compile(r'<iframe[^>]+src="(https://cdntvmedia\.com/[^"]+)"')
_RE_SMOTRU_FILE_PARAM = re.compile(r'[?&]file=([^"&]+)')
_RE_SMOTRU_GENERATED_FILE = re.compile(r'generatedFile\s*=\s*"([^"]+)"')
_SMOTRU_UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
              '(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36')


def _smotru_channels_raw():
    ck = 'smotru_channels_v1'
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    channels = []
    seen_slugs = set()
    for cat_slug, group_label in _SMOTRU_CATEGORIES.items():
        try:
            html = requests.get('%s/kategorii/%s.html' % (_SMOTRU_BASE, cat_slug),
                             headers={'User-Agent': _SMOTRU_UA}, timeout=15).text
        except Exception as e:
            xbmc.log('[Starfleet/LiveTV] smotru category fetch error (%s): %s' % (cat_slug, e), xbmc.LOGWARNING)
            continue
        for href, img, name in _RE_SMOTRU_CARD.findall(html):
            slug = href.strip('/').rsplit('.', 1)[0]
            if slug in seen_slugs:
                continue
            seen_slugs.add(slug)
            thumb = img if img.startswith('http') else (_SMOTRU_BASE + img)
            channels.append({
                'slug': slug,
                'title': _html_mod.unescape(name).strip(),
                'group': group_label,
                'thumb': thumb,
            })
    _cache.set(ck, channels, 24 * 3600 if channels else 10 * 60)
    return channels


def get_smotru_channels():
    """Return smotru.tv's live channel directory in the usual shape.
    stream_url is a lazy-resolve marker ('smotru:<slug>') resolved at play
    time by resolve_smotru_channel() below — each mirror needs its own
    Sec-Fetch-gated fetch chain, too slow to pre-resolve ~239 channels
    up front just to build a menu listing."""
    raw = _smotru_channels_raw()
    return [{
        'id':         'smotru-%s' % ch['slug'],
        'title':      ch['title'],
        'group':      ch['group'],
        'thumbnail':  ch['thumb'],
        'stream_url': 'smotru:%s' % ch['slug'],
        'source':     'smotru.tv',
    } for ch in raw]


def _smotru_verify_and_tag(m3u8):
    try:
        v = requests.get(m3u8, headers={'User-Agent': _SMOTRU_UA, 'Referer': 'https://cdntvmedia.com/'}, timeout=10)
        if v.status_code == 200 and v.text.lstrip().startswith('#EXTM3U'):
            from urllib.parse import quote as _uq
            return '%s|User-Agent=%s&Referer=%s' % (
                m3u8, _uq(_SMOTRU_UA, safe=''), _uq('https://cdntvmedia.com/', safe=''))
    except Exception:
        pass
    return None


def resolve_smotru_channel(slug):
    """Resolve one smotru.tv channel slug to a real playable .m3u8 at play
    time — see this module's own comment above for the Sec-Fetch-gated
    cdntvmedia.com chain reused here. Two different nested-iframe shapes
    confirmed live: some resolve straight to a '?file=<url>' query param,
    others go one hop deeper to a '?ch=<id>' player page whose own inline
    JS assigns the real (escaped) URL(s) to a plain generatedFile string —
    sometimes two alternate CDN mirrors separated by literal ' or '."""
    channel_url = '%s/%s.html' % (_SMOTRU_BASE, slug)
    try:
        page_html = requests.get(channel_url, headers={'User-Agent': _SMOTRU_UA}, timeout=15).text
    except Exception as e:
        xbmc.log('[Starfleet/LiveTV] smotru page fetch error: %s' % e, xbmc.LOGWARNING)
        return None

    sec_fetch_headers = {
        'User-Agent': _SMOTRU_UA,
        'Referer': channel_url,
        'Sec-Fetch-Dest': 'iframe',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'cross-site',
    }
    from urllib.parse import unquote as _unq

    mirrors = _RE_SMOTRU_IFRAME.findall(page_html)
    for mirror_url in mirrors:
        try:
            r = requests.get(mirror_url, headers=sec_fetch_headers, timeout=10)
            if r.status_code != 200:
                continue

            file_m = _RE_SMOTRU_FILE_PARAM.search(r.text)
            if file_m:
                m3u8 = _unq(file_m.group(1))
                if m3u8.startswith('http'):
                    tagged = _smotru_verify_and_tag(m3u8)
                    if tagged:
                        return tagged
                continue

            # Some channels embed straight from ok.ru instead of cdntvmedia's
            # own delivery — reuse this addon's own already-built OK.ru
            # resolver (sports_router._resolve_okru) rather than duplicating
            # it. Rutube-embedded channels (the other third-party platform
            # seen live here) have no existing resolver anywhere in this
            # codebase yet and are left unresolved (returns None below) —
            # not worth a speculative new platform integration on top of
            # everything else this round.
            okru_m = re.search(r'<iframe[^>]+src="(https://ok\.ru/videoembed/\d+[^"]*)"', r.text)
            if okru_m:
                try:
                    from resources.lib.sports_router import _resolve_okru
                    tagged = _resolve_okru(okru_m.group(1))
                    if tagged:
                        return tagged
                except Exception:
                    pass
                continue

            # No direct file= param — look for the nested ?ch=<id> player
            # page one hop deeper instead.
            nested_m = re.search(r'<iframe[^>]+src="(https://cdntvmedia\.com/[^"]+)"', r.text)
            if not nested_m:
                continue
            r2 = requests.get(nested_m.group(1), headers=dict(sec_fetch_headers, Referer=mirror_url), timeout=10)
            if r2.status_code != 200:
                continue
            gen_m = _RE_SMOTRU_GENERATED_FILE.search(r2.text)
            if not gen_m:
                continue
            raw = gen_m.group(1).replace('\\/', '/')
            for candidate in raw.split(' or '):
                candidate = candidate.strip()
                if candidate.startswith('http'):
                    tagged = _smotru_verify_and_tag(candidate)
                    if tagged:
                        return tagged
        except Exception:
            continue
    return None


def prewarm_smotru():
    _smotru_channels_raw()


# ── EPG helpers ───────────────────────────────────────────────────────────────

def get_epg_urls():
    """
    Return dict of source -> XMLTV EPG URL.
    Used by the EPG export feature and pvr.iptvsimple integration.
    """
    return {
        'Samsung TV+': MJH_SAMSUNG_EPG,
        'Plex':        MJH_PLEX_EPG,
        # Pluto: EPG embedded in boot response (channel timeline arrays)
        # Starfleet:  EPG not yet captured — needs browser endpoint discovery
    }


# ── tvnow247.top Live Channels (500+, DaddyLive channel_id scheme) ───────────
#
# tvnow247.top is a client-rendered SPA — the channel catalogue isn't in the
# HTML, it's baked into a content-hashed JS bundle (/assets/channelData-*.js)
# at build time. The exact filename changes on redeploy, so it's discovered
# fresh from the page each time rather than hardcoded. Each channel's
# channel_id uses the SAME numbering as daddylive.mov (verified: id 663 =
# "NHL Network USA" on both), so playback resolves via
# sports_sources._dlchan_stream_url — no separate resolver needed here.

_TVNOW_BASE = 'https://tvnow247.top'
# Confirmed live 2026-08-09: the site's build renamed this chunk from
# "channelData-<hash>.js" to "channels-<hash>.js" — the reference is still
# a plain string sitting in the /tv-channels page's own static HTML (no JS
# execution needed to find it, same as before), so this was purely a
# filename-pattern change, not a move to some other discovery mechanism.
# Matching both patterns costs nothing and survives a future revert.
_RE_TVNOW_ASSET = re.compile(r'/assets/((?:channelData|channels)-[A-Za-z0-9_-]+\.js)')
_RE_TVNOW_CHANNEL = re.compile(
    r'channel_name:"([^"]*)",channel_id:"([^"]*)",slug:"([^"]*)",country:"([^"]*)".*?logoUrl:"([^"]*)"',
    re.DOTALL
)

# Adult channels are mixed into the same catalogue (e.g. "18+ (Player-N)") —
# excluded here since this addon already has a dedicated, PIN-gated Adult
# section; a general Live TV list shouldn't surface them unprompted.
_TVNOW_ADULT_BLOCK = {
    'pornhub', 'xvideos', 'xhamster', 'beeg', 'motherless', 'naughtyamerica',
    'sexvid', 'tnaflix', 'realitykings', 'drtuber', 'youporn', 'tube8',
    'pornhd', 'porntrex', 'bangbros', 'brazzers', 'spankbang', 'eporner',
}


def _tvnow_is_adult(name, slug):
    n = (name or '').lower()
    s = (slug or '').lower().replace('-', '')
    if '18+' in n or '18plus' in s:
        return True
    return any(b in n.replace(' ', '') or b in s for b in _TVNOW_ADULT_BLOCK)


_TVNOW_STREAM_API = 'https://chat.cfbu247.sbs/api/resolve-dlstream/%s'


def resolve_tvnow_stream(channel_id):
    """Fresh-resolve one of get_tvnow_channels()'s own channel ids to a
    playable stream URL at play time — never cached, since tokens/mirrors
    expire. Same API endpoint sports_sources._tvnow_api_resolve_mirror uses
    to resolve daddylive.mov mirrors that redirect through tvnow247.top;
    this calls it directly by channel_id for the general Live TV channel
    case (a plain menu click, not a sport-event mirror lookup)."""
    if not channel_id:
        return None
    from resources.lib import dns_fallback as _dnsf
    ua = {'User-Agent': ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
                         'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36')}
    try:
        # chat.cfbu247.sbs fails to resolve on some local/ISP DNS resolvers
        # even though it's live (confirmed via a public DNS resolver) —
        # _dnsf.get transparently retries via DNS-over-HTTPS on a local
        # resolution failure instead of just giving up.
        data = _dnsf.get(_TVNOW_STREAM_API % channel_id, timeout=8, headers=ua).json()
    except Exception as e:
        xbmc.log('[Starfleet/TVNow] resolve_tvnow_stream API error (%s): %s' % (channel_id, e),
                  xbmc.LOGWARNING)
        return None
    playlist_url = data.get('proxyPlaylistUrl') or data.get('m3u8')
    if not playlist_url:
        return None
    # The API happily returns a token even for a channel with no live
    # upstream right now — verify it actually serves before handing it to
    # the player, same check _tvnow_api_resolve_mirror already relies on.
    try:
        check = _dnsf.get(playlist_url, timeout=6, headers=ua)
        if check.status_code != 200 or not check.text.lstrip().startswith('#EXTM3U'):
            return None
    except Exception:
        return None
    return playlist_url


def get_tvnow_channels():
    """Scrape tvnow247.top's full channel catalogue. Cached 12h."""
    ck = 'tvnow_channels_v1'
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    channels = []
    try:
        ua = {'User-Agent': ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
                             'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36')}
        html = requests.get(_TVNOW_BASE + '/tv-channels', timeout=10, headers=ua).text
        am = _RE_TVNOW_ASSET.search(html)
        if not am:
            xbmc.log('[Starfleet/TVNow] channelData asset not found on page', xbmc.LOGWARNING)
            _cache.set(ck, [], 30 * 60)
            return []
        js_url = '%s/assets/%s' % (_TVNOW_BASE, am.group(1))
        js = requests.get(js_url, timeout=15, headers=ua).text

        seen = set()
        for m in _RE_TVNOW_CHANNEL.finditer(js):
            name, cid, slug, country, logo = m.groups()
            if not name or not cid or cid in seen:
                continue
            if _tvnow_is_adult(name, slug):
                continue
            seen.add(cid)
            channels.append({
                'id':        cid,
                'slug':      slug,
                'title':     name,
                'group':     country or 'Other',
                'source':    'TVNow247',
                'thumbnail': logo,
            })
    except Exception as e:
        xbmc.log('[Starfleet/TVNow] get_tvnow_channels error: %s' % e, xbmc.LOGWARNING)
        _cache.set(ck, [], 10 * 60)
        return []

    xbmc.log('[Starfleet/TVNow] %d channels scraped (adult filtered)' % len(channels), xbmc.LOGINFO)
    _cache.set(ck, channels, 12 * 3600)
    return channels


_RE_TVNOW_PLAYER_NUM = re.compile(r'player[\s\-]*0*(\d+)', re.IGNORECASE)

# adult-tv-channels.click — investigated live 2026-08-29 per direct request
# (alongside 2 mirror domains, fuckflix.click/xlivetv.com, sharing the exact
# same channel slugs and page template — confirmed byte-for-byte identical
# playerConfig shape, so scraping this one domain covers all three rather
# than duplicating the same content 3x). 24 real channels confirmed live
# across its 2 listing pages (Brazzers TV, Babes TV, Playboy TV, Hustler TV,
# Private TV, Penthouse TV, Dorcel TV, Vivid TV and more) — each channel
# page embeds a plain, unencrypted stream URL directly in a <script> block
# as either 'sourceUrl' or 'fallbackUrl' (template variant), no signing/
# token/expiry at all, same class of static config already confirmed and
# wired in for this site's own Vivid TV channel before this. A 4th
# candidate (guljaj.com) was also investigated and found to require a real
# account/login (own /user/reg.php + /user/ent.php pages, no free channel
# list reachable at all) — not added, unlike the other 3 which need no auth.
_ATC_BASE = 'https://adult-tv-channels.click'
_RE_ATC_CHANNEL_HREF = re.compile(r'href="https://adult-tv-channels\.click/([a-z0-9-]+)/"')
_RE_ATC_TITLE = re.compile(r'<h1[^>]*class="posttitle"[^>]*>([^<]+)</h1>')
_RE_ATC_STREAM_URL = re.compile(r'(?:sourceUrl|fallbackUrl)\s*:\s*"([^"]+)"')


def _adult_tv_channels_click_raw():
    """Real channel catalogue + direct stream URL for every adult-tv-
    channels.click channel — see this module comment above for what was
    confirmed live and why only this one (of 3 identical mirror) domains
    needs scraping."""
    ck = 'adult_tv_channels_click_v1'
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    headers = {'User-Agent': ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
                               '(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36')}
    slugs = set()
    try:
        for path in ('/', '/page2'):
            html_text = requests.get(_ATC_BASE + path, headers=headers, timeout=15).text
            slugs.update(_RE_ATC_CHANNEL_HREF.findall(html_text))
    except Exception as e:
        xbmc.log('[Starfleet/AdultTV] adult-tv-channels.click listing fetch error: %s' % e, xbmc.LOGWARNING)
        return []

    def _fetch_one(slug):
        try:
            html_text = requests.get('%s/%s/' % (_ATC_BASE, slug),
                                      headers=dict(headers, Referer=_ATC_BASE + '/'),
                                      timeout=12).text
        except Exception:
            return None
        m_url = _RE_ATC_STREAM_URL.search(html_text)
        if not m_url:
            return None
        m_title = _RE_ATC_TITLE.search(html_text)
        title = _html_mod.unescape(m_title.group(1)).strip() if m_title else slug.replace('-', ' ').title()
        return {'title': title, 'url': m_url.group(1)}

    channels = []
    from concurrent.futures import ThreadPoolExecutor, as_completed
    # NOT a `with` block — same reason as every other ThreadPoolExecutor in
    # this codebase: __exit__ would call shutdown(wait=True) and block on
    # every submitted task even after a straggler's own result is no
    # longer needed.
    pool = ThreadPoolExecutor(max_workers=12)
    try:
        futs = [pool.submit(_fetch_one, slug) for slug in slugs]
        for fut in as_completed(futs, timeout=20):
            try:
                r = fut.result()
                if r:
                    channels.append(r)
            except Exception:
                pass
    finally:
        pool.shutdown(wait=False)

    channels.sort(key=lambda c: c['title'])
    xbmc.log('[Starfleet/AdultTV] %d channels scraped from adult-tv-channels.click' % len(channels),
              xbmc.LOGINFO)
    _cache.set(ck, channels, 24 * 3600 if channels else 10 * 60)
    return channels


def get_tvnow_adult_channels():
    """18+ channels — sourced from dlstreams.st's combined channel
    directory (see get_dlstreams_channels()'s own docstring for the
    site's background) rather than tvnow247.top. Confirmed live
    2026-08-24: tvnow247.top's /tv-channels page still loads (200), but
    its own SPA build no longer exposes a channelData asset bundle this
    regex ever matches — the site appears to have changed its own build
    tooling since this was first written, so that path silently returned
    zero channels regardless of query. dlstreams.st's own combined
    /24-7-channels.php listing (already scraped for the general SFW
    catalogue, and confirmed live as the same DaddyLive/DLHD family this
    addon already resolves elsewhere — see that module comment) carries a
    real 18+ section too: 20 real, currently-playable channels confirmed
    live (ids 501-520, titled "18+ (Player-NN)"), resolved through the
    exact same chain the SFW channels already use.

    Function name/signature kept as-is so afdb_router.py's/home.py's
    existing call sites don't need restructuring — only their own resolve
    call needed to switch from resolve_tvnow_stream() to
    resolve_dlstreams_channel() to match (done at both call sites)."""
    ck = 'tvnow_adult_channels_v1'
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    channels = []
    try:
        raw = _dlstreams_channels_raw()
        for ch in raw:
            name = ch.get('name', '')
            if not name.strip().lower().startswith('18+'):
                continue
            nm = _RE_TVNOW_PLAYER_NUM.search(name)
            title = '18+ Player %02d' % int(nm.group(1)) if nm else name
            channels.append({
                'id':        ch['id'],
                'slug':      '',
                'title':     title,
                'group':     '18+',
                'source':    'DLHD',
                'thumbnail': '',
            })
        # adult-tv-channels.click — extended 2026-08-29 from a single
        # hardcoded Vivid TV entry to this site's full real catalogue (24
        # channels — see _adult_tv_channels_click_raw()'s own comment for
        # what was confirmed live). Each entry's own already-resolved
        # direct URL is embedded straight into the id as a 'DIRECT:<url>'
        # sentinel (not a dlstreams.st numeric id) — see
        # resolve_adult_channel() below, which both call sites use instead
        # of calling resolve_dlstreams_channel() directly, so these can
        # skip that resolution chain entirely (same static-URL shape
        # already confirmed safe for Vivid TV specifically before this).
        for ch in _adult_tv_channels_click_raw():
            channels.append({
                'id':        'DIRECT:%s' % ch['url'],
                'slug':      '',
                'title':     ch['title'],
                'group':     '18+',
                'source':    'AdultTVChannelsClick',
                'thumbnail': '',
            })
    except Exception as e:
        xbmc.log('[Starfleet/TVNow] get_tvnow_adult_channels error: %s' % e, xbmc.LOGWARNING)
        _cache.set(ck, [], 10 * 60)
        return []

    channels.sort(key=lambda c: c['title'])
    xbmc.log('[Starfleet/TVNow] %d adult channels scraped (via dlstreams.st)' % len(channels), xbmc.LOGINFO)
    _cache.set(ck, channels, 12 * 3600)
    return channels


def resolve_adult_channel(channel_id):
    """Single resolve entry point for get_tvnow_adult_channels()'s list —
    both afdb_router.py's and home.py's play handlers call this instead of
    resolve_dlstreams_channel() directly, so a channel from a different
    source (currently the 24 adult-tv-channels.click entries, each with
    their own already-resolved static direct URL) can be handled here
    without either call site needing its own per-source branching."""
    if channel_id.startswith('DIRECT:'):
        return channel_id[len('DIRECT:'):]
    return resolve_dlstreams_channel(channel_id)


def get_combined_m3u(include_tva_channels=None):
    """
    Generate a combined M3U playlist for ALL sources.
    This can be pointed at by pvr.iptvsimple for a full EPG experience.
    include_tva_channels: list of {'title', 'asset_key', 'thumbnail'} dicts
    """
    lines = ['#EXTM3U']

    # TVA / DAI channels — use plugin:// URL so DAI token is fetched at play time
    if include_tva_channels:
        for ch in include_tva_channels:
            plugin_url = (
                'plugin://plugin.video.starfleet/'
                '?action=play_live_dai'
                '&asset_key=%s&title=%s' % (ch['asset_key'],
                                             requests.utils.quote(ch['title']))
            )
            lines.append(
                '#EXTINF:-1 tvg-id="%s" tvg-logo="%s" group-title="Starfleet",\t%s'
                % (ch['asset_key'], ch.get('thumbnail',''), ch['title'])
            )
            lines.append(plugin_url)

    # Samsung
    for ch in get_samsung_channels():
        lines.append(
            '#EXTINF:-1 tvg-id="%s" tvg-logo="%s" group-title="Samsung TV+",\t%s'
            % (ch['id'], ch['thumbnail'], ch['title'])
        )
        lines.append(ch['stream_url'])

    # Plex
    for ch in get_plex_channels():
        lines.append(
            '#EXTINF:-1 tvg-id="%s" tvg-logo="%s" group-title="Plex",\t%s'
            % (ch['id'], ch['thumbnail'], ch['title'])
        )
        lines.append(ch['stream_url'])

    # Pluto
    for ch in get_pluto_channels():
        lines.append(
            '#EXTINF:-1 tvg-id="%s" tvg-logo="%s" group-title="Pluto TV",\t%s'
            % (ch['id'], ch['thumbnail'], ch['title'])
        )
        lines.append(ch.get('stream_url', ''))

    return '\n'.join(lines)
