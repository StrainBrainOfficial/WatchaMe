﻿# -*- coding: utf-8 -*-
"""
resources/lib/dispatcher.py

Central action dispatcher. Imported once and kept alive by
reuselanguageinvoker — all subsequent navigation calls reuse
this module without re-importing or re-executing top-level code.

All heavy imports are inside elif branches (lazy) so only the
modules needed for the current action are loaded per call.
"""

import sys
from urllib.parse import parse_qsl, urlencode, unquote_plus
import xbmc
import xbmcplugin


def _build_url(base, params):
    return base + '?' + urlencode({k: str(v) for k, v in params.items()})


_AUDIO_LANG_ENFORCED = False


def _ensure_english_audio_default():
    """Force Kodi's global preferred-audio-language setting to English —
    per explicit request, so a multi-audio-track release (e.g. a dubbed
    anime shipping both a Japanese and an English track) defaults to the
    English track instead of whatever track happens to be first in the
    file. This is a Kodi core player setting, not per-file — setting it
    once here covers every play from any source in this addon. Only runs
    once per invoker process (reuselanguageinvoker keeps this module
    alive across calls — see this file's own docstring), not on every
    single navigation call, since it's the same fixed value every time.
    'videoplayer.preferredaudiolanguage' is the current (Kodi 19+) setting
    id; falls back to the older 'locale.audiolanguage' id for older Kodi
    builds if that first attempt doesn't take."""
    global _AUDIO_LANG_ENFORCED
    if _AUDIO_LANG_ENFORCED:
        return
    _AUDIO_LANG_ENFORCED = True
    import json as _json
    for setting_id in ('videoplayer.preferredaudiolanguage', 'locale.audiolanguage'):
        try:
            resp = xbmc.executeJSONRPC(_json.dumps({
                'jsonrpc': '2.0', 'method': 'Settings.SetSettingValue',
                'params': {'setting': setting_id, 'value': 'eng'},
                'id': 1,
            }))
            if _json.loads(resp).get('result') is True:
                xbmc.log('[Starfleet] Preferred audio language set to English (%s)' % setting_id,
                         xbmc.LOGINFO)
                return
        except Exception as e:
            xbmc.log('[Starfleet] set preferred audio language (%s) failed: %s' % (setting_id, e),
                     xbmc.LOGWARNING)


def run(handle, base_url, query_string):
    # Wipe the whole cache the first time this process runs after a version
    # change — see cache.clear_if_updated()'s own docstring. Must happen
    # before any action below gets a chance to populate the cache with
    # data built under the version that just started running.
    from resources.lib import cache as _cache
    _cache.clear_if_updated()
    _ensure_english_audio_default()

    params = dict(parse_qsl(query_string.lstrip('?')))
    action = params.get('action', 'main_menu')

    def p(k, d=''):
        return unquote_plus(params.get(k, d))

    def build_url(ps):
        return _build_url(base_url, ps)

    # ── Playback actions — resolved URL, no endOfDirectory ────────────────────
    if action == 'play_live_dai':
        from resources.lib.router import play_live_dai
        play_live_dai(handle, p('asset_key'), p('title'), p('channel_id'))
        return

    if action == 'play_sinclair':
        from resources.lib.router import play_sinclair
        play_sinclair(handle, p('callsign'), p('domain'), p('title'))
        return

    if action == 'play_direct':
        from resources.lib.router import play_direct
        play_direct(handle, p('stream_url'), p('ch_id'), p('source'), p('title'))
        return

    if action == 'radio_play':
        from resources.lib.radio_router import radio_play
        radio_play(handle, p('station_uuid'), p('stream_url'), p('title'))
        return

    if action == 'afdb_play':
        from resources.lib.afdb_router import afdb_play
        afdb_play(handle, p('stream_url'), p('film_id'))
        return

    if action == 'play_xxxclub_magnet':
        from resources.lib.afdb_router import play_xxxclub_magnet
        play_xxxclub_magnet(handle, p('magnet'), p('title'))
        return

    if action == 'adult_stream_play':
        from resources.lib.afdb_router import adult_stream_play
        adult_stream_play(handle, p('stream_url'), p('title'))
        return

    if action == 'adult_stream_sources':
        from resources.lib.afdb_router import adult_stream_sources
        adult_stream_sources(handle, build_url, p('film_id'), p('title'), p('film_url'))
        return

    if action == 'afdb_play_search':
        from resources.lib.afdb_router import afdb_play_search
        afdb_play_search(handle, p('film_id'), p('film_slug'), p('film_title'))
        return

    if action == 'sports_event_play':
        from resources.lib.sports_router import sports_event_play
        sports_event_play(handle, p('event_id'), p('event_path'), p('sport_slug'), p('title'))
        return

    if action == 'replay_play':
        from resources.lib.sports_router import replay_play
        replay_play(handle, p('url'), p('title'))
        return

    if action == 'free_play':
        from resources.lib.free_router import free_play
        free_play(handle, p('tmdb_id'), p('title'), p('year'), p('media_type'), p('svc_label'), p('archive_id'), p('stream_url'))
        return

    if action == 'meta_movie_play':
        from resources.lib.metadata_router import movie_play
        movie_play(handle, p('tmdb_id'), p('title'), p('imdb_id'), p('year'))
        return

    if action == 'meta_ep_play':
        from resources.lib.metadata_router import episode_play
        episode_play(handle, p('tmdb_id'), p('season_num'), p('episode_num'), p('title'), p('year'))
        return

    if action == 'live_unified_play':
        from resources.lib import unified_live
        from resources.lib import api as _api
        tva_channels = _api.get_live_channels()
        channels     = unified_live.get_all_channels(tva_channels=tva_channels)
        ch_key       = p('ch_key')
        ch_title     = p('ch_title')
        match        = next((c for c in channels if c['key'] == ch_key), None)
        if match:
            source_entry, play_action = unified_live.pick_source_and_play(handle, match)
            if source_entry and play_action == 'play_live_dai':
                from resources.lib.router import play_live_dai
                play_live_dai(handle, source_entry.get('asset_key', ''), ch_title, source_entry.get('channel_id', ''))
            elif source_entry and play_action == 'play_sinclair':
                from resources.lib.router import play_sinclair
                play_sinclair(handle, source_entry.get('callsign', ''), source_entry.get('domain', ''), ch_title)
            elif source_entry:
                from resources.lib.router import play_direct
                play_direct(handle, source_entry['stream_url'],
                            source_entry['ch_id'], source_entry['source'], ch_title)
            else:
                xbmcplugin.setResolvedUrl(handle, False, __import__('xbmcgui').ListItem())
        else:
            xbmcplugin.setResolvedUrl(handle, False, __import__('xbmcgui').ListItem())
        return

    # ── Favorites utility actions (RunPlugin — no directory) ─────────────────
    if action == 'favorites_add':
        from resources.lib.favorites import favorites_add_action
        favorites_add_action(p('media_type'), p('tmdb_id'), p('title'),
                             year=p('year'), imdb_id=p('imdb_id'),
                             thumb=p('thumb'), fanart=p('fanart'))
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    if action == 'favorites_remove':
        from resources.lib.favorites import favorites_remove_action
        favorites_remove_action(p('media_type'), p('tmdb_id'),
                                refresh=bool(p('refresh')))
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    if action == 'favorites_clear_confirm':
        from resources.lib.favorites import favorites_clear_confirm
        favorites_clear_confirm()
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    if action == 'meta_toggle_watched':
        # Context-menu 'Mark as Watched/Unwatched' for Movies/TV custom-skin
        # lists — those items only carry a tmdb_id (imdb_id requires a full
        # detail fetch we don't do for whole-list rendering), so resolve the
        # real imdb_id here on demand, same as movie_play()/episode_play()
        # already do before writing to watch_history, to keep the storage
        # key consistent with what automatic playback-based tracking uses.
        from resources.lib import watch_history as _wh
        media_type = p('media_type', 'movie')
        # TV episode toggles pass the exact identifier the episode list
        # already resolved for reads (_open_tv_episodes' _wh_key — real
        # imdb_id if found, else tvdb_id/tmdb_id fallback) via wh_key, so
        # the write always lands under the same key the list checks —
        # re-deriving it here independently risked the read/write key
        # mismatch already flagged elsewhere in this codebase as the exact
        # reason a watched status silently never showed up.
        wh_key  = p('wh_key', '')
        imdb_id = p('imdb_id', '') or wh_key
        tmdb_id = p('tmdb_id', '')
        season  = int(p('season', '0') or 0)
        episode = int(p('episode', '0') or 0)
        if not imdb_id and tmdb_id:
            try:
                from resources.lib import metadata as _md
                detail = _md.get_tv_detail(tmdb_id) if media_type == 'tv' else _md.get_movie_detail(tmdb_id)
                imdb_id = detail.get('imdb_id', '') if detail else ''
            except Exception:
                imdb_id = ''
        if imdb_id:
            new_state = _wh.toggle_watched(imdb_id, title=p('title', ''),
                                           season=season, episode=episode, tmdb_id=tmdb_id)
            import xbmcgui as _xg
            _xg.Dialog().notification(
                'Starfleet', 'Marked Watched' if new_state else 'Marked Unwatched',
                _xg.NOTIFICATION_INFO, 1500)
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    if action == 'meta_toggle_season_watched':
        # Bulk sibling of meta_toggle_watched above — per direct request,
        # so a whole season can be marked from the season picker itself
        # instead of one episode at a time. Same wh_key-consistency
        # reasoning as the per-episode action: wh_key is whatever the
        # season picker already resolved for the show (real imdb_id, or
        # the tvdb_id/tmdb_id fallback), so this writes under the exact
        # same key every read path in this addon already checks.
        from resources.lib import watch_history as _wh
        wh_key  = p('wh_key', '')
        imdb_id = p('imdb_id', '') or wh_key
        tmdb_id = p('tmdb_id', '')
        tvdb_id = p('tvdb_id', '')
        season  = int(p('season', '0') or 0)
        if not imdb_id and tmdb_id:
            try:
                from resources.lib import metadata as _md
                detail = _md.get_tv_detail(tmdb_id)
                imdb_id = detail.get('imdb_id', '') if detail else ''
            except Exception:
                imdb_id = ''
        if imdb_id:
            try:
                from resources.lib import metadata as _md
                episodes = _md.get_episodes(tmdb_id, season, tvdb_id or None)
                ep_nums = [ep.get('episode', 0) for ep in episodes if ep.get('episode')]
            except Exception:
                ep_nums = []
            if ep_nums:
                new_state = _wh.mark_season_watched(imdb_id, season, ep_nums,
                                                    title=p('title', ''), tmdb_id=tmdb_id)
                import xbmcgui as _xg
                _xg.Dialog().notification(
                    'Starfleet', 'Season Marked Watched' if new_state else 'Season Marked Unwatched',
                    _xg.NOTIFICATION_INFO, 2000)
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    if action == 'live_favorites_add':
        from resources.lib.live_favorites import live_favorites_add_action
        live_favorites_add_action(p('ch_key'), p('title'), thumb=p('thumb'), fanart=p('fanart'),
                                  direct_url=p('direct_url'))
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    if action == 'live_favorites_remove':
        from resources.lib.live_favorites import live_favorites_remove_action
        live_favorites_remove_action(p('ch_key'), title=p('title'))
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    if action == 'live_favorites_list':
        from resources.lib.live_favorites import live_favorites_list
        live_favorites_list(handle, build_url)
        return

    # ── Utility actions — no directory listing ────────────────────────────────
    if action == 'set_adult_pin':
        from resources.lib.pin_lock import set_pin
        set_pin()
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    if action in ('lock_adult', 'adult_lock'):
        from resources.lib.pin_lock import lock_session
        lock_session()
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    if action == 'resolver_status':
        from resources.lib.resolvers import show_account_status
        show_account_status()
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    if action == 'trakt_pair':
        from resources.lib.trakt_auth import pair_with_trakt
        pair_with_trakt()
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    if action == 'trakt_status':
        from resources.lib.trakt_auth import show_status
        show_status()
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    if action == 'tmdb_pair':
        from resources.lib.tmdb_auth import pair_with_tmdb
        pair_with_tmdb()
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    if action == 'tmdb_status':
        from resources.lib.tmdb_auth import show_status
        show_status()
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    if action == 'simkl_pair':
        from resources.lib.simkl_auth import pair_with_simkl
        pair_with_simkl()
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    if action == 'simkl_status':
        from resources.lib.simkl_auth import show_status as simkl_show_status
        simkl_show_status()
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    if action == 'wetrakr_pair':
        from resources.lib.wetrakr_auth import pair_with_wetrakr
        pair_with_wetrakr()
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    if action == 'wetrakr_status':
        from resources.lib.wetrakr_auth import show_status as wetrakr_show_status
        wetrakr_show_status()
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    if action == 'mdblist_verify':
        from resources.lib.mdblist_auth import verify_key
        verify_key()
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    if action == 'donate_show':
        from resources.lib import donate as _donate
        _donate.show_donate_dialog(p('coin'))
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    if action == 'open_settings':
        import xbmcaddon
        xbmcaddon.Addon('plugin.video.starfleet').openSettings()
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    if action == 'open_url':
        # Referenced by several Settings "Get API key" help buttons
        # (rd_help/ad_help/pm_help/tb_help) but never actually implemented —
        # those buttons silently did nothing when clicked. Kodi has no
        # universal, cross-platform "open in the device's browser" builtin
        # (System.Exec only works on desktop OSes, not Android/FireTV where
        # this addon is mainly used), so rather than a half-working launcher,
        # show the URL as selectable text the user can read/copy — works
        # identically on every platform.
        import xbmcgui as _xg
        url = p('url')
        _xg.Dialog().textviewer('Open this URL in your browser', url or '(no URL provided)')
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    if action == 'meta_content_advisory':
        from resources.lib import metadata as _meta
        import xbmcgui as _xg
        guide = _meta.get_parental_guide(p('imdb_id'))
        if not guide:
            _xg.Dialog().notification('Content Advisory', 'No parents-guide data found for this title',
                                       _xg.NOTIFICATION_INFO, 4000)
            xbmcplugin.endOfDirectory(handle, succeeded=False)
            return
        lines = []
        for cat in guide:
            header = cat['name']
            if cat.get('severity'):
                header += '  —  %s' % cat['severity']
            lines.append(header)
            for it in cat.get('items', []):
                bullet = '  • ' + it['text']
                if it.get('spoiler'):
                    bullet += '  [SPOILER]'
                lines.append(bullet)
            lines.append('')
        _xg.Dialog().textviewer('Content Advisory — %s' % p('title'), '\n'.join(lines).strip())
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    if action == 'pair_debrid':
        # Settings "Pair Device" buttons for Real-Debrid/AllDebrid/
        # Premiumize/TorBox — see debrid_pairing.py's own docstring for
        # why this replaces manual API-key copy-paste with the same
        # device-code flow used across the Kodi debrid-client ecosystem.
        from resources.lib import debrid_pairing as _dp
        _dp.pair(p('service'))
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    if action == 'send_debug_log':
        # Settings > General "Send Debug Log" — see resources/lib/debug_log.py's
        # module docstring for why this exists: ADB can't reach a Firestick's
        # own kodi.log (confirmed live, permission denied / not debuggable,
        # not rooted), but the running app can read its own log file fine, so
        # this reads+redacts+uploads it from inside the addon instead. Tries
        # a couple of paste services before falling back to a guaranteed
        # local save, so this always has SOMETHING to show, not just a
        # failure notification.
        from resources.lib import debug_log as _dbglog
        import xbmcgui as _xg
        dlg = _xg.DialogProgress()
        dlg.create('Starfleet', 'Uploading debug log...')
        try:
            result = _dbglog.upload_debug_log()
        finally:
            dlg.close()
        if result:
            _xg.Dialog().textviewer('Debug Log', result)
        else:
            _xg.Dialog().notification('Starfleet', 'Could not read the log file — see log',
                                       _xg.NOTIFICATION_ERROR, 4000)
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    if action == 'clear_cache':
        # Android blocks ADB/file-manager access to another app's private
        # data dir, so this is the only way to drop a stale cached result
        # (e.g. the Sports category list) without waiting out its TTL —
        # confirmed live: a device that browsed Sports before a menu fix
        # shipped kept serving the old cached list for the rest of that
        # window even after updating, since caching is time-based only,
        # not aware of addon code changes.
        from resources.lib import cache as _cache
        import xbmcgui as _xg
        _cache.clear_all()
        _xg.Dialog().notification(
            'Starfleet', 'Cache cleared', _xg.NOTIFICATION_INFO, 2000)
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    if action == 'torrent_sources_bulk':
        # Settings > Torrent Sources' convenience buttons — "Enable All
        # Sources" (mode=all), "Disable All Sources" (mode=none), and
        # "Reset to Recommended (Fast) Set" (mode=recommended) — set every
        # individual src_<key> toggle at once instead of making the user
        # click through all ~35 of them by hand. Recommended defaults
        # mirror exactly what each setting's own settings.xml default="..."
        # already is, so "reset" and "never touched Settings at all" always
        # mean the same thing. mode=none is for someone who wants to search
        # zero torrent sources (e.g. debrid-only via direct library/embed
        # sources) without hand-unchecking every box.
        from resources.lib import torrent_sources as _tsrc
        import xbmcgui as _xg
        import xbmcaddon as _xa
        mode = p('mode') or 'recommended'
        addon = _xa.Addon('plugin.video.starfleet')
        # Recommended set replaced 2026-08-16 with the top 5 real,
        # correctly-matched sources per category (Movie/TV/Adult) from a
        # live test against a real title in each — 11 total since Movie/TV
        # share this one list. Keep in sync with settings.xml's own
        # default="..." values above (the invariant this whole button
        # exists to preserve: "reset" and "never touched Settings" must
        # always mean the same thing).
        _CORE_KEYS = {'torrentio', 'knaben', 'eztv', '1337x', 'torrentz2',
                      'torrentfunk', 'snowfl', 'extto', 'limetorrents',
                      'filemood', 'tordl'}
        for key in _tsrc._ALL_SOURCE_KEYS:
            if mode == 'all':
                value = 'true'
            elif mode == 'none':
                value = 'false'
            else:
                value = 'true' if key in _CORE_KEYS else 'false'
            addon.setSetting('src_' + key, value)
        if mode == 'all':
            msg = 'All torrent sources enabled'
        elif mode == 'none':
            msg = 'All torrent sources disabled'
        else:
            msg = 'Reset to recommended fast source set'
        _xg.Dialog().notification('Starfleet', msg, _xg.NOTIFICATION_INFO, 3000)
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    if action == 'live_pluto_refresh':
        from resources.lib import live_sources
        live_sources.refresh_pluto()
        from resources.lib.router import list_live_pluto
        list_live_pluto(handle, build_url)
        # An explicit user-requested refresh is the last place that should
        # let Kodi's own core directory cache serve a stale copy back —
        # see the main _dispatch_directory cacheToDisc=False comment below
        # for the full explanation of this separate caching layer.
        xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
        return

    if action == 'live_refresh_all':
        from resources.lib import unified_live, live_sources
        unified_live.invalidate()
        live_sources.refresh_pluto()
        from resources.lib.router import list_live_all
        list_live_all(handle, build_url)
        xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
        return

    # ── Main menu — opens custom home window ──────────────────────────────────
    if action == 'main_menu':
        import os as _os
        import xbmcaddon as _xa
        _addon_path = _xa.Addon().getAddonInfo('path')
        _run_script = _os.path.join(_addon_path, 'resources', 'lib', 'gui', 'run_home.py')
        _xml_path   = _os.path.join(_addon_path, 'resources', 'skins', 'Default', '1080i', 'Starfleet-Home.xml')
        if _os.path.isfile(_run_script) and _os.path.isfile(_xml_path):
            import xbmcvfs as _xbmcvfs
            import time as _time
            _data_dir   = _xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.starfleet/')
            _win_lock   = _os.path.join(_data_dir, 'window.lock')
            # Treat locks older than 30 s as stale (script was killed by Kodi without cleanup).
            _nav_lock   = _os.path.join(_data_dir, 'nav.lock')
            _home_open = False
            if _os.path.exists(_win_lock):
                try:
                    _age = _time.time() - _os.path.getmtime(_win_lock)
                    if _age < 30:
                        _home_open = True
                    else:
                        xbmc.log('[Starfleet/Home] stale window.lock (age %.0fs) — removing' % _age, xbmc.LOGWARNING)
                        _os.remove(_win_lock)
                except Exception:
                    _home_open = False
            if not _home_open and _os.path.exists(_nav_lock):
                try:
                    _age = _time.time() - _os.path.getmtime(_nav_lock)
                    if _age < 8:
                        _home_open = True
                    else:
                        _os.remove(_nav_lock)
                except Exception:
                    pass
            if _home_open:
                # Nav transition in progress — home.py fires ActivateWindow(Videos,
                # target_url) ~600 ms after home closes.  Return an empty succeeded
                # listing so Videos shows nothing (no error → no retry loop, and
                # DialogBusy dismisses cleanly so ActivateWindow is not blocked).
                xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)
            else:
                xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)
                # Only pop Home open if the plugin's own directory listing is
                # actually the thing on screen right now (id 10025 = Videos).
                # This root action also fires when something OTHER than the
                # user genuinely opening the addon queries the plugin root —
                # e.g. Kodi/the active skin briefly resolving addon metadata
                # for a widget or the Add-ons browser tile — and in that case
                # the Videos window was never made active, so RunScript here
                # would pop Home open on top of whatever the user is actually
                # looking at (confirmed in the field: backing all the way out
                # to Kodi's own Add-ons screen, then Home reopening on its own
                # a moment later with no input). Skip the relaunch entirely
                # when Videos isn't the foreground window.
                if xbmc.getCondVisibility('Window.IsActive(videos)'):
                    # Only check for/prompt about dependencies on a genuine
                    # Home (re)launch, not on the internal placeholder
                    # ActivateWindow hop home.py fires for every in-app nav
                    # click (Sports/Movies/TV/etc) — that hop used to always
                    # run this too, which could pop a blocking yesno dialog
                    # mid-navigation for no reason tied to what the user
                    # actually clicked.
                    from resources.lib.setup import check_and_guide
                    check_and_guide()
                    xbmc.executebuiltin('RunScript(%s)' % _run_script)
                else:
                    xbmc.log('[Starfleet/Home] main_menu fired without Videos window active — '
                             'skipping Home relaunch (likely a background metadata query)', xbmc.LOGINFO)
        else:
            xbmc.log('[Starfleet/Home] skin not found, falling back to menu', xbmc.LOGWARNING)
            from resources.lib.router import main_menu as _main_menu
            _main_menu(handle, build_url)
            xbmcplugin.endOfDirectory(handle)
        return

    # ── Directory actions — all end with endOfDirectory ───────────────────────
    # cacheToDisc=False is the real fix for a genuine, systemic bug: every
    # directory action dispatched through _dispatch_directory() (Movies, TV,
    # Seasons, Episodes, search results — virtually everything) used to hit
    # this one shared endOfDirectory() call with NO cacheToDisc argument,
    # meaning it silently took Kodi's own default of True. That's Kodi's
    # OWN core-level directory cache, written to Kodi's own local database —
    # a completely separate layer from this addon's own cache.py (which
    # dispatcher.run()'s clear_if_updated() and the Settings "Clear Cache"
    # button both only ever touched). Confirmed live this is exactly why a
    # stale TV season listing (or any other dynamic listing) kept surviving
    # an update even after Starfleet's own cache was correctly wiped —
    # nothing about that ever cleared Kodi's SEPARATE directory cache, so
    # only a full OS-level Kodi app-cache clear (a much bigger hammer than
    # anyone should need to reach for) actually forced Kodi to re-request
    # fresh data instead of replaying its own stale cached listing. Only 2
    # other call sites in this whole file already correctly used
    # cacheToDisc=False for this exact reason - this generic, shared exit
    # point covering nearly everything else never did. cacheToDisc=True is
    # meant for genuinely static local content; every listing here is
    # dynamically fetched from TMDB/live scrapers on every real call, and
    # already has its own purpose-built, addon-controlled caching via
    # cache.py - there's no good reason to also let Kodi's own engine cache
    # the rendered output a second time at a layer this addon can't clear.
    _dispatch_directory(action, handle, build_url, p, params)
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def _dispatch_directory(action, handle, build_url, p, params):
    """All directory-listing actions dispatched here."""
    # ── Favorites ─────────────────────────────────────────────────────────────
    if action == 'favorites_menu':
        from resources.lib.favorites import favorites_menu
        favorites_menu(handle, build_url)

    elif action == 'favorites_movies':
        from resources.lib.favorites import favorites_movies
        favorites_movies(handle, build_url)

    elif action == 'favorites_tv':
        from resources.lib.favorites import favorites_tv
        favorites_tv(handle, build_url)

    # ── Live TV ───────────────────────────────────────────────────────────────
    elif action == 'live_menu':
        from resources.lib.router import live_menu
        live_menu(handle, build_url)

    elif action == 'live_all':
        from resources.lib.router import list_live_all
        list_live_all(handle, build_url)

    elif action == 'live_tva':
        from resources.lib.router import list_live_tva
        list_live_tva(handle, build_url)

    elif action == 'live_samsung':
        from resources.lib.router import list_live_samsung
        list_live_samsung(handle, build_url)

    elif action == 'live_samsung_group':
        from resources.lib.router import list_live_samsung_group
        list_live_samsung_group(handle, build_url, p('group'))

    elif action == 'live_plex':
        from resources.lib.router import list_live_plex
        list_live_plex(handle, build_url)

    elif action == 'live_plex_group':
        from resources.lib.router import list_live_plex_group
        list_live_plex_group(handle, build_url, p('group'))

    elif action == 'live_pluto':
        from resources.lib.router import list_live_pluto
        list_live_pluto(handle, build_url)

    elif action == 'live_toutv':
        from resources.lib.router import list_live_toutv
        list_live_toutv(handle, build_url)

    elif action == 'live_news':
        from resources.lib.router import list_live_news
        list_live_news(handle, build_url)

    elif action == 'live_free_sports':
        from resources.lib.router import list_live_free_sports
        list_live_free_sports(handle, build_url)

    elif action == 'live_dlstreams':
        from resources.lib.router import list_live_dlstreams
        list_live_dlstreams(handle, build_url)

    elif action == 'live_bigbrother':
        from resources.lib.router import list_live_bigbrother
        list_live_bigbrother(handle, build_url)

    elif action == 'play_dlstreams':
        from resources.lib.router import play_dlstreams_channel
        play_dlstreams_channel(handle, p('ch_id'), p('title'))

    elif action == 'play_daddylive_catalog':
        from resources.lib.router import play_daddylive_catalog
        play_daddylive_catalog(handle, p('title'))

    elif action == 'live_ustvnow':
        from resources.lib.router import list_live_ustvnow
        list_live_ustvnow(handle, build_url)

    elif action == 'play_ustvnow':
        from resources.lib.router import play_ustvnow_channel
        play_ustvnow_channel(handle, p('ch_link'), p('title'))

    elif action == 'live_filmon':
        from resources.lib.router import list_live_filmon
        list_live_filmon(handle, build_url)

    elif action == 'play_filmon':
        from resources.lib.router import play_filmon_channel
        play_filmon_channel(handle, p('ch_id'), p('title'))

    elif action == 'request_play':
        from resources.lib.router import play_request_stream
        play_request_stream(handle, p('url'), p('title'))

    elif action == 'live_smotru':
        from resources.lib.router import list_live_smotru
        list_live_smotru(handle, build_url)

    elif action == 'play_smotru':
        from resources.lib.router import play_smotru_channel
        play_smotru_channel(handle, p('slug'), p('title'))

    elif action == 'live_tvnow':
        from resources.lib.router import list_live_tvnow
        list_live_tvnow(handle, build_url)

    elif action == 'live_tvnow_country':
        from resources.lib.router import list_live_tvnow_country
        list_live_tvnow_country(handle, build_url, p('country'))

    elif action == 'live_tvnow_play':
        from resources.lib.router import live_tvnow_play
        live_tvnow_play(handle, p('playable_url'), p('title'))

    elif action == 'live_tvnow_channel_play':
        from resources.lib.router import play_tvnow_channel
        play_tvnow_channel(handle, p('channel_id'), p('title'))

    elif action == 'live_channel_picker':
        from resources.lib.router import live_channel_picker
        live_channel_picker(handle, p('key'))

    elif action == 'live_pluto_group':
        from resources.lib.router import list_live_pluto_group
        list_live_pluto_group(handle, build_url, p('group'))

    elif action == 'export_iptv':
        from resources.lib.router import export_iptv
        export_iptv(handle, build_url)

    # ── Metadata — Movies ─────────────────────────────────────────────────────
    elif action == 'meta_movies_menu':
        from resources.lib.metadata_router import movies_menu
        movies_menu(handle, build_url)

    elif action == 'meta_movies_by_date':
        from resources.lib.metadata_router import movies_by_date
        movies_by_date(handle, build_url, int(p('page', '1')))

    elif action == 'meta_movies_popular':
        from resources.lib.metadata_router import movies_popular
        movies_popular(handle, build_url, int(p('page', '1')))

    elif action == 'meta_movies_top':
        from resources.lib.metadata_router import movies_top_rated
        movies_top_rated(handle, build_url, int(p('page', '1')))

    elif action == 'meta_movies_new':
        from resources.lib.metadata_router import movies_now_playing
        movies_now_playing(handle, build_url, int(p('page', '1')))

    elif action == 'meta_movies_upcoming':
        from resources.lib.metadata_router import movies_upcoming
        movies_upcoming(handle, build_url, int(p('page', '1')))

    elif action == 'meta_movie_genres':
        from resources.lib.metadata_router import movie_genres
        movie_genres(handle, build_url)

    elif action == 'meta_movies_by_genre':
        from resources.lib.metadata_router import movies_by_genre
        movies_by_genre(handle, build_url, p('genre_id'), p('genre_name'), int(p('page', '1')))

    elif action == 'meta_movies_search':
        from resources.lib.metadata_router import movies_search
        movies_search(handle, build_url)

    elif action == 'meta_movie_detail':
        from resources.lib.metadata_router import movie_detail
        movie_detail(handle, build_url, p('tmdb_id'))

    # ── Metadata — TV Shows ───────────────────────────────────────────────────
    elif action == 'meta_tv_menu':
        from resources.lib.metadata_router import tv_menu
        tv_menu(handle, build_url)

    elif action == 'meta_tv_popular':
        from resources.lib.metadata_router import tv_popular
        tv_popular(handle, build_url, int(p('page', '1')))

    elif action == 'meta_tv_top':
        from resources.lib.metadata_router import tv_top_rated
        tv_top_rated(handle, build_url, int(p('page', '1')))

    elif action == 'meta_tv_airing':
        from resources.lib.metadata_router import tv_airing_today
        tv_airing_today(handle, build_url, int(p('page', '1')))

    elif action == 'meta_tv_genres':
        from resources.lib.metadata_router import tv_genres
        tv_genres(handle, build_url)

    elif action == 'meta_tv_by_genre':
        from resources.lib.metadata_router import tv_by_genre
        tv_by_genre(handle, build_url, p('genre_id'), p('genre_name'), int(p('page', '1')))

    elif action == 'meta_tv_search':
        from resources.lib.metadata_router import tv_search
        tv_search(handle, build_url)

    elif action == 'meta_tv_show':
        from resources.lib.metadata_router import tv_show_detail
        tv_show_detail(handle, build_url, p('tmdb_id'))

    elif action == 'meta_tv_episodes':
        from resources.lib.metadata_router import tv_season_episodes
        tv_season_episodes(handle, build_url, p('tmdb_id'), p('season_num'),
                           p('tvdb_id'), p('show_title'), p('show_fanart'))

    elif action == 'meta_person':
        from resources.lib.metadata_router import person_movies
        person_movies(handle, build_url, p('name'), p('media_type'))

    # ── Radio ─────────────────────────────────────────────────────────────────
    elif action == 'radio_menu':
        from resources.lib.radio_router import radio_menu
        radio_menu(handle, build_url)

    elif action == 'radio_countries':
        from resources.lib.radio_router import radio_countries
        radio_countries(handle, build_url)

    elif action == 'radio_states':
        from resources.lib.radio_router import radio_states
        radio_states(handle, build_url, p('country'))

    elif action == 'radio_cities':
        from resources.lib.radio_router import radio_cities
        radio_cities(handle, build_url, p('country'), p('state'))

    elif action == 'radio_stations_city':
        from resources.lib.radio_router import radio_stations_city
        radio_stations_city(handle, build_url, p('country'), p('state'), p('city'))

    elif action == 'radio_stations_state':
        from resources.lib.radio_router import radio_stations_state
        radio_stations_state(handle, build_url, p('country'), p('state'))

    elif action == 'radio_search':
        from resources.lib.radio_router import radio_search
        radio_search(handle, build_url)

    # ── Adult ─────────────────────────────────────────────────────────────────
    elif action == 'adult_menu':
        from resources.lib.pin_lock import pin_required, prompt_pin
        from resources.lib.afdb_router import adult_menu
        if pin_required() and not prompt_pin():
            import xbmcplugin as _xp
            _xp.endOfDirectory(handle, succeeded=False)
            return
        adult_menu(handle, build_url)

    elif action == 'adult_search_unified':
        from resources.lib.afdb_router import adult_search_unified
        # 'query' carries the already-typed search text across Next Page
        # clicks (see adult_search_unified's own docstring) — empty string
        # when absent (first, keyboard-driven entry into this screen),
        # same p(k, d='') convention every other optional param here uses.
        adult_search_unified(handle, build_url, query=p('query'), page=int(p('page', '1')))

    elif action == 'adult_performer_films':
        # Reached only via a link rendered from inside the Adult custom
        # category-list view's cast strip, which itself only opens after
        # Home's own adult_enabled/PIN check has already passed — no second
        # PIN check needed here, same reasoning as adult_search_unified.
        from resources.lib.afdb_router import adult_performer_films
        adult_performer_films(handle, build_url, p('name'))

    elif action == 'javseen_play':
        # Reached only via the plugin://...?action=javseen_play URL that
        # javseen_play_direct() builds for the custom-skin category list's
        # doModal() window — already PIN-gated by that same reasoning as
        # every other adult sub-action here.
        from resources.lib.afdb_router import javseen_play
        javseen_play(handle, p('vid'), p('slug'), p('title', ''))

    elif action == 'javhd_play':
        from resources.lib.afdb_router import javhd_play
        javhd_play(handle, p('vid'), p('slug'), p('title', ''))

    elif action == 'javleak_play':
        from resources.lib.afdb_router import javleak_play
        javleak_play(handle, p('vid'), p('slug'), p('title', ''))

    elif action == 'mythav_play':
        from resources.lib.afdb_router import mythav_play
        mythav_play(handle, p('vid'), p('slug'), p('title', ''))

    elif action == 'xxxclub_browse':
        from resources.lib.afdb_router import xxxclub_browse
        xxxclub_browse(handle, build_url, cursor=p('cursor', ''))

    elif action == 'afdb_new':
        from resources.lib.afdb_router import afdb_new
        afdb_new(handle, build_url, int(p('page', '1')))

    elif action == 'afdb_popular':
        from resources.lib.afdb_router import afdb_popular
        afdb_popular(handle, build_url, int(p('page', '1')))

    elif action == 'afdb_categories':
        from resources.lib.afdb_router import afdb_categories
        afdb_categories(handle, build_url)

    elif action == 'afdb_by_category':
        from resources.lib.afdb_router import afdb_by_category
        afdb_by_category(handle, build_url, p('category'), int(p('page', '1')))

    elif action == 'afdb_studios':
        from resources.lib.afdb_router import afdb_studios
        afdb_studios(handle, build_url, p('letter', 'A'))

    elif action == 'afdb_by_studio':
        from resources.lib.afdb_router import afdb_by_studio
        afdb_by_studio(handle, build_url, p('studio'), p('studio_name'), int(p('page', '1')))

    elif action == 'afdb_actors':
        from resources.lib.afdb_router import afdb_actors
        afdb_actors(handle, build_url, p('letter', 'A'))

    elif action == 'afdb_actor_detail':
        from resources.lib.afdb_router import afdb_actor_detail
        afdb_actor_detail(handle, build_url, p('actor_id'), p('actor_slug'), p('actor_name'))

    elif action == 'afdb_actor_films':
        from resources.lib.afdb_router import afdb_actor_films
        afdb_actor_films(handle, build_url, p('actor_id'), p('actor_slug'),
                         p('actor_name'), int(p('page', '1')))

    elif action == 'afdb_search':
        from resources.lib.afdb_router import afdb_search
        afdb_search(handle, build_url)

    elif action == 'adult_movies_menu':
        from resources.lib.afdb_router import adult_movies_menu
        adult_movies_menu(handle, build_url)

    elif action == 'adult_browse_new_releases':
        from resources.lib.afdb_router import adult_browse_new_releases
        adult_browse_new_releases(handle, build_url, int(p('page', '1')))

    elif action == 'adult_browse_recently_added':
        from resources.lib.afdb_router import adult_browse_recently_added
        adult_browse_recently_added(handle, build_url, int(p('page', '1')))

    elif action == 'adult_browse_bestsellers':
        from resources.lib.afdb_router import adult_browse_bestsellers
        adult_browse_bestsellers(handle, build_url, int(p('page', '1')))

    elif action == 'adult_ade_play':
        from resources.lib.afdb_router import adult_ade_play
        adult_ade_play(handle, p('ade_id'), p('ade_slug', ''), p('title', ''))

    elif action == 'adult_favorites_list':
        from resources.lib.adult_favorites import adult_favorites_list
        adult_favorites_list(handle, build_url)

    elif action == 'adult_favorites_add':
        import urllib.parse as _up2
        from resources.lib.adult_favorites import adult_favorites_add_action
        adult_favorites_add_action(p('ade_id'), p('title', ''), p('thumb', ''), p('fanart', ''))
        import xbmcplugin as _xp2
        _xp2.endOfDirectory(handle, succeeded=False)
        return

    elif action == 'adult_favorites_remove':
        from resources.lib.adult_favorites import adult_favorites_remove_action
        adult_favorites_remove_action(p('ade_id'), p('title', ''))
        import xbmcplugin as _xp3
        _xp3.endOfDirectory(handle, succeeded=False)
        return

    elif action == 'adult_movies_library':
        from resources.lib.afdb_router import adult_movies_library
        adult_movies_library(handle, build_url, int(p('page', '1')))

    elif action == 'adult_trailers':
        from resources.lib.afdb_router import adult_trailers
        adult_trailers(handle, build_url, int(p('page', '1')))

    elif action == 'adult_streams':
        from resources.lib.afdb_router import adult_streams
        adult_streams(handle, build_url, int(p('page', '1')), xclub_cursor=p('xclub_cursor', ''))

    elif action == 'adult_free_streams':
        from resources.lib.afdb_router import adult_free_streams
        adult_free_streams(handle, build_url, int(p('page', '1')))

    elif action == 'adult_free_sites':
        from resources.lib.afdb_router import adult_free_sites
        adult_free_sites(handle, build_url)

    elif action == 'adult_panda_genres':
        from resources.lib.afdb_router import adult_panda_genres
        adult_panda_genres(handle, build_url)

    elif action == 'adult_panda_movies':
        from resources.lib.afdb_router import adult_panda_movies
        adult_panda_movies(handle, build_url, p('genre_url'), p('genre_name', ''),
                           int(p('page', '1')))

    elif action == 'adult_panda_play':
        from resources.lib.afdb_router import adult_panda_play
        adult_panda_play(handle, p('slug'), p('film_url'), p('title', ''))

    elif action == 'adult_hqp_categories':
        from resources.lib.afdb_router import adult_hqp_categories
        adult_hqp_categories(handle, build_url)

    elif action == 'adult_hqp_movies':
        from resources.lib.afdb_router import adult_hqp_movies
        adult_hqp_movies(handle, build_url, p('cat_url'), p('cat_name', ''),
                         int(p('page', '1')))

    elif action == 'adult_hqp_play':
        from resources.lib.afdb_router import adult_hqp_play
        adult_hqp_play(handle, p('slug'), p('film_url'), p('title', ''))

    elif action == 'adult_scenes_select':
        from resources.lib.afdb_router import adult_scenes_select
        adult_scenes_select(handle, build_url)

    elif action == 'adult_scene_movies':
        from resources.lib.afdb_router import adult_scene_movies
        adult_scene_movies(handle, build_url, p('site'), int(p('page', '1')))

    elif action == 'adult_scene_search':
        from resources.lib.afdb_router import adult_scene_search
        adult_scene_search(handle, build_url, p('site'))

    elif action == 'adult_scene_play':
        from resources.lib.afdb_router import adult_scene_play
        adult_scene_play(handle, p('site'), p('slug'), p('film_url'), p('title', ''))

    elif action == 'adult_tvnow_channels':
        from resources.lib.afdb_router import adult_tvnow_channels
        adult_tvnow_channels(handle, build_url)

    elif action == 'adult_requests':
        from resources.lib.afdb_router import adult_requests_list
        adult_requests_list(handle, build_url)

    elif action == 'adult_tvnow_channel_play':
        from resources.lib.afdb_router import adult_tvnow_channel_play
        adult_tvnow_channel_play(handle, p('channel_id'), p('title', ''))

    elif action == 'sports_menu':
        from resources.lib.sports_router import sports_menu
        sports_menu(handle, build_url)

    elif action == 'sports_events':
        from resources.lib.sports_router import sports_events
        sports_events(handle, build_url, p('sport_slug'), p('sport_label'), p('sport_icon'), p('tsdb_sport', ''))

    elif action == 'hockey_menu':
        from resources.lib.sports_router import hockey_menu
        hockey_menu(handle, build_url)

    elif action == 'hockey_league_events':
        from resources.lib.sports_router import hockey_league_events
        hockey_league_events(handle, build_url, p('league', 'NHL'))

    elif action == 'free_menu':
        from resources.lib.free_router import free_menu
        free_menu(handle, build_url)

    elif action == 'free_services':
        from resources.lib.free_router import free_services
        free_services(handle, build_url, p('media_type', 'movies'))

    elif action == 'free_browse':
        from resources.lib.free_router import free_browse
        free_browse(handle, build_url, p('service_id'), p('media_type', 'movies'),
                    int(p('page', '1')))

    elif action == 'afdb_detail':
        from resources.lib.afdb_router import afdb_detail
        afdb_detail(handle, build_url, p('film_id'), p('film_slug'), p('film_title'))

    else:
        xbmc.log('[Starfleet/Home] action not managed %s => main menu' % action, xbmc.LOGWARNING)
        from resources.lib.router import main_menu
        main_menu(handle, build_url)
