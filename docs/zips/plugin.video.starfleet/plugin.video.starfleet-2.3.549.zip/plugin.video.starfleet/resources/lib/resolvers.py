# -*- coding: utf-8 -*-
"""
resources/lib/resolvers.py

Premium link resolver integration. Back to native credential storage in
this addon's own settings.xml (Settings → Premium Services) — the brief
ResolveURL-delegation approach ("pair everything in ResolveURL's own
settings screen instead") turned out to not actually work for pairing
Real-Debrid/AllDebrid/Premiumize/TorBox in practice, so this reverts to
each service's own enable-toggle + API-key field entered directly here,
same as before that change. MegaDebrid and SimplyDebrid (added alongside
that ResolveURL-delegation attempt) are kept as extra services, but now
also with their own native username/password fields here instead of
ResolveURL's settings.

Supported services (link-unrestrict — resolving an already-scraped hoster
link to a direct stream; magnet/torrent resolution is a separate concern
still handled natively in debrid_torrent.py):
  Real-Debrid   — plain API key   (real-debrid.com/apitoken)
  AllDebrid     — plain API key   (alldebrid.com/apikeys)
  Premiumize    — plain API key   (premiumize.me/account)
  TorBox        — plain API key   (torbox.app/settings)
  MegaDebrid    — username/password
  SimplyDebrid  — username/password
  ResolveURL    — generic 50+ hoster fallback (unchanged — still a hard
                  addon dependency, still tried last for hosters none of
                  the six services above specifically handle)

Resolution priority is configurable in Settings → Premium Services.
"""

import xbmc
import xbmcaddon
import xbmcgui

ADDON = xbmcaddon.Addon('plugin.video.starfleet')

import requests as _req

_HEADERS = {'User-Agent': 'plugin.video.starfleet/1.0'}

import re as _re

# Confirmed live 2026-08-15 via kodi.log: debrid_torrent.py already rejects a
# magnet whose own dn= display name ends in one of these extensions before
# ever resolving it (get_debrid_streams' _is_fake) - but that's the torrent's
# own ADVERTISED name, checked before resolution. It says nothing about what
# file debrid actually hands back once resolved, and a real scam-torrent
# pattern is exactly this mismatch: a magnet advertised as "The Odyssey 2026
# 2160p...", real enough to pass every title/quality filter, whose actual
# served file is a disguised .exe (malware, or a fake "codec" trick) -
# confirmed live, TWO different Premiumize-resolved candidates in a row for
# the same title both ended "...EZTV.exe", and Kodi's demuxer correctly
# refused to play either (error probing input format) rather than silently
# accepting it, but nothing checked that as a failed candidate to move past -
# the resolve just returned the bad URL as a "success". Same extension list
# as _is_fake, applied to the RESOLVED URL's own path (not the whole URL, to
# avoid a false match against an unrelated substring in the domain/CDN
# path/query string) before ever accepting a resolve result, in both the
# quick-check (resolve_magnet_candidates) and slow (_resolve_magnet_slow)
# paths.
_RE_BAD_STREAM_EXT = _re.compile(r'\.(?:exe|zip|rar|bat|msi|dmg|apk|iso|7z|tar|gz)(?:\?|$)', _re.IGNORECASE)
def _resolved_is_fake(url):
    try:
        import urllib.parse as _ul
        path = _ul.urlparse(url).path
        return bool(_RE_BAD_STREAM_EXT.search(_ul.unquote(path)))
    except Exception:
        return False


def _priority(): return int(ADDON.getSetting('resolver_priority') or 6)


def _ru_token(resolver_class):
    """Fallback-only credential source: if this addon's own API-key field
    for a service is empty, and a separate, independently-maintained hoster
    resolver module is installed and already paired for that same service,
    borrow its stored token instead of requiring the user to copy the same
    key into two places. Never overrides an already-configured native key,
    never enables a service that isn't explicitly turned on here — purely
    fills in a credential gap when possible. Wrapped so any failure here
    (module not installed, settings API shape changes) just yields '' and
    falls through to "not configured" like before, never raises.
    Real-Debrid is deliberately excluded from this — its token there can be
    a short-lived OAuth access token that module refreshes internally on
    its own schedule; borrowing it as a static Bearer value risks silently
    breaking once it expires, since nothing here would ever refresh it."""
    try:
        if not xbmc.getCondVisibility("System.HasAddon(script.module.resolveurl)"):
            return ''
        addon = xbmcaddon.Addon('script.module.resolveurl')
        return (addon.getSetting('%s_token' % resolver_class) or '').strip()
    except Exception:
        return ''


# ── Real-Debrid ───────────────────────────────────────────────────────────────

RD_BASE = 'https://api.real-debrid.com/rest/1.0'

def _rd_token(): return ADDON.getSetting('rd_api_key').strip()
def _rd_on():    return ADDON.getSetting('rd_enabled') == 'true' and bool(_rd_token())


def _rd_unrestrict(url):
    """POST to Real-Debrid /unrestrict/link → returns direct download URL."""
    try:
        r = _req.post(
            RD_BASE + '/unrestrict/link',
            data={'link': url},
            headers={**_HEADERS, 'Authorization': 'Bearer %s' % _rd_token()},
            timeout=10
        )
        if r.status_code == 200:
            link = r.json().get('download', '')
            if link:
                xbmc.log('[Starfleet] Real-Debrid resolved: %s' % link[:60], xbmc.LOGINFO)
                return link
            xbmc.log('[Starfleet] Real-Debrid: no download link in response', xbmc.LOGWARNING)
        elif r.status_code == 401:
            xbmc.log('[Starfleet] Real-Debrid: API key invalid/expired — check Settings → Premium Services',
                     xbmc.LOGERROR)
        elif r.status_code == 403:
            xbmc.log('[Starfleet] Real-Debrid: hoster not supported or traffic exhausted',
                     xbmc.LOGWARNING)
        else:
            xbmc.log('[Starfleet] Real-Debrid HTTP %d: %s' % (r.status_code, r.text[:100]),
                     xbmc.LOGWARNING)
    except Exception as e:
        xbmc.log('[Starfleet] Real-Debrid error: %s' % e, xbmc.LOGERROR)
    return None


# ── AllDebrid ─────────────────────────────────────────────────────────────────

AD_BASE = 'https://api.alldebrid.com/v4'

def _ad_token(): return ADDON.getSetting('ad_api_key').strip() or _ru_token('AllDebridResolver')
def _ad_on():    return ADDON.getSetting('ad_enabled') == 'true' and bool(_ad_token())


def _ad_unrestrict(url):
    """GET AllDebrid /link/unlock → returns direct stream URL."""
    try:
        r = _req.get(
            AD_BASE + '/link/unlock',
            params={'agent': 'starfleet', 'apikey': _ad_token(), 'link': url},
            headers=_HEADERS,
            timeout=10
        )
        if r.status_code == 200:
            data = r.json()
            if data.get('status') == 'success':
                link = data.get('data', {}).get('link', '')
                if link:
                    xbmc.log('[Starfleet] AllDebrid resolved: %s' % link[:60], xbmc.LOGINFO)
                    return link
            else:
                err = data.get('error', {}).get('message', 'unknown error')
                xbmc.log('[Starfleet] AllDebrid error: %s' % err, xbmc.LOGWARNING)
    except Exception as e:
        xbmc.log('[Starfleet] AllDebrid error: %s' % e, xbmc.LOGERROR)
    return None


# ── Premiumize ────────────────────────────────────────────────────────────────

PM_BASE = 'https://www.premiumize.me/api'

def _pm_token(): return ADDON.getSetting('pm_api_key').strip() or _ru_token('PremiumizeMeResolver')
def _pm_on():    return ADDON.getSetting('pm_enabled') == 'true' and bool(_pm_token())


def _pm_unrestrict(url):
    """POST to Premiumize /transfer/directdl → returns direct stream URL."""
    try:
        r = _req.post(
            PM_BASE + '/transfer/directdl',
            data={'apikey': _pm_token(), 'src': url},
            headers=_HEADERS,
            timeout=10
        )
        if r.status_code == 200:
            data = r.json()
            if data.get('status') == 'success':
                content = data.get('content', [])
                if content:
                    link = content[0].get('stream_link') or content[0].get('link', '')
                    if link:
                        xbmc.log('[Starfleet] Premiumize resolved: %s' % link[:60],
                                 xbmc.LOGINFO)
                        return link
            else:
                xbmc.log('[Starfleet] Premiumize: %s' % data.get('message', ''),
                         xbmc.LOGWARNING)
    except Exception as e:
        xbmc.log('[Starfleet] Premiumize error: %s' % e, xbmc.LOGERROR)
    return None


# ── TorBox ────────────────────────────────────────────────────────────────────

TB_BASE = 'https://api.torbox.app/v1/api'

def _tb_key(): return ADDON.getSetting('tb_api_key').strip() or _ru_token('TorBoxResolver')
def _tb_on():  return ADDON.getSetting('tb_enabled') == 'true' and bool(_tb_key())


def _tb_unrestrict(url):
    """POST to TorBox /link/unblock → returns direct stream URL."""
    try:
        r = _req.post(
            TB_BASE + '/link/unblock',
            json={'link': url},
            headers={**_HEADERS, 'Authorization': 'Bearer %s' % _tb_key()},
            timeout=10
        )
        if r.status_code == 200:
            data = r.json()
            if data.get('success'):
                link = data.get('data', '')
                if isinstance(link, dict):
                    link = link.get('url', link.get('link', ''))
                if link:
                    xbmc.log('[Starfleet] TorBox resolved: %s' % str(link)[:60], xbmc.LOGINFO)
                    return link
                xbmc.log('[Starfleet] TorBox: success but no link in response', xbmc.LOGWARNING)
            else:
                detail = data.get('detail', 'unknown error')
                xbmc.log('[Starfleet] TorBox: %s' % detail, xbmc.LOGWARNING)
        elif r.status_code == 401:
            xbmc.log('[Starfleet] TorBox: invalid API key — check Settings → Premium Services',
                     xbmc.LOGERROR)
        else:
            xbmc.log('[Starfleet] TorBox HTTP %d: %s' % (r.status_code, r.text[:100]),
                     xbmc.LOGWARNING)
    except Exception as e:
        xbmc.log('[Starfleet] TorBox error: %s' % e, xbmc.LOGERROR)
    return None


# ── MegaDebrid ────────────────────────────────────────────────────────────────
# Username/password, not a static API key — needs its own lightweight
# session-login step before each resolve (same endpoint/params ResolveURL's
# own MegaDebridResolver.login() uses internally).

MD_BASE = 'https://www.mega-debrid.eu/api.php'

def _md_creds():
    return (ADDON.getSetting('md_username').strip(),
            ADDON.getSetting('md_password').strip())


def _md_on():
    u, p = _md_creds()
    return ADDON.getSetting('md_enabled') == 'true' and bool(u) and bool(p)


def _md_login():
    u, p = _md_creds()
    if not u or not p:
        return None
    try:
        r = _req.post(MD_BASE, params={'action': 'connectUser'},
                      data={'login': u, 'password': p}, headers=_HEADERS, timeout=10)
        data = r.json()
        if data.get('response_code') == 'ok':
            return data.get('token')
        xbmc.log('[Starfleet] MegaDebrid login failed: %s' % data.get('response_text', ''),
                 xbmc.LOGWARNING)
    except Exception as e:
        xbmc.log('[Starfleet] MegaDebrid login error: %s' % e, xbmc.LOGERROR)
    return None


def _md_unrestrict(url):
    token = _md_login()
    if not token:
        return None
    try:
        r = _req.post(MD_BASE, params={'action': 'getLink', 'token': token},
                      data={'link': url}, headers=_HEADERS, timeout=10)
        data = r.json()
        if data.get('response_code') == 'ok' and data.get('debridLink'):
            link = data['debridLink'].strip('"')
            if link.startswith('http'):
                xbmc.log('[Starfleet] MegaDebrid resolved: %s' % link[:60], xbmc.LOGINFO)
                return link
        xbmc.log('[Starfleet] MegaDebrid: %s' % data.get('response_text', 'no link in response'),
                 xbmc.LOGWARNING)
    except Exception as e:
        xbmc.log('[Starfleet] MegaDebrid error: %s' % e, xbmc.LOGERROR)
    return None


# ── SimplyDebrid ──────────────────────────────────────────────────────────────
# Same username/password + fresh-session-login pattern as MegaDebrid above.

SD_BASE = 'https://simply-debrid.com/kapi.php'

def _sd_creds():
    return (ADDON.getSetting('sd_username').strip(),
            ADDON.getSetting('sd_password').strip())


def _sd_on():
    u, p = _sd_creds()
    return ADDON.getSetting('sd_enabled') == 'true' and bool(u) and bool(p)


def _sd_login():
    u, p = _sd_creds()
    if not u or not p:
        return None
    try:
        r = _req.get(SD_BASE, params={'action': 'login', 'u': u, 'p': p},
                     headers=_HEADERS, timeout=10)
        data = r.json()
        if not data.get('error'):
            return data.get('token')
        xbmc.log('[Starfleet] SimplyDebrid login failed: %s' % data.get('message', ''),
                 xbmc.LOGWARNING)
    except Exception as e:
        xbmc.log('[Starfleet] SimplyDebrid login error: %s' % e, xbmc.LOGERROR)
    return None


def _sd_unrestrict(url):
    token = _sd_login()
    if not token:
        return None
    try:
        r = _req.get(SD_BASE, params={'action': 'generate', 'u': url, 'token': token},
                     headers=_HEADERS, timeout=10)
        data = r.json()
        if not data.get('error') and data.get('link'):
            xbmc.log('[Starfleet] SimplyDebrid resolved: %s' % data['link'][:60], xbmc.LOGINFO)
            return data['link']
        xbmc.log('[Starfleet] SimplyDebrid: %s' % data.get('message', 'no link in response'),
                 xbmc.LOGWARNING)
    except Exception as e:
        xbmc.log('[Starfleet] SimplyDebrid error: %s' % e, xbmc.LOGERROR)
    return None


def any_debrid_enabled():
    """True if the user has any real-debrid-style service enabled and
    configured at all. Used to decide whether Elementum is ever an
    acceptable magnet fallback: per explicit instruction, once ANY debrid
    service is
    enabled, a magnet should never fall through to Elementum just because
    THIS particular torrent wasn't resolvable via debrid within the poll
    window — it should fail cleanly instead. Elementum stays the fallback
    only when no debrid service is configured at all."""
    return _rd_on() or _ad_on() or _pm_on() or _tb_on() or _md_on() or _sd_on()


# ── ResolveURL (Kodi addon fallback) ─────────────────────────────────────────

def _resolveurl(url):
    """Try Kodi's ResolveURL addon as last-resort resolver — its own
    generic multi-resolver dispatch, for the 50+ hosters none of the six
    services above specifically handle."""
    try:
        import resolveurl
        hmf = resolveurl.HostedMediaFile(url)
        if hmf.valid_url():
            resolved = hmf.resolve()
            if resolved:
                xbmc.log('[Starfleet] ResolveURL resolved: %s' % str(resolved)[:60],
                         xbmc.LOGINFO)
                return resolved
    except ImportError:
        xbmc.log('[Starfleet] ResolveURL not installed', xbmc.LOGINFO)
    except Exception as e:
        xbmc.log('[Starfleet] ResolveURL error: %s' % e, xbmc.LOGWARNING)
    return None


# ── Main public resolver ──────────────────────────────────────────────────────

def resolve(url):
    """
    Attempt to resolve a URL through enabled premium services in priority order.
    Returns resolved direct URL, or original URL if nothing resolves it.

    Priority order (from Settings → Premium Services):
      0 = Real-Debrid first     3 = TorBox first
      1 = AllDebrid first       4 = MegaDebrid first
      2 = Premiumize first      5 = SimplyDebrid first
      6 = ResolveURL auto (tries all enabled, no preference)
    """
    if not url:
        return url

    if _is_direct(url):
        xbmc.log('[Starfleet] Direct URL — skipping resolvers', xbmc.LOGINFO)
        return url

    priority = _priority()

    resolvers = []

    _all_premium = [
        ('Real-Debrid',  _rd_unrestrict, _rd_on),
        ('AllDebrid',    _ad_unrestrict, _ad_on),
        ('Premiumize',   _pm_unrestrict, _pm_on),
        ('TorBox',       _tb_unrestrict, _tb_on),
        ('MegaDebrid',   _md_unrestrict, _md_on),
        ('SimplyDebrid', _sd_unrestrict, _sd_on),
    ]

    if priority < len(_all_premium):
        chosen = _all_premium[priority]
        if chosen[2]():
            resolvers.append((chosen[0], chosen[1]))
        for name, fn, check in _all_premium:
            if name != chosen[0] and check():
                resolvers.append((name, fn))
    else:
        for name, fn, check in _all_premium:
            if check():
                resolvers.append((name, fn))

    resolvers.append(('ResolveURL', _resolveurl))

    for name, fn in resolvers:
        xbmc.log('[Starfleet] Trying resolver: %s for %s' % (name, url[:60]), xbmc.LOGINFO)
        result = fn(url)
        if result:
            return result

    xbmc.log('[Starfleet] No resolver succeeded — playing direct: %s' % url[:60],
             xbmc.LOGWARNING)
    return url


def resolve_magnet_candidates(magnet_urls, season=None, episode=None):
    """Try several candidate magnets (same quality tier, chosen one first)
    for an instantly-cached hit before ever committing to a real wait.

    Confirmed live that a hard-coded fixed poll on the ONE torrent the user
    happened to click is a bad bet on its own — with dozens of same-quality
    candidates now surfaced per search, it's far better to quickly check
    several of them (upload + one immediate status read, no polling loop)
    and play whichever is already cached, than to gamble everything on a
    single pick. Falls back to the original slow behavior (a real poll with
    a visible, cancellable progress dialog) on just the FIRST candidate
    (the one actually chosen) only if none of them are quick-cached —
    same "only resolves what's really there, never a silent Elementum
    fallback once debrid is on" contract as before.

    magnet_urls: non-empty list of magnet: URIs, first one is the user's
    actual pick; the rest are same-quality-tier alternates to try fast.

    season/episode (TV only) get passed all the way down to each debrid
    service's own file-selection logic — a magnet correctly matched as
    the right show can still be a season pack with one file per episode,
    and picking "just the biggest/first file" with no regard for which
    episode that actually is was a real, confirmed bug (a Comet-sourced
    season pack playing an entirely different episode than requested)."""
    magnet_urls = [m for m in (magnet_urls or []) if m and m.startswith('magnet:')]
    if not magnet_urls:
        return None

    from resources.lib import debrid_torrent as _dt

    def _hash_of(m):
        hm = _re.search(r'btih:([a-fA-F0-9]{32,40})', m, _re.IGNORECASE)
        return hm.group(1).lower() if hm else ''

    _fast_capable = [
        ('Real-Debrid', _dt.rd_magnet_quick_check, _rd_on),
        ('AllDebrid',   _dt.ad_magnet_quick_check, _ad_on),
        ('Premiumize',  _dt.pm_magnet_to_stream,   _pm_on),
        ('TorBox',      _dt.tb_magnet_to_stream,   _tb_on),
    ]
    fast_enabled = [(name, fn) for name, fn, check in _fast_capable if check()]
    if fast_enabled:
        for m in magnet_urls:
            ih = _hash_of(m)
            for name, fn in fast_enabled:
                try:
                    result = fn(m, ih, season=season, episode=episode)
                except Exception as e:
                    xbmc.log('[Starfleet] quick-check %s error: %s' % (name, e), xbmc.LOGWARNING)
                    result = None
                if result and _resolved_is_fake(result):
                    xbmc.log('[Starfleet] %s quick-check resolved a non-video file (candidate %d/%d) - '
                             'skipping: %s' % (name, magnet_urls.index(m) + 1, len(magnet_urls), result[:120]),
                             xbmc.LOGWARNING)
                    continue
                if result:
                    xbmc.log('[Starfleet] Magnet resolved via %s quick-check (candidate %d/%d)' %
                             (name, magnet_urls.index(m) + 1, len(magnet_urls)), xbmc.LOGINFO)
                    return result

    # None of the candidates were already cached — fall back to a real,
    # visible wait on just the one the user actually picked.
    return _resolve_magnet_slow(magnet_urls[0], season=season, episode=episode)


def resolve_magnet(magnet_url, season=None, episode=None):
    """Single-magnet convenience wrapper — see resolve_magnet_candidates
    (the real entry point now) for the fast-pass-then-slow-fallback logic."""
    return resolve_magnet_candidates([magnet_url], season=season, episode=episode)


def resolve_nzb(nzb_url, title='', media_type='movie', season=None, episode=None):
    """Resolve a Usenet .nzb download URL to a playable stream via
    Premiumize or TorBox — the only two debrid services here with any
    Usenet support at all (Real-Debrid/AllDebrid have none, confirmed
    live).

    title/media_type/season/episode matter here, not just for display -
    Premiumize's own NZB uploads all land in one shared account folder
    (confirmed live), so debrid_torrent.py needs the real title/episode to
    pick the correct file back out of that folder instead of just
    grabbing whatever happens to be biggest, which can be a leftover from
    a completely different, earlier search.

    Shows a real progress dialog (with cancel) the same way magnet
    resolution does — confirmed live this is NOT an instant lookup like
    magnet cache-checks are: Premiumize has no shared cache for Usenet
    content, so resolving an NZB means a genuine real-time download from
    Usenet on Premiumize's end, taking well over a minute for a
    few-gigabyte episode. A silent blocking call here would look
    indistinguishable from a hang."""
    if not nzb_url:
        return None
    from resources.lib import debrid_torrent as _dt

    try:
        from resources.lib.gui import progress_dialog as _pdlg
        dlg = _pdlg.get_native()
        dlg.create('Starfleet', 'Resolving NZB…')
    except Exception:
        dlg = None

    def _progress_cb(message, percent):
        if dlg is None:
            return True
        if dlg.iscanceled():
            return False
        dlg.update(percent, message)
        return True

    try:
        return _dt.resolve_nzb(nzb_url, progress_cb=_progress_cb, title=title,
                                media_type=media_type, season=season, episode=episode) or None
    finally:
        if dlg is not None:
            dlg.close()


def _resolve_magnet_slow(magnet_url, season=None, episode=None):
    """Attempt to resolve a raw magnet: URI through whichever enabled
    premium services actually have real torrent-to-stream support,
    respecting the same Settings -> Premium Services priority order
    resolve() uses. Only ever resolves instantly-cached torrents (no
    waiting for a real download — not a reasonable "press play" wait), so
    this correctly returns None for a magnet none of the enabled services
    already have cached, and the caller should fall back to Elementum in
    that case.

    Delegates to debrid_torrent.py's rd/ad/pm/tb_magnet_to_stream — those
    keep their own native torrent-upload/poll implementations (MegaDebrid
    and SimplyDebrid have no torrent-caching backend of their own, only
    plain link-unrestrict, so they're link-only and never appear here)."""
    if not magnet_url or not magnet_url.startswith('magnet:'):
        return None

    from resources.lib import debrid_torrent as _dt
    import re as _re
    _hm = _re.search(r'btih:([a-fA-F0-9]{32,40})', magnet_url, _re.IGNORECASE)
    info_hash = _hm.group(1).lower() if _hm else ''

    priority = _priority()
    _magnet_capable = [
        ('Real-Debrid', _dt.rd_magnet_to_stream, _rd_on),
        ('AllDebrid',   _dt.ad_magnet_to_stream, _ad_on),
        ('Premiumize',  _dt.pm_magnet_to_stream, _pm_on),
        ('TorBox',      _dt.tb_magnet_to_stream, _tb_on),
    ]

    ordered = []
    if priority < len(_magnet_capable):
        chosen = _magnet_capable[priority]
        if chosen[2]():
            ordered.append((chosen[0], chosen[1]))
        for name, fn, check in _magnet_capable:
            if name != chosen[0] and check():
                ordered.append((name, fn))
    else:
        for name, fn, check in _magnet_capable:
            if check():
                ordered.append((name, fn))

    if not ordered:
        return None

    try:
        from resources.lib.gui import progress_dialog as _pdlg
        dlg = _pdlg.get_native()
        # This function is only ever reached after every enabled service's
        # own fast "already cached?" quick-check already said no (see
        # resolve_magnet_candidates above) — confirmed live 2026-08-16 via
        # a real debug log that this can mean a genuine 60-90+ second real
        # download on the debrid service's own end, not a hang. The old
        # generic "Checking debrid services…" message looked identical to
        # the fast quick-check phase that had already finished, which read
        # as stuck/broken rather than genuinely working - worth being
        # upfront about here since this IS the slow path.
        dlg.create('Starfleet', 'Not instantly cached — resolving now (can take a minute)…')
    except Exception:
        dlg = None

    def _progress_cb(message, percent):
        if dlg is None:
            return True
        if dlg.iscanceled():
            return False
        dlg.update(percent, message)
        return True

    try:
        for name, fn in ordered:
            xbmc.log('[Starfleet] Trying %s for magnet: %s' % (name, magnet_url[:60]), xbmc.LOGINFO)
            if dlg is not None:
                dlg.update(0, 'Checking %s…' % name)
                if dlg.iscanceled():
                    break
            result = fn(magnet_url, info_hash, progress_cb=_progress_cb, season=season, episode=episode)
            if result and _resolved_is_fake(result):
                xbmc.log('[Starfleet] %s resolved a non-video file - skipping: %s' %
                         (name, result[:120]), xbmc.LOGWARNING)
                continue
            if result:
                return result

        # None of our own hand-rolled implementations above resolved this
        # magnet. Last-resort fallback (only if a separate, independently-
        # maintained hoster-resolver module is installed): let it try its
        # own torrent-capable resolvers for whichever debrid service is
        # configured there. Purely additive — never runs unless everything
        # above already failed, and any problem here just falls through to
        # the existing "return None" -> Elementum path exactly as before.
        if (dlg is None or not dlg.iscanceled()) and \
           xbmc.getCondVisibility("System.HasAddon(script.module.resolveurl)"):
            if dlg is not None:
                dlg.update(0, 'Checking additional services…')
            try:
                import resolveurl
                stream = resolveurl.resolve(magnet_url)
                if stream and isinstance(stream, str) and not _resolved_is_fake(stream):
                    xbmc.log('[Starfleet] Magnet resolved via resolveurl fallback', xbmc.LOGINFO)
                    return stream
            except Exception as e:
                xbmc.log('[Starfleet] resolveurl magnet fallback error: %s' % e, xbmc.LOGWARNING)
    finally:
        if dlg is not None:
            dlg.close()

    return None


def _is_direct(url):
    """Return True if the URL looks like a direct streamable file.

    Real bug fixed 2026-09-04: this addon's own pipe-tagged URL convention
    (url|Referer=...&User-Agent=...) — used throughout for direct CDN
    stream links, e.g. every DLHD/daddylive-resolved channel — always
    failed both checks below, since the extension check needs the URL to
    literally END in e.g. '.m3u8' and this addon's own suffix defeats
    that. Confirmed live via kodi.log: a real, already-resolved DLHD
    channel URL got sent through AllDebrid/Premiumize/ResolveURL first
    (all correctly rejecting it, since it's not an embed-host page at
    all) before finally falling through to "no resolver succeeded,
    playing direct" anyway — wasted round trips and real added latency on
    every single DLHD/daddylive channel play, not a cosmetic issue.
    Stripping this addon's own pipe-tag suffix before checking fixes it
    at the source rather than special-casing every caller."""
    url_lower = url.split('|', 1)[0].lower()
    direct_exts   = ('.m3u8', '.mp4', '.mkv', '.avi', '.mov', '.ts',
                     '.mpd', '.f4v', '.flv', '.webm')
    direct_hosts  = ('akamaized.net', 'cdn.', 'cloudfront.net',
                     'dai.google.com', 'pluto.tv', 'plex.tv',
                     'samsung.com', 'plutotv.com')
    if any(url_lower.endswith(ext) or (ext + '?') in url_lower
           for ext in direct_exts):
        return True
    if any(h in url_lower for h in direct_hosts):
        return True
    return False


# ── Account info helpers (for settings display) ───────────────────────────────

def check_rd():
    """Return Real-Debrid account info dict or None."""
    if not _rd_on():
        return None
    try:
        r = _req.get(RD_BASE + '/user',
                     headers={**_HEADERS, 'Authorization': 'Bearer %s' % _rd_token()},
                     timeout=8)
        if r.status_code == 200:
            return r.json()
    except Exception:
        pass
    return None


def check_ad():
    """Return AllDebrid user info dict or None."""
    if not _ad_on():
        return None
    try:
        r = _req.get(AD_BASE + '/user',
                     params={'agent': 'starfleet', 'apikey': _ad_token()},
                     headers=_HEADERS, timeout=8)
        if r.status_code == 200:
            data = r.json()
            if data.get('status') == 'success':
                return data.get('data', {}).get('user', {})
    except Exception:
        pass
    return None


def check_pm():
    """Return Premiumize account info dict or None."""
    if not _pm_on():
        return None
    try:
        r = _req.get(PM_BASE + '/account/info',
                     params={'apikey': _pm_token()}, headers=_HEADERS, timeout=8)
        if r.status_code == 200:
            data = r.json()
            if data.get('status') == 'success':
                return data
    except Exception:
        pass
    return None


def check_tb():
    """Return TorBox user info dict or None."""
    if not _tb_on():
        return None
    try:
        r = _req.get(TB_BASE + '/user/me',
                     params={'settings': 'false'},
                     headers={**_HEADERS, 'Authorization': 'Bearer %s' % _tb_key()},
                     timeout=8)
        if r.status_code == 200:
            data = r.json()
            if data.get('success'):
                return data.get('data', {})
    except Exception:
        pass
    return None


def check_md():
    """Return True if MegaDebrid login currently succeeds, else None."""
    if not _md_on():
        return None
    return {'ok': True} if _md_login() else None


def check_sd():
    """Return True if SimplyDebrid login currently succeeds, else None."""
    if not _sd_on():
        return None
    return {'ok': True} if _sd_login() else None


def show_account_status():
    """Show a dialog with status of all enabled premium services."""
    lines = ['[B]Premium Service Status[/B]\n']

    if _rd_on():
        info = check_rd()
        if info:
            expiry  = info.get('expiration', '')[:10]
            premium = '✅ Premium' if info.get('type') == 'premium' else '⚠️ Free'
            lines.append('Real-Debrid: %s (expires %s)' % (premium, expiry))
        else:
            lines.append('Real-Debrid: ❌ Auth failed — check API key in Settings')
    else:
        lines.append('Real-Debrid: not paired')

    if _ad_on():
        info = check_ad()
        if info:
            expiry = info.get('premiumUntil', '')
            lines.append('AllDebrid: ✅ %s (expires %s)' % (
                info.get('username', ''), expiry))
        else:
            lines.append('AllDebrid: ❌ Auth failed — check API key in Settings')
    else:
        lines.append('AllDebrid: not paired')

    if _pm_on():
        info = check_pm()
        if info:
            used  = info.get('space_used_bytes', 0)
            total = info.get('space_limit_bytes', 1)
            pct   = int(used / total * 100) if total else 0
            lines.append('Premiumize: ✅ %s — storage %d%% used' % (
                info.get('customer_id', ''), pct))
        else:
            lines.append('Premiumize: ❌ Auth failed — check API key in Settings')
    else:
        lines.append('Premiumize: not paired')

    if _tb_on():
        info = check_tb()
        if info:
            plan = info.get('plan', 0)
            plan_label = {0: 'Free', 1: 'Essential', 2: 'Pro', 3: 'Standard'}.get(plan, 'Unknown')
            expiry = str(info.get('premium_expires_at', ''))[:10]
            lines.append('TorBox: ✅ %s — %s (expires %s)' % (
                info.get('email', ''), plan_label, expiry))
        else:
            lines.append('TorBox: ❌ Auth failed — check API key in Settings')
    else:
        lines.append('TorBox: not paired')

    if _md_on():
        lines.append('MegaDebrid: ✅ login OK' if check_md() else
                     'MegaDebrid: ❌ Login failed — check username/password in Settings')
    else:
        lines.append('MegaDebrid: not paired')

    if _sd_on():
        lines.append('SimplyDebrid: ✅ login OK' if check_sd() else
                     'SimplyDebrid: ❌ Login failed — check username/password in Settings')
    else:
        lines.append('SimplyDebrid: not paired')

    if not any_debrid_enabled():
        lines.append('\nNo premium services paired yet.')
        lines.append('Settings → Premium Services → Open ResolveURL Settings.')

    xbmcgui.Dialog().textviewer('Starfleet — Premium Services', '\n'.join(lines))
