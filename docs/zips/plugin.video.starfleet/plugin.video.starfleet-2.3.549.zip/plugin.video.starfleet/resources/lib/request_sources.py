# -*- coding: utf-8 -*-
"""
resources/lib/request_sources.py

"Requests" — hand-organized movie/TV/adult titles living directly in the
user's own Streamtape and MixDrop accounts (Settings > Personal Sources —
same credentials personal_sources.py already uses for its fuzzy-match
"[Personal]" source), scraped and exact-matched here instead of relying on
an external orchestrator PC that pre-scraped the same folders into a JSON
file published to this repo's data/ folder (the previous design). Matched
precisely by the id embedded in each file/folder's own name, not fuzzy
title search:
  - Movies: Movies/ folder, files named "tt1234567 Title.ext"
             → matched by imdb_id (e.g. "tt20912374")
  - TV:     TV Shows/ folder, one subfolder per show ("tt1234567 Show
             Title") → season subfolder(s) → episode files named
             "tt1234567 s01e06[...]"  → matched by show title (normalised)
             + season + episode (season/episode always read straight off
             the episode filename itself, not the season folder's own
             name, which was found live to be inconsistently named —
             sometimes duplicated as both "Season N" and "tt... Season N"
             for the same season, sometimes present with zero files in
             either)
  - Adult:  Porn/Movies/ folder specifically (not Scenes/3D porn — those
             are covered by this addon's other adult scrapers already),
             files named "<adc_id> Title.ext" → matched by AdultDVDEmpire's
             own numeric film id (the same "ade_id"/"film_id" ade.py
             already uses)

Every entry's own url(s) are handed to ResolveURL exactly like every other
embed source in this addon — streamtape.com/mxdrop.sx are both standard
ResolveURL-supported hosts, no custom per-host logic needed here.

An entry can carry ONE source ("url": "...", a plain string) or SEVERAL
("urls": [...], a list) — built here as "urls" whenever a title/episode
exists on both hosts (matched by the same id), so the same file mirrored
on Streamtape and MixDrop shows as two [Request] rows in the source
picker instead of one host silently shadowing the other. entry_urls()
below is the one place that reads either shape, so every caller gets a
plain list regardless of which shape a given entry carries.

Low-level Streamtape/MixDrop folder listing, credential storage, and
caching are all reused from personal_sources.py rather than duplicated
here — see that module for the actual API calls.
"""
import html
import re
import unicodedata
import xbmc
import xbmcaddon
import xbmcvfs

ADDON    = xbmcaddon.Addon('plugin.video.starfleet')
_PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))

from resources.lib import cache as _cache
_cache.init(_PROFILE + '/cache.db')

# Full account scan (a handful of folder listings for Movies/Adult, up to a
# couple hundred for TV Shows' per-show recursion) is heavier than the old
# design's single small JSON fetch, but personal_sources.py's own
# per-folder listing cache (1h) means only the FIRST build after this
# outer cache expires actually hits the network for most folders — this
# just bounds how often that first, slightly heavier build happens.
_TTL = 15 * 60

_RE_MOVIE_FILE   = re.compile(r'^(tt\d+)\s+(.+?)(?:\.(?:mp4|mkv|avi|mov|wmv|m4v|ts))?$', re.IGNORECASE)
_RE_ADULT_FILE   = re.compile(r'^(\d{4,9})\s+(.+?)(?:\.(?:mp4|mkv|avi|mov|wmv|m4v|ts))?$', re.IGNORECASE)
_RE_SHOW_FOLDER  = re.compile(r'^(tt\d+)\s+(.+)$', re.IGNORECASE)
_RE_EPISODE_FILE = re.compile(r'^(tt\d+)\s+[Ss](\d{1,3})[Ee](\d{1,3})', re.IGNORECASE)


def _norm_title(t):
    t = (t or '').lower()
    t = ''.join(c for c in unicodedata.normalize('NFD', t) if unicodedata.category(c) != 'Mn')
    return re.sub(r'[^a-z0-9 ]', '', t).strip()


def _norm_tt(s):
    return (s or '').strip().lower()


def _clean_name(raw):
    return html.unescape((raw or '').strip())


def _cache_wrap(key, builder):
    cached = _cache.get(key)
    if cached is not None:
        return cached
    try:
        data = builder()
    except Exception as e:
        xbmc.log('[Starfleet/Requests] %s build error: %s' % (key, e), xbmc.LOGWARNING)
        data = []
    _cache.set(key, data, _TTL if data else 60)
    return data


# ── Movies ───────────────────────────────────────────────────────────────────

def _build_movie_requests():
    from resources.lib import personal_sources as _ps
    entries = {}

    def _add(tt_id, title, url):
        if not tt_id or not url:
            return
        tt_id = _norm_tt(tt_id)
        e = entries.setdefault(tt_id, {'imdb_id': tt_id, 'title': '', 'urls': []})
        if title and not e['title']:
            e['title'] = title
        if url not in e['urls']:
            e['urls'].append(url)

    try:
        md_ref = _ps._md_root_folders().get('movies')
        if md_ref:
            _, files = _ps._md_list_folder(md_ref)
            for f in files:
                name = _clean_name(f.get('title') or f.get('name'))
                m = _RE_MOVIE_FILE.match(name)
                if m:
                    _add(m.group(1), m.group(2).strip(), f.get('url', ''))
    except Exception as e:
        xbmc.log('[Starfleet/Requests] MixDrop movies scan error: %s' % e, xbmc.LOGWARNING)

    try:
        st_id = _ps._st_root_folders().get('movies')
        if st_id:
            _, files = _ps._st_list_folder(st_id)
            for f in files:
                name = (f.get('name') or '').strip()
                m = _RE_MOVIE_FILE.match(name)
                if m:
                    _add(m.group(1), m.group(2).strip(), f.get('link', ''))
    except Exception as e:
        xbmc.log('[Starfleet/Requests] Streamtape movies scan error: %s' % e, xbmc.LOGWARNING)

    return list(entries.values())


# ── Adult ────────────────────────────────────────────────────────────────────

def _subfolder_id(subfolders, name, id_keys=('id',), name_keys=('title', 'name')):
    for f in subfolders:
        fname = ''
        for k in name_keys:
            fname = f.get(k) or fname
        if fname.strip().lower() == name:
            for k in id_keys:
                if f.get(k):
                    return f[k]
    return None


def _build_adult_requests():
    from resources.lib import personal_sources as _ps
    entries = {}

    def _add(adc_id, title, url):
        if not adc_id or not url:
            return
        e = entries.setdefault(adc_id, {'adc_id': adc_id, 'title': '', 'urls': []})
        if title and not e['title']:
            e['title'] = title
        if url not in e['urls']:
            e['urls'].append(url)

    try:
        porn_ref = _ps._md_root_folders().get('porn')
        if porn_ref:
            subfolders, _ = _ps._md_list_folder(porn_ref)
            movies_ref = _subfolder_id(subfolders, 'movies', id_keys=('ref', 'id'))
            if movies_ref:
                _, files = _ps._md_list_folder(movies_ref)
                for f in files:
                    name = _clean_name(f.get('title') or f.get('name'))
                    m = _RE_ADULT_FILE.match(name)
                    if m:
                        _add(m.group(1), m.group(2).strip(), f.get('url', ''))
    except Exception as e:
        xbmc.log('[Starfleet/Requests] MixDrop adult scan error: %s' % e, xbmc.LOGWARNING)

    try:
        porn_id = _ps._st_root_folders().get('porn')
        if porn_id:
            subfolders, _ = _ps._st_list_folder(porn_id)
            movies_id = _subfolder_id(subfolders, 'movies')
            if movies_id:
                _, files = _ps._st_list_folder(movies_id)
                for f in files:
                    name = (f.get('name') or '').strip()
                    m = _RE_ADULT_FILE.match(name)
                    if m:
                        _add(m.group(1), m.group(2).strip(), f.get('link', ''))
    except Exception as e:
        xbmc.log('[Starfleet/Requests] Streamtape adult scan error: %s' % e, xbmc.LOGWARNING)

    return list(entries.values())


# ── TV ───────────────────────────────────────────────────────────────────────

def _build_tv_requests():
    from resources.lib import personal_sources as _ps
    from concurrent.futures import ThreadPoolExecutor
    import threading

    entries = {}
    lock = threading.Lock()

    def _add(tt_id, show_title, season, episode, url):
        if not url:
            return
        key = (_norm_tt(tt_id), season, episode)
        with lock:
            e = entries.setdefault(key, {'title': show_title, 'season': season,
                                          'episode': episode, 'urls': []})
            if show_title and not e['title']:
                e['title'] = show_title
            if url not in e['urls']:
                e['urls'].append(url)

    def _walk_st(folder_id, tt_id, show_title, depth=0):
        if depth > 3 or not folder_id:
            return
        folders, files = _ps._st_list_folder(folder_id)
        for f in files:
            name = (f.get('name') or '').strip()
            m = _RE_EPISODE_FILE.match(name)
            if m and _norm_tt(m.group(1)) == _norm_tt(tt_id):
                _add(tt_id, show_title, int(m.group(2)), int(m.group(3)), f.get('link', ''))
        for sub in folders:
            _walk_st(sub.get('id'), tt_id, show_title, depth + 1)

    def _walk_md(folder_ref, tt_id, show_title, depth=0):
        if depth > 3 or not folder_ref:
            return
        subfolders, files = _ps._md_list_folder(folder_ref)
        for f in files:
            name = _clean_name(f.get('title') or f.get('name'))
            m = _RE_EPISODE_FILE.match(name)
            if m and _norm_tt(m.group(1)) == _norm_tt(tt_id):
                _add(tt_id, show_title, int(m.group(2)), int(m.group(3)), f.get('url', ''))
        for sub in subfolders:
            _walk_md(sub.get('ref') or sub.get('id'), tt_id, show_title, depth + 1)

    def _scan_streamtape():
        try:
            tv_id = _ps._st_root_folders().get('tv shows')
            if not tv_id:
                return
            shows, _ = _ps._st_list_folder(tv_id)

            def _do(show):
                m = _RE_SHOW_FOLDER.match((show.get('name') or '').strip())
                if m:
                    _walk_st(show.get('id'), m.group(1), _clean_name(m.group(2)))

            with ThreadPoolExecutor(max_workers=8) as pool:
                list(pool.map(_do, shows))
        except Exception as e:
            xbmc.log('[Starfleet/Requests] Streamtape TV scan error: %s' % e, xbmc.LOGWARNING)

    def _scan_mixdrop():
        try:
            tv_ref = _ps._md_root_folders().get('tv shows')
            if not tv_ref:
                return
            shows, _ = _ps._md_list_folder(tv_ref)

            def _do(show):
                name = (show.get('title') or show.get('name') or '').strip()
                m = _RE_SHOW_FOLDER.match(name)
                if m:
                    _walk_md(show.get('ref') or show.get('id'), m.group(1), _clean_name(m.group(2)))

            with ThreadPoolExecutor(max_workers=8) as pool:
                list(pool.map(_do, shows))
        except Exception as e:
            xbmc.log('[Starfleet/Requests] MixDrop TV scan error: %s' % e, xbmc.LOGWARNING)

    with ThreadPoolExecutor(max_workers=2) as outer:
        list(outer.map(lambda fn: fn(), [_scan_streamtape, _scan_mixdrop]))

    return list(entries.values())


# ── Public API (unchanged shape — every caller elsewhere in the addon uses
#    only these functions, never the scan internals above) ───────────────────

def get_requested_movies():
    return [e for e in _cache_wrap('personal_requests_movies_v1', _build_movie_requests) if _has_source(e)]


def get_requested_tv():
    return [e for e in _cache_wrap('personal_requests_tv_v1', _build_tv_requests) if _has_source(e)]


def get_requested_adult():
    return [e for e in _cache_wrap('personal_requests_adult_v1', _build_adult_requests) if _has_source(e)]


def _has_source(entry):
    return bool(entry_urls(entry))


def entry_urls(entry):
    """Every candidate url for one Requests entry, regardless of whether it
    carries a single "url" string or a "urls" list. Always returns a plain
    list (possibly empty) — every caller iterates this instead of ever
    reading entry['url'] directly."""
    if not entry:
        return []
    urls = entry.get('urls')
    if isinstance(urls, list):
        return [u for u in urls if u]
    single = entry.get('url')
    return [single] if single else []


def find_movie_request(imdb_id):
    if not imdb_id:
        return None
    for r in get_requested_movies():
        if r.get('imdb_id') == imdb_id:
            return r
    return None


def find_tv_request(title, season, episode):
    if not title or not season or not episode:
        return None
    norm_q = _norm_title(title)
    for r in get_requested_tv():
        if (_norm_title(r.get('title', '')) == norm_q
                and str(r.get('season', '')) == str(season)
                and str(r.get('episode', '')) == str(episode)):
            return r
    return None


def find_adult_request(ade_id):
    if not ade_id:
        return None
    ade_id = str(ade_id)
    for r in get_requested_adult():
        if str(r.get('adc_id', r.get('ade_id', ''))) == ade_id:
            return r
    return None


_ADE_META_TTL = 24 * 60 * 60


def enrich_adult_metadata(title, adc_id):
    """Full AdultDVDEmpire metadata (description/cast/studio/director/year/
    runtime) plus a trailer url, for one Requests adult entry.

    The JSON always carries the film's real adc_id, so the primary path is
    ade.get_film_detail_by_id(adc_id) — ADE's own site redirects a bare
    numeric id straight to that exact film's canonical detail page (no
    title matching involved at all, confirmed live), so it can never
    attach a different film's data. Falls back to a search-by-title +
    id-match-validate path only if ADE doesn't
    recognize the id outright (same "never trust an unvalidated slug"
    safety rule, kept as a backstop rather than the primary route now
    that the more reliable id-only lookup exists — confirmed live this
    matters: some real titles' search hits didn't validate even though
    the id-direct lookup found them fine). That fallback checks every
    exact-title search candidate, not just ADE's single top-ranked one —
    confirmed live that ADE catalogs a DVD edition ("-porn-movies.html")
    and an on-demand edition ("-porn-videos.html") of the same title under
    two DIFFERENT numeric ids, so a naive single-candidate check could
    miss a real match just because ADE's search happened to rank the
    other edition first.

    Returns a dict always containing at least 'trailer'; on success it
    also has 'description'/'cast'/'studio'/'director'/'year'/'runtime'/
    'thumb'/'fanart' (ade.py's own get_film_detail() shape).
    """
    if not adc_id:
        return {}
    adc_id = str(adc_id)
    cache_key = 'requests_adult_meta_%s' % adc_id
    cached = _cache.get(cache_key)
    if cached is not None:
        return cached

    from resources.lib import ade
    result = {'trailer': ade.trailer_url(adc_id)}
    try:
        detail = ade.get_film_detail_by_id(adc_id)
        if detail is not None:
            # Already fully validated by construction — get_film_detail_by_id
            # only returns non-None when ADE's own id-redirect landed on
            # this exact film's real page, so its thumb/fanart (og:image,
            # sometimes 404/415 from the plain CDN-formula guess — confirmed
            # live) is trustworthy even on a page with a thin description.
            result.update(detail)
        else:
            # ADE catalogs a DVD edition ("-porn-movies.html") and an
            # on-demand/streaming edition ("-porn-videos.html") of the same
            # title as two SEPARATE numeric ids (confirmed live) —
            # search_by_title() only returns ADE's own single best-ranked
            # candidate, which could be either edition's id, so relying on
            # just that one candidate can miss a match even when our own
            # adc_id is completely correct (it's just the OTHER edition's
            # id). search_films() returns every candidate; check every one
            # with an exact-normalised title match before giving up — still
            # only ever trusts a candidate whose own id equals our known
            # adc_id, same safety rule as before, just checked against more
            # of the right candidates first.
            norm_q = _norm_title(title or '')
            candidates = [f for f in ade.search_films(title or '', limit=30)
                          if _norm_title(f.get('title', '')) == norm_q]
            found = next((f for f in candidates if str(f.get('id', '')) == adc_id), None)
            if found:
                detail2 = ade.get_film_detail(found['id'], found['slug']) or {}
                if detail2.get('description') or detail2.get('cast'):
                    result.update(detail2)
    except Exception as e:
        xbmc.log('[Starfleet/Requests] enrich_adult_metadata error: %s' % e, xbmc.LOGWARNING)

    _cache.set(cache_key, result, _ADE_META_TTL)
    return result


def resolve_request_stream(url):
    """Hand a Request entry's own url to ResolveURL — every current entry
    is a streamtape.com or mxdrop.sx link, both standard ResolveURL-
    supported hosts, same as every other embed source in this addon.
    Falls back to the raw url untouched if ResolveURL can't resolve it (or
    isn't installed), same fallback behaviour every other resolver call in
    this codebase uses."""
    if not url:
        return None
    try:
        import resolveurl
        hmf = resolveurl.HostedMediaFile(url)
        if hmf.valid_url():
            r = hmf.resolve()
            if r:
                return r
    except ImportError:
        pass
    except Exception as e:
        xbmc.log('[Starfleet/Requests] resolveurl error: %s' % e, xbmc.LOGWARNING)
    return url
