# -*- coding: utf-8 -*-
"""
resources/lib/account_sync.py

Settings > Sync accounts: back up the viewer's linked accounts (debrid, trackers, Usenet, private sites...) and bring them to another
device with a passphrase. Shared by the Kodi add-on, the HazMat TV app and the desktop app (the app packages this same file).

How it travels: the data is packed into JSON, compressed and ENCRYPTED HERE with a key made from the viewer's passphrase (PBKDF2-HMAC-SHA256,
HMAC-SHA256 counter-mode keystream, encrypt-then-MAC; standard library only, so it runs everywhere). Only the encrypted text is sent to the
relay, which keeps it for 30 days under the viewer's paired Telegram account; any other device paired to the same Telegram account can fetch
it and decrypt it with the same passphrase. Nobody else, the relay included, can read it. A forgotten passphrase cannot be recovered.

Platform extras: the Android and desktop apps also keep things outside the add-on settings (IPTV providers, Plex / Jellyfin / Emby servers,
network shares). They hand those over as the `extra` dictionary of pack() and receive it back from unpack().
"""
import base64
import hashlib
import hmac
import json
import os
import time
import zlib

RELAY = 'https://hazmat-relay.hazmat-tv-aad5.workers.dev'
_UA = {'User-Agent': 'Starfleet-Sync'}
_ITER = 200000
_MAGIC = 'HZ1'

# The add-on settings that hold an account: tokens, keys, logins, and the switches that go with them.
SETTING_IDS = (
    'rd_api_key', 'ad_api_key', 'pm_api_key', 'tb_api_key', 'dl_api_key', 'oc_api_key',
    'easynews_username', 'easynews_password',
    'nzbgeek_api_key', 'nzbgeek_enabled', 'nzbplanet_api_key', 'nzbplanet_enabled',
    'md_username', 'md_password', 'sd_username', 'sd_password',
    'trakt_client_id', 'trakt_client_secret', 'trakt_access_token', 'trakt_refresh_token',
    'simkl_access_token',
    'wetrakr_api_url', 'wetrakr_access_token', 'wetrakr_username',
    'mdblist_api_key', 'mdblist_enabled', 'md_personal_email', 'md_personal_key',
    'st_personal_login', 'st_personal_key',
    'bitporn_api_token', 'podzemlje_api_token',
    'hf_username', 'hf_password', 'hf_cookies',
    'tmdb_v4_access_token', 'tmdb_v4_account_id', 'tmdb_favorites_list_id',
    # the per-service switches that go with them (a restored login does nothing while its switch is off)
    'rd_enabled', 'ad_enabled', 'pm_enabled', 'tb_enabled', 'dl_enabled', 'oc_enabled',
    'easynews_enabled', 'bitporn_enabled', 'podzemlje_enabled', 'md_enabled', 'sd_enabled', 'md_personal_enabled', 'st_personal_enabled',
)

# For a backup made before the switches were carried: restoring this login switches this service on.
SWITCH_FOR = {
    'rd_api_key': 'rd_enabled', 'ad_api_key': 'ad_enabled', 'pm_api_key': 'pm_enabled', 'tb_api_key': 'tb_enabled',
    'dl_api_key': 'dl_enabled', 'oc_api_key': 'oc_enabled', 'easynews_password': 'easynews_enabled',
    'bitporn_api_token': 'bitporn_enabled', 'podzemlje_api_token': 'podzemlje_enabled', 'md_password': 'md_enabled',
    'sd_password': 'sd_enabled', 'md_personal_key': 'md_personal_enabled', 'st_personal_key': 'st_personal_enabled',
}


# Kodi only: how the add-on is set up (not logins). The Android app keeps its own equivalents in its own storage and sends them in `extra`.
PREF_IDS = ('telegram_auto_report', 'phone_remote')


def _b64(b):
    return base64.urlsafe_b64encode(b).decode('ascii').rstrip('=')


def _unb64(s):
    return base64.urlsafe_b64decode(s + '=' * (-len(s) % 4))


def _keys(passphrase, salt):
    dk = hashlib.pbkdf2_hmac('sha256', passphrase.encode('utf-8'), salt, _ITER, 64)
    return dk[:32], dk[32:]


def _stream(key, iv, n):
    out = bytearray()
    i = 0
    while len(out) < n:
        out += hmac.new(key, iv + i.to_bytes(4, 'big'), hashlib.sha256).digest()
        i += 1
    return bytes(out[:n])


def encrypt(obj, passphrase):
    """obj (JSON-able) -> 'HZ1:salt:iv:ciphertext:tag' (URL-safe text)."""
    plain = zlib.compress(json.dumps(obj, separators=(',', ':')).encode('utf-8'), 9)
    salt, iv = os.urandom(16), os.urandom(16)
    ek, mk = _keys(passphrase, salt)
    ct = (int.from_bytes(plain, 'big') ^ int.from_bytes(_stream(ek, iv, len(plain)), 'big')).to_bytes(len(plain), 'big')
    tag = hmac.new(mk, _MAGIC.encode() + salt + iv + ct, hashlib.sha256).digest()
    return ':'.join((_MAGIC, _b64(salt), _b64(iv), _b64(ct), _b64(tag)))


def decrypt(blob, passphrase):
    """The inverse of encrypt(). Raises ValueError('wrong passphrase') when the passphrase or the data is wrong."""
    try:
        magic, s, i, c, t = blob.strip().split(':')
        if magic != _MAGIC:
            raise ValueError
        salt, iv, ct, tag = _unb64(s), _unb64(i), _unb64(c), _unb64(t)
    except Exception:
        raise ValueError('this is not an account backup')
    ek, mk = _keys(passphrase, salt)
    if not hmac.compare_digest(hmac.new(mk, _MAGIC.encode() + salt + iv + ct, hashlib.sha256).digest(), tag):
        raise ValueError('wrong passphrase')
    plain = (int.from_bytes(ct, 'big') ^ int.from_bytes(_stream(ek, iv, len(ct)), 'big')).to_bytes(len(ct), 'big')
    return json.loads(zlib.decompress(plain).decode('utf-8'))


def _addon():
    import xbmcaddon
    return xbmcaddon.Addon('plugin.video.starfleet')


def collect():
    """The linked accounts found in the add-on settings (empty ones are left out)."""
    a = _addon()
    out = {}
    for k in SETTING_IDS:
        try:
            v = a.getSetting(k)
        except Exception:
            v = ''
        if v and v.strip():
            out[k] = v
    return out


def collect_prefs():
    """Kodi: the set-up switches in PREF_IDS ('true' / 'false' as the add-on stores them)."""
    a = _addon()
    out = {}
    for k in PREF_IDS:
        try:
            v = a.getSetting(k)
        except Exception:
            v = ''
        if v in ('true', 'false'):
            out[k] = v
    return out


_DEBRID_IDS = {'realdebrid': 'rd_api_key', 'alldebrid': 'ad_api_key', 'premiumize': 'pm_api_key',
               'torbox': 'tb_api_key', 'debridlink': 'dl_api_key', 'offcloud': 'oc_api_key'}
_ENABLE_OF = {'realdebrid': 'rd_enabled', 'alldebrid': 'ad_enabled', 'premiumize': 'pm_enabled',
              'torbox': 'tb_enabled', 'debridlink': 'dl_enabled', 'offcloud': 'oc_enabled'}


def _store():
    try:
        from starfleetresolve.debrid import store
        return store
    except Exception:
        return None


def collect_debrid():
    """The live debrid accounts of the resolver (token plus what is needed to renew it: refresh token, client id / secret, expiry). A service
    that renews its token (Real-Debrid, Debrid-Link) keeps the renewed one only here, not in the add-on setting. Host caches are left out."""
    st = _store()
    out = {}
    if st is None:
        return out
    for sid in _DEBRID_IDS:
        try:
            rec = st.get(sid)
        except Exception:
            continue
        if not rec.get('token'):
            continue
        keep = {k: v for k, v in rec.items() if isinstance(v, (str, int, float, bool)) and not k.endswith('_hosts') and len(str(v)) < 2000}
        out[sid] = keep
    return out


def _restore_debrid(a, accounts):
    """Puts backed-up debrid accounts into the resolver's store: where this device has none, or only one that cannot renew itself and has run
    out, the backed-up one (with its renewal data) is used; a working account here is kept. Switches the restored service on."""
    st = _store()
    if st is None or not isinstance(accounts, dict):
        return 0
    n = 0
    for sid, rec in accounts.items():
        if sid not in _DEBRID_IDS or not isinstance(rec, dict) or not rec.get('token'):
            continue
        rec = {k: v for k, v in rec.items() if isinstance(v, (str, int, float, bool))}
        try:
            cur = st.get(sid)
            expired = bool(cur.get('expires_at')) and cur.get('expires_at', 0) <= time.time() and not cur.get('refresh')
            if cur.get('token') and cur.get('token') != rec['token'] and not expired:
                continue                                    # what is already here works: kept
            st.put(sid, **rec)
            a.setSetting(_DEBRID_IDS[sid], rec['token'])
            if a.getSetting(_ENABLE_OF[sid]) != 'true':
                a.setSetting(_ENABLE_OF[sid], 'true')
            n += 1
        except Exception:
            pass
    return n


def pack(passphrase, extra=None, kodi=False):
    """Everything to back up -> encrypted text. `extra` is what the platform keeps outside the settings (a JSON-able dictionary);
    kodi=True adds the Kodi set-up switches."""
    settings = collect()
    debrid = collect_debrid()
    for sid, rec in debrid.items():                       # old readers take the settings: they get the live (renewed) token
        settings[_DEBRID_IDS[sid]] = rec['token']
        settings[_ENABLE_OF[sid]] = settings.get(_ENABLE_OF[sid]) or 'true'
    data = {'v': 1, 'ts': int(time.time()), 'settings': settings, 'extra': extra or {}, 'debrid': debrid}
    if kodi:
        data['prefs'] = collect_prefs()
    return encrypt(data, passphrase)


def _apply_kodi_prefs(a, data):
    """Kodi restoring: the switches from a Kodi backup, or their Android equivalents from a backup made in the app."""
    prefs = dict(data.get('prefs') or {})
    extra = data.get('extra') or {}
    if 'autoReport' in extra and 'telegram_auto_report' not in prefs:
        prefs['telegram_auto_report'] = 'true' if extra.get('autoReport') else 'false'
    remote = extra.get('remote')
    if isinstance(remote, dict) and 'phone_remote' not in prefs:
        prefs['phone_remote'] = 'true' if remote.get('on') else 'false'
    n = 0
    for k, v in prefs.items():
        if k in PREF_IDS and v in ('true', 'false'):
            try:
                a.setSetting(k, v)
                n += 1
            except Exception:
                pass
    return n


def unpack(blob, passphrase, kodi=False):
    """Decrypts a backup, puts the settings back (only the known account settings are accepted) and returns {'count': n, 'extra': {...}}.
    kodi=True also applies the set-up switches."""
    data = decrypt(blob, passphrase)
    if not isinstance(data, dict):
        raise ValueError('this is not an account backup')
    a = _addon()
    n = 0
    if kodi:
        _apply_kodi_prefs(a, data)
    saved = data.get('settings') or {}
    for k, v in saved.items():
        if k in SETTING_IDS and isinstance(v, str) and v.strip():
            try:
                a.setSetting(k, v)
                if not k.endswith('_enabled'):
                    n += 1
            except Exception:
                pass
    for login, switch in SWITCH_FOR.items():       # an older backup has no switches: a login that came back turns its service on
        if login in saved and switch not in saved:
            try:
                if a.getSetting(switch) != 'true':
                    a.setSetting(switch, 'true')
            except Exception:
                pass
    try:
        _restore_debrid(a, data.get('debrid'))
    except Exception:
        pass
    try:                                     # hand the debrid accounts to the Starfleet resolver, as a fresh pairing does
        from resources.lib import sf_debrid as _sfd
        if _sfd.available():
            _sfd.sync(force=True)
    except Exception:
        pass
    return {'count': n, 'extra': data.get('extra') or {}}


# ---- the relay ----------------------------------------------------------------------------------------------------------------------

def _req():
    import requests
    return requests


def upload(code, blob):
    """'' when stored (kept 30 days); else a sentence about what failed."""
    try:
        r = _req().put('%s/sync' % RELAY, data=blob.encode('ascii'), headers=dict(_UA, **{'X-Code': code, 'Content-Type': 'text/plain'}), timeout=30)
        if r.status_code == 200:
            return ''
        if r.status_code == 403:
            return 'Telegram is not paired on this device'
        if r.status_code == 429:
            return 'Too many backups in the last hour - try again later'
        return 'The relay answered with an error (%s)' % r.status_code
    except Exception as e:
        return 'Could not reach the relay (%s)' % e


def download(code):
    """(blob, '') or (None, a sentence about what went wrong)."""
    try:
        r = _req().get('%s/sync' % RELAY, headers=dict(_UA, **{'X-Code': code}), timeout=30)
        if r.status_code == 200:
            return r.text, ''
        if r.status_code == 404:
            return None, 'No backup found. Back up on the other device first (backups are kept for 30 days).'
        if r.status_code == 403:
            return None, 'Telegram is not paired on this device'
        if r.status_code == 429:
            return None, 'Too many tries in the last hour - try again later'
        return None, 'The relay answered with an error (%s)' % r.status_code
    except Exception as e:
        return None, 'Could not reach the relay (%s)' % e


def peek(code):
    """When a backup was saved for this Telegram account (millis), 0 if there is none. Downloads nothing."""
    try:
        r = _req().get('%s/sync' % RELAY, params={'peek': '1'}, headers=dict(_UA, **{'X-Code': code}), timeout=15)
        if r.status_code == 200:
            return int(r.json().get('saved') or 0)
    except Exception:
        pass
    return 0


def remove(code):
    """'' when the stored copy was deleted."""
    try:
        r = _req().delete('%s/sync' % RELAY, headers=dict(_UA, **{'X-Code': code}), timeout=20)
        return '' if r.status_code == 200 else 'The relay answered with an error (%s)' % r.status_code
    except Exception as e:
        return 'Could not reach the relay (%s)' % e


# ---- Kodi: Settings > General > Sync accounts -----------------------------------------------------------------------------------------

def kodi_menu():
    """Back up / Restore / Delete, with the Telegram pairing and the passphrase asked as needed."""
    import xbmcgui
    from resources.lib import telegram_link as tg
    dlg = xbmcgui.Dialog()
    if not tg.linked_name():
        if not dlg.yesno('Sync accounts', 'Syncing goes through your Telegram account. Pair Telegram now? (Use the same Telegram account on every device.)'):
            return
        if not tg.pair(offer=False):
            return
    pick = dlg.select('Sync accounts (Telegram: %s)' % tg.linked_name(),
                      ['Back up my accounts now', 'Restore my accounts from the backup', 'Delete the backup'])
    if pick < 0:
        return
    if pick == 2:
        err = remove(tg.code())
        dlg.notification('Starfleet', 'Backup deleted' if not err else err, xbmcgui.NOTIFICATION_INFO if not err else xbmcgui.NOTIFICATION_ERROR, 5000)
        return
    pw = dlg.input('Passphrase (you need the same one to restore; it cannot be recovered)', type=xbmcgui.INPUT_ALPHANUM, option=xbmcgui.ALPHANUM_HIDE_INPUT)
    if not pw:
        return
    busy = xbmcgui.DialogProgress()
    busy.create('Sync accounts', 'Please wait...')
    try:
        if pick == 0:
            pw2 = None
            busy.close()
            pw2 = dlg.input('Type the passphrase again', type=xbmcgui.INPUT_ALPHANUM, option=xbmcgui.ALPHANUM_HIDE_INPUT)
            if pw2 != pw:
                dlg.ok('Sync accounts', 'The two passphrases are different. Nothing was saved.')
                return
            busy.create('Sync accounts', 'Encrypting and saving...')
            n = len([k for k in collect() if not k.endswith('_enabled')])
            err = upload(tg.code(), pack(pw, kodi=True))
            busy.close()
            dlg.ok('Sync accounts', ('Backed up %d account settings. They are kept for 30 days; restore them on another device with this passphrase.' % n) if not err else err)
        else:
            busy.close()
            _restore(dlg, tg, pw)
    finally:
        try:
            busy.close()
        except Exception:
            pass


def _restore(dlg, tg, pw):
    """Downloads the backup, opens it with the passphrase and says what happened."""
    blob, err = download(tg.code())
    if blob is None:
        dlg.ok('Sync accounts', err)
        return
    try:
        res = unpack(blob, pw, kodi=True)
    except ValueError as e:
        dlg.ok('Sync accounts', 'That passphrase does not open the backup.' if 'passphrase' in str(e) else str(e))
        return
    dlg.ok('Sync accounts', 'Restored %d account settings.' % res['count'])


def offer_restore():
    """Right after Telegram was paired: if a backup is waiting for this Telegram account, offer to restore it."""
    import xbmcgui
    from resources.lib import telegram_link as tg
    ts = peek(tg.code())
    if not ts:
        return
    dlg = xbmcgui.Dialog()
    when = time.strftime('%d %b %Y', time.localtime(ts / 1000.0))
    if not dlg.yesno('Sync accounts', 'A backup of your accounts, made %s, is waiting for this Telegram account. Restore it on this device? (What is already here is kept.)' % when):
        return
    pw = dlg.input('Passphrase of the backup', type=xbmcgui.INPUT_ALPHANUM, option=xbmcgui.ALPHANUM_HIDE_INPUT)
    if pw:
        _restore(dlg, tg, pw)
