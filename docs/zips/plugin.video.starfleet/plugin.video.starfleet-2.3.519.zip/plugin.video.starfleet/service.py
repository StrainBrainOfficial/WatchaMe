# -*- coding: utf-8 -*-
"""
service.py — Kodi background service entry point (xbmc.python.service,
start="startup" in addon.xml). Runs for the whole Kodi session, unlike
default.py's plugin:// invocations which are fresh, short-lived processes
(this addon explicitly sets reuselanguageinvoker=false) — see
resources/lib/local_proxy.py's own docstring for why that distinction is
exactly what OK.ru playback needed.
"""
import xbmc

from resources.lib import local_proxy

local_proxy.run_service(xbmc.Monitor())
