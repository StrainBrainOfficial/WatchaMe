# -*- coding: utf-8 -*-
"""
resources/lib/wetrakr_auth.py

WeTrakr account pairing (device-code flow) — same idea as trakt_auth.py/
simkl_auth.py's pairing, mirrored for WeTrakr (wetrakr.com), a third
watch-tracking service. Independent of Trakt/SIMKL — nothing here touches
their settings. Backs watch_history.py's WeTrakr scrobble sync (see
wetrakr_sync.py) the same way trakt_auth.py/simkl_auth.py back theirs.

Read directly from the real script.wetrakr Kodi add-on's own installed
source (resources/lib/auth.py) before writing this, since WeTrakr has no
public API docs — its actual device-code flow:
  1. POST {api_url}/oauth/device/code, body {} (empty JSON object)
     -> {"device_code","user_code","verification_url","expires_in","interval"}
  2. Show user_code (+ a QR code for verification_url, same pyqrcode/
     qr_dialog.py mechanism simkl_auth.py already uses).
  3. Poll POST {api_url}/oauth/device/token, body {"device_code": ...}
     every `interval` seconds:
       - {"error":"authorization_pending"} -> keep polling
       - {"error":"expired_token"} -> stop, code expired
       - {"access_token":"...","username":"..."} -> done

Unlike Trakt (client_id+secret) and SIMKL (bundled client_id), WeTrakr's
real server issues device codes with NO app identifier at all — "Pair with
WeTrakr" needs nothing pre-registered, not even a shared/bundled key.
api_url is a user-editable setting (default https://api.wetrakr.com) since
the real add-on treats it as self-hostable, unlike Trakt/SIMKL's fixed
hosts.
"""
import time
import xbmc
import xbmcaddon
import xbmcgui
from resources.lib.gui import progress_dialog as _pdlg
from resources.lib.gui import qr_dialog as _qrdlg

ADDON = xbmcaddon.Addon('plugin.video.starfleet')


def api_url():
    return (ADDON.getSetting('wetrakr_api_url').strip() or 'https://api.wetrakr.com').rstrip('/')


def user_agent():
    version = ADDON.getAddonInfo('version') or '1.0'
    return 'plugin.video.starfleet/%s' % version


def is_paired():
    # A fresh Addon() every call, NOT the module-level ADDON above - same
    # fix simkl_auth.py's is_paired() already documents (a long-lived
    # process like the Home screen can otherwise keep reading a settings
    # snapshot frozen from before pairing completed).
    return bool(xbmcaddon.Addon('plugin.video.starfleet').getSetting('wetrakr_access_token').strip())


def unpair():
    ADDON.setSetting('wetrakr_access_token', '')
    ADDON.setSetting('wetrakr_username', '')


def pair_with_wetrakr():
    """Run the full device-code pairing flow, showing a QR code (if
    available) plus the short code in a Kodi dialog. Bound to the
    wetrakr_pair Settings action. No credentials to enter first - see this
    module's docstring for why no client id/secret is needed at all."""
    try:
        import requests
    except Exception:
        xbmcgui.Dialog().notification('Starfleet', 'requests module unavailable',
                                      xbmcgui.NOTIFICATION_ERROR)
        return

    base = api_url()
    headers = {'Content-Type': 'application/json', 'User-Agent': user_agent()}

    try:
        r = requests.post(base + '/oauth/device/code', json={}, headers=headers, timeout=10)
        r.raise_for_status()
        data = r.json()
    except Exception as e:
        xbmc.log('[Starfleet/WeTrakr] oauth/device/code error: %s' % e, xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Starfleet', 'WeTrakr pairing failed to start',
                                      xbmcgui.NOTIFICATION_ERROR, 4000)
        return

    device_code = data.get('device_code')
    user_code   = data.get('user_code')
    verify_url  = data.get('verification_url', 'wetrakr.com')
    expires_in  = data.get('expires_in', 900)
    interval    = data.get('interval', 5)

    if not device_code or not user_code:
        xbmcgui.Dialog().notification('Starfleet', 'WeTrakr pairing failed to start',
                                      xbmcgui.NOTIFICATION_ERROR, 4000)
        return

    msg = 'Scan, or go to %s and enter code: %s' % (verify_url, user_code)
    qr_path = _qrdlg.make_qr(verify_url, 'starfleet_wetrakr_qr.png')
    qr_dlg, txt_dlg = None, None
    if qr_path:
        qr_dlg = _qrdlg.QRDialog(qr_path, 'Pair with WeTrakr',
                                 'Scan, or go to %s' % verify_url, code=user_code)
        qr_dlg.show()
    else:
        txt_dlg = _pdlg.DialogProgress()
        txt_dlg.create('Starfleet - Pair with WeTrakr', msg)

    def _iscanceled():
        return qr_dlg.iscanceled() if qr_dlg else txt_dlg.iscanceled()

    def _update():
        if qr_dlg:
            qr_dlg.update('Waiting for you to approve… (%ds)' % waited)
        else:
            txt_dlg.update(min(99, int(100 * waited / expires_in)), msg)

    def _close():
        (qr_dlg or txt_dlg).close()

    waited = 0
    while waited < expires_in:
        if _iscanceled():
            _close()
            return
        time.sleep(interval)
        waited += interval
        _update()

        try:
            pr = requests.post(base + '/oauth/device/token', json={'device_code': device_code},
                               headers=headers, timeout=10)
            pr.raise_for_status()
            pdata = pr.json()
        except Exception as e:
            xbmc.log('[Starfleet/WeTrakr] device/token poll error: %s' % e, xbmc.LOGWARNING)
            continue

        if pdata.get('error') == 'expired_token':
            _close()
            xbmcgui.Dialog().notification('Starfleet', 'WeTrakr: code expired, try again',
                                          xbmcgui.NOTIFICATION_ERROR, 4000)
            return

        if pdata.get('access_token'):
            ADDON.setSetting('wetrakr_access_token', pdata['access_token'])
            ADDON.setSetting('wetrakr_username', pdata.get('username', ''))
            _close()
            xbmcgui.Dialog().notification('Starfleet', 'WeTrakr account paired',
                                          xbmcgui.NOTIFICATION_INFO, 3000)
            return
        # error == 'authorization_pending' (or any other unrecognized shape) - keep polling

    _close()
    xbmcgui.Dialog().notification('Starfleet', 'WeTrakr pairing timed out',
                                  xbmcgui.NOTIFICATION_INFO, 4000)


def show_status():
    """Bound to the wetrakr_status Settings action."""
    if is_paired():
        username = xbmcaddon.Addon('plugin.video.starfleet').getSetting('wetrakr_username').strip()
        who = ' as %s' % username if username else ''
        if xbmcgui.Dialog().yesno('Starfleet - WeTrakr', 'WeTrakr is paired%s.\n\nUnpair?' % who):
            unpair()
            xbmcgui.Dialog().notification('Starfleet', 'WeTrakr unpaired',
                                          xbmcgui.NOTIFICATION_INFO, 3000)
    else:
        xbmcgui.Dialog().ok('Starfleet - WeTrakr', 'Not paired yet. Use "Pair with WeTrakr" above.')
