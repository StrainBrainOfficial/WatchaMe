﻿# -*- coding: utf-8 -*-
"""
resources/lib/scraper_sources.py

Free streaming scrapers for movies, TV shows, and adult content.
Covers sites from the user-supplied list that are not already handled
by free_sources.py (Popcornflix/Tubi) or adult_streams.py.

Sources:
  cuevana3.eu     — Spanish-language streaming, iframe embeds
  hdtodayz.to     — General streaming aggregator, iframe embeds
  netmirror.app   — Mirror/aggregator, embed players
  zaxflix.com     — WordPress streaming, iframe embeds
  rarefilmm.com   — Classic/rare film archive, direct links
  1shows.org      — TV shows + movies, WordPress streaming
  456movie.nl     — General streaming, iframe embeds
  msearch.vercel.app — Meta-search aggregator (JSON API)

Each site scraper:
  1. Hits the site's search endpoint with the query title
  2. Parses film cards from the results HTML
  3. Fetches each film's detail page to extract embed/stream URLs
  4. Returns a list of film dicts compatible with adult_streams.py format:
     { 'id', 'title', 'title_norm', 'thumb', 'description', 'url',
       'source', 'streams': [{'label', 'url'}] }

search_all_scrapers(title, media_type) runs all scrapers in parallel and
returns a flat list of stream dicts: [{'label', 'url', 'source'}].
"""

import re
import unicodedata
import xbmc
import xbmcaddon
import xbmcvfs

ADDON     = xbmcaddon.Addon('plugin.video.starfleet')
_PROFILE  = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
_CACHE_DB = _PROFILE + '/cache.db'

try:
    import requests as _requests
    from resources.lib import cache as _cache
    _cache.init(_CACHE_DB)
    _HAS_REQUESTS = True
except Exception:
    _HAS_REQUESTS = False

CUEVANA3_BASE  = 'https://www.cuevana3.eu'
HDTODAYZ_BASE  = 'https://hdtodayz.to'
NETMIRROR_BASE = 'https://netmirror.app'
ZAXFLIX_BASE   = 'https://zaxflix.com'
RAREFILMM_BASE = 'https://rarefilmm.com'
SHOWS1_BASE    = 'https://www.1shows.org'
M456_BASE      = 'https://456movie.nl'
MSEARCH_BASE   = 'https://msearch.vercel.app'

_HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/126.0.0.0 Safari/537.36'
    ),
    'Accept':          'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9',
}

_RE_STRIP_TAGS = re.compile(r'<[^>]+>')
_RE_WHITESPACE = re.compile(r'\s+')
_RE_NONALNUM   = re.compile(r'[^a-z0-9 ]')
# Social-share/page-furniture links — never real stream candidates,
# skipped regardless of debrid pairing.
_JUNK_SKIP = re.compile(
    r'(?:facebook\.com|twitter\.com|google\.com|youtube\.com)',
    re.IGNORECASE
)
# Premium-locker hosts (rapidgator/nitroflare/keep2share/uploaded.net/
# frdl.io) — same family adult_streams.py's _PREMIUM_LOCKER_RE matches.
# Real-Debrid's/AllDebrid's own unrestrict API genuinely supports unlocking
# most of these directly (confirmed live: ResolveURL's realdebrid.py
# plugin declares domains=['*'], forwarding ANY host straight to Real-
# Debrid's own API rather than needing a hardcoded supported-host list
# here), so they're only discarded when no debrid service is paired at
# all — see _skip_locker_unless_debrid() below.
_PREMIUM_LOCKER_RE = re.compile(
    r'(?:rapidgator|nitroflare|keep2share|uploaded\.net|frdl\.io)',
    re.IGNORECASE
)


def _skip_locker_unless_debrid(url):
    if not _PREMIUM_LOCKER_RE.search(url):
        return False
    from resources.lib import resolvers as _resolvers
    return not _resolvers.any_debrid_enabled()


def _STREAM_SKIP_search(url):
    """Combined replacement for the old single _STREAM_SKIP regex's
    .search(url) calls below — junk links always skip, premium-locker
    links only skip without a paired debrid service."""
    return bool(_JUNK_SKIP.search(url)) or _skip_locker_unless_debrid(url)

_session    = None
_cf_session = None


def _sess():
    global _session
    if not _HAS_REQUESTS:
        return None
    if _session is None:
        _session = _requests.Session()
        _session.headers.update(_HEADERS)
        a = _requests.adapters.HTTPAdapter(
            pool_connections=4, pool_maxsize=12,
            max_retries=_requests.adapters.Retry(total=0)
        )
        _session.mount('https://', a)
        _session.mount('http://', a)
    return _session


def _cf_sess():
    """Cloudflare-bypass session: cloudscraper if available, else plain requests."""
    global _cf_session
    if _cf_session is not None:
        return _cf_session
    try:
        import cloudscraper as _cs
        _cf_session = _cs.create_scraper(
            browser={'browser': 'chrome', 'platform': 'windows', 'mobile': False}
        )
        _cf_session.headers.update(_HEADERS)
        return _cf_session
    except Exception:
        pass
    _cf_session = _sess()
    return _cf_session


# Domains known to use Cloudflare — use _cf_sess() for these
_CF_DOMAINS = (
    'hdtodayz.to', 'zaxflix.com', '456movie.nl', '1shows.org',
    'bbflix.watch', 'fmoviess.org', 'filmslook.com',
)


def _get(url, timeout=(6, 12)):
    s = _cf_sess() if any(d in url for d in _CF_DOMAINS) else _sess()
    if not s:
        return ''
    try:
        r = s.get(url, timeout=timeout, allow_redirects=True)
        r.raise_for_status()
        return r.text
    except Exception as e:
        xbmc.log('[Starfleet/Scrapers] GET failed (%s): %s' % (url[:70], e), xbmc.LOGWARNING)
        return ''


def _get_json(url, timeout=(6, 12)):
    s = _cf_sess() if any(d in url for d in _CF_DOMAINS) else _sess()
    if not s:
        return None
    try:
        r = s.get(url, timeout=timeout, allow_redirects=True)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        xbmc.log('[Starfleet/Scrapers] JSON GET failed (%s): %s' % (url[:70], e), xbmc.LOGWARNING)
        return None


def _clean(text):
    text = _RE_STRIP_TAGS.sub(' ', text)
    return _RE_WHITESPACE.sub(' ', text).strip()


def _og(html, prop):
    """Extract og: meta property value."""
    m = re.search(
        r'<meta[^>]+property=["\']og:%s["\'][^>]+content=["\']([^"\']+)["\']' % re.escape(prop),
        html, re.IGNORECASE
    )
    if not m:
        m = re.search(
            r'<meta[^>]+content=["\']([^"\']+)["\'][^>]+property=["\']og:%s["\']' % re.escape(prop),
            html, re.IGNORECASE
        )
    return _clean(m.group(1)) if m else ''


def _norm_title(title):
    title = title.lower()
    title = ''.join(
        c for c in unicodedata.normalize('NFD', title)
        if unicodedata.category(c) != 'Mn'
    )
    title = _RE_NONALNUM.sub('', title)
    return _RE_WHITESPACE.sub(' ', title).strip()


_RE_IMG_URL = re.compile(
    r'\.(?:jpe?g|png|gif|webp|svg|ico|bmp)(?:\?|$)|image\.tmdb\.org|gravatar\.com',
    re.IGNORECASE
)


def _extract_embeds(html):
    """Extract all playable iframe/embed/data-* URLs from an HTML page."""
    seen, embeds = set(), []

    # iframes
    for m in re.finditer(
        r'<iframe[^>]+(?:src|data-src)=["\']([^"\']{10,})["\']', html, re.IGNORECASE
    ):
        url = m.group(1).strip()
        if not url.startswith('http') or url in seen:
            continue
        if _STREAM_SKIP_search(url) or _RE_IMG_URL.search(url):
            continue
        seen.add(url)
        dom = re.search(r'https?://(?:www\.)?([^./]+)', url)
        label = dom.group(1).capitalize() if dom else 'Embed'
        embeds.append({'label': label, 'url': url})

    # data-* stream attributes (DooPlay / TPostMv themes). data-lazy-src in
    # particular is a WordPress lazy-image-loading convention far more often
    # than a video embed — confirmed live it was picking up plain TMDB poster
    # thumbnails (image.tmdb.org .jpg URLs) and handing them back as if they
    # were playable "streams". Filter out anything image-shaped before
    # accepting a match from this attribute group.
    for m in re.finditer(
        r'data-(?:fl-url|src|embed|player|lazy-src)=["\']([^"\']{10,})["\']',
        html, re.IGNORECASE
    ):
        url = m.group(1).strip()
        if not url.startswith('http') or url in seen:
            continue
        if _STREAM_SKIP_search(url) or _RE_IMG_URL.search(url):
            continue
        seen.add(url)
        dom = re.search(r'https?://(?:www\.)?([^./]+)', url)
        label = dom.group(1).capitalize() if dom else 'Stream'
        embeds.append({'label': label, 'url': url})

    # Direct video file links (mp4 / m3u8 / mkv)
    for m in re.finditer(
        r'["\' ](https?://[^"\'<\s]+\.(?:mp4|m3u8|mkv|avi|mov)[^"\'<\s]*)["\' ]',
        html, re.IGNORECASE
    ):
        url = m.group(1).strip()
        if url in seen:
            continue
        seen.add(url)
        embeds.append({'label': 'Direct', 'url': url})

    return embeds


def _h1_title(html):
    m = re.search(r'<h1[^>]*>([^<]+)</h1>', html, re.IGNORECASE)
    return _clean(m.group(1)) if m else ''


def _strip_site_suffix(title):
    return re.sub(r'\s*[|\-–—].*$', '', title).strip()


def _cache_get(key):
    try:
        return _cache.get(key)
    except Exception:
        return None


def _cache_set(key, value, ttl):
    try:
        _cache.set(key, value, ttl)
    except Exception:
        pass


def _rank_stubs_by_title(stubs, query, limit=5):
    """Sort candidate stubs by how well their title matches `query`, best
    first, then cap to `limit`.

    Every site's stub-collection loop used to cap at the first N raw search
    hits *before* any relevance check — fine when a site's search already
    ranks the real match first, but confirmed live (bbflix.watch, "The
    Matrix") that spinoffs/parodies/tributes can rank above the actual film,
    silently pushing the real match past the cap so it never even gets a
    detail-page fetch. Collecting a wider net and ranking by title match
    before capping fixes that without changing anything about detail
    fetching itself.
    """
    norm_q = _norm_title(query)
    q_words = set(norm_q.split())

    def _score(stub):
        norm_t = _norm_title(stub.get('title', ''))
        if not norm_t:
            return -1
        if norm_t == norm_q:
            return 3
        t_words = set(norm_t.split())
        if q_words and q_words.issubset(t_words):
            # Prefer the closest length match among candidates that contain
            # every query word (fewer extra words = more likely the exact title)
            return 2 - min(1, (len(t_words) - len(q_words)) / 10.0)
        overlap = len(q_words & t_words)
        return overlap / max(1, len(q_words))

    ranked = sorted(enumerate(stubs), key=lambda p: (-_score(p[1]), p[0]))
    return [s for _, s in ranked[:limit]]


def _pfetch(stubs, fn, limit=5):
    """Fetch up to limit stubs concurrently, return non-None results."""
    from concurrent.futures import ThreadPoolExecutor
    batch = stubs[:limit]
    if not batch:
        return []
    with ThreadPoolExecutor(max_workers=min(len(batch), 5)) as pool:
        results = list(pool.map(fn, batch, timeout=20))
    return [r for r in results if r and r.get('streams')]


# ── cuevana3.eu ───────────────────────────────────────────────────────────────

_RE_CUEVANA_CARD = re.compile(
    r'href="(https?://(?:www\.)?cuevana3\.[a-z]+/(?:peliculas?|movies?|series?|ver)/([^"/?#\s]+)[^"]*)"',
    re.IGNORECASE
)
_CUEVANA_SKIP = {
    'page', 'category', 'tag', 'search', 'genre', 'actor', 'director',
    'year', 'country', 'tipo', 'fecha', 'calidad', 'idioma',
}


def _cuevana3_search_stubs(title):
    from urllib.parse import quote as _q
    html = _get('%s/?s=%s' % (CUEVANA3_BASE, _q(title)))
    stubs, seen = [], set()
    for m in _RE_CUEVANA_CARD.finditer(html):
        url, slug = m.group(1), m.group(2)
        if slug not in _CUEVANA_SKIP and slug not in seen:
            seen.add(slug)
            stubs.append({'url': url, 'slug': slug})
    return stubs


def _cuevana3_detail(stub):
    url, slug = stub['url'], stub['slug']
    ck = 'scrapers_cuevana3_%s' % slug[:60]
    cached = _cache_get(ck)
    if cached is not None:
        return cached
    html = _get(url)
    if not html:
        return None
    title = _h1_title(html) or _strip_site_suffix(_og(html, 'title')) or slug.replace('-', ' ').title()
    title = re.sub(r'^(?:ver|watch)\s+', '', title, flags=re.IGNORECASE).strip()
    embeds = _extract_embeds(html)
    film = {
        'id': 'cuevana3_%s' % slug[:40], 'title': title,
        'title_norm': _norm_title(title), 'thumb': _og(html, 'image'),
        'description': _og(html, 'description')[:300],
        'url': url, 'source': 'cuevana3', 'streams': embeds,
    }
    if embeds:
        _cache_set(ck, film, 12 * 3600)
    return film


def search_cuevana3(title, media_type='movie'):
    try:
        stubs = _cuevana3_search_stubs(title)
        return _pfetch(stubs, _cuevana3_detail)
    except Exception as e:
        xbmc.log('[Starfleet/Scrapers] cuevana3 error: %s' % e, xbmc.LOGWARNING)
        return []


# ── hdtodayz.to ───────────────────────────────────────────────────────────────

_RE_HDTODAYZ_CARD = re.compile(
    r'href="(https?://hdtodayz\.to/(?:movie|watch|tv)?/?([a-z0-9][a-z0-9-]+)[^"]*)"',
    re.IGNORECASE
)
_HDTODAYZ_SKIP = {
    'page', 'category', 'tag', 'genre', 'actor', 'director', 'country',
    'year', 'search', 'watchlist', 'request', 'contact',
}


def _hdtodayz_search_stubs(title):
    from urllib.parse import quote as _q
    html = _get('%s/?s=%s' % (HDTODAYZ_BASE, _q(title)))
    stubs, seen = [], set()
    for m in _RE_HDTODAYZ_CARD.finditer(html):
        url, slug = m.group(1), m.group(2)
        if slug not in _HDTODAYZ_SKIP and slug not in seen:
            seen.add(slug)
            stubs.append({'url': url, 'slug': slug})
    return stubs


def _hdtodayz_detail(stub):
    url, slug = stub['url'], stub['slug']
    ck = 'scrapers_hdtodayz_%s' % slug[:60]
    cached = _cache_get(ck)
    if cached is not None:
        return cached
    html = _get(url)
    if not html:
        return None
    title = _h1_title(html) or _strip_site_suffix(_og(html, 'title')) or slug.replace('-', ' ').title()
    embeds = _extract_embeds(html)
    film = {
        'id': 'hdtodayz_%s' % slug[:40], 'title': title,
        'title_norm': _norm_title(title), 'thumb': _og(html, 'image'),
        'description': _og(html, 'description')[:300],
        'url': url, 'source': 'hdtodayz', 'streams': embeds,
    }
    if embeds:
        _cache_set(ck, film, 12 * 3600)
    return film


def search_hdtodayz(title, media_type='movie'):
    try:
        stubs = _hdtodayz_search_stubs(title)
        return _pfetch(stubs, _hdtodayz_detail)
    except Exception as e:
        xbmc.log('[Starfleet/Scrapers] hdtodayz error: %s' % e, xbmc.LOGWARNING)
        return []


# ── netmirror.app ─────────────────────────────────────────────────────────────

_RE_NETMIRROR_CARD = re.compile(
    r'href="(https?://(?:www\.)?netmirror\.app/(?:movie|show|watch|film)/([^"/?#\s]+)[^"]*)"',
    re.IGNORECASE
)
_RE_NETMIRROR_CARD_ALT = re.compile(
    r'href="(https?://(?:www\.)?netmirror\.app/([a-z0-9][a-z0-9/-]+)[^"]*)"',
    re.IGNORECASE
)
_NETMIRROR_SKIP = {
    'page', 'category', 'tag', 'genre', 'search', 'about',
    'contact', 'privacy', 'dmca', 'sitemap',
}


def _netmirror_search_stubs(title):
    from urllib.parse import quote as _q
    for search_url in [
        '%s/search?q=%s' % (NETMIRROR_BASE, _q(title)),
        '%s/?s=%s' % (NETMIRROR_BASE, _q(title)),
    ]:
        html = _get(search_url)
        if not html:
            continue
        stubs, seen = [], set()
        for pattern in (_RE_NETMIRROR_CARD, _RE_NETMIRROR_CARD_ALT):
            for m in pattern.finditer(html):
                url, slug = m.group(1), m.group(2).strip('/')
                slug_key = slug.split('/')[0]
                if slug_key not in _NETMIRROR_SKIP and slug not in seen:
                    seen.add(slug)
                    stubs.append({'url': url, 'slug': re.sub(r'[^a-z0-9-]', '-', slug_key)})
        if stubs:
            return stubs
    return []


def _netmirror_detail(stub):
    url, slug = stub['url'], stub['slug']
    ck = 'scrapers_netmirror_%s' % slug[:60]
    cached = _cache_get(ck)
    if cached is not None:
        return cached
    html = _get(url)
    if not html:
        return None
    title = _h1_title(html) or _strip_site_suffix(_og(html, 'title')) or slug.replace('-', ' ').title()
    embeds = _extract_embeds(html)
    film = {
        'id': 'netmirror_%s' % slug[:40], 'title': title,
        'title_norm': _norm_title(title), 'thumb': _og(html, 'image'),
        'description': _og(html, 'description')[:300],
        'url': url, 'source': 'netmirror', 'streams': embeds,
    }
    if embeds:
        _cache_set(ck, film, 12 * 3600)
    return film


def search_netmirror(title, media_type='movie'):
    try:
        stubs = _netmirror_search_stubs(title)
        return _pfetch(stubs, _netmirror_detail)
    except Exception as e:
        xbmc.log('[Starfleet/Scrapers] netmirror error: %s' % e, xbmc.LOGWARNING)
        return []


# ── zaxflix.com ───────────────────────────────────────────────────────────────

_RE_ZAXFLIX_CARD = re.compile(
    r'href="(https?://(?:www\.)?zaxflix\.com/(?:film|movie|serie|show|watch|ver)/([^"/?#\s]+)[^"]*)"',
    re.IGNORECASE
)
_RE_ZAXFLIX_CARD_ALT = re.compile(
    r'href="(https?://(?:www\.)?zaxflix\.com/([a-z0-9][a-z0-9-]+)/?)"',
    re.IGNORECASE
)
_ZAXFLIX_SKIP = {
    'page', 'category', 'tag', 'genre', 'search', 'about', 'contact',
    'privacy', 'dmca', 'sitemap', 'login', 'register',
}


def _zaxflix_search_stubs(title):
    from urllib.parse import quote as _q
    html = _get('%s/?s=%s' % (ZAXFLIX_BASE, _q(title)))
    stubs, seen = [], set()
    for pattern in (_RE_ZAXFLIX_CARD, _RE_ZAXFLIX_CARD_ALT):
        for m in pattern.finditer(html):
            url, slug = m.group(1), m.group(2)
            if slug not in _ZAXFLIX_SKIP and slug not in seen:
                seen.add(slug)
                stubs.append({'url': url, 'slug': slug})
    return stubs


def _zaxflix_detail(stub):
    url, slug = stub['url'], stub['slug']
    ck = 'scrapers_zaxflix_%s' % slug[:60]
    cached = _cache_get(ck)
    if cached is not None:
        return cached
    html = _get(url)
    if not html:
        return None
    title = _h1_title(html) or _strip_site_suffix(_og(html, 'title')) or slug.replace('-', ' ').title()
    embeds = _extract_embeds(html)
    film = {
        'id': 'zaxflix_%s' % slug[:40], 'title': title,
        'title_norm': _norm_title(title), 'thumb': _og(html, 'image'),
        'description': _og(html, 'description')[:300],
        'url': url, 'source': 'zaxflix', 'streams': embeds,
    }
    if embeds:
        _cache_set(ck, film, 12 * 3600)
    return film


def search_zaxflix(title, media_type='movie'):
    try:
        stubs = _zaxflix_search_stubs(title)
        return _pfetch(stubs, _zaxflix_detail)
    except Exception as e:
        xbmc.log('[Starfleet/Scrapers] zaxflix error: %s' % e, xbmc.LOGWARNING)
        return []


# ── rarefilmm.com ─────────────────────────────────────────────────────────────
# Classic/rare film archive. Film pages often have direct MP4/embed links.

_RE_RAREFILMM_RESULT = re.compile(
    r'<h2[^>]+class="[^"]*entry-title[^"]*"[^>]*>\s*<a[^>]+href="([^"]+)"',
    re.IGNORECASE
)
_RE_RAREFILMM_RESULT_ALT = re.compile(
    r'href="(https?://rarefilmm\.com/\d{4}/\d{2}/[^"/?#]+/?)(?:")',
    re.IGNORECASE
)
_RE_RAREFILMM_STREAM = re.compile(
    r'(https?://[^"\'<\s]+\.(?:mp4|m3u8|mkv|avi|mov)(?:\?[^"\'<\s]*)?)',
    re.IGNORECASE
)
_RE_RAREFILMM_ARCHIVE = re.compile(
    r'href="(https?://(?:archive\.org|ia800[^.]+\.us\.archive\.org)/[^"]+\.(?:mp4|mkv|ogv))"',
    re.IGNORECASE
)


def search_rarefilmm(title, media_type='movie'):
    from urllib.parse import quote as _q
    try:
        html = _get('%s/?s=%s' % (RAREFILMM_BASE, _q(title)))
        film_urls = []
        seen = set()
        for pattern in (_RE_RAREFILMM_RESULT, _RE_RAREFILMM_RESULT_ALT):
            for m in pattern.finditer(html):
                u = m.group(1)
                if u not in seen and 'rarefilmm.com' in u:
                    seen.add(u)
                    film_urls.append(u)

        results = []
        for film_url in film_urls[:5]:
            try:
                detail_html = _get(film_url)
                if not detail_html:
                    continue
                film_title = _h1_title(detail_html) or _strip_site_suffix(_og(detail_html, 'title')) or ''
                if not film_title:
                    continue
                thumb   = _og(detail_html, 'image')
                streams = []
                for sm in _RE_RAREFILMM_STREAM.finditer(detail_html):
                    su = sm.group(1)
                    if su not in {s['url'] for s in streams}:
                        streams.append({'label': 'RareFilmm Direct', 'url': su})
                for sm in _RE_RAREFILMM_ARCHIVE.finditer(detail_html):
                    su = sm.group(1)
                    if su not in {s['url'] for s in streams}:
                        streams.append({'label': 'Archive.org', 'url': su})
                streams.extend(_extract_embeds(detail_html))
                if streams:
                    results.append({
                        'id':          'rarefilmm_%s' % re.sub(r'[^a-z0-9]', '_', film_title.lower())[:40],
                        'title':       film_title,
                        'title_norm':  _norm_title(film_title),
                        'thumb':       thumb,
                        'description': _og(detail_html, 'description')[:300],
                        'url':         film_url,
                        'source':      'rarefilmm',
                        'streams':     streams,
                    })
            except Exception as de:
                xbmc.log('[Starfleet/Scrapers] rarefilmm detail error: %s' % de, xbmc.LOGWARNING)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Scrapers] rarefilmm search error: %s' % e, xbmc.LOGWARNING)
        return []


# ── 1shows.org ────────────────────────────────────────────────────────────────

_RE_1SHOWS_CARD = re.compile(
    r'href="(https?://(?:www\.)?1shows\.org/(?:[a-z0-9-]+/)*([a-z0-9][a-z0-9-]+)/?)"',
    re.IGNORECASE
)
_1SHOWS_SKIP = {
    'page', 'category', 'tag', 'genre', 'country', 'year', 'actor',
    'search', 'watchlist', 'request', 'contact', 'dmca', 'privacy',
    'movies', 'series', 'shows', 'home',
}


def _1shows_search_stubs(title):
    from urllib.parse import quote as _q
    html = _get('%s/?s=%s' % (SHOWS1_BASE, _q(title)))
    stubs, seen = [], set()
    for m in _RE_1SHOWS_CARD.finditer(html):
        url, slug = m.group(1), m.group(2)
        if slug not in _1SHOWS_SKIP and slug not in seen:
            seen.add(slug)
            stubs.append({'url': url, 'slug': slug})
    return stubs


def _1shows_detail(stub):
    url, slug = stub['url'], stub['slug']
    ck = 'scrapers_1shows_%s' % slug[:60]
    cached = _cache_get(ck)
    if cached is not None:
        return cached
    html = _get(url)
    if not html:
        return None
    title = _h1_title(html) or _strip_site_suffix(_og(html, 'title')) or slug.replace('-', ' ').title()
    embeds = _extract_embeds(html)
    film = {
        'id': '1shows_%s' % slug[:40], 'title': title,
        'title_norm': _norm_title(title), 'thumb': _og(html, 'image'),
        'description': _og(html, 'description')[:300],
        'url': url, 'source': '1shows', 'streams': embeds,
    }
    if embeds:
        _cache_set(ck, film, 12 * 3600)
    return film


def search_1shows(title, media_type='movie'):
    try:
        stubs = _1shows_search_stubs(title)
        return _pfetch(stubs, _1shows_detail)
    except Exception as e:
        xbmc.log('[Starfleet/Scrapers] 1shows error: %s' % e, xbmc.LOGWARNING)
        return []


# ── 456movie.nl ───────────────────────────────────────────────────────────────

_RE_456_CARD = re.compile(
    r'href="(https?://(?:www\.)?456movie\.nl/(?:movie|film|series|watch)/([^"/?#\s]+)[^"]*)"',
    re.IGNORECASE
)
_RE_456_CARD_ALT = re.compile(
    r'href="(https?://(?:www\.)?456movie\.nl/([a-z0-9][a-z0-9-]+)/?)"',
    re.IGNORECASE
)
_456_SKIP = {
    'page', 'category', 'tag', 'genre', 'search', 'about', 'contact',
    'privacy', 'dmca', 'sitemap', 'movies', 'series', 'home',
}


def _456_search_stubs(title):
    from urllib.parse import quote as _q
    html = _get('%s/?s=%s' % (M456_BASE, _q(title)))
    stubs, seen = [], set()
    for pattern in (_RE_456_CARD, _RE_456_CARD_ALT):
        for m in pattern.finditer(html):
            url, slug = m.group(1), m.group(2)
            if slug not in _456_SKIP and slug not in seen:
                seen.add(slug)
                stubs.append({'url': url, 'slug': slug})
    return stubs


def _456_detail(stub):
    url, slug = stub['url'], stub['slug']
    ck = 'scrapers_456movie_%s' % slug[:60]
    cached = _cache_get(ck)
    if cached is not None:
        return cached
    html = _get(url)
    if not html:
        return None
    title = _h1_title(html) or _strip_site_suffix(_og(html, 'title')) or slug.replace('-', ' ').title()
    embeds = _extract_embeds(html)
    film = {
        'id': '456movie_%s' % slug[:40], 'title': title,
        'title_norm': _norm_title(title), 'thumb': _og(html, 'image'),
        'description': _og(html, 'description')[:300],
        'url': url, 'source': '456movie', 'streams': embeds,
    }
    if embeds:
        _cache_set(ck, film, 12 * 3600)
    return film


def search_456movie(title, media_type='movie'):
    try:
        stubs = _456_search_stubs(title)
        return _pfetch(stubs, _456_detail)
    except Exception as e:
        xbmc.log('[Starfleet/Scrapers] 456movie error: %s' % e, xbmc.LOGWARNING)
        return []


# ── msearch.vercel.app ────────────────────────────────────────────────────────
# Meta-search aggregator. Tries JSON API first, falls back to HTML scrape.

_RE_MSEARCH_STREAM = re.compile(
    r'(https?://[^"\'<\s]+\.(?:mp4|m3u8|mkv)[^"\'<\s]*)',
    re.IGNORECASE
)


def search_msearch(title, media_type='movie'):
    from urllib.parse import quote as _q
    try:
        # Try JSON API endpoint (common for Vercel Next.js apps)
        data = _get_json('%s/api/search?q=%s&type=%s' % (MSEARCH_BASE, _q(title), media_type))
        if data and isinstance(data, (list, dict)):
            results_raw = data if isinstance(data, list) else (
                data.get('results') or data.get('data') or data.get('items') or []
            )
            films = []
            for item in results_raw[:8]:
                film_title = (
                    item.get('title') or item.get('name') or item.get('t') or ''
                )
                if not film_title:
                    continue
                streams = []
                for key in ('stream', 'url', 'src', 'link', 'video'):
                    su = item.get(key, '')
                    if su and su.startswith('http') and su not in {s['url'] for s in streams}:
                        streams.append({'label': 'MSearch', 'url': su})
                for su in (item.get('sources') or item.get('streams') or []):
                    u = su if isinstance(su, str) else su.get('url', '')
                    if u and u not in {s['url'] for s in streams}:
                        streams.append({'label': 'MSearch', 'url': u})
                if streams:
                    films.append({
                        'id': 'msearch_%s' % re.sub(r'[^a-z0-9]', '_', film_title.lower())[:40],
                        'title': film_title, 'title_norm': _norm_title(film_title),
                        'thumb': item.get('poster') or item.get('thumb') or item.get('image') or '',
                        'description': item.get('plot') or item.get('description') or '',
                        'url': item.get('url') or MSEARCH_BASE, 'source': 'msearch',
                        'streams': streams,
                    })
            if films:
                return films

        # Fallback: HTML scrape
        html = _get('%s/search?q=%s' % (MSEARCH_BASE, _q(title)))
        if not html:
            html = _get('%s/?s=%s' % (MSEARCH_BASE, _q(title)))
        if html:
            streams = []
            for m in _RE_MSEARCH_STREAM.finditer(html):
                su = m.group(1)
                if su not in {s['url'] for s in streams}:
                    streams.append({'label': 'MSearch', 'url': su})
            embeds = _extract_embeds(html)
            streams.extend(embeds)
            if streams:
                return [{
                    'id': 'msearch_results', 'title': title,
                    'title_norm': _norm_title(title), 'thumb': '',
                    'description': '', 'url': MSEARCH_BASE,
                    'source': 'msearch', 'streams': streams,
                }]
    except Exception as e:
        xbmc.log('[Starfleet/Scrapers] msearch error: %s' % e, xbmc.LOGWARNING)
    return []


# ── bflix.se ─────────────────────────────────────────────────────────────────

BFLIX_BASE = 'https://bbflix.watch'

_RE_BFLIX_CARD = re.compile(
    r'href="(https?://(?:www\.)?bbflix\.watch/(?:movie|watch|series|tv)/([^"/?#\s]{3,120})[^"]*)"[^>]*>\s*(?:[^<]*<[^>]+>)*\s*([^<]{3,100})',
    re.IGNORECASE | re.DOTALL
)
_RE_BFLIX_CARD2 = re.compile(
    r'href="(/(?:movie|watch|series|tv)/[^"/?#\s]{3,120})"',
    re.IGNORECASE
)


def search_bflix(title, media_type='movie'):
    from urllib.parse import quote as _q
    # bbflix.watch uses /search?keyword= for both movies and series
    urls = [
        '%s/search?keyword=%s' % (BFLIX_BASE, _q(title)),
    ]
    html = ''
    for u in urls:
        html = _get(u)
        if html and len(html) > 500:
            break
    if not html:
        return []

    # bbflix uses absolute URLs: href="https://bbflix.watch/series/slug-123/"
    path_re = re.compile(
        r'href="(https?://(?:www\.)?bbflix\.watch/(movie|series|watch|tv)/([^"?#\s]{3,120}))"',
        re.IGNORECASE)
    seen, stubs = set(), []
    for m in path_re.finditer(html):
        full_url = m.group(1)
        section  = m.group(2).lower()
        slug     = m.group(3).rstrip('/')
        if full_url in seen:
            continue
        if media_type == 'tv' and section == 'movie':
            continue
        if media_type == 'movie' and section == 'series':
            continue
        seen.add(full_url)
        start = max(0, m.start() - 50)
        ctx   = html[start:m.end() + 200]
        mt    = re.search(r'(?:title=["\']|alt=["\']|<span[^>]*>|<h\d[^>]*>)\s*([^"\'<]{4,80})', ctx, re.IGNORECASE)
        card_title = _clean(mt.group(1)) if mt else slug.rsplit('/', 1)[-1].replace('-', ' ').title()
        stubs.append({'path': full_url, 'title': card_title})
        if len(stubs) >= 25:
            break
    # Rank by title match before capping — confirmed live that the exact
    # film can rank behind several spinoffs/parodies/tributes in the site's
    # own search order (e.g. "The Matrix" behind "Free Your Mind: The Matrix
    # Now", "The Living Matrix", etc.), so capping at 5 by raw page order
    # alone was silently dropping the real match before it ever got a
    # detail-page fetch.
    stubs = _rank_stubs_by_title(stubs, title, limit=5)

    def _fetch_bflix(stub):
        detail_html = _get(stub['path'])
        if not detail_html:
            return None
        embeds = _extract_embeds(detail_html)
        if not embeds:
            return None
        return {
            'id': 'bflix_' + re.sub(r'\W+', '_', stub['title'].lower())[:40],
            'title': stub['title'], 'title_norm': _norm_title(stub['title']),
            'thumb': _og(detail_html, 'image'), 'description': _og(detail_html, 'description'),
            'url': stub['path'], 'source': 'bflix',
            'streams': [{'label': e['label'], 'url': e['url']} for e in embeds],
        }

    results = _pfetch(stubs, _fetch_bflix, limit=4)
    xbmc.log('[Starfleet/Scrapers] bflix "%s": %d results' % (title, len(results)), xbmc.LOGINFO)
    return results


# ── fmoviess.org ──────────────────────────────────────────────────────────────

FMOVIESS_BASE = 'https://fmoviess.org'

_RE_FMOVIESS_CARD = re.compile(
    r'href="(https?://(?:www\.)?fmoviess\.org/(?:movie|watch|film)/[^"/?#\s]{3,120})"',
    re.IGNORECASE
)


def search_fmoviess(title, media_type='movie'):
    from urllib.parse import quote as _q
    html = _get('%s/?s=%s' % (FMOVIESS_BASE, _q(title)))
    if not html:
        html = _get('%s/search/%s' % (FMOVIESS_BASE, _q(title).replace('+', '-').replace('%20', '-')))
    if not html:
        return []

    seen, stubs = set(), []
    for m in _RE_FMOVIESS_CARD.finditer(html):
        url = m.group(1)
        if url in seen:
            continue
        seen.add(url)
        ctx = html[m.end():m.end() + 300]
        mt  = re.search(r'(?:title=["\']|alt=["\']|class="[^"]*title[^"]*"[^>]*>)\s*([^"\'<]{4,80})', ctx, re.IGNORECASE)
        card_title = _clean(mt.group(1)) if mt else title
        stubs.append({'url': url, 'title': card_title})
        if len(stubs) >= 5:
            break

    def _fetch_fm(stub):
        dh = _get(stub['url'])
        if not dh:
            return None
        embeds = _extract_embeds(dh)
        if not embeds:
            return None
        return {
            'id': 'fmoviess_' + re.sub(r'\W+', '_', stub['title'].lower())[:40],
            'title': stub['title'], 'title_norm': _norm_title(stub['title']),
            'thumb': _og(dh, 'image'), 'description': _og(dh, 'description'),
            'url': stub['url'], 'source': 'fmoviess',
            'streams': [{'label': e['label'], 'url': e['url']} for e in embeds],
        }

    results = _pfetch(stubs, _fetch_fm, limit=4)
    xbmc.log('[Starfleet/Scrapers] fmoviess "%s": %d results' % (title, len(results)), xbmc.LOGINFO)
    return results


# ── solarmovie.net.pk ─────────────────────────────────────────────────────────

SOLAR_BASE = 'https://www.solarmovie.net.pk'

_RE_SOLAR_CARD = re.compile(
    r'href="(https?://(?:www\.)?solarmovie\.net\.pk/(?:movie|watch|film|play)/[^"/?#\s]{3,120})"',
    re.IGNORECASE
)


def search_solarmovie(title, media_type='movie'):
    from urllib.parse import quote as _q
    urls = [
        '%s/search/?q=%s' % (SOLAR_BASE, _q(title)),
        '%s/?s=%s' % (SOLAR_BASE, _q(title)),
        '%s/search/%s/' % (SOLAR_BASE, _q(title).replace('+', '-').replace('%20', '-')),
    ]
    html = ''
    for u in urls:
        html = _get(u)
        if html and len(html) > 500:
            break
    if not html:
        return []

    seen, stubs = set(), []
    for m in _RE_SOLAR_CARD.finditer(html):
        url = m.group(1)
        if url in seen:
            continue
        seen.add(url)
        ctx = html[m.end():m.end() + 300]
        mt  = re.search(r'(?:title=["\']|alt=["\']|<h\d[^>]*>|class="[^"]*title[^"]*"[^>]*>)\s*([^"\'<]{4,80})', ctx, re.IGNORECASE)
        card_title = _clean(mt.group(1)) if mt else title
        stubs.append({'url': url, 'title': card_title})
        if len(stubs) >= 5:
            break

    def _fetch_solar(stub):
        dh = _get(stub['url'])
        if not dh:
            return None
        embeds = _extract_embeds(dh)
        if not embeds:
            return None
        return {
            'id': 'solar_' + re.sub(r'\W+', '_', stub['title'].lower())[:40],
            'title': stub['title'], 'title_norm': _norm_title(stub['title']),
            'thumb': _og(dh, 'image'), 'description': _og(dh, 'description'),
            'url': stub['url'], 'source': 'solarmovie',
            'streams': [{'label': e['label'], 'url': e['url']} for e in embeds],
        }

    results = _pfetch(stubs, _fetch_solar, limit=4)
    xbmc.log('[Starfleet/Scrapers] solarmovie "%s": %d results' % (title, len(results)), xbmc.LOGINFO)
    return results


# ── filmslook.com ─────────────────────────────────────────────────────────────

FILMSLOOK_BASE = 'https://filmslook.com'

_RE_FILMSLOOK_CARD = re.compile(
    r'href="(https?://(?:www\.)?filmslook\.com/(?:movies?|watch|film|series|tv)/[^"?#\s]{3,200})"',
    re.IGNORECASE
)


def search_filmslook(title, media_type='movie'):
    from urllib.parse import quote as _q
    # /search?keyword= silently ignores the query and serves the generic
    # "latest films" feed instead of a 404/empty response (confirmed live:
    # searching "Superman" returned zero occurrences of the word anywhere in
    # the page) — since it still passes the len>500 "did this work" check
    # below, the real, working endpoint (WordPress-native /?s=, confirmed
    # live to return genuine title-matching results) was never even tried.
    # /?s= now tried first; /search?keyword= kept as a fallback only.
    urls = [
        '%s/?s=%s' % (FILMSLOOK_BASE, _q(title)),
        '%s/search?keyword=%s' % (FILMSLOOK_BASE, _q(title)),
    ]
    html = ''
    for u in urls:
        html = _get(u)
        if html and len(html) > 500:
            break
    if not html:
        return []

    seen, stubs = set(), []
    for m in _RE_FILMSLOOK_CARD.finditer(html):
        url = m.group(1)
        if url in seen:
            continue
        seen.add(url)
        ctx = html[m.end():m.end() + 300]
        mt  = re.search(r'(?:title=["\']|alt=["\']|<h\d[^>]*>|class="[^"]*title[^"]*"[^>]*>)\s*([^"\'<]{4,80})', ctx, re.IGNORECASE)
        card_title = _clean(mt.group(1)) if mt else title
        stubs.append({'url': url, 'title': card_title})
        if len(stubs) >= 25:
            break
    stubs = _rank_stubs_by_title(stubs, title, limit=5)

    def _fetch_fl(stub):
        dh = _get(stub['url'])
        if not dh:
            return None
        embeds = _extract_embeds(dh)
        if not embeds:
            return None
        return {
            'id': 'filmslook_' + re.sub(r'\W+', '_', stub['title'].lower())[:40],
            'title': stub['title'], 'title_norm': _norm_title(stub['title']),
            'thumb': _og(dh, 'image'), 'description': _og(dh, 'description'),
            'url': stub['url'], 'source': 'filmslook',
            'streams': [{'label': e['label'], 'url': e['url']} for e in embeds],
        }

    results = _pfetch(stubs, _fetch_fl, limit=4)
    xbmc.log('[Starfleet/Scrapers] filmslook "%s": %d results' % (title, len(results)), xbmc.LOGINFO)
    return results


# ── ici.tou.tv (Radio-Canada OTT catalog) ────────────────────────────────────

TOUTV_CATALOG = 'https://services.radio-canada.ca/ott/catalog/v2/toutv'
TOUTV_STREAM  = 'https://services.radio-canada.ca/media/validation/v2/'

_RE_TOUTV_M3U8 = re.compile(r'url["\s]*:["\s]*(https?://[^"\'<\s]+\.m3u8[^"\'<\s]*)', re.IGNORECASE)


def _toutv_stream_url(media_id):
    """Resolve a tou.tv mediaId to an HLS stream URL (free content only)."""
    from urllib.parse import urlencode
    params = urlencode({
        'appCode':        'toutv',
        'idMedia':        str(media_id),
        'connectionType': 'hd',
        'deviceType':     'ipad',
        'manifestType':   'm3u8',
        'output':         'json',
    })
    try:
        s = _sess()
        if not s:
            return ''
        r = s.get('%s?%s' % (TOUTV_STREAM, params), timeout=(6, 12),
                  headers=dict(_HEADERS, Referer='https://ici.tou.tv/'))
        if r.status_code != 200:
            return ''
        data = r.json()
        url = (data.get('url') or data.get('mediaUrl') or
               (data.get('validationData') or {}).get('url', ''))
        return url or ''
    except Exception:
        return ''


def search_toutv(title, media_type='movie'):
    """Search ici.tou.tv for free French-Canadian content."""
    from urllib.parse import quote as _q
    try:
        s    = _sess()
        if not s:
            return []
        data = s.get(
            '%s/search?q=%s&locale=fr_CA&items=10' % (TOUTV_CATALOG, _q(title)),
            timeout=(6, 12), headers=dict(_HEADERS, Referer='https://ici.tou.tv/')
        ).json()
    except Exception as e:
        xbmc.log('[Starfleet/Scrapers] toutv search error: %s' % e, xbmc.LOGWARNING)
        return []

    items = (data.get('items') or data.get('medias') or
             data.get('results') or data.get('data') or [])
    if not items and isinstance(data, list):
        items = data

    results = []
    for item in items[:8]:
        media_id = (item.get('mediaId') or item.get('id') or item.get('appMediaId') or '')
        film_title = (item.get('title') or item.get('label') or
                      item.get('name') or item.get('mediaTitle') or '')
        if not film_title:
            continue
        is_free = not item.get('isExtra', False)
        thumb = ''
        for img_key in ('thumbnail', 'image', 'poster', 'logo'):
            img = item.get(img_key)
            if isinstance(img, str):
                thumb = img
                break
            elif isinstance(img, dict):
                thumb = img.get('url', img.get('src', img.get('path', '')))
                if thumb:
                    break

        streams = []
        if media_id and is_free:
            su = _toutv_stream_url(media_id)
            if su:
                streams.append({'label': 'Tou.tv', 'url': su})

        # Always include the page URL as a fallback embed
        page_url = 'https://ici.tou.tv/%s' % (
            item.get('url') or item.get('slug') or media_id or ''
        )
        if not streams and media_id:
            streams.append({'label': 'Tou.tv (auth required)', 'url': page_url})

        if streams:
            results.append({
                'id': 'toutv_%s' % str(media_id),
                'title': film_title, 'title_norm': _norm_title(film_title),
                'thumb': thumb, 'description': item.get('description', ''),
                'url': page_url, 'source': 'toutv', 'streams': streams,
            })

    xbmc.log('[Starfleet/Scrapers] toutv "%s": %d results' % (title, len(results)), xbmc.LOGINFO)
    return results


# ── srstop.link (TV shows only — confirmed live, no movies section exists) ────

SRSTOP_BASE = 'https://srstop.link'

_RE_SRSTOP_ONCLICK = re.compile(r'<a class="embed-selector[^"]*"[^>]*onclick="([^"]+)"')
_RE_SRSTOP_DBNEG    = re.compile(r"dbneg\('([^']+)'\)")


def _srstop_decode(code):
    """Decode srstop.link's obfuscated embed-host codes: hex byte values
    joined by '-', each shifted by a constant offset derived from the
    FIRST value (offset = first_value - ord('h')). Same algorithm the
    cMaN-repo "TV Free" addon's own bst.py plugin uses for this exact
    site (credited there to "T4ils") — confirmed correct here against a
    real decoded episode page rather than assumed from that addon's code
    alone."""
    ret = []
    offset = None
    for part in code.split('-'):
        try:
            val = int(part, 16)
        except ValueError:
            return ''
        if offset is None:
            offset = val - ord('h')
        ret.append(chr(val - offset))
    return ''.join(ret)


def _srstop_search_stubs(title):
    from urllib.parse import quote as _q
    try:
        r = _sess().post('%s/ajax/search.php?q=%s' % (SRSTOP_BASE, _q(title)), timeout=10)
        r.raise_for_status()
        data = r.json()
    except Exception as e:
        xbmc.log('[Starfleet/Scrapers] srstop search error: %s' % e, xbmc.LOGWARNING)
        return []
    return data if isinstance(data, list) else []


def search_srstop(title, media_type='movie', season=None, episode=None, imdb_id=None):
    """srstop.link — TV shows ONLY (confirmed live: the site's own title
    is "Watch TV shows for free", no movies section exists at all).
    Requires season+episode (Starfleet's own TV play flow always has both
    by the time source search runs) — the site's per-episode URL is fully
    predictable once the show's slug is known, confirmed live:
    "<permalink>-s{S:02d}e{E:02d}/season/{S}/episode/{E}" loads the exact
    episode directly, no need to page through the show's own episode-list
    grid. Search's own JSON response already includes each show's real
    imdb_id, so that's preferred over fuzzy title matching when available
    — more reliable than every other scraper in this file, none of which
    get an imdb_id straight from the site itself."""
    if media_type != 'tv' or not season or not episode:
        return []

    stubs = _srstop_search_stubs(title)
    if not stubs:
        return []

    match = None
    if imdb_id:
        match = next((s for s in stubs if str(s.get('imdb_id', '')) == str(imdb_id)), None)
    if not match:
        ranked = _rank_stubs_by_title(stubs, title, limit=1)
        match = ranked[0] if ranked else None
    if not match or not match.get('permalink'):
        return []

    permalink = match['permalink'].rstrip('/')
    season, episode = int(season), int(episode)
    ep_url = '%s-s%02de%02d/season/%d/episode/%d' % (permalink, season, episode, season, episode)
    slug = permalink.rsplit('/', 1)[-1][:40]

    ck = 'scrapers_srstop_%s_s%02de%02d' % (slug, season, episode)
    cached = _cache_get(ck)
    if cached is not None:
        return cached

    html = _get(ep_url)
    if not html:
        return []

    streams, seen = [], set()
    for onclick_m in _RE_SRSTOP_ONCLICK.finditer(html):
        code_m = _RE_SRSTOP_DBNEG.search(onclick_m.group(1))
        if not code_m:
            continue
        url = _srstop_decode(code_m.group(1))
        if not url or not url.startswith('http') or url in seen:
            continue
        if _STREAM_SKIP_search(url):
            continue
        seen.add(url)
        dom = re.search(r'https?://(?:www\.)?([^./]+)', url)
        label = dom.group(1).capitalize() if dom else 'Embed'
        streams.append({'label': label, 'url': url})

    if not streams:
        return []

    film_title = match.get('title', title)
    film = {
        'id': 'srstop_%s_s%02de%02d' % (slug, season, episode),
        'title': film_title, 'title_norm': _norm_title(film_title),
        'thumb': match.get('image', ''), 'description': '',
        'url': ep_url, 'source': 'srstop', 'streams': streams,
    }
    _cache_set(ck, [film], 6 * 3600)
    xbmc.log('[Starfleet/Scrapers] srstop "%s" S%02dE%02d: %d streams'
             % (title, season, episode, len(streams)), xbmc.LOGINFO)
    return [film]


# ── vavoo.to ──────────────────────────────────────────────────────────────────
#
# Investigated live 2026-08-21 per direct request. vavoo.to's own frontend
# is a client-rendered app calling three plain, unauthenticated POST JSON
# endpoints (the "MediaHubMX" protocol, confirmed against a real browser
# capture of the site's own network traffic — every attempt to guess the
# request bodies blind returned "Validation error", the real shapes below
# only came from that capture):
#   1. POST /mediahubmx-catalog.json {catalogId:'tmdb.movie'|'tmdb.series',
#      search:<title>, ...} -> matching items keyed by tmdb_id
#   2. POST /mediahubmx-source.json {type:'movie', ids:{tmdb_id}} for movies,
#      or {type:'series', ids:{tmdb_id}, episode:{season, episode}} for a
#      specific TV episode -> a list of third-party embed URLs
# vavoo.to itself hosts nothing — every source it returns is a normal
# embed on a host this addon (via ResolveURL) already knows: voe.sx,
# dood.to/dood.yt, mixdrop.ps, vidoza.net, veev.to, vidsonic.net, etc.
# Confirmed live end-to-end for both a movie and a TV episode. Per direct
# request, only 'en'-tagged results are kept — the same catalogue also
# returns de/hi/ta/te/pl (and others) dubbed/subbed copies of the exact
# same title, confirmed live these come back regardless of the request's
# own language/region fields (they don't filter server-side at all).
_VAVOO_BASE = 'https://vavoo.to'


def _vavoo_post(endpoint, body):
    try:
        r = _sess().post('%s/%s' % (_VAVOO_BASE, endpoint), json=body,
                         headers={'Content-Type': 'application/json; charset=utf-8'}, timeout=12)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        xbmc.log('[Starfleet/Scrapers] vavoo %s error: %s' % (endpoint, e), xbmc.LOGWARNING)
        return None


def search_vavoo(title, media_type='movie', season=None, episode=None):
    if media_type not in ('movie', 'tv'):
        return []
    if media_type == 'tv' and not (season and episode):
        return []

    catalog_id = 'tmdb.movie' if media_type == 'movie' else 'tmdb.series'
    catalog = _vavoo_post('mediahubmx-catalog.json', {
        'language': 'en', 'region': 'US', 'catalogId': catalog_id, 'id': '',
        'adult': False, 'search': title, 'sort': 'trendingDay', 'filter': {}, 'cursor': None,
    })
    items = (catalog or {}).get('items') or []
    norm_q = _norm_title(title)
    match = next((it for it in items if _title_matches(norm_q, _norm_title(it.get('name', '')))), None)
    if not match:
        return []
    tmdb_id = (match.get('ids') or {}).get('tmdb_id')
    if not tmdb_id:
        return []

    if media_type == 'movie':
        source_body = {'language': 'en', 'region': 'US', 'type': 'movie',
                       'ids': {'tmdb_id': tmdb_id}, 'name': ''}
    else:
        source_body = {'language': 'en', 'region': 'US', 'type': 'series',
                       'ids': {'tmdb_id': tmdb_id}, 'name': '',
                       'episode': {'ids': {}, 'season': int(season), 'episode': int(episode)}}

    raw_sources = _vavoo_post('mediahubmx-source.json', source_body) or []
    streams = []
    for s in raw_sources:
        url = s.get('url', '')
        if not url or 'en' not in (s.get('languages') or []) or _STREAM_SKIP_search(url):
            continue
        label = s.get('name', 'Server')
        if s.get('tag'):
            label = '%s [%s]' % (label, s['tag'])
        streams.append({'label': label, 'url': url})
    if not streams:
        return []

    film_title = match.get('name', title)
    film = {
        'id': 'vavoo_%s' % tmdb_id,
        'title': film_title, 'title_norm': _norm_title(film_title),
        'thumb': (match.get('images') or {}).get('poster', ''),
        'description': match.get('description', ''),
        'url': '', 'source': 'vavoo', 'streams': streams,
    }
    xbmc.log('[Starfleet/Scrapers] vavoo "%s" (%s): %d streams' % (title, media_type, len(streams)),
             xbmc.LOGINFO)
    return [film]


# ── Title matching ────────────────────────────────────────────────────────────

def _title_matches(norm_query, norm_film):
    """Return True if the normalised query matches a film title closely enough."""
    if not norm_query or not norm_film:
        return False
    if norm_query == norm_film:
        return True
    q_words = norm_query.split()
    f_words = norm_film.split()
    if len(q_words) >= 2 and all(w in norm_film for w in q_words):
        return True
    if len(f_words) >= 2 and all(w in norm_query for w in f_words):
        return True
    return False


# ── Unified search ────────────────────────────────────────────────────────────

# ── LookMovie2 ────────────────────────────────────────────────────────────────

_LM2_BASE = 'https://www.lookmovie2.to'

def search_lookmovie2(title, media_type='movie', season=None, episode=None):
    """
    lookmovie2.to — search → extract server-signed hash → call stream API → direct HLS.

    Flow:
      1. Search /movies/search/?q= or /shows/search/?q=
      2. Fetch play page, parse window['movie_storage'] or window['show_storage']
      3. POST to /api/v1/security/movie-access or episode-access with id+hash+expires
      4. Return direct m3u8 stream URLs (480p/720p/1080p)
    """
    from urllib.parse import quote as _q
    import json as _json
    if not _HAS_REQUESTS or not title:
        return []
    try:
        s = _sess()
        if s is None:
            return []

        if media_type == 'tv':
            search_html = _get('%s/shows/search/?q=%s' % (_LM2_BASE, _q(title)))
            link_m = re.search(r'href="(/shows/view/([^"]+))"', search_html)
            if not link_m:
                return []
            view_path = link_m.group(1)
            play_path = view_path.replace('/view/', '/play/')

            play_html = _get(_LM2_BASE + play_path)
            storage_m = re.search(r"window\['show_storage'\]\s*=\s*\{([^;]+)\};", play_html, re.DOTALL)
            if not storage_m:
                return []
            raw = storage_m.group(1)

            hash_m    = re.search(r"hash:\s*['\"]([^'\"]+)['\"]", raw)
            expires_m = re.search(r'expires:\s*(\d+)', raw)
            if not (hash_m and expires_m):
                return []

            # Find id_episode matching requested season+episode
            target_s = str(season or 1)
            target_e = str(episode or 1)
            # seasons list has objects: {title, index, episode, id_episode, season}
            ep_id = None
            for ep_m in re.finditer(r'\{[^}]+id_episode:\s*(\d+)[^}]+\}', raw):
                blk = ep_m.group(0)
                s_m = re.search(r"season:\s*['\"]?(%s)['\"]?" % re.escape(target_s), blk)
                e_m = re.search(r"episode:\s*['\"]?(%s)['\"]?" % re.escape(target_e), blk)
                if s_m and e_m:
                    ep_id = ep_m.group(1)
                    break
            if not ep_id:
                return []

            api_url = ('%s/api/v1/security/episode-access?id_episode=%s&hash=%s&expires=%s'
                       % (_LM2_BASE, ep_id, hash_m.group(1), expires_m.group(1)))
            api_ref  = _LM2_BASE + play_path

        else:
            search_html = _get('%s/movies/search/?q=%s' % (_LM2_BASE, _q(title)))
            link_m = re.search(r'href="(/movies/view/([^"]+))"', search_html)
            if not link_m:
                return []
            view_path = link_m.group(1)
            play_path = view_path.replace('/view/', '/play/')

            play_html = _get(_LM2_BASE + play_path)
            storage_m = re.search(r"window\['movie_storage'\]\s*=\s*\{([^}]+)\}", play_html, re.DOTALL)
            if not storage_m:
                return []
            raw = storage_m.group(1)

            id_m      = re.search(r'id_movie:\s*(\d+)', raw)
            hash_m    = re.search(r"hash:\s*['\"]([^'\"]+)['\"]", raw)
            expires_m = re.search(r'expires:\s*(\d+)', raw)
            if not (id_m and hash_m and expires_m):
                return []

            api_url = ('%s/api/v1/security/movie-access?id_movie=%s&hash=%s&expires=%s'
                       % (_LM2_BASE, id_m.group(1), hash_m.group(1), expires_m.group(1)))
            api_ref  = _LM2_BASE + play_path

        r = _sess().get(api_url, headers=dict(_HEADERS, Referer=api_ref), timeout=10)
        data = r.json()
        if not data.get('success'):
            return []

        results = []
        streams = data.get('streams', {})
        # movie-access keys are 'p'-suffixed ('480p'); episode-access (TV)
        # keys are bare digits ('480') — confirmed live, two genuinely
        # different conventions on the same site. Checking both means this
        # works regardless of which endpoint this call went through instead
        # of silently missing every TV result the bare-digit key held.
        for quality in ('1080p', '720p', '480p'):
            url = streams.get(quality) or streams.get(quality.rstrip('p'))
            if url and isinstance(url, str):
                results.append({
                    'title': title, 'title_norm': _norm_title(title),
                    'streams': [{'label': 'LookMovie2 [%s]' % quality, 'url': url}],
                    'source': 'lookmovie2',
                })
        xbmc.log('[Starfleet/Scrapers] lookmovie2 "%s" → %d streams' % (title, len(results)), xbmc.LOGINFO)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Scrapers] lookmovie2 error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Nuvio (IMDb-based Stremio-compatible direct stream API) ───────────────────

NUVIO_BASE = 'https://nuviostreams.hayd.uk'
_RE_QUALITY = re.compile(
    r'\b(4K|2160p?|UHD|1080p?|1080i|720p?|480p?|WEB-?DL|WEBRip|BluRay|HDTV|HDRip)\b',
    re.IGNORECASE
)


def search_nuvio(imdb_id, media_type='movie', season=None, episode=None):
    """Nuvio free direct stream API — IMDb-ID based, no auth required."""
    if not imdb_id:
        return []
    try:
        if media_type == 'tv' and season and episode:
            url = '%s/stream/series/%s:%s:%s.json' % (NUVIO_BASE, imdb_id, season, episode)
        else:
            url = '%s/stream/movie/%s.json' % (NUVIO_BASE, imdb_id)
        data = _get_json(url, timeout=(8, 35))
        if not data or not isinstance(data.get('streams'), list):
            return []
        results = []
        for stream in data['streams']:
            stream_url = stream.get('url', '')
            if not stream_url:
                continue
            name = stream.get('title', '')
            q_m = _RE_QUALITY.search(name)
            label = q_m.group(0).upper() if q_m else (name[:30] if name else 'Stream')
            results.append({
                'label':  '[NUVIO] %s' % label,
                'url':    stream_url,
                'source': 'nuvio',
            })
        xbmc.log('[Starfleet/Nuvio] %s → %d streams' % (imdb_id, len(results)), xbmc.LOGINFO)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Nuvio] error: %s' % e, xbmc.LOGWARNING)
        return []


# ── WebStreamer (IMDb-based Stremio-compatible direct stream API) ──────────────

WEBSTREAMER_BASE = 'https://webstreamr.hayd.uk'
_RE_FLAG_EMOJI = re.compile(
    u'[\U0001F1E0-\U0001F1FF\U0001F300-\U0001F9FF☀-⛿✀-➿]',
    re.UNICODE
)


def search_webstreamer(imdb_id, media_type='movie', season=None, episode=None):
    """WebStreamer free direct stream API — IMDb-ID based, no auth required."""
    if not imdb_id:
        return []
    try:
        if media_type == 'tv' and season and episode:
            url = '%s/stream/series/%s:%s:%s.json' % (WEBSTREAMER_BASE, imdb_id, season, episode)
        else:
            url = '%s/stream/movie/%s.json' % (WEBSTREAMER_BASE, imdb_id)
        data = _get_json(url, timeout=(8, 25))
        if not data or not isinstance(data.get('streams'), list):
            return []
        results = []
        for stream in data['streams']:
            stream_url = stream.get('url', '')
            if not stream_url:
                continue
            if 'video-downloads.googleusercontent' in stream_url:
                continue
            stream_url = stream_url.replace('pixeldrain.dev/u/', 'pixeldrain.dev/api/file/')
            raw_title = stream.get('title', '')
            name = _RE_FLAG_EMOJI.sub('', raw_title).split('\n')[0].strip()
            q_m = _RE_QUALITY.search(name)
            label = q_m.group(0).upper() if q_m else (name[:30] if name else 'Stream')
            results.append({
                'label':  '[WEBSTREAMER] %s' % label,
                'url':    stream_url,
                'source': 'webstreamer',
            })
        xbmc.log('[Starfleet/WebStreamer] %s → %d streams' % (imdb_id, len(results)), xbmc.LOGINFO)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/WebStreamer] error: %s' % e, xbmc.LOGWARNING)
        return []


# ── "fmovie" WordPress theme family (ramoflix.net, doraby.com, ...) ───────────
# Movie pages on sites running this theme embed a `var Servers = {...}` JSON
# blob directly in the raw HTML with ready-to-use embed URLs for several
# providers — no AJAX call or JS execution needed at all, confirmed live via
# a real browser render vs. the plain HTTP response (identical).
#
# The JSON's own key names (embedru/vidlink/superembed/vidsrc/vidsrc2/
# movieclub/...) do NOT reliably map to the same provider across different
# sites running this theme — confirmed live: ramoflix.net's "vidsrc" key
# points at vidcore.net, but doraby.com's "vidsrc" key points at
# 111movies.com instead. Each site operator apparently configures which
# provider fills which slot independently. Labels are therefore derived from
# each URL's actual domain rather than trusted from the key name, so this
# stays correct regardless of how any given site (or a future one running
# the same theme) has its slots wired up.
#
# TV shows use a separate per-episode AJAX call (infoEpisodio(post_id,
# season, episode) -> admin-ajax.php with a page-load nonce) that isn't
# implemented here — movies only for now.

_RE_FMOVIE_SERVERS = re.compile(r'var\s+Servers\s*=\s*(\{.*?\});', re.DOTALL)
_FMOVIE_NAV_SLUGS  = {'category', 'request', 'wp-content', 'wp-admin', 'wp-json'}


def _fmovie_theme_search_stubs(base_url, base_host, title):
    from urllib.parse import quote as _q
    result_re = re.compile(
        r'<div class="meta">.*?<a href="(https?://%s/([a-z0-9-]+)/)">([^<]{2,120})</a>'
        % re.escape(base_host),
        re.IGNORECASE
    )
    html = _get('%s/?s=%s' % (base_url, _q(title)))
    if not html:
        return []
    seen, stubs = set(), []
    for url, slug, link_text in result_re.findall(html):
        if slug.split('/')[0] in _FMOVIE_NAV_SLUGS or url in seen:
            continue
        seen.add(url)
        stubs.append({'url': url, 'title': _clean(link_text)})
        if len(stubs) >= 25:
            break
    return _rank_stubs_by_title(stubs, title, limit=5)


_FMOVIE_GENERIC_SUBDOMAINS = ('www', 'player', 'embed', 'api', 'cdn', 'stream')


def _fmovie_brand_from_host(host):
    """Best-effort brand name from a hostname for a stream label — e.g.
    'player.videasy.net' -> 'Videasy', not 'Player' (the literal first
    label). Strips one generic subdomain prefix if present, then takes the
    next label as the brand."""
    parts = host.split('.')
    if len(parts) >= 3 and parts[0] in _FMOVIE_GENERIC_SUBDOMAINS:
        parts = parts[1:]
    return (parts[0] if parts else host).capitalize()


def _fmovie_theme_detail(stub, site_source, base_host):
    dh = _get(stub['url'])
    if not dh:
        return None
    m = _RE_FMOVIE_SERVERS.search(dh)
    if not m:
        return None
    try:
        import json as _json
        servers = _json.loads(m.group(1))
    except Exception:
        return None

    streams = []
    seen_domains = set()
    for val in servers.values():
        if not (isinstance(val, str) and val.startswith('http')):
            continue
        dom_m = re.search(r'https?://(?:www\.)?([^/]+)', val)
        if not dom_m:
            continue
        host = dom_m.group(1)
        # 'site'/'domain'/similar metadata fields in this JSON blob point
        # back at the scraped site itself (e.g. its own /wp-content/themes/
        # path or homepage) — confirmed live these aren't real embed
        # providers at all, just got swept up by "any http value counts".
        if host in seen_domains or host == base_host or host.endswith('.' + base_host):
            continue
        seen_domains.add(host)
        streams.append({'label': '%s (%s)' % (site_source, _fmovie_brand_from_host(host)), 'url': val})
    if not streams:
        return None

    img = servers.get('image', '') or ''
    thumb = ('https:' + img) if img.startswith('//') else img

    return {
        'id': site_source.lower() + '_' + re.sub(r'\W+', '_', stub['title'].lower())[:40],
        'title': stub['title'], 'title_norm': _norm_title(stub['title']),
        'thumb': thumb, 'description': '',
        'url': stub['url'], 'source': site_source.lower(),
        'streams': streams,
    }


RAMOFLIX_BASE = 'https://ramoflix.net'


def search_ramoflix(title, media_type='movie'):
    if media_type != 'movie':
        return []
    try:
        stubs = _fmovie_theme_search_stubs(RAMOFLIX_BASE, 'ramoflix.net', title)
        return _pfetch(stubs, lambda s: _fmovie_theme_detail(s, 'RamoFlix', 'ramoflix.net'))
    except Exception as e:
        xbmc.log('[Starfleet/Scrapers] ramoflix error: %s' % e, xbmc.LOGWARNING)
        return []


DORABY_BASE = 'https://doraby.com'


def search_doraby(title, media_type='movie'):
    if media_type != 'movie':
        return []
    try:
        stubs = _fmovie_theme_search_stubs(DORABY_BASE, 'doraby.com', title)
        return _pfetch(stubs, lambda s: _fmovie_theme_detail(s, 'Doraby', 'doraby.com'))
    except Exception as e:
        xbmc.log('[Starfleet/Scrapers] doraby error: %s' % e, xbmc.LOGWARNING)
        return []


def search_all_scrapers(title, media_type='movie', season=None, episode=None, imdb_id=None):
    """
    Search all scraper sources in parallel for the given title.
    Works for media_type 'movie', 'tv', or 'adult' — no content is filtered
    at the scraper level; resolution happens via ResolveURL at play time.

    When imdb_id is provided, also queries Nuvio and WebStreamer direct APIs.
    Returns list of {'label', 'url', 'source'} stream dicts.
    """
    from concurrent.futures import ThreadPoolExecutor, as_completed

    if not _HAS_REQUESTS or not title:
        return []

    norm_query = _norm_title(title)

    # Title-based HTML scrapers — return film dicts with 'streams' lists
    title_tasks = {
        # cuevana3.eu: rebuilt as a client-rendered Next.js app with a real
        # bot-detection gate in front of it (confirmed live via a real
        # browser, not just requests) — no server-rendered content reachable
        # at all anymore. Removed 2026-07-25.
        # hdtodayz.to: dead (connection refused) — removed 2026-07-04
        # bbflix.watch: search still finds real matching titles, but the
        # actual movie page has zero extractable embeds (confirmed via both
        # a plain HTTP fetch and a real rendered browser), and live browsing
        # it triggered a fake "(1) New Message!" tab-title popup — a known
        # malvertising pattern. Not worth the risk for zero real results.
        # Removed 2026-07-25.
        # zaxflix.com: not actually JS-rendering-gated — confirmed live its
        # movie cards link straight to Pluto TV/Tubi/YouTube URLs, no embed
        # of its own to scrape at all — but its own on-site Search button is
        # currently non-functional site-wide (confirmed via a real browser:
        # clicking Search does nothing, no results ever load), so there's no
        # way to reach a specific title's page regardless. Removed 2026-07-25.
        'rarefilmm':  lambda: search_rarefilmm(title, media_type),
        # 1shows.org: domain has been repurposed — navigating to it now
        # redirects straight to an unrelated YouTube video (confirmed live).
        # Not the same site anymore. Removed 2026-07-25.
        # 456movie.nl: domain no longer resolves at all (confirmed live,
        # DNS NXDOMAIN) — removed 2026-07-25.
        # fmoviess.org: JS-rendered, not scrapable — removed 2026-07-06
        # filmslook.com: search now finds real matches (fixed 2026-07-25),
        # but its actual film pages have zero extractable embeds (confirmed
        # on the correct page for a real search hit) — same dead-end as
        # bbflix, just without the malvertising. Removed 2026-07-25.
        # toutv (Radio-Canada's TOU.TV): dropped per explicit request —
        # confirmed live returning 0 results across dozens of real Adult
        # searches in a row, and being a mainstream French-Canadian public
        # broadcaster's own catalog, it was never a realistic source for
        # that content in the first place. Was also unconditionally
        # included for every Movies/TV search regardless of media_type,
        # so this also trims one more always-run, rarely-if-ever-useful
        # source out of the per-search wait on every single title, not
        # just Adult ones. Removed 2026-07-29.
        'lookmovie2':  lambda: search_lookmovie2(title, media_type, season=season, episode=episode),
        # srstop.link: TV shows only (confirmed live, no movies section) —
        # per direct request. No-ops immediately for movie/adult searches
        # via its own media_type check, so it's safe to include unconditionally
        # here the same way lookmovie2/rarefilmm already are.
        'srstop':      lambda: search_srstop(title, media_type, season=season, episode=episode, imdb_id=imdb_id),
        # vavoo.to: movies AND TV, per direct request — real, working
        # embeds on already-supported hosts (voe.sx/dood/mixdrop/etc),
        # confirmed live for both. No-ops on 'adult' via its own
        # media_type check, safe to include unconditionally.
        'vavoo':       lambda: search_vavoo(title, media_type, season=season, episode=episode),
        # ramoflix.net / doraby.com: search/matching still works correctly
        # (confirmed), but every provider URL they return
        # (vidcore.net, 111movies.com, player.videasy.net, player.vidzee.wtf)
        # is a client-rendered app with zero stream data in the raw page —
        # confirmed live, none of them work without executing real
        # JavaScript, which this addon's Python runtime cannot do at all.
        # soap2night.cc (the remaining provider) doesn't resolve as a domain
        # anymore. Removed 2026-07-25 rather than leave a source wired in
        # that guarantees a failed playback attempt on every single click —
        # a real fix needs pre-resolving these offline via the standalone
        # scraper PC's Playwright-based resolver (same approach already
        # used for embed.st in scraper_streameast.py) and shipping the
        # result as JSON, not a live in-app resolver — no such Python-only
        # resolver can exist for these hosts.
        # cineby.at: investigated 2026-08-03 per explicit request. Real
        # TMDB-id-based URLs (/movie/{tmdb_id}, /tv/{tmdb_id} — would have
        # needed zero title-matching at all), but its actual player loads
        # through videasy.to/videasy.net (confirmed live via a real
        # Playwright network capture) — the exact same client-rendered,
        # zero-extractable-stream player already confirmed dead here for
        # ramoflix.net/doraby.com above. Same class of dead end, same fix
        # needed (standalone Playwright resolver, not a live scraper) —
        # not built per explicit instruction (not worth the effort for a
        # full on-demand movie/TV catalog, unlike the bounded "today's
        # live events" scope the standalone sports scrapers cover).
        # cinejoy.to: investigated 2026-08-03 — client-rendered app shell
        # (5.9KB homepage, no server-rendered content at all), same
        # architecture problem as cineby.at. Not pursued further per
        # explicit instruction to drop all 3 candidates.
        # 67movies.nl: investigated 2026-08-03 — also a client-rendered
        # Next.js app (real content ships as an RSC payload inside
        # self.__next_f.push([...]) script chunks, not plain HTML), same
        # architecture problem. Not pursued further per explicit
        # instruction to drop all 3 candidates.
    }

    # IMDb-based API scrapers — return flat stream dicts directly (only when imdb_id known)
    imdb_tasks = {}
    if imdb_id and media_type in ('movie', 'tv'):
        imdb_tasks = {
            # nuvio / webstreamer: deprecated 2026-07-06
        }

    streams    = []
    seen_urls  = set()

    all_tasks = dict(list(title_tasks.items()) + list(imdb_tasks.items()))
    # NOT a 'with ThreadPoolExecutor(...) as pool:' block — same footgun
    # already fixed elsewhere this session (torrent_sources.search_all,
    # adult_streams.search_by_title, afdb_router._filter_films_with_sources,
    # sports_sources._dl_streams_by_title): ThreadPoolExecutor.__exit__
    # calls shutdown(wait=True), which blocks until EVERY submitted task
    # finishes even when as_completed's own timeout below has already given
    # up. Confirmed live as the real cause of a 409s adult-search run (well
    # past the 35s this function is supposed to cap at) — a single slow
    # title-scraper task (rarefilmm/lookmovie2/srstop) held the with-block
    # open for its own full multi-minute hang. shutdown(wait=False) lets
    # this function return promptly at the soft cutoff; any still-running
    # task's result is simply discarded since nothing reads `futures` after.
    pool = ThreadPoolExecutor(max_workers=len(all_tasks))
    try:
        futures = {pool.submit(fn): name for name, fn in all_tasks.items()}
        try:
            for future in as_completed(futures, timeout=35):
                name = futures[future]
                try:
                    result = future.result() or []
                    if name in imdb_tasks:
                        # IMDb scrapers return flat [{'label', 'url', 'source'}]
                        for s in result:
                            if s.get('url') and s['url'] not in seen_urls:
                                seen_urls.add(s['url'])
                                streams.append(s)
                    else:
                        # Title scrapers return film dicts with 'streams' lists.
                        # Skip the title-text re-check ONLY for Adult — those
                        # sites' own search endpoints are confirmed live to
                        # match on cast/performer name and genre tags, not
                        # just title text (same reasoning as
                        # adult_streams.py's own search_by_title() merge,
                        # fixed for the identical reason), so re-filtering by
                        # title text there discarded genuinely relevant hits
                        # whose title doesn't contain the query words. Movie/
                        # TV scrapers' own search endpoints are typically a
                        # plain title-only catalog lookup, not cast/genre-
                        # aware the same way, so keep the stricter check
                        # there to avoid noisier unrelated matches.
                        for film in result:
                            if not film:
                                continue
                            if media_type != 'adult' and not _title_matches(norm_query, film.get('title_norm', '')):
                                continue
                            film_title = film.get('title', '')
                            for s in film.get('streams', []):
                                if s.get('url') and s['url'] not in seen_urls:
                                    seen_urls.add(s['url'])
                                    host_label = '[%s] %s' % (name.upper(), s.get('label', 'Stream'))
                                    streams.append({
                                        'label':  '%s - %s' % (film_title, host_label) if film_title else host_label,
                                        'url':    s['url'],
                                        'source': name,
                                    })
                except Exception as e:
                    xbmc.log('[Starfleet/Scrapers] %s search error: %s' % (name, e), xbmc.LOGWARNING)
        except Exception as e:
            xbmc.log('[Starfleet/Scrapers] search_all_scrapers timeout: %s' % e, xbmc.LOGWARNING)
    finally:
        pool.shutdown(wait=False)

    xbmc.log(
        '[Starfleet/Scrapers] search_all_scrapers "%s" (%s) → %d streams'
        % (title, media_type, len(streams)),
        xbmc.LOGINFO
    )
    return streams
