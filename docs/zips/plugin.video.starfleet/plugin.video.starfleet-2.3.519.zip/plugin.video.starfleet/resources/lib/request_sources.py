# -*- coding: utf-8 -*-
"""
resources/lib/request_sources.py

"Requests" — manually curated movie/TV/adult stream links, produced by an
external orchestrator (run on a separate always-on PC, same setup as the
sports/channel scraper JSON already hosted this way) and published as JSON
to this repo's own data/ folder. Not a scraped source — real, hand-picked
links, matched precisely instead of by fuzzy title search:
  - Movies: matched by imdb_id (e.g. "tt20912374")
  - TV:     matched by show title (normalised) + season + episode
  - Adult:  matched by AdultDVDEmpire's own numeric film id (the same
            "ade_id"/"film_id" this addon's own ade.py already uses)

Every entry's own url(s) are handed to ResolveURL exactly like every other
embed source in this addon — streamtape.com/mixdrop.sx (every current
example) are standard ResolveURL-supported hosts, no custom per-host
logic needed here.

An entry can carry ONE source ("url": "...", a plain string) or SEVERAL
("urls": [...], a list) — never both keys on the same object, and never
two "url" keys on one object (that's invalid JSON — a JSON object can't
have a duplicate key at all; even a parser lenient enough to accept it
would just silently keep the LAST value and drop every earlier one, not
merge them). entry_urls() below is the one place that reads either shape,
so every caller gets a plain list regardless of which the orchestrator
used for that particular entry.

JSON shape (one array per file):
  requests_movies.json:
    [{"imdb_id": "tt20912374", "title": "Pins and Needles",
      "url": "https://streamtape.com/v/.../tt20912374_Pins_and_Needles.mp4"},
     {"imdb_id": "tt37287335", "title": "Obsession",
      "urls": ["https://streamtape.com/v/.../tt37287335_Obsession",
               "https://mxdrop.sx/f/r6wgdjv0cj1kzw"]}]
  requests_tv.json:
    [{"title": "Furious", "season": 1, "episode": 6,
      "url": "https://streamtape.com/v/.../furious.s01e06...mp4"}]
  requests_adult.json:
    [{"adc_id": "1896334", "title": "Cara & Lucy Escorts Deluxe",
      "url": "https://streamtape.com/v/.../1896334_Cara_%26_Lucy..."}]
"""
import re
import unicodedata
import xbmc
import xbmcaddon
import xbmcvfs
import requests

ADDON    = xbmcaddon.Addon('plugin.video.starfleet')
_PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))

from resources.lib import cache as _cache
_cache.init(_PROFILE + '/cache.db')

# raw.githubusercontent.com, not GitHub Pages — confirmed live this repo's
# Pages/Fastly deploy can get stuck serving a stale data/ file for 45+
# minutes (once observed over a day) after a real commit landed, while
# raw.githubusercontent.com served the correct fresh content the whole
# time (its own CDN cache is a much shorter, more reliable 5 minutes).
# Requests changes with every orchestrator run, so it's the one JSON
# source in this addon that actually needs to reflect a fresh commit
# promptly rather than tolerating an occasional day-long staleness spike.
_BASE = 'https://raw.githubusercontent.com/HazMat77/repository.starfleet/repository.starfleet/data'
_REQUESTS_MOVIES_URL = _BASE + '/requests_movies.json'
_REQUESTS_TV_URL     = _BASE + '/requests_tv.json'
_REQUESTS_ADULT_URL  = _BASE + '/requests_adult.json'

_HEADERS = {
    'User-Agent': ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
                    '(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'),
}

# Short TTL — this is meant to reflect "the orchestrator just ran" quickly,
# not a slow-changing scraper catalogue like everything else in json_data.py.
_TTL = 5 * 60


def _fetch_json(url, cache_key):
    cached = _cache.get(cache_key)
    if cached is not None:
        return cached
    try:
        r = requests.get(url, headers=_HEADERS, timeout=12)
        r.raise_for_status()
        data = r.json()
        if not isinstance(data, list):
            data = []
    except Exception as e:
        xbmc.log('[Starfleet/Requests] fetch error (%s): %s' % (url, e), xbmc.LOGWARNING)
        return []
    _cache.set(cache_key, data, _TTL if data else 60)
    return data


def _norm_title(t):
    t = (t or '').lower()
    t = ''.join(c for c in unicodedata.normalize('NFD', t) if unicodedata.category(c) != 'Mn')
    return re.sub(r'[^a-z0-9 ]', '', t).strip()


def get_requested_movies():
    return [e for e in _fetch_json(_REQUESTS_MOVIES_URL, 'requests_movies_v1') if _has_source(e)]


def get_requested_tv():
    return [e for e in _fetch_json(_REQUESTS_TV_URL, 'requests_tv_v1') if _has_source(e)]


def get_requested_adult():
    return [e for e in _fetch_json(_REQUESTS_ADULT_URL, 'requests_adult_v1') if _has_source(e)]


def _has_source(entry):
    """True once an entry carries at least one real url. The orchestrator's
    own files keep a batch of blank placeholder slots ready for future
    titles (e.g. {"adc_id": "", "title": "", "urls": []}) so new requests
    can just be filled in without hand-typing the JSON shape each time —
    every getter above filters those out here, before anything else in the
    addon (browsing, search, find_*_request matching) ever sees them, so a
    blank slot is never shown as an empty listing or treated as a match
    for anything. entry_urls() already normalises the "url"/"urls" shapes,
    so this is just "does that come back non-empty"."""
    return bool(entry_urls(entry))


def entry_urls(entry):
    """Every candidate url for one Requests entry, regardless of whether
    the orchestrator wrote a single "url" string or a "urls" list. Always
    returns a plain list (possibly empty) — every caller iterates this
    instead of ever reading entry['url'] directly."""
    if not entry:
        return []
    urls = entry.get('urls')
    if isinstance(urls, list):
        return [u for u in urls if u]
    single = entry.get('url')
    return [single] if single else []


def find_movie_request(imdb_id):
    if not imdb_id:
        return None
    for r in get_requested_movies():
        if r.get('imdb_id') == imdb_id:
            return r
    return None


def find_tv_request(title, season, episode):
    if not title or not season or not episode:
        return None
    norm_q = _norm_title(title)
    for r in get_requested_tv():
        if (_norm_title(r.get('title', '')) == norm_q
                and str(r.get('season', '')) == str(season)
                and str(r.get('episode', '')) == str(episode)):
            return r
    return None


def find_adult_request(ade_id):
    if not ade_id:
        return None
    ade_id = str(ade_id)
    for r in get_requested_adult():
        if str(r.get('adc_id', r.get('ade_id', ''))) == ade_id:
            return r
    return None


_ADE_META_TTL = 24 * 60 * 60


def enrich_adult_metadata(title, adc_id):
    """Full AdultDVDEmpire metadata (description/cast/studio/director/year/
    runtime) plus a trailer url, for one Requests adult entry.

    The JSON always carries the film's real adc_id, so the primary path is
    ade.get_film_detail_by_id(adc_id) — ADE's own site redirects a bare
    numeric id straight to that exact film's canonical detail page (no
    title matching involved at all, confirmed live), so it can never
    attach a different film's data. Falls back to a search-by-title +
    id-match-validate path only if ADE doesn't
    recognize the id outright (same "never trust an unvalidated slug"
    safety rule, kept as a backstop rather than the primary route now
    that the more reliable id-only lookup exists — confirmed live this
    matters: some real titles' search hits didn't validate even though
    the id-direct lookup found them fine). That fallback checks every
    exact-title search candidate, not just ADE's single top-ranked one —
    confirmed live that ADE catalogs a DVD edition ("-porn-movies.html")
    and an on-demand edition ("-porn-videos.html") of the same title under
    two DIFFERENT numeric ids, so a naive single-candidate check could
    miss a real match just because ADE's search happened to rank the
    other edition first.

    Returns a dict always containing at least 'trailer'; on success it
    also has 'description'/'cast'/'studio'/'director'/'year'/'runtime'/
    'thumb'/'fanart' (ade.py's own get_film_detail() shape).
    """
    if not adc_id:
        return {}
    adc_id = str(adc_id)
    cache_key = 'requests_adult_meta_%s' % adc_id
    cached = _cache.get(cache_key)
    if cached is not None:
        return cached

    from resources.lib import ade
    result = {'trailer': ade.trailer_url(adc_id)}
    try:
        detail = ade.get_film_detail_by_id(adc_id)
        if detail is not None:
            # Already fully validated by construction — get_film_detail_by_id
            # only returns non-None when ADE's own id-redirect landed on
            # this exact film's real page, so its thumb/fanart (og:image,
            # sometimes 404/415 from the plain CDN-formula guess — confirmed
            # live) is trustworthy even on a page with a thin description.
            result.update(detail)
        else:
            # ADE catalogs a DVD edition ("-porn-movies.html") and an
            # on-demand/streaming edition ("-porn-videos.html") of the same
            # title as two SEPARATE numeric ids (confirmed live) —
            # search_by_title() only returns ADE's own single best-ranked
            # candidate, which could be either edition's id, so relying on
            # just that one candidate can miss a match even when our own
            # adc_id is completely correct (it's just the OTHER edition's
            # id). search_films() returns every candidate; check every one
            # with an exact-normalised title match before giving up — still
            # only ever trusts a candidate whose own id equals our known
            # adc_id, same safety rule as before, just checked against more
            # of the right candidates first.
            norm_q = _norm_title(title or '')
            candidates = [f for f in ade.search_films(title or '', limit=30)
                          if _norm_title(f.get('title', '')) == norm_q]
            found = next((f for f in candidates if str(f.get('id', '')) == adc_id), None)
            if found:
                detail2 = ade.get_film_detail(found['id'], found['slug']) or {}
                if detail2.get('description') or detail2.get('cast'):
                    result.update(detail2)
    except Exception as e:
        xbmc.log('[Starfleet/Requests] enrich_adult_metadata error: %s' % e, xbmc.LOGWARNING)

    _cache.set(cache_key, result, _ADE_META_TTL)
    return result


def resolve_request_stream(url):
    """Hand a Request entry's own url to ResolveURL — every current entry
    is a streamtape.com link, a standard ResolveURL-supported host, same
    as every other embed source in this addon. Falls back to the raw url
    untouched if ResolveURL can't resolve it (or isn't installed), same
    fallback behaviour every other resolver call in this codebase uses."""
    if not url:
        return None
    try:
        import resolveurl
        hmf = resolveurl.HostedMediaFile(url)
        if hmf.valid_url():
            r = hmf.resolve()
            if r:
                return r
    except ImportError:
        pass
    except Exception as e:
        xbmc.log('[Starfleet/Requests] resolveurl error: %s' % e, xbmc.LOGWARNING)
    return url
