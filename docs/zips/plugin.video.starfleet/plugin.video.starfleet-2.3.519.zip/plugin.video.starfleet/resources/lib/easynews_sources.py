# -*- coding: utf-8 -*-
"""
resources/lib/easynews_sources.py — Easynews direct-play Usenet search.

Easynews is fundamentally different from every other Usenet source in this
addon (nzb_sources.py's Binsearch/NZBGeek/NZBPlanet): those return a raw
.nzb file that still has to be downloaded+unpacked by Premiumize/TorBox
before it's playable (see debrid_torrent.py's resolve_nzb()). Easynews
instead runs its own retention servers AND its own global search API — a
search against their catalog returns an already-assembled file with a
direct, streamable HTTPS URL, no NZB/unpack step and no debrid service
involved at all. Auth is plain HTTP Basic (the user's own Easynews member
login), same shape as this addon's MegaDebrid/SimplyDebrid personal-
account sources (personal_sources.py) — never a shared/bundled account,
each installer supplies their own via Settings.

Endpoint + auth mechanism confirmed live 2026-08-15: an unauthenticated
GET against the search endpoint returns a real HTTP 401 challenge (not a
404/DNS failure), confirming the URL and Basic-Auth requirement. The
authenticated JSON response's exact per-result field names could NOT be
confirmed live (no Easynews account available to test against) — built
against the field layout documented by several independent open-source
Easynews integrations (NZBHydra2, Sonarr/Radarr's Easynews indexer, the
Stremio Easynews addon), all of which agree on the same shape: a top-
level dlFarm/dlPort pair plus per-result id/sig/fn fields used to build
the final stream URL. _build_stream_url() is defensive about which exact
key names are present and logs the raw result keys on a shape mismatch,
so a real failure is fixable from one kodi.log capture rather than a
guess — same iterative approach already used this session for NZBGeek.
"""
import base64
import xbmc
import xbmcaddon

ADDON = xbmcaddon.Addon('plugin.video.starfleet')

_HEADERS = {
    'User-Agent': ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
                   '(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'),
}

SEARCH_URL = 'https://members.easynews.com/2.0/search/solr-search/'


def _creds():
    try:
        if ADDON.getSetting('easynews_enabled') != 'true':
            return '', ''
        user = ADDON.getSetting('easynews_username').strip()
        pw = ADDON.getSetting('easynews_password').strip()
        if not user or not pw:
            return '', ''
        return user, pw
    except Exception:
        return '', ''


def _basic_auth_b64(user, pw):
    return base64.b64encode(('%s:%s' % (user, pw)).encode('utf-8')).decode('ascii')


def _build_stream_url(item, dl_farm, dl_port):
    """Best-effort direct-play URL from one search result dict. Tries the
    field names known from public Easynews API integrations; returns None
    (caller skips that result) rather than a guessed, possibly-broken
    link if none match."""
    try:
        fname = item.get('fn') or item.get('filename') or item.get('10') or ''
        if not fname:
            return None
        raw_id = item.get('id') or item.get('0') or ''
        sig = item.get('sig') or item.get('hash') or item.get('passhash') or ''
        if not raw_id or not dl_farm or not dl_port:
            return None
        from urllib.parse import quote as _q
        path = ('%s%s' % (raw_id, sig)).strip('/')
        return 'https://%s.easynews.com:%s/dl/%s/%s' % (dl_farm, dl_port, path, _q(fname))
    except Exception:
        return None


def search_easynews(title, year=None, media_type='movie', limit=15):
    """Search Easynews's own catalog directly by title. Returns
    [{'label', 'url', 'size', 'source': 'Easynews'}] — url is ALREADY a
    direct, playable HTTPS stream (Basic Auth carried via this codebase's
    existing url|Header=... pipe convention), no further resolve step
    needed, unlike nzb_sources.py's results. No-op (returns []) unless
    the user has entered their own Easynews account in Settings."""
    user, pw = _creds()
    if not user or not pw:
        return []
    try:
        import requests
        from urllib.parse import quote as _q
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        url = ('%s?st=adv&sb=1&fty[]=VIDEO&spamf=1&u=1&pby=%d&gps=%s'
               % (SEARCH_URL, max(limit, 20), _q(query)))
        r = requests.get(url, headers=_HEADERS, auth=(user, pw), timeout=15)
        if r.status_code == 401:
            xbmc.log('[Starfleet/Easynews] auth rejected (401) — check username/password in Settings',
                      xbmc.LOGWARNING)
            return []
        if r.status_code != 200:
            xbmc.log('[Starfleet/Easynews] search HTTP %s' % r.status_code, xbmc.LOGWARNING)
            return []
        data = r.json()
        rows = data.get('data') or []
        if not rows:
            return []
        dl_farm = data.get('dlFarm', '')
        dl_port = data.get('dlPort', '80')

        auth_b64 = _basic_auth_b64(user, pw)
        results = []
        shape_logged = False
        for item in rows:
            if len(results) >= limit:
                break
            stream = _build_stream_url(item, dl_farm, dl_port)
            if not stream:
                if not shape_logged:
                    xbmc.log('[Starfleet/Easynews] could not build stream URL from result keys: %s'
                              % list(item.keys()), xbmc.LOGWARNING)
                    shape_logged = True
                continue
            play_url = '%s|Authorization=Basic %s' % (stream, auth_b64)
            fname = item.get('fn') or item.get('filename') or title
            size = item.get('rawSize') or item.get('1') or ''
            results.append({
                'label': str(fname),
                'url': play_url,
                'size': str(size),
                'source': 'Easynews',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Easynews] search error: %s' % e, xbmc.LOGWARNING)
        return []
