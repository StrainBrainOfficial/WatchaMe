# -*- coding: utf-8 -*-
"""
resources/lib/favorites.py

Favorites — save movies and TV shows for quick access.

Schema per entry:
  {
    "media_type": "movie" | "tv",
    "tmdb_id":    "12345",
    "imdb_id":    "tt1234567",
    "title":      "Breaking Bad",
    "year":       "2008",
    "thumb":      "https://...",
    "fanart":     "https://...",
    "ts":         1719600000       # unix timestamp added
  }

Key = "movie:tmdb_12345" or "tv:tmdb_67890"
"""

import json
import os
import time
import threading
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

_LOCK = threading.Lock()
_DB   = None


def _addon():
    """A fresh xbmcaddon.Addon() every call, NOT a cached module-level
    instance. Confirmed live as a real bug: this addon's Home screen runs
    as one long-lived Python process for the whole session (see
    watch_history.py's own _load() docstring for the established reason
    why) - a module-level `_ADDON = xbmcaddon.Addon(...)` constructed once
    when that process's imports first run keeps whatever settings snapshot
    existed at that moment. Pairing TMDB from Settings (a separate, freshly
    spawned process) writes the real new token to disk immediately, but
    the already-running Home process's cached Addon object never picks it
    up - confirmed via kodi.log timestamps showing settings.xml written 9
    real seconds before a same-session favorites_remove_action() call still
    read the old empty value. A fresh instance per call has no such
    snapshot to go stale."""
    return xbmcaddon.Addon('plugin.video.starfleet')

# ── Optional: sync Favorites from a public TMDB List instead of the local
# favorites.json below — see settings.xml's 'Favorites' category. Lets
# someone maintain one TMDB List (themoviedb.org/list/<id>, can freely mix
# movies and TV) and have every device's Favorites widgets read straight
# from it, instead of separately favoriting each title on each device.
_TMDB_LIST_CACHE_TTL = 1800  # 30 min


def _tmdb_list_id():
    v = _addon().getSetting('tmdb_favorites_list_id').strip()
    return v if v.isdigit() else ''


def _tmdb_v4_paired():
    """Returns (list_id, access_token) when a List ID is configured AND
    the account has completed TMDB v4 pairing (see tmdb_auth.py) — the
    only combination that can actually WRITE to the list. Returns None
    otherwise, so callers can tell "read-only mirror" apart from "fully
    wired up" without duplicating both checks everywhere."""
    list_id = _tmdb_list_id()
    if not list_id:
        return None
    access_token = _addon().getSetting('tmdb_v4_access_token').strip()
    if not access_token:
        return None
    return list_id, access_token


def _tmdb_list_items():
    """Return {'movie': [...], 'tv': [...]} from the configured TMDB List,
    normalized to the exact same per-item shape get_movies()/get_tv()'s
    local-favorites entries already use (so every existing caller — Home
    carousel, native Favorites menu, is_favorite() checks — works
    unchanged regardless of which source is active). Returns None when no
    list is configured, so callers can tell "no list — use local file"
    apart from "list configured but currently empty"."""
    list_id = _tmdb_list_id()
    if not list_id:
        return None
    from resources.lib import cache as _cache
    ck = 'tmdb_fav_list_%s' % list_id
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    from resources.lib import metadata as _meta
    movies, tv = [], []
    for it in _meta.get_tmdb_list(list_id):
        media_type = it.get('media_type', 'movie')
        title = it.get('title') or it.get('name', '')
        tmdb_id = str(it.get('id', ''))
        if not tmdb_id or not title:
            continue
        entry = {
            'media_type': media_type,
            'tmdb_id':    tmdb_id,
            'imdb_id':    '',
            'title':      title,
            'year':       (it.get('release_date') or it.get('first_air_date') or '')[:4],
            'thumb':      _meta.poster(it.get('poster_path', '')),
            'fanart':     _meta.fanart(it.get('backdrop_path', '')),
            'ts':         0,
        }
        (tv if media_type == 'tv' else movies).append(entry)
    result = {'movie': movies, 'tv': tv}
    _cache.set(ck, result, _TMDB_LIST_CACHE_TTL)
    return result


def _db_path():
    profile = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.starfleet/')
    if not xbmcvfs.exists(profile):
        xbmcvfs.mkdirs(profile)
    return os.path.join(profile, 'favorites.json')


def _load():
    global _DB
    if _DB is not None:
        return _DB
    try:
        p = _db_path()
        if xbmcvfs.exists(p):
            with open(p, 'r', encoding='utf-8') as f:
                _DB = json.load(f)
        else:
            _DB = {}
    except Exception as e:
        xbmc.log('[Starfleet/Favorites] load error: %s' % e, xbmc.LOGWARNING)
        _DB = {}
    return _DB


def _save():
    try:
        with open(_db_path(), 'w', encoding='utf-8') as f:
            json.dump(_DB, f, indent=2)
    except Exception as e:
        xbmc.log('[Starfleet/Favorites] save error: %s' % e, xbmc.LOGWARNING)


def _key(media_type, tmdb_id):
    return '%s:tmdb_%s' % (media_type, tmdb_id)


# ── Public API ────────────────────────────────────────────────────────────────

def add(media_type, tmdb_id, title, year='', imdb_id='', thumb='', fanart=''):
    if not tmdb_id:
        return
    k = _key(media_type, tmdb_id)
    with _LOCK:
        db = _load()
        db[k] = {
            'media_type': media_type,
            'tmdb_id':    str(tmdb_id),
            'imdb_id':    imdb_id or '',
            'title':      title or '',
            'year':       str(year or ''),
            'thumb':      thumb or '',
            'fanart':     fanart or '',
            'ts':         int(time.time()),
        }
        _save()
    xbmc.log('[Starfleet/Favorites] Added: %s (%s)' % (title, media_type), xbmc.LOGINFO)


def remove(media_type, tmdb_id):
    k = _key(media_type, tmdb_id)
    with _LOCK:
        db = _load()
        if k in db:
            title = db[k].get('title', '')
            del db[k]
            _save()
            xbmc.log('[Starfleet/Favorites] Removed: %s' % title, xbmc.LOGINFO)


def is_favorite(media_type, tmdb_id):
    listed = _tmdb_list_items()
    if listed is not None:
        return any(str(i['tmdb_id']) == str(tmdb_id) for i in listed.get(media_type, []))
    k = _key(media_type, tmdb_id)
    return k in _load()


def get_all():
    listed = _tmdb_list_items()
    if listed is not None:
        # Already in the order the user arranged on themoviedb.org —
        # no ts-based re-sort to second-guess that.
        return listed['movie'] + listed['tv']
    db = _load()
    items = list(db.values())
    items.sort(key=lambda x: x.get('ts', 0), reverse=True)
    return items


def get_movies():
    listed = _tmdb_list_items()
    if listed is not None:
        return listed['movie']
    return [i for i in get_all() if i.get('media_type') == 'movie']


def get_tv():
    listed = _tmdb_list_items()
    if listed is not None:
        return listed['tv']
    return [i for i in get_all() if i.get('media_type') == 'tv']


# ── Kodi UI ───────────────────────────────────────────────────────────────────

def favorites_menu(handle, build_url):
    xbmcplugin.setPluginCategory(handle, '⭐ Favorites')
    xbmcplugin.setContent(handle, 'files')

    movies = get_movies()
    tv     = get_tv()

    xbmcgui.ListItem  # just import check
    from xbmcgui import ListItem as _LI

    def _add_dir(label, params, plot=''):
        li = _LI(label=label)
        li.setInfo('video', {'title': label, 'plot': plot})
        xbmcplugin.addDirectoryItem(handle, build_url(params), li, True)

    _add_dir('🎬  Favourite Movies  (%d)' % len(movies),
             {'action': 'favorites_movies'},
             plot='Your saved movies')
    _add_dir('📺  Favourite TV Shows  (%d)' % len(tv),
             {'action': 'favorites_tv'},
             plot='Your saved TV shows')
    _add_dir('🗑️  Clear All Favorites',
             {'action': 'favorites_clear_confirm'},
             plot='Remove everything from your favorites list')

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def favorites_movies(handle, build_url):
    xbmcplugin.setPluginCategory(handle, '🎬 Favourite Movies')
    xbmcplugin.setContent(handle, 'movies')

    movies = get_movies()
    if not movies:
        xbmcgui.Dialog().notification('Favorites', 'No favourite movies yet',
                                       xbmcgui.NOTIFICATION_INFO, 3000)
        return

    for m in movies:
        label = m['title']
        if m.get('year'):
            label += '  (%s)' % m['year']
        li = xbmcgui.ListItem(label=label)
        li.setInfo('video', {
            'title':     m['title'],
            'year':      int(m['year']) if str(m.get('year', '')).isdigit() else 0,
            'mediatype': 'movie',
        })
        li.setArt({
            'thumb':  m.get('thumb', ''),
            'poster': m.get('thumb', ''),
            'fanart': m.get('fanart', ''),
        })
        li.setProperty('IsPlayable', 'true')
        li.addContextMenuItems([
            ('Remove from Favorites',
             'RunPlugin(%s)' % build_url({'action': 'favorites_remove',
                                          'media_type': 'movie',
                                          'tmdb_id': m['tmdb_id'],
                                          'refresh': '1'}))
        ])
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action':  'meta_movie_play',
                       'tmdb_id': m['tmdb_id'],
                       'title':   m['title'],
                       'imdb_id': m.get('imdb_id', ''),
                       'year':    m.get('year', '')}),
            li, False
        )

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)


def favorites_tv(handle, build_url):
    xbmcplugin.setPluginCategory(handle, '📺 Favourite TV Shows')
    xbmcplugin.setContent(handle, 'tvshows')

    shows = get_tv()
    if not shows:
        xbmcgui.Dialog().notification('Favorites', 'No favourite TV shows yet',
                                       xbmcgui.NOTIFICATION_INFO, 3000)
        return

    for s in shows:
        label = s['title']
        if s.get('year'):
            label += '  (%s)' % s['year']
        li = xbmcgui.ListItem(label=label)
        li.setInfo('video', {
            'title':     s['title'],
            'year':      int(s['year']) if str(s.get('year', '')).isdigit() else 0,
            'mediatype': 'tvshow',
        })
        li.setArt({
            'thumb':  s.get('thumb', ''),
            'poster': s.get('thumb', ''),
            'fanart': s.get('fanart', ''),
        })
        li.addContextMenuItems([
            ('Remove from Favorites',
             'RunPlugin(%s)' % build_url({'action': 'favorites_remove',
                                          'media_type': 'tv',
                                          'tmdb_id': s['tmdb_id'],
                                          'refresh': '1'}))
        ])
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action':  'meta_tv_show',
                       'tmdb_id': s['tmdb_id']}),
            li, True
        )

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)


def favorites_add_action(media_type, tmdb_id, title, year='', imdb_id='',
                          thumb='', fanart=''):
    """Called via RunPlugin context menu — adds item and shows toast.
    When a TMDB List ID is configured AND the account is paired (see
    tmdb_auth.py), pushes the add straight to that TMDB List via the v4
    API instead of the local file, and clears this device's own 30-min
    list cache so the change shows up immediately rather than after a
    stale-cache wait. A List ID with no pairing yet still just no-ops
    with the old "edit it on themoviedb.org" toast, unchanged."""
    paired = _tmdb_v4_paired()
    xbmc.log('[Starfleet/Favorites] favorites_add_action: media_type=%r tmdb_id=%r '
             'list_id_set=%r paired=%r' % (media_type, tmdb_id, bool(_tmdb_list_id()),
                                           bool(paired)), xbmc.LOGINFO)
    if paired:
        list_id, access_token = paired
        from resources.lib import metadata as _meta
        if _meta.tmdb_v4_list_add_item(list_id, access_token, media_type, tmdb_id):
            from resources.lib import cache as _cache
            _cache.delete('tmdb_fav_list_%s' % list_id)
            xbmcgui.Dialog().notification(
                'Starfleet', 'Added to TMDB List: %s' % title,
                xbmcgui.NOTIFICATION_INFO, 3000)
        else:
            xbmcgui.Dialog().notification(
                'Starfleet', 'Could not add to TMDB List (see kodi.log)',
                xbmcgui.NOTIFICATION_ERROR, 4000)
        return
    if _tmdb_list_id():
        xbmcgui.Dialog().notification(
            'Starfleet', 'Favorites are synced from your TMDB List — edit it on themoviedb.org',
            xbmcgui.NOTIFICATION_INFO, 4000)
        return
    add(media_type, tmdb_id, title, year=year, imdb_id=imdb_id,
        thumb=thumb, fanart=fanart)
    xbmcgui.Dialog().notification(
        'Starfleet',
        'Added to Favorites: %s' % title,
        xbmcgui.NOTIFICATION_INFO, 3000
    )


def favorites_remove_action(media_type, tmdb_id, refresh=False):
    """Called via RunPlugin context menu — removes item and optionally
    refreshes. Same TMDB-List write-vs-no-op split as favorites_add_action()
    above."""
    paired = _tmdb_v4_paired()
    xbmc.log('[Starfleet/Favorites] favorites_remove_action: media_type=%r tmdb_id=%r '
             'list_id_set=%r paired=%r' % (media_type, tmdb_id, bool(_tmdb_list_id()),
                                           bool(paired)), xbmc.LOGINFO)
    if paired:
        list_id, access_token = paired
        from resources.lib import metadata as _meta
        if _meta.tmdb_v4_list_remove_item(list_id, access_token, media_type, tmdb_id):
            from resources.lib import cache as _cache
            _cache.delete('tmdb_fav_list_%s' % list_id)
            xbmcgui.Dialog().notification(
                'Starfleet', 'Removed from TMDB List',
                xbmcgui.NOTIFICATION_INFO, 3000)
        else:
            xbmcgui.Dialog().notification(
                'Starfleet', 'Could not remove from TMDB List (see kodi.log)',
                xbmcgui.NOTIFICATION_ERROR, 4000)
        if refresh:
            xbmc.executebuiltin('Container.Refresh')
        return
    if _tmdb_list_id():
        xbmcgui.Dialog().notification(
            'Starfleet', 'Favorites are synced from your TMDB List — edit it on themoviedb.org',
            xbmcgui.NOTIFICATION_INFO, 4000)
        return
    with _LOCK:
        db = _load()
        k  = _key(media_type, tmdb_id)
        title = db.get(k, {}).get('title', '')
        if k in db:
            del db[k]
            _save()
    xbmcgui.Dialog().notification(
        'Starfleet',
        'Removed from Favorites: %s' % title,
        xbmcgui.NOTIFICATION_INFO, 3000
    )
    if refresh:
        xbmc.executebuiltin('Container.Refresh')


def favorites_clear_confirm():
    """Ask for confirmation then wipe everything. Same TMDB-List no-op as
    favorites_add_action() above — nothing local to clear that's actually
    in effect while a list is configured."""
    if _tmdb_list_id():
        xbmcgui.Dialog().notification(
            'Starfleet', 'Favorites are synced from your TMDB List — edit it on themoviedb.org',
            xbmcgui.NOTIFICATION_INFO, 4000)
        return
    if xbmcgui.Dialog().yesno('Clear Favorites',
                               'Remove ALL favorites? This cannot be undone.'):
        global _DB
        with _LOCK:
            _DB = {}
            _save()
        xbmcgui.Dialog().notification('Starfleet', 'Favorites cleared',
                                       xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin('Container.Refresh')
