"""Minimal pure-Python AES-128-CBC decryption (no external dependencies).

Kodi's bundled Python has no pycryptodome/cryptography, so this hand-rolled
implementation exists purely to decrypt hoofoot.ru's API payloads (static
AES-128-CBC key, PKCS7 padding) without adding a binary dependency. Not
optimized, not general-purpose — decrypt-only, CBC-only.
"""

_SBOX = [
    0x63,0x7c,0x77,0x7b,0xf2,0x6b,0x6f,0xc5,0x30,0x01,0x67,0x2b,0xfe,0xd7,0xab,0x76,
    0xca,0x82,0xc9,0x7d,0xfa,0x59,0x47,0xf0,0xad,0xd4,0xa2,0xaf,0x9c,0xa4,0x72,0xc0,
    0xb7,0xfd,0x93,0x26,0x36,0x3f,0xf7,0xcc,0x34,0xa5,0xe5,0xf1,0x71,0xd8,0x31,0x15,
    0x04,0xc7,0x23,0xc3,0x18,0x96,0x05,0x9a,0x07,0x12,0x80,0xe2,0xeb,0x27,0xb2,0x75,
    0x09,0x83,0x2c,0x1a,0x1b,0x6e,0x5a,0xa0,0x52,0x3b,0xd6,0xb3,0x29,0xe3,0x2f,0x84,
    0x53,0xd1,0x00,0xed,0x20,0xfc,0xb1,0x5b,0x6a,0xcb,0xbe,0x39,0x4a,0x4c,0x58,0xcf,
    0xd0,0xef,0xaa,0xfb,0x43,0x4d,0x33,0x85,0x45,0xf9,0x02,0x7f,0x50,0x3c,0x9f,0xa8,
    0x51,0xa3,0x40,0x8f,0x92,0x9d,0x38,0xf5,0xbc,0xb6,0xda,0x21,0x10,0xff,0xf3,0xd2,
    0xcd,0x0c,0x13,0xec,0x5f,0x97,0x44,0x17,0xc4,0xa7,0x7e,0x3d,0x64,0x5d,0x19,0x73,
    0x60,0x81,0x4f,0xdc,0x22,0x2a,0x90,0x88,0x46,0xee,0xb8,0x14,0xde,0x5e,0x0b,0xdb,
    0xe0,0x32,0x3a,0x0a,0x49,0x06,0x24,0x5c,0xc2,0xd3,0xac,0x62,0x91,0x95,0xe4,0x79,
    0xe7,0xc8,0x37,0x6d,0x8d,0xd5,0x4e,0xa9,0x6c,0x56,0xf4,0xea,0x65,0x7a,0xae,0x08,
    0xba,0x78,0x25,0x2e,0x1c,0xa6,0xb4,0xc6,0xe8,0xdd,0x74,0x1f,0x4b,0xbd,0x8b,0x8a,
    0x70,0x3e,0xb5,0x66,0x48,0x03,0xf6,0x0e,0x61,0x35,0x57,0xb9,0x86,0xc1,0x1d,0x9e,
    0xe1,0xf8,0x98,0x11,0x69,0xd9,0x8e,0x94,0x9b,0x1e,0x87,0xe9,0xce,0x55,0x28,0xdf,
    0x8c,0xa1,0x89,0x0d,0xbf,0xe6,0x42,0x68,0x41,0x99,0x2d,0x0f,0xb0,0x54,0xbb,0x16,
]
_INV_SBOX = [0] * 256
for _i, _v in enumerate(_SBOX):
    _INV_SBOX[_v] = _i

_RCON = [0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80,0x1b,0x36]


def _xtime(a):
    a <<= 1
    if a & 0x100:
        a ^= 0x11b
    return a & 0xff


def _mul(a, b):
    result = 0
    for _ in range(8):
        if b & 1:
            result ^= a
        a = _xtime(a)
        b >>= 1
    return result & 0xff


# InvMixColumns' 4 GF(256) multipliers (9, 11, 13, 14), precomputed as flat
# 256-entry tables. Confirmed live this is the dominant cost of the whole
# decrypt (144 _mul() calls per 16-byte block, each an 8-iteration bit loop)
# — a real /api/events payload (~123KB, ~7700 blocks) took 8+ seconds with
# the naive per-call _mul(), which on a Firestick's much weaker CPU was
# slow enough to visibly degrade the whole addon (the decrypt runs as a
# background thread that isn't cancelled when its 5s timeout is hit, so it
# kept burning a CPU core for the real duration regardless). Table lookups
# instead of an 8-iteration loop per multiply cuts this dramatically.
MUL9  = [_mul(x, 9)  for x in range(256)]
MUL11 = [_mul(x, 11) for x in range(256)]
MUL13 = [_mul(x, 13) for x in range(256)]
MUL14 = [_mul(x, 14) for x in range(256)]


def _key_expansion(key):
    nk = 4
    nr = 10
    w = [list(key[4 * i:4 * i + 4]) for i in range(nk)]
    for i in range(nk, 4 * (nr + 1)):
        temp = list(w[i - 1])
        if i % nk == 0:
            temp = temp[1:] + temp[:1]
            temp = [_SBOX[b] for b in temp]
            temp[0] ^= _RCON[i // nk - 1]
        w.append([w[i - nk][j] ^ temp[j] for j in range(4)])
    return w


# Flat 16-element state, indexed state[r + 4*c] (column-major, matching the
# AES spec) — avoids the overhead of a list-of-lists for every access.

def _add_round_key(state, w, round_):
    wr = w[round_ * 4:round_ * 4 + 4]
    for c in range(4):
        col = wr[c]
        base = 4 * c
        state[base]     ^= col[0]
        state[base + 1] ^= col[1]
        state[base + 2] ^= col[2]
        state[base + 3] ^= col[3]


def _inv_sub_bytes(state):
    inv = _INV_SBOX
    for i in range(16):
        state[i] = inv[state[i]]


def _inv_shift_rows(state):
    # row r gets rotated right by r; state is column-major (state[r+4*c])
    s = state
    s[1], s[5], s[9], s[13] = s[13], s[1], s[5], s[9]
    s[2], s[6], s[10], s[14] = s[10], s[14], s[2], s[6]
    s[3], s[7], s[11], s[15] = s[7], s[11], s[15], s[3]


def _inv_mix_columns(state):
    m9, m11, m13, m14 = MUL9, MUL11, MUL13, MUL14
    for c in range(4):
        base = 4 * c
        a0, a1, a2, a3 = state[base], state[base + 1], state[base + 2], state[base + 3]
        state[base]     = m14[a0] ^ m11[a1] ^ m13[a2] ^ m9[a3]
        state[base + 1] = m9[a0]  ^ m14[a1] ^ m11[a2] ^ m13[a3]
        state[base + 2] = m13[a0] ^ m9[a1]  ^ m14[a2] ^ m11[a3]
        state[base + 3] = m11[a0] ^ m13[a1] ^ m9[a2]  ^ m14[a3]


def _decrypt_block(block, w):
    state = list(block)
    _add_round_key(state, w, 10)
    for round_ in range(9, 0, -1):
        _inv_shift_rows(state)
        _inv_sub_bytes(state)
        _add_round_key(state, w, round_)
        _inv_mix_columns(state)
    _inv_shift_rows(state)
    _inv_sub_bytes(state)
    _add_round_key(state, w, 0)
    return bytes(state)


def decrypt_cbc(key, iv, ciphertext):
    """AES-128-CBC decrypt with PKCS7 unpadding. key/iv/ciphertext are bytes."""
    if len(key) != 16:
        raise ValueError('key must be 16 bytes (AES-128)')
    if len(ciphertext) % 16 != 0:
        raise ValueError('ciphertext length must be a multiple of 16')
    w = _key_expansion(key)
    out = bytearray()
    prev = iv
    for i in range(0, len(ciphertext), 16):
        block = ciphertext[i:i + 16]
        decrypted = _decrypt_block(block, w)
        out.extend(bytes(a ^ b for a, b in zip(decrypted, prev)))
        prev = block
    pad_len = out[-1]
    if pad_len < 1 or pad_len > 16:
        raise ValueError('invalid PKCS7 padding')
    return bytes(out[:-pad_len])
