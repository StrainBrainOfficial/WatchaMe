"""
Starfleet Browse GUI launcher.
Reads pre-fetched browse data from browse_data.json, then opens BrowseWindow.
"""
import sys
import os
import json
import xbmc
import xbmcvfs
import xbmcaddon


def main():
    addon      = xbmcaddon.Addon('plugin.video.starfleet')
    addon_path = addon.getAddonInfo('path')
    if addon_path not in sys.path:
        sys.path.insert(0, addon_path)

    items = []
    title = ''
    try:
        data_dir  = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.starfleet/')
        data_file = os.path.join(data_dir, 'browse_data.json')
        with open(data_file, 'r', encoding='utf-8') as f:
            data  = json.load(f)
        items = data.get('items', [])
        title = data.get('title', '')
        xbmc.log('[Starfleet/Browse] loaded %d items for "%s"' % (len(items), title), xbmc.LOGINFO)
    except Exception as e:
        xbmc.log('[Starfleet/Browse] could not read browse_data.json: %s' % e, xbmc.LOGWARNING)

    try:
        from resources.lib.gui.browse import BrowseWindow
        win = BrowseWindow('Starfleet-Browse.xml', addon_path, 'Default', '1080i',
                           items=items, title=title)
        win.doModal()
        del win
    except Exception as e:
        xbmc.log('[Starfleet/Browse] window error: %s' % e, xbmc.LOGERROR)
        import traceback
        xbmc.log(traceback.format_exc(), xbmc.LOGERROR)


if __name__ == '__main__':
    main()
