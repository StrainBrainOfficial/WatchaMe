# -*- coding: utf-8 -*-
"""
resources/lib/gui/donate_dialog.py

Display-only dialog for Settings > Buy Me a Coffee — shows a QR code for
one of the addon author's own crypto deposit addresses, plus the address
itself as plain readable text (long addresses wrapped to a few lines,
same 1280x720 fixed virtual coordinate space as qr_dialog.py — see that
module's docstring for why). Unlike qr_dialog.QRDialog this isn't a
polling pairing flow: it just sits there until the donor presses Back/OK,
so it has no update()/iscanceled() loop.
"""
import textwrap

import xbmcgui
import xbmcvfs

_WHITE_TEXTURE = 'special://home/addons/plugin.video.starfleet/resources/skins/Default/media/white.png'


class DonateDialog(xbmcgui.WindowDialog):
    """address: wrapped across a few lines since these run 25-42 chars.
    note: an extra always-shown line (e.g. XRP's required destination
    tag) — pass '' when the coin has nothing extra to flag."""

    def __init__(self, qr_path, coin_label, address, note=''):
        super(DonateDialog, self).__init__()
        self._done = False

        panel_x, panel_y, panel_w, panel_h = 390, 40, 500, 640

        bg_path = xbmcvfs.translatePath(_WHITE_TEXTURE)
        bg = xbmcgui.ControlImage(panel_x, panel_y, panel_w, panel_h, bg_path)
        self.addControl(bg)
        try:
            bg.setColorDiffuse('FF0F171E')
        except Exception:
            pass

        heading = xbmcgui.ControlLabel(panel_x, panel_y + 15, panel_w, 40,
                                        'Thank You! [COLOR FFFF3B30]♥[/COLOR]',
                                        alignment=2, font='font30', textColor='FFFFFFFF')
        self.addControl(heading)

        sub = xbmcgui.ControlLabel(panel_x, panel_y + 55, panel_w, 30, coin_label,
                                    alignment=2, textColor='FFB0BEC8')
        self.addControl(sub)

        qr_size = 260
        qr_x = panel_x + (panel_w - qr_size) // 2
        qr_y = panel_y + 90
        self.addControl(xbmcgui.ControlImage(qr_x, qr_y, qr_size, qr_size, qr_path))

        content_x, content_w = panel_x + 20, panel_w - 40
        y = qr_y + qr_size + 20

        addr_lines = textwrap.wrap(address, width=26) or [address]
        for line in addr_lines:
            lbl = xbmcgui.ControlLabel(content_x, y, content_w, 28, line,
                                        alignment=2, textColor='FFFFFFFF')
            self.addControl(lbl)
            y += 28
        y += 10

        if note:
            note_lbl = xbmcgui.ControlLabel(content_x, y, content_w, 50,
                                            '[COLOR FFFF8C00]%s[/COLOR]' % note,
                                            alignment=2)
            self.addControl(note_lbl)
            y += 55

        hint = xbmcgui.ControlLabel(content_x, y, content_w, 60,
                                    'No obligation — just a thank you.\nPress Back to close.',
                                    alignment=2, textColor='FFB0BEC8')
        self.addControl(hint)

    def onAction(self, action):
        if action.getId() in (10, 92, 7):  # PREVIOUS_MENU, NAV_BACK, ACTION_SELECT_ITEM
            self._done = True
            self.close()
