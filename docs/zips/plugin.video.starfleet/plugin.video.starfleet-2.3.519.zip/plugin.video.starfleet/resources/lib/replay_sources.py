# -*- coding: utf-8 -*-
"""
resources/lib/replay_sources.py

Replay scraper — PAST events (full fight/game replays with real dates),
architecturally separate from sports_sources.py's LIVE-sports scraping.
Investigated live 2026-08-16 against 4 candidate sites; all 4 turned out to
be real/scrapable (no CF/JS-challenge dead ends this time), but they split
cleanly across the 3 target categories rather than each covering all 3:

  UFC     — watchmmafull.com  (per-INDIVIDUAL-FIGHT pages, one URL per
             matchup) + fullfightreplays.com (per-CARD-SECTION links —
             Main Card/Prelims/Early Prelims, each with 2-3 alternate
             hosts). Both merged per numbered PPV event (e.g. "UFC 330")
             so a single event offers fight-by-fight AND full-card options
             side by side, per the picker design this module is built for.
  Boxing  — fullfightreplays.com (per-fight, multiple host "servers") +
             box.live/full-fight-replays (per-fight, single official
             broadcaster YouTube embed — confirmed live via PBC's own
             channel — but only once uploaded; many recent fights show the
             site's own honest "no replay yet" state, handled as empty).
  MLB     — mlblive.net only (per-GAME, single embed host). Deep real
             archive confirmed live back through the 2025 World Series
             (Dodgers vs Blue Jays, Games 1-7) via its year-indexed pages,
             though the live listing pages themselves are NOT paginated
             (confirmed live: /page/2 on every listing 404s) so only the
             ~10-16 most recent items per page are visible at once.

Confirmed dead ends: none of the 4 — see box.live's sister-site note below
for the one thing that ISN'T covered (MMA/UFC on box.live itself).

── Site-by-site findings (all confirmed live 2026-08-16) ──────────────────

watchmmafull.com (UFC/MMA):
  - Despite "UFC MMA BOXING KICKBOXING" in its own <title> tag, /tag/boxing
    returns zero results live — this site is UFC/MMA-only in practice.
  - Only browsable catalog is the homepage's "New Video" list — /events,
    /search and /page/2 all dead-end to a generic 404 template (confirmed
    live), so this source only ever surfaces whichever ~2 most-recent
    events happen to be on the homepage at fetch time (was UFC 330 +
    UFC Vegas 120, 12 individual fight pages each, when checked).
  - Real per-fight granularity: each matchup (e.g. "Islam Makhachev vs
    Ian Machado Garry") is its own page/URL — confirmed 24 distinct fight
    pages across 2 real events on 2 real different dates. No full-card
    bundle page exists (ufc-330-full-card.html style URLs all 404).
  - Stream mechanism varies PER EVENT (not per fight): UFC 330's fights
    all embed via playmate.to, which is cleanly resolvable with plain
    requests (see _wmf_resolve_fight docstring) to a real, playable ~48-
    minute HLS stream. UFC Vegas 120's fights all embedded via
    suisports.upns.xyz instead — a bare JS-SPA shell (empty <body>,
    everything bootstrapped client-side, fight id only in a URL #hash)
    with nothing server-rendered to scrape, the same dead-end class as
    this addon's other confirmed JS-SPA embeds. Handled by resolving
    playmate.to embeds and skipping (not returning a dead link for)
    anything else, logged at LOGINFO so it's visible without being noisy.
  - No per-event thumbnail anywhere (listing <img src=""> is a lazy-load
    placeholder with no data-src fallback; individual fight pages'
    og:image is also empty) — confirmed live. TMDB is this category's
    only real art source for events from this site specifically.

fullfightreplays.com (UFC AND Boxing):
  - Real multi-org combat-sports catalog: UFC, Boxing, Bellator, ONE
    Championship, Cage Warriors, BKFC, Invicta FC, KSW, K-1. Only UFC and
    Boxing are built out below since those are the 2 of 3 target
    categories it actually covers.
  - Single-page listings per category (/ufc, /boxing) with no working
    pagination (/ufc/page/2 and /boxing/page/2 both 404, confirmed live)
    — ~10 real events per category at check time, spanning roughly one to
    two months back (e.g. boxing: Errol Spence Jr. vs. Tim Tszyu, Jul 26
    2026, through Claressa Shields vs. Kaye Scott, Aug 15 2026).
  - UFC granularity is per-CARD-SECTION, not per-fight: "Main Card" (in
    2 quality tiers x up to 3 parts via Dailymotion, plus OK.ru and
    Filemoon-mirror alternates), "Prelims", "Early Prelims" — each
    section/host pairing is its own selectable link. This is the "full
    card" counterpart to watchmmafull.com's per-fight breakdown.
  - Boxing granularity is per-fight (as expected, one bout per card),
    multiple alternate-host "servers" (OK.ru + Filemoon-mirror, confirmed
    live) per fight.
  - Real per-event thumbnail confirmed live for every listing entry
    (/_pu/<n>/<id>.png|jpg — distinct, working image per event).
  - No CAPTCHA/CF/JS wall on any page hit (listing, event, or embed pages).

box.live/full-fight-replays (Boxing ONLY):
  - Confirmed live: this is boxing-only. The fight-detail page template
    itself says "Love MMA & UFC too? Try our sister site, Cage Walks" —
    an explicit, direct confirmation it does NOT cover UFC/MMA despite
    "full fight replays" reading generically. Not used for the UFC
    category at all as a result.
  - Deep, well-organized real catalog (/fight-results/ listed 38 distinct
    real recent bouts when checked, e.g. Spence vs Tszyu Jul 26 2026,
    Fundora vs Thurman Mar 28 2026) with a real per-fight detail page for
    each (/fights/<slug>/), each carrying a real date and 2 real fighter
    photos in its hero section.
  - Replay video, when present, is a single OFFICIAL broadcaster YouTube
    embed — confirmed live: Fundora vs Thurman's embed resolves via
    YouTube's own oEmbed to "PBC FULL FIGHT: Fundora vs Thurman | March
    28, 2026" on the real Premier Boxing Champions channel. Highest-
    legitimacy source of the 4, but NOT every fight has one yet — spot-
    checking 12 real fights live found only 2 with a replay uploaded so
    far; the rest show the site's own honest "Sorry, we couldn't find any
    replay videos... yet" message (handled as an empty result here, never
    a broken/fake link).

mlblive.net (MLB ONLY):
  - NFL/NBA nav links point off-site to sister domains (nfl-video.com,
    basketball-video.com) — confirmed this specific site is MLB-only.
  - Same site engine/template as fullfightreplays.com (same "/_pu/<n>/
    <id>" thumbnail path scheme, same "Server #N" + embed-host markup) —
    _ffr_parse_sources() below is reused as-is for MLB event pages.
  - Real, deep catalog: homepage + year-indexed listing pages go back to
    2021 including the complete real 2025 World Series game-by-game
    (Los Angeles Dodgers vs Toronto Blue Jays, Games 1 through 7, real
    dates Oct 24 - Nov 1 2025) confirmed live, plus the current 2026
    regular season (multiple real games checked for Aug 15 2026: Rangers
    @ Athletics, Royals @ Angels, Brewers @ Dodgers, etc). No listing page
    is paginated though (confirmed live 404 on /page/2 for every listing
    tried) — only the most-recent ~12-16 games per page/day are visible;
    older days are reachable only via the year-index pages, which
    themselves only surface a curated/recent slice, not exhaustive daily
    coverage. One game per event (no innings-level breakdown attempted —
    not offered by the site and not asked for).
  - Real per-event thumbnail confirmed live, same /_pu/ scheme as above.

sport-video.org.ua (UFC + Boxing + MLB, TORRENT-based — added 2026-08-16):
  - Multi-sport torrent index, real and live, no CF/JS wall anywhere in the
    chain (listing pages, detail pages, or the .torrent downloads
    themselves) — confirmed live end-to-end.
  - /baseball.html (+ numbered /baseball1.html..baseball6.html) is MLB —
    real per-game detail pages (e.g. /BRSPP150826.html = "Boston Red Sox at
    Pittsburgh Pirates 15.08.2026"). Real pagination confirmed live to run
    ONE page deeper than that: /baseball7.html and /baseball8.html are both
    real 200s with real distinct older games (back to 12.06.2024 on
    baseball8.html); /baseball9.html 404s, confirmed the true end.
  - /other.html (+ /other1.html..other25.html, confirmed live 200 through
    other25.html, other26.html 404s — a real 26-page-deep archive going
    back to April/May 2024) is a mixed bag: Formula 1, NASCAR, IndyCar,
    MotoGP, WRC, tennis, golf, cricket, athletics — AND, confirmed live,
    real UFC (title always starts "UFC ...", e.g. "UFC Fight Night Gamrot
    vs Salkilld", "UFC 329 McGregor vs Holloway 2") and Boxing (title
    starts "Boxing ..." for standalone cards, e.g. "Boxing Anthony Joshua
    vs Kristian Prenga", or "Zuffa Boxing N ..." for Dana White's Zuffa
    Boxing series) entries mixed in among the rest — roughly 3-5 real
    UFC/Boxing events per page. No separate combat-sports category page
    exists on this site; /other.html is genuinely where they live.
  - Each detail page has a real `<a href="./<Title> <DD.MM.YYYY>.mkv.torrent">`
    download link — never a magnet: URI directly. Two HTML template
    generations coexist across the archive (newer: onclick=window.open(...)
    thumbnails; older, pre-~mid-2026: plain rel="prettyPhoto" thumbnail
    links) — the listing parser below anchors only on the <strong>TITLE
    DATE</strong> heading and the following ./<slug>.html detail link, so
    it parses both generations the same way without caring which one a
    given page uses.
  - Downloading that .torrent file and deriving its info_hash from the raw
    bencoded 'info' dict (same technique torrent_sources.py's own
    _torrent_info_hash/_make_magnet already use for FreeJAVTorrent's
    identically torrent-file-only detail pages — reused here rather than a
    second bencode parser) produces a real, valid magnet: URI — confirmed
    live against 3 real detail pages spanning both template generations:
      "Boston Red Sox at Pittsburgh Pirates 15.08.2026" (MLB, new template)
        -> info_hash 6de0636d09f82b1991185997cf63d5934c760e99
      "UFC Fight Night Song vs Figueiredo 30.05.2026" (UFC, OLD template)
        -> info_hash a33ad29bdbc10880c79c67eb7a427e483190566a
      "UFC Fight Night Medic vs Rodriguez 01.08.2026" (UFC, new template)
        -> info_hash 684619ef06c9a2bd663579b2e6cbfcaac52b5764
  - Kept as its own separate 'sportvideo' source entry per event (not
    merged into the wmf/ffr/mlblive catalogs) — this site's own titles
    ("UFC Fight Night Song vs Figueiredo") don't reliably line up with the
    other sites' naming (fullfightreplays.com's "UFC Fight Night 284:
    Gamrot vs. Salkilld"), same "list separately rather than risk a wrong
    merge" call already made for Boxing's ffr-vs-box.live split above.
    get_replay_sources() resolves the magnet lazily (network + bencode
    parse only happen when a user actually opens the source picker for
    that event), cached 15 min same as every other per-event resolution
    in this module.

Generic multi-site torrent search (torrent_sources.search_all — the same
44-source engine Movies/TV/Adult already use, wired in for every Replay
event across all 3 sports, added 2026-08-16):
  - Called with just the event's own title text (no imdb_id/year — these
    are event names, not movie titles), same plain title-search mode
    search_knaben/search_1337x already support on their own.
  - UFC: real, correctly-matched results confirmed live for "UFC 330" — 10
    results, including actual real full main-card/prelims rips (e.g.
    "UFC.330.Makhachev.vs.Machado.Garry.Main.Card.And.Prelims.1080p.IPTV.
    MKV/H.265") alongside some legitimately-titled-but-not-the-full-event
    noise (PPV Countdown specials, Embedded vlog episodes — these carry
    "UFC 330" in their real title too, so they pass the title-word filter
    honestly; they're just not what most users mean by "the replay").
  - Boxing: real match confirmed live for "Errol Spence Jr. vs. Tim Tszyu"
    — 1 result, a real, well-seeded (94 seeds) Russian-broadcast IPTV rip
    with the fighters' names and date in its own title.
  - MLB: confirmed NOT a good match — 0 real results across several real
    title attempts tried live ("Boston Red Sox at Pittsburgh Pirates",
    "Los Angeles Dodgers vs Toronto Blue Jays World Series Game 7", "MLB
    World Series 2025 Game 7"). Individual regular-season (and even
    marquee playoff) games essentially don't get uploaded/named this way
    on general torrent sites the way PPV/fight-card events do. Still wired
    in unconditionally for MLB too (a big enough game could hit some day)
    rather than special-cased off — it's a harmless no-op exactly like
    every other empty-results case already handled throughout this module.
  - Each matched result is appended with 'magnet' (and 'url' set to the
    same magnet: URI) and a label like 'Knaben [1080p, 11 seeds]' so it's
    clearly distinguishable in the picker from the embed-page sources
    above it — see sports_router.py's _play_stream for the magnet: branch
    that routes these through the addon's existing debrid resolver instead
    of ResolveURL.

TMDB icon feasibility (checked live via /search/movie, api.themoviedb.org
using the same TMDB_KEYS this addon already uses in metadata.py):
  - UFC: excellent coverage. Every real event name pulled from the scrape
    above resolved to exactly one movie result with a real poster_path —
    "UFC 330" -> "UFC 330: Makhachev vs. Machado Garry" (2026-08-15,
    poster /dG6WMwBdPjSxlXFuBed4DKDAcdM.jpg), "UFC 329" -> "UFC 329:
    McGregor vs. Holloway 2", and even watchmmafull.com's own "UFC Vegas
    120" naming correctly fuzzy-matched to the same TMDB entry
    fullfightreplays.com calls "UFC Fight Night 284: Gamrot vs. Salkilld"
    (2026-08-08, poster /qSsDud1zHhodVHDs439xEj33OTK.jpg) — TMDB catalogs
    these as /search/movie results (PPV "event specials"), not /search/tv.
  - Boxing: also excellent. "Errol Spence Jr vs Tim Tszyu" ->
    "Errol Spence Jr. vs. Tim Tszyu" (2026-07-25, real poster), "Claressa
    Shields vs Kaye Scott" -> exact match (2026-08-15, real poster),
    "Fundora vs Thurman" -> "Sebastian Fundora vs. Keith Thurman"
    (2026-03-28, real poster) — same /search/movie pattern as UFC.
  - MLB: confirmed NOT catalogued, as expected. "Texas Rangers vs
    Athletics", "Los Angeles Dodgers vs Toronto Blue Jays World Series
    Game 7", "Milwaukee Brewers vs Los Angeles Dodgers" all returned 0
    results on both /search/movie and /search/tv — individual MLB games
    are not TMDB/IMDb entries. MLB events should fall back to a generic
    MLB/team logo (this addon already has ESPN CDN team-logo plumbing in
    sports_sources.py's _espn_logo — the mlblive.net per-event thumbnail
    below is also a real, live-confirmed fallback in the meantime).
  get_replay_poster() below wraps metadata.search_movies() for this.

Per-event site-native thumbnail (checked live per the follow-up request —
"does the source site itself expose a real per-event image, for the cases
TMDB won't have one"):
  - UFC:    watchmmafull.com has NONE (empty <img src> and empty og:image,
            confirmed live) — TMDB is the only real art source for events
            sourced from there. fullfightreplays.com DOES have one, a
            real distinct image per event (/_pu/<n>/<id>.png|jpg,
            confirmed live 200/real bytes) — carried in event['thumb']
            when an event has an ffr_url.
  - Boxing: fullfightreplays.com — same real per-event thumbnail as UFC
            above. box.live has no single fight-poster image, but DOES
            have 2 real per-fighter hero photos on every fight page
            (confirmed live, distinct real files, not the site's own
            'blank-fighter.png' placeholder for the fights checked) —
            carried as event['fighter1_photo']/['fighter2_photo'].
  - MLB:    mlblive.net has a real per-event thumbnail, same /_pu/ scheme
            as fullfightreplays.com (confirmed live) — carried in
            event['thumb'].

Return shape (per the eventual Sports > Replay > [UFC|Boxing|MLB] >
[dates] > [events] > [fight/source picker] menu this is built for):
  get_replay_dates(sport)          -> [{'date_key': 'YYYY-MM-DD',
                                         'label': 'Month D, YYYY'}, ...]
                                       most recent first.
  get_replay_events(sport, date_key) -> [event dict, ...] — each carries
                                       at least 'title', 'date_key',
                                       'date_label', 'id', 'thumb', plus
                                       internal fields (e.g. 'wmf_fights',
                                       'ffr_url', 'boxlive_url') that
                                       get_replay_sources() reads back.
                                       Pass one of these dicts straight
                                       into get_replay_sources() — no
                                       separate lookup needed.
  get_replay_sources(sport, event) -> [{'label': str, 'url': str}, ...] —
                                       individual fight/matchup entries
                                       AND full-card/section entries are
                                       both included as separate options
                                       whenever the source site offers
                                       both, never one-or-the-other. Magnet
                                       (torrent) entries — sport-video.org.ua
                                       and the generic torrent_sources.
                                       search_all() results, both added
                                       2026-08-16 — also carry a 'magnet'
                                       key equal to 'url' so the caller
                                       (sports_router.py's _play_stream)
                                       knows to route them through the
                                       addon's debrid resolver instead of
                                       ResolveURL.

Cache: event catalogs 20 min, individual source-page resolutions 15 min
(sport-video.org.ua's per-event magnet resolution included), TMDB poster
lookups 24h (via metadata.py's own cache calls). torrent_sources.search_all()
has its own separate 15 min cache, unaffected by this module's own TTLs.

── 2026-08-16 reliability audit ("most of the replays dont play") ────────
User-reported regression after the OK.ru/ffmpegdirect fix, investigated
live end-to-end (real requests.get() against every resolved URL, not just
"did a URL come back") rather than guessing a 3rd OK.ru fix:
  - watchmmafull.com: confirmed still fully working, deep-verified all the
    way to a real MPEG-TS sync byte (0x47) inside a fetched segment.
  - Dailymotion embeds (used by fullfightreplays.com's UFC Main Card/
    Prelims and, discovered live while auditing NBA, basketball-video.com):
    confirmed fully working — its public /player/metadata/video/<id> API
    (no key needed) returns a real HLS master that fetches clean.
  - "Filemoon" (bysesukior.com, labeled by both fullfightreplays.com and
    basketball-video.com): confirmed NEVER works — 16/16 sampled pages
    across UFC/Boxing/NBA are the identical bare React SPA shell, nothing
    server-side to scrape. This is NOT the real filemoon.sx/.to ResolveURL
    supports, just a similarly-branded dead host. Now filtered out
    entirely (_FFR_DEAD_HOSTS) instead of offered as a guaranteed-broken
    picker option.
  - OK.ru: still failing on the user's real Kodi 21.1 device even with
    curl-mode ffmpegdirect active. Root-caused (not just re-guessed) via a
    live tamper test: okcdn.ru's CDN URL embeds a `srcIp=<ip>` param that
    IS actively enforced server-side — editing only that param on an
    otherwise-untouched, correctly-signed URL flips a working 200/video
    response into a 400. This confirms the earlier "IP/session-binding
    between the metadata-fetch step and the video-fetch step" theory is
    real, not a hunch — see sports_router._resolve_okru's own docstring
    for the exact proof and why this is a genuine dead end for this
    addon's own code (both DNS hosts involved are IPv4-only, ruling out
    an IPv4/IPv6 dual-stack mismatch specifically; a network-level cause
    on the user's own device/ISP side, e.g. per-connection NAT/VPN IP
    rotation between the addon's own metadata POST and Kodi's separate
    ffmpegdirect/curl playback fetch, remains the leading real
    explanation). Kept as an option everywhere (never removed — some
    users' networks won't hit this), but now sorted toward the END of
    each event's source list (_ffr_host_priority) rather than wherever it
    fell in raw document order, so Dailymotion (confirmed reliable) is
    reached first when both exist.
  - Coverage gap this audit surfaced: MLB (mlblive.net) offers ONLY OK.ru
    per game — confirmed live across 12/12 sampled games, zero exceptions,
    no Dailymotion/Filemoon alternate ever appears for MLB specifically.
    Reordering is a no-op there; MLB's only other real options are sport-
    video.org.ua's torrent (needs a debrid service) and the generic
    torrent search (confirmed a poor match for MLB titles — see the
    original torrent-search section above). This — not a scraper bug — is
    the biggest single reason "most of the replays don't play" for MLB
    specifically right now.
  - YouTube path (box.live, Boxing) audited per direct request: ResolveURL
    5.1.206's own youtube.py plugin (checked directly via its published
    source) never appends Kodi's pipe-delimited url|Header=value syntax to
    a resolved googlevideo.com URL — confirmed by reading its actual
    get_media_url() return paths. This means sports_router._play_stream's
    `if '|' in resolved and _has_ffmpegdirect():` branch (added by the
    OK.ru fix) structurally CANNOT fire for a successfully-resolved
    YouTube stream — it's already correctly scoped to only the OK.ru/
    Referer-tagged paths that explicitly build a pipe-tagged string, and
    was NOT the cause of any YouTube regression. No code change was needed
    there; left as-is with this evidence documented in its own comment so
    a future session doesn't re-litigate it from scratch.

── 2026-08-16 new categories: NHL, NFL, NBA ───────────────────────────────
Each candidate investigated live, independently — see _get_nhl_catalog/
_get_nfl_catalog/_get_nba_catalog and the comment blocks directly above
_RE_NHL_CARD/_RE_BV_ROW for the full live evidence per site:
  NHL — NHL66.ir is a dead end for THIS feature (redirects straight to
    nhl24all.ir, which per this addon's own addon.xml changelog is
    already a wired-in LIVE-game source elsewhere, not a past-event
    archive). NHL.com's own /video/topic/condensed-games/ page is real
    and genuinely used instead: free, DRM-free, resolved via Brightcove's
    public Playback API using a policy key scraped from NHL.com's own
    public player JS — confirmed live against 2 different real video ids,
    both real fetchable HLS. Plus sport-video.org.ua's /hockey.html
    (unfiltered — confirmed no non-NHL contamination live).
  NFL — nfl-video.com is the same site engine as mlblive.net/
    fullfightreplays.com as expected (confirmed live, needed one shared-
    regex tolerance fix, not a new parser), but its own per-event "watch"
    buttons are confirmed dead on every event sampled (see the dead-host
    audit above) — real catalog, non-functional native delivery. Real
    working sources for NFL come from sport-video.org.ua's
    /americanfootball.html (team-name-filtered — real page, mixed with
    CFL/UFL) and the generic torrent search.
  NBA — basketball-video.com is real but NOT the same per-event template
    as the other 3 FFR-family sites — confirmed live it's a per-DAY
    multi-game HTML table (literally reusing "nhl-"-prefixed CSS classes
    from what was clearly an NHL-family template originally), needing its
    own row-based parser (_bv_parse_sources) rather than reusing
    _ffr_parse_sources unchanged. OK.ru/Filemoon in that table carry the
    exact same audited reliability as everywhere else above; Dailymotion
    when present is reliable. Plus sport-video.org.ua's /basketball.html
    (team-name-filtered — real page, mixed with WNBA, which is the
    majority of its content in August's real NBA off-season).
"""

import re
import html as _html
import datetime
import xbmc
import xbmcaddon
import xbmcvfs
from concurrent.futures import ThreadPoolExecutor, as_completed

import requests as _req
from resources.lib import cache as _cache

ADDON    = xbmcaddon.Addon('plugin.video.starfleet')
_PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
_cache.init(_PROFILE + '/cache.db')

# Same browser-header convention as sports_sources.py/torrent_sources.py —
# no 'br' (Brotli) since decoding it needs an optional dependency this
# environment doesn't have; gzip/deflate are handled natively.
_HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/126.0.0.0 Safari/537.36'
    ),
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9',
    'Accept-Encoding': 'gzip, deflate',
}

_WMF_BASE     = 'https://watchmmafull.com'
_FFR_BASE     = 'https://fullfightreplays.com'
_BOXLIVE_BASE = 'https://box.live'
_MLBLIVE_BASE = 'https://mlblive.net'
_SVO_BASE     = 'https://sport-video.org.ua'
_NFL_BASE     = 'https://nfl-video.com'
_NBA_BASE     = 'https://basketball-video.com'
_NHL_BASE     = 'https://www.nhl.com'


_RE_CHALLENGE = re.compile(
    r'cf-browser-verification|Just a moment\.\.\.|__cf_chl_|Checking your browser|'
    r'cf-please-wait|Attention Required! \| Cloudflare',
    re.IGNORECASE)


def _get(url, timeout=12, referer=''):
    """Real diagnostic gap found live 2026-08-17: a device-specific report
    of every Replay catalog coming back genuinely empty (not erroring - a
    clean "No X replays found" with zero warnings logged anywhere,
    confirmed live even right after a cache clear) meant _get() itself was
    never producing evidence either way. A response that's a bot-challenge
    interstitial (Cloudflare's "Just a moment..." page, etc.) still comes
    back as a normal 200 - raise_for_status() never fires, so this used to
    silently hand the challenge HTML to the caller's regex parser, which
    then just as silently finds 0 matches (no event markup in a challenge
    page) with nothing to log at any layer. Detecting and logging this
    case explicitly turns "no idea why this device gets nothing" into a
    real, checkable answer."""
    try:
        headers = dict(_HEADERS)
        if referer:
            headers['Referer'] = referer
        r = _req.get(url, headers=headers, timeout=timeout)
        r.raise_for_status()
        text = r.text
        if _RE_CHALLENGE.search(text[:4000]):
            xbmc.log('[Starfleet/Replay] GET %s: got a bot-challenge page '
                      '(200 OK, but no real content) instead of the real page'
                      % url[:90], xbmc.LOGWARNING)
            return ''
        snippet = _RE_WS.sub(' ', text[:4000]).strip()[:150]
        xbmc.log('[Starfleet/Replay] GET %s: %d bytes, starts: %r'
                  % (url[:90], len(text), snippet), xbmc.LOGINFO)
        return text
    except Exception as e:
        xbmc.log('[Starfleet/Replay] GET %s: %s' % (url[:90], e), xbmc.LOGWARNING)
        return ''


_RE_WS = re.compile(r'\s+')


def _clean(t):
    return _RE_WS.sub(' ', _html.unescape(t or '')).strip(' - ')


_MONTHS = {
    'january': 1, 'jan': 1, 'february': 2, 'feb': 2, 'march': 3, 'mar': 3,
    'april': 4, 'apr': 4, 'may': 5, 'june': 6, 'jun': 6, 'july': 7, 'jul': 7,
    'august': 8, 'aug': 8, 'september': 9, 'sep': 9, 'sept': 9,
    'october': 10, 'oct': 10, 'november': 11, 'nov': 11, 'december': 12, 'dec': 12,
}
_MONTH_LABEL = ('', 'January', 'February', 'March', 'April', 'May', 'June',
                'July', 'August', 'September', 'October', 'November', 'December')
_RE_DATE_PARTS = re.compile(r'^([A-Za-z]+)\.?\s+(\d{1,2})\s+(\d{4})$')


def _parse_date(s):
    """Parse the various date-string formats used across the 4 sites
    ('August 15, 2026' / 'Aug 09, 2026' / 'Saturday, Aug 08 2026') into
    (date_key 'YYYY-MM-DD', label 'Month D, YYYY'). Returns (None, s) on
    failure so one malformed date can never crash a whole catalog fetch —
    the caller just drops that entry.

    Deliberately hand-rolled instead of datetime.strptime's %B/%b, which
    match month names via the process's current LC_TIME locale - confirmed
    live this silently fails to match plain English month names ("August")
    under a non-English locale (e.g. strptime('August 15 2026', '%B %d %Y')
    raises under fr_FR), and this function's own broad except/continue was
    swallowing that failure with nothing logged anywhere. A device whose
    locale isn't English-or-C could see every single date on every single
    Replay site fail to parse at once, silently dropping every event before
    it ever reached the catalog. This lookup table means the result no
    longer depends on the device's locale at all."""
    if not s:
        return None, ''
    s2 = re.sub(r'^[A-Za-z]+,\s*', '', s.strip())  # strip leading weekday, e.g. "Saturday, "
    s2 = s2.replace(',', '')
    m = _RE_DATE_PARTS.match(s2.strip())
    if not m:
        return None, s.strip()
    month = _MONTHS.get(m.group(1).lower())
    if not month:
        return None, s.strip()
    try:
        d = datetime.date(int(m.group(3)), month, int(m.group(2)))
    except Exception:
        return None, s.strip()
    return d.isoformat(), '%s %d, %d' % (_MONTH_LABEL[month], d.day, d.year)


# ── watchmmafull.com (UFC/MMA — per-fight) ──────────────────────────────────

_RE_WMF_ITEM = re.compile(
    r'<li class="video-item-compact">(.*?)</li>\s*(?=<li class="video-item-compact">|</ul>)',
    re.S)
_RE_WMF_TITLE     = re.compile(r'title="([^"]+)"', re.I)
_RE_WMF_HREF      = re.compile(r'href="(/[a-z0-9\-]+\.html)"\s+class="video-thumb-small"', re.I)
_RE_WMF_WATCH_BTN = re.compile(r'<a href="([^"]+)"\s+class="watch-link-btn', re.I)
_RE_WMF_FILECODE  = re.compile(r'/embed/([A-Za-z0-9]+)')


def _wmf_scrape_ufc():
    """See module docstring's watchmmafull.com section for what's confirmed
    live about this site's real catalog depth/shape. Groups the individual
    fight-card entries (title format always "EVENT - FIGHTER A vs.
    FIGHTER B - DATE", confirmed stable live) by event into one dict per
    real event, each carrying its list of per-fight page URLs."""
    html = _get(_WMF_BASE + '/')
    if not html:
        return []

    events = {}  # (event_name, date_key) -> event dict
    for block in _RE_WMF_ITEM.findall(html):
        href_m  = _RE_WMF_HREF.search(block)
        title_m = _RE_WMF_TITLE.search(block)
        if not href_m or not title_m:
            continue
        title = _clean(title_m.group(1))
        parts = [p.strip() for p in title.split(' - ')]
        if len(parts) < 3:
            continue
        event_name, fighters, date_str = parts[0], parts[1], parts[-1]
        date_key, date_label = _parse_date(date_str)
        if not date_key:
            continue
        key = (event_name, date_key)
        ev = events.setdefault(key, {
            'sport': 'ufc', 'source': 'watchmmafull',
            'title': event_name, 'date_key': date_key, 'date_label': date_label,
            'id': 'wmf_%s_%s' % (re.sub(r'\W+', '_', event_name.lower()).strip('_'), date_key),
            'thumb': '', 'fanart': '',
            'wmf_fights': [],
        })
        ev['wmf_fights'].append({
            'label': fighters.replace(' vs.', ' vs'),
            'url':   _WMF_BASE + href_m.group(1),
        })

    return list(events.values())


def _wmf_resolve_fight(fight_url):
    """Resolve one watchmmafull.com fight page to a real playable URL, or
    None if the event's embed host is an unresolvable JS-SPA (see module
    docstring — this varies per EVENT, not per fight). playmate.to embeds
    resolve via a plain POST to its own /api/s endpoint with the filecode
    parsed out of the embed URL, returning {'sx': '<master m3u8 URL>'} —
    confirmed live real HLS (#EXTM3U) whose segments carry deliberately
    fake .css/.js/.woff extensions (real MPEG-TS bytes underneath, 0x47
    sync byte confirmed) as a crude scraper-deterrent; Kodi's own HLS
    demuxer reads the playlist by its declared content, not the URL
    suffix, so this plays fine as a direct stream URL."""
    ck = 'replay_wmf_fight_%s' % re.sub(r'\W+', '_', fight_url)[-80:]
    cached = _cache.get(ck)
    if cached is not None:
        return cached or None

    html = _get(fight_url)
    m = _RE_WMF_WATCH_BTN.search(html) if html else None
    if not m:
        _cache.set(ck, False, 15 * 60)
        return None
    embed_url = m.group(1)

    if 'playmate.to' in embed_url:
        fc_m = _RE_WMF_FILECODE.search(embed_url)
        if fc_m:
            try:
                r = _req.post(
                    'https://playmate.to/api/s',
                    json={'filecode': fc_m.group(1)},
                    headers=dict(_HEADERS, Referer=embed_url, Origin='https://playmate.to',
                                 **{'Content-Type': 'application/json'}),
                    timeout=10)
                r.raise_for_status()
                sx = r.json().get('sx', '') or None
                _cache.set(ck, sx or False, 15 * 60)
                return sx
            except Exception as e:
                xbmc.log('[Starfleet/Replay] watchmmafull playmate.to resolve failed (%s): %s'
                         % (fight_url[:60], e), xbmc.LOGWARNING)

    # Unknown/JS-SPA embed host (e.g. suisports.upns.xyz — bare JS bootstrap
    # shell, nothing server-rendered) — no real link to scrape, skip rather
    # than hand back a dead one.
    xbmc.log('[Starfleet/Replay] watchmmafull unresolved embed host for %s: %s'
             % (fight_url[:60], embed_url), xbmc.LOGINFO)
    _cache.set(ck, False, 15 * 60)
    return None


# ── fullfightreplays.com (UFC + Boxing) / mlblive.net (MLB) shared template ──
# Confirmed live: both sites are built on the same site engine — same
# "/_pu/<n>/<id>" thumbnail scheme, same event-listing markup, same
# "<strong>/<b>Section header</strong>" + su-button-link-or-iframe watch
# section on event pages — so one pair of parsers covers all 3 of this
# module's 3 target categories for these 2 sites.

_RE_FFR_LIST_ITEM = re.compile(
    # Loosened 2026-08-16 while adding NFL (nfl-video.com)/NBA (basketball-
    # video.com) — confirmed live those 2 sibling sites use the exact same
    # "/_pu/<n>/<id>" listing engine as fullfightreplays.com/mlblive.net,
    # but with 2 small template differences that made the original strict
    # pattern miss every single item on them (0 matches, confirmed live):
    # (1) the thumbnail <a>/<img> tags carry extra attributes (a `title=`
    # on the <a>, a `loading="lazy"` on the <img>) instead of being bare,
    # and (2) the date line is nfl-video.com's own site text sits directly
    # inside <div class="short_descr"> with NO inner <p> wrapper, instead
    # of fullfightreplays.com/mlblive.net's <p>Month D, YYYY - Title</p>.
    # Both variants now match with the same one regex — re-verified live
    # this doesn't change what matches on the original 2 sites at all
    # (identical event counts/content before and after).
    r'<a href="(/[a-z0-9\-]+)"[^>]*>\s*<img src="(/_pu/[^"]+)"[^>]*>\s*</a>.*?'
    r'<h3><a href="\1">([^<]+)</a></h3>.*?'
    r'<div class="short_descr">\s*(?:<p>)?\s*([A-Za-z]+ \d{1,2}, \d{4})',
    re.S)


def _ffr_scrape_listing(base, path, pages=1):
    """Scrape a fullfightreplays.com/mlblive.net category or homepage
    listing page, optionally following its real pagination for `pages`
    total pages. CORRECTION from an earlier pass of this module: this
    site's pagination is NOT the `/path/page/2` scheme that was tried and
    404'd — confirmed live 2026-08-16 the real working scheme is a bare
    `?page<N>` query suffix on the SAME path (`/ufc?page2`, `/?page3`,
    etc — no `=` sign, no leading `/page/`), which returns genuinely
    different, older events on each page (confirmed live: fullfightreplays
    goes back to January 2026 for UFC over 3 pages, and mid-June 2026 for
    Boxing; mlblive.net's `?pageN` on the homepage moves one real day
    back roughly every page). Stops early if a page returns zero events
    (reached the end of the real archive) rather than always fetching the
    full `pages` count."""
    events = []
    for page in range(1, pages + 1):
        url = base + path + ('?page%d' % page if page > 1 else '')
        html = _get(url)
        if not html:
            break
        page_events = []
        for href, thumb, title, date_str in _RE_FFR_LIST_ITEM.findall(html):
            date_key, date_label = _parse_date(date_str)
            if not date_key:
                continue
            page_events.append({
                'title': _clean(title), 'url': base + href, 'thumb': base + thumb,
                'date_key': date_key, 'date_label': date_label,
            })
        if not page_events:
            break
        events.extend(page_events)
    return events


_RE_FFR_HEADER = re.compile(
    # Section headings appear both as <strong><span>Text</span></strong>
    # (mlblive.net's "Server #N") and plain <strong>Text</strong> /
    # <b>Text</b> (fullfightreplays.com's "Main Card...", "OK", "Fiilemoon"
    # [sic]) — confirmed live both nestings occur, so the inner <span> is
    # optional here rather than assumed either way.
    r'<(?:strong|b)>\s*(?:<span[^>]*>)?\s*([^<]{1,60}?)\s*(?:</span>)?\s*</(?:strong|b)>', re.I)
_RE_FFR_BUTTON = re.compile(
    r'class="su-button[^"]*"[^>]*href="([^"]+)"[^>]*>.*?<span[^>]*>([^<]{1,20})</span>',
    re.I | re.S)
_RE_FFR_IFRAME = re.compile(r'<iframe[^>]+src="((?:https?:)?//[^"]+)"', re.I)

# Short/typo'd site labels normalized to a clearer host name for the picker
# (confirmed live "OK" and "Fiilemoon" [sic] are exactly what the site's
# own HTML uses for these 2 headers).
_FFR_HOST_SYNONYMS = {'ok': 'OK.ru', 'fiilemoon': 'Filemoon', 'filemoon': 'Filemoon'}

# ── Reliability audit findings, confirmed live 2026-08-16 (see the user
# report "most of the replays dont play" that triggered this) ─────────────
#
# Hosts that NEVER produce a real playable stream, structurally, regardless
# of ResolveURL/this addon's own scraping — skipped outright rather than
# reordered, same "don't hand back a dead link" rule _wmf_resolve_fight
# already applies to watchmmafull.com's own unresolvable JS-SPA embeds:
#   - bysesukior.com: the site's own "Filemoon" label on fullfightreplays.
#     com/mlblive.net/basketball-video.com is misleading — this domain is
#     NOT filemoon.sx/.to (which ResolveURL's Filemoon plugin actually
#     supports), it's a differently-branded "Byse Frontend" host. Confirmed
#     live: every single one of 16 sampled /d/<id> and /e/<id> pages across
#     4 UFC events, 6 Boxing events, and 2 NBA games returns the IDENTICAL
#     ~2KB bare React SPA shell (empty <div id="root">, a Vite/React JS
#     bundle bootstraps everything client-side) — nothing server-rendered
#     exists to scrape, and the JS bundle's own API base isn't a literal
#     string in its 282KB minified source either (confirmed live, checked).
#     16/16, not "sometimes down" — this is a permanently dead host label.
#   - nhlgamestoday.com: nfl-video.com's own "Server #1/#2/#3" su-buttons
#     point here on every single event sampled (6/6, spanning 3 different
#     dates) — a completely unrelated February-2024 "NHL games on TV today"
#     article, not a video embed at all. This is bogus/broken site data on
#     nfl-video.com's own end (or a hijacked ad slot), not a scraper miss —
#     nothing genuine to recover here either.
_FFR_DEAD_HOSTS = ('bysesukior.com', 'nhlgamestoday.com')


def _ffr_is_dead_host(url):
    return any(h in url for h in _FFR_DEAD_HOSTS)


def _ffr_host_priority(url):
    """Sort key that pushes OK.ru-hosted sources toward the END of a
    picker's option list instead of wherever they happened to fall in
    document order — confirmed live 2026-08-16: OK.ru is currently still
    failing to play on a real Kodi 21.1 device even with the
    inputstream.ffmpegdirect curl-mode fix from the previous round (see
    sports_router._resolve_okru's own docstring for a live tamper-test that
    pins down exactly why: okcdn.ru's CDN signs its URLs to the requesting
    IP via a `srcIp=` query param it actively validates — confirmed by
    editing just that param on an otherwise-untouched, correctly-signed
    URL and getting a 400 back), while this SAME event's Dailymotion
    alternates (when the site offers any — see module docstring) were
    independently confirmed live to serve real HLS video via a plain
    requests.get(). Never removes OK.ru — it may well still work fine on
    a network that isn't hitting that IP-binding gap — just stops it being
    the default-looking first choice the way a blind document-order list
    would. A stable sort (Python's default) keeps same-priority entries
    (e.g. Main Card Part 1/2/3) in their original relative order."""
    if 'ok.ru' in url or 'odnoklassniki.ru' in url:
        return 1
    return 0


def _ffr_parse_sources(html):
    """Generic 'section heading (<strong>/<b>) applies to every su-button
    link or raw <iframe> that follows it, until the next heading' parser —
    confirmed live against both fullfightreplays.com's UFC (Main Card in
    2 quality tiers x parts, Prelims, Early Prelims x multiple hosts) and
    Boxing (Server #1/#2 x host) event pages, and mlblive.net's game pages
    (single "Server #N" x host). Confirmed-dead hosts are dropped and
    OK.ru is stable-sorted toward the end — see _FFR_DEAD_HOSTS/
    _ffr_host_priority above for the live evidence behind both."""
    if not html:
        return []
    tokens = []
    for m in _RE_FFR_HEADER.finditer(html):
        tokens.append((m.start(), 'header', _clean(m.group(1))))
    for m in _RE_FFR_BUTTON.finditer(html):
        tokens.append((m.start(), 'button', (m.group(1), _clean(m.group(2)))))
    for m in _RE_FFR_IFRAME.finditer(html):
        tokens.append((m.start(), 'iframe', m.group(1)))
    tokens.sort(key=lambda t: t[0])

    results = []
    seen    = set()
    cur_header = ''
    for _, kind, val in tokens:
        if kind == 'header':
            cur_header = _FFR_HOST_SYNONYMS.get(val.lower(), val)
            continue
        url, label = val if kind == 'button' else (val, '')
        url = _html.unescape(url)
        url = url if url.startswith('http') else 'https:' + url
        if url in seen or _ffr_is_dead_host(url):
            continue
        seen.add(url)
        if label and label.lower() != 'watch' and cur_header:
            full_label = '%s - %s' % (cur_header, label)
        else:
            full_label = cur_header or label or 'Watch'
        results.append({'label': full_label, 'url': url})
    results.sort(key=lambda r: _ffr_host_priority(r['url']))
    return results


def _ffr_event_sources(url):
    ck = 'replay_ffr_src_%s' % re.sub(r'\W+', '_', url)[-80:]
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    result = _ffr_parse_sources(_get(url))
    _cache.set(ck, result, 15 * 60)
    return result


# ── box.live (Boxing only) ───────────────────────────────────────────────────

_RE_BOXLIVE_VS_LINK = re.compile(r'href="(https://box\.live/fights/[a-z0-9\-]+-vs-[a-z0-9\-]+/)"')
_RE_BOXLIVE_H1       = re.compile(r'<h1[^>]*>\s*([^<]+?)\s*</h1>', re.I)
_RE_BOXLIVE_DATE     = re.compile(r'fight-date__str1[^>]*>\s*([^<]+?)\s*<', re.I)
_RE_BOXLIVE_VIDEO    = re.compile(r'replay-iframe[^>]*src="([^"]+)"', re.I)
_RE_BOXLIVE_PHOTO    = re.compile(
    r'data-src="(https://box\.live/wp-content/uploads/[^"]+\.(?:png|jpg))"', re.I)
_BOXLIVE_PHOTO_SKIP = ('ppv', 'amazon', 'banner', 'sponsor', 'blank-fighter', 'logo')


def _boxlive_fight_detail(url):
    """Fetch one box.live /fights/<slug>/ page. Returns None on fetch
    failure; otherwise a dict — 'video_url' is '' (not missing) when the
    site's own honest 'no replay yet' state applies, which is common for
    fights within the last couple of weeks (confirmed live: not every
    fight gets an official replay upload, and it can take weeks when it
    does)."""
    html = _get(url)
    if not html:
        return None
    h1_m   = _RE_BOXLIVE_H1.search(html)
    date_m = _RE_BOXLIVE_DATE.search(html)
    if not h1_m or not date_m:
        return None
    date_key, date_label = _parse_date(date_m.group(1))
    if not date_key:
        return None

    video_m = _RE_BOXLIVE_VIDEO.search(html)

    # Hero fighter photos: scoped to the region between the fight-card
    # header and the replays section so an ad banner or undercard-fighter
    # thumbnail elsewhere on the page can't get picked up instead.
    i0 = html.find('single-fight')
    i1 = html.find('id="replays"')
    region = html[i0:i1] if 0 <= i0 < i1 else html[:20000]
    photos = []
    for p in _RE_BOXLIVE_PHOTO.finditer(region):
        u = p.group(1)
        if any(skip in u.lower() for skip in _BOXLIVE_PHOTO_SKIP):
            continue
        if u not in photos:
            photos.append(u)
        if len(photos) >= 2:
            break

    return {
        'title':      _clean(h1_m.group(1)),
        'url':        url,
        'date_key':   date_key,
        'date_label': date_label,
        'video_url':  video_m.group(1) if video_m else '',
        'fighter1_photo': photos[0] if len(photos) > 0 else '',
        'fighter2_photo': photos[1] if len(photos) > 1 else '',
    }


def _boxlive_scrape_boxing():
    """box.live's /fight-results/ listing gives slugs + records but not a
    clean per-card date/title in one pass (that page is a stats/results
    table, not a blog-style listing like fullfightreplays.com's), so each
    real fight found there is fetched individually for its date, video
    (if any) and fighter photos — bounded (~38 real fights at check time)
    and threaded, same pattern sports_sources.py already uses for
    concurrent per-item fetches."""
    html = _get(_BOXLIVE_BASE + '/fight-results/')
    if not html:
        return []
    slugs = list(dict.fromkeys(_RE_BOXLIVE_VS_LINK.findall(html)))  # de-dup, preserve order

    events = []
    with ThreadPoolExecutor(max_workers=8) as ex:
        futures = {ex.submit(_boxlive_fight_detail, u): u for u in slugs}
        for fut in as_completed(futures):
            try:
                d = fut.result()
            except Exception as e:
                xbmc.log('[Starfleet/Replay] box.live fight detail: %s' % e, xbmc.LOGWARNING)
                continue
            if d:
                events.append(d)
    return events


# ── sport-video.org.ua (UFC + Boxing via /other.html, MLB via /baseball.html
#    — TORRENT-based, .torrent-file-to-magnet, see module docstring) ────────

_RE_SVO_ITEM = re.compile(
    r"<strong>([^<]+?)\s+(\d{2}\.\d{2}\.\d{4})</strong></span>(.*?)"
    r'<a href="\./([^"]+\.html)">', re.S)
_RE_SVO_THUMB = re.compile(r"images/([^'\"]+\.(?:jpg|png))", re.I)
_RE_SVO_TORRENT_LINK = re.compile(r'<a href="(\./[^"]+\.torrent)">')
_SVO_UFC_RE    = re.compile(r'\bUFC\b', re.I)
_SVO_BOXING_RE = re.compile(r'\bBoxing\b', re.I)

# /americanfootball.html and /basketball.html (checked live 2026-08-16 while
# adding NFL/NBA — both nav links seen during the earlier investigation of
# this site) are real, but each is a mixed-league page with no "NFL"/"NBA"
# text prefix to filter on the way /other.html's "UFC ..."/"Boxing ..."
# titles have — confirmed live /americanfootball.html mixes real NFL with
# CFL (Roughriders, Tiger-Cats, Elks, Redblacks, Alouettes, Stampeders,
# Argonauts, BC Lions, Blue Bombers) and UFL (Defenders, Kings,
# Battlehawks, Storm, Aviators, Gamblers, Stallions) team names, and
# /basketball.html mixes real NBA with WNBA (Lynx, Aces, Fever, Sky,
# Valkyries, Tempo, Dream, Liberty, Mystics, Sparks, Storm, Mercury, Sun)
# team names — so these filter by a real NFL/NBA team-name whitelist
# instead. /hockey.html only ever returned real NHL content in a live
# check (4/4 items, all 2026 Stanley Cup Final Carolina/Vegas games) with
# no other-league contamination seen, so it's taken unfiltered like
# /baseball.html already is for MLB.
_SVO_NFL_TEAMS = re.compile(
    r'\b(?:Cardinals|Falcons|Ravens|Bills|Panthers|Bears|Bengals|Browns|'
    r'Cowboys|Broncos|Lions|Packers|Texans|Colts|Jaguars|Chiefs|Raiders|'
    r'Chargers|Rams|Dolphins|Vikings|Patriots|Saints|Giants|Jets|Eagles|'
    r'Steelers|49ers|Seahawks|Buccaneers|Titans|Commanders)\b', re.I)
_SVO_NBA_TEAMS = re.compile(
    r'\b(?:Hawks|Celtics|Nets|Hornets|Bulls|Cavaliers|Mavericks|Nuggets|'
    r'Pistons|Warriors|Rockets|Pacers|Clippers|Lakers|Grizzlies|Heat|'
    r'Bucks|Timberwolves|Pelicans|Knicks|Thunder|Magic|76ers|Suns|'
    r'Trail\s?Blazers|Kings|Spurs|Raptors|Jazz|Wizards)\b', re.I)
_SVO_NHL_TEAMS = re.compile(
    r'\b(?:Ducks|Bruins|Sabres|Flames|Hurricanes|Blackhawks|Avalanche|'
    r'Blue\s?Jackets|Stars|Red\s?Wings|Oilers|Panthers|Kings|Wild|'
    r'Canadiens|Predators|Devils|Islanders|Rangers|Senators|Flyers|'
    r'Penguins|Sharks|Kraken|Blues|Lightning|Maple\s?Leafs|Mammoth|'
    r'Canucks|Golden\s?Knights|Capitals|Jets)\b', re.I)
_SVO_MLB_TEAMS = re.compile(
    r'\b(?:Diamondbacks|Braves|Orioles|Red\s?Sox|Cubs|White\s?Sox|Reds|'
    r'Guardians|Rockies|Tigers|Astros|Royals|Angels|Dodgers|Marlins|'
    r'Brewers|Twins|Mets|Yankees|Athletics|Phillies|Pirates|Padres|'
    r'Giants|Mariners|Cardinals|Rays|Rangers|Blue\s?Jays|Nationals)\b', re.I)


def _extract_team_pair(title, team_re):
    """Pull the (up to) two team nicknames out of a title, normalized so
    'Team A vs. Team B' and 'Team B at Team A' style titles from different
    sites resolve to the same order-independent key."""
    teams = team_re.findall(title)
    if len(teams) < 2:
        return None
    norm = lambda t: re.sub(r'\s+', ' ', t).strip().lower()
    return frozenset((norm(teams[0]), norm(teams[1])))


def _merge_svo_by_teams(primary_events, svo_events, team_re, sport):
    """Merge a primary site's event list with sport-video.org.ua's separate
    listing for the same sport, matched by (date_key, team-name pair)
    rather than by title/URL. The two sites use different title formats
    for the same real games (e.g. NFL: nfl-video.com's "Team vs. Team -
    Full Game Replay - NFL Preseason" vs sport-video.org.ua's "Team at
    Team"), so without this a single real game shows up as 2 unrelated
    catalog entries — one from the primary site (often with dead native
    links) and one from sport-video.org.ua (real magnet source) — and a
    user who opens the wrong one sees "no sources" even though a working
    duplicate exists elsewhere in the same date's list. Confirmed live for
    NFL before this existed: 7 of 10 games on one date were split exactly
    this way, all 7 resolvable once matched against their sport-video.org.ua
    counterpart.
    """
    svo_by_key = {}
    for ev in svo_events:
        pair = _extract_team_pair(ev['title'], team_re)
        if not pair:
            continue
        svo_by_key.setdefault((ev['date_key'], pair), []).append(ev)

    merged = []
    used_keys = set()
    for ev in primary_events:
        merged_ev = dict(ev)
        pair = _extract_team_pair(ev['title'], team_re)
        key = (ev['date_key'], pair) if pair else None
        if key and key in svo_by_key:
            svo_ev = svo_by_key[key][0]
            merged_ev['svo_url'] = svo_ev['url']
            if not merged_ev.get('thumb'):
                merged_ev['thumb'] = svo_ev.get('thumb', '')
            used_keys.add(key)
        merged.append(merged_ev)

    for key, evs in svo_by_key.items():
        if key in used_keys:
            continue
        for ev in evs:
            merged.append({
                'sport': sport, 'source': 'sportvideo', 'title': ev['title'],
                'date_key': ev['date_key'], 'date_label': ev['date_label'],
                'id': 'svo_%s_%s' % (re.sub(r'\W+', '_', ev['title'].lower()).strip('_'), ev['date_key']),
                'thumb': ev.get('thumb', ''), 'fanart': '',
                'svo_url': ev['url'],
            })
    return merged


def _svo_parse_date(s):
    """sport-video.org.ua's own date format is always numeric DD.MM.YYYY
    (e.g. '15.08.2026') — confirmed live, distinct from every other source
    in this module (all of which use textual month names) — so this gets
    its own tiny parser rather than overloading _parse_date's format list
    with a 5th guess."""
    try:
        d = datetime.datetime.strptime(s.strip(), '%d.%m.%Y').date()
        return d.isoformat(), d.strftime('%B %d, %Y')
    except Exception:
        return None, s.strip()


def _svo_scrape_listing(path_base, max_pages):
    """Fetch sport-video.org.ua's numbered pagination for one category
    (path_base='baseball' or 'other') — confirmed live real, distinct
    pages/dates all the way from path_base+'.html' (page 1) through
    path_base+'<max_pages-1>.html', 404ing cleanly past the real archive
    end (confirmed live: baseball9.html and other26.html both 404 —
    max_pages is passed one past the last confirmed-real page so a 404 on
    the extra page is expected/harmless, not a sign something broke).

    Two HTML template generations coexist across the real archive (newer:
    thumbnail via onclick="window.open('images/...')"; older, pre-mid-2026:
    thumbnail via a plain <a href="images/...jpg" rel="prettyPhoto...">
    link) — _RE_SVO_ITEM only anchors on the <strong>TITLE DATE</strong>
    heading and the following ./<slug>.html detail-page link, capturing
    whatever thumbnail markup sits between them as an opaque middle group
    parsed separately by _RE_SVO_THUMB — confirmed live this parses both
    template generations identically without needing to detect which one
    a given page uses.

    Fetched concurrently since every page URL is independently addressable
    (a numbered filename, not a real 'next page' link that has to be
    followed one at a time) — same threaded-fetch pattern
    _boxlive_scrape_boxing already uses for its own bounded per-item
    fetches."""
    urls = [_SVO_BASE + '/' + path_base + '.html']
    urls += [_SVO_BASE + '/%s%d.html' % (path_base, n) for n in range(1, max_pages)]

    pages = {}
    with ThreadPoolExecutor(max_workers=8) as ex:
        futures = {ex.submit(_get, u): u for u in urls}
        for fut in as_completed(futures):
            u = futures[fut]
            try:
                html = fut.result()
            except Exception as e:
                xbmc.log('[Starfleet/Replay] sport-video.org.ua page fetch (%s): %s'
                         % (u[:60], e), xbmc.LOGWARNING)
                continue
            if html:
                pages[u] = html

    events = []
    seen = set()
    for u in urls:  # preserve page order (most recent first)
        html = pages.get(u)
        if not html:
            continue
        for title, date_str, mid, href in _RE_SVO_ITEM.findall(html):
            date_key, date_label = _svo_parse_date(date_str)
            if not date_key:
                continue
            detail_url = _SVO_BASE + '/' + href
            if detail_url in seen:
                continue
            seen.add(detail_url)
            thumb_m = _RE_SVO_THUMB.search(mid)
            events.append({
                'title': _clean(title), 'url': detail_url,
                'thumb': (_SVO_BASE + '/images/' + thumb_m.group(1)) if thumb_m else '',
                'date_key': date_key, 'date_label': date_label,
            })
    return events


def _svo_get_listing(path_base, max_pages):
    """Cached wrapper around _svo_scrape_listing — both the UFC and Boxing
    catalogs below filter the SAME /other.html archive for their own
    sport, so without this they'd each independently re-fetch all ~26
    pages on a cold cache. 20 min TTL, same as every other catalog-level
    cache in this module."""
    ck = 'replay_svo_listing_%s_v1' % path_base
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    events = _svo_scrape_listing(path_base, max_pages)
    _cache.set(ck, events, 20 * 60)
    return events


def _svo_resolve_magnet(detail_url, title=''):
    """Resolve one sport-video.org.ua event page to a magnet: URI.
    Confirmed live this site only ever offers a real `.torrent` FILE
    download link on its detail pages (never a magnet: URI directly — see
    module docstring), so this downloads that file and derives the
    info_hash from its own bencoded 'info' dict — reusing
    torrent_sources.py's own _torrent_info_hash/_make_magnet helpers (the
    exact same technique already used there for FreeJAVTorrent's own
    torrent-file-only detail pages) instead of a second bencode parser
    living in this file too."""
    ck = 'replay_svo_magnet_%s' % re.sub(r'\W+', '_', detail_url)[-80:]
    cached = _cache.get(ck)
    if cached is not None:
        return cached or None

    html = _get(detail_url)
    m = _RE_SVO_TORRENT_LINK.search(html) if html else None
    if not m:
        _cache.set(ck, False, 15 * 60)
        return None

    from urllib.parse import quote as _uq, urljoin as _urljoin
    # The .torrent filename is the real event title + date with spaces —
    # confirmed live (e.g. "./UFC Fight Night Gamrot vs Salkilld
    # 08.08.2026.mkv.torrent") — quoted here rather than reconstructed from
    # the listing's own title/date fields so a mismatch in either can never
    # produce a broken download URL.
    torrent_url = _uq(_urljoin(detail_url, m.group(1)), safe=':/')
    try:
        r = _req.get(torrent_url, headers=_HEADERS, timeout=20)
        r.raise_for_status()
        torrent_bytes = r.content
    except Exception as e:
        xbmc.log('[Starfleet/Replay] sport-video.org.ua torrent fetch failed (%s): %s'
                 % (detail_url[:60], e), xbmc.LOGWARNING)
        _cache.set(ck, False, 15 * 60)
        return None

    from resources.lib import torrent_sources as _ts
    info_hash = _ts._torrent_info_hash(torrent_bytes)
    if not info_hash:
        xbmc.log('[Starfleet/Replay] sport-video.org.ua: no info_hash parsed from torrent (%s)'
                 % detail_url[:60], xbmc.LOGWARNING)
        _cache.set(ck, False, 15 * 60)
        return None
    magnet = _ts._make_magnet(info_hash, title)
    _cache.set(ck, magnet, 15 * 60)
    return magnet


# ── nfl-video.com (NFL) ──────────────────────────────────────────────────
# Investigated live 2026-08-16 per direct request (home.py's own comment
# already noted mlblive.net's nav links point to this as its NFL sister
# site). Confirmed: real, current listing (_ffr_scrape_listing works as-is
# once the shared regex above was loosened) — e.g. "Dallas Cowboys vs.
# Seattle Seahawks - NFL Preseason - August 15, 2026", real ?pageN
# pagination going back to mid-July. BUT the per-event "watch" links
# themselves are confirmed dead (see _FFR_DEAD_HOSTS above) on 6/6 events
# sampled across 3 different dates — this site's own catalog is real, its
# own delivery mechanism is not. Kept anyway (not a full dead end): the
# real event listing still gives sport-video.org.ua's own /americanfoot
# ball.html entries (below) and the generic torrent search something
# accurate to match against, and _ffr_event_sources already returns
# nothing (not a broken link) once the dead-host filter strips its output,
# so an NFL event with truly zero working sources just shows the
# torrent-only options rather than a guaranteed-broken "Server #1" button.

# ── basketball-video.com (NBA) ───────────────────────────────────────────
# Investigated live 2026-08-16, same expectation as NFL. Listing: real,
# current (2026-08-16 is deep NBA off-season, so the most recent real
# content is 2026 NBA Summer League — legitimate, not a bug). BUT the
# per-EVENT page structure is NOT the same single-su-button-article
# template fullfightreplays.com/mlblive.net/nfl-video.com use — confirmed
# live it's a per-DAY HTML <table class="nhl-box"> (yes, "nhl"-prefixed
# CSS class names even here — this whole table template was clearly built
# for an NHL-family sibling site first and reused as-is for basketball),
# with one ROW per individual GAME and one column per host (OK/
# DailyMotion/Filemoon — which columns exist and in what order varies row
# to row, so column position can't be trusted). _bv_parse_sources below
# parses each game row directly instead of tracking header columns.
_RE_BV_ROW = re.compile(
    r'<td class="nhl-game">\s*<p>\s*<span[^>]*>\s*<strong>([^<]+)</strong>.*?</p>\s*</td>(.*?)</tr>',
    re.S)
_RE_BV_LINK = re.compile(r'<a[^>]*href="([^"]+)"[^>]*>([^<]*)</a>', re.I)


def _bv_host_label(url):
    if 'ok.ru' in url or 'odnoklassniki.ru' in url:
        return 'OK.ru'
    if 'dailymotion' in url:
        return 'Dailymotion'
    try:
        return url.split('/')[2]
    except IndexError:
        return url


def _bv_parse_sources(html):
    """Per-game-row parser for basketball-video.com's own multi-game-per-
    day table layout — see the module-level comment above for why this
    can't reuse _ffr_parse_sources' header-then-buttons approach. Each
    game row's own <a href> links are classified by domain (same dead-host
    filter/OK.ru-last ordering as _ffr_parse_sources, reused not
    duplicated) rather than trusting column position, since confirmed live
    the header row's own column set isn't consistent from table to table
    on the same page (some games only have OK+Filemoon, others add a
    DailyMotion column with multiple Parts)."""
    if not html:
        return []
    results = []
    seen = set()
    for m in _RE_BV_ROW.finditer(html):
        matchup = _clean(m.group(1))
        for url, label in _RE_BV_LINK.findall(m.group(2)):
            url = _html.unescape(url)
            url = url if url.startswith('http') else 'https:' + url
            if url in seen or _ffr_is_dead_host(url):
                continue
            seen.add(url)
            host = _bv_host_label(url)
            label = label.strip()
            full_label = '%s - %s' % (matchup, host)
            if label and label.lower() not in ('watch', ''):
                full_label += ' %s' % label
            results.append({'label': full_label, 'url': url})
    results.sort(key=lambda r: _ffr_host_priority(r['url']))
    return results


def _bv_event_sources(url):
    ck = 'replay_bv_src_%s' % re.sub(r'\W+', '_', url)[-80:]
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    result = _bv_parse_sources(_get(url))
    _cache.set(ck, result, 15 * 60)
    return result


# ── NHL.com (NHL — "Condensed Games") ────────────────────────────────────
# Investigated live 2026-08-16 per direct request, both candidates:
#   - NHL66.ir: redirects straight to nhl24all.ir (confirmed live, both
#     http:// and https://) — this addon's OWN changelog (addon.xml
#     v2.3.212) shows nhl24all.ir/nba24all.ir/nfl24all.ir/mlb24all.ir are
#     ALREADY a wired-in, unauthenticated-JSON-API LIVE-game source
#     elsewhere in this addon (sports_sources.py) — not a past-event
#     replay archive at all, just this addon's existing live-game feed
#     under a different domain. Confirmed dead end for THIS feature
#     specifically (Replay), not worth a second, redundant integration.
#   - NHL.com's own /video/topic/condensed-games/ page: real dead end
#     RULED OUT — confirmed live this is a genuine, free, DRM-free source.
#     The listing page is real and server-rendered (32 real condensed
#     games on one page at check time, spanning the entire real 2026
#     Stanley Cup Playoffs/Final run, e.g. "CAR at VGK | Condensed Game",
#     Jun 15 2026) and — the key discovery — the Brightcove video ID is
#     baked directly into each card's own URL slug (e.g. ".../car-at-vgk-
#     condensed-game-6398428229112" -> video id 6398428229112), so no
#     per-event detail-page fetch is needed at all, unlike box.live's
#     equivalent per-fight crawl. Confirmed live end-to-end: NHL.com's own
#     public Brightcove account (6415718365001) + the policy key baked
#     into its own publicly-served player JS (players.brightcove.net/
#     6415718365001/default_default/index.min.js, no login/cookie needed)
#     resolves via Brightcove's standard Playback API to a real, genuinely
#     fetchable HLS master playlist — verified against 2 different real
#     video ids with a plain requests.get() using the SAME headers this
#     module uses everywhere else, both real 200s. The manifest path
#     itself says "clear" (Brightcove's own DRM-vs-clear distinction) —
#     confirmed no Widevine/DRM involved, matching this being NHL's free
#     highlight tier (full 2+ hour broadcasts are the actual subscription-
#     gated NHL.TV/ESPN+ product; condensed games ~12min are NHL's own
#     free tier and were never gated). No visible "load more"/pagination
#     API in the static HTML — this module takes the one real listing
#     page as-is, same "whatever's visible, no deeper crawl" approach
#     already used for watchmmafull.com's homepage-only listing and box.
#     live's /fight-results/ page.
_RE_NHL_CARD = re.compile(
    r'href="(/video/topic/condensed-games/[a-z0-9\-]*-(\d{9,}))"[^>]*data-id="[^"]*"[^>]*>.*?'
    r'<h3 class="fa-text__title">([^<]+)</h3>.*?'
    r'<time datetime="(\d{4}-\d{2}-\d{2})',
    re.S)

_NHL_BC_ACCOUNT = '6415718365001'
_NHL_PLAYER_JS  = 'https://players.brightcove.net/%s/default_default/index.min.js' % _NHL_BC_ACCOUNT
_RE_NHL_POLICY_KEY = re.compile(r'(BCpkADawqM[0-9A-Za-z_\-]{15,})')

# Full names for the 3-letter codes NHL.com's own condensed-game titles use
# ("CAR at VGK | Condensed Game") — cosmetic only, falls back to the raw
# code untouched for anything not in this list (e.g. a relocated/renamed
# team) rather than ever dropping/crashing on an unknown one.
_NHL_TEAM_NAMES = {
    'ANA': 'Anaheim Ducks', 'ARI': 'Arizona Coyotes', 'BOS': 'Boston Bruins',
    'BUF': 'Buffalo Sabres', 'CGY': 'Calgary Flames', 'CAR': 'Carolina Hurricanes',
    'CHI': 'Chicago Blackhawks', 'COL': 'Colorado Avalanche', 'CBJ': 'Columbus Blue Jackets',
    'DAL': 'Dallas Stars', 'DET': 'Detroit Red Wings', 'EDM': 'Edmonton Oilers',
    'FLA': 'Florida Panthers', 'LAK': 'Los Angeles Kings', 'MIN': 'Minnesota Wild',
    'MTL': 'Montreal Canadiens', 'NSH': 'Nashville Predators', 'NJD': 'New Jersey Devils',
    'NYI': 'New York Islanders', 'NYR': 'New York Rangers', 'OTT': 'Ottawa Senators',
    'PHI': 'Philadelphia Flyers', 'PIT': 'Pittsburgh Penguins', 'SJS': 'San Jose Sharks',
    'SEA': 'Seattle Kraken', 'STL': 'St. Louis Blues', 'TBL': 'Tampa Bay Lightning',
    'TOR': 'Toronto Maple Leafs', 'UTA': 'Utah Mammoth', 'VAN': 'Vancouver Canucks',
    'VGK': 'Vegas Golden Knights', 'WSH': 'Washington Capitals', 'WPG': 'Winnipeg Jets',
}


def _nhl_expand_title(raw_title):
    """'CAR at VGK | Condensed Game' -> 'Carolina Hurricanes at Vegas
    Golden Knights' when both 3-letter codes are recognized, else the raw
    title untouched."""
    m = re.match(r'^([A-Z]{3})\s+(at|vs)\s+([A-Z]{3})\s*\|', raw_title or '')
    if not m:
        return _clean(raw_title)
    a, joiner, b = m.group(1), m.group(2), m.group(3)
    if a in _NHL_TEAM_NAMES and b in _NHL_TEAM_NAMES:
        return '%s %s %s' % (_NHL_TEAM_NAMES[a], joiner, _NHL_TEAM_NAMES[b])
    return _clean(raw_title)


def _nhl_scrape_condensed():
    html = _get(_NHL_BASE + '/video/topic/condensed-games/')
    if not html:
        return []
    events = []
    for href, video_id, title, date_str in _RE_NHL_CARD.findall(html):
        try:
            d = datetime.datetime.strptime(date_str, '%Y-%m-%d').date()
        except Exception:
            continue
        events.append({
            'title': _nhl_expand_title(title),
            'url': _NHL_BASE + href,
            'video_id': video_id,
            'date_key': d.isoformat(),
            'date_label': d.strftime('%B %d, %Y'),
        })
    return events


def _nhl_policy_key():
    """The Brightcove player's own policy key, scraped once from NHL.com's
    own publicly-served player JS (no login/cookie/API-key of any kind
    needed to fetch it) rather than hardcoded — confirmed live this key is
    embedded as a plain string literal in that JS bundle. Cached 24h (same
    long TTL this module already uses for TMDB poster lookups) since this
    is effectively static site configuration, not per-event data."""
    ck = 'replay_nhl_policykey_v1'
    cached = _cache.get(ck)
    if cached is not None:
        return cached or None
    html = _get(_NHL_PLAYER_JS, timeout=20)
    m = _RE_NHL_POLICY_KEY.search(html) if html else None
    key = m.group(1) if m else None
    _cache.set(ck, key or False, 24 * 60 * 60)
    return key


def _nhl_resolve_video(video_id):
    """Resolve one NHL.com condensed-game Brightcove video id to a real
    playable HLS master playlist URL via Brightcove's standard Playback
    API — confirmed live end-to-end (see module comment above) against 2
    different real video ids, both genuine 200s with real #EXTM3U content
    fetched via a plain requests.get(). Returns None on any failure
    (missing policy key, video since removed/region-blocked, etc) rather
    than a broken link."""
    ck = 'replay_nhl_video_%s' % video_id
    cached = _cache.get(ck)
    if cached is not None:
        return cached or None

    pk = _nhl_policy_key()
    if not pk:
        _cache.set(ck, False, 15 * 60)
        return None

    api_url = 'https://edge.api.brightcove.com/playback/v1/accounts/%s/videos/%s' % (
        _NHL_BC_ACCOUNT, video_id)
    try:
        r = _req.get(api_url, headers={
            'Accept': 'application/json;pk=%s' % pk,
            'User-Agent': _HEADERS['User-Agent'],
        }, timeout=15)
        r.raise_for_status()
        data = r.json()
    except Exception as e:
        xbmc.log('[Starfleet/Replay] NHL.com brightcove resolve failed (%s): %s'
                 % (video_id, e), xbmc.LOGWARNING)
        _cache.set(ck, False, 15 * 60)
        return None

    hls = [s.get('src') for s in (data.get('sources') or [])
           if s.get('type') == 'application/x-mpegURL' and s.get('src', '').startswith('https')]
    url = hls[0] if hls else None
    _cache.set(ck, url or False, 15 * 60)
    return url


# ── UFC catalog (merge watchmmafull.com per-fight + fullfightreplays.com
#    per-card-section, matched by numbered PPV, e.g. "UFC 330") ────────────

_UFC_NUM_RE = re.compile(r'\bUFC\s+(\d{3,4})\b', re.I)


def _get_ufc_catalog():
    ck = 'replay_catalog_ufc_v1'
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    try:
        wmf_events = _wmf_scrape_ufc()
    except Exception as e:
        xbmc.log('[Starfleet/Replay] wmf ufc scrape: %s' % e, xbmc.LOGWARNING)
        wmf_events = []
    try:
        ffr_events = _ffr_scrape_listing(_FFR_BASE, '/ufc', pages=4)
    except Exception as e:
        xbmc.log('[Starfleet/Replay] ffr ufc scrape: %s' % e, xbmc.LOGWARNING)
        ffr_events = []

    ffr_by_num = {}
    ffr_unmatched = []
    for ev in ffr_events:
        m = _UFC_NUM_RE.search(ev['title'])
        (ffr_by_num.__setitem__(m.group(1), ev) if m else ffr_unmatched.append(ev))

    catalog = []
    matched_nums = set()
    for ev in wmf_events:
        m = _UFC_NUM_RE.search(ev['title'])
        num = m.group(1) if m else None
        merged = dict(ev)
        if num and num in ffr_by_num:
            ffr_ev = ffr_by_num[num]
            merged['title'] = ffr_ev['title']       # fuller name, e.g. includes headliners
            merged['ffr_url'] = ffr_ev['url']
            merged['thumb'] = ffr_ev.get('thumb', '')
            matched_nums.add(num)
        catalog.append(merged)

    for num, ev in ffr_by_num.items():
        if num in matched_nums:
            continue
        catalog.append({
            'sport': 'ufc', 'source': 'fullfightreplays', 'title': ev['title'],
            'date_key': ev['date_key'], 'date_label': ev['date_label'],
            'id': 'ffr_%s_%s' % (re.sub(r'\W+', '_', ev['title'].lower()).strip('_'), ev['date_key']),
            'thumb': ev.get('thumb', ''), 'fanart': '',
            'ffr_url': ev['url'], 'wmf_fights': [],
        })
    for ev in ffr_unmatched:
        catalog.append({
            'sport': 'ufc', 'source': 'fullfightreplays', 'title': ev['title'],
            'date_key': ev['date_key'], 'date_label': ev['date_label'],
            'id': 'ffr_%s_%s' % (re.sub(r'\W+', '_', ev['title'].lower()).strip('_'), ev['date_key']),
            'thumb': ev.get('thumb', ''), 'fanart': '',
            'ffr_url': ev['url'], 'wmf_fights': [],
        })

    # sport-video.org.ua (torrent-based) — kept as its own separate entries
    # rather than merged into the wmf/ffr matching above; see module
    # docstring for why (naming doesn't line up reliably with the other 2
    # sites).
    try:
        for ev in _svo_get_listing('other', 26):
            if not _SVO_UFC_RE.search(ev['title']):
                continue
            catalog.append({
                'sport': 'ufc', 'source': 'sportvideo', 'title': ev['title'],
                'date_key': ev['date_key'], 'date_label': ev['date_label'],
                'id': 'svo_%s_%s' % (re.sub(r'\W+', '_', ev['title'].lower()).strip('_'), ev['date_key']),
                'thumb': ev.get('thumb', ''), 'fanart': '',
                'wmf_fights': [], 'svo_url': ev['url'],
            })
    except Exception as e:
        xbmc.log('[Starfleet/Replay] sport-video.org.ua ufc scrape: %s' % e, xbmc.LOGWARNING)

    catalog.sort(key=lambda e: e.get('date_key') or '', reverse=True)
    _cache.set(ck, catalog, 20 * 60)
    return catalog


# ── Boxing catalog (fullfightreplays.com + box.live, kept as separate
#    entries per source rather than merged — the 2 sites' naming
#    conventions differ too much to match reliably: "Claressa Shields vs.
#    Kaye Scott" vs box.live's surname-only "Shields vs Scott" h1 — safer
#    to list both plainly labeled by source than risk a wrong merge) ───────

def _get_boxing_catalog():
    ck = 'replay_catalog_boxing_v1'
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    catalog = []
    try:
        for ev in _ffr_scrape_listing(_FFR_BASE, '/boxing', pages=4):
            catalog.append({
                'sport': 'boxing', 'source': 'fullfightreplays', 'title': ev['title'],
                'date_key': ev['date_key'], 'date_label': ev['date_label'],
                'id': 'ffr_%s_%s' % (re.sub(r'\W+', '_', ev['title'].lower()).strip('_'), ev['date_key']),
                'thumb': ev.get('thumb', ''), 'fanart': '',
                'ffr_url': ev['url'],
            })
    except Exception as e:
        xbmc.log('[Starfleet/Replay] ffr boxing scrape: %s' % e, xbmc.LOGWARNING)

    try:
        for ev in _boxlive_scrape_boxing():
            catalog.append({
                'sport': 'boxing', 'source': 'boxlive', 'title': ev['title'],
                'date_key': ev['date_key'], 'date_label': ev['date_label'],
                'id': 'bl_%s_%s' % (re.sub(r'\W+', '_', ev['title'].lower()).strip('_'), ev['date_key']),
                'thumb': ev.get('fighter1_photo', ''), 'fanart': ev.get('fighter2_photo', ''),
                'fighter1_photo': ev.get('fighter1_photo', ''),
                'fighter2_photo': ev.get('fighter2_photo', ''),
                'boxlive_url': ev['url'], 'boxlive_video': ev.get('video_url', ''),
            })
    except Exception as e:
        xbmc.log('[Starfleet/Replay] boxlive boxing scrape: %s' % e, xbmc.LOGWARNING)

    # sport-video.org.ua (torrent-based) — same /other.html archive the UFC
    # catalog above filters, re-used here via the cached wrapper so this
    # doesn't re-fetch all ~26 pages a second time within the same 20 min
    # window.
    try:
        for ev in _svo_get_listing('other', 26):
            if not _SVO_BOXING_RE.search(ev['title']):
                continue
            catalog.append({
                'sport': 'boxing', 'source': 'sportvideo', 'title': ev['title'],
                'date_key': ev['date_key'], 'date_label': ev['date_label'],
                'id': 'svo_%s_%s' % (re.sub(r'\W+', '_', ev['title'].lower()).strip('_'), ev['date_key']),
                'thumb': ev.get('thumb', ''), 'fanart': '',
                'svo_url': ev['url'],
            })
    except Exception as e:
        xbmc.log('[Starfleet/Replay] sport-video.org.ua boxing scrape: %s' % e, xbmc.LOGWARNING)

    catalog.sort(key=lambda e: e.get('date_key') or '', reverse=True)
    _cache.set(ck, catalog, 20 * 60)
    return catalog


# ── MLB catalog (mlblive.net only — homepage + current-year index merged
#    and de-duplicated by URL, since neither page alone is exhaustive and
#    homepage paginates via the real ?pageN scheme documented on
#    _ffr_scrape_listing now — the year-index page is fetched too since
#    it's not guaranteed to be a strict subset of the homepage's recent
#    slice, de-duplicated by URL either way) ──────────────────────────────

def _get_mlb_catalog():
    ck = 'replay_catalog_mlb_v1'
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    catalog = {}
    year = datetime.date.today().year
    for path, pages in (('/', 6), ('/%d-mlb-full-game-replays' % year, 2)):
        try:
            for ev in _ffr_scrape_listing(_MLBLIVE_BASE, path, pages=pages):
                catalog[ev['url']] = ev
        except Exception as e:
            xbmc.log('[Starfleet/Replay] mlblive scrape (%s): %s' % (path, e), xbmc.LOGWARNING)

    primary = []
    for ev in catalog.values():
        primary.append({
            'sport': 'mlb', 'source': 'mlblive', 'title': ev['title'],
            'date_key': ev['date_key'], 'date_label': ev['date_label'],
            'id': 'mlb_%s_%s' % (re.sub(r'\W+', '_', ev['title'].lower()).strip('_'), ev['date_key']),
            'thumb': ev.get('thumb', ''), 'fanart': '',
            'mlblive_url': ev['url'],
        })

    # sport-video.org.ua (torrent-based) — /baseball.html + its own numbered
    # pagination. Merged by (date, team pair) below rather than kept as
    # fully separate entries — same duplicate-entry bug confirmed live for
    # NFL applies here too (mlblive.net and sport-video.org.ua use different
    # title formats — "Team @ Team" vs "Team at Team" — for the same real
    # games), so an unmerged listing risks a game whose mlblive.net link is
    # dead/CDN-broken (e.g. its only source is a failing OK.ru embed) never
    # surfacing its separately-listed real sport-video.org.ua magnet.
    svo_events = []
    try:
        svo_events = list(_svo_get_listing('baseball', 9))
    except Exception as e:
        xbmc.log('[Starfleet/Replay] sport-video.org.ua mlb scrape: %s' % e, xbmc.LOGWARNING)

    result = _merge_svo_by_teams(primary, svo_events, _SVO_MLB_TEAMS, 'mlb')
    result.sort(key=lambda e: e.get('date_key') or '', reverse=True)
    _cache.set(ck, result, 20 * 60)
    return result


# ── NFL catalog (nfl-video.com — real listing, dead own-site "watch"
#    links, see the module comment above _RE_BV_ROW for the live evidence
#    — + sport-video.org.ua's /americanfootball.html, NFL-team-filtered) ──

def _get_nfl_catalog():
    ck = 'replay_catalog_nfl_v1'
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    primary = []
    try:
        for ev in _ffr_scrape_listing(_NFL_BASE, '/', pages=6):
            primary.append({
                'sport': 'nfl', 'source': 'nflvideo', 'title': ev['title'],
                'date_key': ev['date_key'], 'date_label': ev['date_label'],
                'id': 'nfl_%s_%s' % (re.sub(r'\W+', '_', ev['title'].lower()).strip('_'), ev['date_key']),
                'thumb': ev.get('thumb', ''), 'fanart': '',
                'nflvideo_url': ev['url'],
            })
    except Exception as e:
        xbmc.log('[Starfleet/Replay] nfl-video.com scrape: %s' % e, xbmc.LOGWARNING)

    svo_events = []
    try:
        # /americanfootball.html + numbered pagination — confirmed live real
        # through americanfootball13.html, americanfootball14.html 404s (max_pages
        # passed one past that). Mixed with real CFL/UFL content (see
        # _SVO_NFL_TEAMS above), filtered by team-name whitelist.
        for ev in _svo_get_listing('americanfootball', 14):
            if _SVO_NFL_TEAMS.search(ev['title']):
                svo_events.append(ev)
    except Exception as e:
        xbmc.log('[Starfleet/Replay] sport-video.org.ua nfl scrape: %s' % e, xbmc.LOGWARNING)

    # merged by (date, team pair) — see _merge_svo_by_teams docstring: without
    # this, the same real game shows up twice under nfl-video.com's "vs."
    # title format (dead native links) and sport-video.org.ua's "at" title
    # format (real magnet), as two unrelated, unlinked catalog entries.
    result = _merge_svo_by_teams(primary, svo_events, _SVO_NFL_TEAMS, 'nfl')
    result.sort(key=lambda e: e.get('date_key') or '', reverse=True)
    _cache.set(ck, result, 20 * 60)
    return result


# ── NBA catalog (basketball-video.com — real listing, real per-day
#    multi-game table sources via _bv_event_sources — + sport-video.org.ua's
#    /basketball.html, NBA-team-filtered to exclude WNBA) ──────────────────

def _get_nba_catalog():
    ck = 'replay_catalog_nba_v1'
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    primary = []
    try:
        for ev in _ffr_scrape_listing(_NBA_BASE, '/', pages=6):
            primary.append({
                'sport': 'nba', 'source': 'basketballvideo', 'title': ev['title'],
                'date_key': ev['date_key'], 'date_label': ev['date_label'],
                'id': 'nba_%s_%s' % (re.sub(r'\W+', '_', ev['title'].lower()).strip('_'), ev['date_key']),
                'thumb': ev.get('thumb', ''), 'fanart': '',
                'bv_url': ev['url'],
            })
    except Exception as e:
        xbmc.log('[Starfleet/Replay] basketball-video.com scrape: %s' % e, xbmc.LOGWARNING)

    svo_events = []
    try:
        # /basketball.html + numbered pagination — confirmed live real
        # through basketball19.html, basketball20.html 404s (max_pages
        # passed one past that). Mixed with real WNBA content (see
        # _SVO_NBA_TEAMS above), filtered by team-name whitelist.
        for ev in _svo_get_listing('basketball', 20):
            if _SVO_NBA_TEAMS.search(ev['title']):
                svo_events.append(ev)
    except Exception as e:
        xbmc.log('[Starfleet/Replay] sport-video.org.ua nba scrape: %s' % e, xbmc.LOGWARNING)

    # merged by (date, team pair) — same duplicate-entry issue confirmed for
    # NFL applies here architecturally; see _merge_svo_by_teams docstring.
    result = _merge_svo_by_teams(primary, svo_events, _SVO_NBA_TEAMS, 'nba')
    result.sort(key=lambda e: e.get('date_key') or '', reverse=True)
    _cache.set(ck, result, 20 * 60)
    return result


# ── NHL catalog (NHL.com condensed games — real, free, DRM-free, see the
#    module comment above _RE_NHL_CARD for the live evidence — +
#    sport-video.org.ua's /hockey.html, unfiltered like /baseball.html) ───

def _get_nhl_catalog():
    ck = 'replay_catalog_nhl_v1'
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    # Removed again 2026-08-22 (originally removed 2026-08-16, briefly
    # re-enabled 2026-08-21) — this round's investigation actually found
    # the real root cause instead of just the symptom, via a real kodi.log
    # captured on a genuine device:
    #   1. The content itself is completely legitimate — the master
    #      playlist, a video rendition, AND an actual .ts segment all
    #      fetch fine with a plain requests.get(), no auth needed; the
    #      segment a real ~2.9MB video/MP2T chunk. Confirmed a second time:
    #      the video rendition's own media playlist is fully spec-compliant
    #      VOD (#EXT-X-PLAYLIST-TYPE:VOD AND a proper #EXT-X-ENDLIST, 126
    #      real segments) — not a live stream by any HLS-spec definition.
    #   2. Tried routing this to Kodi's NATIVE player instead of
    #      inputstream.adaptive first — confirmed live this was WORSE:
    #      Kodi's bare ffmpeg HLS demuxer opened only ONE stream (the
    #      manifest's first #EXT-X-MEDIA entry, which happens to be the
    #      AUDIO group — Brightcove lists it before any video variant) and
    #      never touched a video stream at all ("Opening stream: 0 source:
    #      256" then "CDVDMessageQueue(video)::Put MSGQ_NOT_INITIALIZED").
    #   3. Reverted back to forcing inputstream.adaptive (confirmed via a
    #      log line that the property really was being set this time) —
    #      genuinely different, more informative failure: ISA's own parser
    #      DID find both streams ("Streams in first period: 2") but then
    #      misclassified the whole manifest as "Type: live" despite it
    #      being provably spec-compliant VOD per point 1 above, and failed
    #      to extract H.264 extradata under that live-path handling
    #      ("CVideoPlayerVideo::OpenStream: Codec id 27 require extradata"),
    #      disabling the video stream and hitting EOF almost immediately.
    # So both of Kodi's playback paths fail on this exact manifest shape
    # (a separate #EXT-X-MEDIA AUDIO group per bitrate tier, rather than
    # one shared group every STREAM-INF variant points at) for two
    # different internal reasons — while VLC's own separate demuxer plays
    # the identical URL correctly. This is a real bug/limitation inside
    # Kodi's bundled inputstream.adaptive binary (and its native ffmpeg
    # HLS demuxer) for this specific manifest shape, not something
    # resolvable from this addon's own Python code — no ListItem property
    # or URL change controls ISA's internal live/vod classification or its
    # extradata extraction path. _nhl_scrape_condensed()/_nhl_resolve_
    # video() are left in place, unreferenced, in case a future Kodi/ISA
    # release fixes this manifest shape.
    primary = []

    svo_events = []
    try:
        # /hockey.html + numbered pagination — confirmed live real through
        # hockey11.html (11 numbered pages + the base page), hockey12.html
        # 404s (max_pages passed one past that, same "expected/harmless"
        # convention _svo_scrape_listing's own docstring already documents
        # for /baseball.html and /other.html). Unlike /other.html this page
        # only ever returned real NHL content in a live check (no other-
        # league contamination seen), so it's used unfiltered.
        svo_events = list(_svo_get_listing('hockey', 12))
    except Exception as e:
        xbmc.log('[Starfleet/Replay] sport-video.org.ua nhl scrape: %s' % e, xbmc.LOGWARNING)
    result = _merge_svo_by_teams(primary, svo_events, _SVO_NHL_TEAMS, 'nhl')
    result.sort(key=lambda e: e.get('date_key') or '', reverse=True)
    _cache.set(ck, result, 20 * 60)
    return result


_CATALOG_FUNCS = {
    'ufc':    _get_ufc_catalog,
    'boxing': _get_boxing_catalog,
    'mlb':    _get_mlb_catalog,
    'nfl':    _get_nfl_catalog,
    'nba':    _get_nba_catalog,
    'nhl':    _get_nhl_catalog,
}


# ── Public API ────────────────────────────────────────────────────────────

def get_replay_dates(sport):
    """Real dates (most recent first) that have at least one replay event
    for `sport` ('ufc' / 'boxing' / 'mlb'), across every source confirmed
    live for that sport (see module docstring)."""
    fn = _CATALOG_FUNCS.get(sport)
    if not fn:
        return []
    try:
        catalog = fn()
    except Exception as e:
        xbmc.log('[Starfleet/Replay] get_replay_dates(%s): %s' % (sport, e), xbmc.LOGWARNING)
        return []

    xbmc.log('[Starfleet/Replay] get_replay_dates(%s): catalog has %d events'
              % (sport, len(catalog)), xbmc.LOGINFO)

    seen = {}
    for ev in catalog:
        dk = ev.get('date_key')
        if dk and dk not in seen:
            seen[dk] = ev.get('date_label', dk)
    return [{'date_key': dk, 'label': seen[dk]} for dk in sorted(seen, reverse=True)]


def get_replay_events(sport, date_key):
    """Events for `sport` on `date_key` ('YYYY-MM-DD'), most-recently-added
    source first. Each dict carries everything get_replay_sources() needs
    — pass it straight through, no separate lookup required."""
    fn = _CATALOG_FUNCS.get(sport)
    if not fn:
        return []
    try:
        catalog = fn()
    except Exception as e:
        xbmc.log('[Starfleet/Replay] get_replay_events(%s, %s): %s' % (sport, date_key, e), xbmc.LOGWARNING)
        return []
    return [ev for ev in catalog if ev.get('date_key') == date_key]


_RE_TORRENT_QUERY_STRIP = re.compile(
    r'\s*-\s*Full Fight Replays?\s*-\s*[A-Za-z]+\.?\s*\d{1,2},?\s*\d{4}(?:\s+\w+)?\s*$', re.I)


def _torrent_search_title(title):
    """Clean an event['title'] down to a real search query for
    torrent_sources.search_all(). fullfightreplays.com's own titles
    (which flow straight into event['title'] for merged/unmatched UFC and
    Boxing catalog entries — see _get_ufc_catalog/_get_boxing_catalog)
    carry a real trailing "- Full Fight Replay(s) - <Month D, YYYY>
    [Boxing]" suffix that's literally that SITE's own page-title text, not
    anything added by this module. Confirmed live this measurably breaks
    the generic search: the raw stored title for UFC 330 returns 0 results
    from search_all(), while the same query stripped down to "UFC 330:
    Makhachev vs. Machado Garry" returns 10 real ones — most of the 44
    wired-in sources do a fairly literal site-search, not a fuzzy one, so
    a `date`/`Full Fight Replay(s)` tail poisons the query for all of
    them at once. No-op (returns the title unchanged) for every other
    source in this module (watchmmafull.com, box.live, mlblive.net,
    sport-video.org.ua) since none of them carry this suffix."""
    cleaned = _RE_TORRENT_QUERY_STRIP.sub('', title or '').strip()
    return cleaned or title


def get_replay_sources(sport, event):
    """Every real playable option for `event` (as returned by
    get_replay_events), individual-fight AND full-card/section entries
    both included whenever the underlying site(s) offer both — never
    picking just one. Entries with a broken/unresolvable underlying embed
    are silently skipped rather than returned as a dead link."""
    sources = []
    try:
        if sport == 'ufc':
            for fight in event.get('wmf_fights') or []:
                url = _wmf_resolve_fight(fight['url'])
                if url:
                    sources.append({'label': fight['label'], 'url': url})
            ffr_url = event.get('ffr_url')
            if ffr_url:
                sources.extend(_ffr_event_sources(ffr_url))
            svo_url = event.get('svo_url')
            if svo_url:
                magnet = _svo_resolve_magnet(svo_url, event.get('title', ''))
                if magnet:
                    sources.append({'label': 'sport-video.org.ua (Torrent)',
                                     'url': magnet, 'magnet': magnet})

        elif sport == 'boxing':
            ffr_url = event.get('ffr_url')
            if ffr_url:
                sources.extend(_ffr_event_sources(ffr_url))
            bl_url = event.get('boxlive_url')
            if bl_url:
                video = event.get('boxlive_video', '')
                if not video:
                    # Event dict may predate a video being uploaded, or came
                    # from a cached catalog — re-check live rather than
                    # trusting a stale 'no replay yet' from catalog-build time.
                    detail = _boxlive_fight_detail(bl_url)
                    video = detail.get('video_url', '') if detail else ''
                if video:
                    sources.append({'label': 'Full Fight (Official YouTube)', 'url': video})
            svo_url = event.get('svo_url')
            if svo_url:
                magnet = _svo_resolve_magnet(svo_url, event.get('title', ''))
                if magnet:
                    sources.append({'label': 'sport-video.org.ua (Torrent)',
                                     'url': magnet, 'magnet': magnet})

        elif sport == 'mlb':
            mlb_url = event.get('mlblive_url')
            if mlb_url:
                sources.extend(_ffr_event_sources(mlb_url))
            svo_url = event.get('svo_url')
            if svo_url:
                magnet = _svo_resolve_magnet(svo_url, event.get('title', ''))
                if magnet:
                    sources.append({'label': 'sport-video.org.ua (Torrent)',
                                     'url': magnet, 'magnet': magnet})

        elif sport == 'nfl':
            # nfl-video.com's own "watch" links are confirmed dead (see
            # _FFR_DEAD_HOSTS above) — _ffr_event_sources already filters
            # them out, so this correctly contributes nothing rather than
            # a guaranteed-broken button when that's all this site has.
            nflvideo_url = event.get('nflvideo_url')
            if nflvideo_url:
                sources.extend(_ffr_event_sources(nflvideo_url))
            svo_url = event.get('svo_url')
            if svo_url:
                magnet = _svo_resolve_magnet(svo_url, event.get('title', ''))
                if magnet:
                    sources.append({'label': 'sport-video.org.ua (Torrent)',
                                     'url': magnet, 'magnet': magnet})

        elif sport == 'nba':
            bv_url = event.get('bv_url')
            if bv_url:
                sources.extend(_bv_event_sources(bv_url))
            svo_url = event.get('svo_url')
            if svo_url:
                magnet = _svo_resolve_magnet(svo_url, event.get('title', ''))
                if magnet:
                    sources.append({'label': 'sport-video.org.ua (Torrent)',
                                     'url': magnet, 'magnet': magnet})

        elif sport == 'nhl':
            # NHL.com condensed-game (Brightcove) source removed again
            # 2026-08-22 — see _get_nhl_catalog's own comment for the full,
            # now root-caused story: a real bug/limitation inside Kodi's
            # bundled inputstream.adaptive (misclassifies this manifest
            # shape as live, then fails H.264 extradata extraction) and its
            # native ffmpeg HLS demuxer (opens only the manifest's first-
            # listed stream, which is the audio group) — not this
            # resolver or the content, which is confirmed genuinely valid,
            # spec-compliant VOD. _nhl_resolve_video()/_nhl_scrape_
            # condensed() left in place, unreferenced, in case a future
            # Kodi/ISA release handles this manifest shape correctly.
            svo_url = event.get('svo_url')
            if svo_url:
                magnet = _svo_resolve_magnet(svo_url, event.get('title', ''))
                if magnet:
                    sources.append({'label': 'sport-video.org.ua (Torrent)',
                                     'url': magnet, 'magnet': magnet})

        # Generic multi-site torrent search (torrent_sources.search_all —
        # the same 44-source engine Movies/TV/Adult already use) matched
        # purely on the event's own title text: no imdb_id/year is passed
        # since replay event titles ("UFC 330", "Errol Spence Jr. vs. Tim
        # Tszyu") aren't conventional movie titles, just a plain
        # title-text search the same way search_knaben/search_1337x
        # already support when only given a title. Wired in unconditionally
        # for all 3 sports (see module docstring for the live-verified,
        # per-sport results) — MLB team-vs-team titles are confirmed a
        # poor match (0 real results across several real titles tried
        # live), but this is left wired in rather than special-cased off
        # since it's a harmless no-op exactly like every other empty-result
        # case in this module, and a big enough MLB game could still hit.
        # Each match is labeled distinctly ('<source> [quality, N seeds]')
        # and carries a 'magnet' key (== 'url') so it's obvious in the
        # picker and to the caller that this routes through the addon's
        # debrid resolver — see sports_router.py's _play_stream magnet:
        # branch — instead of ResolveURL/embed resolution like every
        # source above.
        title = event.get('title', '')
        if title:
            try:
                from resources.lib import torrent_sources as _ts
                query = _torrent_search_title(title)
                for t in _ts.search_all(query, media_type='movie', max_per_source=5):
                    magnet = t.get('magnet', '')
                    if not magnet:
                        continue
                    label = '%s [%s, %s seeds]' % (
                        t.get('source', 'Torrent'), t.get('quality') or '?', t.get('seeds', 0))
                    sources.append({'label': label, 'url': magnet, 'magnet': magnet})
            except Exception as e:
                xbmc.log('[Starfleet/Replay] torrent_sources search_all(%r): %s'
                         % (title, e), xbmc.LOGWARNING)

    except Exception as e:
        xbmc.log('[Starfleet/Replay] get_replay_sources(%s, %r): %s'
                 % (sport, event.get('title', ''), e), xbmc.LOGWARNING)

    return sources


# ── TMDB poster lookup (icon feasibility — see module docstring) ──────────

def get_replay_poster(title):
    """UFC/Boxing event poster via TMDB, wrapping metadata.py's own
    search_movies() (same TMDB_KEYS, same 24h cache) rather than
    duplicating key rotation here — confirmed live this reliably finds
    both UFC PPVs/Fight Nights and named boxing matchups (see module
    docstring for real examples). Returns {} for MLB games (confirmed
    live these are never on TMDB) or on any lookup failure — callers
    should fall back to the site-native thumbnail/fanart already present
    on the event dict, or a generic sport logo, when this is empty."""
    if not title:
        return {}
    try:
        from resources.lib import metadata as _meta
        results = _meta.search_movies(title)
        if results:
            m = results[0]
            return {'thumb': m.get('thumb', ''), 'fanart': m.get('fanart', '')}
    except Exception as e:
        xbmc.log('[Starfleet/Replay] get_replay_poster(%r): %s' % (title, e), xbmc.LOGWARNING)
    return {}
