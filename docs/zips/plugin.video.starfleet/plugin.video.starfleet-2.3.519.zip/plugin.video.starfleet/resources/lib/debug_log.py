# -*- coding: utf-8 -*-
"""
resources/lib/debug_log.py

"Send Debug Log" — Settings > General button. Built 2026-08-16 after ADB
access to a Firestick's own kodi.log turned out to be blocked (confirmed
live: both a direct `adb pull` and `adb shell run-as` failed with
Permission denied / package not debuggable — Android's scoped storage on
that device won't let an external ADB shell read another app's private
files, and the device isn't rooted). The same restriction is already
documented in dispatcher.py's own clear_cache action for the exact same
reason (can't clear another app's cache file over ADB either).

The one place that ISN'T restricted is the running Kodi process itself —
it already has full read access to its own log via special://logpath/,
since that's a normal in-app file read, not cross-app ADB access. So
instead of trying to get a file OFF the device, this reads the log from
inside the app and uploads it, leaving the user with just a short URL to
read off their screen and paste wherever they're asking for help.

Redaction: kodi.log can contain this addon's own outbound request logging,
which in turn can carry real debrid/premium-service credentials (Real-
Debrid/AllDebrid/Premiumize/TorBox API keys, MDBList/Trakt/SIMKL tokens,
Easynews login) in query strings or Authorization headers. Uploading that
verbatim to a public, unauthenticated paste service would hand out live
credentials to anyone who finds the link — so every known credential
pattern is stripped before anything leaves the device, not after.

Paste service: tries 0x0.st, then termbin.com, then gives up on uploading
and just saves the redacted log to a local file instead — built as a real
fallback chain, not a single point of failure, after watching 3 different
free paste services die in a row on the exact same day this was built:
paste.rs (the original choice) failed plain DNS resolution on a real
device's first use; its replacement, 0x0.st, then returned a genuine 503
on the very next real use; and dpaste.org (considered as 0x0.st's own
backup) turned out to have already shut down its public service after a
security incident. None of that was this addon's own code being wrong —
free anonymous paste hosts are just not reliable enough to trust as a
single dependency, so this no longer bets on any one of them working.
termbin.com is a much older, simpler service (raw TCP on port 9999, no
HTTP stack involved at all) chosen specifically because it doesn't share
whatever's currently wrong with the HTTP-based ones. If every upload
attempt fails, the redacted log is still saved locally (special://profile)
and that path is shown instead — the feature can no longer end in "it
tried and failed with nothing to show for it."
"""

import re
import time
import socket
import xbmc
import xbmcvfs
import requests as _req

_HEADERS = {'User-Agent': 'Mozilla/5.0'}

# Matches the VALUE half of key=value pairs for every credential-shaped
# field name this addon's own settings.xml stores (Real-Debrid/AllDebrid/
# Premiumize/TorBox/MDBList/Trakt/SIMKL/Easynews) plus generic
# token/secret/password/signature names any future source might log.
_RE_REDACT_KV = re.compile(
    r'((?:api[_-]?key|apikey|token|access_token|refresh_token|auth_token|'
    r'client_secret|client_id|secret|password|passwd|pass|sig|signature|'
    r'session|sessionid|cookie)=)[^&\s"\'<>]+',
    re.IGNORECASE)
_RE_REDACT_HEADER = re.compile(r'(Authorization:\s*).*', re.IGNORECASE)
_RE_REDACT_BEARER = re.compile(r'\bBearer\s+[A-Za-z0-9._\-]+', re.IGNORECASE)

# Keep the upload focused and bounded — a debug-logging session can grow
# to many MB, and the interesting part for a fresh bug report is always
# whatever just happened, not the whole session history.
_MAX_BYTES = 800 * 1024


def _redact(text):
    text = _RE_REDACT_KV.sub(r'\1REDACTED', text)
    text = _RE_REDACT_HEADER.sub(r'\1REDACTED', text)
    text = _RE_REDACT_BEARER.sub('Bearer REDACTED', text)
    return text


def _read_recent_log():
    path = xbmcvfs.translatePath('special://logpath/kodi.log')
    try:
        f = xbmcvfs.File(path)
        size = f.size()
        if size > _MAX_BYTES:
            f.seek(size - _MAX_BYTES, 0)
        data = f.readBytes() if size > _MAX_BYTES else f.readBytes()
        f.close()
        text = bytes(data).decode('utf-8', 'ignore')
        if size > _MAX_BYTES:
            # Drop a possibly-truncated first line from the seek point.
            text = text.split('\n', 1)[-1]
        return text
    except Exception as e:
        xbmc.log('[Starfleet/DebugLog] read failed: %s' % e, xbmc.LOGERROR)
        return None


def _try_0x0st(data):
    try:
        files = {'file': ('kodi.log', data, 'text/plain')}
        r = _req.post('https://0x0.st', files=files, headers=_HEADERS, timeout=25)
        r.raise_for_status()
        url = r.text.strip()
        if url.startswith('http'):
            return url
        xbmc.log('[Starfleet/DebugLog] unexpected 0x0.st response: %s' % url[:200],
                  xbmc.LOGWARNING)
    except Exception as e:
        xbmc.log('[Starfleet/DebugLog] 0x0.st failed: %s' % e, xbmc.LOGWARNING)
    return None


def _try_termbin(data):
    try:
        s = socket.create_connection(('termbin.com', 9999), timeout=15)
        try:
            s.sendall(data)
            s.shutdown(socket.SHUT_WR)
            chunks = []
            while True:
                chunk = s.recv(4096)
                if not chunk:
                    break
                chunks.append(chunk)
        finally:
            s.close()
        url = b''.join(chunks).decode('utf-8', 'ignore').strip().strip('\x00')
        if url.startswith('http'):
            return url
        xbmc.log('[Starfleet/DebugLog] unexpected termbin response: %s' % url[:200],
                  xbmc.LOGWARNING)
    except Exception as e:
        xbmc.log('[Starfleet/DebugLog] termbin failed: %s' % e, xbmc.LOGWARNING)
    return None


def _save_local(text):
    try:
        ts = time.strftime('%Y%m%d_%H%M%S')
        path = xbmcvfs.translatePath('special://profile/debug_log_%s.txt' % ts)
        f = xbmcvfs.File(path, 'w')
        f.write(text)
        f.close()
        return path
    except Exception as e:
        xbmc.log('[Starfleet/DebugLog] local save failed: %s' % e, xbmc.LOGERROR)
        return None


def upload_debug_log():
    """Read this device's own kodi.log, redact known credential patterns,
    try each paste service in turn, and fall back to a local file save if
    every upload fails. Always returns a string describing where the log
    ended up (a URL, or a local path with an explanation) — or None only
    if the log itself couldn't even be read."""
    raw = _read_recent_log()
    if not raw:
        return None
    redacted = _redact(raw)
    data = redacted.encode('utf-8', 'ignore')

    url = _try_0x0st(data)
    if url:
        xbmc.log('[Starfleet/DebugLog] uploaded via 0x0.st: %s' % url, xbmc.LOGINFO)
        return url

    url = _try_termbin(data)
    if url:
        xbmc.log('[Starfleet/DebugLog] uploaded via termbin: %s' % url, xbmc.LOGINFO)
        return url

    path = _save_local(redacted)
    if path:
        xbmc.log('[Starfleet/DebugLog] all uploads failed, saved locally: %s' % path,
                  xbmc.LOGWARNING)
        return 'Upload services unavailable — saved locally instead:\n%s' % path

    return None
