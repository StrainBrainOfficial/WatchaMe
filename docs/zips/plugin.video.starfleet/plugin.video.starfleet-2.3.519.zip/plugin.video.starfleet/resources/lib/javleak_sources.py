# -*- coding: utf-8 -*-
"""
resources/lib/javleak_sources.py — third JAV source (javleak.com), same
shape as javseen_sources.py/javhd_sources.py so home.py's _JAV_SOURCES
dict and _render_jav_category can stay source-agnostic.

Confirmed live (page source fetched directly, not via a browser DOM — a
plain requests.get() sees exactly this):
  - It's a WordPress/Yoast-SEO site. sitemap.xml is an index of 26+
    post-sitemap<N>.xml files; the highest-numbered one is the actively-
    growing "current" sitemap (older ones are frozen at a fixed historical
    date). URLs within it are plain slugs (no numeric id in the path,
    unlike javseen/javhd) — the slug itself IS both id and slug here.
  - Detail pages embed the actual third-party player iframes DIRECTLY in
    the page HTML (confirmed two: e.g. abyssplayer.com/<id>, and a second
    "Player 2" host like hgcloud.to/e/<id>) — no extra myserver-style hop
    to walk first, unlike javseen. Both are hosts this addon's existing
    resolvers.py chain already knows how to resolve.
  - Real cover art comes straight from DMM's own CDN
    (pics.dmm.co.jp/mono/movie/adult/<code>/<code>ps.jpg for the poster,
    <code>pl.jpg for a larger version) — there are two <meta property=
    "og:image"> tags on these pages and the FIRST one is empty, so this
    matches the pics.dmm.co.jp URL directly instead of trusting og:image
    tag order.
"""
import re
import xbmc
import xbmcaddon
import xbmcvfs

ADDON    = xbmcaddon.Addon('plugin.video.starfleet')
_PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))

from resources.lib import cache as _cache
_cache.init(_PROFILE + '/cache.db')

JAVLEAK_BASE = 'https://javleak.com'

_HEADERS = {
    'User-Agent': ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
                   '(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'),
    'Accept-Language': 'en-US,en;q=0.9',
}

PAGE_SIZE = 30
_SITEMAP_INDEX_URL = JAVLEAK_BASE + '/sitemap.xml'
_LATEST_CACHE_KEY   = 'javleak_latest_all'
_LATEST_CACHE_TTL   = 6 * 3600  # sitemap only updates as new posts are published

_RE_SITEMAP_NUM   = re.compile(r'<loc>https?://javleak\.com/post-sitemap(\d+)\.xml</loc>', re.IGNORECASE)
_RE_SITEMAP_ITEM  = re.compile(r'<loc>(https://javleak\.com/[a-z0-9\-]+/)</loc>', re.IGNORECASE)
_RE_IFRAME_SRC    = re.compile(r'<iframe[^>]+src="([^"]+)"', re.IGNORECASE)
_RE_OG_DESC       = re.compile(r'<meta[^>]+property="og:description"[^>]+content="([^"]+)"', re.IGNORECASE)
_RE_DMM_IMAGE     = re.compile(r'https://pics\.dmm\.co\.jp/mono/movie/adult/[a-z0-9_]+/[a-z0-9_]+p[sl]\.jpg', re.IGNORECASE)


def _get(url, referer='', timeout=15):
    import requests
    headers = dict(_HEADERS)
    if referer:
        headers['Referer'] = referer
    try:
        r = requests.get(url, headers=headers, timeout=timeout)
        if r.status_code == 200:
            return r.text
    except Exception as e:
        xbmc.log('[Starfleet/JavLeak] fetch error %s: %s' % (url[:80], e), xbmc.LOGWARNING)
    return ''


def _slug_title(slug):
    return re.sub(r'\s+', ' ', slug.replace('-', ' ')).strip().title()


def _detail_url(slug):
    return '%s/%s/' % (JAVLEAK_BASE, slug)


# ── "New / Latest" browsing (sitemap-based, no JS needed) ────────────────────

def _newest_post_sitemap_url():
    """Find the highest-numbered post-sitemap<N>.xml in the index — that's
    the one actively being appended to as new posts publish. Hardcoding a
    number would eventually go stale once the site rolls to the next file;
    this stays correct as the site grows. Falls back to the unnumbered
    post-sitemap.xml if the index can't be parsed for any reason."""
    xml_text = _get(_SITEMAP_INDEX_URL)
    nums = [int(n) for n in _RE_SITEMAP_NUM.findall(xml_text)] if xml_text else []
    if nums:
        return '%s/post-sitemap%d.xml' % (JAVLEAK_BASE, max(nums))
    return '%s/post-sitemap.xml' % JAVLEAK_BASE


def _load_latest_all():
    """Parsed newest post-sitemap file, newest-first. Confirmed live this
    file's own <loc> entries are in ASCENDING publish-date order (oldest
    first) — the opposite of javseen's combined sitemap — so the parsed
    list is reversed here to show newest first. Title/id/slug are all
    derived from the URL alone (no per-item detail fetch), same lazy-detail
    pattern as javseen_sources.py; there's no numeric video id on this
    site, so the slug itself doubles as the id."""
    cached = _cache.get(_LATEST_CACHE_KEY)
    if cached is not None:
        return cached or []
    sitemap_url = _newest_post_sitemap_url()
    xml_text = _get(sitemap_url)
    items = []
    if xml_text:
        for m in _RE_SITEMAP_ITEM.finditer(xml_text):
            url = m.group(1)
            slug = url.rstrip('/').rsplit('/', 1)[-1]
            items.append({'id': slug, 'slug': slug, 'title': _slug_title(slug), 'source': 'javleak'})
        items.reverse()
    _cache.set(_LATEST_CACHE_KEY, items or False, _LATEST_CACHE_TTL)
    xbmc.log('[Starfleet/JavLeak] %s parsed: %d items' % (sitemap_url, len(items)), xbmc.LOGINFO)
    return items


def _populate_artwork(items):
    """Concurrently fetch each item's own detail page for its real cover
    art + description before the grid ever opens. The sitemap this module's
    listing is built from carries no images at all (just <loc> URLs), so
    without this every item showed a blank thumbnail in the grid itself --
    CategoryListWindow's onInit() only ever reads an item's 'thumb' key for
    the actual list icon, and this module never set one; the existing lazy
    per-focus detail_fetch only ever populated the side panel's window
    properties, not the ListItem's own art. Runs once per page load, in
    parallel, not for the whole multi-hundred-item sitemap up front."""
    if not items:
        return
    from concurrent.futures import ThreadPoolExecutor

    def _fetch(item):
        try:
            detail = get_javleak_detail(item['id'], item['slug'])
            if detail.get('fanart'):
                item['thumb']  = detail['fanart']
                item['fanart'] = detail['fanart']
            if detail.get('description'):
                item['plot'] = detail['description']
        except Exception:
            pass

    with ThreadPoolExecutor(max_workers=min(15, len(items))) as pool:
        list(pool.map(_fetch, items))


def browse_javleak_latest(page=1):
    """'New / Latest' listing, locally paginated from the cached sitemap."""
    items = _load_latest_all()
    start = (page - 1) * PAGE_SIZE
    page_items = items[start:start + PAGE_SIZE]
    _populate_artwork(page_items)
    return page_items


def get_javleak_detail(vid, slug):
    """Lazily fetch a video's real thumbnail/description from its detail
    page — called on-demand (e.g. when the custom-skin list's focus lands
    on an item), not for every item up front. vid is unused here (this
    site has no separate numeric id, slug alone builds the URL) but kept
    in the signature so home.py's source-agnostic _render_jav_category can
    call every JAV source's detail_fn the same way."""
    html = _get(_detail_url(slug))
    if not html:
        return {}
    out = {}
    m = _RE_DMM_IMAGE.search(html)
    if m:
        out['fanart'] = m.group(0)
    m = _RE_OG_DESC.search(html)
    if m:
        import html as _html_lib
        out['description'] = _html_lib.unescape(m.group(1))
    return out


# ── Play-time resolution ──────────────────────────────────────────────────────

def _candidate_embed_urls(vid, slug):
    """Unlike javseen (detail page -> its own /embed/ page -> a
    myserver.javseen.tv play page -> the real host list), javleak embeds
    the actual third-party player iframes DIRECTLY on the detail page —
    confirmed live: two <iframe src="..."> tags in the raw page HTML
    itself (e.g. abyssplayer.com/<id> and a second "Player 2" host), no
    extra hop needed. Returns them in the order the page presents them."""
    html = _get(_detail_url(slug))
    if not html:
        return []
    return list(dict.fromkeys(_RE_IFRAME_SRC.findall(html)))


def resolve_javleak_stream(vid, slug):
    """Try each candidate third-party embed host in turn. mycloudz.cc/
    cloudwish.xyz (and any other mirror of the same "VidHide" player
    template) get a direct plain-HTTP bypass first — see
    vidhide_bypass.py's own docstring, added 2026-08-04. Everything else
    still goes through this addon's own resolvers.py chain (Real-Debrid/
    AllDebrid/Premiumize/TorBox, then ResolveURL) until one resolves to a
    real playable URL. Returns '' if none do."""
    candidates = _candidate_embed_urls(vid, slug)
    if not candidates:
        return ''

    from resources.lib import vidhide_bypass
    from resources.lib import resolvers as _resolvers
    for url in candidates:
        direct = vidhide_bypass.try_resolve(url)
        if direct:
            xbmc.log('[Starfleet/JavLeak] resolved via VidHide bypass %s' % url[:60], xbmc.LOGINFO)
            return direct
        try:
            resolved = _resolvers.resolve(url)
        except Exception as e:
            xbmc.log('[Starfleet/JavLeak] resolver error for %s: %s' % (url, e), xbmc.LOGWARNING)
            continue
        if resolved and resolved != url:
            xbmc.log('[Starfleet/JavLeak] resolved via %s' % url[:60], xbmc.LOGINFO)
            return resolved
    xbmc.log('[Starfleet/JavLeak] no candidate resolved (%d tried)' % len(candidates), xbmc.LOGWARNING)
    return ''
