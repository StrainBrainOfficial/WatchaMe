# -*- coding: utf-8 -*-
"""
resources/lib/nzb_sources.py — Usenet/NZB search.

binsearch.info is a free, public Usenet search engine that needs no
account/API key — confirmed live 2026-08-06: a plain GET returns real,
server-rendered results (title, size, file count, age), and each result's
opaque per-post id can be turned into a real, valid downloadable .nzb file
via a second plain GET, no login/session required at all.

NZBGeek and NZBPlanet are the opposite of Binsearch: real, paid, account-
gated indexers, but both speak the standard Newznab API (the same
Sonarr/Radarr/NZBHydra etc. all use) — confirmed live 2026-08-06, an
invalid API key against each got back a real, correctly-formatted Newznab
`<error code="101" .../>` response, confirming the endpoints and query
shape are right without needing a real account to verify. A valid user's
own API key turns this into a clean, structured XML search with a
ready-to-fetch NZB download URL already baked into each item's own <link>
— no HTML scraping, no CSRF, no junk-file filtering needed the way
Binsearch's raw post-search requires, since Newznab indexers already do
their own release grouping server-side.

Deliberately NOT wired into torrent_sources.search_all() — an NZB result
isn't a magnet: URI and has no info_hash, so it doesn't fit that pipeline's
shape, and more importantly it's only ever useful if Premiumize or TorBox
(the only two debrid services here with real NZB-caching support — Real-
Debrid and AllDebrid have none at all, confirmed live) are actually
enabled. debrid_torrent.py's search_nzb_streams() is the real gate for
that; this module is pure search, no debrid-awareness at all.
"""
import re
import xbmc
import xbmcaddon

ADDON = xbmcaddon.Addon('plugin.video.starfleet')

_HEADERS = {
    'User-Agent': ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
                   '(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'),
}

BINSEARCH_BASE = 'https://binsearch.info'

# One result row's full markup, from its "N." index cell through to the Age
# cell — confirmed live against real search output 2026-08-06. The
# checkbox's own `name` attribute is the opaque per-post id binsearch's own
# /nzb?q=<query>&<id>=on GET uses to build a real downloadable .nzb for
# just that one post (no other params needed).
_RE_ROW = re.compile(
    r'name="([^"]+)"/></td><td><div class="flex flex-col">'
    r'<a[^>]+href="/details/[^"]+">([^<]+)</a>'
    r'.*?<span[^>]*>([\d.]+\s*[KMGT]?i?B)</span>'
    r'.*?<td class="min-w-20">([^<]+)</td>',
    re.IGNORECASE | re.DOTALL
)

# A raw title search surfaces every post matching the query as its own
# row -- for a modern release that's mostly PAR2 recovery blocks, NFOs,
# and sample files scattered around the one post that's actually the real
# content (confirmed live: querying "The Agency" put five PAR2-block rows
# ahead of anything else, and NONE of the top 50 results for that query
# were a directly-quoted video filename at all — most real releases post
# as an .rar-compressed archive, e.g. "{Title.2160p.WEB-DL.H.265-x.rar}
# {id} yEnc", not a bare quoted .mkv). Premiumize/TorBox both unpack RAR
# archives server-side the same way they do for torrents, so a .rar post
# is just as usable as a direct video one — requiring a quoted video
# extension (tried first) rejected every real release for some queries.
# An EXCLUDE-based filter is more robust here: reject the specific
# extensions that are NEVER the actual content (recovery blocks, index/
# checksum files, cover art, text notes), and let everything else
# (.rar/.mkv/.mp4/.zip/etc.) through.
_RE_JUNK_FILE = re.compile(
    r'\.(?:par2|nfo|sfv|srr|jpg|jpeg|png|gif|txt|url|db|diz)["”}]',
    re.IGNORECASE
)

# Same junk-extension exclusion list as _RE_JUNK_FILE above, but for titles
# that have already had their surrounding quote characters stripped during
# extraction (NZBIndex's RSS <title> text, NZBKing's unquoted filename
# capture) — _RE_JUNK_FILE's trailing `["”}]` requirement never matches
# those (confirmed live: "The Matrix (1999).par2" and "Summer.of.Sam.1999.
# 720p.nfo" both slipped through _RE_JUNK_FILE untouched), so this variant
# matches the extension at a real word boundary/end-of-string instead.
_RE_JUNK_EXT = re.compile(
    r'\.(?:par2|nfo|sfv|srr|jpg|jpeg|png|gif|txt|url|db|diz)(?:[^a-z0-9]|$)',
    re.IGNORECASE
)


def _get(url, timeout=12):
    try:
        import requests
        r = requests.get(url, headers=_HEADERS, timeout=timeout)
        if r.status_code == 200:
            return r.text
    except Exception as e:
        xbmc.log('[Starfleet/NZB] fetch error %s: %s' % (url[:80], e), xbmc.LOGWARNING)
    return ''


def search_binsearch_nzb(title, year=None, limit=10, media_type='movie'):
    """Search binsearch.info by title. Returns
    [{'title':..., 'size':..., 'age':..., 'nzb_url':..., 'source': 'Binsearch'}]
    — nzb_url is a direct, ready-to-fetch .nzb download link, not a search
    result page; no further hop needed to get a real NZB for it."""
    try:
        from urllib.parse import quote as _q
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        url = '%s/?q=%s&max=100' % (BINSEARCH_BASE, _q(query))
        html = _get(url)
        if not html:
            return []

        import html as _html_lib
        results = []
        for m in _RE_ROW.finditer(html):
            if len(results) >= limit:
                break
            post_id, raw_title, size, age = m.groups()
            name = _html_lib.unescape(raw_title).strip()
            if not name or _RE_JUNK_FILE.search(name):
                continue
            name = name.strip('"')
            nzb_url = '%s/nzb?q=%s&%s=on' % (BINSEARCH_BASE, _q(query), post_id)
            results.append({
                'title':   name,
                'size':    size.strip(),
                'age':     age.strip(),
                'nzb_url': nzb_url,
                'source':  'Binsearch',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/NZB] Binsearch search error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Newznab-API indexers (NZBGeek, NZBPlanet) — need the user's own key ──────

def _newznab_search(base_url, api_key, source_name, title, year=None, limit=10, media_type='movie'):
    """Generic Newznab `t=search` query — shared by every Newznab-compatible
    indexer (NZBGeek, NZBPlanet, and any other one added later), since the
    API shape itself is identical across all of them; only base_url/api_key
    differ per site."""
    if not api_key:
        return []
    try:
        from urllib.parse import quote as _q
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        url = '%s?t=search&q=%s&apikey=%s&extended=1&limit=%d' % (
            base_url, _q(query), _q(api_key), max(limit, 20))
        xml_text = _get(url, timeout=15)
        if not xml_text:
            return []

        import xml.etree.ElementTree as ET
        try:
            root = ET.fromstring(xml_text)
        except ET.ParseError:
            return []

        # A Newznab error response is a bare <error .../> root, not <rss>
        if root.tag == 'error':
            xbmc.log('[Starfleet/NZB] %s error: %s' % (source_name, root.get('description', '')),
                     xbmc.LOGWARNING)
            return []

        ns = {'newznab': 'http://www.newznab.com/DTD/2010/feeds/attributes/'}
        results = []
        for item in root.findall('.//item'):
            if len(results) >= limit:
                break
            name = (item.findtext('title') or '').strip()
            if not name:
                continue
            enclosure = item.find('enclosure')
            nzb_url = (enclosure.get('url') if enclosure is not None else '') or (item.findtext('link') or '')
            if not nzb_url:
                continue
            size_bytes = 0
            for attr in item.findall('newznab:attr', ns):
                if attr.get('name') == 'size':
                    try:
                        size_bytes = int(attr.get('value', 0))
                    except (TypeError, ValueError):
                        pass
                    break
            size = ''
            if size_bytes >= 1_073_741_824:
                size = '%.2f GB' % (size_bytes / 1_073_741_824)
            elif size_bytes >= 1_048_576:
                size = '%.0f MB' % (size_bytes / 1_048_576)
            results.append({
                'title':   name,
                'size':    size,
                'age':     (item.findtext('pubDate') or '').strip(),
                'nzb_url': nzb_url,
                'source':  source_name,
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/NZB] %s search error: %s' % (source_name, e), xbmc.LOGWARNING)
        return []


def search_nzbgeek(title, year=None, limit=10, media_type='movie'):
    api_key = ADDON.getSetting('nzbgeek_api_key').strip()
    if ADDON.getSetting('nzbgeek_enabled') != 'true' or not api_key:
        return []
    return _newznab_search('https://api.nzbgeek.info/api', api_key, 'NZBGeek',
                            title, year=year, limit=limit, media_type=media_type)


def search_nzbplanet(title, year=None, limit=10, media_type='movie'):
    api_key = ADDON.getSetting('nzbplanet_api_key').strip()
    if ADDON.getSetting('nzbplanet_enabled') != 'true' or not api_key:
        return []
    return _newznab_search('https://nzbplanet.net/api', api_key, 'NZBPlanet',
                            title, year=year, limit=limit, media_type=media_type)


# ── NZBIndex.nl — free, no account needed ────────────────────────────────────
#
# The site's own search page (nzbindex.nl/search/?q=...) is now a client-
# rendered Next.js app — confirmed live 2026-08-15: the raw HTML response
# has no results markup at all, just a
# `<template data-dgst="BAILOUT_TO_CLIENT_SIDE_RENDERING">` placeholder,
# meaning the visible results only ever get built in-browser by JS. BUT the
# same backend still serves its own classic RSS feed at plain `/rss?q=...`
# (no auth, no session, no cookies) — confirmed live: a plain GET returns
# real, well-formed `<rss><channel><item>` XML with a genuine post title,
# byte-accurate `<enclosure length=... url=.../>`, and that enclosure URL
# (`https://nzbindex.nl/download/<uuid>.nzb`) was confirmed live to return
# an actual, complete, ready-to-use NZB (verified against a real ~700KB
# multi-segment NZB, not a stub/redirect/login-wall) — no extra hop needed
# at all, unlike Binsearch's separate query+checkbox-id dance.
NZBINDEX_BASE = 'https://nzbindex.nl'


def _format_size(size_bytes):
    try:
        size_bytes = int(size_bytes)
    except (TypeError, ValueError):
        return ''
    if size_bytes >= 1_073_741_824:
        return '%.2f GB' % (size_bytes / 1_073_741_824)
    if size_bytes >= 1_048_576:
        return '%.0f MB' % (size_bytes / 1_048_576)
    if size_bytes >= 1024:
        return '%.0f KB' % (size_bytes / 1024)
    return ''


def search_nzbindex_nzb(title, year=None, limit=10, media_type='movie'):
    """Search nzbindex.nl via its classic RSS feed (the visible /search
    page is JS-only, but /rss?q=... is still plain server-rendered XML).
    Same loose multi-word matching caveat as Binsearch — results get
    filtered downstream by debrid_torrent.search_nzb_streams() via
    torrent_sources.filter_by_title_and_episode(). Returns
    [{'title':..., 'size':..., 'age':..., 'nzb_url':..., 'source': 'NZBIndex'}]"""
    try:
        from urllib.parse import quote as _q
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        url = '%s/rss?q=%s&max=%d' % (NZBINDEX_BASE, _q(query), max(limit * 3, 30))
        xml_text = _get(url, timeout=15)
        if not xml_text:
            return []

        import xml.etree.ElementTree as ET
        try:
            root = ET.fromstring(xml_text)
        except ET.ParseError:
            return []

        import html as _html_lib
        results = []
        for item in root.findall('.//item'):
            if len(results) >= limit:
                break
            name = (item.findtext('title') or '').strip()
            if not name:
                continue
            name = _html_lib.unescape(name).strip()
            if _RE_JUNK_EXT.search(name):
                continue
            enclosure = item.find('enclosure')
            nzb_url = (enclosure.get('url') if enclosure is not None else '') or (item.findtext('link') or '')
            if not nzb_url:
                continue
            size = _format_size(enclosure.get('length')) if enclosure is not None else ''
            results.append({
                'title':   name,
                'size':    size,
                'age':     (item.findtext('pubDate') or '').strip(),
                'nzb_url': nzb_url,
                'source':  'NZBIndex',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/NZB] NZBIndex search error: %s' % e, xbmc.LOGWARNING)
        return []


# ── NZBKing.com — free, no account needed ────────────────────────────────────
#
# Confirmed live 2026-08-15: `https://www.nzbking.com/?q=<query>` is real,
# server-rendered HTML (not JS-only) — each result is a
# `<div class='search-result'>...</div>` block containing the post subject
# (with the actual filename wrapped in `&quot;...&quot;`), a `size: NNN KB`
# line, an `<div class='search-age'>` cell, and a same-page checkbox whose
# `value` is the opaque per-post id nzbking's own `/nzb:<id>/` GET turns
# into a real downloadable .nzb — confirmed live against a real result: a
# plain GET to that URL returned a genuine, complete, multi-segment
# `application/x-nzb` file, no login/session needed.
#
# Like Binsearch/NZBIndex, `q=` is a loose OR-style multi-word match, not
# an exact title match (confirmed live: searching "matrix 1999" surfaced
# an unrelated "Music from the Year 1999" post and a Windows XP ISO purely
# because they matched on the word "1999") — downstream title filtering in
# debrid_torrent.search_nzb_streams() already handles this the same way it
# does for Binsearch/NZBIndex.
NZBKING_BASE = 'https://www.nzbking.com'

_RE_NZBKING_ID = re.compile(r'name="nzb"[^>]*value="([a-f0-9]+)"')
_RE_NZBKING_SUBJECT = re.compile(r"search-subject'>(.*?)<br>", re.DOTALL)
_RE_NZBKING_SIZE = re.compile(r'size:\s*([0-9.]+\s*[KMGT]?B)')
_RE_NZBKING_AGE = re.compile(r"search-age'>\s*([^<\n]+)")
_RE_NZBKING_QUOTED = re.compile(r'&quot;([^&]*?)&quot;')


def search_nzbking_nzb(title, year=None, limit=10, media_type='movie'):
    """Search nzbking.com. Returns
    [{'title':..., 'size':..., 'age':..., 'nzb_url':..., 'source': 'NZBKing'}]
    — nzb_url is a direct, ready-to-fetch .nzb download link."""
    try:
        from urllib.parse import quote as _q
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        url = '%s/?q=%s' % (NZBKING_BASE, _q(query))
        html_text = _get(url)
        if not html_text:
            return []

        import html as _html_lib
        results = []
        blocks = html_text.split("<div class='search-result'>")[1:]
        for block in blocks:
            if len(results) >= limit:
                break
            id_m = _RE_NZBKING_ID.search(block)
            subj_m = _RE_NZBKING_SUBJECT.search(block)
            if not id_m or not subj_m:
                continue
            post_id = id_m.group(1)
            subject = subj_m.group(1)
            quotes = _RE_NZBKING_QUOTED.findall(subject)
            name = next((q for q in quotes if q.strip() and '.' in q), None)
            name = _html_lib.unescape(name).strip() if name else _html_lib.unescape(subject).strip()
            name = re.sub(r'\s+', ' ', name).strip()
            if not name or _RE_JUNK_EXT.search(name):
                continue
            size_m = _RE_NZBKING_SIZE.search(block)
            age_m = _RE_NZBKING_AGE.search(block)
            nzb_url = '%s/nzb:%s/' % (NZBKING_BASE, post_id)
            results.append({
                'title':   name,
                'size':    size_m.group(1).strip() if size_m else '',
                'age':     age_m.group(1).strip() if age_m else '',
                'nzb_url': nzb_url,
                'source':  'NZBKing',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/NZB] NZBKing search error: %s' % e, xbmc.LOGWARNING)
        return []
