# -*- coding: utf-8 -*-
"""
resources/lib/trakt_sync.py

Push "watched" events AND real-time playback progress to a paired Trakt
account, and pull saved progress back for cross-device resume — the Trakt
equivalent of simkl_sync.py, mirrored function-for-function so
watch_history.py and continue_watching.py can treat all three providers
(SIMKL/MDBList/Trakt) uniformly. This is the actual payoff trakt_auth.py's
own docstring flagged as missing: tokens have been paired since that module
existed, but "nothing in the addon consumes the paired tokens yet" — this
module is what finally consumes them.

Trakt API v2 (api.trakt.tv, per trakt.docs.apiary.io — long-stable,
extensively documented public API; this addon's own trakt_auth.py already
depends on its /oauth/device/code and /oauth/device/token endpoints for the
pairing flow itself):

  - Every request needs three headers beyond Content-Type:
    'trakt-api-version': '2', 'trakt-api-key': <client_id>,
    'Authorization': 'Bearer <trakt_access_token>'. client_id comes from
    trakt_auth._client_id() (the same BYO Client ID/Secret the user already
    entered to pair) — Trakt's API requires the calling app's own
    client_id on every authenticated request, not just during the OAuth
    handshake, unlike SIMKL/MDBList's single bundled/personal key model.
  - POST /sync/history — mark_watched_movie/episode/show: body
    {'movies': [{'ids': {...}}]} / {'shows': [{'ids': {...}, 'seasons':
    [{'number': N, 'episodes': [{'number': N}]}]}]} — no watched_at needed
    (Trakt defaults to "now" when omitted), same shape SIMKL's own
    /sync/history call already uses in this codebase.
  - POST /scrobble/start|pause|stop — body {'progress': <0-100 float>,
    'movie': {'ids': {...}}} or {'progress': <float>, 'show': {'ids':
    {...}}, 'episode': {'season': N, 'number': N}}.
  - GET /sync/playback — array of paused items: {'progress': float,
    'paused_at': <iso8601>, 'type': 'movie'|'episode', 'movie': {...} or
    'show'+'episode': {...}}. Normalized to the same flat-dict shape as
    simkl_sync's own _normalize_playback_item().
  - get_all_items_shows(): Trakt has no bulk "next unwatched episode per
    in-progress show" convenience endpoint the way SIMKL's
    /sync/all-items/shows or MDBList's /upnext do. GET /sync/watched/shows
    returns full per-episode watched state per show but not a
    precomputed "next" pointer, and per-show GET /shows/{id}/progress/
    watched is one call per title — wrong shape for a bulk continue-
    watching scan. Per direct instruction, this is left as a no-op stub
    (always returns []) rather than forcing a bad approximation; the
    scrobble/playback-based get_normalized_playback() tier above still
    gives real cross-device resume value without it.
  - No token-refresh logic here, by direct instruction: trakt_auth.py
    doesn't implement refresh at all yet (pairing only stores the initial
    access/refresh token pair), so a 401 here just logs a warning and
    returns/no-ops, same as every other call site in this codebase already
    does for an expired/invalid token. Building refresh logic is explicitly
    out of scope for this task.

Adult content never reaches Trakt, same guard as simkl_sync.py/
mdblist_sync.py: only ever treats imdb_id as valid when it's shaped like a
real IMDB id (tt<digits>), copied here independently per this codebase's
no-cross-imports-between-sync-modules convention.

Every function no-ops immediately if not trakt_auth.is_paired(), exactly
like simkl_sync.py, so nothing changes for a user who never pairs Trakt.
"""
import re
import threading
import xbmc

from resources.lib import trakt_auth

_IMDB_RE = re.compile(r'^tt\d+$')


def _real_imdb(imdb_id):
    """Returns imdb_id if it's shaped like a genuine IMDB id, else ''."""
    return imdb_id if imdb_id and _IMDB_RE.match(imdb_id) else ''


TRAKT_BASE = 'https://api.trakt.tv'


def _fresh_token():
    # Same "always construct a fresh Addon(), never reuse a cached one" fix
    # as simkl_sync.py's own _fresh_token() and simkl_auth.py's is_paired()
    # — this can run from watch_history.py's playback-monitor thread, which
    # can easily be alive across a mid-session pairing.
    import xbmcaddon
    return xbmcaddon.Addon('plugin.video.starfleet').getSetting('trakt_access_token').strip()


def _headers():
    return {
        'Content-Type':     'application/json',
        'trakt-api-version': '2',
        'trakt-api-key':     trakt_auth._client_id(),
        'Authorization':     'Bearer %s' % _fresh_token(),
    }


def _post(payload, endpoint='/sync/history'):
    if not trakt_auth.is_paired():
        return
    token = _fresh_token()
    if not token:
        return
    try:
        import requests
        r = requests.post(TRAKT_BASE + endpoint, headers=_headers(), json=payload, timeout=10)
        if r.status_code == 401:
            xbmc.log('[Starfleet/Trakt] %s -> 401 (token expired/invalid, no refresh '
                     'implemented — see trakt_sync.py docstring)' % endpoint, xbmc.LOGWARNING)
            return
        xbmc.log('[Starfleet/Trakt] %s -> %s: %s' % (endpoint, r.status_code, payload),
                 xbmc.LOGINFO)
    except Exception as e:
        xbmc.log('[Starfleet/Trakt] %s error: %s' % (endpoint, e), xbmc.LOGWARNING)


def _post_async(payload, endpoint='/sync/history'):
    if not trakt_auth.is_paired():
        return
    threading.Thread(target=_post, args=(payload, endpoint), daemon=True).start()


def _ids(imdb_id='', tmdb_id=''):
    ids = {}
    if imdb_id:
        ids['imdb'] = imdb_id
    if tmdb_id:
        ids['tmdb'] = int(tmdb_id) if str(tmdb_id).isdigit() else tmdb_id
    return ids


def mark_watched_movie(imdb_id='', tmdb_id='', title=''):
    imdb_id = _real_imdb(imdb_id)
    if not trakt_auth.is_paired() or not (imdb_id or tmdb_id):
        return
    entry = {'ids': _ids(imdb_id, tmdb_id)}
    if title:
        entry['title'] = title
    _post_async({'movies': [entry]})


def mark_watched_episode(imdb_id='', tmdb_id='', title='', season=0, episode=0):
    imdb_id = _real_imdb(imdb_id)
    if not trakt_auth.is_paired() or not (imdb_id or tmdb_id) or not season or not episode:
        return
    entry = {
        'ids': _ids(imdb_id, tmdb_id),
        'seasons': [{'number': int(season), 'episodes': [{'number': int(episode)}]}],
    }
    if title:
        entry['title'] = title
    _post_async({'shows': [entry]})


def mark_show_watched(imdb_id='', tmdb_id='', title='', season_episode_pairs=None):
    """Mark every given (season, episode) watched on Trakt in one call —
    same rationale as simkl_sync.mark_show_watched, called by
    continue_watching.py's dismiss_show() alongside the other two providers
    so a dismissed card doesn't get resynthesized from Trakt's own
    still-stale remote state (Trakt has no bulk get_all_items_shows() tier
    here to resynthesize FROM — see this module's docstring — but keeping
    Trakt's own watched state in sync is still correct in its own right for
    anything else that reads it, e.g. Trakt.tv's own website/apps)."""
    imdb_id = _real_imdb(imdb_id)
    if not trakt_auth.is_paired() or not (imdb_id or tmdb_id) or not season_episode_pairs:
        return
    by_season = {}
    for season, episode in season_episode_pairs:
        by_season.setdefault(int(season), []).append({'number': int(episode)})
    entry = {
        'ids': _ids(imdb_id, tmdb_id),
        'seasons': [{'number': s, 'episodes': eps} for s, eps in sorted(by_season.items())],
    }
    if title:
        entry['title'] = title
    _post_async({'shows': [entry]})


# ── Scrobble (real cross-device resume) ─────────────────────────────────────

def _scrobble_body(progress, imdb_id='', tmdb_id='', title='', season=0, episode=0):
    ids = _ids(imdb_id, tmdb_id)
    body = {'progress': float(progress)}
    if season and episode:
        show = {'ids': ids}
        if title:
            show['title'] = title
        body['show'] = show
        body['episode'] = {'season': int(season), 'number': int(episode)}
    else:
        movie = {'ids': ids}
        if title:
            movie['title'] = title
        body['movie'] = movie
    return body


def _scrobble(endpoint, imdb_id='', tmdb_id='', title='', season=0, episode=0, progress=0.0):
    imdb_id = _real_imdb(imdb_id)
    if not trakt_auth.is_paired() or not (imdb_id or tmdb_id):
        return
    body = _scrobble_body(progress, imdb_id, tmdb_id, title, season, episode)
    _post_async(body, endpoint)


def scrobble_start(imdb_id='', tmdb_id='', title='', season=0, episode=0, progress=0.0):
    """Call once when playback actually begins. progress should reflect
    where playback is actually starting from (e.g. a resumed position),
    not always 0."""
    _scrobble('/scrobble/start', imdb_id, tmdb_id, title, season, episode, progress)


def scrobble_pause(imdb_id='', tmdb_id='', title='', season=0, episode=0, progress=0.0):
    """Call once when playback ends short of Trakt's own ~80%-watched mark
    — saves the position so get_playback_progress() below can find it from
    a different device later."""
    _scrobble('/scrobble/pause', imdb_id, tmdb_id, title, season, episode, progress)


def scrobble_stop(imdb_id='', tmdb_id='', title='', season=0, episode=0, progress=0.0):
    """Call once when playback ends at/past Trakt's own watched threshold —
    Trakt marks it watched server-side at that point, same conclusion
    mark_watched_movie/episode already reaches independently via
    /sync/history at this addon's own 90% threshold."""
    _scrobble('/scrobble/stop', imdb_id, tmdb_id, title, season, episode, progress)


def _normalize_playback_item(item):
    """One /sync/playback item -> a flat dict, matching simkl_sync's own
    shape, or None if it doesn't parse."""
    is_episode = item.get('type') == 'episode'
    container = item.get('show') if is_episode else item.get('movie')
    if not container:
        return None
    try:
        progress = float(item.get('progress'))
    except (TypeError, ValueError):
        return None
    season = episode = 0
    if is_episode:
        ep = item.get('episode') or {}
        try:
            season, episode = int(ep.get('season', 0)), int(ep.get('number', 0))
        except (TypeError, ValueError):
            return None
        if not (season and episode):
            return None
    return {
        'is_episode': is_episode,
        'ids':        container.get('ids', {}) or {},
        'season':     season, 'episode': episode,
        'title':      container.get('title', ''),
        'year':       container.get('year', ''),
        'progress':   progress,
        'ts':         _parse_iso_ts(item.get('paused_at', '')),
    }


def _parse_iso_ts(s):
    """paused_at is an ISO-8601 UTC timestamp - converts it to a unix epoch
    int so continue_watching.py can sort remote-only entries by recency
    alongside local ones. Returns 0 (sorts last, never crashes) on any
    format it doesn't recognize. Same helper as simkl_sync.py's own, copied
    independently rather than shared (no cross-imports between sync
    modules)."""
    if not s:
        return 0
    try:
        import datetime
        try:
            dt = datetime.datetime.fromisoformat(s.replace('Z', '+00:00'))
            return int(dt.timestamp())
        except Exception:
            import calendar
            dt = datetime.datetime.strptime(s[:19], '%Y-%m-%dT%H:%M:%S')
            return calendar.timegm(dt.timetuple())
    except Exception:
        return 0


def get_normalized_playback():
    """Every one of this account's paused playback sessions (movies and
    episodes mixed), normalized to a flat dict per item. [] if not paired,
    the request fails, or nothing is currently paused."""
    if not trakt_auth.is_paired():
        return []
    token = _fresh_token()
    if not token:
        return []
    try:
        import requests
        r = requests.get(TRAKT_BASE + '/sync/playback', headers=_headers(), timeout=10)
        if r.status_code == 401:
            xbmc.log('[Starfleet/Trakt] sync/playback -> 401 (token expired/invalid)',
                     xbmc.LOGWARNING)
            return []
        r.raise_for_status()
        items = r.json() or []
    except Exception as e:
        xbmc.log('[Starfleet/Trakt] sync/playback error: %s' % e, xbmc.LOGWARNING)
        return []
    out = []
    for item in items:
        n = _normalize_playback_item(item)
        if n:
            out.append(n)
    return out


def get_all_items_shows():
    """No-op stub — Trakt has no bulk 'next unwatched episode per
    in-progress show' endpoint the way SIMKL's /sync/all-items/shows or
    MDBList's /upnext do (see this module's docstring for what was
    considered and why it doesn't fit). Always returns [] so
    continue_watching.py's tier-2 remote merge simply contributes nothing
    for Trakt, without needing a special case at the call site."""
    return []


def get_playback_progress(imdb_id='', tmdb_id='', season=0, episode=0):
    """Return the matching item's saved progress percentage (0-100) from
    get_normalized_playback() above, or None if nothing matches / not
    paired / the request fails. Same matching rules as simkl_sync's own
    version: movies match on ids alone, episodes also require an exact
    season/episode match."""
    if not (imdb_id or tmdb_id):
        return None
    is_episode = bool(season and episode)
    for item in get_normalized_playback():
        if item['is_episode'] != is_episode:
            continue
        ids = item['ids']
        if not ((imdb_id and str(ids.get('imdb', '')) == str(imdb_id)) or
                (tmdb_id and str(ids.get('tmdb', '')) == str(tmdb_id))):
            continue
        if is_episode and (item['season'] != int(season) or item['episode'] != int(episode)):
            continue
        return item['progress']
    return None
