# -*- coding: utf-8 -*-
"""
resources/lib/wetrakr_sync.py

Push playback events to a paired WeTrakr account. Mirrors trakt_sync.py's/
simkl_sync.py's public function names and signatures so watch_history.py/
continue_watching.py's call sites work identically across all three -
deliberately NO cross-imports between sync modules, same as those two
(each redefines its own _IMDB_RE/_real_imdb guard rather than sharing it).

WeTrakr's real API is structurally different from Trakt/SIMKL, confirmed
by reading the actual installed script.wetrakr add-on's own resources/lib/
api.py: it is a SINGLE webhook endpoint, not a REST resource collection -
  POST {api_url}/webhooks/kodi/{access_token}
  Content-Type: application/json
  body: {"event": "playing"|"paused"|"scrobble"|"rating", "media_type":
         "movie"|"episode", "title", "year"?, "ids": {"imdb"?,"tmdb"?},
         ["show_title","show_ids","season","episode" for episodes,]
         "progress": float}
The access token is embedded in the URL path itself, not sent as an
Authorization header - a materially different auth transport than Trakt's
Bearer+api-key headers or SIMKL's Bearer header+query-string client params.

There is no separate "mark as watched" history endpoint and no GET query
endpoint at all in WeTrakr's real client (confirmed by reading its
player.py/service_runner.py: a "scrobble" event IS how it represents
"watched", sent once local progress crosses its own threshold setting;
nothing in the real add-on ever reads data back from the server). So here:
  - mark_watched_movie/mark_watched_episode/mark_show_watched send a
    "scrobble" event at progress=100.0 (there being no separate history
    call to make) - mark_show_watched sends one call per (season, episode)
    pair since WeTrakr's event shape is always a single episode, not a
    batched list like Trakt's/SIMKL's /sync/history.
  - scrobble_start/pause/stop map onto "playing"/"paused"/"scrobble".
  - get_normalized_playback()/get_playback_progress()/get_all_items_shows()
    are no-op stubs (return []/None/[]) - same precedent trakt_sync.py's
    own get_all_items_shows() already sets for "this provider has no
    equivalent bulk/query endpoint", since WeTrakr genuinely has nothing
    to query.

Adult content never reaches WeTrakr, same guard as trakt_sync.py/
simkl_sync.py: every function here only ever treats imdb_id as valid when
it matches real IMDB id shape (tt<digits>) - every adult source's opaque
key (e.g. "ade:5122655") fails that check and is silently dropped.
"""
import re
import threading
import xbmc

from resources.lib import wetrakr_auth

_IMDB_RE = re.compile(r'^tt\d+$')


def _real_imdb(imdb_id):
    """Returns imdb_id if it's shaped like a genuine IMDB id, else ''."""
    return imdb_id if imdb_id and _IMDB_RE.match(imdb_id) else ''


def _fresh_token():
    # Same "always construct a fresh Addon(), never reuse a cached one" fix
    # as simkl_sync.py's _fresh_token() - this runs from watch_history.py's
    # playback-monitor thread, which can easily be alive across a
    # mid-session pairing.
    import xbmcaddon
    return xbmcaddon.Addon('plugin.video.starfleet').getSetting('wetrakr_access_token').strip()


def _ids(imdb_id='', tmdb_id=''):
    ids = {}
    if imdb_id:
        ids['imdb'] = imdb_id
    if tmdb_id:
        try:
            ids['tmdb'] = int(tmdb_id)
        except (TypeError, ValueError):
            ids['tmdb'] = tmdb_id
    return ids


def _event_body(event, progress, imdb_id='', tmdb_id='', title='', season=0, episode=0):
    ids = _ids(imdb_id, tmdb_id)
    if season and episode:
        return {
            'event': event, 'media_type': 'episode',
            'title': title, 'show_title': title,
            'show_ids': ids, 'ids': ids,
            'season': int(season), 'episode': int(episode),
            'progress': float(progress),
        }
    return {
        'event': event, 'media_type': 'movie',
        'title': title, 'ids': ids,
        'progress': float(progress),
    }


def _post(payload):
    if not wetrakr_auth.is_paired():
        return
    token = _fresh_token()
    if not token:
        return
    base = wetrakr_auth.api_url()
    url = '%s/webhooks/kodi/%s' % (base, token)
    try:
        import requests
        r = requests.post(url, json=payload, headers={
            'Content-Type': 'application/json',
            'User-Agent':   wetrakr_auth.user_agent(),
        }, timeout=10)
        xbmc.log('[Starfleet/WeTrakr] webhook -> %s: %s' % (r.status_code, payload), xbmc.LOGINFO)
    except Exception as e:
        xbmc.log('[Starfleet/WeTrakr] webhook error: %s' % e, xbmc.LOGWARNING)


def _post_async(payload):
    threading.Thread(target=_post, args=(payload,), daemon=True).start()


def _send(event, progress, imdb_id='', tmdb_id='', title='', season=0, episode=0):
    imdb_id = _real_imdb(imdb_id)
    if not wetrakr_auth.is_paired() or not (imdb_id or tmdb_id):
        return
    _post_async(_event_body(event, progress, imdb_id, tmdb_id, title, season, episode))


def mark_watched_movie(imdb_id='', tmdb_id='', title=''):
    _send('scrobble', 100.0, imdb_id, tmdb_id, title)


def mark_watched_episode(imdb_id='', tmdb_id='', title='', season=0, episode=0):
    if not season or not episode:
        return
    _send('scrobble', 100.0, imdb_id, tmdb_id, title, season, episode)


def mark_show_watched(imdb_id='', tmdb_id='', title='', season_episode_pairs=None):
    """One webhook call per (season, episode) pair - WeTrakr's event shape
    is always a single episode, unlike Trakt's/SIMKL's batched
    /sync/history call. See this module's docstring."""
    if not season_episode_pairs:
        return
    for season, episode in season_episode_pairs:
        mark_watched_episode(imdb_id, tmdb_id, title, season, episode)


# ── Scrobble (playback progress events) ─────────────────────────────────────

def scrobble_start(imdb_id='', tmdb_id='', title='', season=0, episode=0, progress=0.0):
    """Call once when playback actually begins (see watch_history.py's
    start_playback_monitor()) - sends WeTrakr's "playing" event."""
    _send('playing', progress, imdb_id, tmdb_id, title, season, episode)


def scrobble_pause(imdb_id='', tmdb_id='', title='', season=0, episode=0, progress=0.0):
    """Call once when playback ends short of the watched threshold - sends
    WeTrakr's "paused" event (just a position/status update; WeTrakr has no
    separate resume-progress store to read back, see get_playback_progress
    below)."""
    _send('paused', progress, imdb_id, tmdb_id, title, season, episode)


def scrobble_stop(imdb_id='', tmdb_id='', title='', season=0, episode=0, progress=0.0):
    """Call once when playback ends at/past the watched threshold - sends
    WeTrakr's "scrobble" event, which IS how it represents "watched"
    server-side (confirmed live in the real add-on's own player.py)."""
    _send('scrobble', progress, imdb_id, tmdb_id, title, season, episode)


def get_normalized_playback():
    """WeTrakr's real API has no GET endpoint to query saved progress from
    (confirmed live - it's a write-only webhook) - always []."""
    return []


def get_all_items_shows():
    """Same reason as get_normalized_playback() above - always []."""
    return []


def get_playback_progress(imdb_id='', tmdb_id='', season=0, episode=0):
    """Same reason as get_normalized_playback() above - always None, so
    watch_history.apply_resume()'s priority chain just skips WeTrakr and
    falls through to the next provider (or local-only)."""
    return None
