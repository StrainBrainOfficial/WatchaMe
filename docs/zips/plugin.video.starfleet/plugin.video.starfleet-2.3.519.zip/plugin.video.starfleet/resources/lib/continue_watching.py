# -*- coding: utf-8 -*-
"""
resources/lib/continue_watching.py

Builds the Home carousel's "Continue Watching" row from watch_history.json.

Broader than a plain "resume where I left off" list:
  - Movies: anything in progress (resume_s > 0, not marked watched).
  - TV shows: a show comes back if there's a real unwatched episode still
    ahead of it ANYWHERE in its catalog, not just "the last episode I
    touched is unfinished" — e.g. finishing all of Season 1 still counts
    as Continue Watching if Season 2 exists and hasn't been watched, even
    though no watch_history entry for Season 2 exists yet at all (nothing
    has ever been played there). Detecting that requires the show's real,
    full episode catalog (TMDB), not just what's already in local history.
  - If the very next unwatched slot hasn't aired yet (season announced but
    not released, or a real future air_date), the show is left out of this
    row entirely rather than shown as a not-yet-playable "upcoming" card —
    it reappears here on its own once that episode has actually aired.

Requires tmdb_id per watch_history entry to do the TMDB season/episode
lookup — every write path (movie_play/episode_play via
start_playback_monitor, and the manual Mark Watched/Unwatched toggle)
already threads tmdb_id through, so this only "goes quiet" for a show
whose local history predates that field being stored (skipped gracefully,
not an error).

Cross-device merge (only when a SIMKL account is paired — see
simkl_auth.py/simkl_sync.py): pulls GET /sync/playback (every paused
session on the account, any device) and folds it in two ways —
  (1) a LOCAL entry whose SIMKL-saved progress is further along than what
      this device itself recorded gets its displayed percentage bumped up
      to match, so both devices show the same number, not just the same
      row;
  (2) a title with NO local record at all on this device, but genuinely
      in progress on another device per SIMKL, gets synthesized into the
      row from scratch (fresh TMDB lookup for poster/title) so it shows up
      here even though this device has never played a second of it.
When no SIMKL account is paired, none of this runs — behavior is exactly
what it was before this feature existed.

A second, separate merge tier (GET /sync/all-items/shows for SIMKL, GET
/upnext for MDBList) covers what the two above miss: a show with watched
episodes on the remote provider but NOTHING currently paused there (e.g.
the last episode already crossed the provider's completion threshold, or
was watched via a device/app that never sent a scrobble/pause at all) —
each of these endpoints already computes the show's own "next to watch"
episode from its per-episode watched state, so it's used directly as the
anchor instead of needing a local TMDB catalog walk. This closes the one
gap earlier versions of this docstring called out as deferred pending
confidence in the endpoint's shape. Trakt has no bulk equivalent of this
tier and always contributes [] here (see trakt_sync.py's docstring).

As of MDBList/Trakt sync being wired in, only ONE remote provider is ever
consulted per rebuild, not merged across all paired ones — see
_remote_provider() below for the exact SIMKL > MDBList > Trakt > local-only
priority order and why.
"""
import time
import xbmc

from resources.lib import watch_history as _wh
from resources.lib import metadata as _meta
from resources.lib import simkl_auth as _simkl_auth
from resources.lib import simkl_sync as _simkl_sync
from resources.lib import mdblist_auth as _mdblist_auth
from resources.lib import mdblist_sync as _mdblist_sync
from resources.lib import trakt_auth as _trakt_auth
from resources.lib import trakt_sync as _trakt_sync
from resources.lib import wetrakr_auth as _wetrakr_auth
from resources.lib import wetrakr_sync as _wetrakr_sync

_MOVIE_LIMIT = 8
_SHOW_LIMIT  = 12


def _today_str():
    return time.strftime('%Y-%m-%d')


def _remote_provider():
    """Pick the single remote sync provider (prefix, sync_module) to use
    for BOTH remote-merge tiers below, in the same deliberate priority
    order as watch_history.py's own _remote_progress_provider() — see that
    function's docstring for the full rationale (SIMKL: existing/most-
    tested; MDBList: added second per this session's request; Trakt:
    connected for the first time ever in this addon, zero production
    history, so it goes last). (None, None) if nothing is paired at all,
    meaning both tiers contribute nothing and behavior is exactly what it
    was before any of this existed (local-only).

    The prefix ('simkl'/'mdblist'/'trakt') is used to namespace synthetic
    Continue Watching keys (e.g. 'mdblist:%s' % tmdb_id) so remote-only
    cards from different providers can never collide with each other in
    the local dismiss-tracking system, and so switching which provider is
    paired doesn't accidentally "undismiss" a card that was dismissed
    under a different provider's key."""
    if _simkl_auth.is_paired():
        return 'simkl', _simkl_sync
    if _mdblist_auth.is_paired():
        return 'mdblist', _mdblist_sync
    if _trakt_auth.is_paired():
        return 'trakt', _trakt_sync
    if _wetrakr_auth.is_paired():
        return 'wetrakr', _wetrakr_sync
    return None, None


def dismiss_show(tmdb_id, imdb_id, title=''):
    """Remove a show from Continue Watching for good — used by a Continue
    Watching card's own long-press 'Mark as Watched', NOT the same as
    marking one specific episode watched. Confirmed live as a real,
    reported bug otherwise: marking only the single displayed "next"
    episode just advances the pointer to whatever unwatched episode comes
    right after it — if the show has more episodes anywhere ahead in its
    catalog (a different season included), _find_next_episode() finds
    that one instead and the card never actually goes away, no matter how
    many times the action is used. This walks the show's ENTIRE known
    catalog (every season TMDB lists, not just the current one) and marks
    every episode watched in one pass, so there is nothing left for
    _shows_in_progress() to anchor a new "next episode" on. One-way (not
    a toggle) — the concept of "unmark this whole show" isn't well-defined
    the way a single episode's toggle is, and re-watching anything in it
    naturally recreates a Continue Watching entry on its own anyway."""
    try:
        detail = _meta.get_tv_detail(tmdb_id) or {}
    except Exception as e:
        xbmc.log('[Starfleet/ContinueWatching] dismiss_show get_tv_detail(%s): %s' % (tmdb_id, e), xbmc.LOGWARNING)
        return False
    pairs = []
    for s in (detail.get('seasons') or []):
        snum = s.get('season', 0)
        if snum <= 0 or s.get('episode_count', 0) == 0:
            continue
        try:
            sd = _meta.get_season_detail(tmdb_id, snum) or {}
        except Exception as e:
            xbmc.log('[Starfleet/ContinueWatching] dismiss_show get_season_detail(%s,%s): %s' % (tmdb_id, snum, e), xbmc.LOGWARNING)
            continue
        for ep in (sd.get('episodes') or []):
            enum = ep.get('episode')
            if enum:
                pairs.append((snum, enum))
    if not pairs:
        return False
    _wh.mark_episodes_watched(imdb_id, pairs, title=title, tmdb_id=tmdb_id)
    # Also tell every paired remote provider — otherwise each provider's own
    # next-to-watch computation (tier 2 below) independently recomputes an
    # unwatched episode from ITS OWN remote state and re-synthesizes this
    # exact show right back into the list on the very next rebuild,
    # regardless of what the local write above just did. Confirmed live
    # (for SIMKL) as the actual reason a dismissed card kept reappearing.
    # Unlike the single-provider read-side priority elsewhere in this file,
    # this write fires to ALL THREE unconditionally — each self-gates via
    # its own is_paired() check, matching watch_history.py's "fire to
    # every paired service independently" write-side philosophy, since a
    # user who paired multiple services presumably wants all of them kept
    # in sync, not just whichever one is read-side-highest-priority.
    try:
        _simkl_sync.mark_show_watched(imdb_id, tmdb_id, title=title, season_episode_pairs=pairs)
    except Exception as e:
        xbmc.log('[Starfleet/ContinueWatching] dismiss_show SIMKL mark error: %s' % e, xbmc.LOGWARNING)
    try:
        _mdblist_sync.mark_show_watched(imdb_id, tmdb_id, title=title, season_episode_pairs=pairs)
    except Exception as e:
        xbmc.log('[Starfleet/ContinueWatching] dismiss_show MDBList mark error: %s' % e, xbmc.LOGWARNING)
    try:
        _trakt_sync.mark_show_watched(imdb_id, tmdb_id, title=title, season_episode_pairs=pairs)
    except Exception as e:
        xbmc.log('[Starfleet/ContinueWatching] dismiss_show Trakt mark error: %s' % e, xbmc.LOGWARNING)
    try:
        _wetrakr_sync.mark_show_watched(imdb_id, tmdb_id, title=title, season_episode_pairs=pairs)
    except Exception as e:
        xbmc.log('[Starfleet/ContinueWatching] dismiss_show WeTrakr mark error: %s' % e, xbmc.LOGWARNING)
    return True


def _find_next_episode(tmdb_id, watched_set, anchor_season, anchor_episode):
    """Walk the show's real TMDB catalog forward from (anchor_season,
    anchor_episode) and return (episode_or_stub_dict, is_upcoming) for the
    first slot not already in watched_set. (None, False) if nothing is
    left (fully watched) or the catalog can't be read."""
    try:
        detail = _meta.get_tv_detail(tmdb_id) or {}
    except Exception as e:
        xbmc.log('[Starfleet/ContinueWatching] get_tv_detail(%s): %s' % (tmdb_id, e), xbmc.LOGWARNING)
        return None, False

    seasons = sorted(
        [s for s in (detail.get('seasons') or []) if s.get('season', 0) >= anchor_season],
        key=lambda s: s.get('season', 0))

    for s in seasons:
        snum = s.get('season', 0)
        if s.get('episode_count', 0) == 0:
            # Season announced (has a TMDB entry) but no episodes listed
            # yet — the whole season is the "upcoming" unit here.
            if (snum, 1) in watched_set:
                continue
            return {'season': snum, 'episode': 1, 'aired': s.get('air_date', ''),
                    'title': '', 'still': '', 'season_name': s.get('name', '')}, True
        try:
            sd = _meta.get_season_detail(tmdb_id, snum) or {}
        except Exception as e:
            xbmc.log('[Starfleet/ContinueWatching] get_season_detail(%s,%s): %s' % (tmdb_id, snum, e), xbmc.LOGWARNING)
            continue
        for ep in sorted(sd.get('episodes') or [], key=lambda e: e.get('episode', 0)):
            enum = ep.get('episode', 0)
            if snum == anchor_season and enum <= anchor_episode:
                continue
            if (snum, enum) in watched_set:
                continue
            aired = ep.get('aired', '')
            is_upcoming = (not aired) or (aired > _today_str())
            ep = dict(ep)
            ep['season_name'] = s.get('name', '')
            return ep, is_upcoming
    return None, False


def _movies_in_progress(db, limit=_MOVIE_LIMIT):
    candidates = []
    for k, e in db.items():
        if k.startswith('tmdb:'):
            continue  # the movie-only tmdb-bridge duplicate, not a real entry to show twice
        if e.get('season') or e.get('episode'):
            continue  # TV episode entry, handled separately
        if e.get('watched') or not e.get('resume_s'):
            continue
        candidates.append(e)
    candidates.sort(key=lambda e: e.get('ts', 0), reverse=True)

    provider_prefix, provider = _remote_provider()
    paired = provider is not None
    remote_movies = []
    if paired:
        try:
            remote_movies = [p for p in provider.get_normalized_playback() if not p['is_episode']]
        except Exception as ex:
            xbmc.log('[Starfleet/ContinueWatching] get_normalized_playback error: %s' % ex, xbmc.LOGWARNING)

    def _remote_match(imdb_id, tmdb_id):
        for p in remote_movies:
            ids = p['ids']
            if (imdb_id and str(ids.get('imdb', '')) == str(imdb_id)) or \
               (tmdb_id and str(ids.get('tmdb', '')) == str(tmdb_id)):
                return p
        return None

    out = []
    seen_tmdb_ids = set()
    for e in candidates[:limit]:
        tmdb_id = e.get('tmdb_id', '')
        if not tmdb_id:
            continue
        try:
            d = _meta.get_movie_detail(tmdb_id) or {}
        except Exception:
            d = {}
        if not d:
            continue
        pct = int(e['resume_s'] / e['total_s'] * 100) if e.get('total_s') else 0
        if paired:
            match = _remote_match(e.get('imdb_id', ''), tmdb_id)
            if match and match['progress'] > pct:
                pct = int(match['progress'])
        seen_tmdb_ids.add(str(tmdb_id))
        out.append({
            'id': str(tmdb_id), 'tmdb_id': str(tmdb_id),
            'title': d.get('title') or e.get('title', ''),
            'thumb': d.get('thumb', ''), 'fanart': d.get('fanart', ''),
            'plot': d.get('overview', ''), 'year': d.get('year', ''),
            'source': 'tmdb', 'media_type': 'movie',
            'cw_kind': 'movie_resume', 'progress_pct': pct,
            'ts': e.get('ts', 0),
        })

    # Remote-only: in progress on another device via whichever provider is
    # highest-priority-and-paired (see _remote_provider()), no local record
    # here at all yet — synthesize a full entry via a fresh TMDB lookup.
    if paired:
        for p in remote_movies:
            tmdb_id = str(p['ids'].get('tmdb', '') or '')
            if not tmdb_id or tmdb_id in seen_tmdb_ids or not (0 < p['progress'] < 90):
                continue
            try:
                d = _meta.get_movie_detail(tmdb_id) or {}
            except Exception:
                d = {}
            if not d:
                continue
            seen_tmdb_ids.add(tmdb_id)
            out.append({
                'id': tmdb_id, 'tmdb_id': tmdb_id,
                'title': d.get('title') or p.get('title', ''),
                'thumb': d.get('thumb', ''), 'fanart': d.get('fanart', ''),
                'plot': d.get('overview', ''), 'year': d.get('year', ''),
                'source': 'tmdb', 'media_type': 'movie',
                'cw_kind': 'movie_resume', 'progress_pct': int(p['progress']),
                'ts': p.get('ts', 0),
            })
    return out[:limit]


def _shows_in_progress(db, limit=_SHOW_LIMIT):
    groups = {}
    for k, e in db.items():
        season, episode = e.get('season', 0), e.get('episode', 0)
        if not (season and episode):
            continue
        show_key = e.get('imdb_id', '') or k.rsplit(':S', 1)[0]
        groups.setdefault(show_key, []).append(e)

    provider_prefix, provider = _remote_provider()
    paired = provider is not None
    remote_episodes = []
    if paired:
        try:
            remote_episodes = [p for p in provider.get_normalized_playback() if p['is_episode']]
        except Exception as ex:
            xbmc.log('[Starfleet/ContinueWatching] get_normalized_playback error: %s' % ex, xbmc.LOGWARNING)

    def _remote_match_show(imdb_id, tmdb_id):
        return [p for p in remote_episodes
                if (imdb_id and str(p['ids'].get('imdb', '')) == str(imdb_id)) or
                   (tmdb_id and str(p['ids'].get('tmdb', '')) == str(tmdb_id))]

    scored = []
    seen_tmdb_ids = set()
    for show_key, entries in groups.items():
        watched_set = {(e['season'], e['episode']) for e in entries if e.get('watched')}
        last = max(entries, key=lambda e: e.get('ts', 0))
        tmdb_id = last.get('tmdb_id', '') or next(
            (e.get('tmdb_id', '') for e in entries if e.get('tmdb_id')), '')
        if not tmdb_id:
            continue  # legacy entry predating tmdb_id storage — can't safely enrich, skip
        watched_entries = [e for e in entries if e.get('watched')]
        anchor = max(watched_entries, key=lambda e: (e['season'], e['episode'])) if watched_entries else last
        if paired:
            imdb_id = last.get('imdb_id', '') or show_key
            remote_for_show = _remote_match_show(imdb_id, tmdb_id)
            for p in remote_for_show:
                last_ts = max(last.get('ts', 0), p.get('ts', 0))
                if last_ts != last.get('ts', 0):
                    last = dict(last, ts=last_ts)
        seen_tmdb_ids.add(str(tmdb_id))
        scored.append((show_key, entries, last, tmdb_id, watched_set, anchor))

    # Remote-only: a show with an episode currently in progress on another
    # device via whichever provider is highest-priority-and-paired, but
    # ZERO local history for it at all yet — seed a synthetic group from
    # the remote episode alone. anchor is set one slot BEFORE the paused
    # episode (season, episode-1) so _find_next_episode()'s own "skip
    # anything <= anchor" walk naturally returns the paused episode itself
    # as the thing to continue, rather than skipping past it. episode-1 is
    # clamped to 0, NOT rolled back a whole season when the target is
    # itself episode 1 — confirmed live as a real off-by-one: the old
    # "roll back to (season-1, episode=1)" fallback collided with a target
    # of S01E01 itself (anchor became S01E01 too, since season can't go
    # below 1), so the walk's "enum <= anchor_episode" check incorrectly
    # skipped episode 1 as if it were already anchored/watched. Episode 0
    # never collides with any real episode number, so nothing gets skipped.
    # The synthetic key is namespaced with the active provider's own prefix
    # ('simkl:'/'mdblist:'/'trakt:') so remote-only cards from different
    # providers can never collide in the local dismiss-tracking system.
    if paired:
        for p in remote_episodes:
            tmdb_id = str(p['ids'].get('tmdb', '') or '')
            if not tmdb_id or tmdb_id in seen_tmdb_ids or not (0 < p['progress'] < 90):
                continue
            anchor_season, anchor_episode = p['season'], max(p['episode'] - 1, 0)
            seen_tmdb_ids.add(tmdb_id)
            scored.append((
                '%s:%s' % (provider_prefix, tmdb_id), [],
                {'ts': p.get('ts', 0), 'title': p.get('title', '')},
                tmdb_id, set(), {'season': anchor_season, 'episode': anchor_episode},
            ))

    # Remote-only, tier 2: a show with WATCHED episodes on the paired
    # provider but nothing currently paused (e.g. the last watched episode
    # already crossed the provider's own completion threshold, or was
    # watched on a device/app that never sent a scrobble/pause at all) —
    # each provider's get_all_items_shows() already computes next_to_watch
    # itself (SIMKL via /sync/all-items/shows, MDBList via /upnext; Trakt
    # has no bulk equivalent and always returns [] here — see
    # trakt_sync.py's docstring), so it's used directly as the anchor
    # instead of re-deriving it from a local TMDB catalog walk.
    if paired:
        try:
            remote_shows = provider.get_all_items_shows()
        except Exception as ex:
            xbmc.log('[Starfleet/ContinueWatching] get_all_items_shows error: %s' % ex, xbmc.LOGWARNING)
            remote_shows = []
        for s in remote_shows:
            tmdb_id = str(s['ids'].get('tmdb', '') or '')
            if not tmdb_id or tmdb_id in seen_tmdb_ids:
                continue
            anchor_season, anchor_episode = s['next_season'], max(s['next_episode'] - 1, 0)
            seen_tmdb_ids.add(tmdb_id)
            scored.append((
                '%s:%s' % (provider_prefix, tmdb_id), [],
                {'ts': s.get('ts', 0), 'title': s.get('title', '')},
                tmdb_id, set(), {'season': anchor_season, 'episode': anchor_episode},
            ))

    scored.sort(key=lambda t: t[2].get('ts', 0), reverse=True)

    out = []
    for show_key, entries, last, tmdb_id, watched_set, anchor in scored[:limit]:
        nxt, upcoming = _find_next_episode(tmdb_id, watched_set, anchor['season'], anchor['episode'])
        if not nxt:
            continue  # nothing left to watch — show is genuinely finished
        try:
            show_detail = _meta.get_tv_detail(tmdb_id) or {}
        except Exception:
            show_detail = {}
        title = show_detail.get('title') or last.get('title', '')
        entry = {
            'id': str(tmdb_id), 'tmdb_id': str(tmdb_id),
            'title': title,
            # The show's own poster, not the next episode's still — this
            # is a carousel of SHOWS to continue, same visual identity
            # as every other row (New Releases/Popular/etc all show the
            # series icon, never a random episode frame), not a
            # per-episode browsing list where a still would make sense.
            'thumb': show_detail.get('thumb', ''),
            'fanart': show_detail.get('fanart', ''),
            'year': show_detail.get('year', ''),
            'source': 'tmdb', 'media_type': 'tv',
            'cw_season': nxt['season'], 'cw_episode': nxt['episode'],
            'ts': last.get('ts', 0),
        }
        if upcoming:
            # Per direct request: surface the show even though the next
            # episode hasn't aired yet, rather than hiding it entirely
            # (the earlier behavior) — home.py's _set_hero() renders this
            # kind distinctly (red italic + air date in the hero meta line)
            # so it reads as "coming soon", not as playable right now.
            entry['cw_kind'] = 'tv_upcoming'
            entry['cw_air_date'] = nxt.get('aired', '')
            entry['plot'] = ('Upcoming: S%02dE%02d — %s' %
                             (nxt['season'], nxt['episode'], nxt.get('title', '')))
        else:
            entry['cw_kind'] = 'tv_next'
            entry['plot'] = 'S%02dE%02d — %s' % (nxt['season'], nxt['episode'], nxt.get('title', ''))
        out.append(entry)
    return out


def get_continue_watching(limit=20):
    try:
        db = _wh._load()
    except Exception as e:
        xbmc.log('[Starfleet/ContinueWatching] load error: %s' % e, xbmc.LOGWARNING)
        return []
    items = _movies_in_progress(db) + _shows_in_progress(db)
    items.sort(key=lambda x: x.get('ts', 0), reverse=True)
    return items[:limit]
