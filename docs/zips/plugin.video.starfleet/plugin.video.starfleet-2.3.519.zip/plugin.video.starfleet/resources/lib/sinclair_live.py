# -*- coding: utf-8 -*-
"""
resources/lib/sinclair_live.py

Sinclair Broadcast Group local US station live streams — same legitimate-
official-source idea as TVA/Global News/CBC in api.py, just a different
broadcaster group and a plain public HLS manifest instead of a Google DAI
session (no token dance needed at all).

Mechanism (confirmed live against real stations, no browser automation
needed — the manifest URL is embedded straight in the server-rendered
/watch page HTML, a plain requests.get() + regex sees it):
  GET https://{station_domain}/watch
  -> regex for https://harvested-assets(-<region>)?.sinclairstoryline.com
                /{CALLSIGN}/{timestamp}/HLS/index.m3u8

That timestamp segment rotates (confirmed two fetches of the same page
minutes apart returned different timestamps), so the URL isn't a stable
permalink — cached with a short TTL and re-resolved on expiry, same
overall shape as the daddylive channel-id resolver elsewhere in this addon.

Station list below is NOT the full ~185-station Sinclair portfolio — it's
every station whose {callsign}.com (or known alternate domain) was
actually confirmed live to return a real harvested-assets manifest.
Most Sinclair stations either use a different branded domain entirely
(e.g. not callsign.com) or don't run this particular watch-live page, and
guessing further domains risks listing dead entries — this list only
contains what was verified working.
"""
import re
import requests
import xbmc

from resources.lib import cache as _cache

_UA = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
    'AppleWebKit/537.36 (KHTML, like Gecko) '
    'Chrome/126.0.0.0 Safari/537.36'
)
_HEADERS = {'User-Agent': _UA}

_MANIFEST_RE = re.compile(
    r'https://harvested-assets(?:-[a-z]+-\d)?\.sinclairstoryline\.com'
    r'/([A-Z0-9]+)/[0-9TZ:.\-]+/HLS/index\.m3u8'
)

_RESOLVE_TTL = 600  # 10 min — long enough to avoid hammering the site on
                    # every menu open, short enough that a rotated
                    # timestamp doesn't go stale for long.

# (callsign, domain, city/market, state, network label, thumbnail)
SINCLAIR_STATIONS = [
    ('KATV', 'katv.com', 'Little Rock',        'Arkansas',              'ABC'),
    ('KMPH', 'kmph.com', 'Fresno',              'California',            'Fox'),
    ('WJLA', 'wjla.com', 'Washington',          'District of Columbia',  'ABC'),
    ('WGXA', 'wfxl.com', 'Albany',              'Georgia',               'Fox'),
    ('WSBT', 'wsbt.com', 'South Bend',          'Indiana',               'CBS'),
    ('WGME', 'wgme.com', 'Portland',            'Maine',                 'CBS'),
    ('WWMT', 'wwmt.com', 'Grand Rapids',        'Michigan',              'CBS'),
    ('KTUL', 'ktul.com', 'Tulsa',               'Oklahoma',              'ABC'),
    ('KATU', 'katu.com', 'Portland',            'Oregon',                'ABC'),
    ('KVAL', 'kval.com', 'Eugene',              'Oregon',                'CBS'),
    ('WACH', 'wach.com', 'Columbia',            'South Carolina',        'Fox'),
    ('WLOS', 'wlos.com', 'Greenville/Asheville','South Carolina',        'ABC'),
    ('WPDE', 'wpde.com', 'Myrtle Beach',        'South Carolina',        'ABC'),
    ('WCYB', 'wcyb.com', 'Tri-Cities',          'Virginia/Tennessee',    'NBC'),
    ('KTXS', 'ktxs.com', 'Abilene',             'Texas',                 'ABC'),
    ('KFDM', 'kfdm.com', 'Beaumont',            'Texas',                 'CBS'),
    ('KUTV', 'kutv.com', 'Salt Lake City',      'Utah',                  'CBS'),
    ('KJZZ', 'kjzz.com', 'Salt Lake City',      'Utah',                  'Independent'),
    ('WSET', 'wset.com', 'Lynchburg/Roanoke',   'Virginia',              'ABC'),
    # Second recovery pass — these all originally failed under a plain
    # "{callsign}.com" domain guess (some resolved to an unrelated business
    # entirely, e.g. komo.com is a machine-tool company, not KOMO-TV) and
    # were only found by reading each station's real "Website" field off
    # its own Wikipedia infobox, then confirming live against the same
    # harvested-assets manifest pattern.
    ('WEAR', 'weartv.com',      'Mobile',                 'Alabama',        'ABC'),
    ('KRCR', 'krcrtv.com',      'Chico/Redding',          'California',     'ABC'),
    ('KECI', 'nbcmontana.com',  'Butte/Missoula',         'Montana',        'NBC'),
    ('WCTI', 'wcti12.com',      'New Bern',               'North Carolina', 'ABC'),
    ('WKRC', 'cwcincinnati.com','Cincinnati',             'Ohio',           'The CW'),
    ('WSTR', 'star64.tv',       'Cincinnati',             'Ohio',           'MyNetworkTV'),
    ('KMTR', 'nbc16.com',       'Eugene',                 'Oregon',         'NBC'),
    ('WJAC', 'wjactv.com',      'Johnstown',              'Pennsylvania',   'NBC'),
    ('KFOX', 'kfoxtv.com',      'El Paso',                'Texas',          'Fox'),
    ('KOMO', 'komonews.com',    'Seattle',                'Washington',     'ABC'),
    ('WCHS', 'wchstv.com',      'Huntington/Charleston',  'West Virginia',  'ABC'),
    ('WTOV', 'wtov9.com',       'Wheeling',               'West Virginia',  'NBC'),
]


def _get_session():
    from resources.lib import geo_spoof_us as geo
    if geo.is_enabled():
        return geo.session()
    s = requests.Session()
    s.headers.update(_HEADERS)
    return s


def get_channels():
    """Return the confirmed-working Sinclair station list as unified_live-
    shaped channel dicts (no network call — resolution happens lazily on
    play, same lazy pattern as everything else in this addon)."""
    channels = []
    for callsign, domain, city, state, network in SINCLAIR_STATIONS:
        channels.append({
            'key':       'sinclair_%s' % callsign.lower(),
            'title':     '%s %s (%s, %s)' % (callsign, network, city, state),
            'group':     'US Local News (Sinclair)',
            'thumbnail': 'https://%s/favicon.ico' % domain,
            'sources': [{
                'source':     'sinclair',
                'label':      '%s %s' % (callsign, network),
                'callsign':   callsign,
                'domain':     domain,
                'thumbnail':  'https://%s/favicon.ico' % domain,
                'channel_id': callsign,
            }],
        })
    return channels


def resolve_stream_url(callsign, domain):
    """
    Fetch the station's /watch page and extract the current live manifest
    URL, decorated with US geo-bypass headers if enabled in settings.
    Returns '' if the page no longer contains a matching manifest (station
    off-air, redesigned page, etc).
    """
    ck = 'sinclair_stream_%s' % callsign
    from resources.lib import geo_spoof_us as geo

    cached = _cache.get(ck)
    if cached:
        return geo.decorate_url(cached) if geo.is_enabled() else cached

    try:
        sess = _get_session()
        resp = sess.get('https://%s/watch' % domain, headers=_HEADERS, timeout=10)
        resp.raise_for_status()
        m = _MANIFEST_RE.search(resp.text)
        if not m:
            xbmc.log('[Sinclair] %s: no manifest match on /watch page' % callsign,
                      xbmc.LOGWARNING)
            return ''
        url = m.group(0)
        _cache.set(ck, url, _RESOLVE_TTL)
        return geo.decorate_url(url) if geo.is_enabled() else url
    except Exception as e:
        xbmc.log('[Sinclair] resolve_stream_url(%s): %s' % (callsign, e), xbmc.LOGERROR)
        return ''
