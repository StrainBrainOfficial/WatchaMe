# -*- coding: utf-8 -*-
"""
resources/lib/trakt_auth.py

Trakt account pairing (OAuth device-code flow) — lets a user link their own
Trakt account to this addon. Independent of the home screen's Anticipated
widgets (those are TMDB-only now, see trakt_widgets.py) — this is a general
building block for any future feature that needs to act as a specific
user's Trakt account (watchlist, scrobbling, personalized lists, etc.).
Nothing in the addon consumes the paired tokens yet.

Needs a free Trakt API app (Settings > Premium Services > Trakt Client
ID/Secret), registered by whoever's using it — trakt.tv/oauth/applications/new,
redirect URI http://localhost. There's no app shared by this addon itself:
the device-code flow requires the calling application's own client_id/secret
on every request, so each installer registers their own, same BYO-key model
as the Real-Debrid/AllDebrid/Premiumize/TorBox settings above it.
"""
import time
import xbmc
import xbmcaddon
import xbmcgui
from resources.lib.gui import progress_dialog as _pdlg

ADDON      = xbmcaddon.Addon('plugin.video.starfleet')
TRAKT_BASE = 'https://api.trakt.tv'


def _client_id():
    return ADDON.getSetting('trakt_client_id').strip()


def _client_secret():
    return ADDON.getSetting('trakt_client_secret').strip()


def is_paired():
    return bool(ADDON.getSetting('trakt_access_token').strip())


def unpair():
    ADDON.setSetting('trakt_access_token', '')
    ADDON.setSetting('trakt_refresh_token', '')


def pair_with_trakt():
    """Run the full device-code pairing flow, showing progress in a Kodi
    dialog. Bound to the trakt_pair Settings action."""
    cid    = _client_id()
    secret = _client_secret()
    if not cid or not secret:
        xbmcgui.Dialog().ok(
            'Starfleet - Trakt',
            'Enter a Trakt Client ID and Client Secret first (Settings > '
            'Premium Services > Trakt) - create a free app at '
            'trakt.tv/oauth/applications/new (redirect URI http://localhost).'
        )
        return

    try:
        import requests
    except Exception:
        xbmcgui.Dialog().notification('Starfleet', 'requests module unavailable',
                                      xbmcgui.NOTIFICATION_ERROR)
        return

    try:
        r = requests.post(TRAKT_BASE + '/oauth/device/code',
                          json={'client_id': cid}, timeout=10)
        r.raise_for_status()
        data = r.json()
    except Exception as e:
        xbmc.log('[Starfleet/Trakt] device/code error: %s' % e, xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Starfleet', 'Trakt pairing failed to start',
                                      xbmcgui.NOTIFICATION_ERROR, 4000)
        return

    device_code = data.get('device_code')
    user_code   = data.get('user_code')
    verify_url  = data.get('verification_url', 'trakt.tv/activate')
    expires_in  = data.get('expires_in', 600)
    interval    = data.get('interval', 5)

    if not device_code or not user_code:
        xbmcgui.Dialog().notification('Starfleet', 'Trakt pairing failed to start',
                                      xbmcgui.NOTIFICATION_ERROR, 4000)
        return

    dlg = _pdlg.DialogProgress()
    msg = 'Go to %s on any device and enter code:\n\n%s' % (verify_url, user_code)
    dlg.create('Starfleet - Pair with Trakt', msg)

    waited = 0
    while waited < expires_in:
        if dlg.iscanceled():
            dlg.close()
            return
        time.sleep(interval)
        waited += interval
        dlg.update(min(99, int(100 * waited / expires_in)), msg)

        try:
            tr = requests.post(TRAKT_BASE + '/oauth/device/token', json={
                'code': device_code, 'client_id': cid, 'client_secret': secret,
            }, timeout=10)
        except Exception as e:
            xbmc.log('[Starfleet/Trakt] device/token error: %s' % e, xbmc.LOGWARNING)
            continue

        if tr.status_code == 200:
            tok = tr.json()
            ADDON.setSetting('trakt_access_token', tok.get('access_token', ''))
            ADDON.setSetting('trakt_refresh_token', tok.get('refresh_token', ''))
            dlg.close()
            xbmcgui.Dialog().notification('Starfleet', 'Trakt account paired',
                                          xbmcgui.NOTIFICATION_INFO, 3000)
            return
        if tr.status_code == 400:
            continue  # still pending — user hasn't entered the code yet
        if tr.status_code == 404:
            dlg.close()
            xbmcgui.Dialog().notification('Starfleet', 'Trakt: invalid device code',
                                          xbmcgui.NOTIFICATION_ERROR, 4000)
            return
        if tr.status_code == 409:
            dlg.close()
            xbmcgui.Dialog().notification('Starfleet', 'Trakt: code already used',
                                          xbmcgui.NOTIFICATION_ERROR, 4000)
            return
        if tr.status_code == 410:
            dlg.close()
            xbmcgui.Dialog().notification('Starfleet', 'Trakt: code expired, try again',
                                          xbmcgui.NOTIFICATION_ERROR, 4000)
            return
        if tr.status_code == 418:
            dlg.close()
            xbmcgui.Dialog().notification('Starfleet', 'Trakt: pairing denied',
                                          xbmcgui.NOTIFICATION_ERROR, 4000)
            return
        if tr.status_code == 429:
            interval += 1  # Trakt asked us to slow down

    dlg.close()
    xbmcgui.Dialog().notification('Starfleet', 'Trakt pairing timed out',
                                  xbmcgui.NOTIFICATION_INFO, 4000)


def show_status():
    """Bound to the trakt_status Settings action."""
    if is_paired():
        if xbmcgui.Dialog().yesno('Starfleet - Trakt', 'Trakt account is paired.\n\nUnpair?'):
            unpair()
            xbmcgui.Dialog().notification('Starfleet', 'Trakt unpaired',
                                          xbmcgui.NOTIFICATION_INFO, 3000)
    else:
        xbmcgui.Dialog().ok('Starfleet - Trakt', 'Not paired yet. Use "Pair with Trakt" above.')
