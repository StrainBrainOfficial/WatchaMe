# -*- coding: utf-8 -*-
"""
resources/lib/mdblist_sync.py

Push "watched" events AND real-time playback progress to a paired MDBList
(mdblist.com) account, and pull saved progress back so a different device
can resume where another one left off — the MDBList equivalent of
simkl_sync.py, mirrored function-for-function so watch_history.py and
continue_watching.py can treat all three providers (SIMKL/MDBList/Trakt)
uniformly.

Every endpoint/body shape below was confirmed live against api.mdblist.com's
own OpenAPI schema (GET https://api.mdblist.com/schema/, 2026) and, where
noted, against real HTTP responses using an intentionally-invalid API key —
not guessed by analogy to SIMKL or Trakt:

  - POST /sync/watched — "Add or Update Watched History". Body:
    {'movies': [{'ids': {...}, 'watched_at': <iso8601>}],
     'shows':  [{'ids': {...}, 'seasons': [{'number': N,
                 'episodes': [{'number': N, 'watched_at': <iso8601>}]}]}]}
    The shows[].seasons[].episodes[] nesting isn't expanded in the schema's
    property list directly (MDBList's schema exporter leaves several nested
    objects as untyped `object` throughout this API — confirmed live: the
    spec's `components:` section has no `schemas:` block at all, only
    `securitySchemes`), but the sibling top-level `episodes` field's own
    description explicitly names "shows[].seasons[].episodes[]" as the
    structure it's a flat alternative to, which is what pins this shape
    down as real rather than assumed.
  - POST /scrobble/start|pause|stop — confirmed live, identical body shape
    across all three: {'movie': {'ids': {...}}, 'progress': <0-100 float>}
    for a movie, or {'show': {'ids': {...}, 'season': N, 'episode': N},
    'progress': <float>} for an episode (MDBList's docs call this the
    "flat" form; a "nested" season/episode.number form is also accepted
    but the flat form matches simkl_sync.py's own body shape most closely,
    so that's what's used here). No 'title' field is in the confirmed
    request schema/examples for these three, unlike SIMKL's, so none is
    sent.
  - GET /sync/playback — "Get Playback Sessions": paused sessions the user
    can resume elsewhere. Confirmed live top-level item fields: id,
    progress (0-100), updated_at_ts (unix epoch int — no ISO parsing
    needed, nicer than SIMKL's paused_at string), runtime, is_manual,
    type ('movie'|'episode'), and movie/episode/show sub-objects. IMPORTANT
    LIMITATION: those three sub-objects are documented only as generic
    `object` with no expanded properties anywhere in the schema (same
    "no components/schemas block" gap as above) — MDBList's docs describe
    WHAT the endpoint returns but not the exact field names inside movie/
    show/episode. _normalize_playback_item() below parses them
    defensively (trying the 'ids'/'title'/'year' shape confirmed
    elsewhere in this same API for movie/show, and a couple of reasonable
    key fallbacks for the episode's season/number), and silently skips any
    item whose shape doesn't match rather than guessing wrong data into
    continue_watching.py's merge logic — same fail-safe posture as
    simkl_sync.py's own malformed-item handling. This is a real, flagged
    gap; a live key would let this be tightened up.
  - GET /upnext — "Get Up Next": in-progress shows with next unwatched
    episode, MDBList's purpose-built direct equivalent of SIMKL's
    /sync/all-items/shows + next_to_watch. Confirmed live top-level
    response shape: {'items': [...], 'limit': int, 'has_more': bool}. Same
    limitation as /sync/playback above: each item's internal fields aren't
    expanded in the schema (only the English description says items
    include "show metadata, next-episode details, progress counts, and the
    last watched timestamp") — get_all_items_shows() below parses
    defensively for the same reason, with the same silent-skip fallback.

Adult content (Adult Section sources) never reaches MDBList, same guard as
simkl_sync.py: watch_history.py's adult play paths pass opaque keys like
"ade:5122655" or "javseen:abc123" through the same imdb_id parameter real
content uses, so every function below only ever treats imdb_id as valid
when it's actually shaped like a real IMDB id (tt<digits>) — copied here
independently rather than imported from simkl_sync.py, matching this
codebase's existing convention of no cross-imports between sync modules.

Every function no-ops immediately if not mdblist_auth.is_paired(), exactly
like simkl_sync.py, so nothing changes for a user who never sets this up.
"""
import re
import threading
import time
import xbmc

from resources.lib import mdblist_auth

_IMDB_RE = re.compile(r'^tt\d+$')


def _real_imdb(imdb_id):
    """Returns imdb_id if it's shaped like a genuine IMDB id, else ''."""
    return imdb_id if imdb_id and _IMDB_RE.match(imdb_id) else ''


MDBLIST_BASE = 'https://api.mdblist.com'


def _params():
    return {'apikey': mdblist_auth._api_key()}


def _headers():
    return {'Content-Type': 'application/json'}


def _iso_now():
    return time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())


def _request(method, endpoint, payload=None, timeout=10):
    if not mdblist_auth.is_paired():
        return None
    try:
        import requests
        fn = requests.post if method == 'POST' else requests.get
        kwargs = {'params': _params(), 'headers': _headers(), 'timeout': timeout}
        if payload is not None:
            kwargs['json'] = payload
        r = fn(MDBLIST_BASE + endpoint, **kwargs)
        xbmc.log('[Starfleet/MDBList] %s %s -> %s' % (method, endpoint, r.status_code),
                 xbmc.LOGINFO)
        return r
    except Exception as e:
        xbmc.log('[Starfleet/MDBList] %s %s error: %s' % (method, endpoint, e), xbmc.LOGWARNING)
        return None


def _post_async(payload, endpoint):
    if not mdblist_auth.is_paired():
        return
    threading.Thread(target=_request, args=('POST', endpoint, payload), daemon=True).start()


def _ids(imdb_id='', tmdb_id=''):
    ids = {}
    if imdb_id:
        ids['imdb'] = imdb_id
    if tmdb_id:
        ids['tmdb'] = str(tmdb_id)
    return ids


# ── Watched history (POST /sync/watched) ────────────────────────────────────

def mark_watched_movie(imdb_id='', tmdb_id='', title=''):
    imdb_id = _real_imdb(imdb_id)
    if not mdblist_auth.is_paired() or not (imdb_id or tmdb_id):
        return
    entry = {'ids': _ids(imdb_id, tmdb_id), 'watched_at': _iso_now()}
    _post_async({'movies': [entry]}, '/sync/watched')


def mark_watched_episode(imdb_id='', tmdb_id='', title='', season=0, episode=0):
    imdb_id = _real_imdb(imdb_id)
    if not mdblist_auth.is_paired() or not (imdb_id or tmdb_id) or not season or not episode:
        return
    entry = {
        'ids': _ids(imdb_id, tmdb_id),
        'seasons': [{'number': int(season),
                     'episodes': [{'number': int(episode), 'watched_at': _iso_now()}]}],
    }
    _post_async({'shows': [entry]}, '/sync/watched')


def mark_show_watched(imdb_id='', tmdb_id='', title='', season_episode_pairs=None):
    """Mark every given (season, episode) watched on MDBList in one call —
    same rationale as simkl_sync.mark_show_watched: continue_watching.py's
    dismiss_show() needs BOTH the local write and the remote provider's own
    watched state to agree, or get_all_items_shows() (/upnext) below just
    recomputes the same unwatched next episode from MDBList's still-stale
    remote state and the dismissed card reappears on the very next rebuild."""
    imdb_id = _real_imdb(imdb_id)
    if not mdblist_auth.is_paired() or not (imdb_id or tmdb_id) or not season_episode_pairs:
        return
    ts = _iso_now()
    by_season = {}
    for season, episode in season_episode_pairs:
        by_season.setdefault(int(season), []).append({'number': int(episode), 'watched_at': ts})
    entry = {
        'ids': _ids(imdb_id, tmdb_id),
        'seasons': [{'number': s, 'episodes': eps} for s, eps in sorted(by_season.items())],
    }
    _post_async({'shows': [entry]}, '/sync/watched')


# ── Scrobble (real cross-device resume) ─────────────────────────────────────

def _scrobble_body(progress, imdb_id='', tmdb_id='', season=0, episode=0):
    ids = _ids(imdb_id, tmdb_id)
    body = {'progress': float(progress)}
    if season and episode:
        body['show'] = {'ids': ids, 'season': int(season), 'episode': int(episode)}
    else:
        body['movie'] = {'ids': ids}
    return body


def _scrobble(endpoint, imdb_id='', tmdb_id='', title='', season=0, episode=0, progress=0.0):
    imdb_id = _real_imdb(imdb_id)
    if not mdblist_auth.is_paired() or not (imdb_id or tmdb_id):
        return
    body = _scrobble_body(progress, imdb_id, tmdb_id, season, episode)
    _post_async(body, endpoint)


def scrobble_start(imdb_id='', tmdb_id='', title='', season=0, episode=0, progress=0.0):
    """Call once when playback actually begins. progress should reflect
    where playback is actually starting from (e.g. a resumed position),
    not always 0."""
    _scrobble('/scrobble/start', imdb_id, tmdb_id, title, season, episode, progress)


def scrobble_pause(imdb_id='', tmdb_id='', title='', season=0, episode=0, progress=0.0):
    """Call once when playback ends short of MDBList's own 80%-watched
    mark (confirmed live in /scrobble/pause's own docstring: "If progress
    >= 80%, marks item as watched") — saves the position so
    get_playback_progress() below can find it from a different device."""
    _scrobble('/scrobble/pause', imdb_id, tmdb_id, title, season, episode, progress)


def scrobble_stop(imdb_id='', tmdb_id='', title='', season=0, episode=0, progress=0.0):
    """Call once when playback ends at/past the 80%-watched mark — finalizes
    the session; confirmed live that /scrobble/stop also marks watched
    server-side at >=80%, same conclusion mark_watched_movie/episode
    already reaches independently via /sync/watched at this addon's own
    90% threshold."""
    _scrobble('/scrobble/stop', imdb_id, tmdb_id, title, season, episode, progress)


# ── Remote progress reads ───────────────────────────────────────────────────

def _normalize_playback_item(item):
    """One /sync/playback item -> a flat dict matching simkl_sync's own
    shape, or None if it doesn't parse. See this module's docstring for why
    the nested movie/show/episode sub-object fields are extracted
    defensively — MDBList's schema doesn't expand their properties."""
    try:
        is_episode = item.get('type') == 'episode'
        container = item.get('show') if is_episode else item.get('movie')
        if not container:
            return None
        progress = float(item.get('progress'))
    except (TypeError, ValueError, AttributeError):
        return None

    season = episode = 0
    if is_episode:
        ep = item.get('episode') or {}
        try:
            s = ep.get('season')
            if isinstance(s, dict):
                s = s.get('number')
            e = ep.get('episode', ep.get('number'))
            if isinstance(e, dict):
                e = e.get('number')
            season, episode = int(s or 0), int(e or 0)
        except (TypeError, ValueError):
            return None
        if not (season and episode):
            return None

    ts = item.get('updated_at_ts', 0) or 0
    try:
        ts = int(ts)
    except (TypeError, ValueError):
        ts = 0

    return {
        'is_episode': is_episode,
        'ids':        container.get('ids', {}) or {},
        'season':     season, 'episode': episode,
        'title':      container.get('title', ''),
        'year':       container.get('year', ''),
        'progress':   progress,
        'ts':         ts,
    }


def get_normalized_playback():
    """Every one of this account's paused playback sessions (movies and
    episodes mixed), normalized to a flat dict per item. [] if not paired,
    the request fails, or nothing is currently paused."""
    if not mdblist_auth.is_paired():
        return []
    r = _request('GET', '/sync/playback')
    if r is None or r.status_code != 200:
        return []
    try:
        items = r.json() or []
    except Exception as e:
        xbmc.log('[Starfleet/MDBList] sync/playback parse error: %s' % e, xbmc.LOGWARNING)
        return []
    out = []
    for item in items:
        n = _normalize_playback_item(item)
        if n:
            out.append(n)
    return out


def get_all_items_shows():
    """Every in-progress show with a next unwatched episode, via GET
    /upnext — normalized to the same flat-dict shape simkl_sync's
    get_all_items_shows() returns (ids/title/year/next_season/
    next_episode/ts). See this module's docstring for the confirmed
    {'items': [...], 'limit', 'has_more'} envelope and the flagged gap in
    each item's own internal field names. [] if not paired, the request
    fails, or nothing is in progress."""
    if not mdblist_auth.is_paired():
        return []
    r = _request('GET', '/upnext', payload=None)
    if r is None or r.status_code != 200:
        return []
    try:
        data = r.json() or {}
    except Exception as e:
        xbmc.log('[Starfleet/MDBList] upnext parse error: %s' % e, xbmc.LOGWARNING)
        return []
    out = []
    for item in (data.get('items') or []):
        try:
            # 'show' sub-object isn't confirmed to exist as a nested key —
            # fall back to the item itself in case show fields are flattened
            # directly onto it (both shapes are plausible given the schema
            # gap documented above).
            show = item.get('show') if isinstance(item.get('show'), dict) else item
            ids = show.get('ids', {}) or {}
            if not ids:
                continue
            nxt = item.get('next_episode') or item.get('episode') or {}
            s = nxt.get('season')
            if isinstance(s, dict):
                s = s.get('number')
            e = nxt.get('episode', nxt.get('number'))
            if isinstance(e, dict):
                e = e.get('number')
            next_season, next_episode = int(s or 0), int(e or 0)
            if not (next_season and next_episode):
                continue
            ts = item.get('last_watched_at_ts') or item.get('updated_at_ts') or 0
            try:
                ts = int(ts)
            except (TypeError, ValueError):
                ts = 0
            out.append({
                'ids':          ids,
                'title':        show.get('title', '') or item.get('title', ''),
                'year':         show.get('year', ''),
                'next_season':  next_season,
                'next_episode': next_episode,
                'ts':           ts,
            })
        except Exception:
            continue
    return out


def get_playback_progress(imdb_id='', tmdb_id='', season=0, episode=0):
    """Return the matching item's saved progress percentage (0-100) from
    get_normalized_playback() above, or None if nothing matches / not
    paired / the request fails. Same matching rules as simkl_sync's own
    version: movies match on ids alone, episodes also require an exact
    season/episode match."""
    if not (imdb_id or tmdb_id):
        return None
    is_episode = bool(season and episode)
    for item in get_normalized_playback():
        if item['is_episode'] != is_episode:
            continue
        ids = item['ids']
        if not ((imdb_id and str(ids.get('imdb', '')) == str(imdb_id)) or
                (tmdb_id and str(ids.get('tmdb', '')) == str(tmdb_id))):
            continue
        if is_episode and (item['season'] != int(season) or item['episode'] != int(episode)):
            continue
        return item['progress']
    return None
