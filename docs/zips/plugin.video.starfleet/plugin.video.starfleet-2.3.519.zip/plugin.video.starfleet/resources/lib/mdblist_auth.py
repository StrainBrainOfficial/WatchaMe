# -*- coding: utf-8 -*-
"""
resources/lib/mdblist_auth.py

MDBList (mdblist.com) account pairing — much simpler than trakt_auth.py's
OAuth device-code flow or simkl_auth.py's PIN flow, because MDBList's API
for a personal account is just a bring-your-own API key passed as a query
parameter (confirmed live against api.mdblist.com's own OpenAPI schema,
2026: `securitySchemes.apiKey: {type: apiKey, in: query, name: apikey}`,
description "API key passed as a query parameter: ?apikey=YOUR_KEY" — every
documented endpoint lists `security: [apiKey, bearerAuth]`, i.e. either
works, but this module and mdblist_sync.py use the apikey query-param form
exclusively, per direct request, since OAuth/bearer is for third-party apps
registering their own client and irrelevant to a personal key).

There is no pairing "flow" to run — the user gets their own key from
mdblist.com/preferences/#api and pastes it into Settings > Premium Services
> MDBList. This module's only real job is verify_key(): a lightweight
GET /user?apikey=... call (confirmed live, 2026: 200 returns
{api_requests, user_id, username, plan, limits: {...}, rate_limit, ...};
an intentionally-wrong key returns 403 {"error": "Invalid API key"}) that
tells the user whether the key they pasted actually works, same UX role as
trakt_auth.py/simkl_auth.py's show_status() — a Dialog notification, not a
full pairing dialog since there's nothing to poll.

SECURITY: the user's own MDBList API key lives ONLY in Kodi's Settings
storage (ADDON.getSetting('mdblist_api_key')), read fresh on every call —
never hardcoded here or anywhere else in this codebase, same BYO-credential
model as the Real-Debrid/AllDebrid/Premiumize/TorBox/MegaDebrid/Streamtape/
Trakt client_id+secret settings already in this addon. Default is empty
string; nothing works until the user pastes their own key in.

is_paired() gates on BOTH the mdblist_enabled Settings toggle AND a
non-empty key (matching personal_sources.py's _md_credentials()/
_st_credentials() convention for simple BYO-credential sources — an
enabled toggle with no key, or a key with the toggle off, both count as
"not paired").
"""
import xbmc
import xbmcaddon
import xbmcgui

MDBLIST_BASE = 'https://api.mdblist.com'


def _addon():
    # A fresh Addon() every call, NOT a module-level cached one — same fix
    # as simkl_auth.py's is_paired()/mdblist_sync.py's own token lookups:
    # a long-lived process (this addon's Home screen runs as one for the
    # whole session) that imported this module before the key was pasted in
    # would otherwise keep reading a settings snapshot frozen from before
    # that write, no matter how long it's been since.
    return xbmcaddon.Addon('plugin.video.starfleet')


def _api_key():
    return _addon().getSetting('mdblist_api_key').strip()


def is_paired():
    a = _addon()
    return bool(a.getSetting('mdblist_enabled') == 'true' and a.getSetting('mdblist_api_key').strip())


def unpair():
    """Clears the stored key and turns the enabled toggle off — there's no
    remote token to revoke (it's the user's own API key, not an OAuth
    grant), so this is purely a local Settings reset."""
    a = _addon()
    a.setSetting('mdblist_api_key', '')
    a.setSetting('mdblist_enabled', 'false')


def verify_key():
    """Bound to the mdblist_verify Settings action ('Verify API Key').
    GETs /user?apikey=... and shows a Kodi notification with the result —
    success shows the real username from the response (proves the key
    actually works, not just that it's non-empty), failure explains why."""
    key = _api_key()
    if not key:
        xbmcgui.Dialog().notification('Starfleet', 'Enter an MDBList API key first',
                                      xbmcgui.NOTIFICATION_ERROR, 4000)
        return

    try:
        import requests
    except Exception:
        xbmcgui.Dialog().notification('Starfleet', 'requests module unavailable',
                                      xbmcgui.NOTIFICATION_ERROR)
        return

    try:
        r = requests.get(MDBLIST_BASE + '/user', params={'apikey': key}, timeout=10)
    except Exception as e:
        xbmc.log('[Starfleet/MDBList] verify_key request error: %s' % e, xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Starfleet', 'MDBList verification failed (network error)',
                                      xbmcgui.NOTIFICATION_ERROR, 4000)
        return

    if r.status_code == 200:
        try:
            data = r.json()
        except Exception:
            data = {}
        username = data.get('username') or data.get('name') or '(unknown user)'
        plan = data.get('plan', '')
        xbmcgui.Dialog().notification(
            'Starfleet', 'MDBList key OK — %s%s' % (username, ' (%s)' % plan if plan else ''),
            xbmcgui.NOTIFICATION_INFO, 4000)
        return

    # Confirmed live: an invalid key returns 403 {"error": "Invalid API key"}
    # on /user specifically (other endpoints return 401 for the same body) —
    # surface that message when present rather than just the status code.
    try:
        err = (r.json() or {}).get('error', '')
    except Exception:
        err = ''
    xbmc.log('[Starfleet/MDBList] verify_key -> %s: %s' % (r.status_code, err), xbmc.LOGWARNING)
    xbmcgui.Dialog().notification(
        'Starfleet', 'MDBList: %s' % (err or 'invalid API key'),
        xbmcgui.NOTIFICATION_ERROR, 4000)
