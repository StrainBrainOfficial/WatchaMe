# -*- coding: utf-8 -*-
"""
resources/lib/adult_favorites.py
Separate favorites store for adult content — does NOT overlap with main favorites.json.
"""
import json
import os
import time
import urllib.parse as _up

import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

_PROFILE = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.starfleet/')
_FPATH   = os.path.join(_PROFILE, 'adult_favorites.json')


def _load():
    try:
        with open(_FPATH, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}


def _save(data):
    try:
        os.makedirs(_PROFILE, exist_ok=True)
        with open(_FPATH, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False)
    except Exception as e:
        xbmc.log('[AdultFav] save error: %s' % e, xbmc.LOGWARNING)


def add(ade_id, title, thumb, fanart=''):
    data = _load()
    data[str(ade_id)] = {
        'ade_id': str(ade_id),
        'title':  title,
        'thumb':  thumb,
        'fanart': fanart or thumb,
        'ts':     int(time.time()),
    }
    _save(data)


def remove(ade_id):
    data = _load()
    data.pop(str(ade_id), None)
    _save(data)


def is_favorite(ade_id):
    return str(ade_id) in _load()


def get_all():
    """Return all adult favorites sorted newest-added first."""
    return sorted(_load().values(), key=lambda x: x.get('ts', 0), reverse=True)


# ── Action handlers called by dispatcher ─────────────────────────────────────

def adult_favorites_add_action(ade_id, title, thumb='', fanart=''):
    add(ade_id, title, thumb, fanart)
    xbmcgui.Dialog().notification(
        'Adult Favorites', 'Added: %s' % title,
        xbmcgui.NOTIFICATION_INFO, 2000
    )


def adult_favorites_remove_action(ade_id, title=''):
    remove(ade_id)
    xbmcgui.Dialog().notification(
        'Adult Favorites', 'Removed' + (' : %s' % title if title else ''),
        xbmcgui.NOTIFICATION_INFO, 2000
    )


# ── Directory view ────────────────────────────────────────────────────────────

def adult_favorites_list(handle, build_url):
    xbmcplugin.setPluginCategory(handle, '❤️ Adult Favorites')
    xbmcplugin.setContent(handle, 'movies')

    favs = get_all()
    if not favs:
        xbmcgui.Dialog().notification(
            'Adult Favorites', 'No adult favorites yet — long-press a movie to add one',
            xbmcgui.NOTIFICATION_INFO, 3000
        )
        xbmcplugin.endOfDirectory(handle, succeeded=True)
        return

    for f in favs:
        ade_id    = str(f['ade_id'])
        title     = f.get('title', '')
        thumb     = f.get('thumb', '')
        fanart    = f.get('fanart', thumb)
        title_enc = _up.quote(title)

        li = xbmcgui.ListItem(label=title)
        try:
            tag = li.getVideoInfoTag()
            tag.setTitle(title)
            tag.setMpaa('Adults Only')
        except Exception:
            li.setInfo('video', {'title': title, 'mpaa': 'Adults Only'})
        li.setArt({'thumb': thumb, 'poster': thumb, 'fanart': fanart})
        li.setProperty('IsPlayable', 'true')
        li.addContextMenuItems([
            ('Remove from Adult Favorites',
             'RunPlugin(plugin://plugin.video.starfleet/'
             '?action=adult_favorites_remove&ade_id=%s&title=%s)' % (ade_id, title_enc))
        ])
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action': 'adult_ade_play', 'ade_id': ade_id, 'title': title}),
            li, False
        )

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(handle, succeeded=True)
