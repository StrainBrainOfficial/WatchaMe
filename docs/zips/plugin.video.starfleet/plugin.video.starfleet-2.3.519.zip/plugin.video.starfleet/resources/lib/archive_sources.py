# -*- coding: utf-8 -*-
"""
resources/lib/archive_sources.py

Internet Archive (archive.org) — free, legitimately-hosted public domain
movies and older TV series. No API key needed at all: archive.org's own
advancedsearch.php endpoint and per-item metadata endpoint are both public
and keyless.

Confirmed live before building this (not assumed):
  - The 'feature_films' collection alone has 28,000+ real, searchable
    items (advancedsearch.php's own numFound), each with a direct
    streamable video file.
  - Each item ALSO carries an auto-generated .torrent bundling that same
    item's own files (an alternate BitTorrent-based access path to
    content already legitimately hosted there — not a torrent-index site
    the way ext.to/eztv are), plus thumbnails and metadata/XML files
    alongside the real video — resolve_archive_stream below has to filter
    those out specifically, since a naive "biggest file" pick would just
    grab a Metadata sidecar file rather than the actual video.
  - Movies map cleanly onto 'feature_films'. TV is messier: archive.org's
    generic 'television' collection (733,000+ items) is overwhelmingly
    local news broadcasts and other non-show recordings, confirmed live
    by sampling it directly — using it here would flood every TV search
    with noise. 'classic_tv' (~11,000 items) is the meaningfully curated
    TV collection and is what's used instead, but even there, episode
    titles/queries arrive here already formatted as "Show SxxExx" (see
    metadata_router.py's episode_play), which doesn't match how
    archive.org itself titles things — expect a genuinely low TV hit
    rate, same honestly-disclosed tradeoff already made for MyPornClub
    elsewhere in this addon, not a bug if TV rarely matches here.
"""
import re
import xbmc

try:
    import requests
except ImportError:
    requests = None

try:
    from resources.lib import cache as _cache
    _HAS_CACHE = True
except Exception:
    _HAS_CACHE = False

ARCHIVE_BASE = 'https://archive.org'
_SEARCH_URL  = ARCHIVE_BASE + '/advancedsearch.php'
_META_URL    = ARCHIVE_BASE + '/metadata/%s'
_IMG_URL     = ARCHIVE_BASE + '/services/img/%s'

# Real playable video formats archive.org itself reports on a file —
# everything else an item bundles (Thumbnail, Item Tile, Archive
# BitTorrent, Metadata) must be excluded or resolve_archive_stream would
# happily "resolve" to a JPEG or an XML sidecar.
_VIDEO_FORMATS = {
    'mpeg4', '512kb mpeg4', 'h.264', 'h.264 ia', 'matroska', 'ogg video',
    'ogv', 'mpeg2', 'flash video', 'windows media', 'quicktime', 'mp4',
}

_COLLECTIONS = {'movie': 'feature_films', 'tv': 'classic_tv'}

_HEADERS = {'User-Agent': 'plugin.video.starfleet/1.0'}


def _get_json(url, params=None, timeout=12):
    if requests is None:
        return None
    try:
        r = requests.get(url, params=params, timeout=timeout, headers=_HEADERS)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        xbmc.log('[Starfleet/Archive] request error (%s): %s' % (url, e), xbmc.LOGWARNING)
        return None


def _norm(t):
    return re.sub(r'[^a-z0-9]', '', (t or '').lower())


def _first(v):
    """advancedsearch.php's fl[] fields sometimes come back as a list of
    one instead of a bare value depending on the field — normalize both."""
    if isinstance(v, list):
        return v[0] if v else ''
    return v or ''


def resolve_archive_stream(archive_id):
    """Resolve an Internet Archive item id to its best direct-playable
    video file URL — the single largest file whose own declared format is
    a real video format (see _VIDEO_FORMATS' own comment for why that
    check matters here specifically). Public API: this is exactly the
    function free_router.py's free_play() already expected to exist
    (imported as _fs.resolve_archive_stream) but never actually did."""
    if not archive_id:
        return ''
    ck = 'archive_stream_%s' % archive_id
    if _HAS_CACHE:
        cached = _cache.get(ck)
        if cached is not None:
            return cached
    data = _get_json(_META_URL % archive_id)
    if not data:
        return ''
    best = None
    for f in (data.get('files') or []):
        fmt = (f.get('format') or '').lower()
        if fmt not in _VIDEO_FORMATS:
            continue
        try:
            size = int(f.get('size') or 0)
        except (TypeError, ValueError):
            size = 0
        if best is None or size > best[1]:
            best = (f.get('name', ''), size)
    if not best or not best[0]:
        return ''
    from urllib.parse import quote as _uq
    url = '%s/download/%s/%s' % (ARCHIVE_BASE, archive_id, _uq(best[0]))
    if _HAS_CACHE:
        _cache.set(ck, url, 24 * 3600)
    return url


def get_thumb(archive_id):
    """Archive.org's own per-item thumbnail image — no extra fetch needed,
    this URL just works directly for any valid item id."""
    return (_IMG_URL % archive_id) if archive_id else ''


def browse_archive(media_type='movie', page=1, rows=20):
    """Browse the whole collection for media_type (feature_films/classic_tv)
    sorted by popularity, paginated — backs a real 'Internet Archive' entry
    in the Free Movies / Free TV Shows service list, distinct from
    search_and_resolve_archive's title-driven search-integration path.
    Item dicts intentionally carry no 'plot' — a synopsis would require an
    extra /metadata fetch per item on every page load, and every other free
    service in this addon already tolerates an empty plot the same way."""
    collection = _COLLECTIONS.get(media_type)
    if not collection:
        return []

    ck = 'archive_browse_%s_p%d' % (media_type, page)
    if _HAS_CACHE:
        cached = _cache.get(ck)
        if cached is not None:
            return cached

    query = 'collection:%s AND mediatype:movies' % collection
    data = _get_json(_SEARCH_URL, params={
        'q': query,
        'fl[]': ['identifier', 'title', 'year'],
        'sort[]': 'downloads desc',
        'rows': rows, 'page': page, 'output': 'json',
    })
    docs = ((data or {}).get('response', {}) or {}).get('docs', []) or []

    items = []
    for d in docs:
        archive_id = d.get('identifier', '')
        if not archive_id:
            continue
        title = _first(d.get('title')) or archive_id
        year = _first(d.get('year'))
        items.append({
            'title':      title,
            'year':       str(year),
            'plot':       '',
            'thumb':      get_thumb(archive_id),
            'fanart':     '',
            'archive_id': archive_id,
        })

    if _HAS_CACHE:
        _cache.set(ck, items, 6 * 3600)
    return items


def search_and_resolve_archive(title, year=None, media_type='movie', limit=5):
    """Search Internet Archive for a title within the collection matching
    media_type, then resolve each real match straight to a playable URL —
    returns {'label','url','source'} dicts ready to drop into the same
    'Choose source' picker every other free-stream result already feeds,
    not a two-step browse-then-resolve flow (there are typically only a
    handful of real candidates for a given title, so resolving them all
    up front is cheap and keeps this source's calling shape identical to
    every other one search_free_streams() already aggregates)."""
    collection = _COLLECTIONS.get(media_type)
    if not collection or not title:
        return []

    ck = 'archive_search_%s_%s_%s' % (media_type, _norm(title), year or '')
    if _HAS_CACHE:
        cached = _cache.get(ck)
        if cached is not None:
            return cached

    query = 'collection:%s AND mediatype:movies AND title:(%s)' % (collection, title)
    data = _get_json(_SEARCH_URL, params={
        'q': query,
        'fl[]': ['identifier', 'title', 'year'],
        'rows': 20, 'page': 1, 'output': 'json',
    })
    docs = ((data or {}).get('response', {}) or {}).get('docs', []) or []

    target_norm = _norm(title)
    candidates = []
    for d in docs:
        doc_title = _first(d.get('title'))
        doc_norm = _norm(doc_title)
        if not doc_norm:
            continue
        # advancedsearch's title:(...) is a fuzzy full-text match, not an
        # exact one — it returns plenty of items that merely share a
        # word, so require a genuine substring relationship either way.
        if target_norm not in doc_norm and doc_norm not in target_norm:
            continue
        doc_year = _first(d.get('year'))
        # Year filtering only for movies — a TV query's title already
        # carries "Show SxxExx" (see this module's own docstring), and a
        # per-episode archive.org upload's own year rarely lines up with
        # a whole show's TMDB year anyway, so enforcing it there would
        # just suppress the few real hits TV can ever get here.
        if media_type == 'movie' and year and doc_year and str(year) != str(doc_year):
            continue
        candidates.append((d.get('identifier', ''), doc_title, doc_year))
        if len(candidates) >= limit:
            break

    results = []
    for archive_id, doc_title, doc_year in candidates:
        if not archive_id:
            continue
        url = resolve_archive_stream(archive_id)
        if not url:
            continue
        label = '[Archive.org] %s' % doc_title
        if doc_year:
            label += ' (%s)' % doc_year
        results.append({'label': label, 'url': url, 'source': 'archive'})

    if _HAS_CACHE:
        _cache.set(ck, results, 6 * 3600)
    return results
