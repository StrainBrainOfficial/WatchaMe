# -*- coding: utf-8 -*-
"""
resources/lib/vidhide_bypass.py — direct bypass for the "VidHide"-family
embed-host template (mycloudz.cc, cloudwish.xyz, and any other mirror
running the same branded player) that javseen.tv (and likely javhd.today/
javleak.com, which share the same third-party embed-host pool) rotate
through.

Confirmed live 2026-08-04: this template's player-setup script is wrapped
in a plain Dean Edwards P.A.C.K.E.R. eval() — cosmetic minification, not
real anti-bot. A plain requests.get() sees it exactly as a browser would
and no JS execution is needed to unpack it. This is a fundamentally
different situation from hqq.to's /player/get_md5.php flow (another
javseen candidate host, checked and rejected this same session): that one
enforces genuine server-side bot detection (Adscore fingerprinting +
optional reCAPTCHA) and returns an explicit rejection ({"407":"1"}) for
any request lacking a real browser-computed token — not something to
build a bypass for.

Once unpacked, the script contains a plain `links` object with 2-3
directly playable HLS URLs (hls4/hls3/hls2, in the same priority order the
site's own player code uses). Confirmed live: the final CDN fetch succeeds
with zero request headers, no Referer needed.

Confirmed live 2026-08-06, via a real kodi.log report ("jav isnt
resolving"): the master.m3u8 these links point to fetches fine and looks
completely legitimate (real multi-bitrate #EXT-X-STREAM-INF entries,
real avc1/mp4a CODECS attributes) — but its variant sub-playlists'
actual segment URIs are NOT video segments at all. They point to
`*.tiktokcdn.com/.../*~tplv-*.image?...` — literally ad-creative images
from a TikTok ad CDN, dressed up as `#EXTINF` HLS segments. Kodi's player
happily opens the fake "stream", picks a PNG image codec for the first
"segment" (since that's genuinely what the bytes are), and hits EOF
immediately after — the exact "won't play" symptom reported. This is a
deliberate decoy aimed at exactly this kind of static bypass (the site's
real player JS presumably fetches the real manifest through some other,
harder-to-replicate authenticated call). _validate_not_decoy() below
fetches one level deeper and rejects any candidate whose first real
segment resolves to a known ad-CDN/non-video pattern, so a decoy host
gets correctly treated as unresolved (falls through to the next
candidate/resolver) instead of confidently handing back a guaranteed-
broken stream.
"""
import re
import xbmc

# Substrings seen in decoy ad-CDN segment URLs masquerading as HLS video
# segments (see module docstring). Deliberately substring-based rather than
# a strict domain allowlist, since the whole point is these are seen
# LIVE inside otherwise-legitimate-looking manifests from a legitimate
# video CDN (mycloudz.cc) — there's no single trusted domain to allowlist.
_RE_DECOY_SEGMENT = re.compile(r'tiktokcdn\.com|\.image(?:\?|$)', re.IGNORECASE)


def _looks_like_decoy(playlist_text):
    """True if a media (non-master) HLS playlist's segment lines look like
    the ad-image decoy content described in this module's docstring,
    rather than real video segments."""
    for line in playlist_text.splitlines():
        line = line.strip()
        if line and not line.startswith('#'):
            return bool(_RE_DECOY_SEGMENT.search(line))
    return False

_HEADERS = {
    'User-Agent': ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
                   '(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'),
}

_RE_PACKER = re.compile(
    r"eval\(function\(p,a,c,k,e,d\)\{.*?\}\('(.*)',(\d+),(\d+),'(.*?)'\.split\('\|'\)",
    re.DOTALL
)
_RE_LINK = {
    'hls4': re.compile(r'"hls4":"([^"]+)"'),
    'hls3': re.compile(r'"hls3":"([^"]+)"'),
    'hls2': re.compile(r'"hls2":"([^"]+)"'),
}


def _unpack(payload, radix, count, keywords):
    """Standard P.A.C.K.E.R. decode: each base-`radix` token in the payload
    is a dictionary index into `keywords` (pipe-separated, sparse — empty
    slots mean 'leave the token as-is')."""
    words = keywords.split('|')
    digits = '0123456789abcdefghijklmnopqrstuvwxyz'

    def to_base(num):
        if num == 0:
            return '0'
        s = ''
        while num:
            s = digits[num % radix] + s
            num //= radix
        return s

    p = payload
    for c in range(count - 1, -1, -1):
        if c < len(words) and words[c]:
            token = to_base(c)
            repl = words[c]
            p = re.sub(r'\b' + re.escape(token) + r'\b', lambda m, r=repl: r, p)
    return p


def _is_decoy_master(master_url, referer):
    """Fetch one level deeper than the master playlist -- its first variant
    sub-playlist -- and check whether ITS segments are the ad-image decoy
    content described in this module's docstring. The master itself always
    looks legitimate (real #EXT-X-STREAM-INF/CODECS entries); only the
    actual segment URIs one level down give the decoy away."""
    try:
        import requests
        r = requests.get(master_url, headers=_HEADERS, timeout=10)
        if r.status_code != 200:
            return True
        master_text = r.text
    except Exception as e:
        xbmc.log('[Starfleet/VidHideBypass] decoy-check master fetch error: %s' % e, xbmc.LOGWARNING)
        return True

    variant_line = next(
        (l.strip() for l in master_text.splitlines() if l.strip() and not l.startswith('#')),
        None
    )
    if not variant_line:
        return True
    if variant_line.startswith('http'):
        variant_url = variant_line
    else:
        variant_url = master_url.rsplit('/', 1)[0] + '/' + variant_line

    try:
        import requests
        rv = requests.get(variant_url, headers=_HEADERS, timeout=10)
        if rv.status_code != 200:
            return True
        return _looks_like_decoy(rv.text)
    except Exception as e:
        xbmc.log('[Starfleet/VidHideBypass] decoy-check variant fetch error: %s' % e, xbmc.LOGWARNING)
        return True


def try_resolve(embed_url):
    """Returns a directly-playable .m3u8 URL, or '' if this embed page
    isn't running the VidHide-family template (or none of its candidate
    links contain '.m3u8' — the addon's own play handlers key off that
    substring to decide whether to attach inputstream.adaptive, so a link
    without it, e.g. a stray hls3 '.txt' variant, is treated as a miss
    here rather than risk a raw-file playback attempt elsewhere).

    Returns a Kodi pipe-tagged 'url|Referer=...&User-Agent=...' string, NOT
    a bare URL — same header-passthrough convention already used by
    mythav_sources.py's helvid.com chain, so inputstream.adaptive and
    Kodi's native player carry the same Referer/User-Agent on every
    manifest/segment fetch that this function itself used to validate the
    candidate. Not the actual fix for the "won't play" report (see module
    docstring for the real root cause — decoy ad-image segments), but
    correct hygiene regardless and confirmed not to break anything (all
    three callers already just do `.m3u8 in resolved_url.lower()` then
    hand the whole string to ListItem(path=...))."""
    try:
        import requests
        r = requests.get(embed_url, headers=_HEADERS, timeout=15)
        if r.status_code != 200:
            return ''
        html = r.text
    except Exception as e:
        xbmc.log('[Starfleet/VidHideBypass] fetch error %s: %s' % (embed_url[:80], e), xbmc.LOGWARNING)
        return ''

    m = _RE_PACKER.search(html)
    if not m:
        return ''
    try:
        js = _unpack(m.group(1), int(m.group(2)), int(m.group(3)), m.group(4))
    except Exception as e:
        xbmc.log('[Starfleet/VidHideBypass] unpack error: %s' % e, xbmc.LOGWARNING)
        return ''

    import urllib.parse
    parsed = urllib.parse.urlparse(embed_url)
    origin = '%s://%s' % (parsed.scheme, parsed.netloc)

    for key in ('hls4', 'hls3', 'hls2'):
        lm = _RE_LINK[key].search(js)
        if not lm:
            continue
        link = lm.group(1)
        if link.startswith('/'):
            link = origin + link
        if '.m3u8' in link.lower():
            if _is_decoy_master(link, embed_url):
                xbmc.log('[Starfleet/VidHideBypass] rejected decoy manifest (%s) for %s'
                          % (key, embed_url[:60]), xbmc.LOGWARNING)
                continue
            return '%s|Referer=%s&User-Agent=%s' % (
                link,
                urllib.parse.quote(embed_url, safe=''),
                urllib.parse.quote(_HEADERS['User-Agent'], safe=''),
            )
    return ''
