# -*- coding: utf-8 -*-
"""Glue between this add-on's Premium Services settings and the Starfleet resolver's debrid accounts
(script.module.starfleetresolve.debrid): pairing with the add-on's own QR dialog, token sync both ways, and
link unrestrict for the services the add-on had no code for (Offcloud, Debrid-Link).

Settings keys per service (token / enabled):
    realdebrid rd_api_key rd_enabled    alldebrid ad_api_key ad_enabled    premiumize pm_api_key pm_enabled
    torbox     tb_api_key tb_enabled    debridlink dl_api_key dl_enabled   offcloud  oc_api_key oc_enabled"""
import xbmc
import xbmcaddon
import xbmcgui

ADDON = xbmcaddon.Addon('plugin.video.starfleet')

KEYS = {
    'realdebrid': ('rd_api_key', 'rd_enabled', 'Real-Debrid'),
    'alldebrid':  ('ad_api_key', 'ad_enabled', 'AllDebrid'),
    'premiumize': ('pm_api_key', 'pm_enabled', 'Premiumize'),
    'torbox':     ('tb_api_key', 'tb_enabled', 'TorBox'),
    'debridlink': ('dl_api_key', 'dl_enabled', 'Debrid-Link'),
    'offcloud':   ('oc_api_key', 'oc_enabled', 'Offcloud'),
}

_synced = [False]


def _mod():
    try:
        from starfleetresolve import debrid
        return debrid
    except Exception:
        return None


def available():
    return _mod() is not None


def _setting(k):
    try:
        return (ADDON.getSetting(k) or '').strip()
    except Exception:
        return ''


def sync(force=False):
    """Make the add-on's settings and the resolver's account store agree. A key typed into Settings reaches the
    resolver; an account paired through the resolver shows up in Settings (and switches the service on)."""
    if _synced[0] and not force:
        return
    d = _mod()
    if d is None:
        return
    _synced[0] = True
    try:
        d.authorized()                    # first use: accounts paired in ResolveURL are brought over
    except Exception:
        pass
    from starfleetresolve.debrid import store
    for sid, (tkey, ekey, _name) in KEYS.items():
        try:
            mine = _setting(tkey)
            rec = store.get(sid)
            theirs = rec.get('token', '')
            if mine and not theirs:
                store.put(sid, token=mine)                       # typed / older pairing -> resolver
            elif theirs and not mine:
                ADDON.setSetting(tkey, theirs)                    # paired in the resolver -> settings
                if ADDON.getSetting(ekey) != 'true':
                    ADDON.setSetting(ekey, 'true')
        except Exception as e:
            xbmc.log('[Starfleet/Debrid] sync %s: %s' % (sid, e), xbmc.LOGINFO)


def adopt(sid):
    """The resolver's account for `sid` becomes the add-on's own one: its token replaces whatever the Settings field held (a
    pairing done a second time leaves a token there that the service no longer accepts) and the service is switched on."""
    if sid not in KEYS:
        return
    d = _mod()
    if d is None:
        return
    try:
        from starfleetresolve.debrid import store
        theirs = store.get(sid).get('token', '')
        tkey, ekey, _name = KEYS[sid]
        if theirs:
            if _setting(tkey) != theirs:
                ADDON.setSetting(tkey, theirs)
            if ADDON.getSetting(ekey) != 'true':
                ADDON.setSetting(ekey, 'true')
    except Exception as e:
        xbmc.log('[Starfleet/Debrid] adopt %s: %s' % (sid, e), xbmc.LOGINFO)


def token(sid):
    """Currently valid token for `sid` (refreshed when the service issues short-lived ones); falls back to the setting."""
    d = _mod()
    if d is not None:
        try:
            sync()
            t = d.service(sid).token()
            if t:
                return t
        except Exception:
            pass
    return _setting(KEYS[sid][0]) if sid in KEYS else ''


def enabled(sid):
    return ADDON.getSetting('use_debrid') != 'false' and ADDON.getSetting(KEYS[sid][1]) == 'true' and bool(token(sid))


def unrestrict(sid, url):
    d = _mod()
    if d is None:
        return None
    try:
        sync()
        return d.service(sid).unrestrict(url)
    except Exception as e:
        xbmc.log('[Starfleet/Debrid] %s unrestrict: %s' % (sid, e), xbmc.LOGWARNING)
        return None


class _PairUI(object):
    """The add-on's QR dialog (falls back to a text progress dialog)."""

    def __init__(self, name):
        self.name = name
        self._qr = None
        self._txt = None

    def start(self, info):
        msg = 'Scan, or go to %s and enter code: %s' % (info.get('display_url') or info['url'], info['code'])
        try:
            from resources.lib.gui import qr_dialog as _q
            path = _q.make_qr(info['url'], 'starfleet_debrid_qr.png')
            if path:
                self._qr = _q.QRDialog(path, 'Pair with %s' % self.name,
                                       'Scan, or go to %s' % (info.get('display_url') or info['url']), code=info['code'])
                self._qr.show()
                return
        except Exception:
            self._qr = None
        self._txt = xbmcgui.DialogProgress()
        self._txt.create('Starfleet - Pair with %s' % self.name, msg)
        self._msg = msg

    def update(self, pct, info, remaining):
        if self._qr is not None:
            self._qr.update('Waiting for you to approve... (%ds)' % remaining)
        elif self._txt is not None:
            self._txt.update(max(1, min(99, pct)), self._msg)

    def cancelled(self):
        if self._qr is not None:
            return self._qr.iscanceled()
        return self._txt.iscanceled() if self._txt is not None else False

    def close(self):
        try:
            (self._qr or self._txt).close()
        except Exception:
            pass


def pair(sid):
    """Pair `sid` through the Starfleet resolver. True when an account is stored (and mirrored into Settings)."""
    d = _mod()
    if d is None or sid not in KEYS:
        return False
    name = KEYS[sid][2]
    ok = d.pair(sid, ui=_PairUI(name))
    if ok:
        sync(force=True)
        adopt(sid)
        try:
            acct = d.service(sid).account()
        except Exception:
            acct = {}
        xbmcgui.Dialog().notification('Starfleet', '%s paired%s' % (name, (' (%s)' % acct['user']) if acct.get('user') else ''),
                                      xbmcgui.NOTIFICATION_INFO, 4000)
    else:
        xbmcgui.Dialog().notification('Starfleet', 'Pairing was not completed', xbmcgui.NOTIFICATION_WARNING, 4000)
    return ok
