# -*- coding: utf-8 -*-
"""
resources/lib/diagnostics.py

"Why isn't this working?" - Settings > General. Runs a set of quick checks side by side and shows a plain-language verdict:
what is fine, what is wrong, and what to do about it. The same text is saved to diagnostics.txt in the add-on's data folder
so it can be sent along when asking for help.

Checks: add-on versions against the repository, Kodi / device, the clock, internet reach of the main services, the local relay,
free space and a writable profile, paired accounts (SIMKL / Trakt asked live), debrid / Elementum, the sports data feeds,
required Kodi components, and recent Starfleet errors from kodi.log.

Each check is a function returning a list of (level, text, hint) rows, level being 'ok' | 'warn' | 'fail' | 'info'. A check
that itself breaks is reported as a warning, never raised. Nothing here changes any setting.
"""
import os
import re
import time
from concurrent.futures import ThreadPoolExecutor

import xbmc

REPO_URL = 'https://hazmat77.github.io/repository.starfleet/addons.xml'
_ADDONS = (('plugin.video.starfleet', 'Starfleet'), ('script.module.starfleetscrapers', 'Starfleet Scrapers'),
           ('script.module.starfleetresolve', 'Starfleet Resolver'))
_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'


def _addon():
    import xbmcaddon
    return xbmcaddon.Addon('plugin.video.starfleet')


def _http(url, timeout=8, **kw):
    import requests
    t = time.time()
    r = requests.get(url, headers={'User-Agent': _UA}, timeout=timeout, **kw)
    return r, time.time() - t


def _ver_tuple(v):
    return tuple(int(x) for x in re.findall(r'\d+', v or '')[:4])


def _installed_version(addon_id):
    try:
        import xbmcaddon
        return xbmcaddon.Addon(addon_id).getAddonInfo('version')
    except Exception:
        return ''


# ── individual checks ───────────────────────────────────────────────────────────────────────────────────────────────

def check_versions():
    rows = []
    try:
        r, dt = _http(REPO_URL)
        r.raise_for_status()
        live = dict(re.findall(r'<addon id="([^"]+)"[^>]*?version="([^"]+)"', r.text, re.S))
    except Exception as e:
        live = {}
        rows.append(('warn', 'Could not read the Starfleet repository (%s)' % type(e).__name__,
                     'Check the internet connection; updates cannot be found until it works.'))
    for aid, name in _ADDONS:
        mine = _installed_version(aid)
        if not mine:
            rows.append(('fail', '%s is not installed' % name, 'Install it from the Starfleet repository.'))
        elif live.get(aid) and _ver_tuple(live[aid]) > _ver_tuple(mine):
            rows.append(('warn', '%s %s - update %s is available' % (name, mine, live[aid]),
                         'Update it: Kodi > Add-ons > My add-ons, or use "Check helper add-ons" in Settings.'))
        else:
            rows.append(('ok', '%s %s%s' % (name, mine, ' (latest)' if live.get(aid) else ''), ''))
    return rows


def check_kodi():
    rows = []
    try:
        build = xbmc.getInfoLabel('System.BuildVersion') or 'unknown'
        osinfo = xbmc.getInfoLabel('System.OSVersionInfo') or ''
        rows.append(('info', 'Kodi %s%s' % (build.split(' ')[0], (' on ' + osinfo) if osinfo else ''), ''))
    except Exception:
        pass
    try:
        free = xbmc.getInfoLabel('System.FreeSpace')
        if free:
            m = re.search(r'([\d.]+)\s*(GB|MB|KB)', free.replace(',', ''), re.I)
            gb = float(m.group(1)) * {'GB': 1, 'MB': 1 / 1024.0, 'KB': 1 / 1048576.0}[m.group(2).upper()] if m else None
            if gb is not None and gb < 0.3:
                rows.append(('fail', 'Only %s of free storage' % free, 'Free some space: Kodi cannot save its cache or settings.'))
            elif gb is not None and gb < 1:
                rows.append(('warn', '%s of free storage' % free, 'Getting low; clear the cache or remove unused add-ons.'))
            else:
                rows.append(('ok', '%s of free storage' % free, ''))
    except Exception:
        pass
    for aid, label, why in (('inputstream.adaptive', 'InputStream Adaptive', 'Needed to play HLS live streams.'),):
        try:
            if xbmc.getCondVisibility('System.HasAddon(%s)' % aid):
                rows.append(('ok', '%s is installed' % label, ''))
            else:
                rows.append(('warn', '%s is not installed' % label, why + ' Install it from Kodi\'s add-on browser.'))
        except Exception:
            pass
    return rows


def check_profile():
    try:
        import xbmcvfs
        d = xbmcvfs.translatePath(_addon().getAddonInfo('profile'))
        os.makedirs(d, exist_ok=True)
        p = os.path.join(d, '.diag_write_test')
        with open(p, 'w') as f:
            f.write('ok')
        os.remove(p)
        return [('ok', 'Settings and cache folder is writable', '')]
    except Exception as e:
        return [('fail', 'Cannot write to the add-on data folder (%s)' % str(e)[:60],
                 'Settings, history and the cache cannot be saved. Check the storage and its permissions.')]


def check_clock():
    """Device time against the server's: a wrong clock breaks HTTPS and signed stream links."""
    try:
        r, dt = _http(REPO_URL, timeout=8)
        d = r.headers.get('Date')
        if not d:
            return []
        from email.utils import parsedate_to_datetime
        import calendar
        server = calendar.timegm(parsedate_to_datetime(d).utctimetuple())
        drift = abs(time.time() - dt / 2.0 - server)
        tz = time.tzname[1 if time.localtime().tm_isdst > 0 and len(time.tzname) > 1 else 0] if time.tzname else ''
        if drift > 300:
            return [('fail', 'The device clock is off by %d minutes' % (drift // 60),
                     'Set the date, time and time zone correctly (automatic network time is best): streams and secure sites fail otherwise.')]
        return [('ok', 'Clock is correct (time zone %s)' % tz, '')]
    except Exception:
        return []


def _probe(label, url, hint, timeout=8):
    try:
        r, dt = _http(url, timeout=timeout)
        if r.status_code < 400:
            return ('ok', '%s reachable (%.1fs)' % (label, dt), '')
        return ('warn', '%s answered HTTP %d' % (label, r.status_code), hint)
    except Exception as e:
        return ('fail', '%s not reachable (%s)' % (label, type(e).__name__), hint)


def check_internet():
    def _tmdb():
        # through the plugin's own TMDB client (it carries the API key), not a bare request
        t = time.time()
        try:
            from resources.lib import metadata as meta
            meta._tmdb_get('/configuration', {})
            return ('ok', 'TMDB (posters and details) reachable (%.1fs)' % (time.time() - t), '')
        except Exception as e:
            return ('fail', 'TMDB (posters and details) not reachable (%s)' % type(e).__name__,
                    'Metadata will be missing; check DNS, the TMDB key in Settings, or a blocking router / VPN.')
    targets = (
        lambda: _probe('Starfleet repository', 'https://hazmat77.github.io/repository.starfleet/addons.xml',
                       'Without it, add-on updates cannot be found.'),
        _tmdb,
        lambda: _probe('Live scores (ESPN)', 'https://site.api.espn.com/apis/site/v2/sports/basketball/nba/scoreboard',
                       'Scores and alerts will not work.'),
    )
    with ThreadPoolExecutor(max_workers=len(targets)) as pool:
        out = list(pool.map(lambda f: f(), targets))
    if all(r[0] == 'fail' for r in out):
        return [('fail', 'No internet connection reaches any service', 'Check the network, DNS or VPN on this device.')]
    return out


def check_relay():
    try:
        from starfleetscrapers.sports import local_proxy as lp
        if lp._service_reachable():
            return [('ok', 'Local stream relay is running (port %d)' % lp._PORT, '')]
        return [('warn', 'Local stream relay is not running', 'Some live streams need it. Restart Kodi so the Starfleet service starts.')]
    except Exception as e:
        return [('warn', 'Could not check the local stream relay (%s)' % type(e).__name__, '')]


def check_accounts():
    rows = []
    a = _addon()

    def has(k):
        return bool((a.getSetting(k) or '').strip())
    from resources.lib import simkl_auth, trakt_auth, wetrakr_auth
    for name, mod in (('SIMKL', simkl_auth), ('Trakt', trakt_auth)):
        try:
            if not mod.is_paired():
                rows.append(('info', '%s: not paired' % name, ''))
                continue
            state, who = mod._verify()
            if state == 'ok':
                rows.append(('ok', '%s paired%s and working' % (name, (' as ' + who) if who else ''), ''))
            elif state == 'rejected':
                rows.append(('fail', '%s no longer accepts the saved pairing' % name,
                             'Settings > Premium Services > Unpair %s, then Pair again.' % name))
            else:
                rows.append(('warn', '%s paired (could not reach it to confirm)' % name, ''))
        except Exception as e:
            rows.append(('warn', '%s check failed (%s)' % (name, type(e).__name__), ''))
    try:
        if wetrakr_auth.token_rejected():
            rows.append(('fail', 'WeTrakr rejected the saved pairing', 'Settings > Premium Services > Unpair WeTrakr, then Pair again.'))
        elif wetrakr_auth.is_paired():
            rows.append(('ok', 'WeTrakr paired', ''))
        else:
            rows.append(('info', 'WeTrakr: not paired', ''))
    except Exception:
        pass
    try:
        from resources.lib import resolvers
        if resolvers.any_debrid_enabled():
            names = [n for n, on in (('Real-Debrid', resolvers._rd_on), ('AllDebrid', resolvers._ad_on),
                                     ('Premiumize', resolvers._pm_on), ('TorBox', resolvers._tb_on)) if on()]
            rows.append(('ok', 'Debrid: %s' % (', '.join(names) or 'enabled'), ''))
        elif resolvers.elementum_enabled():
            rows.append(('info', 'No debrid service paired; torrents play through Elementum', 'A debrid service gives instant, reliable torrent playback.'))
        else:
            rows.append(('warn', 'No debrid service paired and Elementum is off', 'Torrent sources cannot play. Pair a debrid service or turn Elementum on in Settings.'))
    except Exception:
        pass
    return rows


def check_sports():
    rows = []
    try:
        from starfleetscrapers.sports import sports_pages_live as P
        feeds = (('pv', 'PPV'), ('dm', 'DAMITV'), ('au', 'Aura Sports'))
        ok = 0
        for code, label in feeds:
            try:
                n = len(P._rows(code, '*'))
                if n:
                    ok += 1
                rows.append(('ok' if n else 'info', '%s feed: %d games listed' % (label, n), ''))
            except Exception as e:
                rows.append(('warn', '%s feed failed (%s)' % (label, type(e).__name__), ''))
        if not ok:
            rows.append(('warn', 'No sports feed returned games', 'Quiet hours are normal; if games are on, check the internet and update the Starfleet Scrapers add-on.'))
    except Exception as e:
        rows.append(('warn', 'Could not check the sports feeds (%s)' % type(e).__name__, ''))
    return rows


def check_sources():
    """Torrent sources the add-on has left out because they kept coming back empty or late (starfleetscrapers source_health)."""
    rows = []
    try:
        from starfleetscrapers.debrid import source_health
        off = source_health.disabled()
        if not off:
            rows.append(('ok', 'All torrent sources are in use', ''))
        else:
            for name, left in sorted(off.items()):
                rows.append(('info', '%s is switched off for about %d more hours (it kept finding nothing)' % (name, max(1, left // 3600)),
                             'It gets another try by itself; Settings > Sources > "Switch all sources back on" tries it now.'))
    except Exception as e:
        rows.append(('info', 'Source health is not available (%s)' % type(e).__name__, 'Update the Starfleet Scrapers add-on.'))
    return rows


def check_log():
    """Recent Starfleet errors from kodi.log (the last ~400 KB)."""
    try:
        import xbmcvfs
        path = xbmcvfs.translatePath('special://logpath/kodi.log')
        size = os.path.getsize(path)
        with open(path, 'rb') as f:
            f.seek(max(0, size - 400000))
            text = f.read().decode('utf-8', 'replace')
    except Exception:
        return [('info', 'kodi.log could not be read', '')]
    seen, rows = {}, []
    for line in text.splitlines():
        if 'Starfleet' not in line and 'StarfleetResolve' not in line:
            continue
        if ' error ' not in line.lower() and 'ERROR' not in line and 'Traceback' not in line and ' warning ' not in line.lower():
            continue
        msg = re.sub(r'^.*?(?:error|warning)\s*<general>:\s*', '', line, flags=re.I)[:140]
        msg = re.sub(r'\d{2}:\d{2}:\d{2}[.\d]*', '', msg).strip()
        sev = 'fail' if re.search(r'\berror\b|Traceback', line, re.I) and ' warning ' not in line.lower() else 'warn'
        seen.setdefault(msg, [sev, 0])[1] += 1
    errs = sorted(((v[1], v[0], m) for m, v in seen.items() if v[0] == 'fail'), reverse=True)[:4]
    if not errs:
        return [('ok', 'No recent Starfleet errors in the Kodi log', '')]
    for n, sev, m in errs:
        rows.append(('warn', 'Log: %s%s' % (m, (' (x%d)' % n) if n > 1 else ''), ''))
    return rows


_CHECKS = (('Add-on versions', check_versions), ('Kodi and device', check_kodi), ('Storage', check_profile),
           ('Clock', check_clock), ('Internet', check_internet), ('Stream relay', check_relay),
           ('Accounts', check_accounts), ('Torrent sources', check_sources), ('Sports feeds', check_sports),
           ('Recent errors', check_log))

_TAG = {'ok': ('[OK]', 'FF66CC66'), 'warn': ('[!]', 'FFFFCC33'), 'fail': ('[X]', 'FFFF5555'), 'info': ('[i]', 'FF9999AA')}


def run_checks(progress=None, budget=40.0):
    """[(section title, rows)] in display order. `progress(done, total, title)` is called as checks finish."""
    pool = ThreadPoolExecutor(max_workers=6)
    futs = [(title, pool.submit(fn)) for title, fn in _CHECKS]
    pool.shutdown(wait=False)
    t0 = time.time()
    results = []
    for i, (title, fut) in enumerate(futs):
        left = max(0.5, budget - (time.time() - t0))
        try:
            rows = fut.result(timeout=left)
        except Exception as e:
            rows = [('warn', '%s check did not finish (%s)' % (title, type(e).__name__), '')]
        results.append((title, rows))
        if progress:
            progress(i + 1, len(futs), title)
    return results


def verdict(results):
    """(headline, [problem rows]) - the short answer to 'is anything wrong?'."""
    fails = [(t, r) for t, rows in results for r in rows if r[0] == 'fail']
    warns = [(t, r) for t, rows in results for r in rows if r[0] == 'warn']
    if fails:
        return '%d problem%s need attention' % (len(fails), '' if len(fails) == 1 else 's'), fails + warns
    if warns:
        return 'Working, with %d thing%s worth a look' % (len(warns), '' if len(warns) == 1 else 's'), warns
    return 'Everything looks good', []


def format_report(results, colour=True):
    head, problems = verdict(results)

    def tag(level):
        t, c = _TAG[level]
        return '[COLOR %s]%s[/COLOR]' % (c, t) if colour else t
    lines = ['%s' % (('[B]%s[/B]' % head) if colour else head), '']
    if problems:
        lines.append('What to do:')
        for sec, (level, text, hint) in problems:
            lines.append('  %s %s' % (tag(level), text))
            if hint:
                lines.append('      -> %s' % hint)
        lines.append('')
    for title, rows in results:
        lines.append(('[B]%s[/B]' % title) if colour else title)
        for level, text, hint in rows:
            lines.append('  %s %s' % (tag(level), text))
        lines.append('')
    lines.append('Checked %s' % time.strftime('%Y-%m-%d %H:%M'))
    return '\n'.join(lines)


def run():
    """Settings action: progress dialog -> report window. Also saves diagnostics.txt next to the settings."""
    import xbmcgui
    import xbmcvfs
    from resources.lib.gui import progress_dialog as _pdlg
    dlg = _pdlg.DialogProgress()
    dlg.create('Starfleet', 'Checking your setup...')

    def _prog(done, total, title):
        try:
            dlg.update(int(done * 100 / total), 'Checked: %s' % title)
        except Exception:
            pass
    try:
        results = run_checks(_prog)
    finally:
        dlg.close()
    try:
        d = xbmcvfs.translatePath(_addon().getAddonInfo('profile'))
        with open(os.path.join(d, 'diagnostics.txt'), 'w', encoding='utf-8') as f:
            f.write(format_report(results, colour=False))
    except Exception as e:
        xbmc.log('[Starfleet/Diagnostics] could not save report: %s' % e, xbmc.LOGWARNING)
    xbmcgui.Dialog().textviewer('Starfleet - Why isn\'t this working?', format_report(results))
