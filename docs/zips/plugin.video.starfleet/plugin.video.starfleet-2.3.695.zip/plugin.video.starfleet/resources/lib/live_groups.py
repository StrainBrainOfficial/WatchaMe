"""Manage groups for Free Live TV: which groups / countries of every free live source are shown.

A group is hidden by key ("<source>|<group>"); the choice is kept per profile (profiles.hidden_live_groups) and applied where the
group lists are built (router._add_dir), so Kodi and HazMat TV hide the same things. The catalogue of groups is gathered by
asking each source for its group list once (collect), then kept for a day.
"""
import json
import os
import threading
import time

_FILE = 'live_groups_catalog.json'
_MAX_AGE = 24 * 3600
_COLLECTING = False          # while the catalogue is gathered nothing is hidden
_OWNER = [0]                 # the thread gathering it: only that thread's directory calls are captured, any other thread lists as usual
_COLLECT_LOCK = threading.Lock()


def key_for(action, params):
    """The key of a group / country list entry built with these params, or '' when the entry is not one."""
    if not action or not action.startswith('live_'):
        return ''
    if action == 'live_iptvorg_country':
        return 'iptvorg|%s' % params.get('cc', '')
    if action == 'live_iptvorg_group':
        return ''                                   # the groups inside a country follow the country
    if action.endswith('_group') and params.get('group'):
        return '%s|%s' % (action[5:-6], params['group'])
    return ''


def hidden():
    try:
        from resources.lib import profiles as _pf
        return set(_pf.hidden_live_groups())
    except Exception:
        return set()


def is_hidden(action, params):
    if _COLLECTING and threading.get_ident() == _OWNER[0]:
        return False
    k = key_for(action, params)
    return bool(k) and k in hidden()


def set_hidden(key, value):
    from resources.lib import profiles as _pf
    cur = set(_pf.hidden_live_groups())
    if value:
        cur.add(key)
    else:
        cur.discard(key)
    _pf.update(_pf.active_id(), hidden_live_groups=sorted(cur))


def reset():
    from resources.lib import profiles as _pf
    _pf.update(_pf.active_id(), hidden_live_groups=[])


def _path():
    try:
        from resources.lib import profiles as _pf
        return os.path.join(_pf.base_dir(), _FILE)
    except Exception:
        return os.path.join(os.path.expanduser('~'), _FILE)


def collect(force=False):
    """Every group / country the free live sources list: [{'key','source','label'}]. Asks each source once (network), cached for a day."""
    path = _path()
    if not force:
        try:
            with open(path, encoding='utf-8') as f:
                data = json.load(f)
            if time.time() - data.get('ts', 0) < _MAX_AGE and data.get('items'):
                return data['items']
        except Exception:
            pass
    import xbmcplugin
    from urllib.parse import urlparse, parse_qs
    from resources.lib import router as _r

    found = {}
    real_add = xbmcplugin.addDirectoryItem
    real_set = getattr(xbmcplugin, 'setPluginCategory', None)

    def grab(handle, url, listitem=None, isFolder=False, *a, **kw):
        if threading.get_ident() != _OWNER[0]:
            return real_add(handle, url, listitem, isFolder, *a, **kw)
        try:
            q = {k: v[0] for k, v in parse_qs(urlparse(url).query).items()}
            act = q.get('action', '')
            k = key_for(act, q)
            if k:
                label = ''
                try:
                    label = listitem.getLabel()
                except Exception:
                    pass
                found.setdefault(k, {'key': k, 'source': act[5:].replace('_group', '').replace('_country', ''), 'label': label or q.get('group') or q.get('cc', '')})
        except Exception:
            pass
        return True

    def build_url(params):
        from urllib.parse import urlencode
        return 'plugin://plugin.video.starfleet/?' + urlencode(params)

    class _Quiet(object):
        def create(self, *a, **k): pass
        def update(self, *a, **k): pass
        def close(self, *a, **k): pass
        def iscanceled(self): return False

    global _COLLECTING
    _COLLECT_LOCK.acquire()
    saved = {n: getattr(xbmcplugin, n, None) for n in ('setContent', 'setPluginCategory', 'addSortMethod', 'endOfDirectory', 'addDirectoryItems')}
    real_loading = _r._loading
    _OWNER[0] = threading.get_ident()
    _COLLECTING = True
    xbmcplugin.addDirectoryItem = grab
    def _guard(orig):
        def f(*a, **k):
            return None if threading.get_ident() == _OWNER[0] else (orig(*a, **k) if orig else None)
        return f
    for n in saved:
        setattr(xbmcplugin, n, _guard(saved[n]))
    _r._loading = lambda msg='', _orig=real_loading: _Quiet() if threading.get_ident() == _OWNER[0] else _orig(msg)
    try:
        for action, _label, _plot in _r.LIVE_SOURCES_MENU:
            fn = getattr(_r, 'list_' + action, None)
            if not fn or not action.startswith('live_'):
                continue
            try:
                fn(-1, build_url)
            except Exception:
                continue
    finally:
        _COLLECTING = False
        xbmcplugin.addDirectoryItem = real_add
        _r._loading = real_loading
        for n, f in saved.items():
            if f is not None:
                setattr(xbmcplugin, n, f)
        _OWNER[0] = 0
        _COLLECT_LOCK.release()
    items = sorted(found.values(), key=lambda x: (x['source'], x['label'].lower()))
    try:
        with open(path, 'w', encoding='utf-8') as f:
            json.dump({'ts': time.time(), 'items': items}, f)
    except Exception:
        pass
    return items


def catalog_json(force=False):
    """For the apps: [{'key','source','label','hidden'}]."""
    hid = hidden()
    return json.dumps([dict(i, hidden=i['key'] in hid) for i in collect(force)])


def manage_dialog():
    """Kodi: tick the groups to show (a tick = shown). Everything unticked is hidden for the active profile."""
    import xbmcgui
    dlg = xbmcgui.DialogProgress()
    dlg.create('Starfleet', 'Reading the group lists of the free live TV sources...')
    try:
        items = collect()
    finally:
        dlg.close()
    if not items:
        xbmcgui.Dialog().notification('Starfleet', 'No groups found - try again in a moment', xbmcgui.NOTIFICATION_WARNING)
        return
    hid = hidden()
    labels = ['%s  -  %s' % (i['source'].replace('_', ' ').title(), i['label']) for i in items]
    pre = [n for n, i in enumerate(items) if i['key'] not in hid]
    picked = xbmcgui.Dialog().multiselect('Manage groups - tick what to show', labels, preselect=pre)
    if picked is None:
        return
    shown = {items[n]['key'] for n in picked}
    known = {i['key'] for i in items}
    new_hidden = (hid - known) | (known - shown)
    from resources.lib import profiles as _pf
    _pf.update(_pf.active_id(), hidden_live_groups=sorted(new_hidden))
    xbmcgui.Dialog().notification('Starfleet', '%d groups shown, %d hidden' % (len(shown), len(known - shown)), xbmcgui.NOTIFICATION_INFO)


def manage_choice():
    """Manage groups: asks whether to manage the viewer's own IPTV groups or the free TV groups."""
    import xbmcgui
    n = xbmcgui.Dialog().select('Manage groups', ['Manage IPTV groups (my IPTV accounts)', 'Manage free TV groups'])
    if n == 0:
        from resources.lib import iptv_ui
        if iptv_ui.has_providers():
            iptv_ui.manage_categories()
        else:
            xbmcgui.Dialog().ok('IPTV', 'No IPTV account is linked yet. Add one in Settings > IPTV first.')
    elif n == 1:
        manage_dialog()
