# -*- coding: utf-8 -*-
"""
resources/lib/donate.py

"Support project" - Settings > Support project: pick a coin, then a QR code for the project's own deposit address for that coin is
shown (clean pre-rendered images in resources/media/qr, made from the address itself). No pairing, no account, no obligation - a
one-way display of a fixed address, not a live payment flow. The QR holds the plain address, so every wallet app can scan it.
Addresses were read from the wallet's own receive screens and checked against their shown start and end.
"""
import os
from collections import OrderedDict

COINS = OrderedDict([
    ('btc', {'label': 'Bitcoin (BTC)', 'address': 'bc1q6ufy4hkl2wgndn0y7srwcpgkjueenh9hplz4z6'}),
    ('eth', {'label': 'Ethereum (ETH)', 'address': '0x13D72a8078b8467B94efA5A27cA2B1598fD98f0a'}),
    ('ltc', {'label': 'Litecoin (LTC)', 'address': 'ltc1qwnl5h825fufhq0hhg92zdgvpnq2y6qpl20ejpr'}),
    ('doge', {'label': 'Dogecoin (DOGE)', 'address': 'DLdZHseafLAfG8YfbQvjvN8P5j9yqDyzAA'}),
    ('bch', {'label': 'Bitcoin Cash (BCH)', 'address': 'bitcoincash:qpcqgzrqz9pu7vmd7kqe8ngtydxc5gpw2qrzd7gf9z'}),
    ('ada', {'label': 'Cardano (ADA)', 'address': 'addr1qyqxt3tcaus8w5xdsyc3yfn3lprpvyl3wquyh2wcx47f38qhm2ddt0d03rdawa5kp5uz4nyrd2wshdecp2xl6fzqgrvqdfz2dc'}),
    ('avax', {'label': 'Avalanche C-Chain (AVAX)', 'address': '0xb01a007Ff0f9E591FF37819eFA8d85718F1D1882'}),
    ('shib', {'label': 'Shiba Inu (SHIB, on Ethereum)', 'address': '0x13D72a8078b8467B94efA5A27cA2B1598fD98f0a'}),
])

_NOTES = {
    'shib': 'Send SHIB on the Ethereum network only.',
    'avax': 'Send AVAX on the Avalanche C-Chain network only.',
    'ada': 'Send ADA on the Cardano network only.',
}


def qr_file(coin_key):
    """Path of the pre-rendered QR image for a coin ('' when it is missing)."""
    path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'media', 'qr', '%s.png' % coin_key)
    return path if os.path.exists(path) else ''


def build_uri(coin_key, amount_str=''):
    """(text for the QR code, extra line to show with it): always the plain address, so any wallet app can scan it."""
    coin = COINS.get(coin_key)
    if not coin:
        return '', ''
    return coin['address'], _NOTES.get(coin_key, '')


def pick_coin():
    """Settings > Support project: choose the coin, then show its QR code."""
    import xbmcgui
    keys = list(COINS)
    n = xbmcgui.Dialog().select('Support project - choose a coin', [COINS[k]['label'] for k in keys])
    if n >= 0:
        show_donate_dialog(keys[n])


def show_donate_dialog(coin_key):
    """Shows the QR code and the address of one coin."""
    import xbmcgui

    coin = COINS.get(coin_key)
    if not coin:
        return
    uri, note = build_uri(coin_key)
    qr_path = qr_file(coin_key)
    if not qr_path:
        from resources.lib.gui import qr_dialog
        qr_path = qr_dialog.make_qr(uri, 'starfleet_donate_%s_qr.png' % coin_key)
    if not qr_path:
        xbmcgui.Dialog().textviewer(coin['label'], coin['address'] + chr(10) + chr(10) + note)
        return

    from resources.lib.gui.donate_dialog import DonateDialog
    dlg = DonateDialog(qr_path, coin['label'], coin['address'], note)
    dlg.doModal()
    del dlg
