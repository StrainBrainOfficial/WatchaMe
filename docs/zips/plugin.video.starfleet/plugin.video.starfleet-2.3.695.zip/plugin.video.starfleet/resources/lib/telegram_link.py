# -*- coding: utf-8 -*-
"""
resources/lib/telegram_link.py

Settings > General > "Pair Telegram": link this Kodi install to a Telegram account with a code (scan the QR code, press Start in the bot),
after which "Send Debug Log" delivers the redacted kodi.log straight to the developer's Telegram through the relay, with the sender's name
and a few words about the problem. The bot's token lives only in the relay; the add-on knows the relay's address and its own random code.
The same relay and code scheme as the HazMat TV app (TelegramLink.kt), so the developer sees both the same way.
"""
import json
import os
import time
import uuid
import xbmc
import xbmcgui
import xbmcvfs
import requests as _req

RELAY = 'https://hazmat-relay.hazmat-tv-aad5.workers.dev'
BOT = 'kuckointraderbot'

_MAX_LOG = 400 * 1024            # the newest part of the log is the part that matters
_UA = {'User-Agent': 'Starfleet-Kodi'}


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log('[Starfleet/Telegram] %s' % msg, level)


def _path():
    d = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.starfleet/')
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, 'telegram.json')


def _load():
    try:
        with open(_path(), 'r', encoding='utf-8') as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def _save(d):
    try:
        with open(_path(), 'w', encoding='utf-8') as f:
            json.dump(d, f)
    except Exception as e:
        _log('could not save: %s' % e, xbmc.LOGWARNING)


def code():
    d = _load()
    if not d.get('code'):
        d['code'] = uuid.uuid4().hex[:16]
        _save(d)
    return d['code']


def linked_name():
    return (_load().get('name') or '').strip() or None


def link_address():
    return 'https://t.me/%s?start=%s' % (BOT, code())


def unlink():
    _save({})


def poll():
    """True once the code was started in the bot (the name is kept); False while waiting or when the relay does not answer."""
    try:
        r = _req.get('%s/link' % RELAY, params={'code': code()}, headers=_UA, timeout=10)
        if r.status_code != 200:
            return False
        o = r.json()
        if o.get('linked'):
            d = _load()
            d['name'] = o.get('name') or 'linked'
            _save(d)
            return True
    except Exception as e:
        _log('poll: %s' % e)
    return False


def pair(offer=True):
    """Show the QR code and wait (up to ten minutes) for the Start press. True when linked. offer=True: if a Sync accounts backup is
    waiting for this Telegram account, offers to restore it."""
    from resources.lib.gui import qr_dialog as _q
    link = link_address()
    qr_path = _q.make_qr(link, 'starfleet_telegram_qr.png')
    if not qr_path:
        xbmcgui.Dialog().textviewer('Pair Telegram', 'Open this link on your phone and press Start:\n\n%s' % link)
        return poll()
    dlg = _q.QRDialog(qr_path, 'Pair Telegram', 'Scan the code with your phone, open it in Telegram and press Start.')
    dlg.show()
    mon = xbmc.Monitor()
    ok = False
    try:
        waited = 0
        while waited < 600 and not dlg.iscanceled() and not mon.abortRequested():
            if mon.waitForAbort(3):
                break
            waited += 3
            if poll():
                ok = True
                break
    finally:
        dlg.close()
    if ok:
        xbmcgui.Dialog().notification('Starfleet', 'Telegram paired as %s' % linked_name(), xbmcgui.NOTIFICATION_INFO, 4000)
        if offer:
            try:
                from resources.lib import account_sync as _as
                _as.offer_restore()
            except Exception as e:
                _log('offer_restore: %s' % e)
    return ok


_reported = set()


def _prop(name):
    """An Android system property (the device model and so on), '' when it cannot be read."""
    try:
        import subprocess
        return subprocess.run(['getprop', name], capture_output=True, text=True, timeout=3).stdout.strip()
    except Exception:
        return ''


def identity():
    """(info line, spec block) for a report: which app this is (the Starfleet Kodi add-on, the HazMat TV APK or the desktop app), its version and
    what it runs on. The info line is plain ASCII (it travels in an HTTP header); nothing here is personal (no addresses or serial numbers)."""
    import os
    import platform
    import sys
    ver = '?'
    try:
        import xbmcaddon
        ver = xbmcaddon.Addon('plugin.video.starfleet').getAddonInfo('version')
    except Exception:
        pass
    bridge = False
    try:
        import importlib.util
        bridge = importlib.util.find_spec('hazmat_bridge') is not None
    except Exception:
        pass
    android = bool(os.environ.get('ANDROID_ROOT')) or sys.platform == 'android'
    if bridge:
        kind = 'HazMat TV APK' if android else 'HazMat TV Desktop (%s)' % ('Windows' if sys.platform.startswith('win') else 'Linux')
    else:
        kind = 'Starfleet Kodi add-on'

    def lab(x):
        try:
            return (xbmc.getInfoLabel(x) or '').strip()
        except Exception:
            return ''
    kodi = lab('System.BuildVersion').split(' ')[0]
    osinfo = lab('System.OSVersionInfo')
    model = ' '.join(x for x in (_prop('ro.product.manufacturer'), _prop('ro.product.model')) if x) if android else ''
    mem = ''
    try:
        with open('/proc/meminfo') as f:
            for ln in f:
                if ln.startswith('MemTotal'):
                    mem = '%d MB' % (int(ln.split()[1]) // 1024)
                    break
    except Exception:
        mem = lab('System.Memory(total)')
    lines = ['App: %s %s' % (kind, ver)]
    if kind == 'Starfleet Kodi add-on':
        lines.append('Kodi: %s (%s)' % (kodi or '?', lab('System.FriendlyName') or 'unnamed device'))
    dev = model or lab('System.FriendlyName') or platform.node() or '?'
    lines.append('Device: %s' % dev)
    sysline = osinfo or platform.platform()
    if android and _prop('ro.build.version.release'):
        sysline += ' (Android %s, API %s)' % (_prop('ro.build.version.release'), _prop('ro.build.version.sdk'))
    lines.append('System: %s' % sysline)
    lines.append('CPU: %s, %s cores' % (platform.machine() or '?', os.cpu_count() or '?'))
    if mem:
        lines.append('Memory: %s total' % mem)
    res = lab('System.ScreenResolution')
    if res:
        lines.append('Screen: %s' % res)
    try:
        import shutil
        d = shutil.disk_usage(os.path.expanduser('~'))
        lines.append('Storage: %.1f GB free of %.1f GB' % (d.free / 1073741824.0, d.total / 1073741824.0))
    except Exception:
        pass
    info = ('%s %s - %s - %s' % (kind, ver, dev, osinfo or platform.system())).encode('ascii', 'ignore').decode()
    return info, '\n'.join(lines) + '\n'


def auto_report_on():
    """Settings > General > Report broken links (on unless switched off). Only ever used once Telegram is paired."""
    try:
        import xbmcaddon
        return xbmcaddon.Addon('plugin.video.starfleet').getSetting('telegram_auto_report') != 'false'
    except Exception:
        return True


def scrub(url):
    """A link with what belongs to the viewer taken out: no query string, no login in the address, no account segments of an IPTV path."""
    import re
    if url.startswith('magnet:'):
        return 'magnet:(torrent)'
    if url.startswith('nzb:'):
        return 'nzb:(usenet release)'
    base = url.split('|')[0].split('?')[0].split('#')[0]
    base = re.sub(r'^(\w+://)[^/@]+@', r'\1', base)
    return re.sub(r'/(live|movie|series)/[^/]+/[^/]+/', r'/\1/(account)/', base)[:300]


def report_broken(title, label, url, what, extra=''):
    """A source that did not work, sent to the developer when Telegram is paired (and Report broken links is on) so it can be looked at
    and fixed: the title, the site, the link without account details and what went wrong. The same failure goes once a day at most (the
    relay keeps the count too). Torrents and Usenet releases that are simply not cached, and the viewer's own IPTV, are not broken links."""
    try:
        url = url or ''
        if not linked_name() or not auto_report_on():
            return
        if url.startswith(('magnet:', 'nzb:')) or 'iptv' in (label or '').lower():
            return
        from urllib.parse import quote, urlparse
        host = (urlparse(url.split('|')[0]).hostname or '?').replace('www.', '')
        key = ('%s:%s:%s' % (host, what[:24], title))[:70]
        if key in _reported:
            return
        _reported.add(key)

        def _go():
            try:
                import re
                info, specs = identity()
                body = 'AUTO REPORT: a link did not work\nWhat: %s\nTitle: %s\nSource: %s\nSite: %s\nLink: %s\n%s\n%sTime: %s\n' % (
                    what, title, label, host, scrub(url), (extra or '')[:1500], specs, time.strftime('%Y-%m-%d %H:%M:%S'))
                _req.post('%s/log' % RELAY, data=body.encode('utf-8', 'ignore'), timeout=20,
                          headers={'X-Code': code(), 'X-Info': info.encode('ascii', 'ignore').decode(), 'X-Auto': '1',
                                   'X-Key': re.sub(r'[^A-Za-z0-9:._-]', '_', key),
                                   'X-Issue': quote(('%s - %s - %s' % (what, title, host))[:200]), 'Content-Type': 'text/plain', **_UA})
            except Exception as e:
                _log('auto report: %s' % e)
        import threading
        threading.Thread(target=_go, daemon=True, name='starfleet-auto-report').start()
    except Exception as e:
        _log('auto report: %s' % e)


def send_log(text, issue=''):
    """Sends the (already redacted) log through the relay. '' when it went; else a sentence about what failed."""
    if not linked_name():
        return 'Telegram is not linked'
    info, specs = identity()
    try:
        from urllib.parse import quote
        r = _req.post('%s/log' % RELAY, data=(specs + '\n' + text).encode('utf-8', 'ignore'), timeout=40,
                      headers={'X-Code': code(), 'X-Info': info.encode('ascii', 'ignore').decode(), 'X-Issue': quote(issue[:400]),
                               'Content-Type': 'text/plain', **_UA})
        if r.status_code == 200:
            return ''
        if r.status_code == 429:
            return 'Too many logs sent in the last hour - try again later'
        if r.status_code == 403:
            unlink()
            return 'This install is no longer linked - pair Telegram again'
        return 'The relay answered with an error (%s)' % r.status_code
    except Exception as e:
        return 'Could not reach the relay (%s)' % e


def send_debug_log():
    """The Send Debug Log flow. True when the log reached Telegram (False: not paired, cancelled or failed, so the caller falls back)."""
    dlg = xbmcgui.Dialog()
    if not linked_name():
        if not dlg.yesno('Send Debug Log', 'Telegram is not paired. Pair it now? Your log (keys and tokens removed) then goes straight to the '
                                           'developer on Telegram, with your name and a few words about the problem.',
                         nolabel='Use a link instead', yeslabel='Pair Telegram'):
            return False
        if not pair():
            return False
    issue = dlg.input('What went wrong? (a few words)', type=xbmcgui.INPUT_ALPHANUM)
    from resources.lib import debug_log as _dbg
    raw = _dbg._read_recent_log()
    if not raw:
        dlg.notification('Starfleet', 'Could not read the log file', xbmcgui.NOTIFICATION_ERROR, 4000)
        return True
    text = _dbg._redact(raw)[-_MAX_LOG:]
    busy = xbmcgui.DialogProgress()
    busy.create('Starfleet', 'Sending the log to Telegram...')
    try:
        fail = send_log(text, issue or '')
    finally:
        busy.close()
    if not fail:
        dlg.ok('Debug log', 'The log was sent to the developer on Telegram. Thank you - it will be looked at as soon as possible.')
        return True
    _log('send failed: %s' % fail, xbmc.LOGWARNING)
    dlg.notification('Starfleet', fail, xbmcgui.NOTIFICATION_ERROR, 5000)
    return False
