# -*- coding: utf-8 -*-
"""
service.py — Kodi background service entry point (xbmc.python.service,
start="startup" in addon.xml). Runs for the whole Kodi session, unlike
default.py's plugin:// invocations which are fresh, short-lived processes
(this addon explicitly sets reuselanguageinvoker=false) — see
resources/lib/local_proxy.py's own docstring for why that distinction is
exactly what OK.ru playback needed.
"""
import xbmc

try:
    from resources.lib import tls_speed
    tls_speed.install()
except Exception:
    pass

try:                                          # the checked IPTV playlists were removed: free the lists they had downloaded (once)
    import os
    import shutil
    import xbmcvfs
    _old = xbmcvfs.translatePath('special://profile/addon_data/script.module.starfleetscrapers/m3ulists/')
    if os.path.isdir(_old):
        shutil.rmtree(_old, ignore_errors=True)
except Exception:
    pass

from resources.lib import local_proxy

# One scheduler for every background job (resources/lib/bg_scheduler.py): two threads instead of about ten, heavy jobs one at a
# time, none while something plays (unless essential) and none while the device is short of memory.
try:
    import threading
    from resources.lib import bg_scheduler as _sched

    def _job(module, attr, *a):
        def _fn():
            import importlib
            return getattr(importlib.import_module(module), attr)(*a)
        return _fn

    _sched.add('connections', _job('resources.lib.torrent_sources', 'prewarm'), first=1, every=None, playing_ok=True)
    _sched.add('update-check', _job('resources.lib.dep_check', 'run'), first=3, every=None, playing_ok=True)
    _sched.add('memory-log', _job('resources.lib.memguard', 'tick'), first=30, every=lambda r: r or 120, heavy=False,
               playing_ok=True, low_mem_ok=True)
    _sched.add('my-teams', _job('resources.lib.myteams_alerts', 'tick'), first=45, every=lambda r: r or 480,
               playing_ok=True, low_mem_ok=True)
    _sched.add('my-events', _job('resources.lib.myevents_alerts', 'tick'), first=50, every=lambda r: r or 120,
               playing_ok=True, low_mem_ok=True)
    _sched.add('tracker-sync', _job('resources.lib.tracker_sync', 'tick'), first=40, every=lambda r: r or 900)
    _sched.add('requests-warm', _job('resources.lib.request_sources', 'warm'), first=60, every=None)
    _sched.add('simkl-flush', _job('resources.lib.simkl_sync', 'flush_pending'), first=120, every=20 * 60, playing_ok=True)
    _sched.add('adult-prewarm', _job('resources.lib.adult_prewarm', 'tick'), first=90, every=lambda r: r or 300)
    _sched.add('live-lists', _job('starfleetscrapers.live.live_sources', 'prewarm_channel_lists'), first=240, every=6 * 3600)
    _sched.add('tv-guide', _job('resources.lib.pvr_export', 'refresh_if_used'), first=30 * 60, every=6 * 3600)
    _sched.add('new-episodes', _job('resources.lib.airing_prep', 'tick'), first=15 * 60, every=30 * 60)   # not at launch: it asks the debrid services
    threading.Thread(target=_sched.run, args=(xbmc.Monitor(),), daemon=True).start()
except Exception as _e:
    xbmc.log('[Starfleet] background scheduler did not start: %s' % _e, xbmc.LOGWARNING)

# downloads (resources/lib/downloads.py): one at a time from the queue the hold-OK "Download (debrid)" fills; resumes after a restart
try:
    import threading as _dl_threading
    from resources.lib import downloads as _downloads
    _dl_threading.Thread(target=_downloads.worker, args=(xbmc.Monitor(),), daemon=True, name='starfleet-downloads').start()
except Exception as _e:
    xbmc.log('[Starfleet] download worker did not start: %s' % _e, xbmc.LOGWARNING)



def _elementum_cleanup():
    """A while after start-up: with a debrid service paired, remove Elementum and Burst once (resources/lib/elementum_setup.py)."""
    try:
        if xbmc.Monitor().waitForAbort(90):
            return
        from resources.lib import elementum_setup
        elementum_setup.cleanup_if_debrid()
    except Exception as _e:
        xbmc.log('[Starfleet] Elementum clean-up: %s' % _e, xbmc.LOGWARNING)


import threading as _el_threading
_el_threading.Thread(target=_elementum_cleanup, daemon=True, name='starfleet-elementum-cleanup').start()


def _iptv_guide_loop():
    """Keep the IPTV TV guide fresh: shortly after start-up, then every three hours (a guide younger than six hours is not loaded again)."""
    mon = xbmc.Monitor()
    if mon.waitForAbort(150):
        return
    while True:
        try:
            from starfleetscrapers.iptv import catalog as _iptv_catalog
            if _iptv_catalog._enabled():
                xbmc.log('[Starfleet/IPTV] guide refresh: %s' % _iptv_catalog.refresh_epg(), xbmc.LOGINFO)
        except Exception as _e:
            xbmc.log('[Starfleet/IPTV] guide refresh: %s' % _e, xbmc.LOGWARNING)
        if mon.waitForAbort(3 * 3600):
            return


_el_threading.Thread(target=_iptv_guide_loop, daemon=True, name='starfleet-iptv-guide').start()


# Hue lights (resources/lib/hue.py): the room dims while a video plays; nothing happens until it is linked and switched on in Settings
try:
    from resources.lib import hue as _hue
    _hue_player = _hue.HuePlayer()
    from resources.lib import skip_intro as _skip
    _skip_player = _skip.SkipPlayer()
    from resources.lib import screen_time as _screen
    _screen_player = _screen.ScreenPlayer()
    from resources.lib import playback_defaults as _pdef
    _defaults_player = _pdef.DefaultsPlayer()
    from resources.lib import loading_card as _lcard
    _card_player = _lcard.CardPlayer()
    from resources.lib import still_watching as _still
    _still_player = _still.StillPlayer()
except Exception as _e:
    xbmc.log('[Starfleet] Hue did not start: %s' % _e, xbmc.LOGWARNING)


try:                                                  # phone as remote (resources/lib/phone_remote.py): answers on the home network while switched on
    from resources.lib import phone_remote as _phone_remote
    _phone_remote.sync()
except Exception as _e:
    xbmc.log('[Starfleet] phone remote did not start: %s' % _e, xbmc.LOGWARNING)


class _SettingsMonitor(xbmc.Monitor):
    """Watches for "Show Adult section in main menu" being switched on, wherever the setting is changed (Home's Settings button, the
    add-on's settings from Kodi's own menus, a profile switch): the Adult widgets are built only while it is on, so every Home row is
    refreshed at once (resources/lib/widget_refresh.py) instead of the Adult tab staying empty until Kodi is restarted."""

    def __init__(self):
        xbmc.Monitor.__init__(self)
        self._adult = self._flag()

    @staticmethod
    def _flag():
        try:
            import xbmcaddon
            return xbmcaddon.Addon('plugin.video.starfleet').getSetting('adult_enabled') == 'true'
        except Exception:
            return False

    def onSettingsChanged(self):
        try:
            try:
                _phone_remote.sync()
            except Exception:
                pass
            try:                                          # Elementum switched on but not installed: offer the download
                import threading as _t
                from resources.lib import elementum_setup as _elem

                def _ask():
                    xbmc.sleep(1500)                      # let the settings dialog close first
                    _elem.on_settings_changed()
                _t.Thread(target=_ask, daemon=True).start()
            except Exception as _e:
                xbmc.log('[Starfleet] Elementum prompt: %s' % _e, xbmc.LOGWARNING)
            now = self._flag()
            turned_on = now and not self._adult
            self._adult = now
            if turned_on:
                import threading
                from resources.lib import widget_refresh

                def _go():
                    xbmc.sleep(2000)                  # let Kodi finish writing the settings
                    widget_refresh.refresh_all('Adult section turned on')
                threading.Thread(target=_go, daemon=True).start()
        except Exception as e:
            xbmc.log('[Starfleet] settings monitor: %s' % e, xbmc.LOGWARNING)


local_proxy.run_service(_SettingsMonitor())
