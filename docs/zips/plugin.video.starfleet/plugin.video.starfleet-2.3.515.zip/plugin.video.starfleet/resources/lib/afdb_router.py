﻿# -*- coding: utf-8 -*-
"""
resources/lib/afdb_router.py — Adult Film Database section

Menu structure:
  🔞 Adult
    ├── 🆕 New Releases
    ├── 🏆 Most Popular
    ├── 🎭 Browse by Category
    ├── 🎬 Browse by Studio  (A-Z)
    ├── 👤 Browse by Actor   (A-Z)
    └── 🔍 Search

Each film item opens a detail page with:
  - Full description / synopsis
  - Cast list (each actor is browsable)
  - Studio, Director, Year, Runtime, Rating
  - Front cover as thumbnail
  - Large front cover as fanart
  - Back cover as additional art
  - Categories as genre tags

Playback:
  - No stream URL yet → shows "Add stream source" dialog
  - When a stream URL is supplied (StreamTape, DoodStream, etc.)
    it is passed to ResolveURL/URLResolver for resolution
  - Falls back to direct play if ResolveURL not installed
"""

import re as _re
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
from resources.lib.gui import progress_dialog as _pdlg
from resources.lib.gui.select_dialog import select as _select_dialog
from resources.lib.gui import busy_dialog as _busy


def _extract_year(title):
    """Pull the most recent 4-digit year from a title string (1980–2099)."""
    years = _re.findall(r'\b(19[89]\d|20[0-9]\d)\b', title or '')
    return max(int(y) for y in years) if years else 0


# Title cleaning (quality/codec/release-group junk stripping) lives in the
# shared resources.lib.title_utils module — used identically here and for
# Movies/TV, so a scraped title looks and matches the same everywhere.
from resources.lib.title_utils import clean_adult_title as _clean_adult_title

from resources.lib import afdb
from resources.lib import cache as _cache
from concurrent.futures import ThreadPoolExecutor

ADDON     = xbmcaddon.Addon('plugin.video.starfleet')
PAGE_SIZE = 30


# ── Helpers ───────────────────────────────────────────────────────────────────

def _add_dir(handle, build_url, label, params, thumb='', plot=''):
    li = xbmcgui.ListItem(label=label)
    li.setInfo('video', {'title': label, 'plot': plot})
    if thumb:
        li.setArt({'thumb': thumb, 'icon': thumb})
    xbmcplugin.addDirectoryItem(handle, build_url(params), li, True)


def _add_film(handle, build_url, film):
    """Add a film as a directly-playable item with the richest available metadata.

    Priority chain:
      thumb  : ADE CDN (highest quality) → AFDB 400 px front → AFDB 200 px front
      fanart : AFDB 400 px front cover (always available by URL pattern)
      banner : AFDB back cover
      landscape / extra fanarts : AFDB scene screenshots
      metadata : AFDB detail (year/studio/director/cast/categories/synopsis)
                 ADE detail (fills any gaps + adds runtime/rating)
    """
    import re as _re

    # 1. Seed from the slim card dict (id, slug, title, thumb from list page)
    d = dict(film)

    # 2. Merge AFDB full detail (prewarm cache)
    full_afdb = _cache.get('afdb_film_%s' % film.get('id', ''))
    if full_afdb:
        for k, v in full_afdb.items():
            if v and not d.get(k):
                d[k] = v
        # Screenshots live only in full detail — always take them
        if full_afdb.get('screenshots'):
            d['screenshots'] = full_afdb['screenshots']

    # 3. Merge ADE search result → higher-quality CDN thumb + description gap-fill
    _ade_ck = 'ade_search_%s' % _re.sub(r'[^a-z0-9]', '_', d.get('title', '').lower())[:80]
    ade_search = _cache.get(_ade_ck)
    ade_film_id = ''
    if ade_search and isinstance(ade_search, dict):
        ade_film_id = ade_search.get('id', '')
        # ADE CDN thumb is typically 600-1200 px — prefer over AFDB 200 px
        if ade_search.get('thumb') and ade_search.get('fanart'):
            d.setdefault('ade_thumb',  ade_search['thumb'])
            d.setdefault('ade_fanart', ade_search['fanart'])
        for k in ('description', 'year', 'studio', 'director'):
            if not d.get(k) and ade_search.get(k):
                d[k] = ade_search[k]
        if not d.get('cast') and ade_search.get('cast'):
            d['cast'] = ade_search['cast']

    # 4. Merge ADE full detail → runtime, rating, genres, cast, synopsis
    if ade_film_id:
        ade_detail = _cache.get('ade_detail_%s' % ade_film_id)
        if ade_detail and isinstance(ade_detail, dict):
            for k in ('description', 'year', 'studio', 'director', 'runtime', 'rating'):
                if not d.get(k) and ade_detail.get(k):
                    d[k] = ade_detail[k]
            if not d.get('categories') and ade_detail.get('categories'):
                d['categories'] = ade_detail['categories']
            if not d.get('cast') and ade_detail.get('cast'):
                d['cast'] = ade_detail['cast']
            # ADE CDN thumb from detail (wider search in full page)
            if ade_detail.get('thumb') and not d.get('ade_thumb'):
                d['ade_thumb']  = ade_detail['thumb']
                d['ade_fanart'] = ade_detail.get('fanart', ade_detail['thumb'])

    # 5. Build best-available artwork URLs
    film_id   = film.get('id', '')
    # Thumb: ADE CDN (highest quality) → AFDB 200px front → whatever card supplied
    best_thumb = (
        d.get('ade_thumb')
        or (afdb.thumb_url(film_id) if film_id else '')
        or d.get('thumb', '')
    )
    fanart = (
        d.get('ade_fanart')
        or (afdb.thumb_url(film_id) if film_id else '')
        or d.get('fanart', best_thumb)
    )
    backcover    = d.get('backcover', '')
    screenshots  = d.get('screenshots', [])

    li = xbmcgui.ListItem(label=d['title'])

    # 6. Set Kodi metadata
    try:
        tag = li.getVideoInfoTag()
        tag.setTitle(d['title'])
        tag.setPlot(d.get('description', ''))
        if str(d.get('year', '')).isdigit():
            tag.setYear(int(d['year']))
        if d.get('studio'):
            tag.setStudios([d['studio']])
        if d.get('categories'):
            tag.setGenres(d['categories'])
        if d.get('director'):
            tag.setDirectors([d['director']])
        if d.get('rating'):
            try:
                tag.setRating(float(d['rating']))
            except (ValueError, TypeError):
                pass
        if d.get('runtime'):
            try:
                tag.setDuration(int(d['runtime']) * 60)
            except (ValueError, TypeError):
                pass
        tag.setMpaa('Adults Only')
        # Cast — merge AFDB actor IDs with ADE names, attach cached photos
        cast_list = []
        seen_names = set()
        for c in (d.get('cast') or []):
            name = c.get('name', '')
            if not name or name in seen_names:
                continue
            seen_names.add(name)
            photo = ''
            actor_id = c.get('id', '')
            if actor_id:
                actor_detail = _cache.get('afdb_actor_detail_%s' % actor_id)
                photo = (actor_detail or {}).get('photo', '')
            cast_list.append(xbmcgui.Actor(name, '', 0, photo))
        if cast_list:
            tag.setCast(cast_list)
    except Exception:
        info = {
            'title':    d['title'],
            'plot':     d.get('description', ''),
            'year':     int(d['year']) if str(d.get('year', '')).isdigit() else 0,
            'studio':   d.get('studio', ''),
            'genre':    ', '.join(d.get('categories', [])),
            'director': d.get('director', ''),
            'rating':   float(d.get('rating', 0) or 0),
            'duration': int(d.get('runtime', 0) or 0) * 60,
            'mpaa':     'Adults Only',
        }
        li.setInfo('video', info)

    # 7. Artwork — richest possible set
    art = {
        'thumb':   best_thumb,
        'poster':  best_thumb,
        'fanart':  fanart,
    }
    if backcover:
        art['banner'] = backcover
    if screenshots:
        art['landscape'] = screenshots[0]
    # Additional fanart slots (Kodi 18+) — scene shots after the front-cover fanart
    for i, shot in enumerate(screenshots[:4], 2):
        art['fanart%d' % i] = shot

    li.setArt(art)

    li.setProperty('IsPlayable', 'true')

    source = film.get('source', 'afdb')
    if source == 'pandamovies':
        play_params = {
            'action':   'adult_panda_play',
            'slug':     film.get('slug', ''),
            'film_url': film.get('url', ''),
            'title':    film['title'],
        }
    elif source == 'hqporner':
        play_params = {
            'action':   'adult_hqp_play',
            'slug':     film.get('slug', ''),
            'film_url': film.get('url', ''),
            'title':    film['title'],
        }
    elif source in ('freeomovie', 'xxxmoviestream', 'pornwatch', 'adultdvdparadise',
                    'watchpornfree', 'speedporn', 'xxxscenes', 'xmovix',
                    # Added 2026-08-15 (Pattern B / Movies)
                    'mangoporn', 'streamporn', 'swingerpornfun', 'paradisehill'):
        play_params = {
            'action':   'adult_stream_sources',
            'film_id':  film.get('id', ''),
            'film_url': film.get('url', ''),
            'title':    film['title'],
        }
    else:
        play_params = {
            'action':     'afdb_play_search',
            'film_id':    film.get('id', ''),
            'film_slug':  film.get('slug', ''),
            'film_title': film['title'],
        }

    xbmcplugin.addDirectoryItem(handle, build_url(play_params), li, False)


def _need_fetch(key):
    return _cache.get(key) is None


def _progress(msg):
    d = _pdlg.DialogProgress()
    d.create('Starfleet', msg)
    return d


def _search_with_cancel(dlg, tasks):
    """Runs every source-search function in `tasks` (a dict of
    name -> (callable, budget_seconds)) concurrently, one worker per task,
    same pattern metadata_router.py's _run_search_pass() already uses for
    the Movies/TV search. Every "Grab a tissue" Adult play path in this
    file used to wait on each source with its own SEQUENTIAL
    .result(timeout=X) call, one after another — those timeouts stack
    additively (confirmed live elsewhere in this codebase as a real ~98s
    hang from the exact same anti-pattern before it was fixed there), and
    none of them ever checked dlg.iscanceled() at any point during the
    wait, so Cancel could never have done anything regardless of whether
    the dialog itself routed the click correctly.

    Returns (collected_dict, was_canceled). collected_dict has every task
    name mapped to its result list (or [] if it never finished within its
    own budget) — always fully populated even when was_canceled is True,
    so a caller that wants to keep whatever streams already came back
    before the user canceled still can, though every call site here just
    discards it and exits instead."""
    from concurrent.futures import ThreadPoolExecutor
    import time as _time
    pool = ThreadPoolExecutor(max_workers=max(len(tasks), 1))
    try:
        start = _time.time()
        pending = {name: (pool.submit(fn), budget) for name, (fn, budget) in tasks.items()}
        collected = {name: [] for name in tasks}
        canceled = False
        while pending:
            if dlg.iscanceled():
                canceled = True
                break
            elapsed = _time.time() - start
            done_now = []
            for name, (fut, budget) in pending.items():
                if fut.done():
                    try:
                        collected[name] = fut.result()
                    except Exception:
                        collected[name] = []
                    done_now.append(name)
                elif elapsed >= budget:
                    collected[name] = []
                    done_now.append(name)
            for name in done_now:
                del pending[name]
            if pending:
                _time.sleep(0.25)
        return collected, canceled
    finally:
        pool.shutdown(wait=False)


def _run_cancelable(dlg, fn, budget=30):
    """Single-call convenience wrapper around _search_with_cancel — same
    fix, same reason, for every Adult browse/loading dialog that only ever
    made ONE blocking call (New Releases, Full Library, Studios, Actors,
    etc.) with no way to check iscanceled() during that one call either.
    Returns (result, was_canceled); result is None if canceled or if fn
    itself didn't finish within budget."""
    collected, canceled = _search_with_cancel(dlg, {'result': (fn, budget)})
    return collected.get('result'), canceled


def _next_page(handle, build_url, action, page, extra=None):
    params = {'action': action, 'page': page + 1}
    if extra:
        params.update(extra)
    _add_dir(handle, build_url,
             label='~~ Next Page (%d) ~~' % (page + 1),
             params=params)


# ── Adult Main Menu ───────────────────────────────────────────────────────────

def _prewarm_film_details(films):
    """
    Fire-and-forget background pre-fetch of full AFDB film detail
    (description, cast, studio, director, rating, photos) for each
    slim result in a list view. User sees instant detail loads with
    no loading dialog on subsequent clicks.
    Only fetches films whose detail cache is cold.
    Max 5 concurrent requests to avoid hammering AFDB.
    """
    cold = [
        (f['id'], f['slug']) for f in films
        if f.get('id') and _need_fetch('afdb_film_%s' % f['id'])
    ]
    if not cold:
        return

    def _fetch(film_id, film_slug):
        try:
            afdb.get_film_detail(film_id, film_slug)
        except Exception:
            pass

    pool = ThreadPoolExecutor(max_workers=5)
    for film_id, film_slug in cold:
        pool.submit(_fetch, film_id, film_slug)
    pool.shutdown(wait=False)   # never blocks the UI


def _prewarm_actor_details(films):
    """
    Pre-fetch actor photos and profiles for cast members found in
    a list of film results. Pulls actor detail for any actor whose
    photo cache is cold so browsing cast is instant.
    Capped at 10 actors to avoid excessive requests.
    """
    seen     = set()
    to_fetch = []

    for film in films:
        for actor in film.get('cast', [])[:5]:  # top 5 cast per film
            aid = actor.get('id', '')
            if aid and aid not in seen:
                seen.add(aid)
                if _need_fetch('afdb_actor_detail_%s' % aid):
                    to_fetch.append((aid, actor.get('slug', '')))
            if len(to_fetch) >= 10:
                break
        if len(to_fetch) >= 10:
            break

    if not to_fetch:
        return

    def _fetch(actor_id, actor_slug):
        try:
            afdb.get_actor_detail(actor_id, actor_slug)
        except Exception:
            pass

    pool = ThreadPoolExecutor(max_workers=5)
    for actor_id, actor_slug in to_fetch:
        pool.submit(_fetch, actor_id, actor_slug)
    pool.shutdown(wait=False)


def _verify_stream_sources(films, detail_fn, max_workers=16):
    """Fetch each film's detail page in parallel and keep only the ones with
    at least one real stream — used for site-native listings (PandaMovies,
    HQPorner, the flat free-stream stubs) whose list-page stubs always carry
    an empty streams:[] until a detail fetch happens. Without this, every
    card on the page shows regardless of whether a real stream will
    actually be found once clicked. Merges the fetched streams (and any
    richer thumb) back onto the surviving film dicts so the caller doesn't
    need a second detail fetch at play time."""
    if not films:
        return films
    from concurrent.futures import ThreadPoolExecutor

    def _check(film):
        try:
            detail = detail_fn(film)
        except Exception:
            detail = None
        return film, detail

    verified = []
    with ThreadPoolExecutor(max_workers=min(max_workers, len(films))) as pool:
        for film, detail in pool.map(_check, films):
            if detail and detail.get('streams'):
                film['streams'] = detail['streams']
                if detail.get('thumb') and not film.get('thumb'):
                    film['thumb'] = detail['thumb']
                verified.append(film)
    return verified


def _filter_films_with_sources(films):
    """
    Filter a film list to only those that have at least one confirmed stream
    source. Films from stream sources (panda, hqporner, freeomovie, etc.)
    always pass — they ARE the source. ADE/AFDB films are checked against
    the title cache.

    Previously, films never checked before were shown optimistically (a
    "graceful degradation" pass-through) with verification only happening in
    a background thread afterward — so a title with genuinely no source
    would still show up the first time, every time its cache entry expired.
    Now unchecked films are verified synchronously, right here, before the
    listing renders at all — slower on a cold cache, but nothing with no
    real source ever gets shown.

    adult_streams.has_cached_source() only ever checks FREE stream sources
    (pandamovies/hqporner/etc.) — it has no idea whether XXXClub/Rintor have
    a torrent. A film with only a torrent source would fail that check and
    get dropped here despite being genuinely playable, and — the bug this
    was missing — a film actually played once (adult_ade_play/
    adult_ade_play_direct, which DOES search XXXClub + Rintor + free +
    trailer) and confirmed to have NO source anywhere gets recorded in
    _load_no_source_ids() by ade_id, but that fact never reached this
    title-keyed, free-stream-only check — so the same dead title kept
    reappearing here even after being confirmed dead elsewhere. Checked
    first, against the cheap in-memory ade_id set, before falling back to
    the title/free-stream check.
    """
    try:
        from resources.lib import adult_streams as _as
        _as.prewarm_title_index()   # ensure index is built from cached data

        # Clean titles in-place before matching/display — see
        # _clean_adult_title for why this must happen before the
        # has_cached_source lookup below, not just at render time.
        for film in films:
            if film.get('title'):
                film['title'] = _clean_adult_title(film['title'])

        no_src_ids = _load_no_source_ids()
        if no_src_ids:
            films = [f for f in films if str(f.get('id', '')) not in no_src_ids]

        checked = []
        unchecked = []
        for film in films:
            # Stream-source films always kept — they carry their own playback
            if film.get('source') in _as.STREAM_SOURCE_NAMES:
                checked.append(film)
                continue
            result = _as.has_cached_source(film.get('title', ''))
            if result is None:
                unchecked.append(film)   # not yet in any cache — verify now
            elif result:
                checked.append(film)     # confirmed has a source
            # else: confirmed has NO source — drop it

        # Verify every unchecked film synchronously (in parallel) before
        # returning, instead of showing it optimistically and checking later.
        if unchecked:
            from concurrent.futures import ThreadPoolExecutor, as_completed

            def _verify(f):
                try:
                    # Movies-only (not adult_streams.search_by_title, which
                    # also fans out across the 18 Scenes tube sites for the
                    # dedicated unified-search box) — confirmed live those
                    # sites' huge, generically-titled short-clip catalogs
                    # produce false-positive matches against real AFDB/ADE
                    # movie titles far more often than the original 8
                    # sources did, wrongly marking a movie as having a
                    # source that's actually an unrelated tube-site clip
                    # (reported: "scenes show up in [the movie] library").
                    # See _search_free_movies_only's own docstring.
                    found = _search_free_movies_only(f['title'])
                except Exception:
                    return (f, True)   # search itself errored — fail open on THIS film
                if not found:
                    # Free stream sites found nothing, but that's not the
                    # whole real source lineup — an ADE/AFDB movie found via
                    # ADE's own genre search ("anal", "threesome", etc.) can
                    # still be genuinely playable via a torrent even with no
                    # free-stream match at all. Confirmed live: this filter
                    # was dropping real ADE movies wholesale from search
                    # results for exactly that reason, since has_cached_source
                    # /search_by_title only ever look at free stream sites,
                    # while the actual play path (adult_ade_play/
                    # adult_ade_play_direct) also checks XXXClub + Rintor.
                    try:
                        from resources.lib import torrent_sources as _ts
                        if _ts.search_xxxclub(f['title'], limit=1, media_type='adult'):
                            found = True
                        elif _ts.search_rintor(f['title'], limit=1, media_type='adult'):
                            found = True
                    except Exception:
                        pass
                if not found:
                    try:
                        _as.mark_no_source_confirmed(f['title'])
                    except Exception:
                        pass
                return (f, bool(found))

            # Deliberately NOT 'with ThreadPoolExecutor(...) as pool:' + a
            # blocking pool.map() — each _verify() call above runs the full,
            # 26-source search_by_title() (already its own 16-worker pool
            # with a 20s soft timeout), so up to 16 of THOSE running
            # concurrently here means up to ~16x16=256 threads all
            # contending for the same connections at once, and pool.map()
            # itself has no timeout at all, unlike search_by_title's own
            # as_completed(timeout=...) — confirmed live as the actual
            # cause of an Adult search still taking a very long time (e.g.
            # "facial") even after search_by_title's own hang was already
            # fixed: this outer loop was the one with no escape hatch.
            # Lower outer concurrency (5, not 16) so this doesn't spawn as
            # many simultaneous inner pools, and the same as_completed +
            # shutdown(wait=False) pattern caps the worst case here too
            # instead of blocking on however long the slowest film's check
            # happens to take.
            pool = ThreadPoolExecutor(max_workers=min(10, len(unchecked)))
            futures = {pool.submit(_verify, f): f for f in unchecked}
            resolved_ids = set()
            try:
                for future in as_completed(futures, timeout=15):
                    try:
                        f, has_source = future.result()
                        resolved_ids.add(id(f))
                        if has_source:
                            checked.append(f)
                    except Exception:
                        pass
            except Exception as e:
                # Confirmed live: a fresh cache-clear (e.g. right after an
                # addon update) can leave HUNDREDS of films unchecked at
                # once for a single listing/carousel populate, not just the
                # handful a live search box passes through here - 5 workers
                # can't get through 506 of them in any reasonable time, and
                # the old behavior (silently drop whatever didn't finish)
                # meant the entire library came back empty on that first
                # cold-cache render. Restoring the graceful-degradation this
                # function's own docstring describes: whatever DID finish
                # is filtered normally above; whatever's still outstanding
                # when the soft cutoff hits is shown optimistically instead
                # of dropped, same as the pre-synchronous-verification
                # behavior this replaced - a real source's absence still
                # gets caught the next time this same film is checked with
                # a warm cache (or when actually played and confirmed dead
                # via mark_no_source_confirmed), just not blocked on here.
                xbmc.log('[AFDB] source filter timeout: %s' % e, xbmc.LOGWARNING)
                checked.extend(f for f in unchecked if id(f) not in resolved_ids)
            finally:
                pool.shutdown(wait=False)

        return checked
    except Exception as e:
        xbmc.log('[AFDB] source filter error: %s' % e, xbmc.LOGWARNING)
        return films   # fail open


def adult_menu(handle, build_url):
    xbmcplugin.setPluginCategory(handle, 'Adult')
    xbmcplugin.setContent(handle, 'movies')

    _add_dir(handle, build_url, '🎬  Movies',
             {'action': 'adult_movies_menu'},
             plot='Browse Adult DVD Empire — New Releases, Recently Added, Best Sellers')

    _add_dir(handle, build_url, '🎞️  Scenes',
             {'action': 'adult_scenes_select'},
             plot='Browse HD scenes — choose HQ Porner or a tube site')

    _add_dir(handle, build_url, '🔍  Search',
             {'action': 'adult_search_unified'},
             plot='Search by movie title, performer name, or scene type (e.g. anal)')

    _add_dir(handle, build_url, '📡  Channels',
             {'action': 'adult_tvnow_channels'},
             plot='Live 18+ channels (tvnow247)')

    _add_dir(handle, build_url, '📥  Requests',
             {'action': 'adult_requests'},
             plot='Hand-picked titles (resources/lib/request_sources.py), matched by AdultDVDEmpire film id')

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def adult_requests_list(handle, build_url):
    """"Requests" — resources/lib/request_sources.py's hand-curated adult
    title list. Reuses the same generic action=request_play handler
    (router.play_request_stream), not an Adult-specific play path, since
    "resolve this url and play it" doesn't depend on media type.

    An entry can carry several candidate urls (request_sources.
    entry_urls) — this is a plain directory listing (not the custom-skin
    dialog Movies/TV's own Requests section uses), so each one just gets
    its own numbered row ("Title (Source 2)") rather than a runtime
    picker, same as how every other multi-mirror source in this file
    already lists one row per mirror.

    Cover art via ade._cover_url(adc_id) — a pure CDN-URL template built
    from the numeric id alone, no extra network call and no slug needed.
    Full description/cast/studio/director plus a trailer row now come
    from request_sources.enrich_adult_metadata(), which validates a
    title-search hit against this entry's own known adc_id before
    trusting its slug — so a search miss just falls back to blank
    description/no cast (never a wrong film's data), same safety rule
    documented in enrich_adult_metadata()'s own docstring. Fetched in
    parallel (one search+detail round trip per entry, cached 24h after
    the first run) since this is a plain eager directory listing, not
    the lazy on-focus fetch the custom-skin Requests screen uses."""
    from resources.lib import request_sources as _reqsrc
    from resources.lib import ade as _ade
    from concurrent.futures import ThreadPoolExecutor

    xbmcplugin.setPluginCategory(handle, 'Adult / Requests')
    xbmcplugin.setContent(handle, 'movies')

    requests_list = _reqsrc.get_requested_adult()
    if not requests_list:
        xbmcgui.Dialog().notification('Starfleet', 'No requested adult titles yet',
                                       xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(handle)
        return

    def _meta(r):
        adc_id = r.get('adc_id', r.get('ade_id', ''))
        return _reqsrc.enrich_adult_metadata(r.get('title', ''), adc_id)

    with ThreadPoolExecutor(max_workers=max(len(requests_list), 1)) as pool:
        metas = list(pool.map(_meta, requests_list))

    for r, meta in zip(requests_list, metas):
        title  = r.get('title', '')
        adc_id = r.get('adc_id', r.get('ade_id', ''))
        urls   = _reqsrc.entry_urls(r)
        cover = fanart_cover = ''
        if adc_id:
            cover = _ade._cover_url(adc_id)
            fanart_cover = _ade._cover_url(adc_id, 'bh')
        # Prefer the real detail page's own thumb/fanart (og:image) when the
        # enrichment fetch succeeded — the plain CDN-formula guess above
        # 404s/415s for some real films (confirmed live), while the actual
        # detail page's own cover always matches this exact product.
        if meta:
            if meta.get('thumb'):
                cover = meta['thumb']
            if meta.get('fanart'):
                fanart_cover = meta['fanart']
        plot = meta.get('description', '') if meta else ''
        cast_names = [c.get('name', '') for c in meta.get('cast', [])] if meta else []
        for i, u in enumerate(urls, 1):
            label = title if len(urls) == 1 else '%s (Source %d)' % (title, i)
            li = xbmcgui.ListItem(label=label)
            info = {'title': label, 'mediatype': 'movie'}
            if plot:
                info['plot'] = plot
            if meta and meta.get('studio'):
                info['studio'] = meta['studio']
            if meta and meta.get('director'):
                info['director'] = meta['director']
            if meta and meta.get('year'):
                info['year'] = meta['year']
            if cast_names:
                info['cast'] = cast_names
            li.setInfo('video', info)
            li.setProperty('IsPlayable', 'true')
            if cover:
                li.setArt({'thumb': cover, 'poster': cover, 'fanart': fanart_cover})
            url = build_url({'action': 'request_play', 'url': u, 'title': label})
            xbmcplugin.addDirectoryItem(handle, url, li, isFolder=False)

        trailer = meta.get('trailer', '') if meta else ''
        if trailer:
            t_label = '%s (Trailer)' % title
            li = xbmcgui.ListItem(label=t_label)
            li.setInfo('video', {'title': t_label, 'mediatype': 'movie'})
            li.setProperty('IsPlayable', 'true')
            if cover:
                li.setArt({'thumb': cover, 'poster': cover, 'fanart': fanart_cover})
            url = build_url({'action': 'request_play', 'url': trailer, 'title': t_label})
            xbmcplugin.addDirectoryItem(handle, url, li, isFolder=False)

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(handle)


def adult_tvnow_channels(handle, build_url):
    from resources.lib import live_sources as _ls

    xbmcplugin.setPluginCategory(handle, 'Adult / Channels')
    xbmcplugin.setContent(handle, 'videos')

    channels = _ls.get_tvnow_adult_channels()
    if not channels:
        xbmcgui.Dialog().notification('Starfleet', 'No 18+ channels available right now',
                                       xbmcgui.NOTIFICATION_INFO)

    for ch in channels:
        li = xbmcgui.ListItem(label=ch['title'])
        li.setArt({'thumb': ch.get('thumbnail', ''), 'icon': ch.get('thumbnail', '')})
        li.setInfo('video', {'title': ch['title'], 'mediatype': 'video'})
        li.setProperty('IsPlayable', 'true')
        url = build_url({'action': 'adult_tvnow_channel_play',
                          'channel_id': ch['id'], 'title': ch['title']})
        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=False)

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(handle)


def adult_tvnow_channel_play(handle, channel_id, title=''):
    from resources.lib import live_sources as _ls

    dlg = _progress('Resolving %s…' % (title or 'channel'))
    try:
        stream_url = _ls.resolve_tvnow_stream(channel_id)
    finally:
        dlg.close()

    if not stream_url:
        xbmcgui.Dialog().notification('Starfleet', 'Stream unavailable right now',
                                       xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    li = xbmcgui.ListItem(label=title or 'Channel', path=stream_url)
    li.setProperty('IsPlayable', 'true')
    xbmcplugin.setResolvedUrl(handle, True, li)


def _jav_torrent_fallback(handle, title):
    """Fallback for the JAV streaming menu (javseen/javhd/javleak/mythav)
    when every embed-host candidate fails to resolve — searches this
    addon's full adult torrent source set (XXXClub, Rintor, XXXTor,
    FreeJAVTorrent, IJAVTorrent, Sukebei, BitDig, TPB, Knaben, etc., same
    set search_all(media_type='adult') already wires up) by title and
    plays the chosen result, instead of just reporting failure.

    Previously the JAV menu and the Adult torrent sources were two
    entirely separate features with no connection between them — a title
    whose streaming embed hosts were all dead/decoy (see
    vidhide_bypass.py's own docstring for a confirmed real example) had no
    path to the torrent sources this addon already has for the exact same
    content. Returns True if something got resolved and setResolvedUrl was
    already called; False if the caller should show its own "nothing
    found" message."""
    if not title:
        return False
    try:
        from resources.lib import torrent_sources as _ts
    except Exception:
        return False

    dlg = _progress('No stream found — searching torrents for %s…' % title)
    try:
        results = _ts.search_all(title, media_type='adult')
    except Exception as e:
        xbmc.log('[Starfleet/JAV] torrent fallback search error: %s' % e, xbmc.LOGWARNING)
        results = []
    dlg.close()

    if not results:
        return False

    options = []
    for t in results:
        qual = ''
        for tag in ('2160p', '4K', '1080p', '720p', '480p'):
            if tag.lower() in t.get('title', '').lower():
                qual = '  [%s]' % tag
                break
        seeds = ('  ↑%d' % t['seeds']) if t.get('seeds') else ''
        size  = ('  [%s]' % t['size']) if t.get('size') else ''
        src   = t.get('source', 'Torrent')
        options.append('[%s] %s%s%s%s' % (src, t.get('title', title), qual, size, seeds))

    idx = _select_dialog('%s — Choose torrent source' % title, options)
    if idx < 0:
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return True

    chosen = results[idx]
    resolved = adult_stream_play(chosen.get('magnet', ''), title)
    if not resolved:
        xbmcgui.Dialog().notification('Starfleet', 'Could not resolve stream', xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return True

    li = xbmcgui.ListItem(path=resolved)
    li.setContentLookup(False)
    li.setInfo('video', {'title': title, 'mediatype': 'movie'})
    _url_lc = resolved.lower()
    if '.m3u8' in _url_lc:
        li.setMimeType('application/x-mpegURL')
    elif '.mp4' in _url_lc:
        li.setMimeType('video/mp4')
    elif '.mkv' in _url_lc:
        li.setMimeType('video/x-matroska')
    try:
        from resources.lib import watch_history as _wh0
        _wh0.apply_resume(li, 'jav_torrent:%s' % title)
    except Exception:
        pass
    xbmcplugin.setResolvedUrl(handle, True, li)
    try:
        from resources.lib import watch_history as _wh
        _wh.start_playback_monitor('jav_torrent:%s' % title, title=title)
    except Exception:
        pass
    return True


def javseen_play_direct(vid, slug, title=''):
    """Direct-call version of javseen_play for the custom-skin category
    list's doModal() window (Home's _open_jav_category). Routed through
    the plugin://...?action=javseen_play URL (not a bare
    xbmc.Player().play(url)) so headers the resolved URL may need get
    extracted properly by the real plugin-resolution call — a bare
    Player().play() on a raw resolved URL has silently dropped required
    headers before for this same class of URL (Live TV country/favorites/
    search play handlers, confirmed earlier this session)."""
    from urllib.parse import quote
    li = xbmcgui.ListItem(label=title)
    li.setProperty('IsPlayable', 'true')
    play_url = ('plugin://plugin.video.starfleet/?action=javseen_play'
                '&vid=%s&slug=%s&title=%s' % (quote(vid), quote(slug), quote(title)))
    xbmc.Player().play(play_url, li)


def javseen_play(handle, vid, slug, title=''):
    """Resolve a javseen.tv title's stream by walking its real embed chain
    (detail page -> its own /embed/<id>/ page -> myserver.javseen.tv ->
    rotating third-party embed host list) and handing each candidate to
    this addon's existing resolvers.py chain (Real-Debrid/AllDebrid/
    Premiumize/TorBox, then ResolveURL) until one resolves — see
    javseen_sources.py's own docstring for why this doesn't need the
    browser-dependent harvest-service the earlier missav.ws-based JAV
    section required."""
    from resources.lib import javseen_sources as _js

    dlg = _progress('Locating stream for %s…' % title)
    resolved_url = _js.resolve_javseen_stream(vid, slug)
    dlg.close()

    if not resolved_url:
        if _jav_torrent_fallback(handle, title):
            return
        xbmcgui.Dialog().notification('JAV', 'No playable stream found for "%s"' % title,
                                      xbmcgui.NOTIFICATION_WARNING, 4000)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    li = xbmcgui.ListItem(path=resolved_url)
    li.setInfo('video', {'title': title, 'mediatype': 'movie'})
    if '.m3u8' in resolved_url.lower():
        try:
            import inputstreamhelper
            h = inputstreamhelper.Helper('hls')
            if h.check_inputstream():
                li.setProperty('inputstream', 'inputstream.adaptive')
                li.setProperty('inputstream.adaptive.manifest_type', 'hls')
        except ImportError:
            pass
    try:
        from resources.lib import watch_history as _wh0
        _wh0.apply_resume(li, 'javseen:%s' % vid)
    except Exception:
        pass
    xbmcplugin.setResolvedUrl(handle, True, li)

    # Same watch-progress tracking mainstream Movies/TV already get —
    # watch_history.py keys on an opaque string (real imdb_id for those),
    # so a synthetic "javseen:<id>" key works identically with zero changes
    # to that module; it already persists to the profile/addon_data
    # directory, outside the addon's own code folder, so it survives
    # updates the same way.
    try:
        from resources.lib import watch_history as _wh
        _wh.start_playback_monitor('javseen:%s' % vid, title=title)
    except Exception:
        pass


def javleak_play_direct(vid, slug, title=''):
    """Direct-call version of javleak_play for the custom-skin category
    list's doModal() window — same reasoning as javseen_play_direct."""
    from urllib.parse import quote
    li = xbmcgui.ListItem(label=title)
    li.setProperty('IsPlayable', 'true')
    play_url = ('plugin://plugin.video.starfleet/?action=javleak_play'
                '&vid=%s&slug=%s&title=%s' % (quote(vid), quote(slug), quote(title)))
    xbmc.Player().play(play_url, li)


def javleak_play(handle, vid, slug, title=''):
    """Resolve a javleak.com title's stream — its detail page embeds the
    real third-party player iframes directly (no extra hop to walk first,
    unlike javseen/javhd), handed to this addon's existing resolvers.py
    chain (Real-Debrid/AllDebrid/Premiumize/TorBox, then ResolveURL) until
    one resolves — see javleak_sources.py's own docstring."""
    from resources.lib import javleak_sources as _jl

    dlg = _progress('Locating stream for %s…' % title)
    resolved_url = _jl.resolve_javleak_stream(vid, slug)
    dlg.close()

    if not resolved_url:
        if _jav_torrent_fallback(handle, title):
            return
        xbmcgui.Dialog().notification('JAV', 'No playable stream found for "%s"' % title,
                                      xbmcgui.NOTIFICATION_WARNING, 4000)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    li = xbmcgui.ListItem(path=resolved_url)
    li.setInfo('video', {'title': title, 'mediatype': 'movie'})
    if '.m3u8' in resolved_url.lower():
        try:
            import inputstreamhelper
            h = inputstreamhelper.Helper('hls')
            if h.check_inputstream():
                li.setProperty('inputstream', 'inputstream.adaptive')
                li.setProperty('inputstream.adaptive.manifest_type', 'hls')
        except ImportError:
            pass
    try:
        from resources.lib import watch_history as _wh0
        _wh0.apply_resume(li, 'javleak:%s' % vid)
    except Exception:
        pass
    xbmcplugin.setResolvedUrl(handle, True, li)

    try:
        from resources.lib import watch_history as _wh
        _wh.start_playback_monitor('javleak:%s' % vid, title=title)
    except Exception:
        pass


def mythav_play_direct(vid, slug, title=''):
    """Direct-call version of mythav_play for the custom-skin category
    list's doModal() window — same reasoning as javleak_play_direct."""
    from urllib.parse import quote
    li = xbmcgui.ListItem(label=title)
    li.setProperty('IsPlayable', 'true')
    play_url = ('plugin://plugin.video.starfleet/?action=mythav_play'
                '&vid=%s&slug=%s&title=%s' % (quote(vid), quote(slug), quote(title)))
    xbmc.Player().play(play_url, li)


def mythav_play(handle, vid, slug, title=''):
    """Resolve a mythav.org title's stream. Unlike javseen/javhd/javleak,
    this site's own chain (detail page -> decoded upload18.org player ->
    its window.PLAYER_CONFIG.m3u8 field) already ends in a fully-signed,
    directly playable helvid.com HLS URL — no resolvers.py hand-off
    needed, see mythav_sources.py's own docstring."""
    from resources.lib import mythav_sources as _mt

    dlg = _progress('Locating stream for %s…' % title)
    resolved_url = _mt.resolve_mythav_stream(vid, slug)
    dlg.close()

    if not resolved_url:
        if _jav_torrent_fallback(handle, title):
            return
        xbmcgui.Dialog().notification('JAV', 'No playable stream found for "%s"' % title,
                                      xbmcgui.NOTIFICATION_WARNING, 4000)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    # resolved_url is pipe-tagged 'url|Referer=...&User-Agent=...' — helvid.com
    # 403s without the Referer (confirmed live 2026-08-03), same header-
    # propagation convention as router.py's _hls_item for Live TV.
    stream_url, extra_headers = (resolved_url.split('|', 1) + [''])[:2]

    li = xbmcgui.ListItem(path=resolved_url)
    li.setInfo('video', {'title': title, 'mediatype': 'movie'})
    if '.m3u8' in stream_url.lower():
        try:
            import inputstreamhelper
            h = inputstreamhelper.Helper('hls')
            if h.check_inputstream():
                li.setProperty('inputstream', 'inputstream.adaptive')
                li.setProperty('inputstream.adaptive.manifest_type', 'hls')
                if extra_headers:
                    li.setProperty('inputstream.adaptive.stream_headers',   extra_headers)
                    li.setProperty('inputstream.adaptive.manifest_headers', extra_headers)
        except ImportError:
            pass
    try:
        from resources.lib import watch_history as _wh0
        _wh0.apply_resume(li, 'mythav:%s' % vid)
    except Exception:
        pass
    xbmcplugin.setResolvedUrl(handle, True, li)

    try:
        from resources.lib import watch_history as _wh
        _wh.start_playback_monitor('mythav:%s' % vid, title=title)
    except Exception:
        pass


def javhd_play_direct(vid, slug, title=''):
    """javhd.today counterpart to javseen_play_direct — same reasoning for
    routing through a plugin://...?action=javhd_play URL instead of a bare
    Player().play()."""
    from urllib.parse import quote
    li = xbmcgui.ListItem(label=title)
    li.setProperty('IsPlayable', 'true')
    play_url = ('plugin://plugin.video.starfleet/?action=javhd_play'
                '&vid=%s&slug=%s&title=%s' % (quote(vid), quote(slug), quote(title)))
    xbmc.Player().play(play_url, li)


def javhd_play(handle, vid, slug, title=''):
    """javhd.today counterpart to javseen_play — same embed-chain-then-
    resolvers.py hand-off, see javhd_sources.py's own docstring for why
    it needs no browser/harvest-service either."""
    from resources.lib import javhd_sources as _jh

    dlg = _progress('Locating stream for %s…' % title)
    resolved_url = _jh.resolve_javhd_stream(vid, slug)
    dlg.close()

    if not resolved_url:
        if _jav_torrent_fallback(handle, title):
            return
        xbmcgui.Dialog().notification('JAV', 'No playable stream found for "%s"' % title,
                                      xbmcgui.NOTIFICATION_WARNING, 4000)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    li = xbmcgui.ListItem(path=resolved_url)
    li.setInfo('video', {'title': title, 'mediatype': 'movie'})
    if '.m3u8' in resolved_url.lower():
        try:
            import inputstreamhelper
            h = inputstreamhelper.Helper('hls')
            if h.check_inputstream():
                li.setProperty('inputstream', 'inputstream.adaptive')
                li.setProperty('inputstream.adaptive.manifest_type', 'hls')
        except ImportError:
            pass
    try:
        from resources.lib import watch_history as _wh0
        _wh0.apply_resume(li, 'javhd:%s' % vid)
    except Exception:
        pass
    xbmcplugin.setResolvedUrl(handle, True, li)

    try:
        from resources.lib import watch_history as _wh
        _wh.start_playback_monitor('javhd:%s' % vid, title=title)
    except Exception:
        pass


def adult_movies_menu(handle, build_url):
    """Movies submenu: ADE browse sections + library + favorites."""
    xbmcplugin.setPluginCategory(handle, 'Adult — Movies')
    xbmcplugin.setContent(handle, 'movies')

    _add_dir(handle, build_url, '🆕  New Releases',
             {'action': 'adult_browse_new_releases', 'page': 1},
             plot='New release movies from Adult DVD Empire (/new-release-porn-movies.html)')
    _add_dir(handle, build_url, '🕐  Recently Added',
             {'action': 'adult_browse_recently_added', 'page': 1},
             plot='Recently added videos from Adult DVD Empire (/new-addition-porn-videos.html)')
    _add_dir(handle, build_url, '🏆  Best Sellers',
             {'action': 'adult_browse_bestsellers', 'page': 1},
             plot='Best selling videos from Adult DVD Empire (/best-selling-porn-videos.html)')
    _add_dir(handle, build_url, '❤️  Adult Favorites',
             {'action': 'adult_favorites_list'},
             plot='Your saved adult movies')
    _add_dir(handle, build_url, '🗄️  Full Library',
             {'action': 'adult_movies_library', 'page': 1},
             plot='All movies — sources checked, sorted by most recent year')

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def _ade_browse_page(handle, build_url, films, section_label, page, next_action):
    """Render an ADE listing page with parallel detail prewarming and context menus."""
    import urllib.parse as _up
    import html as _html_lib
    from resources.lib import ade as _ade, adult_favorites as _afav

    xbmcplugin.setPluginCategory(handle, section_label)
    xbmcplugin.setContent(handle, 'movies')

    if not films:
        xbmcgui.Dialog().notification('ADE', 'No films found — try a different page', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(handle, succeeded=True)
        return

    # has_cached_source() previously treated "never checked" the same as
    # "confirmed no source", so once its passive title index stopped being
    # empty (a few hours of real use) it started hiding almost everything
    # — confirmed live: New Releases went from showing real content to
    # showing nothing. Fixed at the source (has_cached_source /
    # mark_no_source_confirmed now track a real negative result
    # separately from "not yet looked at"), so this filter is safe to use
    # here again: unchecked titles still show immediately, and only ones
    # actually searched and confirmed empty get hidden.
    films = _filter_films_with_sources(films)
    if not films:
        xbmcgui.Dialog().notification('ADE', 'No films with a source found — try a different page', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(handle, succeeded=True)
        return

    # Parallel detail prewarming for uncached films (fire-and-forget)
    def _prewarm(film):
        try:
            if not _cache.get('ade_detail_%s' % film.get('id', '')):
                _ade.get_film_detail(film['id'], film['slug'])
        except Exception:
            pass

    pool = ThreadPoolExecutor(max_workers=10)
    for film in films:
        pool.submit(_prewarm, film)
    pool.shutdown(wait=False)

    for film in films:
        ade_id = str(film.get('id', ''))
        # Merge cached detail into the stub — include artwork so og:image / scraped covers apply
        ade_detail = _cache.get('ade_detail_%s' % ade_id)
        d = dict(film)
        d['title'] = _html_lib.unescape(d.get('title', ''))
        if isinstance(ade_detail, dict):
            for k in ('description', 'year', 'studio', 'director', 'runtime', 'rating',
                      'categories', 'cast', 'trailer', 'thumb', 'fanart', 'backcover'):
                if ade_detail.get(k) and (not d.get(k) or k in ('thumb', 'fanart', 'backcover', 'trailer')):
                    d[k] = ade_detail[k]

        li = xbmcgui.ListItem(label=d['title'])
        try:
            tag = li.getVideoInfoTag()
            tag.setTitle(d['title'])
            tag.setPlot(d.get('description', ''))
            if str(d.get('year', '')).isdigit():
                tag.setYear(int(d['year']))
            if d.get('studio'):
                tag.setStudios([d['studio']])
            if d.get('categories'):
                tag.setGenres(d['categories'])
            if d.get('rating'):
                try:
                    tag.setRating(float(d['rating']))
                except Exception:
                    pass
            if d.get('runtime'):
                try:
                    tag.setDuration(int(d['runtime']) * 60)
                except Exception:
                    pass
            if d.get('trailer'):
                try:
                    tag.setTrailer(d['trailer'])
                except Exception:
                    pass
            tag.setMpaa('Adults Only')
        except Exception:
            li.setInfo('video', {'title': d['title'], 'plot': d.get('description', ''),
                                  'year': int(d['year']) if str(d.get('year','')).isdigit() else 0,
                                  'mpaa': 'Adults Only'})

        thumb    = d.get('thumb', '')
        # Use back cover as fanart/background when available; it's a different composition
        # that works better as a wide background than the front cover repeated
        backcover = d.get('backcover', '')
        fanart    = backcover if backcover else d.get('fanart', thumb)
        li.setArt({'thumb': thumb, 'poster': thumb, 'fanart': fanart, 'banner': thumb})
        li.setProperty('IsPlayable', 'true')

        # Context menu: add or remove from adult favorites
        title_enc  = _up.quote(d['title'])
        thumb_enc  = _up.quote(thumb)
        fanart_enc = _up.quote(fanart)
        if _afav.is_favorite(ade_id):
            ctx_label  = 'Remove from Adult Favorites'
            ctx_action = ('RunPlugin(plugin://plugin.video.starfleet/'
                          '?action=adult_favorites_remove&ade_id=%s&title=%s)' % (ade_id, title_enc))
        else:
            ctx_label  = 'Add to Adult Favorites'
            ctx_action = ('RunPlugin(plugin://plugin.video.starfleet/'
                          '?action=adult_favorites_add&ade_id=%s&title=%s&thumb=%s&fanart=%s)'
                          % (ade_id, title_enc, thumb_enc, fanart_enc))
        li.addContextMenuItems([(ctx_label, ctx_action)])

        slug = d.get('slug', '')
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action': 'adult_ade_play', 'ade_id': ade_id,
                       'ade_slug': slug, 'title': d['title']}),
            li, False
        )

    # Next page — skipped when next_action is falsy (e.g. a one-shot
    # performer search result, which has no real page 2 to advance to).
    if next_action:
        _next_page(handle, build_url, next_action, page)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(handle, succeeded=True)


def adult_performer_films(handle, build_url, name):
    """All ADE films featuring a specific performer, by name — reached by
    clicking their photo in the custom Adult category-list view's cast
    strip. Reuses the same performer-filtered ADE search (type=talent)
    already wired into the unified search path, rendered the same way every
    other ADE listing page is."""
    from resources.lib import ade as _ade
    dlg = _progress('Searching %s...' % name)
    films = _ade.search_by_talent(name)
    dlg.close()
    _ade_browse_page(handle, build_url, films, '\U0001F464 %s' % name, 1, None)


def adult_browse_new_releases(handle, build_url, page=1):
    """ADE new release movies — /new-release-porn-movies.html (16 pages)."""
    from resources.lib import ade as _ade
    dlg = _progress('Loading New Releases — page %d…' % page)
    films, canceled = _run_cancelable(dlg, lambda: _ade.browse_new_release_movies(page), 25)
    dlg.close()
    if canceled:
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return
    _ade_browse_page(handle, build_url, films, '🆕 New Releases', page, 'adult_browse_new_releases')


def adult_browse_recently_added(handle, build_url, page=1):
    """ADE recently added videos — /new-addition-porn-videos.html (5000+ pages)."""
    from resources.lib import ade as _ade
    dlg = _progress('Loading Recently Added — page %d…' % page)
    films, canceled = _run_cancelable(dlg, lambda: _ade.browse_recently_added_videos(page), 25)
    dlg.close()
    if canceled:
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return
    _ade_browse_page(handle, build_url, films, '🕐 Recently Added', page, 'adult_browse_recently_added')


def adult_browse_bestsellers(handle, build_url, page=1):
    """ADE best selling videos — /best-selling-porn-videos.html."""
    from resources.lib import ade as _ade
    dlg = _progress('Loading Best Sellers — page %d…' % page)
    films, canceled = _run_cancelable(dlg, lambda: _ade.browse_bestseller_videos(page), 25)
    dlg.close()
    if canceled:
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return
    _ade_browse_page(handle, build_url, films, '🏆 Best Sellers', page, 'adult_browse_bestsellers')


def _no_source_path():
    import os, xbmcvfs
    d = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.starfleet/')
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, 'no_source_ids.json')


def _load_no_source_ids():
    try:
        import json
        with open(_no_source_path(), 'r', encoding='utf-8') as f:
            return set(json.load(f))
    except Exception:
        return set()


def _mark_no_source(ade_id):
    xbmc.log('[Starfleet/NoSource] marking ade_id=%r' % ade_id, xbmc.LOGINFO)
    try:
        import json
        ids = _load_no_source_ids()
        ids.add(str(ade_id))
        p = _no_source_path()
        with open(p + '.tmp', 'w', encoding='utf-8') as f:
            json.dump(list(ids), f)
        import os
        os.replace(p + '.tmp', p)
        xbmc.log('[Starfleet/NoSource] saved %d ids' % len(ids), xbmc.LOGINFO)
    except Exception:
        pass


def adult_ade_play_direct(ade_id, ade_slug='', title=''):
    """
    Play an ADE film from the home screen carousel without going through the plugin URL
    resolver.  Called directly (no handle) in a background thread so the home window
    keeps its doModal() alive and no Videos window is opened.
    """
    from resources.lib import ade as _ade, adult_streams as _as, torrent_sources as _ts
    import html as _html_lib
    title = _html_lib.unescape(title)
    xbmc.log('[Starfleet/ADE] play_direct ade_id=%r title=%r' % (ade_id, title), xbmc.LOGINFO)

    dlg = _progress('Grab a tissue… getting your load ready')

    trailer_url = _ade.trailer_url(ade_id)
    streams = []

    def _search_xxxclub():
        try:
            results = _ts.search_xxxclub(title, limit=8, media_type='adult')
            out = []
            for t in (results or []):
                qual = ''
                t_title = t.get('title', '')
                for kw in ('2160p', '4K', '1080p', '720p'):
                    if kw.lower() in t_title.lower():
                        qual = ' [%s]' % kw
                        break
                out.append({'label': '[XXXClub]%s %s [%s]' % (qual, t_title, t.get('size', '')),
                            'url': t.get('magnet', '')})
            return out
        except Exception:
            return []

    def _search_free():
        try:
            return _search_free_movies_only(title) or []
        except Exception:
            return []

    def _search_rintor():
        try:
            results = _ts.search_rintor(title, limit=8, media_type='adult')
            out = []
            for t in (results or []):
                out.append({'label': '[Rintor] %s [%s]' % (t.get('title', ''), t.get('size', '')),
                            'url': t.get('magnet', '')})
            return out
        except Exception:
            return []

    def _search_myporn():
        # Confirmed live myporn.club's own search is single-word-tag-only
        # (a multi-word query 404s), so this hit rate is genuinely lower
        # than XXXClub's real title search — included anyway per request,
        # same role/shape as every other parallel source here.
        try:
            from resources.lib import myporn_sources as _mpc
            return _mpc.search_myporn_club(title, limit=5, media_type='adult')
        except Exception:
            return []

    def _search_extto():
        try:
            results = _ts.search_extto(title, limit=8, media_type='adult')
            out = []
            for t in (results or []):
                out.append({'label': '[EXTto] %s [%s]' % (t.get('title', ''), t.get('size', '')),
                            'url': t.get('magnet', '')})
            return out
        except Exception:
            return []

    def _search_requests():
        # Manually curated Requests JSON (resources/lib/request_sources.py)
        # — matched exactly by AdultDVDEmpire's own numeric film id
        # (ade_id), not fuzzy title search. Real, hand-picked links, not a
        # scraper — shown first in the picker below. One matched entry can
        # carry several candidate urls (request_sources.entry_urls) —
        # every one gets its own [Request] line, numbered when there's
        # more than one.
        try:
            from resources.lib import request_sources as _reqsrc
            match = _reqsrc.find_adult_request(ade_id)
            if not match:
                return []
            urls = _reqsrc.entry_urls(match)
            label_base = match.get('title') or title
            out = []
            for i, u in enumerate(urls, 1):
                resolved = _reqsrc.resolve_request_stream(u)
                if not resolved:
                    continue
                label = '[Request] %s' % label_base if len(urls) == 1 else \
                        '[Request] %s (Source %d)' % (label_base, i)
                out.append({'label': label, 'url': resolved})
            return out
        except Exception:
            return []

    collected, canceled = _search_with_cancel(dlg, {
        'requests': (_search_requests, 15),
        'xxxclub': (_search_xxxclub, 25),
        'rintor':  (_search_rintor,  25),
        'myporn':  (_search_myporn,  15),
        'extto':   (_search_extto,   25),
        'free':    (_search_free,    30),
    })
    dlg.close()
    if canceled:
        return

    for item in collected.get('requests', []):
        if item.get('url'):
            streams.append(item)
    for item in collected.get('xxxclub', []):
        if item.get('url'):
            streams.append(item)
    for item in collected.get('rintor', []):
        if item.get('url'):
            streams.append(item)
    for item in collected.get('myporn', []):
        if item.get('url'):
            streams.append(item)
    for item in collected.get('extto', []):
        if item.get('url'):
            streams.append(item)
    for r in collected.get('free', []):
        if r.get('url'):
            streams.append({'label': '[FREE] %s' % r.get('label', 'Stream'), 'url': r['url']})

    if not streams:
        _mark_no_source(ade_id)
        xbmcgui.Dialog().notification('Starfleet', 'No sources found for "%s"' % title,
                                      xbmcgui.NOTIFICATION_WARNING, 4000)
        return

    if trailer_url:
        streams.insert(0, {'label': '[TRAILER] HD', 'url': trailer_url})

    if len(streams) == 1 and streams[0]['label'].startswith('[TRAILER]'):
        _mark_no_source(ade_id)
        xbmcgui.Dialog().notification('Starfleet', 'No adult sources for "%s" — skipping' % title,
                                      xbmcgui.NOTIFICATION_WARNING, 4000)
        return

    if len(streams) == 1:
        chosen_url = streams[0]['url']
        chosen_label = streams[0]['label']
    else:
        idx = _select_dialog('Source — %s' % title, [s['label'] for s in streams])
        if idx < 0:
            return
        chosen_url = streams[idx]['url']
        chosen_label = streams[idx]['label']

    resolved = adult_stream_play(chosen_url, title)
    if not resolved:
        xbmcgui.Dialog().notification('Starfleet', 'Could not resolve stream',
                                      xbmcgui.NOTIFICATION_ERROR, 3000)
        return

    li = xbmcgui.ListItem(path=resolved)
    li.setContentLookup(False)
    li.setInfo('video', {'title': title, 'mediatype': 'movie'})
    _url_lc = resolved.lower()
    if '.m3u8' in _url_lc:
        li.setMimeType('application/x-mpegURL')
    elif '.mp4' in _url_lc:
        li.setMimeType('video/mp4')
    if not chosen_label.startswith('[TRAILER]'):
        try:
            from resources.lib import watch_history as _wh0
            _wh0.apply_resume(li, 'ade:%s' % ade_id)
        except Exception:
            pass
    xbmc.Player().play(resolved, li)

    try:
        from resources.lib import watch_history as _wh
        _wh.start_playback_monitor('ade:%s' % ade_id, title=title)
    except Exception:
        pass


def _search_free_movies_only(title):
    """Free-stream search scoped to the original 8 legacy sources (freeo,
    xxxms, wpf, spn, xxxsc, xmovix, panda, hqporner) — real feature-length
    movie/video catalogs, matching what ADE itself carries. Deliberately
    does NOT use adult_streams.search_by_title(), which was expanded in
    v2.3.427 to also fan out across the 18 Scenes tube sites (XVideos,
    XNXX, PornHub, etc.) for the dedicated unified-search box — confirmed
    live as a real regression when reused here: those sites' enormous,
    generically-titled short-clip catalogs (thousands of entries like
    "Amateur Teen...") produce false-positive fuzzy title matches against
    an unrelated ADE movie's title far more often than the original 8
    sources ever did, surfacing an irrelevant Scenes site as a "source"
    for a movie it has nothing to do with (reported: "scene sources we
    added show up as sources in movies"). Movies and Scenes are different
    content types with different catalogs; this keeps them separate for
    every purpose EXCEPT the unified search box, which still deliberately
    searches both since finding a performer's individual scenes there
    alongside her movies is the whole point of that screen."""
    from concurrent.futures import as_completed
    from resources.lib import adult_streams as _as
    norm_query = _as._norm_title(title)
    if not norm_query:
        return []
    search_fns = [
        _as._search_freeo_films, _as._search_xxxms_films, _as._search_wpf_films,
        _as._search_spn_films, _as._search_xxxsc_films, _as._search_xmovix_films,
        _as._search_panda_films, _as._search_hqporner_films,
        # Added 2026-08-15: en.paradisehill.cc is a genuine full-length-movie
        # source (same content type as the 8 above). mangoporn.net/
        # streamporn.vip/swingerpornfun.com were also added here initially
        # but corrected per direct confirmation: those three are actually
        # scenes/clip sites, not full movies — removed to avoid reintroducing
        # the exact cross-contamination bug this function exists to prevent
        # (see docstring above).
        _as._search_paradise_films,
        # pelisxporno.net: real WP-search full-length movie catalog, same
        # content type as the rest of this list.
        _as._search_pxp_films,
    ]
    streams, seen_urls = [], set()
    pool = ThreadPoolExecutor(max_workers=len(search_fns))
    futures = {pool.submit(fn, title): fn.__name__ for fn in search_fns}
    try:
        for future in as_completed(futures, timeout=15):
            name = futures[future]
            try:
                films = future.result() or []
                for film in films:
                    if not film:
                        continue
                    if _as._title_matches(norm_query, film.get('title_norm', '')):
                        for s in film.get('streams', []):
                            if s.get('url') and s['url'] not in seen_urls:
                                seen_urls.add(s['url'])
                                streams.append({'label': s.get('label', name), 'url': s['url']})
            except Exception as e:
                xbmc.log('[AFDB] free-movie search error (%s): %s' % (name, e), xbmc.LOGWARNING)
    except Exception as e:
        xbmc.log('[AFDB] free-movie search timeout: %s' % e, xbmc.LOGWARNING)
    finally:
        pool.shutdown(wait=False)
    return streams


def adult_ade_play(handle, ade_id, ade_slug='', title=''):
    """Play an ADE film: trailer + XXXClub (debrid) + free streams in parallel."""
    from resources.lib import ade as _ade, adult_streams as _as, torrent_sources as _ts
    import html as _html_lib
    title = _html_lib.unescape(title)

    dlg = _progress('Grab a tissue… getting your load ready')

    trailer_url = _ade.trailer_url(ade_id)
    streams = []

    def _search_xxxclub():
        try:
            results = _ts.search_xxxclub(title, limit=8, media_type='adult')
            out = []
            for t in (results or []):
                qual = ''
                t_title = t.get('title', '')
                for kw in ('2160p', '4K', '1080p', '720p'):
                    if kw.lower() in t_title.lower():
                        qual = ' [%s]' % kw
                        break
                out.append({'label': '[XXXClub]%s %s [%s]' % (qual, t_title, t.get('size', '')),
                            'url': t.get('magnet', '')})
            return out
        except Exception:
            return []

    def _search_free():
        try:
            return _search_free_movies_only(title) or []
        except Exception:
            return []

    def _search_rintor():
        try:
            results = _ts.search_rintor(title, limit=8, media_type='adult')
            out = []
            for t in (results or []):
                out.append({'label': '[Rintor] %s [%s]' % (t.get('title', ''), t.get('size', '')),
                            'url': t.get('magnet', '')})
            return out
        except Exception:
            return []

    def _search_myporn():
        try:
            from resources.lib import myporn_sources as _mpc
            return _mpc.search_myporn_club(title, limit=5, media_type='adult')
        except Exception:
            return []

    def _search_extto():
        try:
            results = _ts.search_extto(title, limit=8, media_type='adult')
            out = []
            for t in (results or []):
                out.append({'label': '[EXTto] %s [%s]' % (t.get('title', ''), t.get('size', '')),
                            'url': t.get('magnet', '')})
            return out
        except Exception:
            return []

    def _search_requests():
        # Manually curated Requests JSON (resources/lib/request_sources.py)
        # — matched exactly by AdultDVDEmpire's own numeric film id
        # (ade_id), not fuzzy title search. Real, hand-picked links, not a
        # scraper — shown first in the picker below. One matched entry can
        # carry several candidate urls (request_sources.entry_urls) —
        # every one gets its own [Request] line, numbered when there's
        # more than one.
        try:
            from resources.lib import request_sources as _reqsrc
            match = _reqsrc.find_adult_request(ade_id)
            if not match:
                return []
            urls = _reqsrc.entry_urls(match)
            label_base = match.get('title') or title
            out = []
            for i, u in enumerate(urls, 1):
                resolved = _reqsrc.resolve_request_stream(u)
                if not resolved:
                    continue
                label = '[Request] %s' % label_base if len(urls) == 1 else \
                        '[Request] %s (Source %d)' % (label_base, i)
                out.append({'label': label, 'url': resolved})
            return out
        except Exception:
            return []

    collected, canceled = _search_with_cancel(dlg, {
        'requests': (_search_requests, 15),
        'xxxclub': (_search_xxxclub, 25),
        'rintor':  (_search_rintor,  25),
        'myporn':  (_search_myporn,  15),
        'extto':   (_search_extto,   25),
        'free':    (_search_free,    30),
    })
    dlg.close()
    if canceled:
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    for item in collected.get('requests', []):
        if item.get('url'):
            streams.append(item)
    for item in collected.get('xxxclub', []):
        if item.get('url'):
            streams.append(item)
    for item in collected.get('rintor', []):
        if item.get('url'):
            streams.append(item)
    for item in collected.get('myporn', []):
        if item.get('url'):
            streams.append(item)
    for item in collected.get('extto', []):
        if item.get('url'):
            streams.append(item)
    for r in collected.get('free', []):
        if r.get('url'):
            streams.append({'label': '[FREE] %s' % r.get('label', 'Stream'), 'url': r['url']})

    if not streams:
        # No sources and no trailer — nothing to play
        _mark_no_source(ade_id)
        xbmcgui.Dialog().notification('Starfleet', 'No sources found for "%s"' % title,
                                      xbmcgui.NOTIFICATION_WARNING, 4000)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    if trailer_url:
        streams.insert(0, {'label': '[TRAILER] HD', 'url': trailer_url})

    if len(streams) == 1 and streams[0]['label'].startswith('[TRAILER]'):
        # Only trailer available — mark and skip
        _mark_no_source(ade_id)
        xbmcgui.Dialog().notification('Starfleet', 'No adult sources for "%s" — skipping' % title,
                                      xbmcgui.NOTIFICATION_WARNING, 4000)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    if len(streams) == 1:
        chosen_url = streams[0]['url']
        chosen_label = streams[0]['label']
    else:
        idx = _select_dialog('Source — %s' % title, [s['label'] for s in streams])
        if idx < 0:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return
        chosen_url = streams[idx]['url']
        chosen_label = streams[idx]['label']

    resolved = adult_stream_play(chosen_url, title)
    if not resolved:
        xbmcgui.Dialog().notification('Starfleet', 'Could not resolve stream', xbmcgui.NOTIFICATION_ERROR, 3000)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    li = xbmcgui.ListItem(path=resolved)
    li.setContentLookup(False)
    li.setInfo('video', {'title': title, 'mediatype': 'movie'})
    _url_lc = resolved.lower()
    if '.m3u8' in _url_lc:
        li.setMimeType('application/x-mpegURL')
    elif '.mp4' in _url_lc:
        li.setMimeType('video/mp4')
    if not chosen_label.startswith('[TRAILER]'):
        try:
            from resources.lib import watch_history as _wh0
            _wh0.apply_resume(li, 'ade:%s' % ade_id)
        except Exception:
            pass
    xbmcplugin.setResolvedUrl(handle, True, li)

    try:
        from resources.lib import watch_history as _wh
        _wh.start_playback_monitor('ade:%s' % ade_id, title=title)
    except Exception:
        pass


def adult_free_sites(handle, build_url):
    """Top-level menu listing all browsable free adult sites."""
    xbmcplugin.setPluginCategory(handle, 'Free Adult Sites')
    xbmcplugin.setContent(handle, 'files')

    _add_dir(handle, build_url, 'PandaMovies — Browse by Genre',
             {'action': 'adult_panda_genres'},
             plot='Browse adult movies on PandaMovies by genre category')

    _add_dir(handle, build_url, 'HQ Porner — Browse by Category',
             {'action': 'adult_hqp_categories'},
             plot='Browse HD adult movies on HQ Porner by category')

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def adult_panda_genres(handle, build_url):
    """List all genre categories from PandaMovies."""
    from resources.lib import adult_streams as _as
    xbmcplugin.setPluginCategory(handle, 'PandaMovies — Genres')
    xbmcplugin.setContent(handle, 'files')

    dlg = _progress('Loading PandaMovies genres...')
    genres, canceled = _run_cancelable(dlg, _as.get_panda_genres, 25)
    dlg.close()
    if canceled:
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return
    genres = genres or []

    if not genres:
        xbmcgui.Dialog().notification('PandaMovies', 'No genres found', xbmcgui.NOTIFICATION_INFO)
        return

    for g in genres:
        _add_dir(handle, build_url, g['name'],
                 {'action': 'adult_panda_movies', 'genre_url': g['url'], 'page': 1,
                  'genre_name': g['name']},
                 plot='Browse %s movies on PandaMovies' % g['name'])

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)


def adult_panda_movies(handle, build_url, genre_url, genre_name='', page=1):
    """List movies from a PandaMovies genre page."""
    from resources.lib import adult_streams as _as
    xbmcplugin.setPluginCategory(handle, 'PandaMovies — %s' % (genre_name or 'Movies'))
    xbmcplugin.setContent(handle, 'movies')

    dlg = _progress('Loading movies...')
    films, canceled = _run_cancelable(dlg, lambda: _as.get_panda_movies(genre_url, page=page), 25)
    if canceled:
        dlg.close()
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return
    films = films or []
    dlg.update(40, 'Verifying sources...')
    films = _verify_stream_sources(films, lambda f: _as.get_panda_movie_detail(f['slug'], f['url']))
    canceled = dlg.iscanceled()
    dlg.close()
    if canceled:
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    if not films:
        xbmcgui.Dialog().notification('PandaMovies', 'No movies found', xbmcgui.NOTIFICATION_INFO)
        return

    for film in films:
        li = xbmcgui.ListItem(label=film['title'])
        try:
            tag = li.getVideoInfoTag()
            tag.setTitle(film['title'])
            tag.setMpaa('Adults Only')
        except Exception:
            li.setInfo('video', {'title': film['title'], 'mpaa': 'Adults Only'})
        if film.get('thumb'):
            li.setArt({'thumb': film['thumb'], 'poster': film['thumb'], 'fanart': film['thumb']})
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action': 'adult_panda_play', 'slug': film['slug'],
                       'film_url': film['url'], 'title': film['title']}),
            li, False
        )

    _next_page(handle, build_url, 'adult_panda_movies', page,
               extra={'genre_url': genre_url, 'genre_name': genre_name})
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def adult_panda_play(handle, slug, film_url, title=''):
    """Fetch PandaMovies detail, show stream picker, play via ResolveURL."""
    from resources.lib import adult_streams as _as

    dlg = _progress('Finding streams...')
    film = _as.get_panda_movie_detail(slug, film_url)
    dlg.close()

    if not film or not film.get('streams'):
        xbmcgui.Dialog().notification('PandaMovies', 'No streams found for: %s' % title,
                                       xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    film_title = title or film.get('title', '')
    streams = film['streams']

    if len(streams) == 1:
        chosen = streams[0]
    else:
        options = [s['label'] for s in streams]
        idx = _select_dialog('%s — Choose stream' % film_title, options)
        if idx < 0:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return
        chosen = streams[idx]

    resolved = adult_stream_play(chosen['url'], film_title)
    if not resolved:
        xbmcgui.Dialog().notification('PandaMovies', 'Could not resolve stream',
                                       xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    li = xbmcgui.ListItem(path=resolved, label=film_title)
    li.setContentLookup(False)
    li.setInfo('video', {'title': film_title, 'mediatype': 'movie', 'mpaa': 'Adults Only'})
    if '.m3u8' in resolved.lower():
        li.setMimeType('application/x-mpegURL')
    elif '.mp4' in resolved.lower():
        li.setMimeType('video/mp4')
    try:
        from resources.lib import watch_history as _wh
        _wh.apply_resume(li, 'panda:%s' % slug)
    except Exception:
        pass
    xbmcplugin.setResolvedUrl(handle, True, li)

    # PandaMovies previously had no watch-progress tracking at all — added
    # here (same synthetic-key pattern as 'hqp:'/'ade:') so a resume point
    # actually gets recorded for it to apply on the next play.
    try:
        from resources.lib import watch_history as _wh
        _wh.start_playback_monitor('panda:%s' % slug, title=film_title)
    except Exception:
        pass


def adult_hqp_categories(handle, build_url):
    """List all categories from HQ Porner."""
    from resources.lib import adult_streams as _as
    xbmcplugin.setPluginCategory(handle, 'HQ Porner — Categories')
    xbmcplugin.setContent(handle, 'files')

    dlg = _progress('Loading HQ Porner categories...')
    cats, canceled = _run_cancelable(dlg, _as.get_hqporner_categories, 25)
    dlg.close()
    if canceled:
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return
    cats = cats or []

    if not cats:
        xbmcgui.Dialog().notification('HQ Porner', 'No categories found', xbmcgui.NOTIFICATION_INFO)
        return

    for c in cats:
        _add_dir(handle, build_url, c['name'],
                 {'action': 'adult_hqp_movies', 'cat_url': c['url'], 'page': 1,
                  'cat_name': c['name']},
                 plot='Browse %s movies on HQ Porner' % c['name'])

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)


def adult_hqp_movies(handle, build_url, cat_url, cat_name='', page=1):
    """List movies from an HQ Porner category page."""
    from resources.lib import adult_streams as _as
    xbmcplugin.setPluginCategory(handle, 'HQ Porner — %s' % (cat_name or 'Movies'))
    xbmcplugin.setContent(handle, 'movies')

    dlg = _progress('Loading movies...')
    films, canceled = _run_cancelable(dlg, lambda: _as.get_hqporner_movies(cat_url, page=page), 25)
    if canceled:
        dlg.close()
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return
    films = films or []
    dlg.update(40, 'Verifying sources...')
    films = _verify_stream_sources(films, lambda f: _as.get_hqporner_movie_detail(f['slug'], f['url']))
    canceled = dlg.iscanceled()
    dlg.close()
    if canceled:
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    if not films:
        xbmcgui.Dialog().notification('HQ Porner', 'No movies found', xbmcgui.NOTIFICATION_INFO)
        return

    for film in films:
        li = xbmcgui.ListItem(label=film['title'])
        try:
            tag = li.getVideoInfoTag()
            tag.setTitle(film['title'])
            tag.setMpaa('Adults Only')
        except Exception:
            li.setInfo('video', {'title': film['title'], 'mpaa': 'Adults Only'})
        if film.get('thumb'):
            li.setArt({'thumb': film['thumb'], 'poster': film['thumb'], 'fanart': film['thumb']})
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action': 'adult_hqp_play', 'slug': film['slug'],
                       'film_url': film['url'], 'title': film['title']}),
            li, False
        )

    _next_page(handle, build_url, 'adult_hqp_movies', page,
               extra={'cat_url': cat_url, 'cat_name': cat_name})
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def adult_hqp_play(handle, slug, film_url, title=''):
    """Fetch HQ Porner detail, show stream picker, play."""
    from resources.lib import adult_streams as _as

    dlg = _progress('Finding streams...')
    film = _as.get_hqporner_movie_detail(slug, film_url)
    dlg.close()

    if not film or not film.get('streams'):
        xbmcgui.Dialog().notification('HQ Porner', 'No streams found for: %s' % title,
                                       xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    film_title = title or film.get('title', '')
    streams = film['streams']

    if len(streams) == 1:
        chosen = streams[0]
    else:
        options = [s['label'] for s in streams]
        idx = _select_dialog('%s — Choose stream' % film_title, options)
        if idx < 0:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return
        chosen = streams[idx]

    resolved = adult_stream_play(chosen['url'], film_title)
    if not resolved:
        xbmcgui.Dialog().notification('HQ Porner', 'Could not resolve stream',
                                       xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    li = xbmcgui.ListItem(path=resolved, label=film_title)
    li.setContentLookup(False)
    li.setInfo('video', {'title': film_title, 'mediatype': 'movie', 'mpaa': 'Adults Only'})
    if '.m3u8' in resolved.lower():
        li.setMimeType('application/x-mpegURL')
    elif '.mp4' in resolved.lower():
        li.setMimeType('video/mp4')
    try:
        from resources.lib import watch_history as _wh0
        _wh0.apply_resume(li, 'hqp:%s' % slug)
    except Exception:
        pass
    xbmcplugin.setResolvedUrl(handle, True, li)

    try:
        from resources.lib import watch_history as _wh
        _wh.start_playback_monitor('hqp:%s' % slug, title=film_title)
    except Exception:
        pass


def adult_hqp_play_direct(slug, film_url, title=''):
    """Play an HQ Porner film from the custom-skin category grid without
    going through the plugin URL resolver — same background-thread, no-
    handle pattern as adult_ade_play_direct/javseen_play_direct."""
    from resources.lib import adult_streams as _as

    dlg = _progress('Finding streams...')
    film = _as.get_hqporner_movie_detail(slug, film_url)
    dlg.close()

    if not film or not film.get('streams'):
        xbmcgui.Dialog().notification('HQ Porner', 'No streams found for: %s' % title,
                                       xbmcgui.NOTIFICATION_WARNING)
        return

    film_title = title or film.get('title', '')
    streams = film['streams']

    if len(streams) == 1:
        chosen = streams[0]
    else:
        options = [s['label'] for s in streams]
        idx = _select_dialog('%s — Choose stream' % film_title, options)
        if idx < 0:
            return
        chosen = streams[idx]

    resolved = adult_stream_play(chosen['url'], film_title)
    if not resolved:
        xbmcgui.Dialog().notification('HQ Porner', 'Could not resolve stream',
                                       xbmcgui.NOTIFICATION_ERROR)
        return

    li = xbmcgui.ListItem(path=resolved, label=film_title)
    li.setContentLookup(False)
    li.setInfo('video', {'title': film_title, 'mediatype': 'movie', 'mpaa': 'Adults Only'})
    if '.m3u8' in resolved.lower():
        li.setMimeType('application/x-mpegURL')
    elif '.mp4' in resolved.lower():
        li.setMimeType('video/mp4')
    try:
        from resources.lib import watch_history as _wh0
        _wh0.apply_resume(li, 'hqp:%s' % slug)
    except Exception:
        pass
    xbmc.Player().play(resolved, li)

    try:
        from resources.lib import watch_history as _wh
        _wh.start_playback_monitor('hqp:%s' % slug, title=film_title)
    except Exception:
        pass


# ── Scenes — multi-site selector (HQPorner + tube sites) ──────────────────────
#
# Added 2026-08-14. One generic set of movies/search/play handlers, keyed by
# a 'site' registry, instead of a hand-copied function-trio per site — every
# site added to _SCENE_SITES automatically gets a working listing, search
# and play path with zero new routing code. HQPorner itself keeps its own
# existing category-first flow (adult_hqp_categories) since it has real
# genre categories the tube sites here don't expose without a lot more
# per-site archaeology; it's offered as its own choice in the same selector.

def _adult_scene_site_registry():
    from resources.lib import adult_streams as _as
    return {
        'xvideos':  {'label': 'XVideos',  'movies': _as.get_xvideos_movies,  'detail': _as.get_xvideos_movie_detail,  'search': _as.search_xvideos_movies},
        'xnxx':     {'label': 'XNXX',     'movies': _as.get_xnxx_movies,     'detail': _as.get_xnxx_movie_detail,     'search': _as.search_xnxx_movies},
        'pornhub':  {'label': 'PornHub',  'movies': _as.get_pornhub_movies,  'detail': _as.get_pornhub_movie_detail,  'search': _as.search_pornhub_movies},
        'youporn':  {'label': 'YouPorn',  'movies': _as.get_youporn_movies,  'detail': _as.get_youporn_movie_detail,  'search': _as.search_youporn_movies},
        'xhamster': {'label': 'xHamster', 'movies': _as.get_xhamster_movies, 'detail': _as.get_xhamster_movie_detail, 'search': _as.search_xhamster_movies},
        'xerotica': {'label': 'Xerotica', 'movies': _as.get_xerotica_movies, 'detail': _as.get_xerotica_movie_detail, 'search': _as.search_xerotica_movies},
        'redtube':  {'label': 'RedTube',  'movies': _as.get_redtube_movies,  'detail': _as.get_redtube_movie_detail,  'search': _as.search_redtube_movies},
        'tube8':    {'label': 'Tube8',    'movies': _as.get_tube8_movies,    'detail': _as.get_tube8_movie_detail,    'search': _as.search_tube8_movies},
        'thumbzilla': {'label': 'Thumbzilla', 'movies': _as.get_thumbzilla_movies, 'detail': _as.get_thumbzilla_movie_detail, 'search': _as.search_thumbzilla_movies},
        'porntrex': {'label': 'Porntrex', 'movies': _as.get_porntrex_movies, 'detail': _as.get_porntrex_movie_detail, 'search': _as.search_porntrex_movies},
        'noodlemagazine': {'label': 'NoodleMagazine', 'movies': _as.get_noodlemagazine_movies, 'detail': _as.get_noodlemagazine_movie_detail, 'search': _as.search_noodlemagazine_movies},
        'letmejizz': {'label': 'LetMeJizz', 'movies': _as.get_letmejizz_movies, 'detail': _as.get_letmejizz_movie_detail, 'search': _as.search_letmejizz_movies},
        'eporner': {'label': 'Eporner', 'movies': _as.get_eporner_movies, 'detail': _as.get_eporner_movie_detail, 'search': _as.search_eporner_movies},
        'beeg':    {'label': 'Beeg',    'movies': _as.get_beeg_movies,    'detail': _as.get_beeg_movie_detail,    'search': _as.search_beeg_movies},
        'tnaflix': {'label': 'TNAFlix', 'movies': _as.get_tnaflix_movies, 'detail': _as.get_tnaflix_movie_detail, 'search': _as.search_tnaflix_movies},
        'txxx':    {'label': 'TXXX',    'movies': _as.get_txxx_movies,    'detail': _as.get_txxx_movie_detail,    'search': _as.search_txxx_movies},
        'hdzog':   {'label': 'HDZog',   'movies': _as.get_hdzog_movies,   'detail': _as.get_hdzog_movie_detail,   'search': _as.search_hdzog_movies},
        '6xtube':  {'label': '6XTube',  'movies': _as.get_6xtube_movies,  'detail': _as.get_6xtube_movie_detail,  'search': _as.search_6xtube_movies},
        # Added 2026-08-15 — all live-verified (real server-rendered listing,
        # real detail-page stream, real page-N pagination for browse) before
        # wiring in. cumlouder and allpornstream have no working search of
        # their own (cumlouder's search is Cloudflare-challenged — not
        # bypassed per policy; allpornstream has no discoverable search
        # endpoint at all) so their 'search' entries are still wired (the
        # Scenes picker's per-site "Search X" menu item needs the key to
        # exist) but always return no results rather than a broken search.
        'pornhat':  {'label': 'PornHat',  'movies': _as.get_pornhat_movies,  'detail': _as.get_pornhat_movie_detail,  'search': _as.search_pornhat_movies},
        'okxxx':    {'label': 'OK.XXX',   'movies': _as.get_okxxx_movies,    'detail': _as.get_okxxx_movie_detail,    'search': _as.search_okxxx_movies},
        '3movs':    {'label': '3Movs',    'movies': _as.get_3movs_movies,    'detail': _as.get_3movs_movie_detail,    'search': _as.search_3movs_movies},
        'justporn': {'label': 'JustPorn', 'movies': _as.get_justporn_movies, 'detail': _as.get_justporn_movie_detail, 'search': _as.search_justporn_movies},
        'porn00':   {'label': 'Porn00',   'movies': _as.get_porn00_movies,   'detail': _as.get_porn00_movie_detail,   'search': _as.search_porn00_movies},
        'xmoviesforyou': {'label': 'XMoviesForYou', 'movies': _as.get_xmoviesforyou_movies, 'detail': _as.get_xmoviesforyou_movie_detail, 'search': _as.search_xmoviesforyou_movies},
        'pornone':  {'label': 'PornOne',  'movies': _as.get_pornone_movies,  'detail': _as.get_pornone_movie_detail,  'search': _as.search_pornone_movies},
        'porndig':  {'label': 'PornDig',  'movies': _as.get_porndig_movies,  'detail': _as.get_porndig_movie_detail,  'search': _as.search_porndig_movies},
        'cumlouder': {'label': 'Cumlouder', 'movies': _as.get_cumlouder_movies, 'detail': _as.get_cumlouder_movie_detail, 'search': _as.search_cumlouder_movies},
        'porngo':   {'label': 'PornGO',   'movies': _as.get_porngo_movies,   'detail': _as.get_porngo_movie_detail,   'search': _as.search_porngo_movies},
        'allpornstream': {'label': 'AllPornStream', 'movies': _as.get_allpornstream_movies, 'detail': _as.get_allpornstream_movie_detail, 'search': _as.search_allpornstream_movies},
    }


def adult_scenes_select(handle, build_url):
    """Entry point for the Adult menu's Scenes item — themed picker between
    HQPorner's own category browse and every registered tube site's Latest
    listing."""
    registry = _adult_scene_site_registry()
    labels = ['HQPorner (browse by category)'] + [v['label'] for v in registry.values()]
    idx = _select_dialog('Scenes — Choose Source', labels)
    if idx < 0:
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return
    if idx == 0:
        adult_hqp_categories(handle, build_url)
        return
    site_key = list(registry.keys())[idx - 1]
    adult_scene_movies(handle, build_url, site_key, 1)


def _adult_scene_render(handle, build_url, films, site_key, site_label):
    for film in films:
        li = xbmcgui.ListItem(label=film['title'])
        try:
            tag = li.getVideoInfoTag()
            tag.setTitle(film['title'])
            tag.setMpaa('Adults Only')
        except Exception:
            li.setInfo('video', {'title': film['title'], 'mpaa': 'Adults Only'})
        if film.get('thumb'):
            li.setArt({'thumb': film['thumb'], 'poster': film['thumb'], 'fanart': film['thumb']})
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action': 'adult_scene_play', 'site': site_key, 'slug': film['slug'],
                       'film_url': film['url'], 'title': film['title']}),
            li, False
        )
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def adult_scene_movies(handle, build_url, site, page=1):
    registry = _adult_scene_site_registry()
    site_info = registry.get(site)
    if not site_info:
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return
    label = site_info['label']
    xbmcplugin.setPluginCategory(handle, '%s — Latest' % label)
    xbmcplugin.setContent(handle, 'movies')

    dlg = _progress('Loading %s...' % label)
    films, canceled = _run_cancelable(dlg, lambda: site_info['movies'](page), 25)
    if canceled:
        dlg.close()
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return
    films = films or []
    dlg.update(40, 'Verifying sources...')
    films = _verify_stream_sources(films, lambda f, d=site_info['detail']: d(f['slug'], f['url']))
    canceled = dlg.iscanceled()
    dlg.close()
    if canceled:
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    _add_dir(handle, build_url, '🔍  Search %s' % label,
             {'action': 'adult_scene_search', 'site': site},
             plot='Search %s by name or keyword' % label)

    if not films:
        xbmcgui.Dialog().notification(label, 'No videos found', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(handle)
        return

    _adult_scene_render(handle, build_url, films, site, label)
    _next_page(handle, build_url, 'adult_scene_movies', page, extra={'site': site})


def adult_scene_search(handle, build_url, site):
    registry = _adult_scene_site_registry()
    site_info = registry.get(site)
    if not site_info:
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return
    label = site_info['label']

    kb = xbmc.Keyboard('', 'Search %s' % label)
    kb.doModal()
    if not kb.isConfirmed() or not kb.getText().strip():
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return
    query = kb.getText().strip()

    xbmcplugin.setPluginCategory(handle, '%s — Search: %s' % (label, query))
    xbmcplugin.setContent(handle, 'movies')

    dlg = _progress('Searching %s...' % label)
    films, canceled = _run_cancelable(dlg, lambda: site_info['search'](query), 25)
    dlg.close()
    if canceled:
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return
    films = films or []

    if not films:
        xbmcgui.Dialog().notification(label, 'No results for: %s' % query, xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(handle)
        return

    _adult_scene_render(handle, build_url, films, site, label)
    xbmcplugin.endOfDirectory(handle)


def adult_scene_play(handle, site, slug, film_url, title=''):
    registry = _adult_scene_site_registry()
    site_info = registry.get(site)
    if not site_info:
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return
    label = site_info['label']

    dlg = _progress('Finding streams...')
    film = site_info['detail'](slug, film_url)
    dlg.close()

    if not film or not film.get('streams'):
        xbmcgui.Dialog().notification(label, 'No streams found for: %s' % title,
                                       xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    film_title = title or film.get('title', '')
    streams = film['streams']

    if len(streams) == 1:
        chosen = streams[0]
    else:
        options = [s['label'] for s in streams]
        idx = _select_dialog('%s — Choose stream' % film_title, options)
        if idx < 0:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return
        chosen = streams[idx]

    resolved = adult_stream_play(chosen['url'], film_title)
    if not resolved:
        xbmcgui.Dialog().notification(label, 'Could not resolve stream',
                                       xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    # A handful of sites' CDNs 403/404 with no Referer at all (confirmed
    # live for pornhub/xerotica) — adult_stream_play() only ever resolves
    # magnets/hoster pages, it never adds this, so it's applied here once,
    # after resolution, using this codebase's own url|Referer=... pipe
    # syntax Kodi's player already understands elsewhere (sports_sources.py
    # daddylive/falconstreams resolvers). Only applied when resolved_url is
    # still the plain URL adult_stream_play was given (i.e. nothing else
    # already resolved/rewrote it into something like a magnet or an
    # Elementum plugin:// URI, where appending a Referer wouldn't make sense).
    referer = chosen.get('referer')
    if referer and resolved == chosen['url'] and resolved.startswith('http'):
        from urllib.parse import quote as _uq
        resolved = '%s|Referer=%s' % (resolved, _uq(referer, safe=''))

    li = xbmcgui.ListItem(path=resolved, label=film_title)
    li.setContentLookup(False)
    li.setInfo('video', {'title': film_title, 'mediatype': 'movie', 'mpaa': 'Adults Only'})
    if '.m3u8' in resolved.lower():
        li.setMimeType('application/x-mpegURL')
    elif '.mp4' in resolved.lower():
        li.setMimeType('video/mp4')
    try:
        from resources.lib import watch_history as _wh0
        _wh0.apply_resume(li, '%s:%s' % (site, slug))
    except Exception:
        pass
    xbmcplugin.setResolvedUrl(handle, True, li)

    try:
        from resources.lib import watch_history as _wh
        _wh.start_playback_monitor('%s:%s' % (site, slug), title=film_title)
    except Exception:
        pass


def adult_scene_play_direct(site, slug, film_url, title=''):
    """Play a Scenes tube-site film from the custom-skin category grid
    without going through the plugin URL resolver — same background-thread,
    no-handle pattern as adult_hqp_play_direct."""
    registry = _adult_scene_site_registry()
    site_info = registry.get(site)
    if not site_info:
        return
    label = site_info['label']

    dlg = _progress('Finding streams...')
    film = site_info['detail'](slug, film_url)
    dlg.close()

    if not film or not film.get('streams'):
        xbmcgui.Dialog().notification(label, 'No streams found for: %s' % title,
                                       xbmcgui.NOTIFICATION_WARNING)
        return

    film_title = title or film.get('title', '')
    streams = film['streams']

    if len(streams) == 1:
        chosen = streams[0]
    else:
        options = [s['label'] for s in streams]
        idx = _select_dialog('%s — Choose stream' % film_title, options)
        if idx < 0:
            return
        chosen = streams[idx]

    resolved = adult_stream_play(chosen['url'], film_title)
    if not resolved:
        xbmcgui.Dialog().notification(label, 'Could not resolve stream',
                                       xbmcgui.NOTIFICATION_ERROR)
        return

    referer = chosen.get('referer')
    if referer and resolved == chosen['url'] and resolved.startswith('http'):
        from urllib.parse import quote as _uq
        resolved = '%s|Referer=%s' % (resolved, _uq(referer, safe=''))

    li = xbmcgui.ListItem(path=resolved, label=film_title)
    li.setContentLookup(False)
    li.setInfo('video', {'title': film_title, 'mediatype': 'movie', 'mpaa': 'Adults Only'})
    if '.m3u8' in resolved.lower():
        li.setMimeType('application/x-mpegURL')
    elif '.mp4' in resolved.lower():
        li.setMimeType('video/mp4')
    try:
        from resources.lib import watch_history as _wh0
        _wh0.apply_resume(li, '%s:%s' % (site, slug))
    except Exception:
        pass
    xbmc.Player().play(resolved, li)

    try:
        from resources.lib import watch_history as _wh
        _wh.start_playback_monitor('%s:%s' % (site, slug), title=film_title)
    except Exception:
        pass


# ── Adult Trailers ────────────────────────────────────────────────────────────

def adult_trailers(handle, build_url, page=1):
    """
    Show ADE new-release trailers as directly-playable items.
    Fetches up to 24 new releases, resolves trailer URLs in parallel,
    and shows only entries that have a playable trailer (YouTube/Vimeo/mp4).
    """
    from concurrent.futures import ThreadPoolExecutor, as_completed
    from resources.lib import ade as _ade

    xbmcplugin.setPluginCategory(handle, '🎬 Trailers')
    xbmcplugin.setContent(handle, 'movies')

    dlg = _progress('Loading trailers...')
    films, canceled = _run_cancelable(dlg, lambda: _ade.browse_new_releases(page=page), 25)
    dlg.close()
    if canceled:
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return
    films = films or []

    if not films:
        xbmcgui.Dialog().notification('Adult', 'No trailers found',
                                       xbmcgui.NOTIFICATION_INFO)
        return

    # Resolve trailer URLs in parallel — each film needs a detail fetch
    def _get_trailer(film):
        try:
            detail = _ade.get_film_detail(film['id'], film.get('slug', ''))
            trailer = detail.get('trailer', '') if detail else ''
            return film, trailer
        except Exception:
            return film, ''

    trailer_items = []
    with ThreadPoolExecutor(max_workers=8) as pool:
        futures = {pool.submit(_get_trailer, f): f for f in films[:24]}
        for fut in as_completed(futures, timeout=20):
            try:
                film, trailer_url = fut.result()
                if trailer_url:
                    trailer_items.append((film, trailer_url))
            except Exception:
                pass

    if not trailer_items:
        xbmcgui.Dialog().notification('Adult', 'No trailers available right now',
                                       xbmcgui.NOTIFICATION_INFO)
        return

    # Sort by film title
    trailer_items.sort(key=lambda x: x[0].get('title', '').lower())

    for film, trailer_url in trailer_items:
        title = film.get('title', 'Unknown')
        thumb = film.get('thumb', '') or film.get('fanart', '')
        year  = film.get('year', '')
        studio = film.get('studio', '')

        label = '[Trailer] %s' % title
        if year:
            label += ' (%s)' % year

        li = xbmcgui.ListItem(label=label)
        info = {'title': title, 'mediatype': 'movie'}
        if year:
            try:
                info['year'] = int(year)
            except (ValueError, TypeError):
                pass
        if studio:
            info['studio'] = studio
        li.setInfo('video', info)
        if thumb:
            li.setArt({'thumb': thumb, 'poster': thumb, 'fanart': thumb})
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action': 'play_direct', 'stream_url': trailer_url, 'title': title}),
            li, False
        )

    if len(films) >= 24:
        _next_page(handle, build_url, 'adult_trailers', page)

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


# ── Adult Movies Library ──────────────────────────────────────────────────────

_LIBRARY_CACHE_KEY = 'adult_library_full_v5'
_LIBRARY_CACHE_TTL = 2 * 3600  # 2 hours
_LIBRARY_PAGE_SIZE = 20


def _build_full_library():
    """
    Fetch films from all live ADE sections (new releases, new additions,
    bestsellers — movies + videos variants) plus AFDB new/popular.
    Deduplicates, filters to known sources, sorts by year desc.  Cached 2 h.

    ADE's DVD genre categories and its entire /on-demand/... namespace were
    retired site-wide (confirmed dead, no live replacement) and are no longer
    fetched here — see resources/lib/ade.py for details.
    """
    from resources.lib import adult_streams as _as
    from resources.lib import ade as _ade

    def _safe(fn, *args):
        try:
            return fn(*args) or []
        except Exception:
            return []

    all_films_map  = {}
    seen_titles    = set()

    def _norm_title(t):
        import re as _re
        return _re.sub(r'[^a-z0-9]', '', (t or '').lower())

    def _add_films(films):
        for film in (films or []):
            fid = film.get('id', '')
            if not fid:
                fid = '%s_%s' % (film.get('source', 'ade'), film.get('slug', ''))
            if not fid or fid in all_films_map:
                continue
            nt = _norm_title(film.get('title', ''))
            if nt and nt in seen_titles:
                continue
            all_films_map[fid] = film
            if nt:
                seen_titles.add(nt)

    # ── Phase A: static section fetches (all in parallel) ────────────────────
    static_jobs = []

    # AFDB
    for pg in range(1, 4):
        static_jobs += [(afdb.get_new_releases, pg), (afdb.get_popular, pg)]

    # ADE sections — pages 1-3 each. All 5 confirmed live against the current
    # site (2026 restructure): genre categories and /on-demand/... are gone
    # site-wide with no replacement, so they're no longer fetched here.
    dvd_fns = [
        _ade.browse_new_releases,       _ade.browse_bestsellers,
        _ade.browse_new_release_movies, _ade.browse_recently_added_videos,
        _ade.browse_bestseller_videos,
    ]
    for fn in dvd_fns:
        for pg in range(1, 4):
            static_jobs.append((fn, pg))

    with ThreadPoolExecutor(max_workers=20) as pool:
        futs = [pool.submit(_safe, fn, arg) for fn, arg in static_jobs]
        for fut in futs:
            try:
                _add_films(fut.result(timeout=25))
            except Exception:
                pass

    # ── Phase C: free stream sites + panda + hqporner (bulk list-page stubs) ─
    try:
        from resources.lib import adult_streams as _as_bulk
        _add_films(_as_bulk.get_library_stubs_bulk(max_pages=15))
    except Exception as _e:
        xbmc.log('[Starfleet/Library] bulk stubs error: %s' % _e, xbmc.LOGWARNING)

    films = list(all_films_map.values())
    xbmc.log('[Starfleet/Library] _build_full_library: %d unique films before filter' % len(films), xbmc.LOGWARNING)

    _as.prewarm_title_index()
    films = _filter_films_with_sources(films)

    def _year_key(f):
        y = f.get('year', '') or ''
        try:
            return int(str(y)[:4]) if str(y).isdigit() else 0
        except Exception:
            return 0

    films.sort(key=_year_key, reverse=True)
    xbmc.log('[Starfleet/Library] _build_full_library: %d films after filter/sort' % len(films), xbmc.LOGWARNING)
    return films


def get_home_carousel_data(rows=3, per_row=20):
    """
    Return a dict of context row-sets for HomeWindow.
    Keys: 'default', 'movies', 'tv'
    Each value is a list of 3 row-lists (each list = up to per_row film dicts).
    """
    try:
        from resources.lib import metadata as _meta
        from concurrent.futures import ThreadPoolExecutor

        def _movie(m):
            return {
                'id': str(m.get('tmdb_id', '')), 'tmdb_id': str(m.get('tmdb_id', '')),
                'title': m.get('title', ''), 'thumb': m.get('thumb', ''),
                'fanart': m.get('fanart', m.get('thumb', '')),
                'plot': m.get('overview', ''), 'year': str(m.get('year', '')),
                'rating': str(m.get('rating', '')), 'source': 'tmdb', 'media_type': 'movie',
            }
        def _tv(m):
            return {
                'id': str(m.get('tmdb_id', '')), 'tmdb_id': str(m.get('tmdb_id', '')),
                'title': m.get('title', ''), 'thumb': m.get('thumb', ''),
                'fanart': m.get('fanart', m.get('thumb', '')),
                'plot': m.get('overview', ''), 'year': str(m.get('year', '')),
                'rating': str(m.get('rating', '')), 'source': 'tmdb', 'media_type': 'tv',
            }

        from resources.lib import sports_sources as _ss

        _CAROUSEL_PAGES = 4  # ~60-100 items/row instead of one ~20-item page,

        def _multi_page(fetch_fn, pages=_CAROUSEL_PAGES):
            """Fetch several sequential pages from a TMDB-style paginated
            fetch_fn and concatenate them — per explicit request, every
            carousel row should show more than a single page's worth
            whenever the source actually has more to offer, without going
            fully unlimited (TMDB's own Popular/Trending lists run into
            hundreds of pages, which would balloon Home's load time,
            especially on Firestick). Sequential, not threaded, so this
            still counts as exactly one worker slot in the caller's own
            ThreadPoolExecutor rather than multiplying concurrent
            connections beyond its own cap."""
            out = []
            for p in range(1, pages + 1):
                try:
                    batch = fetch_fn(page=p) or []
                except Exception:
                    batch = []
                if not batch:
                    break
                out.extend(batch)
            return out

        # Cap at 6 workers — 12 simultaneous threads OOM-crashes low-RAM devices (FireStick)
        ex = ThreadPoolExecutor(max_workers=6)
        f_new      = ex.submit(_multi_page, _meta.get_movies_new)
        f_popular  = ex.submit(_multi_page, _meta.get_movies_popular)
        f_top      = ex.submit(_multi_page, _meta.get_movies_top_rated)
        f_upcoming = ex.submit(_multi_page, _meta.get_movies_upcoming)
        f_trend    = ex.submit(_multi_page, _meta.get_movies_trending)
        f_tv_pop   = ex.submit(_multi_page, _meta.get_tv_popular)
        f_tv_top   = ex.submit(_multi_page, _meta.get_tv_top_rated)
        f_tv_air   = ex.submit(_multi_page, _meta.get_tv_airing_today)
        f_tv_onair = ex.submit(_multi_page, _meta.get_tv_on_the_air)
        f_sp_soc   = ex.submit(_ss.get_todays_sport_events, 'soccer', 'Soccer',            per_row)
        f_sp_nba   = ex.submit(_ss.get_todays_sport_events, 'nba',    'Basketball',        per_row)
        f_sp_nhl   = ex.submit(_ss.get_todays_sport_events, 'nhl',    'Ice Hockey',        per_row)
        f_sp_mlb   = ex.submit(_ss.get_todays_sport_events, 'mlb',    'Baseball',          per_row)
        f_sp_nfl   = ex.submit(_ss.get_todays_sport_events, 'nfl',    'American Football', per_row)
        from resources.lib import trakt_widgets as _tw
        # No per_row here — that would clamp back down to one page's worth
        # (20), undoing get_anticipated_movies/shows' own multi-page fetch.
        # Their own default (80) already matches every other carousel row.
        f_trakt_mov = ex.submit(_tw.get_anticipated_movies)
        f_trakt_tv  = ex.submit(_tw.get_anticipated_shows)
        ex.shutdown(wait=False)

        # No [:per_row] slicing on these 11 — _multi_page already fetched
        # several pages per row on purpose (see its own docstring above),
        # so truncating back down to one page's worth here would silently
        # undo that.
        try: new_films      = [_movie(m) for m in (f_new.result(timeout=30)      or [])]
        except Exception: new_films = []
        try: pop_films      = [_movie(m) for m in (f_popular.result(timeout=30)  or [])]
        except Exception: pop_films = []
        try: top_films      = [_movie(m) for m in (f_top.result(timeout=30)      or [])]
        except Exception: top_films = []
        try: upcoming_films = [_movie(m) for m in (f_upcoming.result(timeout=30) or [])]
        except Exception: upcoming_films = []
        try: trend_films    = [_movie(m) for m in (f_trend.result(timeout=30)    or [])]
        except Exception: trend_films = []
        try: tv_pop         = [_tv(m)   for m in (f_tv_pop.result(timeout=30)    or [])]
        except Exception: tv_pop = []
        try: tv_top         = [_tv(m)   for m in (f_tv_top.result(timeout=30)    or [])]
        except Exception: tv_top = []
        try: tv_air         = [_tv(m)   for m in (f_tv_air.result(timeout=30)    or [])]
        except Exception: tv_air = []
        try: tv_onair       = [_tv(m)   for m in (f_tv_onair.result(timeout=30)  or [])]
        except Exception: tv_onair = []

        try: sp_soc  = f_sp_soc.result(timeout=90) or []
        except Exception: sp_soc = []
        try: sp_nba  = f_sp_nba.result(timeout=90) or []
        except Exception: sp_nba = []
        try: sp_nhl  = f_sp_nhl.result(timeout=90) or []
        except Exception: sp_nhl = []
        try: sp_mlb  = f_sp_mlb.result(timeout=90) or []
        except Exception: sp_mlb = []
        try: sp_nfl  = f_sp_nfl.result(timeout=90) or []
        except Exception: sp_nfl = []
        sp_row2 = (sp_nba + sp_nhl)[:per_row]
        sp_row3 = (sp_mlb + sp_nfl)[:per_row]

        # Trakt "Anticipated" widgets for the Settings-hover carousel — return
        # [] with no network call at all when no Client ID is configured (see
        # trakt_widgets.py), so this is always safe/cheap to include. No
        # [:per_row] here — would clamp back down to 20 and undo their own
        # multi-page fetch, same reasoning as the movie/tv rows above.
        try: trakt_mov = f_trakt_mov.result(timeout=30) or []
        except Exception: trakt_mov = []
        try: trakt_tv  = f_trakt_tv.result(timeout=30)  or []
        except Exception: trakt_tv = []

        def _fav_carousel(media_type):
            # No [:per_row] cap here on purpose — unlike the TMDB/sports rows
            # above (which are naturally capped at 20 by the source API's own
            # page size), favorites are user-curated with no such limit, and
            # were getting silently truncated to 20 for no real reason.
            try:
                from resources.lib import favorites as _fav
                items = _fav.get_movies() if media_type == 'movie' else _fav.get_tv()
                return [{'id': str(f.get('tmdb_id', '')), 'tmdb_id': str(f.get('tmdb_id', '')),
                         'title': f.get('title', ''), 'thumb': f.get('thumb', ''),
                         'fanart': f.get('fanart', ''), 'source': 'tmdb',
                         'media_type': media_type} for f in (items or [])]
            except Exception:
                return []

        xbmc.log('[Starfleet/Home] TMDB rows: %d new / %d popular / %d top / %d tv_pop / %d tv_top / %d airing' % (
            len(new_films), len(pop_films), len(top_films), len(tv_pop), len(tv_top), len(tv_air)), xbmc.LOGINFO)
        xbmc.log('[Starfleet/Home] Sports rows: soc=%d nba=%d nhl=%d mlb=%d nfl=%d' % (
            len(sp_soc), len(sp_nba), len(sp_nhl), len(sp_mlb), len(sp_nfl)), xbmc.LOGINFO)

        # Adult rows — only fetch if adult section is enabled (saves RAM + network on FireStick)
        ade_new_films = ade_recent_films = ade_fav_films = []
        _adult_on = False
        try:
            _adult_on = xbmcaddon.Addon('plugin.video.starfleet').getSetting('adult_enabled') == 'true'
        except Exception:
            pass
        try:
            if not _adult_on:
                raise Exception('adult disabled')
            from resources.lib import ade as _ade, adult_favorites as _af

            def _ade_item(film):
                return {
                    'id': str(film.get('id', '')), 'ade_id': str(film.get('id', '')),
                    'ade_slug': film.get('slug', ''),
                    'title': film.get('title', ''), 'thumb': film.get('thumb', ''),
                    'fanart': film.get('fanart', film.get('thumb', '')),
                    'source': 'ade', 'media_type': 'movie',
                }

            def _ade_multi_page(fetch_fn, pages=_CAROUSEL_PAGES):
                out = []
                for p in range(1, pages + 1):
                    try:
                        batch = fetch_fn(p) or []
                    except Exception:
                        batch = []
                    if not batch:
                        break
                    out.extend(batch)
                return out

            _ade_pool = ThreadPoolExecutor(max_workers=2)
            f_ade_new    = _ade_pool.submit(_ade_multi_page, _ade.browse_new_release_movies)
            f_ade_recent = _ade_pool.submit(_ade_multi_page, _ade.browse_recently_added_videos)
            _ade_pool.shutdown(wait=False)

            # No [:per_row] — same reasoning as the movie/tv rows above.
            try: ade_new_films    = [_ade_item(m) for m in (f_ade_new.result(timeout=25)    or [])]
            except Exception: ade_new_films = []
            try: ade_recent_films = [_ade_item(m) for m in (f_ade_recent.result(timeout=25) or [])]
            except Exception: ade_recent_films = []

            # Filter out ADE items previously found to have no adult sources.
            # Deliberately the CHEAP id-only check, not the full
            # _filter_films_with_sources() used by the native adult_browse_*
            # menus and the custom-skin category grid — this widget row is
            # rebuilt on every Home background refresh (not a one-time,
            # user-initiated page open like those two), and
            # _filter_films_with_sources() synchronously live-searches every
            # free-stream scraper for each not-yet-confirmed title. Doing
            # that here turned every periodic refresh into a burst of
            # dozens of scraper calls — confirmed live: it collided with an
            # unrelated movie scrape and made the whole UI feel frozen.
            # _load_no_source_ids() is a local id-set lookup, no network —
            # it still hides anything a real play attempt has already
            # confirmed dead, just without adding a new expensive check of
            # its own on top of the play-attempt-based one.
            _no_src = _load_no_source_ids()
            if _no_src:
                ade_new_films    = [m for m in ade_new_films    if str(m.get('ade_id', '')) not in _no_src]
                ade_recent_films = [m for m in ade_recent_films if str(m.get('ade_id', '')) not in _no_src]

            # No [:per_row] cap here either — same reasoning as _fav_carousel.
            ade_fav_films = [{'id': f['ade_id'], 'ade_id': f['ade_id'], 'ade_slug': '',
                              'title': f.get('title', ''), 'thumb': f.get('thumb', ''),
                              'fanart': f.get('fanart', f.get('thumb', '')),
                              'source': 'ade', 'media_type': 'movie'}
                             for f in _af.get_all()]
        except Exception as _ae:
            xbmc.log('[Starfleet/Home] adult rows error (non-fatal): %s' % _ae, xbmc.LOGWARNING)

        try:
            from resources.lib import continue_watching as _cw
            cw_row = _cw.get_continue_watching(per_row)
        except Exception as _cwe:
            xbmc.log('[Starfleet/Home] continue watching error (non-fatal): %s' % _cwe, xbmc.LOGWARNING)
            cw_row = []

        return {
            'default': [new_films,  tv_pop,    trend_films,    pop_films],
            'movies':  [new_films,  pop_films,  top_films,     upcoming_films],
            'tv':      [tv_pop,     tv_top,     tv_air,        tv_onair],
            'sports':  [sp_soc,     sp_row2,    sp_row3,       []],
            'live':    [_fav_carousel('movie'), _fav_carousel('tv'), [], []],
            'adult':   [ade_new_films, ade_recent_films, ade_fav_films, []],
            'trakt_anticipated': [trakt_mov, trakt_tv, [], []],
            'radio':   [cw_row, [], [], []],
        }
    except Exception as _e:
        xbmc.log('[Starfleet/Home] get_home_carousel_data error: %s' % _e, xbmc.LOGWARNING)
        empty = [[], [], [], []]
        return {'default': empty, 'movies': empty, 'tv': empty, 'sports': empty, 'live': empty,
                'adult': empty, 'trakt_anticipated': empty, 'radio': empty}


def get_full_library_cached():
    """Load/build the full merged adult-movie library, 2h cached under
    _LIBRARY_CACHE_KEY. Shared by the native adult_movies_library() page
    AND the custom-skin Full Library option (home.py's _open_adult_category)
    so the expensive _build_full_library() pass — which does a real,
    synchronous per-title stream-source verification, not just a network
    fetch — only ever runs once per cache window no matter which UI path
    triggers it first."""
    all_films = _cache.get(_LIBRARY_CACHE_KEY) if _LIBRARY_CACHE_KEY else None
    if all_films is None:
        all_films = _build_full_library()
        try:
            _cache.set(_LIBRARY_CACHE_KEY, all_films, _LIBRARY_CACHE_TTL)
        except Exception:
            pass
    return all_films


def adult_movies_library(handle, build_url, page=1):
    """
    Browse adult movies with local pagination.
    All films are fetched once and cached; each page call slices the cached list.
    """
    import re as _re
    from resources.lib import adult_streams as _as

    xbmcplugin.setPluginCategory(handle, 'Adult Movies — Page %d' % page)
    xbmcplugin.setContent(handle, 'movies')

    # ── Load full library (from cache on warm visits) ─────────────────────────
    all_films = _cache.get(_LIBRARY_CACHE_KEY) if _LIBRARY_CACHE_KEY else None
    if all_films is None:
        dlg = _pdlg.DialogProgress()
        dlg.create('Starfleet', 'Populating list....grab a tissue')
        dlg.update(10, 'Fetching movie catalogue...')
        # _build_full_library() does a real, synchronous per-title stream
        # verification pass across the whole catalogue — the single
        # slowest step in this whole function, and until now the one part
        # of it Cancel could never actually interrupt (the prewarm loop
        # below already correctly checks dlg.iscanceled() every chunk;
        # this call, upstream of it, never did).
        all_films, _canceled = _run_cancelable(dlg, _build_full_library, 90)
        if _canceled:
            dlg.close()
            xbmcplugin.endOfDirectory(handle, succeeded=False)
            return
        all_films = all_films or []
        try:
            _cache.set(_LIBRARY_CACHE_KEY, all_films, _LIBRARY_CACHE_TTL)
        except Exception:
            pass
        dlg.update(80, 'Prewarming metadata...')
        # Prewarm detail for first 36 films in background
        CHUNK_SIZE = 12
        cold_films = all_films[:36]

        def _prewarm_film(film):
            fid   = film.get('id', '')
            fslug = film.get('slug', '')
            title = film.get('title', '')
            if fid and _need_fetch('afdb_film_%s' % fid):
                try:
                    afdb.get_film_detail(fid, fslug)
                except Exception:
                    pass
            if title:
                _ade_ck = 'ade_search_%s' % _re.sub(r'[^a-z0-9]', '_', title.lower())[:80]
                ade_cached = _cache.get(_ade_ck)
                if ade_cached is None:
                    try:
                        from resources.lib import ade as _ade
                        ade_meta = _ade.search_by_title(title)
                        if ade_meta and ade_meta.get('id'):
                            _ade.get_film_detail(ade_meta['id'], ade_meta.get('slug', ''))
                    except Exception:
                        pass

        for chunk_start in range(0, len(cold_films), CHUNK_SIZE):
            if dlg.iscanceled():
                break
            chunk = cold_films[chunk_start: chunk_start + CHUNK_SIZE]
            with ThreadPoolExecutor(max_workers=len(chunk)) as pool:
                futs_chunk = [pool.submit(_prewarm_film, f) for f in chunk]
                for fut in futs_chunk:
                    try:
                        fut.result(timeout=30)
                    except Exception:
                        pass
            pct = 80 + int(18 * (chunk_start + CHUNK_SIZE) / max(len(cold_films), 1))
            dlg.update(min(pct, 98), 'Metadata prewarmed: %d / %d' % (
                min(chunk_start + CHUNK_SIZE, len(cold_films)), len(cold_films)))

        dlg.close()

        # Background: ADE DVD-cover enrichment for all films beyond the first 36.
        # Runs silently so the UI is responsive; results land in ade_search_* cache.
        _bg_enrich_films = all_films[36:]
        if _bg_enrich_films:
            import threading as _thr
            def _bg_ade_enrich(films):
                import re as _re2
                try:
                    from resources.lib import ade as _ade2
                except Exception:
                    return
                for f in films:
                    title = f.get('title', '')
                    if not title:
                        continue
                    ck = 'ade_search_%s' % _re2.sub(r'[^a-z0-9]', '_', title.lower())[:80]
                    if _cache.get(ck) is not None:
                        continue
                    try:
                        meta = _ade2.search_by_title(title)
                        if meta and meta.get('id'):
                            _ade2.get_film_detail(meta['id'], meta.get('slug', ''))
                    except Exception:
                        pass
            _thr.Thread(target=_bg_ade_enrich, args=(_bg_enrich_films,), daemon=True).start()

    # ── Slice for the requested page ──────────────────────────────────────────
    start = (page - 1) * _LIBRARY_PAGE_SIZE
    end   = start + _LIBRARY_PAGE_SIZE
    page_films = all_films[start:end]

    xbmc.log('[Starfleet/Library] PAGE=%d showing films[%d:%d] of %d total. First 3: %s' % (
        page, start, end, len(all_films), [f.get('title','?') for f in page_films[:3]]), xbmc.LOGWARNING)

    if not page_films and page == 1:
        xbmcgui.Dialog().notification(
            'Adult', 'Sources still loading — check back in a moment',
            xbmcgui.NOTIFICATION_INFO, 4000)

    for film in page_films:
        _add_film(handle, build_url, film)

    if end < len(all_films):
        _next_page(handle, build_url, 'adult_movies_library', page)

    # Background: ADE cover enrichment for current page + stream source search
    import threading
    def _bg_page_enrich():
        import re as _re2
        try:
            from resources.lib import ade as _ade2
        except Exception:
            return
        for f in page_films:
            title = f.get('title', '')
            if not title:
                continue
            ck = 'ade_search_%s' % _re2.sub(r'[^a-z0-9]', '_', title.lower())[:80]
            if _cache.get(ck) is not None:
                continue
            try:
                meta = _ade2.search_by_title(title)
                if meta and meta.get('id'):
                    _ade2.get_film_detail(meta['id'], meta.get('slug', ''))
            except Exception:
                pass

    threading.Thread(target=_bg_page_enrich, daemon=True).start()
    _prewarm_actor_details(page_films)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


# ── New Releases ──────────────────────────────────────────────────────────────

def afdb_new(handle, build_url, page=1):
    xbmcplugin.setPluginCategory(handle, '🆕 New Releases')
    xbmcplugin.setContent(handle, 'movies')

    cold = _need_fetch('afdb_new_%d' % page)
    if cold:
        dlg = _progress('Loading new releases...')
        films, canceled = _run_cancelable(dlg, lambda: afdb.get_new_releases(page=page), 25)
        dlg.close()
        if canceled:
            xbmcplugin.endOfDirectory(handle, succeeded=False)
            return
        films = films or []
    else:
        films = afdb.get_new_releases(page=page)

    if not films:
        xbmcgui.Dialog().notification('Adult', 'No results found',
                                       xbmcgui.NOTIFICATION_INFO)
        return

    films = _filter_films_with_sources(films)
    for film in films:
        _add_film(handle, build_url, film)

    _prewarm_film_details(films)

    if len(films) >= PAGE_SIZE:
        _next_page(handle, build_url, 'afdb_new', page)

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


# ── Most Popular ──────────────────────────────────────────────────────────────

def afdb_popular(handle, build_url, page=1):
    xbmcplugin.setPluginCategory(handle, '🏆 Most Popular')
    xbmcplugin.setContent(handle, 'movies')

    cold = _need_fetch('afdb_popular_%d' % page)
    if cold:
        dlg = _progress('Loading popular films...')
        films, canceled = _run_cancelable(dlg, lambda: afdb.get_popular(page=page), 25)
        dlg.close()
        if canceled:
            xbmcplugin.endOfDirectory(handle, succeeded=False)
            return
        films = films or []
    else:
        films = afdb.get_popular(page=page)

    if not films:
        xbmcgui.Dialog().notification('Adult', 'No results found',
                                       xbmcgui.NOTIFICATION_INFO)
        return

    films = _filter_films_with_sources(films)
    for film in films:
        _add_film(handle, build_url, film)

    if len(films) >= PAGE_SIZE:
        _next_page(handle, build_url, 'afdb_popular', page)

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


# ── Categories ────────────────────────────────────────────────────────────────

def afdb_categories(handle, build_url):
    xbmcplugin.setPluginCategory(handle, '🎭 Categories')
    xbmcplugin.setContent(handle, 'files')

    for cat in sorted(afdb.CATEGORIES):
        _add_dir(handle, build_url, cat,
                 {'action': 'afdb_by_category', 'category': cat, 'page': 1},
                 plot='Browse %s films' % cat)

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)


def afdb_by_category(handle, build_url, category, page=1):
    xbmcplugin.setPluginCategory(handle, '🎭 %s' % category)
    xbmcplugin.setContent(handle, 'movies')

    cold = _need_fetch('afdb_cat_%s_%d' % (category.replace(' ', '_'), page))
    if cold:
        dlg = _progress('Loading %s...' % category)
        films, canceled = _run_cancelable(dlg, lambda: afdb.get_by_category(category, page=page), 25)
        dlg.close()
        if canceled:
            xbmcplugin.endOfDirectory(handle, succeeded=False)
            return
        films = films or []
    else:
        films = afdb.get_by_category(category, page=page)

    films = _filter_films_with_sources(films)
    for film in films:
        _add_film(handle, build_url, film)

    if len(films) >= PAGE_SIZE:
        _next_page(handle, build_url, 'afdb_by_category', page,
                   extra={'category': category})

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


# ── Studios ───────────────────────────────────────────────────────────────────

def afdb_studios(handle, build_url, letter='A'):
    xbmcplugin.setPluginCategory(handle, '🎬 Studios — %s' % letter)
    xbmcplugin.setContent(handle, 'files')

    # Alphabet row
    for l in afdb.ALPHABET:
        _add_dir(handle, build_url, '[%s]' % l,
                 {'action': 'afdb_studios', 'letter': l})

    cold = _need_fetch('afdb_studios_%s' % letter)
    if cold:
        dlg = _progress('Loading studios...')
        studios, canceled = _run_cancelable(dlg, lambda: afdb.get_studios(letter), 25)
        dlg.close()
        if canceled:
            xbmcplugin.endOfDirectory(handle, succeeded=False)
            return
        studios = studios or []
    else:
        studios = afdb.get_studios(letter)

    for s in studios:
        _add_dir(handle, build_url, s['name'],
                 {'action': 'afdb_by_studio', 'studio': s['slug'],
                  'studio_name': s['name'], 'page': 1},
                 plot='Films from %s' % s['name'])

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def afdb_by_studio(handle, build_url, studio, studio_name='', page=1):
    xbmcplugin.setPluginCategory(handle, '🎬 %s' % (studio_name or studio))
    xbmcplugin.setContent(handle, 'movies')

    cold = _need_fetch('afdb_studio_%s_%d' % (studio.replace(' ', '_'), page))
    if cold:
        dlg = _progress('Loading studio films...')
        films, canceled = _run_cancelable(dlg, lambda: afdb.get_by_studio(studio, page=page), 25)
        dlg.close()
        if canceled:
            xbmcplugin.endOfDirectory(handle, succeeded=False)
            return
        films = films or []
    else:
        films = afdb.get_by_studio(studio, page=page)

    films = _filter_films_with_sources(films)
    for film in films:
        _add_film(handle, build_url, film)

    if len(films) >= PAGE_SIZE:
        _next_page(handle, build_url, 'afdb_by_studio', page,
                   extra={'studio': studio, 'studio_name': studio_name})

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


# ── Actors ────────────────────────────────────────────────────────────────────

def afdb_actors(handle, build_url, letter='A'):
    xbmcplugin.setPluginCategory(handle, '👤 Actors — %s' % letter)
    xbmcplugin.setContent(handle, 'files')

    # Alphabet row
    for l in afdb.ALPHABET:
        _add_dir(handle, build_url, '[%s]' % l,
                 {'action': 'afdb_actors', 'letter': l})

    cold = _need_fetch('afdb_actors_%s' % letter)
    if cold:
        dlg = _progress('Loading actors...')
        actors, canceled = _run_cancelable(dlg, lambda: afdb.get_actors(letter), 25)
        dlg.close()
        if canceled:
            xbmcplugin.endOfDirectory(handle, succeeded=False)
            return
        actors = actors or []
    else:
        actors = afdb.get_actors(letter)

    for actor in actors:
        li = xbmcgui.ListItem(label=actor['name'])
        li.setInfo('video', {'title': actor['name']})
        li.setArt({
            'thumb':  actor.get('photo', ''),
            'icon':   actor.get('photo', ''),
            'poster': actor.get('photo', ''),
            'fanart': actor.get('photo_large', actor.get('photo', '')),
        })
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action': 'afdb_actor_detail',
                       'actor_id': actor['id'],
                       'actor_slug': actor['slug'],
                       'actor_name': actor['name']}),
            li, True
        )

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def afdb_actor_detail(handle, build_url, actor_id, actor_slug, actor_name=''):
    """
    Show actor profile page:
    - Photo as full-screen poster/fanart
    - Bio, measurements, nationality, hair, eyes, ethnicity
    - Filmography link
    """
    xbmcplugin.setPluginCategory(handle, '👤 %s' % actor_name)
    xbmcplugin.setContent(handle, 'files')

    cold = afdb._cache.get('afdb_actor_detail_%s' % actor_id) is None
    if cold:
        dlg = _progress('Loading %s...' % actor_name)
        actor, canceled = _run_cancelable(dlg, lambda: afdb.get_actor_detail(actor_id, actor_slug), 25)
        dlg.close()
        if canceled:
            xbmcplugin.endOfDirectory(handle, succeeded=False)
            return
        actor = actor or {}
    else:
        actor = afdb.get_actor_detail(actor_id, actor_slug)

    # Build rich plot string from all available fields
    plot_parts = []
    if actor.get('birthday'):
        plot_parts.append('Born: %s' % actor['birthday'])
    if actor.get('nationality'):
        plot_parts.append('Nationality: %s' % actor['nationality'])
    if actor.get('ethnicity'):
        plot_parts.append('Ethnicity: %s' % actor['ethnicity'])
    if actor.get('measurements'):
        plot_parts.append('Measurements: %s' % actor['measurements'])
    if actor.get('height'):
        plot_parts.append('Height: %s' % actor['height'])
    if actor.get('weight'):
        plot_parts.append('Weight: %s' % actor['weight'])
    if actor.get('hair'):
        plot_parts.append('Hair: %s' % actor['hair'])
    if actor.get('eyes'):
        plot_parts.append('Eyes: %s' % actor['eyes'])
    if actor.get('bio'):
        plot_parts.append('\n%s' % actor['bio'])
    plot = '\n'.join(plot_parts)

    # Profile card item
    li = xbmcgui.ListItem(label='ℹ️  %s — Profile' % actor['name'])
    li.setInfo('video', {
        'title': actor['name'],
        'plot':  plot,
    })
    li.setArt({
        'thumb':   actor.get('photo', ''),
        'poster':  actor.get('photo', ''),
        'fanart':  actor.get('photo_large', actor.get('photo', '')),
        'banner':  actor.get('photo_large', actor.get('photo', '')),
    })
    xbmcplugin.addDirectoryItem(handle, build_url({'action': 'afdb_actor_detail',
                                                    'actor_id': actor_id,
                                                    'actor_slug': actor_slug,
                                                    'actor_name': actor['name']}),
                                li, False)

    # Filmography link
    _add_dir(handle, build_url,
             label='🎬  Filmography (%s films)' % (actor.get('filmcount') or ''),
             params={'action': 'afdb_actor_films',
                     'actor_id': actor_id,
                     'actor_slug': actor_slug,
                     'actor_name': actor['name'],
                     'page': 1},
             thumb=actor.get('photo', ''),
             plot='Browse all films featuring %s' % actor['name'])

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def afdb_actor_films(handle, build_url, actor_id, actor_slug,
                     actor_name='', page=1):
    xbmcplugin.setPluginCategory(handle, '👤 %s' % actor_name)
    xbmcplugin.setContent(handle, 'movies')

    cold = _need_fetch('afdb_actor_films_%s_%d' % (actor_id, page))
    if cold:
        dlg = _progress('Loading films...')
        films, canceled = _run_cancelable(dlg, lambda: afdb.get_by_actor(actor_id, actor_slug, page=page), 25)
        dlg.close()
        if canceled:
            xbmcplugin.endOfDirectory(handle, succeeded=False)
            return
        films = films or []
    else:
        films = afdb.get_by_actor(actor_id, actor_slug, page=page)

    if not films:
        xbmcgui.Dialog().notification('Adult', 'No films found for %s' % actor_name,
                                       xbmcgui.NOTIFICATION_INFO)
        return

    films = _filter_films_with_sources(films)
    for film in films:
        _add_film(handle, build_url, film)

    if len(films) >= PAGE_SIZE:
        _next_page(handle, build_url, 'afdb_actor_films', page,
                   extra={'actor_id': actor_id, 'actor_slug': actor_slug,
                          'actor_name': actor_name})

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


# ── Search ────────────────────────────────────────────────────────────────────

def afdb_search(handle, build_url):
    kb = xbmc.Keyboard('', 'Search Adult Film Database')
    kb.doModal()
    if not kb.isConfirmed() or not kb.getText().strip():
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    query = kb.getText().strip()
    xbmcplugin.setPluginCategory(handle, '🔍 Search: %s' % query)
    xbmcplugin.setContent(handle, 'movies')

    dlg = _progress('Searching...')
    films, canceled = _run_cancelable(dlg, lambda: afdb.search_films(query), 25)
    dlg.close()
    if canceled:
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return
    films = films or []

    if not films:
        xbmcgui.Dialog().notification('Adult', 'No results for: %s' % query,
                                       xbmcgui.NOTIFICATION_INFO)
        return

    for film in films:
        _add_film(handle, build_url, film)

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)


_ACTOR_NAME_INDEX_CACHE_KEY = 'afdb_actor_name_index_v1'


def _get_actor_name_index():
    """Full A-Z actor list for name search. AFDB has no actor-search API, so
    this builds one by walking all 26 letter pages in parallel — each page
    is already cached 24h individually by afdb.get_actors, so this is only
    actually expensive the first time it's built; cached whole afterward."""
    cached = _cache.get(_ACTOR_NAME_INDEX_CACHE_KEY)
    if cached is not None:
        return cached

    import string
    from concurrent.futures import as_completed

    def _fetch(letter):
        try:
            return afdb.get_actors(letter)
        except Exception:
            return []

    # Not pool.map() inside a 'with' block — that has no timeout mechanism
    # at all (worse than the with-block-blocks-on-stragglers footgun fixed
    # elsewhere this session, since there isn't even a soft as_completed
    # cutoff to be defeated): if AFDB is slow/down for even one letter,
    # this hangs with zero bound, which a performer search (e.g. "scarlit
    # scandal") pays for on every cold-cache run since _search_actors_by_name
    # calls straight into this. Bounded the same way as the other fixes.
    all_actors = []
    pool = ThreadPoolExecutor(max_workers=13)
    try:
        futures = {pool.submit(_fetch, letter): letter for letter in string.ascii_uppercase}
        for future in as_completed(futures, timeout=15):
            try:
                all_actors.extend(future.result() or [])
            except Exception:
                pass
    except Exception as e:
        xbmc.log('[AFDB] actor name index timeout: %s' % e, xbmc.LOGWARNING)
    finally:
        pool.shutdown(wait=False)

    if all_actors:
        _cache.set(_ACTOR_NAME_INDEX_CACHE_KEY, all_actors, 24 * 3600)
    return all_actors


def _search_actors_by_name(query, max_actors=5):
    """Return up to max_actors {id, slug, name} dicts whose name contains
    query (case-insensitive)."""
    q = query.lower().strip()
    if not q:
        return []
    index = _get_actor_name_index()
    matches = [a for a in index if q in (a.get('name', '') or '').lower()]
    # Prefer names starting with the query over ones just containing it.
    matches.sort(key=lambda a: not (a.get('name', '') or '').lower().startswith(q))
    return matches[:max_actors]


def _films_for_matched_actors(actors, max_per_actor=15):
    from concurrent.futures import as_completed
    films = []

    def _fetch(actor):
        try:
            return afdb.get_by_actor(actor.get('id', ''), actor.get('slug', ''), page=1)
        except Exception:
            return []

    # Same unbounded pool.map() issue as _get_actor_name_index() above —
    # fixed the same way.
    pool = ThreadPoolExecutor(max_workers=max(1, len(actors)))
    try:
        futures = {pool.submit(_fetch, actor): actor for actor in actors}
        for future in as_completed(futures, timeout=15):
            try:
                films.extend((future.result() or [])[:max_per_actor])
            except Exception:
                pass
    except Exception as e:
        xbmc.log('[AFDB] matched-actor films timeout: %s' % e, xbmc.LOGWARNING)
    finally:
        pool.shutdown(wait=False)
    return films


# ── Unified Search ────────────────────────────────────────────────────────────

def _adult_unified_search_data_stream_page(query, page):
    """Page > 1 of the unified Adult search's stream-results branch. Split
    out from _adult_unified_search_data (see its own docstring) since only
    adult_streams.search_by_title is genuinely paginated — every other
    branch there (category-match, actor, AFDB/ADE title, torrent) is
    page-1-only data that would just be re-fetched and re-rendered
    identically on every Next Page click if this ran the whole function
    again instead of only the one branch that actually varies by page.

    Bounded to 20s here too (own ThreadPoolExecutor, not a plain call) —
    confirmed live this was missing: search_by_title() only bounds ITSELF
    to ~55s worst case (its own two internal pools, 20s+35s), which is fine
    for page 1 sitting inside that page's own 20s-capped concurrent group
    but was the ONLY thing bounding a Next Page click when called here
    directly - measured a real 60.3s single-page click, reintroducing
    exactly the "too slow" complaint the page-1 recalibration (8s -> 20s)
    was trying to balance in the first place. Same shutdown(wait=False)
    pattern as every other pool in this file."""
    from concurrent.futures import ThreadPoolExecutor, as_completed
    from resources.lib import adult_streams as _as
    dlg = _progress('Searching "%s" (page %d)...' % (query, page))
    stream_results = []
    pool = ThreadPoolExecutor(max_workers=1)
    try:
        fut = pool.submit(_as.search_by_title, query, page)
        for future in as_completed([fut], timeout=20):
            try:
                stream_results = future.result() or []
            except Exception as e:
                xbmc.log('[AFDB] stream search (page %d) error: %s' % (page, e), xbmc.LOGWARNING)
    except Exception as e:
        xbmc.log('[AFDB] stream search (page %d) timeout: %s' % (page, e), xbmc.LOGWARNING)
    finally:
        dlg.close()
        pool.shutdown(wait=False)
    return [], [], [], stream_results


def _adult_unified_search_data(query, page=1):
    """Actual search/merge logic behind adult_search_unified, extracted so
    the custom-skin Adult search screen (home.py's _open_adult_search) can
    share it instead of duplicating it — this was previously only ever
    called from inside the native listing function below, which meant the
    custom-skin three-panel UI had no equivalent at all and Adult search
    fell through to a plain native Kodi listing (a real, reported
    "skin change" bug — every other Adult screen stays inside our own
    skin). Returns (films, torrent_results, rintor_results, stream_results)
    as plain data; the native function below renders these as
    xbmcgui.ListItems, the custom-skin one builds CategoryListWindow items
    from the exact same data instead.

    Every phase below (category-match fetch, actor search, title search,
    torrent search, stream search) used to run strictly sequentially, each
    already individually bounded by its own as_completed timeout - but with
    5-7 of those bounds stacking one after another, a query that genuinely
    finds nothing anywhere (worst case for every bound) could still take
    3+ minutes even though no single call was unbounded. Confirmed live:
    "facial" went from 409s before the individual-pool fixes to 176s after
    them, entirely from this stacking, not from any one hang. Since these
    phases don't depend on each other's results, they now run inside a
    single shared pool per group instead, so the group's wall-clock time is
    the SLOWEST phase, not the sum of all of them.

    `page` (added 2026-08-14, real pagination for the Scenes/stream search
    results) is passed straight through to adult_streams.search_by_title,
    which is the only branch below that's genuinely paginated — see that
    function's own docstring for exactly which of its ~26 underlying sites
    got real, live-confirmed search pagination. The category-match / actor
    / AFDB-title / ADE-title / torrent branches are deliberately kept on
    page 1 only (none of those sources gained pagination in this change),
    so for page > 1 they're skipped entirely rather than re-run and
    re-rendered — re-running them on every Next Page click would just
    re-pay their own several-second round trips to reproduce the exact
    same page-1 results a second (third, fourth...) time."""
    from concurrent.futures import ThreadPoolExecutor, as_completed
    query_lower = query.lower()

    if page > 1:
        return _adult_unified_search_data_stream_page(query, page)

    # Check if query matches an AFDB category (scene type / tag search)
    category_match = None
    try:
        for cat in afdb.CATEGORIES:
            if query_lower in cat.lower() or cat.lower() in query_lower:
                category_match = cat
                break
    except Exception:
        pass

    # HQPorner has its own, separately-named category list (confirmed live:
    # "Threesome" and "Group Sex" both exist there, matching real user
    # queries like "threesome"/"group" that also happen to match an AFDB
    # category, but AFDB's own naming doesn't cover everything HQPorner
    # does and vice versa) — checked independently of the AFDB match above
    # rather than through a hardcoded name-mapping table, so a query that
    # matches HQPorner's own category wording but not AFDB's still gets
    # this treatment. HQPorner items already carry their own real streams
    # (source='hqporner' is in adult_streams.STREAM_SOURCE_NAMES) so they
    # need no separate source-availability check, unlike AFDB movies.
    hqp_cat_url = None
    try:
        from resources.lib import adult_streams as _as_hqp
        for hcat in _as_hqp._hqporner_categories():
            hname = (hcat.get('name') or '').lower()
            if hname and (query_lower in hname or hname in query_lower):
                hqp_cat_url = hcat.get('url')
                break
    except Exception as e:
        xbmc.log('[AFDB] hqporner category-match error: %s' % e, xbmc.LOGWARNING)

    if category_match or hqp_cat_url:
        dlg = _progress('Searching "%s"...' % (category_match or query))
        from resources.lib import ade as _ade
        from resources.lib import adult_streams as _as
        # ADE also has its own genre-tagged catalog (confirmed live: its
        # search engine understands genre keywords like "anal"/"threesome"
        # server-side, same as ade.search_films() used below for the
        # non-category branch) — merge those movies in here too, since this
        # early-return branch used to short-circuit on AFDB alone the moment
        # a single-word query matched an AFDB category substring, silently
        # skipping ADE (and any real movie there tagged with that category)
        # entirely, even for a query as simple as "threesome". Run alongside
        # the AFDB/HQPorner fetches instead of after them — independent
        # calls, no reason to pay every timeout back to back.
        films, ade_cat_films, hqp_films = [], [], []
        cat_pool = ThreadPoolExecutor(max_workers=3)
        try:
            cat_futs = {}
            if category_match:
                cat_futs[cat_pool.submit(afdb.get_by_category, category_match, page=1)] = 'afdb'
            cat_futs[cat_pool.submit(_ade.search_films, query, limit=30)] = 'ade'
            if hqp_cat_url:
                cat_futs[cat_pool.submit(_as.get_hqporner_category_movies, hqp_cat_url, 1)] = 'hqporner'
            for future in as_completed(cat_futs, timeout=12):
                which = cat_futs[future]
                try:
                    result = future.result() or []
                except Exception as e:
                    xbmc.log('[ADE] category-match %s search error: %s' % (which, e), xbmc.LOGWARNING)
                    result = []
                if which == 'afdb':
                    films = result
                elif which == 'hqporner':
                    hqp_films = result
                else:
                    ade_cat_films = result
        except Exception as e:
            xbmc.log('[ADE] category-match search timeout: %s' % e, xbmc.LOGWARNING)
        finally:
            cat_pool.shutdown(wait=False)
        dlg.close()

        seen_ids = set()
        merged = []
        # HQPorner items pass through untouched (already have real streams
        # and their own hqp_<slug> id namespace) — deliberately NOT run
        # through _filter_films_with_sources below with the AFDB/ADE films,
        # since that filter's per-film verification only knows how to
        # check AFDB/ADE-style titles against the free-stream catalog, not
        # re-verify a source HQPorner already confirmed by construction.
        for film in hqp_films:
            fid = film.get('id', '')
            if fid and fid not in seen_ids:
                seen_ids.add(fid)
                merged.append(film)
        afdb_ade_merged = []
        for film in (films + ade_cat_films):
            fid = film.get('id', '')
            if fid and fid not in seen_ids:
                seen_ids.add(fid)
                afdb_ade_merged.append(film)

        merged = merged + _filter_films_with_sources(afdb_ade_merged)
        if merged:
            return merged, [], [], []

    # Performer search, title search (AFDB + ADE), torrent search, and
    # stream search are all independent of each other's results, so they run
    # concurrently in one pool with a single hard overall cap: whatever's
    # back by the cutoff is shown, stragglers are abandoned rather than
    # waited on. First shipped at 8s per explicit instruction ("this is not
    # a reasonable scrape time... even 5 seconds is better") but confirmed
    # live that was too aggressive to be USEFUL, not just fast: a cold-cache
    # performer search (e.g. "scarlit scandal"/"nia nacci") reliably
    # returned 0 results, because building the actor-name index alone
    # (26 AFDB letter pages, one-time cost, cached 24h after) can't complete
    # in 8s, and neither can a real AFDB/ADE/torrent/stream round-trip most
    # of the time - an 8s cap doesn't make the search fast, it makes it
    # find nothing. Raised to 20s, still dramatically bounded versus the
    # 100-400s this replaced, but long enough for at least the faster
    # sources to actually land a real result instead of getting cut off
    # before any of them can. Each phase still has its own, longer internal
    # bound too (adult_streams.search_by_title, torrent_sources.search_all,
    # etc.) for when THEY'RE called directly elsewhere (a single film's own
    # detail/source lookup can afford to wait longer than a live search-box
    # keystroke can) - those don't matter here since this outer cutoff
    # discards anything not back in time regardless of what a phase's own
    # internal timeout allows for.
    dlg = _progress('Searching "%s"...' % query)
    from resources.lib import ade as _ade
    from resources.lib import adult_streams as _as
    from resources.lib import torrent_sources as _ts

    def _do_actor_search():
        # Performer / actor search — was a stub that always returned nothing
        # ("we skip this for now and rely on title search"); now backed by a
        # cached full-name index built once from AFDB's per-letter actor pages.
        try:
            matched_actors = _search_actors_by_name(query)
            if matched_actors:
                return _films_for_matched_actors(matched_actors)
        except Exception as e:
            xbmc.log('[AFDB] actor search error: %s' % e, xbmc.LOGWARNING)
        return []

    def _do_afdb_title_search():
        try:
            return afdb.search_films(query)
        except Exception:
            return []

    def _do_ade_title_search():
        # ADE (Adult DVD Empire) — was only ever searched for one exact title
        # at a time (to enrich an AFDB film's cover/description), never as
        # its own searchable catalog. ADE's own search engine already
        # indexes genre/tag keywords alongside titles (confirmed live: a
        # genre term like "MILF" returns the correctly genre-tagged films
        # even without a dedicated genre-search mode), and separately
        # supports a real performer-filtered mode (type=talent — confirmed
        # live it returns that performer's actual filmography, not just a
        # title-text coincidence). Both run alongside the AFDB search
        # instead of ADE being title-search-only.
        try:
            return _ade.search_by_talent(query) + _ade.search_films(query)
        except Exception as e:
            xbmc.log('[ADE] unified search error: %s' % e, xbmc.LOGWARNING)
            return []

    def _do_torrent_search():
        # Every adult torrent source (XXXClub, Rintor, XXXTor,
        # FreeJAVTorrent, IJAVTorrent, Sukebei, BitDig, TPB, Knaben, etc. —
        # the same full set search_all() already wires up for
        # media_type='adult', see torrent_sources.py) — previously gated
        # behind "if no movie results at all", which meant a performer with
        # real movie appearances (e.g. an ADE talent-search hit) would never
        # show her individual scenes alongside them, even though both are
        # genuinely her and genuinely playable. Now always searched, so a
        # query that has both movies AND scenes shows both instead of an
        # either/or. Previously only called search_xxxclub()/search_rintor()
        # directly here — confirmed live as a real reported gap: XXXTor (and
        # every other adult torrent source added since) was reachable from
        # a specific film's own play/source-picker (afdb_play_search's
        # _torrents(), which already calls the full search_all()) but never
        # from this unified search box.
        try:
            return _ts.search_all(query, media_type='adult')
        except Exception as e:
            xbmc.log('[AFDB] torrent search error: %s' % e, xbmc.LOGWARNING)
            return []

    def _do_stream_search():
        try:
            return _as.search_by_title(query)
        except Exception as e:
            xbmc.log('[AFDB] stream search error: %s' % e, xbmc.LOGWARNING)
            return []

    def _do_myporn_search():
        # myporn.club has a real (if single-word-only) search endpoint —
        # already used by afdb_play_search's per-film picker via
        # search_myporn_club(), but that never reached this unified search
        # box, unlike XXXClub/Rintor which search_all() already covers
        # here. Returns the same {'label','url'} shape as _do_stream_search,
        # so it's merged straight into stream_results below.
        try:
            from resources.lib import myporn_sources as _mpc
            results = _mpc.search_myporn_club(query, media_type='adult')
            return [{'label': '[COLOR cyan][MyPornClub][/COLOR] %s' % r['label'], 'url': r['url']}
                    for r in (results or [])]
        except Exception as e:
            xbmc.log('[AFDB] myporn search error: %s' % e, xbmc.LOGWARNING)
            return []

    actor_films, afdb_films, ade_films = [], [], []
    _all_torrents, stream_results, myporn_results = [], [], []
    main_pool = ThreadPoolExecutor(max_workers=6)
    try:
        main_futs = {
            main_pool.submit(_do_actor_search):      'actor',
            main_pool.submit(_do_afdb_title_search): 'afdb_title',
            main_pool.submit(_do_ade_title_search):  'ade_title',
            main_pool.submit(_do_torrent_search):    'torrent',
            main_pool.submit(_do_stream_search):     'stream',
            main_pool.submit(_do_myporn_search):     'myporn',
        }
        for future in as_completed(main_futs, timeout=20):
            which = main_futs[future]
            try:
                result = future.result() or []
            except Exception as e:
                xbmc.log('[AFDB] %s branch error: %s' % (which, e), xbmc.LOGWARNING)
                result = []
            if which == 'actor':
                actor_films = result
            elif which == 'afdb_title':
                afdb_films = result
            elif which == 'ade_title':
                ade_films = result
            elif which == 'torrent':
                _all_torrents = result
            elif which == 'stream':
                stream_results = result
            elif which == 'myporn':
                myporn_results = result
    except Exception as e:
        xbmc.log('[AFDB] unified search timeout: %s' % e, xbmc.LOGWARNING)
    finally:
        main_pool.shutdown(wait=False)
    dlg.close()

    # Confirmed live 2026-08-15: torrent_sources.search_all() has no idea
    # what the "real" title is — it just queries every source with the raw
    # (cleaned) query string and returns whatever each site's own search
    # matched, no phrase-adjacency required. For a short/generic query this
    # let completely unrelated content through unfiltered (e.g. "Heatwave 2"
    # matched a Fireman Sam episode, a WWE NXT event, and unrelated Playboy
    # content) — the stream-search branch above already guards against this
    # exact failure mode via _as._title_matches(), but a first attempt at
    # reusing that same function here directly against torrents' RAW,
    # junk-laden release names didn't actually work: _title_matches does
    # plain substring checks per word, and a short numeric query word like
    # "2" trivially substring-matches almost any release name through its
    # own quality/codec tags ("ddp2", "264", etc.) — confirmed live, the
    # "Heatwave 2" query matched "Fireman Sam...1080p AMZN WEB-DL DDP2 0 H
    # 264" purely because "2" is a substring of "ddp2"/"264", nothing to do
    # with the actual film. Fixed by cleaning each torrent's raw title the
    # same way the query itself is already cleaned before comparing — once
    # "1080p"/"DDP2"/"264"/etc. are stripped, the leftover "2" false-matches
    # disappear along with them.
    # _as._title_matches() itself turned out to still be too loose here even
    # after cleaning — confirmed live: it does plain substring checks per
    # word, so a real release title that happens to contain BOTH query
    # words anywhere at all (e.g. "WWE NXT 2.0 ... Heatwave", where "2" is
    # part of the show's own branding, nowhere near "Heatwave") still
    # passed. Reworked as an explicit, per-word \b-boundary check instead —
    # every normalized query word must appear as a real whole word
    # somewhere in the cleaned candidate title (not required to be
    # adjacent/contiguous - phrase-adjacency was tried and rejected as
    # overly strict, since it also dropped some genuinely correct matches
    # where the source's own title word order differs slightly).
    # Confirmed live as a real, pre-existing crash: norm_query was never
    # actually defined anywhere in this function's own scope (only a
    # same-named local in a different function, _search_free_movies_only,
    # had it) - every single call here raised NameError the moment
    # _all_torrents was non-empty, which is common (XXXClub alone matches
    # dozens of real torrents for most queries), silently wiping out the
    # ENTIRE unified search result before anything was ever rendered. This
    # is exactly the reported "search initiates, no results ever show" bug
    # - and it predates every other Adult-search fix this session, since
    # torrent search has been unconditional here since 2026-08-15.
    norm_query = _as._norm_title(query)
    _q_words = norm_query.split()
    def _torrent_title_ok(t):
        try:
            clean = _clean_adult_title(t.get('title', ''))
            norm_film = _as._norm_title(clean)
            return all(_re.search(r'\b%s\b' % _re.escape(w), norm_film) for w in _q_words)
        except Exception:
            return True  # fail open — never let a matcher bug silently empty real results
    _all_torrents = [t for t in _all_torrents if _torrent_title_ok(t)]

    # rintor_results is kept as its own bucket (by filtering search_all()'s
    # combined output on source=='Rintor') purely so both callers below/in
    # home.py don't need their own restructuring — everything else lands in
    # torrent_results, labelled per-item from its own 'source' field rather
    # than a hardcoded "XXXClub" as before.
    rintor_results  = [t for t in _all_torrents if t.get('source') == 'Rintor']
    torrent_results = [t for t in _all_torrents if t.get('source') != 'Rintor']

    # Merge: actor films + AFDB title results + ADE performer/genre/title
    # results (deduplicated by id — same convention already used elsewhere
    # in this file; ADE and AFDB each have their own numeric id space, but a
    # same-number collision between the two is no more likely here than at
    # the other merge points in this module that already dedupe the same way).
    seen_ids = set()
    all_films = []
    for film in (actor_films + afdb_films + ade_films):
        fid = film.get('id', '')
        if fid and fid not in seen_ids:
            seen_ids.add(fid)
            all_films.append(film)

    all_films = _filter_films_with_sources(all_films)
    stream_results = stream_results + myporn_results
    return all_films, torrent_results, rintor_results, stream_results


def adult_search_unified(handle, build_url, query=None, page=1):
    """
    Single search box for: movie title, performer name, or scene type/tag.
    - If query matches an AFDB category → show films for that category
    - If query matches performer names → show matching actor filmographies
    - Otherwise → search AFDB titles + free stream sites by title

    Thin rendering wrapper around _adult_unified_search_data — see that
    function's own docstring for why the actual search/merge logic lives
    there instead of here now.

    `query`/`page` (added 2026-08-14, real Next Page for the stream-results
    portion of this screen): a native ListItem-based directory has no live
    keyboard state to reuse when the user clicks Next Page and this action
    re-fires from scratch — so instead of re-prompting xbmc.Keyboard on
    every page (which would make "Next Page" mean "type your search again"),
    the already-typed query is threaded through the Next Page URL itself
    via _next_page's own extra= mechanism, the same way adult_scene_movies
    threads its 'site' param through Next Page for the exact same reason.
    Only when `query` isn't already supplied (the first, keyboard-driven
    entry into this screen) is the keyboard prompt shown at all.

    Only stream_results is genuinely paginated (see
    _adult_unified_search_data's own docstring) — all_films/torrent_results/
    rintor_results come back empty for page > 1 by design, so they're just
    not re-rendered a second time; only the new stream batch is added.
    """
    if not query:
        kb = xbmc.Keyboard('', 'Search movies, performers, scenes...')
        kb.doModal()
        if not kb.isConfirmed() or not kb.getText().strip():
            xbmcplugin.endOfDirectory(handle, succeeded=False)
            return
        query = kb.getText().strip()

    xbmcplugin.setPluginCategory(handle, 'Search: %s' % query)
    xbmcplugin.setContent(handle, 'movies')

    all_films, torrent_results, rintor_results, stream_results = _adult_unified_search_data(query, page)

    for film in all_films:
        _add_film(handle, build_url, film)
    _prewarm_film_details(all_films)

    if torrent_results or rintor_results or stream_results:
        # Show every non-Rintor torrent result (XXXClub, XXXTor,
        # FreeJAVTorrent, IJAVTorrent, Sukebei, BitDig, TPB, Knaben, etc.)
        # as individual playable items, labelled from each item's own
        # 'source' field rather than a hardcoded "XXXClub" — this list now
        # carries every adult torrent source, not just XXXClub.
        for t in torrent_results:
            src = t.get('source', 'Torrent')
            label = '[COLOR cyan][%s][/COLOR] %s  [COLOR grey][%s][/COLOR]' % (
                src, t['title'], t.get('size', ''))
            li = xbmcgui.ListItem(label=label)
            try:
                tag = li.getVideoInfoTag()
                tag.setTitle(t['title'])
                tag.setPlot('[%s] Seeds: %d' % (src, t.get('seeds', 0)))
                tag.setMpaa('Adults Only')
            except Exception:
                li.setInfo('video', {'title': t['title'], 'mpaa': 'Adults Only'})
            li.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(
                handle,
                build_url({'action': 'play_xxxclub_magnet',
                           'magnet': t['magnet'],
                           'title': t['title']}),
                li, False
            )

        # Show Rintor torrent results the same way — play_xxxclub_magnet is
        # source-agnostic (just resolves whatever magnet it's given via
        # debrid), despite the name.
        for t in rintor_results:
            label = '[COLOR orange][RT][/COLOR] %s  [COLOR grey][%s][/COLOR]' % (
                t['title'], t.get('size', ''))
            li = xbmcgui.ListItem(label=label)
            try:
                tag = li.getVideoInfoTag()
                tag.setTitle(t['title'])
                tag.setPlot('[Rintor] %s' % t.get('size', ''))
                tag.setMpaa('Adults Only')
            except Exception:
                li.setInfo('video', {'title': t['title'], 'mpaa': 'Adults Only'})
            li.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(
                handle,
                build_url({'action': 'play_xxxclub_magnet',
                           'magnet': t['magnet'],
                           'title': t['title']}),
                li, False
            )

        # Show free stream results as individual playable items
        for s in stream_results:
            lbl = s.get('label') or query
            li = xbmcgui.ListItem(label='[COLOR yellow][Stream][/COLOR] %s' % lbl)
            try:
                tag = li.getVideoInfoTag()
                tag.setTitle(lbl)
                tag.setMpaa('Adults Only')
            except Exception:
                li.setInfo('video', {'title': lbl, 'mpaa': 'Adults Only'})
            li.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(handle, s['url'], li, False)

    if not all_films and not torrent_results and not rintor_results and not stream_results:
        msg = ('No results for: %s' % query if page <= 1
               else 'No more results for: %s' % query)
        xbmcgui.Dialog().notification('Adult', msg, xbmcgui.NOTIFICATION_INFO)

    # Only stream_results is genuinely paginated (see
    # _adult_unified_search_data's own docstring for which of its ~26
    # underlying sites actually support this) — Next Page is only offered
    # while the current page's stream batch came back non-empty, same
    # "stop offering once a page comes back empty" convention every other
    # paginated native listing in this file already uses (e.g.
    # adult_scene_movies returning early instead of calling _next_page once
    # its own page comes back with nothing).
    if stream_results:
        _next_page(handle, build_url, 'adult_search_unified', page, extra={'query': query})

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


# ── Film Detail / Play ────────────────────────────────────────────────────────

def afdb_detail(handle, build_url, film_id, film_slug, film_title=''):
    """Legacy detail view — redirects to afdb_play_search."""
    afdb_play_search(handle, film_id, film_slug, film_title)


def afdb_play_search(handle, film_id, film_slug, film_title=''):
    """
    Browse AFDB for metadata → search ALL scrapers in parallel
    (trailer, personal, debrid, free streams, XXXClub, all torrent sources)
    → source picker dialog → play via ResolveURL.

    Source order: Trailer, personal, debrid [yellow], free streams,
    XXXClub [cyan], general torrents [orange].
    """
    from resources.lib import adult_streams as _as
    from resources.lib import ade as _ade
    from resources.lib import torrent_sources as _ts

    # Resolve title
    title = film_title
    year  = None
    if not title:
        cold = _need_fetch('afdb_film_%s' % film_id)
        dlg  = _progress('Loading...') if cold else None
        film_detail = afdb.get_film_detail(film_id, film_slug)
        if dlg: dlg.close()
        title = film_detail.get('title', '')
        year  = film_detail.get('year') or None
        if not film_detail.get('description') and title:
            try:
                _ade.search_by_title(title)
            except Exception:
                pass

    if not title:
        xbmcgui.Dialog().notification('Starfleet', 'Film title not found', xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    dlg = _pdlg.DialogProgress()
    dlg.create('Starfleet', 'Grab a tissue, sources loading...')

    from concurrent.futures import ThreadPoolExecutor as _TPE

    def _free():
        # Movies-only — see _search_free_movies_only's own docstring for
        # why this must not use adult_streams.search_by_title() here.
        return _search_free_movies_only(title)

    def _personal():
        try:
            from resources.lib import personal_sources as _ps
            return _ps.search_personal(title, year=year, media_type='adult')
        except Exception:
            return []

    def _easynews():
        try:
            from resources.lib import easynews_sources as _en
            raw = _en.search_easynews(title, year=year, media_type='adult')
            out = []
            for s in raw:
                out.append({'label': '[COLOR cyan][Easynews][/COLOR] %s' % s['label'], 'url': s['url']})
            return out
        except Exception:
            return []

    def _debrid():
        try:
            from resources.lib import debrid_torrent as _dt
            raw = _dt.get_debrid_streams(title, year=year, media_type='adult')
            for s in raw:
                s['label'] = '[COLOR yellow]%s[/COLOR]' % s['label']
                s['is_debrid'] = True
            return raw
        except Exception:
            return []

    def _trailer():
        try:
            url = _ade.get_trailer_url(title)
            if url:
                return [{'label': '[Trailer]', 'url': url, 'is_trailer': True}]
        except Exception:
            pass
        return []

    def _xxxclub():
        try:
            results = _ts.search_xxxclub(title, limit=5, media_type='adult')
            out = []
            for t in results:
                qual = ''
                for tag in ('2160p', '4K', '1080p', '720p', '480p'):
                    if tag.lower() in t.get('title', '').lower():
                        qual = '  [COLOR lime][%s][/COLOR]' % tag
                        break
                seeds = ('  [COLOR grey]↑%d[/COLOR]' % t['seeds']) if t.get('seeds') else ''
                size  = ('  [COLOR grey][%s][/COLOR]' % t['size']) if t.get('size') else ''
                lbl = '[COLOR cyan][XXXClub][/COLOR] %s%s%s%s' % (
                    t.get('title', title), qual, size, seeds)
                out.append({'label': lbl, 'url': t['magnet']})
            return out
        except Exception:
            return []

    def _rintor():
        try:
            results = _ts.search_rintor(title, limit=5, media_type='adult')
            out = []
            for t in results:
                size = ('  [COLOR grey][%s][/COLOR]' % t['size']) if t.get('size') else ''
                lbl = '[COLOR orange][Rintor][/COLOR] %s%s' % (t.get('title', title), size)
                out.append({'label': lbl, 'url': t['magnet']})
            return out
        except Exception:
            return []

    def _torrents():
        try:
            results = _ts.search_all(title, year=year, media_type='adult')
            out = []
            for t in results:
                qual = ''
                for tag in ('2160p', '4K', '1080p', '720p', '480p'):
                    if tag.lower() in t.get('title', '').lower():
                        qual = '  [COLOR lime][%s][/COLOR]' % tag
                        break
                seeds = ('  [COLOR grey]↑%d[/COLOR]' % t['seeds']) if t.get('seeds') else ''
                size  = ('  [COLOR grey][%s][/COLOR]' % t['size']) if t.get('size') else ''
                src   = t.get('source', '')
                src_tag = ('  [COLOR darkgrey]%s[/COLOR]' % src) if src else ''
                url   = t.get('magnet', '')
                if url:
                    lbl = '[COLOR orange][Torrent][/COLOR] %s%s%s%s%s' % (
                        t.get('title', title), qual, size, seeds, src_tag)
                    out.append({'label': lbl, 'url': url})
            return out
        except Exception:
            return []

    def _myporn():
        try:
            from resources.lib import myporn_sources as _mpc
            results = _mpc.search_myporn_club(title, limit=5, media_type='adult')
            out = []
            for t in (results or []):
                out.append({'label': '[COLOR cyan][MyPornClub][/COLOR] %s [%s]' %
                            (t.get('title', ''), t.get('size', '')), 'url': t.get('magnet', '')})
            return out
        except Exception:
            return []

    collected, canceled = _search_with_cancel(dlg, {
        'trailer':  (_trailer,  15),
        'personal': (_personal, 15),
        'easynews': (_easynews, 15),
        'debrid':   (_debrid,   75),
        'free':     (_free,     30),
        'xxxclub':  (_xxxclub,  25),
        'rintor':   (_rintor,   25),
        'torrents': (_torrents, 35),
        'myporn':   (_myporn,   15),
    })
    dlg.close()
    if canceled:
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    # Order: trailer, personal, Easynews, debrid, free, XXXClub, Rintor, MyPornClub, torrents (ext.to among these)
    streams = (collected.get('trailer', []) + collected.get('personal', []) +
               collected.get('easynews', []) + collected.get('debrid', []) +
               collected.get('free', []) + collected.get('xxxclub', []) +
               collected.get('rintor', []) + collected.get('myporn', []) +
               collected.get('torrents', []))

    if not streams:
        xbmcgui.Dialog().notification(
            'Starfleet', 'No streams found for: %s' % title,
            xbmcgui.NOTIFICATION_WARNING, 5000
        )
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    if len(streams) == 1:
        chosen = streams[0]
    else:
        options = ['%s — %s' % (s['label'], s.get('url', '')[:40]) if s.get('is_trailer')
                   else s['label']
                   for s in streams]
        idx = _select_dialog('%s — Choose stream' % title, options)
        if idx < 0:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return
        chosen = streams[idx]

    resolved = adult_stream_play(chosen['url'], title, is_nzb=chosen.get('is_nzb', False))
    if not resolved:
        xbmcgui.Dialog().notification('Starfleet', 'Could not resolve stream', xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return
    li = xbmcgui.ListItem(path=resolved)
    li.setContentLookup(False)
    li.setInfo('video', {'title': title, 'mediatype': 'movie'})
    _url_lc = resolved.lower()
    if '.m3u8' in _url_lc:
        li.setMimeType('application/x-mpegURL')
    elif '.mp4' in _url_lc:
        li.setMimeType('video/mp4')
    elif '.mkv' in _url_lc:
        li.setMimeType('video/x-matroska')
    # afdb_play_search previously had no watch-progress tracking at all —
    # added here (same synthetic-key pattern as 'hqp:'/'ade:'/'panda:')
    # so Adult's main search-driven play path gets Continue Watching /
    # resume too, matching every other Adult source.
    if not chosen.get('is_trailer'):
        try:
            from resources.lib import watch_history as _wh0
            _wh0.apply_resume(li, 'afdb:%s' % film_id)
        except Exception:
            pass
    xbmcplugin.setResolvedUrl(handle, True, li)
    try:
        from resources.lib import watch_history as _wh
        _wh.start_playback_monitor('afdb:%s' % film_id, title=title)
    except Exception:
        pass


_THUMB_UA = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
    'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'
)

def _thumb_ref(thumb, film_url=''):
    """Append Referer + User-Agent headers so Kodi can fetch images from protected CDNs."""
    if not thumb or '|' in thumb:
        return thumb
    import re as _re
    m = _re.match(r'(https?://[^/]+)', film_url or thumb)
    ref = (m.group(1) + '/') if m else ''
    if ref:
        return '%s|Referer=%s&User-Agent=%s' % (thumb, ref, _THUMB_UA)
    return '%s|User-Agent=%s' % (thumb, _THUMB_UA)


def _ade_enrich_background(films):
    """
    Fire-and-forget: fetch ADE metadata for free-stream films that have
    no thumbnail or description, so the next page load shows enriched data.
    Capped at 10 films per call to avoid hammering ADE.
    """
    from resources.lib import ade as _ade
    from concurrent.futures import ThreadPoolExecutor

    cold = [f for f in films
            if not f.get('thumb') or not f.get('description')][:10]
    if not cold:
        return

    def _fetch(film):
        try:
            _ade.search_by_title(film['title'])
        except Exception:
            pass

    pool = ThreadPoolExecutor(max_workers=4)
    for f in cold:
        pool.submit(_fetch, f)
    pool.shutdown(wait=False)


def adult_streams(handle, build_url, page=1, xclub_cursor=''):
    """
    Browse adult movies. Shows XXXClub torrents (fast) plus a Free Streams folder.
    xclub_cursor: raw xxxclub.to pagination cursor (empty = first page).
    """
    xbmcplugin.setPluginCategory(handle, 'Adult Movies — Page %d' % page)
    xbmcplugin.setContent(handle, 'movies')

    _busy_handle = _busy.show()
    from resources.lib import torrent_sources as _ts
    xxxclub_torrents = []
    next_site_cursor = ''
    try:
        xxxclub_torrents, next_site_cursor = _ts.browse_xxxclub(cursor=xclub_cursor or '1')
        xbmc.log('[Starfleet] XXXClub page=%d cursor=%s returned %d items' % (page, xclub_cursor or '1', len(xxxclub_torrents)), xbmc.LOGWARNING)
        xxxclub_torrents.sort(key=lambda t: _extract_year(t.get('title', '')), reverse=True)
    except Exception as e:
        xbmc.log('[Starfleet] XXXClub failed: %s' % e, xbmc.LOGWARNING)
    _busy.close(_busy_handle)

    # ── XXXClub torrents ──────────────────────────────────────────────────────
    for t in xxxclub_torrents:
        yr = _extract_year(t.get('title', ''))
        yr_tag = '  [COLOR grey](%d)[/COLOR]' % yr if yr else ''
        label = '[COLOR cyan][XC][/COLOR] %s%s  [COLOR grey][%s][/COLOR]' % (t['title'], yr_tag, t['size'])
        li = xbmcgui.ListItem(label=label)
        try:
            tag = li.getVideoInfoTag()
            tag.setTitle(t['title'])
            tag.setPlot('[XXXClub] %s' % t['size'])
            tag.setMpaa('Adults Only')
            if yr:
                tag.setYear(yr)
        except Exception:
            info = {'title': t['title'], 'plot': '[XXXClub] %s' % t['size'], 'mpaa': 'Adults Only'}
            if yr:
                info['year'] = yr
            li.setInfo('video', info)
        if t.get('thumb'):
            li.setArt({'thumb': t['thumb'], 'poster': t['thumb'], 'icon': t['thumb']})
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action': 'play_xxxclub_magnet',
                       'magnet': t['magnet'],
                       'title':  t['title']}),
            li, False
        )

    # Next page: pass the real xxxclub cursor so page 2 needs only one HTTP request
    if next_site_cursor:
        _next_page(handle, build_url, 'adult_streams', page,
                   extra={'xclub_cursor': next_site_cursor})
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def adult_free_streams(handle, build_url, page=1):
    """
    Browse free adult stream sources (loaded on-demand to avoid UI freeze).
    """
    from resources.lib import adult_streams as _as
    import re as _re

    xbmcplugin.setPluginCategory(handle, 'Free Streams — Page %d' % page)
    xbmcplugin.setContent(handle, 'movies')

    dlg = _progress('Loading free streams...')
    films = _as.get_all_stream_stubs(page=page)
    dlg.update(40, 'Verifying sources...')
    films = _verify_stream_sources(
        films, lambda f: _as.fetch_film_detail_on_demand(f['id'], f.get('url', ''))
    )
    dlg.close()

    for film in (films or []):
        ade_key = 'ade_search_%s' % _re.sub(r'[^a-z0-9]', '_', film['title'].lower())[:80]
        ade_meta = _cache.get(ade_key)
        if ade_meta and isinstance(ade_meta, dict):
            if not film.get('thumb') and ade_meta.get('thumb'):
                film['thumb'] = ade_meta['thumb']
            if not film.get('description') and ade_meta.get('description'):
                film['description'] = ade_meta['description']

        li = xbmcgui.ListItem(label=film['title'])
        try:
            tag = li.getVideoInfoTag()
            tag.setTitle(film['title'])
            tag.setPlot(film.get('description', ''))
            tag.setMpaa('Adults Only')
        except Exception:
            li.setInfo('video', {'title': film['title'], 'plot': film.get('description', ''), 'mpaa': 'Adults Only'})

        if film.get('thumb'):
            thumb = _thumb_ref(film['thumb'], film.get('url', ''))
            li.setArt({'thumb': thumb, 'poster': thumb, 'fanart': thumb, 'icon': thumb})

        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action': 'adult_stream_sources',
                       'film_id': film['id'],
                       'film_url': film.get('url', ''),
                       'title': film['title']}),
            li, False
        )

    if films:
        _ade_enrich_background(films)

    _next_page(handle, build_url, 'adult_free_streams', page)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def adult_stream_sources(handle, build_url, film_id, title='', film_url=''):
    """
    Show a dialog listing all stream sources for a film, then play the chosen one.
    Always searches debrid/torrents regardless of whether free streams are cached.
    Fetches the detail page on demand if not cached (stub-based listing).
    """
    from resources.lib import adult_streams as _as
    from concurrent.futures import ThreadPoolExecutor

    # 1. Try merged cache (set by get_all_streams legacy path)
    film = _cache.get('fstreams_merged_%s' % film_id)

    # 2. Try per-source detail cache
    if not film:
        _PREFIX_CACHE = {
            'freeo_':   'fstreams_freeo_detail_%s',
            'xxxms_':   'fstreams_xxxms_detail_%s',
            'wpw_':     'fstreams_wpw_detail_%s',
            'wpf_':     'fstreams_wpf_detail_%s',
            'spn_':     'fstreams_spn_detail_%s',
            'xmovix_':  'fstreams_xmovix_detail_%s',
        }
        for prefix, ck_tpl in _PREFIX_CACHE.items():
            if film_id.startswith(prefix):
                slug = film_id[len(prefix):]
                film = _cache.get(ck_tpl % slug)
                break

    # 3. Fetch detail page on demand (stub listing path — no detail cached yet)
    if not film or not film.get('streams'):
        try:
            fetched = _as.fetch_film_detail_on_demand(film_id, film_url)
            if fetched and fetched.get('streams'):
                film = fetched
        except Exception as e:
            xbmc.log('[Starfleet/Streams] on-demand detail fetch error: %s' % e, xbmc.LOGWARNING)

    film_title  = title or (film.get('title', '') if film else '')
    cached_streams = (film.get('streams') or []) if film else []

    if not film_title:
        xbmcgui.Dialog().notification('Starfleet', 'Film title not found', xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    def _personal():
        try:
            from resources.lib import personal_sources as _ps
            return _ps.search_personal(film_title, media_type='adult')
        except Exception:
            return []

    def _easynews():
        try:
            from resources.lib import easynews_sources as _en
            raw = _en.search_easynews(film_title, media_type='adult')
            out = []
            for s in raw:
                out.append({'label': '[COLOR cyan][Easynews][/COLOR] %s' % s['label'], 'url': s['url']})
            return out
        except Exception as e:
            xbmc.log('[Starfleet/Streams] easynews error: %s' % e, xbmc.LOGWARNING)
            return []

    def _debrid():
        try:
            from resources.lib import debrid_torrent as _dt
            raw = _dt.get_debrid_streams(film_title, media_type='adult')
            for s in raw:
                s['label'] = '[COLOR yellow]%s[/COLOR]' % s['label']
            return raw
        except Exception as e:
            xbmc.log('[Starfleet/Streams] debrid error: %s' % e, xbmc.LOGWARNING)
            return []

    def _site_search():
        # Always search the free streaming sites by title so AFDB browse/search
        # results also get free scraper streams, not just debrid results.
        if cached_streams:
            return cached_streams  # already have them from scraper cache
        try:
            # Movies-only — see _search_free_movies_only's own docstring.
            return _search_free_movies_only(film_title)
        except Exception as e:
            xbmc.log('[Starfleet/Streams] site search error: %s' % e, xbmc.LOGWARNING)
            return []

    with ThreadPoolExecutor(max_workers=4) as pool:
        f_personal = pool.submit(_personal)
        f_easynews = pool.submit(_easynews)
        f_debrid   = pool.submit(_debrid)
        f_sites    = pool.submit(_site_search)
        try:
            personals = f_personal.result(timeout=15)
        except Exception:
            personals = []
        try:
            easynews_r = f_easynews.result(timeout=15)
        except Exception:
            easynews_r = []
        try:
            debrids = f_debrid.result(timeout=75)
        except Exception:
            debrids = []
        try:
            site_free = f_sites.result(timeout=40)
        except Exception:
            site_free = []

    streams = personals + easynews_r + debrids + site_free

    if not streams:
        xbmcgui.Dialog().notification('Starfleet', 'No streams found for: %s' % film_title,
                                       xbmcgui.NOTIFICATION_WARNING, 5000)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    if len(streams) == 1:
        chosen = streams[0]
    else:
        options = [s['label'] for s in streams]
        idx = _select_dialog('%s — Choose stream' % film_title, options)
        if idx < 0:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return
        chosen = streams[idx]

    resolved = adult_stream_play(chosen['url'], film_title, is_nzb=chosen.get('is_nzb', False))
    if not resolved:
        xbmcgui.Dialog().notification('Starfleet', 'Could not resolve stream', xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return
    li = xbmcgui.ListItem(path=resolved)
    li.setContentLookup(False)
    li.setInfo('video', {'title': film_title, 'mediatype': 'movie'})
    _url_lc = resolved.lower()
    if '.m3u8' in _url_lc:
        li.setMimeType('application/x-mpegURL')
    elif '.mp4' in _url_lc:
        li.setMimeType('video/mp4')
    elif '.mkv' in _url_lc:
        li.setMimeType('video/x-matroska')
    try:
        from resources.lib import watch_history as _wh0
        _wh0.apply_resume(li, 'afdb:%s' % film_id)
    except Exception:
        pass
    xbmcplugin.setResolvedUrl(handle, True, li)
    try:
        from resources.lib import watch_history as _wh
        _wh.start_playback_monitor('afdb:%s' % film_id, title=film_title)
    except Exception:
        pass


def adult_stream_play(stream_url, title='', is_nzb=False):
    """Resolve a stream URL and return the playable URL, or '' on failure.
    Callers pass the returned URL to setResolvedUrl(handle, True, ListItem(path=url))."""
    if not stream_url:
        return ''

    # NZB links: same deferred-resolution shape as magnets below, but no
    # Elementum-style P2P fallback exists for Usenet (no swarm to fall back
    # to). Same bug class already fixed in metadata_router.py's Movies/TV
    # play path applied here too: this function only ever received a bare
    # URL string, with no way to know a chosen source was an NZB candidate,
    # so an NZB pick here would silently skip Premiumize/TorBox resolution
    # and try to play the raw NZB search-page link directly.
    if is_nzb:
        from resources.lib import resolvers as _resolvers
        try:
            debrid_resolved = _resolvers.resolve_nzb(stream_url)
        except Exception as e:
            xbmc.log('[Starfleet/Streams] resolve_nzb error: %s' % e, xbmc.LOGWARNING)
            debrid_resolved = None
        if debrid_resolved:
            xbmc.log('[Starfleet/Streams] NZB resolved via debrid: %s' % debrid_resolved[:80],
                     xbmc.LOGINFO)
            return debrid_resolved
        xbmc.log('[Starfleet/Streams] Debrid could not resolve this NZB', xbmc.LOGWARNING)
        return ''

    # Magnet URIs: try enabled debrid services first (instant-cache only —
    # see resolvers.resolve_magnet's own docstring). Elementum is ONLY ever
    # used as a fallback when NO debrid service is enabled at all — per
    # explicit instruction, once any debrid service is on, a magnet that
    # debrid couldn't resolve should fail cleanly rather than fall through
    # to Elementum anyway. Previously this fell back to Elementum for
    # every magnet debrid didn't have cached, regardless of whether debrid
    # was even configured — which is the correct fallback ONLY in the
    # no-debrid-at-all case.
    if stream_url.startswith('magnet:'):
        from resources.lib import resolvers as _resolvers
        try:
            debrid_resolved = _resolvers.resolve_magnet(stream_url)
        except Exception as e:
            xbmc.log('[Starfleet/Streams] resolve_magnet error: %s' % e, xbmc.LOGWARNING)
            debrid_resolved = None
        if debrid_resolved:
            xbmc.log('[Starfleet/Streams] Magnet resolved via debrid: %s' % debrid_resolved[:80],
                     xbmc.LOGINFO)
            return debrid_resolved

        if _resolvers.any_debrid_enabled():
            xbmc.log('[Starfleet/Streams] Debrid enabled but could not resolve this magnet — '
                     'not falling back to Elementum per current policy', xbmc.LOGWARNING)
            return ''

        from urllib.parse import quote as _uq
        elementum_url = 'plugin://plugin.video.elementum/play?uri=%s' % _uq(stream_url)
        xbmc.log('[Starfleet/Streams] No debrid configured — routing magnet via Elementum: '
                 + elementum_url[:80], xbmc.LOGINFO)
        return elementum_url

    resolved_url = stream_url
    _needs_resolution = False

    # Step 1: internal resolver for embed domains ResolveURL doesn't cover
    try:
        from resources.lib import embed_resolver as _er
        internal = _er.resolve(stream_url)
        if internal:
            xbmc.log('[Starfleet/Streams] InternalResolver: %s' % internal[:80], xbmc.LOGINFO)
            resolved_url = internal
    except Exception as e:
        xbmc.log('[Starfleet/Streams] InternalResolver error: %s' % e, xbmc.LOGWARNING)

    # Step 2: ResolveURL for hosters it supports (DoodStream, MixDrop, etc.)
    if resolved_url == stream_url:
        try:
            import resolveurl
            hmf = resolveurl.HostedMediaFile(stream_url)
            if hmf.valid_url():
                # Recognized as a real hoster page ResolveURL knows how to
                # resolve — if resolve() below doesn't actually change
                # resolved_url (raises, or returns '' / None), that means
                # genuine resolution failure, not "nothing to resolve
                # here" - see the check after this block for why that
                # distinction matters.
                _needs_resolution = True
                resolved_url = hmf.resolve()
                xbmc.log('[Starfleet/Streams] ResolveURL: %s' % (resolved_url or 'failed')[:80], xbmc.LOGINFO)
        except ImportError:
            xbmc.log('[Starfleet/Streams] ResolveURL not installed', xbmc.LOGINFO)
        except Exception as e:
            xbmc.log('[Starfleet/Streams] ResolveURL error: %s' % e, xbmc.LOGWARNING)

    if not resolved_url:
        return ''

    # A hoster ResolveURL recognized as needing resolution (DoodStream,
    # MixDrop, etc.) but couldn't actually resolve — a real error, a
    # Cloudflare challenge, whatever — must never fall through to playing
    # the raw, unplayable hoster PAGE url as if it were a real result.
    # Confirmed live this was happening: a DoodStream link blocked by a
    # genuine Cloudflare challenge (ResolveURL itself can't solve that,
    # nothing to fix there) still got handed straight to Kodi's player,
    # which predictably failed to open it with a 403. The old check right
    # below only ever caught ONE specific failure shape (an unresolved JS
    # embed whose URL happens to contain a literal '#') — every other
    # "ResolveURL recognized this but failed" case silently played the
    # dead page URL instead of reporting a clean failure.
    if _needs_resolution and resolved_url == stream_url:
        xbmc.log('[Starfleet/Streams] Hoster recognized but resolution failed — '
                 'refusing to play the raw unresolved page', xbmc.LOGWARNING)
        return ''

    # JS embed with unresolved # fragment — Kodi can't play it
    if resolved_url == stream_url and '#' in resolved_url:
        return ''

    return resolved_url


def afdb_play(handle, stream_url, film_id=''):
    """
    Resolve and play a stream URL via ResolveURL if available,
    otherwise direct play.
    """
    if not stream_url:
        xbmcgui.Dialog().ok(
            'Starfleet — No Stream Source',
            'No stream URL has been assigned to this film yet.\n\n'
            'To add playback support:\n'
            '1. Find the film on a hoster (StreamTape, DoodStream, etc.)\n'
            '2. The stream URL will be passed here automatically\n'
            '   once a source plugin or scraper provides it.\n\n'
            'Metadata from Adult Film Database is ready and waiting.'
        )
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    resolved_url = stream_url

    # Try ResolveURL addon first (supports 50+ hosters)
    try:
        import resolveurl
        if resolveurl.HostedMediaFile(stream_url).valid_url():
            hmf = resolveurl.HostedMediaFile(stream_url)
            resolved_url = hmf.resolve()
            xbmc.log('[AFDB] ResolveURL resolved: %s' % resolved_url[:80],
                     xbmc.LOGINFO)
    except ImportError:
        xbmc.log('[AFDB] ResolveURL not installed — playing directly',
                 xbmc.LOGINFO)
    except Exception as e:
        xbmc.log('[AFDB] ResolveURL error: %s' % e, xbmc.LOGWARNING)

    if not resolved_url:
        xbmcgui.Dialog().notification('Adult', 'Could not resolve stream URL',
                                       xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    li = xbmcgui.ListItem(path=resolved_url)
    xbmcplugin.setResolvedUrl(handle, True, li)


# ── XXXClub Browse ────────────────────────────────────────────────────────────

def xxxclub_browse(handle, build_url, cursor=''):
    """
    Browse latest torrents from XXXClub.to.
    Each item is directly playable via debrid (magnet → debrid → stream).
    """
    from resources.lib import torrent_sources as _ts

    xbmcplugin.setPluginCategory(handle, '🔞 XXXClub — Latest')
    xbmcplugin.setContent(handle, 'movies')

    dlg = _pdlg.DialogProgress()
    dlg.create('XXXClub', 'Fetching latest torrents...')

    result, canceled = _run_cancelable(dlg, lambda: _ts.browse_xxxclub(cursor=cursor), 25)
    dlg.close()
    if canceled:
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return
    torrents, next_cursor = result if result else ([], '')

    if not torrents:
        xbmcgui.Dialog().notification('XXXClub', 'No results found', xbmcgui.NOTIFICATION_INFO)
        return

    for t in torrents:
        li = xbmcgui.ListItem(label='%s  [COLOR grey][%s][/COLOR]' % (t['title'], t['size']))
        try:
            tag = li.getVideoInfoTag()
            tag.setTitle(t['title'])
            tag.setPlot('[COLOR grey]%s[/COLOR]' % t['size'])
            tag.setMpaa('Adults Only')
        except Exception:
            li.setInfo('video', {'title': t['title'], 'plot': t['size'], 'mpaa': 'Adults Only'})
        if t.get('thumb'):
            li.setArt({'thumb': t['thumb'], 'poster': t['thumb'], 'icon': t['thumb']})
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(
            handle,
            build_url({'action': 'play_xxxclub_magnet',
                       'magnet': t['magnet'],
                       'title':  t['title']}),
            li, False
        )

    if next_cursor:
        _add_dir(handle, build_url, '» Next Page',
                 {'action': 'xxxclub_browse', 'cursor': next_cursor},
                 plot='Load next page')

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def play_xxxclub_magnet(handle, magnet, title=''):
    """Resolve a XXXClub magnet via debrid and play it."""
    from resources.lib import resolvers as _resolvers

    dlg = _pdlg.DialogProgress()
    dlg.create('XXXClub', 'Resolving via debrid...')

    try:
        # Respects the user's configured Settings -> Premium Services
        # priority order (was previously hardcoded RD->AD->PM->TB
        # regardless of what the user actually set).
        stream_url = _resolvers.resolve_magnet(magnet)
    finally:
        dlg.close()

    if not stream_url:
        if _resolvers.any_debrid_enabled():
            xbmc.log('[Starfleet] XXXClub debrid enabled but could not resolve this magnet — '
                     'not falling back to Elementum per current policy', xbmc.LOGWARNING)
            xbmcgui.Dialog().notification('Starfleet', 'Debrid could not resolve this torrent',
                                          xbmcgui.NOTIFICATION_WARNING, 4000)
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return
        # No debrid configured at all — route via Elementum by resolving directly to the plugin URL
        import urllib.parse as _ul2
        elem_url = 'plugin://plugin.video.elementum/play?uri=' + _ul2.quote(magnet, safe='')
        xbmc.log('[Starfleet] XXXClub no debrid configured, routing via Elementum: %s' % elem_url[:80], xbmc.LOGINFO)
        li = xbmcgui.ListItem(path=elem_url, label=title or 'XXXClub')
        xbmcplugin.setResolvedUrl(handle, True, li)
        return

    li = xbmcgui.ListItem(path=stream_url, label=title)
    xbmcplugin.setResolvedUrl(handle, True, li)
