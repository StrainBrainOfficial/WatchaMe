# -*- coding: utf-8 -*-
"""
resources/lib/profiles.py

Viewer profiles: each person in the house keeps their own watch history, Continue Watching, favourites, My Teams and their own
SIMKL / Trakt / WeTrakr / TMDB / MDBList accounts, and switching is instant - no logging in or out.

How it is kept apart
  * Data     every per-person file lives in the profile's own folder (data_dir()). The first profile ("Main") uses the add-on's
             existing data folder, so nothing is moved and nothing is lost; later profiles live in <that folder>/profiles/<id>/.
  * Accounts the pairing tokens are Kodi settings, so they are saved into the profile's folder when you switch away and the new
             profile's are put back (PROFILE_SETTINGS). The sync code never knows: it just reads the current setting.
  * Limits   a profile can hide the Adult section (its adult_enabled setting is forced off), cap the content rating shown
             (G / 7+ / 14+), and have its own PIN. An optional Parent PIN stops a restricted profile from opening Settings,
             changing profiles or switching to an unrestricted one.

profiles.json (in the add-on's data folder): {"version": 1, "active": id, "parent_pin": {"salt", "hash"} | null,
"profiles": [{"id", "name", "kind": "adult"|"kids", "hide_adult", "max_rating": "none"|"g"|"7"|"14", "pin": {"salt","hash"}|null}]}
Nothing in here raises: a broken registry falls back to one default profile.
"""
import hashlib
import json
import os
import re
import threading

import xbmc

REG_FILE = 'profiles.json'
SNAPSHOT = 'settings_snapshot.json'
MAIN_ID = 'main'

# settings that belong to one person: switching profiles saves these into the old profile and restores the new profile's
PROFILE_SETTINGS = ('trakt_access_token', 'trakt_refresh_token', 'simkl_access_token', 'wetrakr_access_token', 'wetrakr_username',
                    'wetrakr_auth_invalid', 'mdblist_api_key', 'mdblist_enabled', 'tmdb_v4_access_token', 'tmdb_v4_account_id',
                    'adult_enabled')

# content-rating ladder: a profile shows titles up to its cap
RATINGS = (('none', 'No limit'), ('14', 'Up to 14+ (PG-13 / TV-14)'), ('7', 'Up to 7+ (PG / TV-PG)'),
           ('g', 'Little kids (G / TV-Y / TV-G)'))
_CAP = {'none': 99, '14': 3, '7': 2, 'g': 1}
_RANK = {'G': 1, 'TV-Y': 1, 'TV-G': 1, 'TV-Y7': 1, 'TV-Y7-FV': 1, 'PG': 2, 'TV-PG': 2, 'PG-13': 3, 'TV-14': 3, 'R': 4, 'TV-MA': 4,
         'NC-17': 5, 'X': 5}

_LOCK = threading.RLock()
_switch_hooks = []


def _log(msg):
    xbmc.log('[Starfleet/Profiles] %s' % msg, xbmc.LOGINFO)


# ── storage ─────────────────────────────────────────────────────────────────────────────────────────────────────────

def base_dir():
    import xbmcvfs
    d = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.starfleet/')
    os.makedirs(d, exist_ok=True)
    return d


def _reg_path():
    return os.path.join(base_dir(), REG_FILE)


def _default_registry():
    return {'version': 1, 'active': MAIN_ID, 'parent_pin': None,
            'profiles': [{'id': MAIN_ID, 'name': 'Main', 'kind': 'adult', 'hide_adult': False, 'max_rating': 'none', 'pin': None}]}


def _load():
    try:
        with open(_reg_path(), 'r', encoding='utf-8') as f:
            reg = json.load(f)
        if not isinstance(reg, dict) or not reg.get('profiles'):
            raise ValueError('empty')
        if not any(p.get('id') == reg.get('active') for p in reg['profiles']):
            reg['active'] = reg['profiles'][0]['id']
        return reg
    except Exception:
        return _default_registry()


def _save(reg):
    p = _reg_path()
    with open(p + '.tmp', 'w', encoding='utf-8') as f:
        json.dump(reg, f)
    os.replace(p + '.tmp', p)


def all_profiles():
    return list(_load()['profiles'])


def get(pid):
    return next((p for p in _load()['profiles'] if p['id'] == pid), None)


def active_id():
    return _load()['active']


def active():
    reg = _load()
    return next(p for p in reg['profiles'] if p['id'] == reg['active'])


def has_multiple():
    return len(_load()['profiles']) > 1


def data_dir(pid=None):
    """Folder holding a profile's own files (the active profile's when pid is None). Main uses the add-on's data folder."""
    pid = pid or active_id()
    if pid == MAIN_ID:
        return base_dir()
    d = os.path.join(base_dir(), 'profiles', pid)
    os.makedirs(d, exist_ok=True)
    return d


def data_path(name, pid=None):
    return os.path.join(data_dir(pid), name)


# ── PINs ────────────────────────────────────────────────────────────────────────────────────────────────────────────

def _hash_pin(pin, salt=None):
    salt = salt or os.urandom(8).hex()
    return {'salt': salt, 'hash': hashlib.sha256((salt + str(pin)).encode('utf-8')).hexdigest()}


def _pin_ok(entry, pin):
    return bool(entry) and hashlib.sha256((entry['salt'] + str(pin)).encode('utf-8')).hexdigest() == entry['hash']


def set_profile_pin(pid, pin):
    with _LOCK:
        reg = _load()
        for p in reg['profiles']:
            if p['id'] == pid:
                p['pin'] = _hash_pin(pin) if pin else None
        _save(reg)


def check_profile_pin(pid, pin):
    p = get(pid)
    return bool(p) and (not p.get('pin') or _pin_ok(p['pin'], pin))


def set_parent_pin(pin):
    with _LOCK:
        reg = _load()
        reg['parent_pin'] = _hash_pin(pin) if pin else None
        _save(reg)


def has_parent_pin():
    return bool(_load().get('parent_pin'))


def check_parent_pin(pin):
    return _pin_ok(_load().get('parent_pin'), pin)


# ── profiles ────────────────────────────────────────────────────────────────────────────────────────────────────────

def is_restricted(p=None):
    """A profile that is limited in some way (kids, a hidden Adult section, or a rating cap)."""
    p = p or active()
    return p.get('kind') == 'kids' or bool(p.get('hide_adult')) or p.get('max_rating', 'none') != 'none'


def rating_label(code):
    return dict(RATINGS).get(code, 'No limit')


def create(name, kind='adult', hide_adult=None, max_rating=None, pin=''):
    """A new profile. Kids default to a hidden Adult section and a 14+ cap; adults to no limits. Returns the profile dict."""
    name = (name or '').strip()[:24] or 'Profile'
    kind = 'kids' if kind == 'kids' else 'adult'
    with _LOCK:
        reg = _load()
        base = re.sub(r'[^a-z0-9]+', '', name.lower()) or 'p'
        pid = '%s%s' % (base[:12], os.urandom(2).hex())
        prof = {'id': pid, 'name': name, 'kind': kind,
                'hide_adult': (kind == 'kids') if hide_adult is None else bool(hide_adult),
                'max_rating': (max_rating or ('14' if kind == 'kids' else 'none')),
                'pin': _hash_pin(pin) if pin else None}
        reg['profiles'].append(prof)
        _save(reg)
    data_dir(pid)
    _log('created %s (%s)' % (name, kind))
    return prof


def update(pid, **fields):
    """Change a profile's name / kind / hide_adult / max_rating. Applies to the live settings when it is the active one."""
    allowed = {'name', 'kind', 'hide_adult', 'max_rating', 'daily_minutes', 'bed_hour'}
    with _LOCK:
        reg = _load()
        for p in reg['profiles']:
            if p['id'] == pid:
                for k, v in fields.items():
                    if k in allowed:
                        p[k] = v
        _save(reg)
    if pid == active_id():
        _enforce(get(pid))


def delete(pid):
    """Remove a profile and its data. The active profile and the last remaining one cannot be deleted. Returns True if done."""
    import shutil
    with _LOCK:
        reg = _load()
        if pid == reg['active'] or len(reg['profiles']) <= 1:
            return False
        reg['profiles'] = [p for p in reg['profiles'] if p['id'] != pid]
        _save(reg)
    if pid != MAIN_ID:
        shutil.rmtree(os.path.join(base_dir(), 'profiles', pid), ignore_errors=True)
    return True


# ── switching ───────────────────────────────────────────────────────────────────────────────────────────────────────

def on_switch(fn):
    """Register fn() to run after the active profile changes (caches that must be dropped)."""
    _switch_hooks.append(fn)


def _addon():
    import xbmcaddon
    return xbmcaddon.Addon('plugin.video.starfleet')


def _snapshot_now():
    a = _addon()
    return {k: a.getSetting(k) for k in PROFILE_SETTINGS}


def _enforce(p):
    """A profile with a hidden Adult section can never have it switched on by a leftover setting."""
    if p and p.get('hide_adult'):
        _addon().setSetting('adult_enabled', 'false')


def _reset_caches():
    """Everything held in memory for the previous profile: favourites, the tracker lists, the Adult unlock for this session."""
    import sys
    fav = sys.modules.get('resources.lib.favorites')
    if fav is not None:
        fav._DB = None
    tl = sys.modules.get('resources.lib.tracker_lists')
    if tl is not None:
        tl.clear_cache()
    try:
        from resources.lib import pin_lock
        pin_lock._clear_unlock_marker()
    except Exception:
        pass


def enforce_active():
    """Re-apply the active profile's limits to the live settings (a hidden Adult section stays hidden, whatever Settings says)."""
    try:
        _enforce(active())
    except Exception as e:
        _log('enforce: %s' % e)


def switch(pid):
    """Make `pid` the active profile: save the old one's accounts, restore the new one's. The caller has already asked for the
    profile's PIN where it has one. Returns the profile, or None for an unknown id."""
    with _LOCK:
        reg = _load()
        target = next((p for p in reg['profiles'] if p['id'] == pid), None)
        if not target or pid == reg['active']:
            return target
        old = reg['active']
        try:                                              # the outgoing profile keeps what is in the settings now
            with open(data_path(SNAPSHOT, old), 'w', encoding='utf-8') as f:
                json.dump(_snapshot_now(), f)
        except Exception as e:
            _log('could not save %s settings: %s' % (old, e))
        snap = None
        try:
            with open(data_path(SNAPSHOT, pid), 'r', encoding='utf-8') as f:
                snap = json.load(f)
        except Exception:
            pass
        a = _addon()
        if snap is None:                                  # a profile's first time in: no accounts yet; Adult as the current one
            snap = {k: '' for k in PROFILE_SETTINGS}
            snap['adult_enabled'] = a.getSetting('adult_enabled') if target['kind'] == 'adult' else 'false'
            snap['mdblist_enabled'] = 'false'
            snap['wetrakr_auth_invalid'] = 'false'
        for k in PROFILE_SETTINGS:
            a.setSetting(k, snap.get(k, ''))
        _enforce(target)
        reg['active'] = pid
        _save(reg)
    _log('switched to %s' % target['name'])
    _reset_caches()
    for fn in list(_switch_hooks):
        try:
            fn()
        except Exception as e:
            _log('switch hook: %s' % e)
    return target


# ── content rating limit ────────────────────────────────────────────────────────────────────────────────────────────

_cert_cache = {}


def rating_allowed(cert, max_rating):
    """True when a US certification ('PG-13', 'TV-MA'...) is within the cap. Unknown / unrated titles are hidden under any cap."""
    cap = _CAP.get(max_rating, 99)
    if cap >= 99:
        return True
    rank = _RANK.get((cert or '').strip().upper())
    return rank is not None and rank <= cap


def _certification(tmdb_id, media_type):
    key = (str(tmdb_id), media_type)
    if key in _cert_cache:
        return _cert_cache[key]
    cert = ''
    try:
        from resources.lib import metadata as _meta
        d = (_meta.get_movie_detail(tmdb_id) if media_type == 'movie' else _meta.get_tv_detail(tmdb_id)) or {}
        cert = d.get('mpaa', '') or ''
    except Exception:
        cert = None                                       # unknown right now: not cached, treated as hidden this time
    if cert is not None:
        _cert_cache[key] = cert
    return cert or ''


def filter_items(items, media_type='movie', budget=8.0):
    """`items` for the active profile: titles above its rating cap are dropped. Only TMDB titles are judged (those with a tmdb_id
    and a movie / TV type); sports, live TV, radio and the rest pass through. Unlimited profiles return the list untouched, at no
    cost. Certifications are looked up side by side and remembered."""
    try:
        p = active()
    except Exception:
        return items
    cap = p.get('max_rating', 'none')
    if cap == 'none' or not items:
        return items
    from concurrent.futures import ThreadPoolExecutor, wait
    judged = []
    for it in items:
        mt = it.get('media_type') or media_type
        if it.get('tmdb_id') and mt in ('movie', 'tv') and not str(it.get('source', '')).startswith(('ade', 'afdb', 'panda', 'hqp')):
            judged.append((it, mt))
    if not judged:
        return items
    pool = ThreadPoolExecutor(max_workers=8)
    futs = {id(it): pool.submit(_certification, it['tmdb_id'], mt) for it, mt in judged}
    pool.shutdown(wait=False)
    wait(list(futs.values()), timeout=budget)
    out = []
    for it in items:
        f = futs.get(id(it))
        if f is None:
            out.append(it)
            continue
        cert = f.result() if f.done() and not f.exception() else ''
        if rating_allowed(cert, cap):
            out.append(it)
    return out


def filter_rows(rows):
    """Home carousel data ({context: [row, row, row, row]}) with every row filtered for the active profile."""
    try:
        if active().get('max_rating', 'none') == 'none':
            return rows
    except Exception:
        return rows
    out = {}
    for ctx, lists in rows.items():
        out[ctx] = [filter_items(r, budget=12.0) if r else r for r in lists] if isinstance(lists, list) else lists
    return out
