# -*- coding: utf-8 -*-
"""This scraper now lives in script.module.starfleetscrapers (starfleetscrapers.adult.afdb). This file only keeps the old
import name working: importing it gives you that module itself, so every attribute and function is unchanged."""
import sys

from resources.lib import _scrapers_bridge  # noqa: F401  (registers what the scrapers need from this add-on)
from starfleetscrapers.adult import afdb as _impl

sys.modules[__name__] = _impl
