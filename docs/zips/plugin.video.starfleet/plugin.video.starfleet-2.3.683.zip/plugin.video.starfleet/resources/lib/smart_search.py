# -*- coding: utf-8 -*-
"""
resources/lib/smart_search.py

Smart Search: type what you want the way you would say it - "a 90 minute thriller like Prisoners but lighter", "comedy series
with short episodes from the 90s", "best sci-fi movies with Tom Hanks", "heist movies" - and get TMDB's own answer.

No AI service is involved. parse() reads the sentence for the things TMDB can filter on (kind, genres, runtime, decade / year,
rating, a person, "like <title>", a mood that maps to genres, and any leftover words as keywords) and search() asks TMDB's
discover endpoint with them. "Like <title>" starts from TMDB's own recommended / similar lists for that title, filtered by the
rest of the sentence, and is topped up from discover.

    parse(text, default_media='movie') -> dict   (media, params, like, person, explain)
    search(text, default_media='movie', page=1) -> (media, items, explain)    items are slim TMDB dicts like every list in the add-on
"""
import re
import time

import xbmc

_MOVIE_GENRES = {'action': 28, 'adventure': 12, 'animation': 16, 'animated': 16, 'cartoon': 16, 'comedy': 35, 'comedies': 35,
                 'funny': 35, 'crime': 80, 'documentary': 99, 'documentaries': 99, 'drama': 18, 'family': 10751, 'fantasy': 14,
                 'history': 36, 'historical': 36, 'horror': 27, 'scary': 27, 'music': 10402, 'musical': 10402, 'mystery': 9648,
                 'romance': 10749, 'romantic': 10749, 'sci-fi': 878, 'scifi': 878, 'sci fi': 878, 'science fiction': 878,
                 'thriller': 53, 'thrillers': 53, 'suspense': 53, 'war': 10752, 'western': 37, 'westerns': 37}
_TV_GENRES = {'action': 10759, 'adventure': 10759, 'animation': 16, 'animated': 16, 'cartoon': 16, 'comedy': 35, 'comedies': 35,
              'funny': 35, 'crime': 80, 'documentary': 99, 'documentaries': 99, 'drama': 18, 'family': 10751, 'kids': 10762,
              'fantasy': 10765, 'sci-fi': 10765, 'scifi': 10765, 'sci fi': 10765, 'science fiction': 10765, 'mystery': 9648,
              'reality': 10764, 'war': 10768, 'western': 37, 'westerns': 37, 'thriller': 9648, 'thrillers': 9648,
              'suspense': 9648, 'horror': 9648, 'scary': 9648, 'romance': 18, 'romantic': 18, 'history': 36}
# moods: (genres to lean towards, genres to leave out) - movie ids; TV is mapped through _TV_FROM_MOVIE
_LIGHT = ((35, 10751, 16, 10749), (27, 10752, 80))
_DARK = ((53, 80, 18, 27), (35, 10751))
_TV_FROM_MOVIE = {28: 10759, 12: 10759, 14: 10765, 878: 10765, 10752: 10768, 53: 9648, 27: 9648, 10749: 18, 10402: 10402}
_TV_WORDS = re.compile(r'\b(series|show|shows|tv|season|seasons|episodes?|sitcom|miniseries|binge)\b', re.I)
_MOVIE_WORDS = re.compile(r'\b(movie|movies|film|films|flick|flicks)\b', re.I)
_STOP = set('a an the of for to in on with without from and or but that this these those some any good great best top new recent '
            'old classic please find me show give want watch watching something anything like similar movie movies film films '
            'series shows tv episode episodes less more really very kind sort type about is are was were it its i you my we '
            'under over than hour hours minute minutes min mins long short length runtime rated rating highly decade era '
            'from before after since between made starring directed by dark light lighter darker funnier bleak gritty cozy '
            'feel feelgood feel-good uplifting wholesome happy sad scary not too hidden gem gems underrated epic acclaimed masterpiece '
            'masterpieces what start weekend tonight next binge watchable heartwarming lighthearted light-hearted cozy gritty '
            'bleak depressing grim violent heavy intense lesser known awards award winning'.split())


def _log(msg):
    xbmc.log('[Starfleet/SmartSearch] %s' % msg, xbmc.LOGINFO)


def parse(text, default_media='movie'):
    t = ' %s ' % re.sub(r'\s+', ' ', (text or '').strip().lower().replace('’', "'"))
    plan = {'media': default_media, 'params': {}, 'like': '', 'person': '', 'director': '', 'explain': [], 'keywords': '',
            'lean': set(), 'avoid': set()}
    ex = plan['explain']
    # a title after "like" / "similar to": kept apart (and cut out of the sentence) so its words are not read as filters
    orig = re.sub(r'\s+', ' ', (text or '').strip())
    m = re.search(r'\b(?:like|similar to|such as|reminds? me of|in the style of|along the lines of)\s+'
                  r'(.+?)(?=\s+(?:but|with|and|that|which|from|under|over|only|except|though|yet)\b|[,.;]|$)', orig, re.I)
    if m:
        plan['like'] = m.group(1).strip(' "\'')
        t = ' %s ' % (orig[:m.start()] + ' ' + orig[m.end():]).lower()
        ex.append('like %s' % plan['like'])
    # kind
    if _TV_WORDS.search(t) and not _MOVIE_WORDS.search(t):
        plan['media'] = 'tv'
    elif _MOVIE_WORDS.search(t):
        plan['media'] = 'movie'
    media = plan['media']
    genres = _TV_GENRES if media == 'tv' else _MOVIE_GENRES
    p = plan['params']
    # runtime
    n = None
    mm = re.search(r'(?:under|less than|below|shorter than|max(?:imum)?|no longer than|within)\s+(\d+(?:\.\d+)?)\s*(hours?|hrs?|h|minutes?|mins?|m)\b', t)
    if mm:
        n = float(mm.group(1)) * (60 if mm.group(2).startswith('h') else 1)
        p['with_runtime.lte'] = int(n)
        ex.append('under %d min' % n)
    mm = re.search(r'(?:over|more than|above|longer than|at least)\s+(\d+(?:\.\d+)?)\s*(hours?|hrs?|h|minutes?|mins?|m)\b', t)
    if mm:
        n = float(mm.group(1)) * (60 if mm.group(2).startswith('h') else 1)
        p['with_runtime.gte'] = int(n)
        ex.append('over %d min' % n)
    mm = re.search(r'(\d+)\s*[- ]?\s*(hours?|hrs?|minutes?|mins?)\b(?:\s+long)?', t)
    if mm and not p:
        n = float(mm.group(1)) * (60 if mm.group(2).startswith('h') else 1)
        p['with_runtime.gte'], p['with_runtime.lte'] = max(1, int(n * 0.8)), int(n * 1.15)
        ex.append('about %d min' % n)
    if re.search(r'\bshort (?:episodes?|runtime)|\bquick watch|\bhalf[- ]hour\b', t):
        p['with_runtime.lte'] = 35 if media == 'tv' else 90
        ex.append('short')
    elif re.search(r'\blong (?:movies?|films?|epics?)\b|\bepic\b', t) and media == 'movie':
        p['with_runtime.gte'] = 150
        ex.append('long')
    # time
    cy = time.localtime().tm_year
    mm = re.search(r"\b(?:from the |in the |of the )?(19|20)?(\d0)'?s\b", t)
    if mm and not re.search(r'\d{4}', mm.group(0)):
        dec = int(((mm.group(1) or ('19' if int(mm.group(2)) >= 30 else '20')) + mm.group(2)))
        lo, hi = dec, dec + 9
        k = 'primary_release_date' if media == 'movie' else 'first_air_date'
        p[k + '.gte'], p[k + '.lte'] = '%d-01-01' % lo, '%d-12-31' % hi
        ex.append('%ds' % dec)
    else:
        k = 'primary_release_date' if media == 'movie' else 'first_air_date'
        mm = re.search(r'\b(?:before|older than|prior to)\s+((?:19|20)\d{2})\b', t)
        if mm:
            p[k + '.lte'] = '%s-12-31' % (int(mm.group(1)) - 1)
            ex.append('before %s' % mm.group(1))
        mm = re.search(r'\b(?:after|since|newer than|later than)\s+((?:19|20)\d{2})\b', t)
        if mm:
            p[k + '.gte'] = '%s-01-01' % (int(mm.group(1)) + 1)
            ex.append('after %s' % mm.group(1))
        mm = re.search(r'\b(?:from|in|released in|year)\s+((?:19|20)\d{2})\b', t)
        if mm and k + '.gte' not in p and k + '.lte' not in p:
            p[k + '.gte'], p[k + '.lte'] = '%s-01-01' % mm.group(1), '%s-12-31' % mm.group(1)
            ex.append(mm.group(1))
        if re.search(r'\b(?:new|recent|latest|newest|this year)\b', t) and k + '.gte' not in p:
            p[k + '.gte'] = '%d-01-01' % (cy - 2)
            ex.append('recent')
        elif re.search(r'\b(?:classic|classics|old[- ]school|golden age|vintage)\b', t) and k + '.lte' not in p:
            p[k + '.lte'] = '1989-12-31'
            ex.append('classic')
    # quality
    if re.search(r'\bhidden gems?\b|\bunderrated\b|\blesser[- ]known\b', t):
        p['vote_average.gte'], p['vote_count.gte'], p['vote_count.lte'] = 7, 150, 2500
        p['sort_by'] = 'vote_average.desc'
        ex.append('hidden gems')
    elif re.search(r'\b(?:best|top|highly rated|critically acclaimed|acclaimed|award[- ]winning|masterpieces?)\b', t):
        p['vote_average.gte'], p['vote_count.gte'] = 7.5, 800
        p['sort_by'] = 'vote_average.desc'
        ex.append('highly rated')
        plan['best'] = True
    # a person
    mm = re.search(r'\b(?:starring|with|featuring|stars?)\s+([A-Z][\w\'.-]+(?:\s+[A-Z][\w\'.-]+){0,2})', orig)
    if mm and mm.group(1).lower() not in genres:
        plan['person'] = mm.group(1)
        ex.append('with %s' % mm.group(1))
    mm = re.search(r'\b(?:directed by|director|from director|by)\s+([A-Z][\w\'.-]+(?:\s+[A-Z][\w\'.-]+){0,2})', orig)
    if mm:
        plan['director'] = mm.group(1)
        ex.append('directed by %s' % mm.group(1))
    # genres and moods
    ids = []
    for word, gid in sorted(genres.items(), key=lambda kv: -len(kv[0])):
        if gid and re.search(r'(?<![a-z])%s(?![a-z])' % re.escape(word), t) and gid not in ids:
            ids.append(gid)
            ex.append(word)
            t = re.sub(r'(?<![a-z])%s(?![a-z])' % re.escape(word), ' ', t)
    if re.search(r'\bless (?:bleak|dark|gritty|depressing|grim|violent|heavy|intense)\b|\blighter\b|\bfeel[- ]?good\b|\buplifting\b|'
                 r'\bwholesome\b|\bcozy\b|\bhappy\b|\bheartwarming\b|\blight[- ]?hearted\b', t):
        plan['lean'].update(_LIGHT[0])
        plan['avoid'].update(_LIGHT[1])
        ex.append('lighter')
    elif re.search(r'\bdark(?:er)?\b|\bgritty\b|\bbleak\b|\bdisturbing\b|\bintense\b', t):
        plan['lean'].update(_DARK[0])
        plan['avoid'].update(_DARK[1])
        ex.append('darker')
    plan['genres'] = ids
    if (plan['person'] or plan['director']) and plan.get('best'):      # a person's films are few: a lower bar for "best"
        p['vote_average.gte'], p['vote_count.gte'] = 6.8, 200
    # whatever is left is a topic ("heist", "time travel", "space"): TMDB keywords
    words = [w for w in re.findall(r"[a-z][a-z'-]+", t) if w not in _STOP and len(w) > 2 and w not in genres]
    if plan['person']:
        pw = set(re.findall(r"[a-z][a-z'-]+", plan['person'].lower()))
        words = [w for w in words if w not in pw]
    if plan['director']:
        pw = set(re.findall(r"[a-z][a-z'-]+", plan['director'].lower()))
        words = [w for w in words if w not in pw]
    plan['keywords'] = ' '.join(words[:3])
    if plan['keywords']:
        ex.append('about %s' % plan['keywords'])
    return plan


def _genre_ids(plan, media):
    ids = list(plan.get('genres', []))
    lean = set(plan.get('lean') or ())
    if media == 'tv':
        lean = {_TV_FROM_MOVIE.get(g, g) for g in lean}
    avoid = set(plan.get('avoid') or ())
    if media == 'tv':
        avoid = {_TV_FROM_MOVIE.get(g, g) for g in avoid}
    return ids, lean, avoid


def _tmdb(endpoint, params):
    from resources.lib import metadata as _md
    return _md._tmdb_get(endpoint, params)


def _person_id(name):
    try:
        res = _tmdb('/search/person', {'query': name}).get('results') or []
        return str(res[0]['id']) if res else ''
    except Exception:
        return ''


def _keyword_ids(words):
    ids = []
    for w in words.split():
        try:
            res = _tmdb('/search/keyword', {'query': w}).get('results') or []
            if res:
                ids.append(str(res[0]['id']))
        except Exception:
            pass
    return '|'.join(ids)


def _slim(items, media):
    from resources.lib import metadata as _md
    f = _md._slim_tv if media == 'tv' else _md._slim_movie
    return [f(i) for i in items if i.get('id')]


def _like(plan, media):
    """(recommended + similar titles of the named title with the title itself left out, kind, the named title's genre ids)."""
    try:
        found = _tmdb('/search/%s' % ('tv' if media == 'tv' else 'movie'), {'query': plan['like']}).get('results') or []
    except Exception:
        found = []
    if not found:
        try:                                              # "like X" without saying film or show: try the other kind
            other = 'movie' if media == 'tv' else 'tv'
            found2 = _tmdb('/search/%s' % other, {'query': plan['like']}).get('results') or []
            if found2:
                return _like(dict(plan), other)
        except Exception:
            pass
        return [], media, []
    base = found[0]
    out = []
    for kind in ('recommendations', 'similar'):
        try:
            out += _tmdb('/%s/%s/%s' % ('tv' if media == 'tv' else 'movie', base['id'], kind), {}).get('results') or []
        except Exception:
            pass
    seen, uniq = {base['id']}, []
    for it in out:
        if it.get('id') not in seen:
            seen.add(it['id'])
            uniq.append(it)
    return uniq, media, list(base.get('genre_ids') or [])


def _year(it):
    return int((it.get('release_date') or it.get('first_air_date') or '0000')[:4] or 0)


def _passes(it, plan, media):
    """The parts of the sentence a plain list item can be checked against."""
    p = plan['params']
    ids, lean, avoid = _genre_ids(plan, media)
    gids = set(it.get('genre_ids') or [])
    if ids and not gids & set(ids):
        return False
    if avoid and gids & avoid:
        return False
    k = 'primary_release_date' if media == 'movie' else 'first_air_date'
    y = _year(it)
    if k + '.gte' in p and y and y < int(p[k + '.gte'][:4]):
        return False
    if k + '.lte' in p and y and y > int(p[k + '.lte'][:4]):
        return False
    if 'vote_average.gte' in p and (it.get('vote_average') or 0) < float(p['vote_average.gte']):
        return False
    if 'vote_count.gte' in p and (it.get('vote_count') or 0) < min(float(p['vote_count.gte']), 300):
        return False
    if (it.get('vote_count') or 0) < 40:                  # a recommended / similar title nobody has rated is not a good answer
        return False
    return True


def search(text, default_media='movie', page=1):
    plan = parse(text, default_media)
    media = plan['media']
    p = dict(plan['params'])
    ids, lean, avoid = _genre_ids(plan, media)
    items = []
    like_ids = set()
    base_genres = []
    if plan['like']:
        like_items, media, base_genres = _like(plan, media)
        ids, lean, avoid = _genre_ids(plan, media)
        like_ids = {i.get('id') for i in like_items}
        if page == 1 and not any(k.startswith('with_runtime') for k in p):
            items = [i for i in like_items if _passes(i, plan, media)]
            if lean:
                items.sort(key=lambda i: -len(set(i.get('genre_ids') or []) & lean))
    # discover: the sentence as filters (also tops up a "like" list)
    d = {'sort_by': p.pop('sort_by', 'popularity.desc'), 'page': page, 'include_adult': 'false', 'vote_count.gte': p.pop('vote_count.gte', 300 if plan['like'] else 60)}
    d.update(p)
    if plan['like'] and not ids and not lean and base_genres:        # "like X": X's own (first two) genres, any of them
        d['with_genres'] = '|'.join(str(g) for g in base_genres[:2])
    if ids or lean:
        d['with_genres'] = ','.join(str(g) for g in (ids or sorted(lean)[:2]))     # "," = all of them
        if not ids and lean:
            d['with_genres'] = '|'.join(str(g) for g in sorted(lean))              # "|" = any
    if media == 'tv':                                     # talk shows and news carry the comedy / drama tags too
        avoid = set(avoid) | ({10767, 10763} - set(ids))
    if avoid:
        d['without_genres'] = ','.join(str(g) for g in sorted(avoid))
    if plan['person']:
        pid = _person_id(plan['person'])
        if pid:
            d['with_cast' if media == 'movie' else 'with_people'] = pid
    if plan['director']:
        pid = _person_id(plan['director'])
        if pid and media == 'movie':
            d['with_crew'] = pid
    if plan['keywords'] and not plan['like']:
        kw = _keyword_ids(plan['keywords'])
        if kw:
            d['with_keywords'] = kw
    if media == 'movie' and d.get('with_runtime.lte') and not d.get('with_runtime.gte'):
        d['with_runtime.gte'] = 40
    try:
        got = _tmdb('/discover/%s' % ('tv' if media == 'tv' else 'movie'), d).get('results') or []
    except Exception as e:
        _log('discover failed: %s' % e)
        got = []
    seen = {i.get('id') for i in items}
    if like_ids:                                          # titles TMDB itself links to the named one come first
        got = [i for i in got if i.get('id') in like_ids] + [i for i in got if i.get('id') not in like_ids]
    items += [i for i in got if i.get('id') not in seen]
    explain = ', '.join(plan['explain']) or 'popular right now'
    return media, _slim(items, media), explain


# ── the page ────────────────────────────────────────────────────────────────

def smart_search(handle, build_url, query='', media='movie', page=1):
    import xbmcgui
    import xbmcplugin
    from resources.lib import metadata_router as _mr
    page = int(page or 1)
    if not query:
        kb = xbmc.Keyboard('', 'Describe what you want to watch')
        kb.doModal()
        if not kb.isConfirmed() or not kb.getText().strip():
            xbmcplugin.endOfDirectory(handle, succeeded=False)
            return
        query = kb.getText().strip()
    dlg = _mr._progress('Looking...')
    try:
        kind, items, explain = search(query, media, page)
    finally:
        dlg.close()
    if not items:
        xbmcgui.Dialog().notification('Smart Search', 'Nothing matched: %s' % query, xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return
    xbmcplugin.setPluginCategory(handle, '✨ %s' % query)
    xbmcplugin.setContent(handle, 'tvshows' if kind == 'tv' else 'movies')
    xbmcgui.Dialog().notification('Smart Search', 'Understood: %s' % explain, xbmcgui.NOTIFICATION_INFO, 3500)
    if kind == 'tv':
        _mr._render_tv_list(handle, build_url, items)
        _mr._prewarm_tv_details(items)
    else:
        _mr._render_movie_list(handle, build_url, items)
        _mr._prewarm_movie_details(items)
    if len(items) >= 15:
        build_url_next = {'action': 'smart_search', 'query': query, 'media': kind, 'page': page + 1}
        _mr._add_dir(handle, build_url, 'Next page', build_url_next, plot='More like this')
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)
