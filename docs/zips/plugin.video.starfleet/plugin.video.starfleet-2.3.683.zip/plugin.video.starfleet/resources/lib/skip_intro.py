# -*- coding: utf-8 -*-
"""
resources/lib/skip_intro.py

Skip intro / recap: where an episode's intro and recap are, from the public IntroDB timestamp database (looked up by IMDb id, season and
episode; no key, nothing about the viewer is sent). Episodes nobody has marked simply have no marks and nothing happens. The service
(service.py) runs SkipPlayer, which follows Kodi's player. Same lookup as the HazMat TV app's skip button.

Setting skip_intro: 0 = off, 1 = ask (a prompt for a few seconds when the intro starts), 2 = skip automatically.
"""
import threading
import xbmc
import xbmcaddon
import xbmcgui
import requests as _req

_cache = {}


def _log(msg):
    xbmc.log('[Starfleet/SkipIntro] %s' % msg, xbmc.LOGINFO)


def _mode():
    try:
        return int(xbmcaddon.Addon('plugin.video.starfleet').getSetting('skip_intro') or 0)
    except Exception:
        return 0


def _span(o):
    if not isinstance(o, dict):
        return None
    s, e = o.get('start_ms', -1), o.get('end_ms', -1)
    try:
        return (s / 1000.0, e / 1000.0) if s >= 0 and e > s else None
    except TypeError:
        return None


def load(imdb, season, episode):
    """[(label, start_s, end_s)] for the episode ([] when it has no marks or the lookup failed)."""
    if not imdb or not str(imdb).startswith('tt') or season <= 0 or episode <= 0:
        return []
    key = (imdb, season, episode)
    if key in _cache:
        return _cache[key]
    try:
        r = _req.get('https://api.introdb.app/segments', params={'imdb_id': imdb, 'season': season, 'episode': episode}, timeout=8)
        if r.status_code == 404:
            marks = []
        elif r.status_code != 200:
            return []                                   # a failed try is not remembered
        else:
            j = r.json()
            marks = [(lbl, sp[0], sp[1]) for lbl, sp in (('intro', _span(j.get('intro'))), ('recap', _span(j.get('recap')))) if sp]
    except Exception:
        return []
    _cache[key] = marks
    return marks


class SkipPlayer(xbmc.Player):
    def __init__(self):
        xbmc.Player.__init__(self)
        self._gen = 0

    def onAVStarted(self):
        self._gen += 1
        if _mode() and self.isPlayingVideo():
            threading.Thread(target=self._watch, args=(self._gen,), daemon=True, name='starfleet-skip-intro').start()

    def onPlayBackStopped(self):
        self._gen += 1

    onPlayBackEnded = onPlayBackStopped

    def _watch(self, gen):
        try:
            tag = self.getVideoInfoTag()
            season, episode, imdb = tag.getSeason(), tag.getEpisode(), tag.getIMDBNumber()
            marks = load(imdb, season, episode)
            if not marks:
                return
            _log('%s S%sE%s: %s' % (imdb, season, episode, marks))
            done = set()
            mon = xbmc.Monitor()
            while gen == self._gen and not mon.waitForAbort(1):
                try:
                    pos = self.getTime()
                except Exception:
                    return
                for label, start, end in marks:
                    if label in done or not (start - 1 <= pos < end - 2):
                        continue
                    done.add(label)
                    mode = _mode()
                    if mode == 2 or (mode == 1 and xbmcgui.Dialog().yesno('Skip %s?' % label, 'Skip the %s now?' % label, nolabel='No', yeslabel='Skip', autoclose=7000)):
                        if gen == self._gen:
                            self.seekTime(end)
                            xbmcgui.Dialog().notification('Starfleet', 'Skipped the %s' % label, xbmcgui.NOTIFICATION_INFO, 1500, False)
        except Exception as e:
            xbmc.log('[Starfleet/SkipIntro] %s' % e, xbmc.LOGWARNING)
