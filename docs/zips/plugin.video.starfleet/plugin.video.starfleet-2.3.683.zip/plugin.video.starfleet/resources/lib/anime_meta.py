# -*- coding: utf-8 -*-
"""Anime lists for the Anime section: AniList supplies the catalogue (trending, this season, airing, upcoming, top rated, genres,
search, films) and every entry is linked to its TMDB show / film, so the rest of Starfleet - details, seasons, episodes, the source
picker - works on anime exactly as it does for any other title.

Each function returns TMDB-shaped dicts (tmdb_id, title, year, rating, thumb, fanart, overview, media_type) like metadata.get_tv_*;
entries AniList has but TMDB does not are left out, since there is nothing to open them with."""
import datetime
import re
from concurrent.futures import ThreadPoolExecutor

import requests
import xbmc

from resources.lib import cache as _cache
from resources.lib import metadata as _meta

_API = 'https://graphql.anilist.co'
PAGE_SIZE = 40

_FIELDS = ('id idMal format status episodes season seasonYear startDate{year} averageScore popularity description(asHtml:false) '
           'genres title{romaji english} coverImage{extraLarge large} bannerImage trailer{id site} nextAiringEpisode{episode}')

GENRES = ['Action', 'Adventure', 'Comedy', 'Drama', 'Fantasy', 'Horror', 'Mahou Shoujo', 'Mecha', 'Music', 'Mystery',
          'Psychological', 'Romance', 'Sci-Fi', 'Slice of Life', 'Sports', 'Supernatural', 'Thriller']

_TV_FORMATS = '[TV, TV_SHORT, ONA]'

# list kind -> (AniList filter arguments, cache lifetime seconds)
_KINDS = {
    'trending': ('sort: TRENDING_DESC, format_in: %s' % _TV_FORMATS, 3600),
    'popular':  ('sort: POPULARITY_DESC, format_in: %s, status_in: [RELEASING, FINISHED]' % _TV_FORMATS, 6 * 3600),
    'airing':   ('sort: POPULARITY_DESC, format_in: %s, status: RELEASING' % _TV_FORMATS, 3600),
    'upcoming': ('sort: POPULARITY_DESC, format_in: %s, status: NOT_YET_RELEASED' % _TV_FORMATS, 6 * 3600),
    'top':      ('sort: SCORE_DESC, format_in: %s, popularity_greater: 60000' % _TV_FORMATS, 12 * 3600),
    'movies':   ('sort: POPULARITY_DESC, format: MOVIE', 6 * 3600),
    'newmovies': ('sort: START_DATE_DESC, format: MOVIE, status_in: [FINISHED, RELEASING], popularity_greater: 8000', 6 * 3600),
}


def _season_now():
    d = datetime.date.today()
    return ('WINTER', 'SPRING', 'SUMMER', 'FALL')[(d.month - 1) // 3], d.year


def _next_season():
    s, y = _season_now()
    order = ('WINTER', 'SPRING', 'SUMMER', 'FALL')
    i = order.index(s) + 1
    return (order[i], y) if i < 4 else ('WINTER', y + 1)


def _post(query):
    try:
        r = requests.post(_API, json={'query': query}, headers={'Accept': 'application/json', 'Content-Type': 'application/json'},
                          timeout=12)
        r.raise_for_status()
        return ((r.json() or {}).get('data') or {}).get('Page', {}).get('media') or []
    except Exception as e:
        xbmc.log('[Starfleet/Anime] AniList request failed: %s' % e, xbmc.LOGWARNING)
        return []


def _esc(s):
    return (s or '').replace('\\', ' ').replace('"', ' ')


def _page_query(args, page, per_page=PAGE_SIZE):
    return 'query { Page(page: %d, perPage: %d) { media(type: ANIME, isAdult: false, %s) { %s } } }' % (page, per_page, args, _FIELDS)


# ── AniList entry -> TMDB title ───────────────────────────────────────────────

def _norm(s):
    s = re.sub(r"[’'`]", '', (s or '').lower())
    return re.sub(r'\s+', ' ', re.sub(r'[^a-z0-9]+', ' ', s)).strip()


_SEQUEL = re.compile(r'(?:\s*[:\-–]\s*)?(?:\b(?:the\s+)?(?:final|\d+(?:st|nd|rd|th)|second|third|fourth|fifth)\s+season\b|\bseason\s*\d+\b|'
                     r'\bpart\s*\d+\b|\bcour\s*\d+\b|\bs\d\b|\b(?:ii|iii|iv|v)\b$|\s\d$).*$', re.I)


def _name_variants(e):
    t = e.get('title') or {}
    out = []
    for n in (t.get('english'), t.get('romaji')):
        if n:
            out.append(n)
            base = _SEQUEL.sub('', n).strip(' :-')
            if base and base != n:
                out.append(base)
            sub = re.split(r'\s*[:\-–]\s*', n)[0].strip()
            if len(sub) > 3 and sub not in out:
                out.append(sub)
    seen, res = set(), []
    for n in out:
        k = _norm(n)
        if k and k not in seen:
            seen.add(k)
            res.append(n)
    return res


def _tmdb_for(e):
    """The TMDB search hit (raw dict) for an AniList entry, or None. Cached for a month (a day when there was no hit)."""
    is_movie = (e.get('format') or '') == 'MOVIE'
    ck = 'anime_tmdb_v1_%s' % e.get('id')
    cached = _cache.get(ck)
    if cached is not None:
        return cached or None
    year = ((e.get('startDate') or {}).get('year') or e.get('seasonYear') or 0)
    best, best_score = None, 0
    for name in _name_variants(e)[:4]:
        try:
            data = _meta._tmdb_get('/search/movie' if is_movie else '/search/tv', {'query': name})
        except Exception:
            continue
        for r in (data.get('results') or [])[:8]:
            if r.get('original_language') != 'ja' and 'JP' not in (r.get('origin_country') or []):
                continue
            cand = [_norm(r.get('title') or r.get('name')), _norm(r.get('original_title') or r.get('original_name'))]
            score = 1
            nn = _norm(name)
            if nn in cand:
                score += 4
            elif any(nn and (nn in c or c in nn) for c in cand if c):
                score += 2
            ry = int(str(r.get('release_date') or r.get('first_air_date') or '0')[:4] or 0)
            if year and ry and abs(ry - year) <= 1:
                score += 2
            if is_movie and (r.get('genre_ids') and 16 in r['genre_ids']):
                score += 1
            if not is_movie and (r.get('genre_ids') and 16 in r['genre_ids']):
                score += 2
            score += min(float(r.get('popularity') or 0), 100) / 100.0
            if score > best_score:
                best, best_score = r, score
        if best and best_score >= 6:
            break
    ok = best is not None and best_score >= 3
    _cache.set(ck, best if ok else {}, 30 * 86400 if ok else 86400)
    return best if ok else None


def _plain(text):
    text = re.sub(r'<br\s*/?>', '\n', text or '', flags=re.I)
    return re.sub(r'<[^>]+>', '', text).strip()


def _item(e, hit):
    """TMDB-shaped dict for an AniList entry and its TMDB hit."""
    t = e.get('title') or {}
    is_movie = (e.get('format') or '') == 'MOVIE'
    title = t.get('english') or t.get('romaji') or ''
    cover = (e.get('coverImage') or {})
    poster = cover.get('extraLarge') or cover.get('large') or ''
    year = (e.get('startDate') or {}).get('year') or e.get('seasonYear') or ''
    back = _meta.fanart(hit.get('backdrop_path') or '') if hit.get('backdrop_path') else (e.get('bannerImage') or poster)
    score = e.get('averageScore')
    trailer = e.get('trailer') or {}
    return {
        'tmdb_id':   str(hit.get('id', '')),
        'title':     title,
        'year':      str(year),
        'first_air_date': str(hit.get('first_air_date') or hit.get('release_date') or ''),
        'rating':    round((score or 0) / 10.0, 1),
        'thumb':     poster or _meta.poster(hit.get('poster_path') or ''),
        'fanart':    back,
        'overview':  _plain(e.get('description')) or hit.get('overview', ''),
        'genre_ids': hit.get('genre_ids', []),
        'media_type': 'movie' if is_movie else 'tv',
        'anilist_id': e.get('id'),
        'episodes':  e.get('episodes') or 0,
        'next_episode': (e.get('nextAiringEpisode') or {}).get('episode') or 0,
        'youtube_id': trailer.get('id') if (trailer.get('site') or '').lower() == 'youtube' else '',
    }


def _link(entries):
    """AniList entries -> TMDB-shaped items (parallel TMDB lookups, duplicates of one TMDB title dropped, order kept)."""
    if not entries:
        return []
    with ThreadPoolExecutor(max_workers=6) as pool:
        hits = list(pool.map(_tmdb_for, entries))
    out, seen = [], set()
    for e, h in zip(entries, hits):
        if not h or str(h.get('id')) in seen:
            continue
        seen.add(str(h.get('id')))
        out.append(_item(e, h))
    return out


# ── lists ──────────────────────────────────────────────────────────────────

def _cached_list(ck, ttl, args, page):
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    items = _link(_post(_page_query(args, page)))
    if items:
        _cache.set(ck, items, ttl)
    return items


def get_list(kind, page=1):
    """kind: trending | popular (this season) | airing | upcoming (next season) | top | movies | newmovies."""
    if kind == 'popular':
        s, y = _season_now()
        args, ttl = 'sort: POPULARITY_DESC, format_in: %s, season: %s, seasonYear: %d' % (_TV_FORMATS, s, y), 6 * 3600
    elif kind == 'upcoming':
        s, y = _next_season()
        args, ttl = 'sort: POPULARITY_DESC, format_in: %s, season: %s, seasonYear: %d' % (_TV_FORMATS, s, y), 6 * 3600
    elif kind in _KINDS:
        args, ttl = _KINDS[kind]
    else:
        return []
    return _cached_list('anime_list_v1_%s_%d_%s' % (kind, page, datetime.date.today().isoformat() if kind == 'popular' else ''),
                        ttl, args, page)


def get_by_genre(genre, page=1):
    return _cached_list('anime_genre_v1_%s_%d' % (genre, page), 6 * 3600,
                        'sort: POPULARITY_DESC, format_in: %s, genre: "%s"' % (_TV_FORMATS, _esc(genre)), page)


def search(query, page=1):
    q = _esc(query).strip()
    if not q:
        return []
    return _cached_list('anime_search_v1_%s_%d' % (_norm(q), page), 3600,
                        'sort: SEARCH_MATCH, search: "%s", format_in: [TV, TV_SHORT, ONA, MOVIE]' % q, page)


def get_rows(per_row=PAGE_SIZE):
    """The four Home rows: Trending, Popular This Season, Airing Now, Top Rated."""
    with ThreadPoolExecutor(max_workers=4) as pool:
        futs = [pool.submit(get_list, k) for k in ('trending', 'popular', 'airing', 'top')]
        out = []
        for f in futs:
            try:
                out.append((f.result(timeout=40) or [])[:per_row])
            except Exception:
                out.append([])
    return out
