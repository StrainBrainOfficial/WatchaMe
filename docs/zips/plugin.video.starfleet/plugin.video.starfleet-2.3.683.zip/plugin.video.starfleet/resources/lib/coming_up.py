# -*- coding: utf-8 -*-
"""
resources/lib/coming_up.py

"Coming up": one calendar page for the active profile, in local time, built from what the viewer already follows (tonight.py
supplies the pieces) with a longer look-ahead:

  * ready        the next episode of every show being watched that is out now (continue_watching.py, which folds in a paired
                 SIMKL / Trakt account) - choosing it plays it on Just Play
  * episodes     the next episode of those shows that is still to come in the next 14 days, by air date
  * anime        anime episodes airing in the next 48 hours (paired SIMKL account), at AniList's exact time
  * games        the followed teams' live games and next games in the next 7 days (My Teams)
  * movies       the most talked-about theatrical releases of the next 30 days (TMDB)

build() returns plain dicts in display order, each with 'section' / 'section_title'. coming_up() is the directory page.
"""
import time

import xbmc

_ORDER = {'live': 0, 'today': 1, 'ready': 2, 'tomorrow': 3, 'later': 4, 'movies': 5}
_TITLES = {'live': 'LIVE NOW', 'today': 'TODAY', 'ready': 'READY TO WATCH', 'tomorrow': 'TOMORROW', 'later': 'LATER', 'movies': 'IN CINEMAS SOON'}


def _log(msg):
    xbmc.log('[Starfleet/ComingUp] %s' % msg, xbmc.LOGINFO)


def _movies(now, days=30, limit=12):
    out = []
    try:
        from resources.lib import metadata as _md
        today = time.strftime('%Y-%m-%d', time.localtime(now))
        end = time.strftime('%Y-%m-%d', time.localtime(now + days * 86400))
        data = _md._tmdb_get('/discover/movie', {'primary_release_date.gte': today, 'primary_release_date.lte': end,
                                                'sort_by': 'popularity.desc', 'include_adult': 'false', 'region': 'US',
                                                'with_release_type': '2|3'}).get('results') or []
        for m in data[:limit]:
            slim = _md._slim_movie(m)
            date = slim.get('release_date', '')
            try:                                           # integers, not strptime: that call fails inside Kodi on Fire TV
                y, mo, d = [int(x) for x in date[:10].split('-')]
                ts = time.mktime((y, mo, d, 12, 0, 0, 0, 0, -1))
            except (ValueError, OverflowError):
                continue
            out.append({'kind': 'movie', 'section': 'movies', 'sort': ts, 'title': slim['title'], 'tmdb_id': slim['tmdb_id'],
                        'year': slim['year'], 'thumb': slim['thumb'], 'fanart': slim['fanart'],
                        'row_label': '[COLOR yellow]%s[/COLOR]  %s' % (time.strftime('%a %b %d', time.localtime(ts)), slim['title']),
                        'overview': '%s\n\n%s' % (time.strftime('%A %B %d', time.localtime(ts)), slim.get('overview', ''))})
    except Exception as e:
        _log('movies: %s' % e)
    return out


_cache = {'t': 0.0, 'pid': None, 'rows': None}


def build(now=None):
    from resources.lib import tonight as _tn
    from resources.lib import profiles as _profiles
    pid = _profiles.active_id()
    if _cache['rows'] is not None and _cache['pid'] == pid and time.time() - _cache['t'] < 600 and now is None:
        return [dict(r) for r in _cache['rows']]                      # re-opening the page within ten minutes is instant
    now = now or time.time()
    items = []
    for part in (lambda: _tn._games(now, 7 * 24), lambda: _tn._shows(now, 14), lambda: _tn._anime(now), lambda: _movies(now)):
        try:
            items += part()
        except Exception as e:
            _log('part failed: %s' % e)
    for it in items:                                       # later days read as the day's name, not just "later"
        if it['section'] == 'later':
            it['day'] = time.strftime('%a %b %d', time.localtime(it['sort']))
    items.sort(key=lambda x: (_ORDER.get(x['section'], 9), x['sort']))
    seen = set()
    for it in items:
        key = it['section'] if it['section'] != 'later' else 'later:%s' % it.get('day', '')
        if key not in seen:
            seen.add(key)
            it['section_title'] = it.get('day', '').upper() if it['section'] == 'later' else _TITLES.get(it['section'], '')
    _cache.update({'t': time.time(), 'pid': pid, 'rows': [dict(r) for r in items]})
    return items


# ── the page ────────────────────────────────────────────────────────────────

def coming_up(handle, build_url):
    import xbmcgui
    import xbmcplugin
    from urllib.parse import quote
    xbmcplugin.setPluginCategory(handle, '📅 Coming up')
    xbmcplugin.setContent(handle, 'videos')
    dlg = xbmcgui.DialogProgressBG()
    dlg.create('Starfleet', 'Building your calendar...')
    try:
        rows = build()
    finally:
        dlg.close()
    if not rows:
        xbmcgui.Dialog().ok('Starfleet - Coming up', 'Nothing is coming up yet.\n\nWatch a show, pair SIMKL or Trakt (Settings), or '
                            'follow a team (Sports > My Teams) and its schedule appears here.')
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return
    last = None
    for r in rows:
        if r.get('section_title') and r['section_title'] != last:
            last = r['section_title']
            head = xbmcgui.ListItem(label='[COLOR FF8899AA][B]%s[/B][/COLOR]' % last)
            head.setInfo('video', {'title': last, 'plot': ''})
            xbmcplugin.addDirectoryItem(handle, build_url({'action': 'coming_up'}), head, False)
        li = xbmcgui.ListItem(label=r['row_label'])
        li.setInfo('video', {'title': r.get('title', ''), 'plot': r.get('overview', '')})
        li.setArt({'thumb': r.get('thumb', ''), 'icon': r.get('thumb', ''), 'poster': r.get('thumb', ''), 'fanart': r.get('fanart', '')})
        kind = r.get('kind')
        if kind == 'episode':
            title = quote('%s S%02dE%02d' % (r['title'], int(r['season']), int(r['episode'])))
            url = build_url({'action': 'meta_ep_play', 'tmdb_id': r['tmdb_id'], 'season_num': r['season'], 'episode_num': r['episode'],
                             'title': title})
            li.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(handle, url, li, False)
        elif kind == 'game':
            ev = r['event']
            url = build_url({'action': 'sports_event_play', 'event_id': ev.get('id', ''), 'event_path': ev.get('path', ''),
                             'sport_slug': r['sport'], 'title': ev.get('match_title') or ev.get('title', ''),
                             'start': int(ev.get('start_ts') or 0)})
            li.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(handle, url, li, False)
        elif kind == 'movie':
            xbmcplugin.addDirectoryItem(handle, build_url({'action': 'meta_movie_detail', 'tmdb_id': r['tmdb_id']}), li, True)
        elif kind in ('upcoming', 'anime') and r.get('tmdb_id'):
            xbmcplugin.addDirectoryItem(handle, build_url({'action': 'meta_tv_show', 'tmdb_id': r['tmdb_id']}),
                                        li, True)
        else:
            xbmcplugin.addDirectoryItem(handle, build_url({'action': 'coming_up'}), li, False)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)
