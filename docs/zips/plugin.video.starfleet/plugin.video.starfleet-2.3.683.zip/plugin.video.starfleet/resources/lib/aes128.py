# -*- coding: utf-8 -*-
"""Shared helper; the one copy lives in script.module.starfleetscrapers (starfleetscrapers.core.aes128)."""
import sys

from starfleetscrapers.core import aes128 as _impl

sys.modules[__name__] = _impl
