# -*- coding: utf-8 -*-
"""Shared helper; the one copy lives in script.module.starfleetscrapers (starfleetscrapers.core.tracker_list)."""
import sys

from starfleetscrapers.core import tracker_list as _impl

sys.modules[__name__] = _impl
