# -*- coding: utf-8 -*-
"""The addon's one entry point for turning a host / player address into a playable stream.

Drop-in for `import resolveurl` (HostedMediaFile and resolve): Starfleet's own resolver
(script.module.starfleetresolve) goes first, and ResolveURL (script.module.resolveurl) is the fallback for every
host it knows, so nothing that worked through ResolveURL stops working. If only one of the two is installed, that
one is used alone."""
try:
    import starfleetresolve as _sfr
except Exception:
    _sfr = None

try:
    import resolveurl as _ru
except Exception:
    _ru = None

if _sfr is None and _ru is None:
    raise ImportError('neither script.module.starfleetresolve nor script.module.resolveurl is installed')

if _sfr is not None:
    try:
        from resources.lib import sf_debrid as _sfd      # keys typed in Settings reach the resolver's debrid accounts
        _sfd.sync()
    except Exception:
        pass


class HostedMediaFile(object):
    def __init__(self, url='', *args, **kwargs):
        self.url = url or kwargs.get('url', '')
        self._ru = None
        if _ru is not None:
            try:
                self._ru = _ru.HostedMediaFile(self.url, *args, **kwargs)
            except Exception:
                self._ru = None

    def valid_url(self):
        if _sfr is not None:
            try:
                if _sfr.valid_url(self.url):
                    return True
            except Exception:
                pass
        if self._ru is not None:
            try:
                return bool(self._ru.valid_url())
            except Exception:
                return False
        return False

    def resolve(self):
        if _sfr is not None:
            try:
                out = _sfr.resolve(self.url)
                if out:
                    return out
            except Exception:
                pass
        if self._ru is not None:
            # starfleetresolve already tried ResolveURL; this covers the case where it is not installed
            if _sfr is None:
                return self._ru.resolve()
        return False


def resolve(url):
    """resolveurl.resolve(url) look-alike: playable address, or False."""
    out = None
    if _sfr is not None and str(url).startswith(('http://', 'https://')):
        try:
            out = _sfr.resolve(url)
        except Exception:
            out = None
    if not out and _ru is not None:
        try:
            out = _ru.resolve(url)
        except Exception:
            out = None
    return out or False
