# -*- coding: utf-8 -*-
"""Anime section as a plain Kodi directory (the same menus the custom Home window offers): Trending, Popular This Season, Airing Now,
Upcoming, Top Rated, Anime Movies, Browse by Genre, Search. Shows open the usual TMDB season / episode pages, films the usual movie
page, so playback, favorites, watched marks and the source picker are shared with TV Shows and Movies."""
import xbmc
import xbmcgui
import xbmcplugin

from resources.lib import anime_meta
from resources.lib import metadata_router as _mr
from resources.lib.gui import progress_dialog as _pdlg

_LISTS = (
    ('trending', 'Trending', 'What anime fans are watching right now'),
    ('popular',  'Popular This Season', 'The most popular anime of the current season'),
    ('airing',   'Airing Now', 'Anime with new episodes coming out'),
    ('upcoming', 'Upcoming Next Season', 'Anime starting next season'),
    ('top',      'Top Rated', 'The highest rated anime of all time'),
    ('movies',   'Anime Movies', 'Popular anime films'),
    ('newmovies', 'New Anime Movies', 'Recent anime films'),
)
_TITLES = {k: t for k, t, _p in _LISTS}


def anime_menu(handle, build_url):
    xbmcplugin.setPluginCategory(handle, 'Anime')
    xbmcplugin.setContent(handle, 'files')
    for kind, label, plot in _LISTS:
        _mr._add_dir(handle, build_url, label, {'action': 'anime_list', 'kind': kind, 'page': 1}, plot=plot)
    _mr._add_dir(handle, build_url, 'Browse by Genre', {'action': 'anime_genres'}, plot='Anime by genre')
    _mr._add_dir(handle, build_url, 'Search', {'action': 'anime_search'}, plot='Search anime by title')
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def _render(handle, build_url, items):
    shows = [i for i in items if i.get('media_type') != 'movie']
    films = [i for i in items if i.get('media_type') == 'movie']
    xbmcplugin.setContent(handle, 'tvshows' if shows and not films else 'movies' if films and not shows else 'videos')
    if shows:
        _mr._render_tv_list(handle, build_url, shows)
    if films:
        _mr._render_movie_list(handle, build_url, films)


def _load(fn, msg):
    dlg = _pdlg.DialogProgress()
    dlg.create('Starfleet', msg)
    try:
        return fn()
    finally:
        dlg.close()


def anime_list(handle, build_url, kind, page=1):
    xbmcplugin.setPluginCategory(handle, 'Anime - %s' % _TITLES.get(kind, kind))
    items = _load(lambda: anime_meta.get_list(kind, page), 'Loading anime...')
    _render(handle, build_url, items)
    if len(items) >= 20:
        _mr._next_page(handle, build_url, 'anime_list', page, {'kind': kind})
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def anime_genres(handle, build_url):
    xbmcplugin.setPluginCategory(handle, 'Anime - Genres')
    xbmcplugin.setContent(handle, 'files')
    for g in anime_meta.GENRES:
        _mr._add_dir(handle, build_url, g, {'action': 'anime_by_genre', 'genre': g, 'page': 1})
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def anime_by_genre(handle, build_url, genre, page=1):
    xbmcplugin.setPluginCategory(handle, 'Anime - %s' % genre)
    items = _load(lambda: anime_meta.get_by_genre(genre, page), 'Loading anime...')
    _render(handle, build_url, items)
    if len(items) >= 20:
        _mr._next_page(handle, build_url, 'anime_by_genre', page, {'genre': genre})
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)


def anime_search(handle, build_url):
    kb = xbmc.Keyboard('', 'Search Anime')
    kb.doModal()
    if not kb.isConfirmed() or not kb.getText().strip():
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return
    query = kb.getText().strip()
    xbmcplugin.setPluginCategory(handle, 'Anime: %s' % query)
    items = _load(lambda: anime_meta.search(query), 'Searching...')
    if not items:
        xbmcgui.Dialog().notification('Anime', 'No results for: %s' % query, xbmcgui.NOTIFICATION_INFO)
        return
    _render(handle, build_url, items)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)
