# -*- coding: utf-8 -*-
"""The programme-guide builders live in script.module.starfleetscrapers (starfleetscrapers.live.epg_scrapers). This file only keeps
the old import name working: importing it gives you that module itself."""
import sys

from resources.lib import _scrapers_bridge  # noqa: F401  (registers what the scrapers need from this add-on)
from starfleetscrapers.live import epg_scrapers as _impl

sys.modules[__name__] = _impl
