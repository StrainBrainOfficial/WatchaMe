# -*- coding: utf-8 -*-
"""
resources/lib/myevents_alerts.py

Event reminders, run from the background service (service.py): when a reminder's time comes (its lead before the start, and again at
the start when it was set to be early), Kodi asks "<event> starts now. Watch?" and, when the answer is yes, starts the event on
Just Play (the best stream, the next one when it fails). While something is playing it shows a notice instead of a question.

Nothing is read from the network: the reminders are in my_events.json. Each stage of a reminder fires once; one that is more than
four hours past its start (Kodi was closed) is dropped without a popup.
"""
import threading
import time

import xbmc
import xbmcaddon
import xbmcgui

POLL_MAX = 300
POLL_MIN = 15
POLL_OFF = 120
LATE = 4 * 3600                       # a stage this long past its time is not worth a popup any more


def _log(msg):
    xbmc.log('[Starfleet/MyEventsAlerts] %s' % msg, xbmc.LOGINFO)


def _setting(key, default='true'):
    try:
        v = xbmcaddon.Addon('plugin.video.starfleet').getSetting(key)
        return v if v != '' else default
    except Exception:
        return default


def _stages(r):
    """[(stage number, fire time)]: stage 0 at the lead before the start, stage 1 at the start (only when the lead is not 0)."""
    lead = int(r.get('lead') or 0)
    out = []
    if lead:
        out.append((0, r['start_ts'] - lead * 60))
    out.append((1, r['start_ts']))
    return out


def _watch(r):
    from urllib.parse import quote
    url = ('plugin://plugin.video.starfleet/?action=sports_event_play&event_id=%s&event_path=&sport_slug=%s&title=%s&start=%s&auto=1'
           % (quote(r['id']), r.get('stream_slug') or r.get('sport', ''), quote(r['title']), int(r['start_ts'])))
    li = xbmcgui.ListItem(r['title'])
    li.setProperty('IsPlayable', 'true')
    xbmc.Player().play(url, li)


def _message(r, stage):
    from resources.lib import my_events as _me
    when = _me.when_text(r['start_ts'], r.get('approx'))
    if stage == 0 and int(r.get('lead') or 0):
        return '%s starts %s.' % (r['title'], _me.starts_in(r['start_ts']) if not r.get('approx') else 'later today (%s)' % when)
    return '%s is on now (%s).' % (r['title'], when)


def _fire(r, stage):
    heading = 'Starfleet - Reminder'
    text = _message(r, stage)
    _log('%s: %s' % (r['id'], text))
    try:
        playing = xbmc.Player().isPlaying()
    except Exception:
        playing = False
    if stage == 1 and not playing and _setting('myevents_alert_prompt') != 'false':
        def _ask():
            try:
                if xbmcgui.Dialog().yesno(heading, text + '\n\nWatch now?', nolabel='Not now', yeslabel='Watch', autoclose=45000):
                    _watch(r)
            except Exception as e:
                _log('prompt failed: %s' % e)
                xbmcgui.Dialog().notification(heading, text, xbmcgui.NOTIFICATION_INFO, 8000)
        threading.Thread(target=_ask, daemon=True).start()
        return
    xbmcgui.Dialog().notification(heading, text, xbmcgui.NOTIFICATION_INFO, 8000)


def tick(now=None):
    """One pass over the reminders; returns the seconds to wait before the next one."""
    if _setting('myevents_alerts') == 'false':
        return POLL_OFF
    from resources.lib import my_events as _me
    now = now or time.time()
    rs = _me.reminders()
    if not rs:
        return POLL_OFF
    nxt, fired = None, False
    for r in rs:
        for stage, at in _stages(r):
            if stage in r.get('sent', []):
                continue
            if now >= at:
                if now - at >= LATE:
                    _me.mark_sent(r['id'], stage)          # Kodi was closed at the time: no popup for it any more
                elif not fired:                            # one popup per pass; the others come on the next one
                    fired = True
                    _me.mark_sent(r['id'], stage)
                    _fire(r, stage)
                else:
                    nxt = now + POLL_MIN
                continue
            nxt = at if nxt is None else min(nxt, at)
    if nxt is None:
        return POLL_OFF
    return max(POLL_MIN, min(POLL_MAX, int(nxt - time.time()) + 1))
