# -*- coding: utf-8 -*-
"""
resources/lib/holidays.py

Seasonal sections for the Movies selector: a holiday section that appears two weeks before the holiday (a few weeks for
Christmas) and is gone the day after, filled from TMDB's own keyword lists ("halloween", "christmas", ...).

    active(today=None)        -> [holiday, ...]  the sections to show today, the nearest holiday first
    movies_fetch(key)         -> fn(page=1) -> slim movie dicts (what the selector's category window calls)
    window_text(h, today)     -> short text for the section, e.g. "Halloween - 9 days to go"

The calendar needs no network. The movies come from TMDB discover (keywords looked up once and kept for a month). Switch the
whole feature off with Settings > Metadata > "Seasonal sections". Testing: set the environment variable STARFLEET_HOLIDAY_DATE
(YYYY-MM-DD) to pretend it is that day.
"""
import datetime
import os

import xbmc

_MONTH_TTL = 30 * 86400


def _log(msg):
    xbmc.log('[Starfleet/Holidays] %s' % msg, xbmc.LOGINFO)


# ── the calendar ────────────────────────────────────────────────────────────

def easter(year):
    """Western Easter Sunday (the anonymous Gregorian algorithm)."""
    a, b, c = year % 19, year // 100, year % 100
    d, e = b // 4, b % 4
    f = (b + 8) // 25
    g = (b - f + 1) // 3
    h = (19 * a + b - d - g + 15) % 30
    i, k = c // 4, c % 4
    l = (32 + 2 * e + 2 * i - h - k) % 7
    m = (a + 11 * h + 22 * l) // 451
    month = (h + l - 7 * m + 114) // 31
    day = (h + l - 7 * m + 114) % 31 + 1
    return datetime.date(year, month, day)


def nth_weekday(year, month, weekday, n):
    """The n-th `weekday` (Monday = 0) of a month."""
    first = datetime.date(year, month, 1)
    return first + datetime.timedelta(days=(weekday - first.weekday()) % 7 + 7 * (n - 1))


# before / after = days the section shows before / after the day itself ("after 0": gone the next day)
HOLIDAYS = [
    {'key': 'halloween', 'label': 'Halloween', 'icon': 'DefaultGenre.png', 'date': lambda y: datetime.date(y, 10, 31), 'before': 14, 'after': 0,
     'queries': [{'kw': ['halloween'], 'votes': 8}, {'genres': [27], 'votes': 600}]},
    {'key': 'christmas', 'label': 'Christmas', 'icon': 'DefaultGenre.png', 'date': lambda y: datetime.date(y, 12, 25), 'before': 24, 'after': 1,
     'queries': [{'kw': ['christmas', 'santa claus'], 'votes': 8}]},
    {'key': 'thanksgiving', 'label': 'Thanksgiving', 'icon': 'DefaultGenre.png', 'date': lambda y: nth_weekday(y, 11, 3, 4), 'before': 14, 'after': 0,
     'queries': [{'kw': ['thanksgiving'], 'votes': 5}]},
    {'key': 'valentines', 'label': "Valentine's Day", 'icon': 'DefaultGenre.png', 'date': lambda y: datetime.date(y, 2, 14), 'before': 14, 'after': 0,
     'queries': [{'kw': ["valentine's day"], 'votes': 5}, {'genres': [10749], 'votes': 1200}]},
    {'key': 'stpatricks', 'label': "St. Patrick's Day", 'icon': 'DefaultGenre.png', 'date': lambda y: datetime.date(y, 3, 17), 'before': 14, 'after': 0,
     'queries': [{'kw': ["st. patrick's day", 'leprechaun'], 'votes': 5}]},
    {'key': 'easter', 'label': 'Easter', 'icon': 'DefaultGenre.png', 'date': easter, 'before': 14, 'after': 1,
     'queries': [{'kw': ['easter', 'easter bunny'], 'votes': 5}]},
]


def _today():
    v = os.environ.get('STARFLEET_HOLIDAY_DATE')
    if v:
        try:
            y, m, d = [int(x) for x in v.split('-')]
            return datetime.date(y, m, d)
        except ValueError:
            pass
    return datetime.date.today()


def _enabled():
    try:
        import xbmcaddon
        return xbmcaddon.Addon('plugin.video.starfleet').getSetting('seasonal_sections') != 'false'
    except Exception:
        return True


def active(today=None):
    """The holidays whose window includes `today`, the nearest one first (an empty list when the setting is off)."""
    if not _enabled():
        return []
    today = today or _today()
    out = []
    for h in HOLIDAYS:
        for year in (today.year - 1, today.year, today.year + 1):      # a window can reach across New Year
            day = h['date'](year)
            if day - datetime.timedelta(days=h['before']) <= today <= day + datetime.timedelta(days=h['after']):
                out.append(dict(h, day=day, days_left=(day - today).days))
                break
    out.sort(key=lambda h: abs(h['days_left']))
    return out


ICONS = {'halloween': '\U0001F383', 'christmas': '\U0001F384', 'thanksgiving': '\U0001F983', 'valentines': '\U0001F498',
         'stpatricks': '\U0001F340', 'easter': '\U0001F423'}


def by_key(key):
    return next((h for h in HOLIDAYS if h['key'] == key), None)


def window_text(h, today=None):
    left = h.get('days_left')
    if left is None:
        return h['label']
    if left > 1:
        return '%s - %d days to go' % (h['label'], left)
    return {1: '%s - tomorrow', 0: '%s - today'}.get(left, '%s') % h['label']


# ── the movies ──────────────────────────────────────────────────────────────

def _keyword_ids(names):
    """TMDB keyword ids for the names, looked up once and kept for a month."""
    from resources.lib import metadata as _md
    ids = []
    for name in names:
        ck = 'holiday_kw_%s' % name.lower().replace(' ', '_')
        got = _md._cache.get(ck)
        if got is None:
            got = ''
            try:
                res = _md._tmdb_get('/search/keyword', {'query': name}).get('results') or []
                exact = [r for r in res if (r.get('name') or '').lower() == name.lower()]
                pick = (exact or res or [None])[0]
                got = str(pick['id']) if pick else ''
            except Exception as e:
                _log('keyword %r: %s' % (name, e))
                continue
            _md._cache.set(ck, got, _MONTH_TTL)
        if got:
            ids.append(got)
    return ids


def movies_fetch(key):
    """fn(page=1) -> the section's movies (slim dicts), most popular first, each film once."""
    h = by_key(key)

    def fetch(page=1):
        if not h:
            return []
        from resources.lib import metadata as _md
        ck = 'holiday_movies_%s_%d' % (key, page)
        cached = _md._cache.get(ck)
        if cached is not None:
            return cached
        out, seen = [], set()
        for q in h['queries']:
            # a keyword list holds the famous films and the odd one with a Christmas scene: the most voted first
            d = {'sort_by': 'vote_count.desc' if q.get('kw') else 'popularity.desc', 'include_adult': 'false', 'page': page,
                 'vote_count.gte': q.get('votes', 10)}
            if q.get('kw'):
                ids = _keyword_ids(q['kw'])
                if not ids:
                    continue
                d['with_keywords'] = '|'.join(ids)                       # "|" = any of them
            if q.get('genres'):
                d['with_genres'] = ','.join(str(g) for g in q['genres'])
            try:
                for m in _md._tmdb_get('/discover/movie', d).get('results') or []:
                    if m.get('id') not in seen:
                        seen.add(m.get('id'))
                        out.append(_md._slim_movie(m))
            except Exception as e:
                _log('%s query failed: %s' % (key, e))
        _md._cache.set(ck, out, 6 * 3600 if out else 300)
        return out
    return fetch


# ── the native Movies menu / page (plugin:// directory) ─────────────────────

def movies_holiday(handle, build_url, key, page=1):
    import xbmcgui
    import xbmcplugin
    from resources.lib import metadata_router as _mr
    page = int(page or 1)
    h = by_key(key)
    xbmcplugin.setPluginCategory(handle, h['label'] if h else 'Seasonal')
    xbmcplugin.setContent(handle, 'movies')
    films = movies_fetch(key)(page)
    if not films:
        xbmcgui.Dialog().notification('Starfleet', 'No films found for %s' % (h['label'] if h else key), xbmcgui.NOTIFICATION_INFO)
        return
    _mr._render_movie_list(handle, build_url, films)
    _mr._prewarm_movie_details(films)
    if len(films) >= 15:
        _mr._add_dir(handle, build_url, 'Next page', {'action': 'meta_movies_holiday', 'key': key, 'page': page + 1})
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)
