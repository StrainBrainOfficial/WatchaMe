# -*- coding: utf-8 -*-
"""
resources/lib/loading_card.py

The loading card, like the HazMat TV app's: while the chosen video is loading (from the moment the player opens the stream until the first
picture) a dark screen shows the title's poster, its name and its main cast.

stage() runs when the sources are searched: it looks the title up (the cached TMDB detail) and keeps the card text in a home-window
property. The service's CardPlayer (service.py) shows the card when a video starts to load and closes it on the first picture, when
playback stops or fails, or after two minutes at the latest. A card that nobody played within a quarter of an hour is dropped.
"""
import json
import threading
import time

import xbmc
import xbmcgui

_PROP = 'starfleet.loadcard'
_MAX_AGE = 900
_ID_POSTER, _ID_CAST, _ID_TITLE = 30, 31, 32


def _home():
    return xbmcgui.Window(10000)


def stage(media_type, tmdb_id, title=''):
    """Prepares the card for the video that is about to be chosen (from a worker thread, so a search never waits for it)."""
    if not tmdb_id:
        return

    def _go():
        try:
            from resources.lib import metadata as _md
            d = (_md.get_tv_detail(tmdb_id) if media_type in ('tv', 'episode', 'show') else _md.get_movie_detail(tmdb_id)) or {}
            names = [c.get('name') for c in (d.get('cast') or [])[:5] if c.get('name')]
            _home().setProperty(_PROP, json.dumps({'t': time.time(), 'poster': d.get('thumb') or '', 'title': title or d.get('title') or '',
                                                   'cast': ('With ' + ', '.join(names)) if names else ''}))
        except Exception as e:
            xbmc.log('[Starfleet] loading card: %s' % e, xbmc.LOGINFO)
    threading.Thread(target=_go, daemon=True, name='starfleet-loading-card').start()


def _take():
    raw = _home().getProperty(_PROP)
    if not raw:
        return None
    _home().clearProperty(_PROP)
    try:
        card = json.loads(raw)
    except ValueError:
        return None
    return card if time.time() - card.get('t', 0) < _MAX_AGE else None


class CardDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self._card = {}
        super(CardDialog, self).__init__(*args, **kwargs)

    def onInit(self):
        try:
            if self._card.get('poster'):
                self.getControl(_ID_POSTER).setImage(self._card['poster'], False)
            self.getControl(_ID_TITLE).setLabel(self._card.get('title', ''))
            self.getControl(_ID_CAST).setLabel(self._card.get('cast', ''))
        except Exception as e:
            xbmc.log('[Starfleet/LoadingCard] onInit: %s' % e, xbmc.LOGWARNING)

    def onAction(self, action):
        if action.getId() in (xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK):
            self.close()
            xbmc.executebuiltin('PlayerControl(Stop)')


class CardPlayer(xbmc.Player):
    def __init__(self):
        xbmc.Player.__init__(self)
        self._dlg = None

    def onPlayBackStarted(self):
        try:
            if self._dlg or not self.isPlayingVideo():
                return
            card = _take()
            if not card:
                return
            import xbmcaddon
            path = xbmcaddon.Addon('plugin.video.starfleet').getAddonInfo('path')
            self._dlg = CardDialog('Starfleet-LoadCard.xml', path, 'Default', '1080i')
            self._dlg._card = card
            self._dlg.show()
            dlg = self._dlg
            threading.Timer(120, lambda: self._close(dlg)).start()
        except Exception as e:
            xbmc.log('[Starfleet/LoadingCard] show: %s' % e, xbmc.LOGWARNING)

    def _close(self, only=None):
        dlg = self._dlg
        if not dlg or (only is not None and dlg is not only):
            return
        self._dlg = None
        try:
            dlg.close()
        except Exception:
            pass

    def onAVStarted(self):
        self._close()

    def onPlayBackStopped(self):
        self._close()

    def onPlayBackEnded(self):
        self._close()

    def onPlayBackError(self):
        self._close()
