# -*- coding: utf-8 -*-
"""
resources/lib/iptv_ui.py - the IPTV settings dialogs: add / test / edit / delete a provider (Xtream Codes, Stalker, M3U), refresh the TV guide,
manage categories (show, hide, rename, reorder). The engine is starfleetscrapers.iptv.catalog; this file is only the Kodi dialogs around it.
Opened from Settings > IPTV (actions iptv_manage / iptv_add / iptv_refresh_guide / iptv_categories in dispatcher.py).
"""
import threading

import xbmc
import xbmcgui

from resources.lib.gui import progress_dialog as _pdlg

KINDS = (('live', 'Live TV'), ('movie', 'Movies'), ('series', 'TV Shows'))
_TYPE_ORDER = ('xtream', 'stalker', 'm3u')


def _catalog():
    from starfleetscrapers.iptv import catalog
    return catalog


def has_providers():
    try:
        return bool(_catalog()._enabled())
    except Exception:
        return False


def _log(msg):
    xbmc.log('[Starfleet/IPTV] %s' % msg, xbmc.LOGINFO)


def _ask(heading, default='', hidden=False):
    """Text from the viewer; None when cancelled."""
    dlg = xbmcgui.Dialog()
    kw = {'option': xbmcgui.ALPHANUM_HIDE_INPUT} if hidden else {}
    val = dlg.input(heading, defaultt=default, type=xbmcgui.INPUT_ALPHANUM, **kw)
    return None if val == '' and not default else val


def _busy(message, fn):
    """Run fn() under a progress dialog and return its result."""
    pd = _pdlg.DialogProgress()
    pd.create('Starfleet', message)
    try:
        return fn()
    finally:
        pd.close()


# ── add / edit ──────────────────────────────────────────────────────────────────────────────────────────────────────────

def _form(existing=None):
    """Ask for a provider's details. -> provider dict, or None when cancelled. Blank answers keep the existing value when editing."""
    cat = _catalog()
    from starfleetscrapers.iptv import store
    p = dict(existing or {})
    if not p:
        labels = [store.TYPE_LABELS[t] for t in _TYPE_ORDER]
        i = xbmcgui.Dialog().select('IPTV provider type', labels)
        if i < 0:
            return None
        p['type'] = _TYPE_ORDER[i]
    t = p['type']
    name = _ask('Name for this provider', p.get('name', ''))
    if name is None:
        return None
    p['name'] = name or p.get('name') or store.TYPE_LABELS[t]
    if t == 'xtream':
        url = _ask('Server address (http://host:port) - or paste the whole get.php link', p.get('url', ''))
        if not url:
            return None
        p['url'] = url
        from starfleetscrapers.iptv.xtream import credentials_from_url
        base, u, pw = credentials_from_url(url)
        if u and pw:                                        # the link carried the login: no need to ask again
            p.update(url=base, username=u, password=pw)
        else:
            u = _ask('Username', p.get('username', ''))
            if not u:
                return None
            pw = _ask('Password', '', hidden=True)
            if pw is None and not p.get('password'):
                return None
            p.update(username=u, password=pw or p.get('password', ''))
    elif t == 'stalker':
        url = _ask('Portal address (http://host/c/ or http://host/stalker_portal/c/)', p.get('url', ''))
        if not url:
            return None
        mac = _ask('MAC address of your subscription (00:1A:79:xx:xx:xx)', p.get('mac', '00:1A:79:'))
        if not mac:
            return None
        p.update(url=url, mac=mac)
    else:
        url = _ask('Playlist address (http://...) or the path of an .m3u file', p.get('url', ''))
        if not url:
            return None
        p['url'] = url
    epg = _ask('TV guide address (XMLTV) - leave empty to use the provider\'s own', p.get('epg_url', ''))
    if epg is not None:
        p['epg_url'] = epg.strip()
    return p


def add_provider():
    cat = _catalog()
    p = _form()
    if not p:
        return None
    res = _busy('Checking the provider...', lambda: cat.test(p))
    xbmcgui.Dialog().ok('IPTV - %s' % p['name'], ('[B]Connected[/B]\n' if res['ok'] else '[B]Problem[/B]\n') + res['message'])
    if not res['ok'] and not xbmcgui.Dialog().yesno('IPTV', 'The check failed. Save this provider anyway?'):
        return None
    saved = cat.save_provider(p)
    _log('provider added: %s (%s)' % (saved['name'], saved['type']))
    _bg_guide(saved['id'])
    xbmcgui.Dialog().notification('Starfleet', 'IPTV provider saved', xbmcgui.NOTIFICATION_INFO, 3000)
    return saved


def edit_provider(p):
    cat = _catalog()
    new = _form(p)
    if not new:
        return
    cat.save_provider(new)
    xbmcgui.Dialog().notification('Starfleet', 'IPTV provider updated', xbmcgui.NOTIFICATION_INFO, 3000)
    _bg_guide(new['id'], force=True)


def _bg_guide(provider_id, force=False):
    """Load the guide in the background (it can be tens of MB)."""
    def _go():
        try:
            res = _catalog().refresh_epg(provider_id, force=force)
            _log('guide: %s' % res)
        except Exception as e:
            _log('guide error: %s' % e)
    threading.Thread(target=_go, daemon=True).start()


def refresh_guide(provider_id=None):
    cat = _catalog()
    if not cat._enabled():
        xbmcgui.Dialog().ok('IPTV', 'No IPTV provider yet. Add one in Settings > IPTV.')
        return
    res = _busy('Loading the TV guide...', lambda: cat.refresh_epg(provider_id, force=True))
    lines = []
    for pid, r in res.items():
        p = cat.get_provider(pid) or {}
        lines.append('%s: %s' % (p.get('name', pid), ('%d programmes' % r) if isinstance(r, int) else (r if r != 'none' else 'no guide address')))
    xbmcgui.Dialog().ok('IPTV TV guide', '\n'.join(lines) or 'Nothing to load')


# ── providers screen ────────────────────────────────────────────────────────────────────────────────────────────────────

def manage_providers():
    from starfleetscrapers.iptv import store
    cat = _catalog()
    dlg = xbmcgui.Dialog()
    while True:
        provs = cat.providers()
        rows = ['%s  [%s]%s' % (p.get('name'), store.TYPE_LABELS.get(p['type'], p['type']), '' if p.get('enabled', True) else '  (off)') for p in provs]
        adult = 'Adult-looking categories: %s' % ('hidden' if cat.adult_hidden() else 'shown')
        options = rows + ['+ Add provider', 'Refresh TV guide now', adult]
        i = dlg.select('IPTV providers', options)
        if i < 0:
            return
        if i < len(provs):
            _provider_menu(provs[i])
        elif i == len(provs):
            add_provider()
        elif i == len(provs) + 1:
            refresh_guide()
        else:
            cat.set_adult_hidden(not cat.adult_hidden())


def _provider_menu(p):
    cat = _catalog()
    dlg = xbmcgui.Dialog()
    on = p.get('enabled', True)
    options = ['Test connection', 'Manage categories', 'Refresh TV guide', 'Edit details', 'Switch off' if on else 'Switch on', 'Delete']
    i = dlg.select(p.get('name', 'Provider'), options)
    if i == 0:
        res = _busy('Checking the provider...', lambda: cat.test(p))
        extra = ''
        info = res.get('info') or {}
        if info.get('expires'):
            import time
            extra = '\nExpires: %s' % time.strftime('%Y-%m-%d', time.localtime(info['expires']))
        dlg.ok(p['name'], ('[B]Connected[/B]\n' if res['ok'] else '[B]Problem[/B]\n') + res['message'] + extra)
    elif i == 1:
        manage_categories(p)
    elif i == 2:
        refresh_guide(p['id'])
    elif i == 3:
        edit_provider(p)
    elif i == 4:
        cat.save_provider(dict(p, enabled=not on))
    elif i == 5 and dlg.yesno('Delete provider', 'Delete "%s" with its category choices and guide?' % p.get('name')):
        cat.delete_provider(p['id'])


# ── manage categories ──────────────────────────────────────────────────────────────────────────────────────────────────

def manage_categories(provider=None):
    cat = _catalog()
    dlg = xbmcgui.Dialog()
    if provider is None:
        provs = cat.providers()
        if not provs:
            dlg.ok('IPTV', 'No IPTV provider yet. Add one in Settings > IPTV.')
            return
        if len(provs) == 1:
            provider = provs[0]
        else:
            i = dlg.select('Manage categories - provider', [p.get('name') for p in provs])
            if i < 0:
                return
            provider = provs[i]
    k = dlg.select('Manage categories - %s' % provider.get('name'), [lbl for _k, lbl in KINDS])
    if k < 0:
        return
    kind, kind_label = KINDS[k]
    pid = provider['id']
    try:
        rows = _busy('Loading categories...', lambda: cat.manager_rows(pid, kind, refresh=True))
    except Exception as e:
        dlg.ok('IPTV', 'Could not load the categories (%s).' % type(e).__name__)
        return
    if not rows:
        dlg.ok('IPTV', 'This provider has no %s categories.' % kind_label)
        return
    pos = 0
    while True:
        rows = cat.manager_rows(pid, kind)
        shown = ['%s %s%s' % ('[ hidden ]' if r['hidden'] else '[  shown  ]', r['name'], ('   (was: %s)' % r['original']) if r['renamed'] else '') for r in rows]
        options = shown + ['Show all', 'Hide all', 'Reset to the provider\'s order and names']
        i = dlg.select('%s - %s' % (provider.get('name'), kind_label), options, preselect=min(pos, len(options) - 1))
        if i < 0:
            return
        pos = i
        if i == len(rows):
            cat.hide_all(pid, kind, False)
        elif i == len(rows) + 1:
            cat.hide_all(pid, kind, True)
        elif i == len(rows) + 2:
            cat.reset_categories(pid, kind)
        else:
            r = rows[i]
            j = dlg.select(r['name'], ['Show' if r['hidden'] else 'Hide', 'Rename', 'Move up', 'Move down', 'Move to top'])
            if j == 0:
                cat.set_hidden(pid, kind, r['id'], not r['hidden'])
            elif j == 1:
                n = dlg.input('New name (empty = the provider\'s own)', defaultt=r['name'], type=xbmcgui.INPUT_ALPHANUM)
                cat.set_name(pid, kind, r['id'], '' if n == r['original'] else n)
            elif j == 2:
                cat.move_category(pid, kind, r['id'], -1)
                pos = max(0, i - 1)
            elif j == 3:
                cat.move_category(pid, kind, r['id'], 1)
                pos = min(len(rows) - 1, i + 1)
            elif j == 4:
                cat.move_category(pid, kind, r['id'], -len(rows))
                pos = 0
