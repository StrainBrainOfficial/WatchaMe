# -*- coding: utf-8 -*-
"""Shared helper; the one copy lives in script.module.starfleetscrapers (starfleetscrapers.core.title_utils), so the add-on and the
scrapers use the same cache file / state."""
import sys

from resources.lib import _scrapers_bridge  # noqa: F401  (registers the host for the scrapers)
from starfleetscrapers.core import title_utils as _impl

sys.modules[__name__] = _impl
