# -*- coding: utf-8 -*-
"""
resources/lib/screen_time.py

Screen time of the active profile: a daily amount of watching and/or a bedtime (no watching from the bedtime hour until WAKE_HOUR). Set per
profile in Settings > Profiles > Edit. The service (service.py) runs ScreenPlayer, which counts the seconds a video plays for a profile that
has a limit and stops playback when the time is up; the Parent PIN can add 30 minutes for the day. Same rules as the HazMat TV app.
Kept on the device in screen_time.json (add-on data folder), per profile and day.
"""
import json
import os
import threading
import time
import xbmc
import xbmcgui

WAKE_HOUR = 7
DAILY_CHOICES = (0, 30, 45, 60, 90, 120, 180, 240)
BED_CHOICES = (-1, 19, 20, 21, 22, 23, 0)
_LOCK = threading.RLock()


def _log(msg):
    xbmc.log('[Starfleet/ScreenTime] %s' % msg, xbmc.LOGINFO)


def _path():
    from resources.lib import profiles as pf
    return os.path.join(pf.base_dir(), 'screen_time.json')


def _load():
    try:
        with open(_path(), 'r', encoding='utf-8') as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def _save(d):
    try:
        with open(_path(), 'w', encoding='utf-8') as f:
            json.dump(d, f)
    except Exception as e:
        _log('could not save: %s' % e)


def _day():
    return time.strftime('%Y%m%d')


def _active():
    from resources.lib import profiles as pf
    return pf.active() or {}


def daily_minutes(p):
    try:
        return max(0, int(p.get('daily_minutes') or 0))
    except (TypeError, ValueError):
        return 0


def bed_hour(p):
    try:
        return int(p.get('bed_hour', -1))
    except (TypeError, ValueError):
        return -1


def timed(p=None):
    p = p if p is not None else _active()
    return daily_minutes(p) > 0 or bed_hour(p) >= 0


def hour_label(h):
    if h == 0:
        return '12 AM'
    if h < 12:
        return '%d AM' % h
    return '12 PM' if h == 12 else '%d PM' % (h - 12)


def amount_label(m):
    if m % 60 == 0:
        return '%d h' % (m // 60)
    return '%d h %d min' % (m // 60, m % 60) if m > 60 else '%d min' % m


def summary(p):
    parts = []
    if daily_minutes(p) > 0:
        parts.append(amount_label(daily_minutes(p)) + ' a day')
    if bed_hour(p) >= 0:
        parts.append('bed ' + hour_label(bed_hour(p)))
    return ', '.join(parts)


def in_bedtime(bed, hour):
    if bed < 0:
        return False
    return (hour >= bed or hour < WAKE_HOUR) if bed > WAKE_HOUR else (bed <= hour < WAKE_HOUR)


def add_seconds(seconds):
    """Counts seconds of watching against today (only for a profile with a daily amount)."""
    p = _active()
    if daily_minutes(p) <= 0:
        return
    with _LOCK:
        d = _load()
        used = d.setdefault('used', {})
        k = '%s_%s' % (p.get('id'), _day())
        used[k] = int(used.get(k, 0)) + seconds
        today = _day()
        for key in [x for x in used if not x.endswith('_' + today)]:      # days gone by are not kept
            del used[key]
        _save(d)


def grant_minutes(minutes):
    """Lets the profile watch for more minutes whatever the daily amount or bedtime says (after the Parent PIN)."""
    p = _active()
    with _LOCK:
        d = _load()
        until = d.setdefault('until', {})
        until[p.get('id')] = max(time.time(), float(until.get(p.get('id'), 0))) + minutes * 60
        _save(d)


def minutes_left():
    p = _active()
    if daily_minutes(p) <= 0:
        return None
    used = int(_load().get('used', {}).get('%s_%s' % (p.get('id'), _day()), 0))
    return max(0, (daily_minutes(p) * 60 - used) // 60)


def block_reason():
    """Why watching is not allowed right now, or None when it is."""
    p = _active()
    if not timed(p):
        return None
    d = _load()
    if time.time() < float(d.get('until', {}).get(p.get('id'), 0)):
        return None                                                      # the parent allowed more time
    if in_bedtime(bed_hour(p), time.localtime().tm_hour):
        return 'It is past bedtime (%s) - watching starts again at %s' % (hour_label(bed_hour(p)), hour_label(WAKE_HOUR))
    if daily_minutes(p) > 0 and int(d.get('used', {}).get('%s_%s' % (p.get('id'), _day()), 0)) >= daily_minutes(p) * 60:
        return "Today's %s of watching is used up" % amount_label(daily_minutes(p))
    return None


def _time_is_up(why):
    """Stops the video and, when a Parent PIN exists, offers a parent 30 more minutes."""
    xbmc.Player().stop()
    dlg = xbmcgui.Dialog()
    from resources.lib import profiles as pf
    if pf.has_parent_pin():
        if dlg.yesno('Screen time', why + '\n\nA parent can add 30 minutes.', nolabel='OK', yeslabel='Parent PIN'):
            pin = dlg.input('Parent PIN', type=xbmcgui.INPUT_NUMERIC, option=xbmcgui.ALPHANUM_HIDE_INPUT)
            if pin and pf.check_parent_pin(pin):
                grant_minutes(30)
                dlg.notification('Starfleet', '30 more minutes added', xbmcgui.NOTIFICATION_INFO, 3000)
            elif pin:
                dlg.notification('Starfleet', 'Wrong PIN', xbmcgui.NOTIFICATION_ERROR, 3000)
    else:
        dlg.ok('Screen time', why)


class ScreenPlayer(xbmc.Player):
    """Counts the watching and stops a video that is not allowed (checked at the start, then every five seconds)."""

    def __init__(self):
        xbmc.Player.__init__(self)
        self._gen = 0

    def onAVStarted(self):
        self._gen += 1
        try:
            if not (self.isPlayingVideo() and timed()):
                return
        except Exception:
            return
        threading.Thread(target=self._watch, args=(self._gen,), daemon=True, name='starfleet-screen-time').start()

    def onPlayBackStopped(self):
        self._gen += 1

    onPlayBackEnded = onPlayBackStopped

    def _watch(self, gen):
        mon = xbmc.Monitor()
        try:
            while gen == self._gen:
                why = block_reason()
                if why:
                    _time_is_up(why)
                    return
                if mon.waitForAbort(5) or gen != self._gen:
                    return
                if not xbmc.getCondVisibility('Player.Paused'):
                    add_seconds(5)
        except Exception as e:
            _log('%s' % e)
