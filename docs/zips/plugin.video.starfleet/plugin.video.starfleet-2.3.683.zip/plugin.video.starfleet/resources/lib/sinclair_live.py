# -*- coding: utf-8 -*-
"""This module now lives in script.module.starfleetscrapers (starfleetscrapers.live.sinclair_live). This file only keeps
the old import name working: importing it gives you that module itself, so every attribute and function is unchanged."""
import sys

from resources.lib import _scrapers_bridge  # noqa: F401  (registers the host for the scrapers)
from starfleetscrapers.live import sinclair_live as _impl

sys.modules[__name__] = _impl
