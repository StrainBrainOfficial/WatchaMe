# -*- coding: utf-8 -*-
"""Connects the Starfleet Scrapers module (script.module.starfleetscrapers) to what only this add-on has: its debrid /
resolver layer, its site registry and its other scrapers. Imported by the small alias files that keep the old module
names (adult_streams, afdb, ...) working. The factories import lazily, so nothing here loads until a scraper asks."""
from starfleetscrapers import hooks, host

host.register(addon_id='plugin.video.starfleet', package='resources.lib')


def _resolvers():
    from resources.lib import resolvers
    return resolvers


def _hosted():
    from resources.lib import sf_resolve
    return sf_resolve


def _scene_site_registry():
    from resources.lib.afdb_router import _adult_scene_site_registry
    return _adult_scene_site_registry()


def _search_all_scrapers(title, kind=''):
    from resources.lib.scraper_sources import search_all_scrapers
    return search_all_scrapers(title, kind)


hooks.register(resolvers=_resolvers, hosted=_hosted, scene_site_registry=_scene_site_registry,
               search_all_scrapers=_search_all_scrapers)
