# -*- coding: utf-8 -*-
"""
resources/lib/gui/iptv_browse.py - the "IPTV" entry inside the Movies, TV Shows and Live TV dialogs.

    open_kind(kind)    kind: 'movie' | 'series' | 'live'
        provider (asked when there is more than one) -> its categories (the viewer's hide / rename / order applied) -> the items.
        Live channels show what is on now and next from the imported guide; a series opens its seasons, then its episodes.

The lists reuse CategoryListWindow (the same skin as every other list). Playing goes through the plugin action iptv_play, which asks the engine
for the real stream address at play time (Stalker portals issue a fresh link for every play).
"""
import json
import time
from urllib.parse import quote

import xbmc
import xbmcaddon
import xbmcgui

from resources.lib.gui import progress_dialog as _pdlg

_ADDON_PATH = lambda: xbmcaddon.Addon('plugin.video.starfleet').getAddonInfo('path')
_TITLES = {'live': 'Live TV', 'movie': 'Movies', 'series': 'TV Shows'}


def _catalog():
    from starfleetscrapers.iptv import catalog
    return catalog


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log('[Starfleet/IPTV] %s' % msg, level)


_TMDB = {}


def tmdb_match(kind, title, year=''):
    """TMDB id (and IMDb id) for a provider title, or None. A hit counts when its normalised title is the same and the year is within one.
    Remembered for the session."""
    from starfleetscrapers.iptv import sources as _src
    from resources.lib import metadata as meta
    q = _src.clean(title)
    year = str(year or '') or _src.year_of(title)
    key = (kind, _src.norm(title), year)
    if key in _TMDB:
        return _TMDB[key]
    found = None
    try:
        results = (meta.search_movies(q) if kind == 'movie' else meta.search_tv(q)) or []
        for r in results[:10]:
            if _src.norm(r.get('title', '')) != _src.norm(q):
                continue
            ry = str(r.get('year') or '')
            if year.isdigit() and ry.isdigit() and abs(int(ry) - int(year)) > 1:
                continue
            found = {'tmdb_id': str(r['tmdb_id']), 'title': r.get('title', ''), 'year': ry, 'fanart': r.get('fanart', ''), 'thumb': r.get('thumb', '')}
            break
        if found:
            try:
                d = meta.get_movie_detail(found['tmdb_id']) if kind == 'movie' else meta.get_tv_detail(found['tmdb_id'])
                found['imdb_id'] = (d or {}).get('imdb_id', '')
            except Exception:
                found['imdb_id'] = ''
    except Exception as e:
        _log('tmdb match %r: %s' % (title, e))
    _TMDB[key] = found
    return found


def _detail_fetch(kind):
    """Per-focus metadata for the IPTV movie / show lists: plot and cast come from TMDB, whatever the provider sends."""
    def _fetch(film):
        row = film.get('row') or {}
        m = tmdb_match(kind, film.get('title', ''), row.get('year'))
        if not m:
            return {}
        from resources.lib import metadata as meta
        full = (meta.get_movie_detail(m['tmdb_id']) if kind == 'movie' else meta.get_tv_detail(m['tmdb_id'])) or {}
        return {'overview': full.get('overview', ''),
                'cast': [{'name': c.get('name', ''), 'photo': c.get('photo', '')} for c in full.get('cast', [])[:4]]}
    return _fetch


def _hhmm(ts):
    return time.strftime('%H:%M', time.localtime(ts))


def _now_next_text(cat, provider_id, row):
    try:
        nn = cat.now_next(provider_id, row)
    except Exception:
        return ''
    lines = []
    if nn.get('now'):
        lines.append('Now: %s (until %s)' % (nn['now']['title'], _hhmm(nn['now']['stop'])))
        if nn['now'].get('desc'):
            lines.append(nn['now']['desc'])
    if nn.get('next'):
        lines.append('Next: %s (%s)' % (nn['next']['title'], _hhmm(nn['next']['start'])))
    return '\n'.join(lines)


def _window(items, breadcrumb, subheader, media_type, on_play, **kw):
    from resources.lib.gui.category_list import CategoryListWindow
    win = CategoryListWindow('Starfleet-CategoryList.xml', _ADDON_PATH(), 'Default', '1080i', items=items, breadcrumb=breadcrumb,
                             subheader=subheader, media_type=media_type, on_play=on_play, **kw)
    win.doModal()
    del win


def _pick_provider(kind):
    cat = _catalog()
    provs = cat._enabled()
    if not provs:
        if xbmcgui.Dialog().yesno('IPTV', 'No IPTV provider yet.\nAdd one now (Xtream Codes, Stalker or M3U)?'):
            from resources.lib import iptv_ui
            iptv_ui.add_provider()
            provs = cat._enabled()
        if not provs:
            return None
    if len(provs) == 1:
        return provs[0]
    i = xbmcgui.Dialog().select('IPTV - %s' % _TITLES[kind], [p.get('name') or p['url'] for p in provs])
    return provs[i] if i >= 0 else None


def open_kind(kind):
    """Entry point from the Movies / TV Shows / Live TV dialogs."""
    cat = _catalog()
    p = _pick_provider(kind)
    if not p:
        return
    options = ['Browse categories', 'Search']
    i = xbmcgui.Dialog().select('IPTV - %s - %s' % (p.get('name'), _TITLES[kind]), options)
    if i == 0:
        _categories(cat, p, kind)
    elif i == 1:
        q = xbmcgui.Dialog().input('Search %s' % _TITLES[kind], type=xbmcgui.INPUT_ALPHANUM)
        if q:
            _search(cat, p, kind, q)


def _categories(cat, p, kind):
    pd = _pdlg.DialogProgress()
    pd.create('Starfleet', 'Loading %s categories...' % _TITLES[kind].lower())
    try:
        cats = cat.categories(p['id'], kind)
    except Exception as e:
        pd.close()
        xbmcgui.Dialog().ok('IPTV', 'Could not load the categories (%s).' % type(e).__name__)
        _log('categories %s/%s: %s' % (p.get('name'), kind, e), xbmc.LOGWARNING)
        return
    pd.close()
    if not cats:
        if xbmcgui.Dialog().yesno('IPTV', 'No categories are shown.\nOpen "Manage categories" to show some?'):
            from resources.lib import iptv_ui
            iptv_ui.manage_categories(p)
        return
    items = [{'title': c['name'], 'thumb': '', 'fanart': '', 'overview': '', 'year': '', 'cat_id': c['id']} for c in cats]

    def _pick(item):
        _items(cat, p, kind, item['cat_id'], item['title'])

    _window(items, 'IPTV - %s' % p.get('name'), '%d categories  ·  %s' % (len(items), _TITLES[kind]), 'movie', _pick)


def _rows_to_items(cat, p, kind, rows):
    out = []
    for r in rows:
        it = {'title': r['title'], 'thumb': r.get('poster') or '', 'fanart': r.get('poster') or '', 'overview': r.get('plot') or '',
              'year': r.get('year') or '', 'row': r}
        if kind == 'live':
            it['overview'] = _now_next_text(cat, p['id'], r) or 'Channel %s' % (r.get('num') or '')
        out.append(it)
    return out


def _items(cat, p, kind, cat_id, cat_title):
    pd = _pdlg.DialogProgress()
    pd.create('Starfleet', 'Loading %s...' % cat_title)
    try:
        rows = cat.items(p['id'], kind, cat_id)
    except Exception as e:
        pd.close()
        xbmcgui.Dialog().ok('IPTV', 'Could not load this category (%s).' % type(e).__name__)
        _log('items %s/%s/%s: %s' % (p.get('name'), kind, cat_id, e), xbmc.LOGWARNING)
        return
    items = _rows_to_items(cat, p, kind, rows[:3000])
    pd.close()
    if not items:
        xbmcgui.Dialog().notification('Starfleet', 'Nothing in this category', xbmcgui.NOTIFICATION_INFO, 3000)
        return
    _show_items(cat, p, kind, items, 'IPTV - %s' % cat_title)


def _search(cat, p, kind, query):
    pd = _pdlg.DialogProgress()
    pd.create('Starfleet', 'Searching %s...' % _TITLES[kind].lower())
    try:
        rows = [r for r in cat.search(query, kind) if r.get('provider_id') == p['id']]
    finally:
        pd.close()
    if not rows:
        xbmcgui.Dialog().notification('Starfleet', 'No matches', xbmcgui.NOTIFICATION_INFO, 3000)
        return
    _show_items(cat, p, kind, _rows_to_items(cat, p, kind, rows), 'IPTV - search "%s"' % query)


def _show_items(cat, p, kind, items, breadcrumb):
    def _on_play(item):
        row = item['row']
        if kind == 'series':
            _seasons(cat, p, row)
        elif kind == 'movie':
            play(p['id'], kind, row, tmdb=tmdb_match('movie', row.get('title', ''), row.get('year')))
        else:
            play(p['id'], kind, row)

    extra = {'detail_fetch': _detail_fetch(kind)} if kind in ('movie', 'series') else {}
    _window(items, breadcrumb, '%d  ·  %s' % (len(items), _TITLES[kind]), 'movie' if kind != 'series' else 'tv', _on_play, **extra)


def _seasons(cat, p, show):
    pd = _pdlg.DialogProgress()
    pd.create('Starfleet', 'Loading seasons...')
    try:
        data = cat.seasons(p['id'], show['id'])
    except Exception as e:
        pd.close()
        xbmcgui.Dialog().ok('IPTV', 'Could not load this show (%s).' % type(e).__name__)
        return
    pd.close()
    seasons = data.get('seasons') or {}
    if not seasons:
        xbmcgui.Dialog().notification('Starfleet', 'No episodes found', xbmcgui.NOTIFICATION_INFO, 3000)
        return
    info = data.get('info') or {}
    poster = info.get('poster') or show.get('poster') or ''
    match = tmdb_match('series', show.get('title', ''), show.get('year') or info.get('year'))
    if match and match.get('thumb'):
        poster = match['thumb']
    items = [{'title': 'Season %d' % n, 'thumb': poster, 'fanart': (match or {}).get('fanart') or poster, 'overview': info.get('plot') or '',
              'year': '', 'episodes': eps, 'season': n} for n, eps in sorted(seasons.items())]

    def _pick(item):
        _episodes(p, show, item, match)

    _window(items, 'IPTV - %s' % show['title'], '%d seasons' % len(items), 'tv', _pick)


def _episodes(p, show, season_item, match=None):
    items = [{'title': 'E%02d  %s' % (e.get('episode') or 0, e['title']), 'thumb': e.get('poster') or '', 'fanart': '',
              'overview': e.get('plot') or '', 'year': '', 'row': e} for e in season_item['episodes']]

    def _play(item):
        play(p['id'], 'series', item['row'], tmdb=match, season=item['row'].get('season') or season_item.get('season') or 0,
             episode=item['row'].get('episode') or 0)

    _window(items, 'IPTV - %s - %s' % (show['title'], season_item['title']), '%d episodes' % len(items), 'tv', _play)


def play(provider_id, kind, row, tmdb=None, season=0, episode=0):
    """Hand the row to the plugin's iptv_play action (resolved there, at play time). A TMDB match makes the play tracked (resume, Continue
    Watching, Simkl / Trakt) and gives it the TMDB title."""
    title = (tmdb or {}).get('title') or row.get('title', '')
    url = ('plugin://plugin.video.starfleet/?action=iptv_play&provider=%s&kind=%s&title=%s&ref=%s'
           % (quote(provider_id), quote(kind), quote(title), quote(json.dumps(row.get('ref') or {}, separators=(',', ':')))))
    if tmdb:
        url += '&tmdb_id=%s&imdb_id=%s&year=%s&season=%s&episode=%s' % (quote(tmdb.get('tmdb_id', '')), quote(tmdb.get('imdb_id', '')),
                                                                    quote(str(tmdb.get('year', ''))), int(season or 0), int(episode or 0))
    li = xbmcgui.ListItem(label=row.get('title', ''))
    li.setInfo('video', {'title': row.get('title', ''), 'mediatype': 'episode' if kind == 'series' else ('movie' if kind == 'movie' else 'video')})
    xbmc.Player().play(url, li)
