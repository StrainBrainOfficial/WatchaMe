# -*- coding: utf-8 -*-
"""
resources/lib/tracker_sync.py

Keeps the plugin level with the paired tracking accounts. When Kodi starts (and whenever Home opens, and every 15 minutes while
Kodi runs) one quick question is asked of each paired account - "has anything changed?" (SIMKL /sync/activities, Trakt
/sync/last_activities) - and only when the answer is yes, or the copy on disk is older than six hours, is the account's
My List fetched again (movies, TV shows and, for SIMKL, anime), together with its watched list. The lists are kept on disk per
profile (see tracker_lists.py), so a section opens at once and shows what is on the account, and the watched ticks agree with it.
Watched marks that could not be sent earlier are sent first. On a Fire TV Stick this is a few small requests at start-up instead
of a long wait each time a list is opened.

Nothing happens when no tracker is paired. Never raises.
"""
import json
import os
import threading
import time

import xbmc

GAP = 15 * 60
FULL_EVERY = 6 * 3600
_lock = threading.Lock()
_running = [False]


def _log(msg):
    xbmc.log('[Starfleet/TrackerSync] %s' % msg, xbmc.LOGINFO)


def _state_path():
    from resources.lib import profiles as _profiles
    return _profiles.data_path('tracker_sync.json')


def _load():
    try:
        with open(_state_path(), 'r', encoding='utf-8') as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def _save(d):
    try:
        p = _state_path()
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p + '.tmp', 'w', encoding='utf-8') as f:
            json.dump(d, f)
        os.replace(p + '.tmp', p)
    except Exception:
        pass


def _activity(key):
    """The account's "last changed" stamp, or None when it cannot be read (offline, signed out)."""
    import requests
    try:
        if key == 'simkl':
            from resources.lib import simkl_sync as m
            r = requests.get(m.SIMKL_BASE + '/sync/activities', params=m._params(), headers=m._headers(), timeout=10)
        elif key == 'trakt':
            from resources.lib import trakt_sync as m
            r = requests.get(m.TRAKT_BASE + '/sync/last_activities', headers=m._headers(), timeout=10)
        else:
            return None
        r.raise_for_status()
        return (r.json() or {}).get('all') or ''
    except Exception as e:
        _log('%s: could not ask what changed (%s)' % (key, str(e)[:80]))
        return None


def sync_once(force=False):
    """One pass. Returns the list of trackers that were brought up to date."""
    from resources.lib import tracker_lists as tl
    updated = []
    try:
        from resources.lib import simkl_sync
        simkl_sync.flush_pending()
    except Exception:
        pass
    state = _load()
    now = time.time()
    for key, _label in tl.paired():
        if key not in ('simkl', 'trakt'):
            continue                                   # WeTrakr has no read endpoint
        act = _activity(key)
        if act is None:
            continue
        lists = [('tv', False), ('movie', False)] + ([('tv', True), ('movie', True)] if key == 'simkl' else [])
        ages = [tl.disk_age(key, m, a) for m, a in lists]
        old = any(x is None or x > FULL_EVERY for x in ages)
        if not (force or old or act != (state.get(key) or {}).get('act')):
            continue
        t = time.time()
        ok = True
        for media, anime in lists:
            if tl.refresh(key, media, anime) < 0:
                ok = False
        try:
            if key == 'simkl':
                from resources.lib import simkl_sync as m
            else:
                from resources.lib import trakt_sync as m
            m.watched_map(refresh_if_older=0)
        except Exception:
            ok = False
        if ok:
            state[key] = {'act': act, 't': now}
            updated.append(key)
        _log('%s brought up to date in %.1fs (%s)' % (key, time.time() - t, 'ok' if ok else 'some lists failed'))
    state['last'] = now
    _save(state)
    return updated


def kick(min_gap=300):
    """Start a pass in the background unless one ran in the last `min_gap` seconds (called when Home opens)."""
    if _running[0] or time.time() - _load().get('last', 0) < min_gap:
        return False

    def _run():
        with _lock:
            _running[0] = True
            try:
                sync_once()
            except Exception as e:
                _log('pass failed: %s' % e)
            finally:
                _running[0] = False
    threading.Thread(target=_run, daemon=True).start()
    return True


def tick():
    """One pass for the scheduler. Returns seconds until the next pass."""
    with _lock:
        _running[0] = True
        try:
            sync_once()
        finally:
            _running[0] = False
    return GAP


def run(monitor):
    """Service thread body: a pass shortly after Kodi starts, then every 15 minutes."""
    if monitor.waitForAbort(40):
        return
    while not monitor.abortRequested():
        try:
            from resources.lib import memguard as _mg
            if _mg.low():
                if monitor.waitForAbort(300):
                    break
                continue
            with _lock:
                _running[0] = True
                try:
                    sync_once()
                finally:
                    _running[0] = False
        except Exception as e:
            _log('pass failed: %s' % e)
        if monitor.waitForAbort(GAP):
            break
