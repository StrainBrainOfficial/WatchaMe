# -*- coding: utf-8 -*-
"""
resources/lib/wetrakr_sync.py

Push playback events to a paired WeTrakr account. Mirrors trakt_sync.py's/simkl_sync.py's public function names and
signatures so watch_history.py/continue_watching.py's call sites work identically across all three - deliberately NO
cross-imports between sync modules (each redefines its own _IMDB_RE/_real_imdb guard rather than sharing it).

WeTrakr's API is structurally different from Trakt/SIMKL: a SINGLE webhook endpoint, not a REST resource collection -
  POST {api_url}/webhooks/kodi/{access_token}
  Content-Type: application/json
  body: {"event": "playing"|"paused"|"scrobble"|"rating", "media_type": "movie"|"episode", "title", "year"?,
         "ids": {"imdb"?,"tmdb"?,"tvdb"?}, ["show_title","show_ids","season","episode" for episodes,]
         "progress": float 0-100, ["rating": 1-10 for the rating event]}
The access token is part of the URL path, not a header. A rejected token answers HTTP 401 {"error":"invalid_token"}.

There is no separate "mark as watched" call and no query endpoint: a "scrobble" event IS how WeTrakr represents
"watched", and nothing is read back. So:
  - mark_watched_movie/mark_watched_episode/mark_show_watched send a "scrobble" event at progress=100.0
    (mark_show_watched sends one call per (season, episode) pair - the event shape is always a single episode).
  - scrobble_start / scrobble_progress / scrobble_pause / scrobble_stop map onto "playing" / "playing" / "paused" /
    "scrobble". scrobble_progress is the periodic "still playing" update (WeTrakr treats a session as live from about
    5% played and shows it as Now Playing).
  - send_rating() sends the "rating" event (1-10); prompt_rating() asks the viewer after a finished title when the
    "wetrakr_rate_after_watch" setting is on.
  - get_normalized_playback()/get_playback_progress()/get_all_items_shows() are no-op stubs (return []/None/[]).

A 401/403 means the saved token is stale (revoked, or the account was recreated): the token is flagged as rejected
(wetrakr_auth.mark_token_rejected), events stop, and the viewer is asked to pair again - nothing is retried in a loop.

Adult content never reaches WeTrakr, same guard as trakt_sync.py/simkl_sync.py: every function here only ever treats
imdb_id as valid when it matches real IMDB id shape (tt<digits>) - adult sources' opaque keys (e.g. "ade:5122655") fail
that check and are silently dropped.
"""
import re
import threading
import xbmc

from resources.lib import wetrakr_auth

_IMDB_RE = re.compile(r'^tt\d+$')


def _real_imdb(imdb_id):
    """Returns imdb_id if it's shaped like a genuine IMDB id, else ''."""
    return imdb_id if imdb_id and _IMDB_RE.match(imdb_id) else ''


def _fresh_token():
    # Always construct a fresh Addon(), never reuse a cached one - this runs from watch_history.py's playback-monitor
    # thread, which can easily be alive across a mid-session pairing.
    import xbmcaddon
    return xbmcaddon.Addon('plugin.video.starfleet').getSetting('wetrakr_access_token').strip()


def _ids(imdb_id='', tmdb_id='', tvdb_id=''):
    ids = {}
    if imdb_id:
        ids['imdb'] = imdb_id
    for key, val in (('tmdb', tmdb_id), ('tvdb', tvdb_id)):
        if val:
            try:
                ids[key] = int(val)
            except (TypeError, ValueError):
                ids[key] = val
    return ids


def _event_body(event, progress, imdb_id='', tmdb_id='', title='', season=0, episode=0, year=0):
    ids = _ids(imdb_id, tmdb_id)
    if season and episode:
        return {
            'event': event, 'media_type': 'episode',
            'title': title, 'show_title': title,
            'show_ids': ids, 'ids': ids,
            'season': int(season), 'episode': int(episode),
            'progress': round(float(progress), 1),
        }
    body = {
        'event': event, 'media_type': 'movie',
        'title': title, 'ids': ids,
        'progress': round(float(progress), 1),
    }
    if year:
        body['year'] = int(year)
    return body


def _post(payload):
    """Send one event. Returns True on 2xx. 401/403 flags the token as rejected; a dropped connection is retried once."""
    if not wetrakr_auth.is_paired():
        return False
    token = _fresh_token()
    if not token:
        return False
    url = '%s/webhooks/kodi/%s' % (wetrakr_auth.api_url(), token)
    headers = {'Content-Type': 'application/json', 'User-Agent': wetrakr_auth.user_agent()}
    try:
        import requests
    except Exception:
        return False
    for attempt in (1, 2):
        try:
            r = requests.post(url, json=payload, headers=headers, timeout=10)
        except Exception as e:
            if attempt == 2:
                xbmc.log('[Starfleet/WeTrakr] webhook error: %s' % e, xbmc.LOGWARNING)
                return False
            continue
        xbmc.log('[Starfleet/WeTrakr] %s -> %s' % (payload.get('event'), r.status_code), xbmc.LOGINFO)
        if r.status_code in (401, 403):
            wetrakr_auth.mark_token_rejected()
            return False
        return 200 <= r.status_code < 300
    return False


def _post_async(payload):
    threading.Thread(target=_post, args=(payload,), daemon=True).start()


def _send(event, progress, imdb_id='', tmdb_id='', title='', season=0, episode=0, year=0):
    imdb_id = _real_imdb(imdb_id)
    if not wetrakr_auth.is_paired() or not (imdb_id or tmdb_id):
        return
    _post_async(_event_body(event, progress, imdb_id, tmdb_id, title, season, episode, year))


def mark_watched_movie(imdb_id='', tmdb_id='', title=''):
    _send('scrobble', 100.0, imdb_id, tmdb_id, title)


def mark_watched_episode(imdb_id='', tmdb_id='', title='', season=0, episode=0):
    if not season or not episode:
        return
    _send('scrobble', 100.0, imdb_id, tmdb_id, title, season, episode)


def mark_show_watched(imdb_id='', tmdb_id='', title='', season_episode_pairs=None):
    """One webhook call per (season, episode) pair - the event shape is always a single episode."""
    if not season_episode_pairs:
        return
    for season, episode in season_episode_pairs:
        mark_watched_episode(imdb_id, tmdb_id, title, season, episode)


# ── Scrobble (playback progress events) ─────────────────────────────────────

def scrobble_start(imdb_id='', tmdb_id='', title='', season=0, episode=0, progress=0.0):
    """Once when playback actually begins - sends the "playing" event."""
    _send('playing', progress, imdb_id, tmdb_id, title, season, episode)


def scrobble_progress(imdb_id='', tmdb_id='', title='', season=0, episode=0, progress=0.0):
    """Periodic "still playing" update (watch_history.py sends one about every 30 s)."""
    _send('playing', progress, imdb_id, tmdb_id, title, season, episode)


def scrobble_pause(imdb_id='', tmdb_id='', title='', season=0, episode=0, progress=0.0):
    """Once when playback ends short of the watched threshold - the "paused" event (a position update)."""
    _send('paused', progress, imdb_id, tmdb_id, title, season, episode)


def scrobble_stop(imdb_id='', tmdb_id='', title='', season=0, episode=0, progress=0.0):
    """Once when playback ends at/past the watched threshold - the "scrobble" event, which IS "watched" server-side."""
    _send('scrobble', progress, imdb_id, tmdb_id, title, season, episode)


# ── Ratings ─────────────────────────────────────────────────────────────────

def send_rating(rating, imdb_id='', tmdb_id='', title='', season=0, episode=0, year=0):
    """Rate a movie or episode 1-10. Returns True when WeTrakr accepted it."""
    imdb_id = _real_imdb(imdb_id)
    try:
        rating = int(rating)
    except (TypeError, ValueError):
        return False
    if not 1 <= rating <= 10 or not wetrakr_auth.is_paired() or not (imdb_id or tmdb_id):
        return False
    body = _event_body('rating', 100.0, imdb_id, tmdb_id, title, season, episode, year)
    body['rating'] = rating
    body.pop('progress', None)
    return _post(body)


def rate_after_watch_enabled():
    import xbmcaddon
    return xbmcaddon.Addon('plugin.video.starfleet').getSetting('wetrakr_rate_after_watch') == 'true'


def prompt_rating(imdb_id='', tmdb_id='', title='', season=0, episode=0, year=0):
    """Ask for a 1-10 rating after a finished title (only when paired and the viewer turned the setting on)."""
    if not rate_after_watch_enabled() or not wetrakr_auth.is_paired():
        return
    import xbmcgui
    labels = ['%d' % n for n in range(10, 0, -1)] + ['Skip']
    name = title if not (season and episode) else '%s S%02dE%02d' % (title, int(season), int(episode))
    pick = xbmcgui.Dialog().select('Rate "%s" on WeTrakr' % name, labels)
    if pick < 0 or pick >= 10:
        return
    value = 10 - pick
    if send_rating(value, imdb_id, tmdb_id, title, season, episode, year):
        xbmcgui.Dialog().notification('WeTrakr', 'Rated %d/10' % value, xbmcgui.NOTIFICATION_INFO, 3000)


# ── Read side: WeTrakr is write-only here ───────────────────────────────────

def get_normalized_playback():
    """No GET endpoint to query saved progress from - always []."""
    return []


def get_all_items_shows():
    """Same reason as get_normalized_playback() above - always []."""
    return []


def get_playback_progress(imdb_id='', tmdb_id='', season=0, episode=0):
    """Same reason as above - always None, so watch_history.apply_resume() falls through to the next provider."""
    return None
