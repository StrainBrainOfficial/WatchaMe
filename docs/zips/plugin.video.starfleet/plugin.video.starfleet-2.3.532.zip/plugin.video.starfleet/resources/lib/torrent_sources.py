﻿# -*- coding: utf-8 -*-
"""
resources/lib/torrent_sources.py

Search multiple torrent sites for a title and return magnet links.
Results are used with debrid services (Real-Debrid, AllDebrid, Premiumize, TorBox)
to get instant cached streams — uncached torrents are skipped.

Sources:
  YTS          — JSON API, movies only, high quality
  1337x        — HTML scraping, mirror rotation + CF bypass
  The Pirate Bay — JSON API, movies + TV + adult
  EZTV         — JSON API, TV shows
  Bitsearch    — DHT index scrape
  TorrentGalaxy — HTML scraping + CF bypass
  YourBitTorrent — HTML scraping
  Bitlord      — HTML scraping
  Knaben       — aggregated JSON API (movies/TV/adult)
  Torrentio    — Stremio IMDB-based API
  Torrentdownload — HTML scraping
  XXXClub        — HTML scraping, adult only
"""

import hashlib
import re
import time
import xbmc
import xbmcaddon
import xbmcvfs

try:
    import requests as _req
except ImportError:
    _req = None

try:
    from resources.lib.title_utils import clean_adult_title as _clean_adult_title
except Exception:
    def _clean_adult_title(t):
        return t

try:
    from resources.lib import cache as _cache
    _PROFILE = xbmcvfs.translatePath(xbmcaddon.Addon('plugin.video.starfleet').getAddonInfo('profile'))
    _cache.init(_PROFILE + '/cache.db')
    _HAS_CACHE = True
except Exception:
    _HAS_CACHE = False

# ── Quality helpers ───────────────────────────────────────────────────────────

# High-quality markers
_QUALITY_HQ = re.compile(
    r'\b(?:720p?|1080p?|1080i|2160p?|4k|uhd|3d|bd(?:rip|remux)|bluray|blu[-\s]?ray)\b',
    re.IGNORECASE
)
# Any recognisable video quality marker (accepts HDTV/WEB/x265 without resolution)
_QUALITY_ANY = re.compile(
    r'\b(?:720|1080|2160|4k|uhd|3d|bluray|blu.ray|bdrip|bdremux|'
    r'web[-.]?dl|webdl|webrip|web.rip|hdtv|hdrip|dvdrip|dvd|'
    r'x264|x265|hevc|h\.?264|h\.?265|xvid|avc|hevcrip|remux|'
    r'hdcam|scr|screener|dvdscr)\b',
    re.IGNORECASE
)
# Definitively low-quality markers — anything below the 540p floor, plus
# camrip/screener junk regardless of any resolution tag it might also carry.
# telesync/hdts are the same cam-sourced junk tier as camrip/hdcam (footage
# captured off a cinema screen, sometimes with a separate audio feed synced
# in) but were missing from this list — confirmed live this let releases
# like "The Odyssey 2026 2160pHD TELESYNC..." and "...2160PHD HQ HDTS..."
# through _meets_quality and get mislabeled '4K'/'1080p' by _extract_quality
# below, purely because a genuine cam rip can never actually contain real
# 2160p/1080p detail no matter what resolution tag the release name claims.
# That's not just a mislabel: it's the exact scam-torrent pattern behind
# the malware-disguised-magnet issue found earlier in this same title's
# results (a popular real TELESYNC release's name cloned with a bogus 4K
# tag swapped in), and it was crowding real WEB/BluRay 4K releases out of
# the top-seeded quick-check candidates entirely.
_QUALITY_LQ = re.compile(
    r'\b(?:480p?|360p?|240p?|camrip|hdcam|telesync|hdts|scr|screener|dvdscr|dvdrip)\b',
    re.IGNORECASE
)

# Text-month embedded dates (e.g. "June 13, 2015", "13 Sept", "April 13") —
# used by search_all()'s title filter to keep a release date's day number
# from spuriously satisfying a numeric query word like a scene/sequel number.
_MONTH_NAMES = (r'jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|'
                r'jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:t(?:ember)?)?|'
                r'oct(?:ober)?|nov(?:ember)?|dec(?:ember)?')
_RE_MONTH_DAY_YEAR = re.compile(
    r'\b(?:' + _MONTH_NAMES + r')\.?\s+\d{1,2}(?:st|nd|rd|th)?,?\s*(?:\d{2,4})?\b',
    re.IGNORECASE
)
_RE_DAY_MONTH = re.compile(
    r'\b\d{1,2}(?:st|nd|rd|th)?\s+(?:' + _MONTH_NAMES + r')\.?,?\s*(?:\d{2,4})?\b',
    re.IGNORECASE
)
# Numeric date already space-separated in the source title (e.g. "06 13
# 2015") rather than dot/slash-separated — requires a 19xx/20xx year to
# stay narrow enough not to eat unrelated three-number sequences.
_RE_NUM_DATE_SPACED = re.compile(r'\b\d{1,2}\s+\d{1,2}\s+(?:19|20)\d{2}\b')
# Patterns that identify non-video content (games, software, ebooks, music)
_NON_VIDEO = re.compile(
    r'(?:'
    r'\[(?:Nintendo\s*Switch|NSZ|XCI|NSW|PS[345]|XBOX|PC\s*Game|NDS|3DS|GBA)\]'
    r'|Nintendo\s*Switch'
    r'|(?<!\d)v\d+\.\d+[\.\d]*(?:[- ]|$)'  # software version like v2025.11.22
    r'|\bBuild\s+\d{5,}\b'                  # game build numbers like "Build 13275298"
    r'|\bUpdate\s+v\d'                       # "Update v1" game update pattern
    r'|\bNSZ\b|\bXCI\b|\bNSP\b' # Switch formats
    r'|\[P\]'                    # Knaben game/app marker
    r'|\bAndroid\b|\biOS\b|\bAPK\b'
    r'|-(?:TENOKE|RELOADED|CODEX|SKIDROW|PLAZA|FLT|HOODLUM|GOG|DARKSIDERS|CPY)\b'  # game crack groups
    r')',
    re.IGNORECASE
)
# Adult content markers — excluded from movie/tv results
_IS_ADULT = re.compile(r'\b(?:XXX|adult|porn|sex)\b', re.IGNORECASE)

# EZTV only ever indexed TV shows, never movies (confirmed by user) — EZTV
# itself has also been dead/CF-blocked for years (see search_all()'s own
# "Dead permanently" notes), so nothing genuine is being freshly released
# under that branding either way. A torrent for a MOVIE title carrying an
# "EZTV" tag is therefore not just stale, it's definitionally fake — and
# confirmed live this is exactly the scam-clone pattern behind both the
# disguised-.exe malware and the fake-4K TELESYNC releases found for the
# same title: several "The Odyssey ... EZTV" entries claiming 2160p/4K,
# none of which could be genuine EZTV content since EZTV never covered
# movies at all. Movie-only — real EZTV TV-show releases from when the
# site was alive are still legitimately re-seeded/cached elsewhere.
_RE_FAKE_EZTV = re.compile(r'\beztv\b', re.IGNORECASE)


def _meets_quality(text, media_type='movie'):
    """
    Return True if this torrent is acceptable quality.
    Rejects explicit LQ markers (480p, cam, screener) and non-video content
    (games, software) for movie/tv searches.
    """
    if media_type == 'adult':
        return True
    s = text or ''
    if _QUALITY_LQ.search(s):
        return False
    if media_type in ('movie', 'tv'):
        if _NON_VIDEO.search(s):
            return False
        if _IS_ADULT.search(s):
            return False
    if media_type == 'movie' and _RE_FAKE_EZTV.search(s):
        return False
    return True


def _extract_quality(text):
    # Substring matching (not strict \b-bounded regex) for the resolution
    # tiers, matching gearsscrapers' source_utils.get_qual() breadth -- real
    # scene-release names routinely butt the resolution token right up
    # against other alnum content with no word boundary at all (e.g.
    # "2160p10bit", "2160p60fps", "4kUHD"), which a trailing \b silently
    # rejected even though the release genuinely was that quality. Also
    # catches the "216o"/"108o"/"72o" letter-for-zero obfuscation some sites
    # use, and "ultrahd"/"ultra.hd" as additional 4K signals gears checks
    # for that the old regex never did.
    text = (text or '').lower()
    if any(s in text for s in ('2160', '216o', '4k', 'ultrahd', 'ultra.hd', 'ultra hd', 'uhd')):
        return '4K'
    if any(s in text for s in ('1080', '1o8o', '108o', '1o80', 'fhd')):
        return '1080p'
    if '720' in text or '72o' in text:
        return '720p'
    if '3d' in text:
        return '3D'
    if 'bluray' in text or 'blu-ray' in text or 'blu ray' in text:
        return 'Blu-ray'
    if 'webdl' in text or 'web-dl' in text or 'web.dl' in text or 'web dl' in text:
        return 'WEB-DL'
    if 'webrip' in text:
        return 'WEBRip'
    if 'hdtv' in text:
        return 'HDTV'
    return ''


# ── HTTP session & Cloudflare bypass ─────────────────────────────────────────

_BROWSER_HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/126.0.0.0 Safari/537.36'
    ),
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9',
    # No 'br' (Brotli) — decoding it depends on an optional brotli/brotlicffi
    # package this environment doesn't have installed, so a Brotli-encoded
    # response (which Cloudflare-fronted sites serve whenever Accept-Encoding
    # allows it) came back as raw compressed garbage instead of real HTML.
    # Confirmed live against limetorrents.fun: a real 200 response, silently
    # unusable, looking exactly like the site being dead. gzip/deflate are
    # handled natively with no extra dependency.
    'Accept-Encoding': 'gzip, deflate',
    'DNT': '1',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
}

# Full Chrome headers for CF-protected sites (includes sec-ch-ua and sec-fetch-* fields)
_CF_HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/126.0.0.0 Safari/537.36'
    ),
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'Accept-Language': 'en-US,en;q=0.9',
    # No 'br' (Brotli) — decoding it depends on an optional brotli/brotlicffi
    # package this environment doesn't have installed, so a Brotli-encoded
    # response (which Cloudflare-fronted sites serve whenever Accept-Encoding
    # allows it) came back as raw compressed garbage instead of real HTML.
    # Confirmed live against limetorrents.fun: a real 200 response, silently
    # unusable, looking exactly like the site being dead. gzip/deflate are
    # handled natively with no extra dependency.
    'Accept-Encoding': 'gzip, deflate',
    'Cache-Control': 'max-age=0',
    'sec-ch-ua': '"Not/A)Brand";v="8", "Chromium";v="126", "Google Chrome";v="126"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'Sec-Fetch-Dest': 'document',
    'Sec-Fetch-Mode': 'navigate',
    'Sec-Fetch-Site': 'none',
    'Sec-Fetch-User': '?1',
    'Upgrade-Insecure-Requests': '1',
    'Connection': 'keep-alive',
}

_session = None
_cf_session = None  # cloudscraper session (created lazily)


def _sess():
    global _session
    if _session is None and _req:
        _session = _req.Session()
        _session.headers.update(_BROWSER_HEADERS)
        # No retries — scrapers each have explicit timeouts; retrying a timed-out
        # connection wastes 3× the time (e.g. EZTV hitting 24s instead of 8s).
        # pool_connections/pool_maxsize were sized for a much smaller source
        # list -- confirmed live that with search_all() now running 20-27
        # sources truly concurrently (each hitting a different host) sharing
        # this one session, a pool this small caused real connection-pool
        # contention: the whole batch took 24.9s even though the single
        # slowest individual source only took 12.2s in isolation. Sized well
        # above the realistic peak concurrent-host count so no request ever
        # has to wait on pool space that a DIFFERENT host's requests are
        # sitting on.
        a = _req.adapters.HTTPAdapter(
            pool_connections=40, pool_maxsize=40,
            max_retries=_req.adapters.Retry(total=0, redirect=False)
        )
        _session.mount('https://', a)
        _session.mount('http://', a)
    return _session


def _get_cf_session():
    """Return a Cloudflare-bypass session (cloudscraper) if available, else None."""
    global _cf_session
    if _cf_session is not None:
        return _cf_session
    try:
        import cloudscraper as _cs
        _cf_session = _cs.create_scraper(
            browser={'browser': 'chrome', 'platform': 'windows', 'mobile': False}
        )
        xbmc.log('[Starfleet/Torrents] cloudscraper loaded', xbmc.LOGINFO)
        return _cf_session
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] cloudscraper init failed: %s' % e, xbmc.LOGWARNING)
    return None


def _get(url, timeout=10, cf=False):
    """HTTP GET. If cf=True, try cloudscraper first to bypass Cloudflare."""
    if cf:
        cs = _get_cf_session()
        if cs:
            try:
                r = cs.get(url, timeout=timeout)
                r.raise_for_status()
                return r.text
            except Exception as e:
                xbmc.log('[Starfleet/Torrents] CF session failed (%s): %s' % (url[:60], e),
                         xbmc.LOGWARNING)
    s = _sess()
    if s:
        r = s.get(url, timeout=timeout)
        r.raise_for_status()
        return r.text
    # Fallback: urllib (always available in Kodi's Python)
    try:
        import urllib.request as _ur
        req = _ur.Request(url, headers=_BROWSER_HEADERS)
        with _ur.urlopen(req, timeout=timeout) as resp:
            return resp.read().decode('utf-8', errors='replace')
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] urllib fallback failed (%s): %s' % (url[:60], e),
                 xbmc.LOGWARNING)
        return ''


def _get_json(url, timeout=10):
    s = _sess()
    if not s:
        return None
    r = s.get(url, timeout=timeout)
    r.raise_for_status()
    return r.json()


# Expanded tracker list (2026-08-27, per explicit request) — appended to
# every magnet this addon builds from a bare info_hash (a site that gives
# us a hash/id but no ready-made magnet of its own). More trackers means
# more independent chances to find an active announce for this exact
# torrent's swarm, which matters most for thin/older releases where DHT
# alone is slow to bootstrap, and gives a debrid service more paths to
# confirm "instantly available" or finish caching quickly. A magnet a site
# already hands back fully-formed (with its own embedded trackers) is left
# as-is — this list only fills in for the ones this addon builds itself.
_GOOD_TRACKERS = [
    'udp://tracker.opentrackr.org:1337/announce',
    'udp://open.tracker.cl:1337/announce',
    'udp://tracker.openbittorrent.com:6969/announce',
    'udp://open.stealth.si:80/announce',
    'udp://tracker-udp.gbitt.info:80/announce',
    'http://ipv4announce.sktorrent.eu:6969/announce',
    'udp://tracker.torrent.eu.org:451/announce',
    'udp://evan.im:6969/announce',
    'udp://bittorrent-tracker.e-n-c-r-y-p-t.net:1337/announce',
    'http://tracker.waaa.moe:6969/announce',
    'https://tracker.leechshield.link:443/announce',
    'udp://tracker.corpscorp.online:80/announce',
    'https://tracker.7471.top:443/announce',
    'https://tracker.lenition.de:443/announce',
    'udp://tracker.nyaa.net:6969/announce',
    'udp://tracker.cn.nyaa.net:6969/announce',
    'udp://tracker.qu.ax:6969/announce',
    'udp://tracker.0x7c0.com:6969/announce',
    'udp://martin-gebhardt.eu:25/announce',
    'udp://torrent.tracker.durukanbal.com:6969/announce',
    'udp://tr4ck3r.duckdns.org:6969/announce',
    'http://wegkxfcivgx.ydns.eu:80/announce',
    'udp://ns575949.ip-51-222-82.net:6969/announce',
    'https://004430.xyz:443/announce',
    'http://bt1.archive.org:6969/announce',
    'udp://open.ftorrent.com:443/announce',
    'udp://torrentclub.online:1984/announce',
    'https://tracker.foreverpirates.co:443/announce',
    'udp://tracker.dler.com:6969/announce',
    'https://t.213891.xyz:443/announce',
    'https://tracker.nekomi.cn:443/announce',
    'udp://tracker.aruku.ovh:8081/announce',
    'udp://tracker.teambelgium.net:6969/announce',
    'udp://tracker.nexusstream.eu:6969/announce',
    'http://tracker.dhitechnical.com:6969/announce',
    'https://tracker.pmman.tech:443/announce',
    'https://tracker.zhuqiy.com:443/announce',
    'http://tracker.mywaifu.best:6969/announce',
    'udp://tracker.k.vu:6969/announce',
    'udp://mail.segso.net:6969/announce',
    'udp://tracker.peerfect.org:6969/announce',
    'udp://tracker.opentrackr.com:6969/announce',
    'udp://tracker.ilibr.org:6969/announce',
    'https://tracker.gcrenwp.top:443/announce',
    'udp://tracker.breizh.pm:6969/announce',
    'udp://tracker.gmi.gd:6969/announce',
    'udp://tracker.farted.net:6969/announce',
    'http://tracker.renfei.net:8080/announce',
    'http://bt2.archive.org:6969/announce',
    'udp://tracker.cynma.tv:6969/announce',
    'udp://obey.torrentonline.cc:42069/announce',
    'udp://whybother.torrentonline.cc:42069/announce',
]


def _make_magnet(info_hash, name=''):
    dn = ('&dn=' + _req.utils.quote(name)) if name and _req else ''
    tr = ''.join('&tr=' + t for t in _GOOD_TRACKERS)
    return 'magnet:?xt=urn:btih:%s%s%s' % (info_hash.lower(), dn, tr)


def _bencode_skip(data, i):
    """Return the index just past the bencoded value starting at offset i
    (int/list/dict/string, generic — doesn't care which)."""
    c = data[i:i + 1]
    if c == b'i':
        return data.index(b'e', i) + 1
    if c in (b'l', b'd'):
        j = i + 1
        while data[j:j + 1] != b'e':
            j = _bencode_skip(data, j)
        return j + 1
    colon = data.index(b':', i)
    length = int(data[i:colon])
    return colon + 1 + length


def _torrent_info_hash(torrent_bytes):
    """SHA1 info_hash of a raw .torrent file's bencoded 'info' dict --
    bencode is byte-exact/canonical, so hashing the original raw slice
    (found by walking the structure, not re-encoding a parsed dict) is
    equivalent to the standard BitTorrent info_hash computation."""
    idx = torrent_bytes.find(b'4:info')
    if idx == -1:
        return None
    start = idx + len(b'4:info')
    try:
        end = _bencode_skip(torrent_bytes, start)
    except Exception:
        return None
    import hashlib
    return hashlib.sha1(torrent_bytes[start:end]).hexdigest()


# ── YTS ──────────────────────────────────────────────────────────────────────

_YTS_DOMAINS = [
    'https://yts.lt',
    'https://yts.mx',
    'https://yts.proxyninja.org',
    'https://yts.lu',
    'https://www13.yts.lu',
]


def search_yts(title, year=None, limit=5, media_type='movie'):
    # YTS is a mainstream-only movie site — no adult content at all, so
    # 'adult' is deliberately excluded here too (defense-in-depth alongside
    # search_all()'s own gate, in case something else ever calls this
    # directly with media_type='adult').
    if media_type != 'movie':
        return []
    try:
        # Don't append year — YTS API is strict with full-string matching,
        # title-only gets more results (year can be checked post-fetch if needed)
        params = {'query_term': title, 'limit': limit, 'sort_by': 'seeds'}
        qs = '&'.join('%s=%s' % (k, v) for k, v in params.items())
        data = None
        for domain in _YTS_DOMAINS:
            data = _get_json(domain + '/api/v2/list_movies.json?' + qs)
            if data and data.get('status') == 'ok':
                break
            data = None
        if not data:
            return []
        movies = data.get('data', {}).get('movies') or []
        results = []
        for movie in movies:
            for tor in movie.get('torrents', []):
                ih = tor.get('hash', '')
                if not ih:
                    continue
                quality = tor.get('quality', '')
                if not _meets_quality(quality, media_type):
                    continue
                results.append({
                    'title':     movie.get('title_english') or movie.get('title', ''),
                    'year':      movie.get('year', ''),
                    'quality':   _extract_quality(quality) or quality,
                    'info_hash': ih,
                    'magnet':    _make_magnet(ih, movie.get('title', '')),
                    'seeds':     tor.get('seeds', 0),
                    'size':      tor.get('size', ''),
                    'source':    'YTS',
                })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] YTS error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Zooqle (movies-only meta-index — its own detail pages link out to the
# actual torrent host, e.g. yts.mx, with the info hash right there in the
# download URL; no distinct "adult" section exists on the site at all, so
# it's wired in unconditionally like TPB/Knaben/etc rather than gated to
# a media_type, same as those) ────────────────────────────────────────────────

ZOOQLE_BASE = 'https://zooqle.app'

_RE_ZOOQLE_RESULT = re.compile(
    r'href="(https://zooqle\.app/movies/[a-z0-9-]+)"[^>]*title="([^"]{2,120})"',
    re.IGNORECASE
)
_RE_ZOOQLE_DL = re.compile(
    r'href="(https://[^"]+/torrent/download/([A-F0-9]{40}))"[\s\S]*?>([^<]{2,120})<',
    re.IGNORECASE
)


def search_zooqle(title, year=None, limit=10, media_type='movie'):
    """Zooqle — search page lists candidate movie pages; each movie page's
    own torrent table links out to the real host (yts.mx confirmed live,
    possibly others) with the 40-char info hash sitting directly in the
    download URL — no magnet or extra detail fetch needed for that part,
    just the one candidate-page fetch per matching movie."""
    if media_type not in ('movie', 'adult'):
        return []
    try:
        from urllib.parse import quote as _q
        query = re.sub(r'\s+', ' ', title).strip()
        if not query:
            return []
        # Confirmed live this endpoint either responds quickly or not at all
        # -- a query that's going to fail did so at essentially the full 12s
        # with zero results, making it the single longest pole in the whole
        # movie-search batch for no payoff. Trimmed to fail fast instead.
        search_html = _get('%s/?keyword=%s' % (ZOOQLE_BASE, _q(query)), timeout=6)
        if not search_html:
            return []

        def _nc(s):
            return re.sub(r'\s+', ' ', re.sub(r'[^a-z0-9 ]', ' ', s.lower())).strip()

        norm_query = _nc(query)
        seen_urls = set()
        candidates = []
        for page_url, name in _RE_ZOOQLE_RESULT.findall(search_html):
            if page_url in seen_urls:
                continue
            seen_urls.add(page_url)
            core = _nc(name)
            if not core:
                continue
            if norm_query in core or core in norm_query:
                candidates.append(page_url)
            if len(candidates) >= 4:
                break

        if not candidates:
            return []

        results = []
        from concurrent.futures import ThreadPoolExecutor

        def _fetch_page(page_url):
            html = _get(page_url, timeout=10)
            out = []
            if not html:
                return out
            for dl_url, info_hash, label in _RE_ZOOQLE_DL.findall(html):
                out.append({
                    'title':     label.strip(),
                    'info_hash': info_hash.lower(),
                    'magnet':    _make_magnet(info_hash, label.strip()),
                    'seeds':     0,
                    'size':      '',
                    'source':    'Zooqle',
                })
            return out

        with ThreadPoolExecutor(max_workers=len(candidates)) as pool:
            for page_results in pool.map(_fetch_page, candidates):
                results.extend(page_results)
                if len(results) >= limit:
                    break
        return results[:limit]
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Zooqle error: %s' % e, xbmc.LOGWARNING)
        return []


# ── KONTRAST (small curated x265 release group — movies + full TV season
# packs, no per-episode releases). Its own HTML search page AND even its
# RSS feed's `?search=` query param are behind a genuine Cloudflare JS
# challenge (confirmed live both ways), but the bare unfiltered feed
# (/feed/rss) is NOT protected and hands back a rolling ~30-item window of
# fully-resolved items -- title, category, infoHash and a ready-to-use
# magnet URI, no per-item detail fetch or bencode parsing needed at all.
# Since server-side filtering is blocked, this fetches the whole feed once
# and matches locally -- low hit rate per search (only catches whatever
# KONTRAST happens to have released in roughly the last ~12 days), but
# zero extra cost when it does hit. ──────────────────────────────────────────

KONTRAST_BASE = 'https://kontrast.top'

_RE_KONTRAST_ITEM = re.compile(
    r'<item><title>\[[^\]]*\]\s*([^<(]+?)(?:\s*\([^)]*\))?</title>'
    r'<category>([^<]+)</category>.*?'
    r'<torrent:infoHash>([a-fA-F0-9]{40})</torrent:infoHash>'
    r'<torrent:magnetURI><!\[CDATA\[(magnet:[^\]]+)\]\]></torrent:magnetURI>',
    re.IGNORECASE
)


def search_kontrast(title, year=None, limit=10, media_type='movie'):
    """KONTRAST — fetches the site's own unfiltered RSS feed (its `?search=`
    param is Cloudflare-walled just like the HTML search page) and matches
    the requested title locally against whatever's currently in the
    feed's rolling window.

    The feed itself was never cached — every single search re-fetched the
    same ~30-item, ~75KB feed from scratch, even for a second title looked
    up moments after the first. Confirmed live the feed only actually
    shifts a few times a day at most (it's the group's own release
    cadence, not a live-updating page), so a short cache here costs
    nothing in real freshness while turning every search after the first
    one in a session into a pure local-match pass instead of a repeat
    network round-trip."""
    if media_type not in ('movie', 'tv'):
        return []
    try:
        xml = _cache.get('kontrast_feed') if _HAS_CACHE else None
        if xml is None:
            xml = _get(KONTRAST_BASE + '/feed/rss', timeout=8)
            if _HAS_CACHE and xml:
                _cache.set('kontrast_feed', xml, 900)
        if not xml:
            return []

        def _nc(s):
            return re.sub(r'\s+', '', re.sub(r'[^a-z0-9]', ' ', s.lower())).strip()

        norm_title = _nc(title)
        if not norm_title:
            return []

        results = []
        for raw_name, category, info_hash, magnet in _RE_KONTRAST_ITEM.findall(xml):
            if len(results) >= limit:
                break
            cat_media = 'tv' if category.strip().lower() == 'tv' else 'movie'
            if cat_media != media_type:
                continue
            name = raw_name.strip()
            if norm_title not in _nc(name):
                continue
            # Season packs don't carry the show's premiere year in the
            # filename, so only enforce a year match for movies.
            if year and media_type == 'movie' and str(year) not in name:
                continue
            if not _meets_quality(name, media_type):
                continue
            results.append({
                'title':     name,
                'year':      year or '',
                'quality':   _extract_quality(name),
                'info_hash': info_hash.lower(),
                'magnet':    magnet.replace('&amp;', '&'),
                'seeds':     0,
                'size':      '',
                'source':    'KONTRAST',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] KONTRAST error: %s' % e, xbmc.LOGWARNING)
        return []


# ── The Pirate Bay ────────────────────────────────────────────────────────────

TPB_BASE = 'https://apibay.org'


def search_tpb(title, year=None, category=200, limit=10, media_type='movie'):
    try:
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        if _req:
            query = _req.utils.quote(query)
        data = _get_json(TPB_BASE + '/q.php?q=%s&cat=%d' % (query, category), timeout=8)
        if not data or not isinstance(data, list):
            return []
        results = []
        for item in data[:limit]:
            ih = item.get('info_hash', '')
            if not ih or ih == '0000000000000000000000000000000000000000':
                continue
            name = item.get('name', '')
            if not _meets_quality(name, media_type):
                continue
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    _make_magnet(ih, name),
                'seeds':     int(item.get('seeders', 0)),
                'size':      item.get('size', ''),
                'source':    'TPB',
            })
        results.sort(key=lambda x: x['seeds'], reverse=True)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] TPB error: %s' % e, xbmc.LOGWARNING)
        return []


# ── 1337x (mirror rotation + Cloudflare bypass) ───────────────────────────────
# The old 1337x.* domains (.se/.tw/.pro/.to/.st/.ws/.gd) are all dead or
# reduced to parked "alternative domain" stub pages now — 1337x.tw's own
# stub explicitly points to 1377x.to (extra 7) and 1337xx.to (double x) as
# the real current mirrors, confirmed live. The site itself was also
# restructured: old code's /sort-category-search/.../seeders/desc/1/ search
# path and coll-1/coll-2 class-based row parsing both 404/no-match now —
# real search is GET /srch?search=query, results are plain <td class="...
# seeds">/<td class="... size ..."> table cells, and the health-check path
# is just / (old /home/ 404s on these mirrors' template).

# Re-verified live 2026-08-16 against this exact health-check (real
# search form present, not just a 200 status): only 1377x.to and 1337xx.to
# still pass. 1337x.se/.tw are both now parked stub pages (200 but no
# search form — 1337xto.to, a domain a user asked about adding, is the
# same story: it's a landing page whose own links all point to 1337xx.to,
# not an independent index, so nothing to add there). 1337x.to/.st now
# 403, .ws redirects through an ad-decoy domain, .pro times out, .gd
# doesn't resolve at all — all five removed rather than left in as dead
# weight the health-check loop pays a real timeout to rule out every time
# the 1-hour mirror cache is cold.
_LEET_MIRRORS = [
    '1377x.to', '1337xx.to', 'www.1377x.is',
    # Proxy front-end, not a separate index — last resort only, if every
    # real mirror above is down.
    '1337x-to.hashhackers.com',
]
_leet_working = {}  # {'url': ..., 'ts': ...}

_RE_LEET_MAGNET = re.compile(r'href="(magnet:[^"]+)"', re.IGNORECASE)


def _get_leet_base():
    """Return a working 1337x mirror, cached for 1 hour."""
    cached = _leet_working.get('url')
    ts = _leet_working.get('ts', 0)
    if cached and (time.time() - ts) < 3600:
        return cached

    for mirror in _LEET_MIRRORS:
        try:
            # The hashhackers proxy is already a full subdomain host — prepending
            # 'www.' the way bare "1337x.se"-style domains need would break it.
            no_www_prefix = mirror.startswith('www.') or 'hashhackers' in mirror
            url = 'https://%s' % mirror if no_www_prefix else 'https://www.%s' % mirror
            html = _get(url + '/', timeout=7, cf=True)
            # Several "mirrors" (1337x.tw confirmed live) are just parked
            # stub pages pointing at OTHER domains, still mentioning
            # "1337x" and even "alternative domain" themselves — the real,
            # functional mirrors ALSO casually mention alternate domains on
            # their own homepage, so that phrase isn't a reliable way to
            # tell them apart. The real search form (action="/srch") only
            # exists on an actually-working mirror, confirmed live against
            # both a stub (absent) and the real site (present).
            if html and 'action="/srch"' in html.lower():
                _leet_working['url'] = url
                _leet_working['ts'] = time.time()
                xbmc.log('[Starfleet/Torrents] 1337x using mirror: %s' % url, xbmc.LOGINFO)
                return url
        except Exception:
            continue

    fallback = 'https://www.1377x.to'
    xbmc.log('[Starfleet/Torrents] 1337x all mirrors failed, using: %s' % fallback, xbmc.LOGWARNING)
    return fallback


def _leet_get_magnet(path, base):
    try:
        html = _get(base + path, timeout=8, cf=True)
        m = _RE_LEET_MAGNET.search(html)
        if m:
            return m.group(1).split('&tr=')[0]
    except Exception:
        pass
    return ''


_RE_LEET_ROW = re.compile(
    r'href="(/torrent/\d+/[^"]+/)">([^<]+)</a></td>\s*'
    r'<td[^>]*seeds">(\d+)</td>\s*'
    r'<td[^>]*leeches">\d+</td>\s*'
    r'<td[^>]*coll-date">[^<]*</td>\s*'
    r'<td[^>]*size[^>]*>([^<]+)</td>',
    re.IGNORECASE
)


def search_1337x(title, year=None, limit=5, media_type='movie'):
    try:
        base = _get_leet_base()
        query = title.replace(' ', '+')
        if year and media_type != 'adult':
            query += '+' + str(year)

        url = '%s/srch?search=%s' % (base, query)
        html = _get(url, timeout=10, cf=True)
        if not html:
            return []

        candidates = []
        for m in _RE_LEET_ROW.finditer(html):
            if len(candidates) >= limit:
                break
            path, name, seeds, size = m.group(1), m.group(2).strip(), m.group(3), m.group(4).strip()
            if not _meets_quality(name, media_type):
                continue
            candidates.append((path, name, int(seeds), size))

        if not candidates:
            return []

        from concurrent.futures import ThreadPoolExecutor, as_completed as _ac2
        results = []
        with ThreadPoolExecutor(max_workers=min(len(candidates), 15)) as pool:
            fmap = {pool.submit(_leet_get_magnet, path, base): (name, seeds, size)
                    for path, name, seeds, size in candidates}
            for fut in _ac2(fmap, timeout=12):
                name, seeds, size = fmap[fut]
                try:
                    magnet = fut.result()
                except Exception:
                    magnet = ''
                if not magnet:
                    continue
                ih_m = re.search(r'urn:btih:([a-fA-F0-9]{40})', magnet)
                results.append({
                    'title':     name,
                    'year':      '',
                    'quality':   _extract_quality(name),
                    'info_hash': ih_m.group(1).lower() if ih_m else '',
                    'magnet':    magnet,
                    'seeds':     seeds,
                    'size':      size,
                    'source':    '1337x',
                })
        return sorted(results, key=lambda x: x['seeds'], reverse=True)
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] 1337x error: %s' % e, xbmc.LOGWARNING)
        return []


# ── EZTV (TV shows) ───────────────────────────────────────────────────────────

EZTV_BASE = 'https://eztvx.to'


def _search_eztv_api(imdb_id, limit=5):
    """
    EZTV official API by imdb_id — no Cloudflare in front of this endpoint
    (unlike /search/{slug}, which is CF-403'd), so this is the reliable path
    whenever an imdb_id is known. Returns every episode EZTV has for the show;
    search_all()'s shared title-phrase filter (which already includes the
    S/E marker in the query for TV) narrows it down to the requested episode,
    the same way it narrows Torrentio's per-show results.
    """
    try:
        imdb_num = re.sub(r'^tt', '', str(imdb_id or ''))
        if not imdb_num.isdigit():
            return []
        import json as _json
        url = '%s/api/get-torrents?limit=100&page=1&imdb_id=%s' % (EZTV_BASE, imdb_num)
        raw = _get(url, timeout=8)
        if not raw:
            return []
        data = _json.loads(raw)
        torrents = data.get('torrents') or []
        results = []
        for t in torrents:
            name = t.get('title') or t.get('filename') or ''
            if not name or not _meets_quality(name, 'tv'):
                continue
            ih = (t.get('hash') or '').lower()
            if not ih:
                continue
            magnet = t.get('magnet_url') or _make_magnet(ih, name)
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    magnet,
                'seeds':     int(t.get('seeds', 0) or 0),
                'size':      t.get('size_bytes', ''),
                'source':    'EZTV',
            })
        results.sort(key=lambda x: x['seeds'], reverse=True)
        return results[:limit]
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] EZTV API error: %s' % e, xbmc.LOGWARNING)
        return []


def search_eztv(title, year=None, limit=5, imdb_id=None):
    """
    EZTV: official API by imdb_id first (reliable, no Cloudflare). Falls back
    to the /search/{slug} HTML scrape (CF-protected, needs cloudscraper) only
    when no imdb_id is available — the API doesn't accept free-text keywords.
    """
    if imdb_id:
        results = _search_eztv_api(imdb_id, limit)
        if results:
            return results
    try:
        slug = re.sub(r'[^a-z0-9]+', '-', title.lower()).strip('-')
        url = '%s/search/%s' % (EZTV_BASE, slug)
        cs = _get_cf_session()
        html = (cs.get(url, timeout=10).text if cs else
                _get(url, timeout=10, cf=True))
        if not html:
            return []
        # Rows: <tr class="forum_header_border">
        magnets = re.findall(r'(magnet:\?xt=urn:btih:[a-fA-F0-9]{40}[^"\'<\s]*)', html)
        names   = re.findall(r'class="epinfo"[^>]*>([^<]+)</a>', html)
        seeds_all = re.findall(r'class="[^"]*seeds[^"]*"[^>]*>(\d+)<', html, re.IGNORECASE)
        results = []
        for i, mag in enumerate(magnets):
            ih_m = re.search(r'btih:([a-fA-F0-9]{40})', mag, re.IGNORECASE)
            if not ih_m:
                continue
            ih   = ih_m.group(1).lower()
            name = names[i] if i < len(names) else ''
            if not name:
                dn = re.search(r'[&?]dn=([^&"\'<\s]+)', mag)
                name = _req.utils.unquote(dn.group(1)).replace('+', ' ') if dn and _req else ih
            seeds = int(seeds_all[i]) if i < len(seeds_all) else 0
            if not _meets_quality(name, 'tv'):
                continue
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    mag,
                'seeds':     seeds,
                'size':      '',
                'source':    'EZTV',
            })
            if len(results) >= limit:
                break
        results.sort(key=lambda x: x['seeds'], reverse=True)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] EZTV error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Bitsearch ─────────────────────────────────────────────────────────────────

BITSEARCH_BASE = 'https://bitsearch.eu'  # .to confirmed dead/empty live; .eu is the current real site
_RE_BS_SIZE = re.compile(r'(\d+(?:\.\d+)?)\s*(GB|MB|GiB|MiB)', re.IGNORECASE)


def search_bitsearch(title, year=None, limit=5, media_type='movie'):
    """
    Bitsearch scraper. Anchors on magnet: links rather than CSS card classes
    so it survives HTML/CSS redesigns on bitsearch.to.
    """
    try:
        import html as _html
        query = title
        # No year in query — title-only gets more results
        if _req:
            query = _req.utils.quote(query)
        url = '%s/search?q=%s&sort=seeders' % (BITSEARCH_BASE, query)
        cs = _get_cf_session()
        html_raw = (cs.get(url, timeout=10).text if cs else _get(url, timeout=10))
        if not html_raw:
            return []
        text = _html.unescape(html_raw)

        # Split on magnet: links — one per result card, CSS-class-independent
        parts = re.split(r'(magnet:\?[^"\'<\s]+)', text)
        # parts = [pre, magnet1, after1, magnet2, after2, ...]
        results = []
        i = 1
        while i < len(parts) - 1 and len(results) < limit:
            raw_magnet = parts[i].replace('&amp;', '&')
            before = parts[i - 1][-800:]
            after  = parts[i + 1][:400]
            context = before + after
            i += 2

            ih_m = re.search(r'btih:([a-fA-F0-9]{40})', raw_magnet, re.IGNORECASE)
            if not ih_m:
                continue
            info_hash = ih_m.group(1).lower()

            # Name: prefer &dn= from magnet (already URL-decoded title)
            name = ''
            dn_m = re.search(r'[&?]dn=([^&"\'<\s]+)', raw_magnet)
            if dn_m and _req:
                name = _req.utils.unquote(dn_m.group(1)).replace('+', ' ').strip()
            if not name:
                # Fall back: nearest heading/link text before the magnet
                t_m = re.search(
                    r'<(?:h\d|a)\b[^>]*>\s*(?:<[^>]+>)?\s*([^<]{5,80}?)\s*(?:</[^>]+>)?\s*</(?:h\d|a)>',
                    before, re.IGNORECASE | re.DOTALL
                )
                if t_m:
                    name = re.sub(r'<[^>]+>', '', t_m.group(1)).strip()
                    name = re.sub(r'\s+', ' ', name)
            if not name or not _meets_quality(name, media_type):
                continue

            seeds = 0
            s_m = re.search(r'(\d+)\s*[<\s]*(?:seeder|seed)\b', context, re.IGNORECASE)
            if s_m:
                seeds = int(s_m.group(1))

            size = ''
            z_m = _RE_BS_SIZE.search(context)
            if z_m:
                size = z_m.group(0)

            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': info_hash,
                'magnet':    raw_magnet,
                'seeds':     seeds,
                'size':      size,
                'source':    'Bitsearch',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Bitsearch error: %s' % e, xbmc.LOGWARNING)
        return []


# ── TorrentGalaxy (CF bypass) ────────────────────────────────────────────────

_TGX_MIRRORS = [
    'torrentgalaxy-official.is', 'torrentgalaxy.one', 'torrentgalaxy.info',
    'torrentgalaxy.hair', 'torrentgalaxy.mx', 'torrentgalaxy.to', 'tgx.rs',
]
_tgx_working = {}

_RE_TGX_MAGNET = re.compile(r'a\s+href="(magnet:[^"]+)"', re.IGNORECASE)
_RE_TGX_SIZE   = re.compile(r'(\d+(?:[,.]\d+)?)\s*(GiB|MiB|GB|MB)', re.IGNORECASE)
_TGX_SKIP_LANG = re.compile(r'\b(FRENCH|TRUEFRENCH|ITALIAN|Ita|SPANISH|DUBBED|LAT|Dublado)\b',
                             re.IGNORECASE)


def _get_tgx_base():
    cached = _tgx_working.get('url')
    ts = _tgx_working.get('ts', 0)
    if cached and (time.time() - ts) < 3600:
        return cached
    for mirror in _TGX_MIRRORS:
        try:
            url = 'https://%s' % mirror
            html = _get(url + '/torrents.php', timeout=7, cf=True)
            if html and 'torrent' in html.lower():
                _tgx_working['url'] = url
                _tgx_working['ts'] = time.time()
                xbmc.log('[Starfleet/Torrents] TGX using mirror: %s' % url, xbmc.LOGINFO)
                return url
        except Exception:
            continue
    return 'https://' + _TGX_MIRRORS[0]


def search_torrentgalaxy(title, year=None, limit=5, media_type='movie'):
    try:
        base = _get_tgx_base()
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        if _req:
            query = _req.utils.quote(query)
        url = '%s/torrents.php?search=%s' % (base, query)
        html_raw = _get(url, timeout=10, cf=True)
        if not html_raw:
            return []
        results = []
        for row in re.finditer(r'<div[^>]+class="[^"]*tgxtable[^"]*"[^>]*>(.*?)</div>',
                                html_raw, re.IGNORECASE | re.DOTALL):
            if len(results) >= limit:
                break
            row_text = row.group(1)
            mag_m = _RE_TGX_MAGNET.search(row_text)
            if not mag_m:
                continue
            # Pulled straight from an HTML href attribute, so its '&'s are
            # still HTML-escaped ("&amp;dn=...") — left as-is, the dn=
            # extraction below never matches (it looks for a literal '&'
            # right before "dn="), silently falling back to the info hash
            # as the "title" instead of the real torrent name.
            import html as _html_mod
            magnet = _html_mod.unescape(mag_m.group(1))
            if _TGX_SKIP_LANG.search(magnet):
                continue
            ih_m = re.search(r'btih:([a-fA-F0-9]{40})', magnet, re.IGNORECASE)
            if not ih_m:
                continue
            info_hash = ih_m.group(1).lower()
            dn_m = re.search(r'[&?]dn=([^&]+)', magnet)
            name = _req.utils.unquote(dn_m.group(1)).replace('+', ' ') if dn_m and _req else info_hash
            if not _meets_quality(name, media_type):
                continue
            z_m = _RE_TGX_SIZE.search(row_text)
            size = z_m.group(0) if z_m else ''
            seeds_m = re.search(r'<span[^>]+>(\d+)</span>\s*seeders', row_text, re.IGNORECASE)
            seeds = int(seeds_m.group(1)) if seeds_m else 0
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': info_hash,
                'magnet':    magnet,
                'seeds':     seeds,
                'size':      size,
                'source':    'TGX',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] TorrentGalaxy error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Knaben meta-search (movies / TV / adult) ──────────────────────────────────

KNABEN_API = 'https://api.knaben.org/v1'
# Knaben category filters are unreliable (returns empty when set) — skip them
# and rely on the title/word filter in search_all to remove wrong-media results.

_KNABEN_HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
    'Accept':       'application/json',
    'Content-Type': 'application/json',
}


def search_knaben(title, year=None, media_type='movie', limit=10):
    try:
        import json as _json
        query = title
        if year and media_type not in ('adult',):
            query = '%s %s' % (title, year)

        body = {'query': query, 'order_by': 'seeders', 'take': max(limit * 3, 30)}
        # No category filter — Knaben category IDs are broken (return empty)
        # Use a fresh Session per call: the shared _sess() pool causes empty responses
        # for this large JSON endpoint (211KB response body).
        if not _req:
            return []
        with _req.Session() as _ks:
            # Confirmed live this endpoint either responds well under a
            # couple seconds or doesn't respond at all -- a query that's
            # going to time out did so at essentially the full 12s with zero
            # results, making it consistently the single longest pole in the
            # whole batch for no payoff. Trimmed so a dead query fails fast
            # instead of eating a third of the batch's total time for nothing.
            r = _ks.post(KNABEN_API, json=body, headers=_KNABEN_HEADERS, timeout=6)
        if r.status_code >= 400:
            return []
        if not r.text or not r.text.strip():
            xbmc.log('[Starfleet/Torrents] Knaben: empty response', xbmc.LOGWARNING)
            return []
        data = r.json()
        # API returns 'hits' (old) or 'result' (new) depending on version
        hits = data.get('hits') or data.get('result') or data.get('results') or []
        results = []
        for entry in hits:
            if len(results) >= limit:
                break
            name = entry.get('title', '')
            if not name or not _meets_quality(name, media_type):
                continue
            # Knaben marks games/software with [DL] prefix — skip for movie/tv searches
            if media_type in ('movie', 'tv') and name.startswith('[DL]'):
                continue
            ih = (entry.get('hash') or '').lower()
            if not ih or len(ih) != 40:
                continue
            magnet = entry.get('magnetUrl') or _make_magnet(ih, name)
            seeds  = int(entry.get('seeders') or 0)
            b = entry.get('bytes') or 0
            size = ''
            if b >= 1_073_741_824:
                size = '%.1f GB' % (b / 1_073_741_824)
            elif b >= 1_048_576:
                size = '%.0f MB' % (b / 1_048_576)
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    magnet,
                'seeds':     seeds,
                'size':      size,
                'source':    'Knaben',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Knaben error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Torrentio (IMDB-based Stremio API) ───────────────────────────────────────

TORRENTIO_BASE = 'https://torrentio.strem.fun'
_RE_TIO_INFO = re.compile(r'👤.*')


# ── YourBitTorrent ────────────────────────────────────────────────────────────
# Confirmed live 2026-08-15: this function existed but was never actually
# wired into search_all()'s tasks dict below (a real orphaned-function bug,
# same class as an earlier one found this session) - AND the site itself
# has since moved from yourbittorrent2.com to yourbittorrent.com with a
# redesigned page (different result-link markup, hash/size now in a
# labeled key/value grid instead of <kbd>/card-title tags). Both issues
# fixed together: regexes rewritten against the current live markup,
# function now actually called below.

YBT_BASE = 'https://yourbittorrent.com'
_RE_YBT_LINK = re.compile(r'href="(/torrent/[^"]+)"', re.IGNORECASE)
_RE_YBT_HASH = re.compile(r'<div class="k">Infohash</div><div class="v"[^>]*>([a-fA-F0-9]{40})', re.IGNORECASE)
_RE_YBT_NAME = re.compile(r'<title>([^<]+)</title>', re.IGNORECASE)
_RE_YBT_SIZE = re.compile(r'<div class="k">Size</div><div class="v"[^>]*>([^<]+)', re.IGNORECASE)
_RE_YBT_LANG = re.compile(r'\b(french|italian|spanish|truefrench|dublado|dubbed)\b', re.IGNORECASE)


def search_yourbittorrent(title, year=None, limit=5, media_type='movie'):
    try:
        from concurrent.futures import ThreadPoolExecutor
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        from urllib.parse import quote_plus as _qp
        query_enc = _qp(query).replace('+', '-')
        html_raw = _get('%s?q=%s' % (YBT_BASE, query_enc), timeout=8)
        if not html_raw:
            return []
        links = _RE_YBT_LINK.findall(html_raw)[:limit]

        def _fetch(link):
            try:
                detail = _get(YBT_BASE + link, timeout=8)
                ih_m = _RE_YBT_HASH.search(detail)
                nm_m = _RE_YBT_NAME.search(detail)
                if not ih_m or not nm_m:
                    return None
                ih = ih_m.group(1).lower()
                name = nm_m.group(1).strip()
                if name.endswith(' Torrent Download'):
                    name = name[:-len(' Torrent Download')]
                if not _meets_quality(name, media_type):
                    return None
                if _RE_YBT_LANG.search(name):
                    return None
                sz_m = _RE_YBT_SIZE.search(detail)
                size = sz_m.group(1).strip() if sz_m else ''
                return {
                    'title': name, 'year': '', 'quality': _extract_quality(name),
                    'info_hash': ih, 'magnet': _make_magnet(ih, name),
                    'seeds': 0, 'size': size, 'source': 'YourBT',
                }
            except Exception:
                return None

        if not links:
            return []
        results = []
        with ThreadPoolExecutor(max_workers=max(min(len(links), limit), 1)) as pool:
            for r in pool.map(_fetch, links, timeout=10):
                if r and len(results) < limit:
                    results.append(r)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] YourBitTorrent error: %s' % e, xbmc.LOGWARNING)
        return []


# ── FileMood (DHT file-search index) ─────────────────────────────────────────
# filemood.com is a general DHT/file index (not movie-specific — its own
# homepage claims "1,948,539,407 files ... 64,940,387 entries"), same family
# as Bitsearch/TPB. Cloudflare-fronted (real cf-ray headers, a "Cloudflare
# challenge-platform" analytics beacon on every page), but confirmed live
# 2026-08-16 that the actual search results ARE present in a plain
# unauthenticated GET's HTML with no CF bypass needed at all — the beacon is
# just passive bot-management telemetry, not a blocking JS challenge. (A
# real dead end WAS found immediately next to this one: the #result-main-left
# div this page also renders is permanently empty for every client, browser
# or scraper alike — a leftover/decoy container, not a bot-cloaking tell.
# The real results live in #result-main-center, confirmed by diffing actual
# browser DOM output against this scraper's own plain curl/cloudscraper
# fetches, which were otherwise byte-identical.)
# Each top-level result's own download-page URL already ends in
# "-<40-char-info-hash>.html" — the info hash is sitting directly in the
# HTML with no separate detail-page fetch or bencode parsing needed, same
# shortcut Zooqle uses. The two numbers FileMood shows per result
# (e.g. "683/283") aren't standard tracker seed/leech — how-to page confirms
# this is a DHT crawler with no live tracker connection — but the first
# number tracks the same "how many peers has our crawler seen recently"
# popularity signal seeds normally represent, so it's used as the sort/
# display 'seeds' value the same way.
FILEMOOD_BASE = 'https://filemood.com'

_RE_FILEMOOD_ROW = re.compile(
    r'<td class="dn-title">\s*<p class="filedir">\s*'
    r'<a href="(/[^"]+?-([a-fA-F0-9]{40})\.html)"[^>]*>(.*?)</a>\s*</p>\s*</td>\s*'
    r'<td class="dn-status">\s*<p class="text"[^>]*><b>(\d+)/(\d+)</b></p>\s*</td>\s*'
    r'<td class="dn-size">\s*<p class="text"[^>]*><b>([^<]+)</b>',
    re.IGNORECASE | re.DOTALL
)


def search_filemood(title, year=None, limit=5, media_type='movie'):
    try:
        from urllib.parse import quote as _q
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        query = re.sub(r'\s+', ' ', query).strip()
        if not query:
            return []
        html = _get('%s/result?q=%s' % (FILEMOOD_BASE, _q(query)), timeout=10)
        if not html:
            return []

        results = []
        for href, info_hash, raw_title, n1, n2, size in _RE_FILEMOOD_ROW.findall(html):
            if len(results) >= limit:
                break
            name = re.sub(r'<[^>]+>', '', raw_title)
            name = re.sub(r'\s+', ' ', name).strip()
            if not name or not _meets_quality(name, media_type):
                continue
            ih = info_hash.lower()
            results.append({
                'title':     name,
                'year':      year or '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    _make_magnet(ih, name),
                'seeds':     int(n1),
                'size':      size.strip(),
                'source':    'FileMood',
            })
        results.sort(key=lambda x: x['seeds'], reverse=True)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] FileMood error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Torrentdownload.info (Tordl) ──────────────────────────────────────────────

TORDL_BASE = 'https://www.torrentdownload.info'
_RE_TORDL_LINK = re.compile(r'href="/([a-fA-F0-9]{40})/([^"]+)"', re.IGNORECASE)
_RE_TORDL_SIZE = re.compile(r'(\d+(?:\.\d+)?)\s*(GB|MB|GiB|MiB)', re.IGNORECASE)


def search_tordl(title, year=None, limit=5, media_type='movie'):
    try:
        from urllib.parse import quote_plus as _qp
        query = title.lower()
        if year and media_type != 'adult':
            query = '%s %s' % (query, year)
        url = '%s/search?q=%s' % (TORDL_BASE, _qp(query))
        html = _get(url, timeout=10)
        if not html:
            return []
        results = []
        for m in _RE_TORDL_LINK.finditer(html):
            if len(results) >= limit:
                break
            ih = m.group(1).lower()
            name = m.group(2).replace('+', ' ').replace('-', ' ')
            name = re.sub(r'[_%]', ' ', name).strip()
            if not name or not _meets_quality(name, media_type):
                continue
            # Size is approximate from listing
            magnet = _make_magnet(ih, name)
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    magnet,
                'seeds':     0,
                'size':      '',
                'source':    'Tordl',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Tordl error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Bitlord ───────────────────────────────────────────────────────────────────

BITLORD_BASE = 'http://www.bitlordsearch.com'
_RE_BL_MAG  = re.compile(
    r'class="btn btn-default magnet-button[^"]*"[^>]+href="([^"]+)"', re.IGNORECASE
)
_RE_BL_SIZE = re.compile(r'<td class="size">(\d+)</td>', re.IGNORECASE)
_RE_BL_LANG = re.compile(r'\b(french|italian|spanish|truefrench|dublado|dubbed)\b', re.IGNORECASE)


def search_bitlord(title, year=None, limit=5, media_type='movie'):
    try:
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        if _req:
            query = _req.utils.quote(query)
        html_raw = _get('%s/search?q=%s' % (BITLORD_BASE, query), timeout=10)
        if not html_raw:
            return []
        magnets = _RE_BL_MAG.findall(html_raw)
        sizes   = _RE_BL_SIZE.findall(html_raw)
        results = []
        for i, mag in enumerate(magnets):
            if len(results) >= limit:
                break
            mag = mag.replace('&amp;', '&').split('&tr=')[0]
            if 'magnet' not in mag:
                continue
            dn_m = re.search(r'&dn=([^&]+)', mag)
            name = _req.utils.unquote(dn_m.group(1)).replace('+', ' ') if dn_m and _req else ''
            if not name or not _meets_quality(name, media_type):
                continue
            if _RE_BL_LANG.search(name):
                continue
            ih_m = re.search(r'btih:([a-fA-F0-9]{40})', mag, re.IGNORECASE)
            info_hash = ih_m.group(1).lower() if ih_m else ''
            size = ''
            if i < len(sizes):
                try:
                    b = int(sizes[i])
                    if b >= 1_073_741_824:
                        size = '%.1f GB' % (b / 1_073_741_824)
                    elif b >= 1_048_576:
                        size = '%.0f MB' % (b / 1_048_576)
                except Exception:
                    pass
            results.append({
                'title': name, 'year': '', 'quality': _extract_quality(name),
                'info_hash': info_hash, 'magnet': mag,
                'seeds': 0, 'size': size, 'source': 'Bitlord',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Bitlord error: %s' % e, xbmc.LOGWARNING)
        return []


# ── MagnetDL ──────────────────────────────────────────────────────────────────

MAGNETDL_BASE = 'https://www.magnetdl.hair'
_RE_MDL_ROW  = re.compile(
    r'href="(/([a-fA-F0-9]{40})/([^"]+))"', re.IGNORECASE
)


def search_magnetdl(title, year=None, limit=5, media_type='movie'):
    """MagnetDL — magnets are embedded in search-result URLs, no per-page fetch."""
    try:
        from urllib.parse import quote as _q2
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        slug = re.sub(r'[^\w\s-]', '', query.lower()).strip()
        slug = re.sub(r'[\s_]+', '-', slug)
        first = slug[0] if slug else 'm'
        url = '%s/%s/%s/' % (MAGNETDL_BASE, first, slug)
        html_raw = _get(url, timeout=10)
        if not html_raw:
            return []
        results = []
        seen_hashes = set()
        for m in _RE_MDL_ROW.finditer(html_raw):
            if len(results) >= limit:
                break
            ih = m.group(2).lower()
            if ih in seen_hashes:
                continue
            raw_name = m.group(3)
            name = re.sub(r'[_+]+', ' ', raw_name).strip()
            if not name or not _meets_quality(name, media_type):
                continue
            seen_hashes.add(ih)
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    _make_magnet(ih, name),
                'seeds':     0,
                'size':      '',
                'source':    'MagnetDL',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] MagnetDL error: %s' % e, xbmc.LOGWARNING)
        return []


# ── TorrentDownloads (RSS) ────────────────────────────────────────────────────

TDOWNLOADS_BASE = 'https://www.torrentdownloads.pro'
_RE_TD_ITEM = re.compile(
    r'<info_hash>([a-fA-F0-9]{40})</info_hash>.*?'
    r'<title>(.+?)</title>.*?'
    r'<size>(\d+)</size>.*?'
    r'<seeders>(\d+)</seeders>',
    re.IGNORECASE | re.DOTALL
)


def search_torrentdownloads(title, year=None, limit=5, media_type='movie'):
    """TorrentDownloads — RSS feed returns info_hash directly, very fast."""
    try:
        from urllib.parse import quote as _q3
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        cat = '8' if media_type == 'tv' else '4'  # 4=Movies, 8=TV
        if media_type == 'adult':
            cat = '6'
        url = '%s/rss.xml?new=1&type=search&cid=%s&search=%s' % (
            TDOWNLOADS_BASE, cat, _q3(query))
        html_raw = _get(url, timeout=10)
        if not html_raw:
            return []
        results = []
        for m in _RE_TD_ITEM.finditer(html_raw):
            if len(results) >= limit:
                break
            ih, name, size_b, seeders = (
                m.group(1).lower(), m.group(2).strip(),
                int(m.group(3)), int(m.group(4))
            )
            if not name or not _meets_quality(name, media_type):
                continue
            size = ''
            if size_b >= 1_073_741_824:
                size = '%.1f GB' % (size_b / 1_073_741_824)
            elif size_b >= 1_048_576:
                size = '%d MB' % (size_b // 1_048_576)
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    _make_magnet(ih, name),
                'seeds':     seeders,
                'size':      size,
                'source':    'TorrentDL',
            })
        results.sort(key=lambda x: x['seeds'], reverse=True)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] TorrentDownloads error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Glodls ───────────────────────────────────────────────────────────────────

_GLODLS_BASE = 'https://glodls.to'
_GLODLS_TV   = 'search_results.php?search={q}&cat=41&incldead=0&inclexternal=0&lang=1&sort=seeders&order=desc'
_GLODLS_MOV  = 'search_results.php?search={q}&cat=1&incldead=0&inclexternal=0&lang=1&sort=size&order=desc'
_RE_GL_NAME  = re.compile(r'<a[^>]+title="([^"]+)"', re.IGNORECASE)
_RE_GL_MAG   = re.compile(r'href="(magnet:\?[^"]+)"', re.IGNORECASE)
_RE_GL_SIZE  = re.compile(r'(\d+(?:[,.]\d+)?)\s*(GiB|MiB|GB|MB)', re.IGNORECASE)


def search_glodls(title, year=None, limit=5, media_type='movie'):
    try:
        if not _req:
            return []
        query = title
        if year and media_type not in ('adult',):
            query = '%s %s' % (title, year)
        q = _req.utils.quote(query)
        tmpl = _GLODLS_TV if media_type == 'tv' else _GLODLS_MOV
        url = '%s/%s' % (_GLODLS_BASE, tmpl.format(q=q))
        html = _get(url, timeout=10)
        if not html:
            return []
        results = []
        # Parse t-row table rows
        for row in html.split('class="t-row"')[1:]:
            if len(results) >= limit:
                break
            try:
                mag_m = _RE_GL_MAG.search(row)
                if not mag_m:
                    continue
                magnet = mag_m.group(1).replace('&amp;', '&')
                ih_m = re.search(r'btih:([a-fA-F0-9]{40})', magnet, re.IGNORECASE)
                if not ih_m:
                    continue
                info_hash = ih_m.group(1).lower()
                # Title from <a title="...">
                name_m = _RE_GL_NAME.search(row)
                name = name_m.group(1) if name_m else ''
                if not name or not _meets_quality(name, media_type):
                    continue
                # Size
                sz_m = _RE_GL_SIZE.search(row)
                size = sz_m.group(0) if sz_m else ''
                results.append({
                    'title':     name,
                    'year':      '',
                    'quality':   _extract_quality(name),
                    'info_hash': info_hash,
                    'magnet':    magnet.split('&tr')[0],
                    'seeds':     0,
                    'size':      size,
                    'source':    'Glodls',
                })
            except Exception:
                continue
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Glodls error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Rutor (rutor.info / rutor.is) ─────────────────────────────────────────────
# Russian tracker (mixed Cyrillic/English titles) — confirmed live 2026-08-11:
# 39 real results for a real query, magnets embedded directly in the search
# results table, no per-item fetch needed, fully anonymous (no login).
# rutor.info and rutor.is confirmed live 2026-08-27 to be byte-identical
# mirrors of the same site (same backend) — tries both so this source
# survives either domain going down on its own.

_RUTOR_MIRRORS = ['https://rutor.info', 'https://rutor.is']
_rutor_working = {}
_RE_RUTOR_ROW = re.compile(
    r'href="magnet:\?xt=urn:btih:([a-fA-F0-9]{40})[^"]*".*?'
    r'<a href="/torrent/\d+/[^"]*">([^<]+)</a>.*?'
    r'<td align="right">([\d.,]+)&nbsp;(GB|MB|KB)</td>.*?'
    r'S"\s*/>&nbsp;(\d+)',
    re.IGNORECASE | re.DOTALL
)


def _get_rutor_base():
    cached = _rutor_working.get('url')
    ts     = _rutor_working.get('ts', 0)
    if cached and (time.time() - ts) < 3600:
        return cached
    for mirror in _RUTOR_MIRRORS:
        try:
            html = _get(mirror + '/', timeout=7)
            if html and 'rutor' in html.lower():
                _rutor_working['url'] = mirror
                _rutor_working['ts']  = time.time()
                return mirror
        except Exception:
            continue
    return _RUTOR_MIRRORS[0]


def search_rutor(title, year=None, limit=5, media_type='movie'):
    try:
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        q = _req.utils.quote(query) if _req else query
        url = '%s/search/0/0/000/0/%s' % (_get_rutor_base(), q)
        html = _get(url, timeout=10)
        if not html:
            return []
        results = []
        for ih, name, size_val, size_unit, seeds in _RE_RUTOR_ROW.findall(html):
            if len(results) >= limit:
                break
            name = name.strip()
            if not name or not _meets_quality(name, media_type):
                continue
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih.lower(),
                'magnet':    _make_magnet(ih.lower(), name),
                'seeds':     int(seeds),
                'size':      '%s %s' % (size_val, size_unit),
                'source':    'Rutor',
            })
        results.sort(key=lambda x: x['seeds'], reverse=True)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Rutor error: %s' % e, xbmc.LOGWARNING)
        return []


# ── NNMClub (nnmclub.to) ──────────────────────────────────────────────────────
# Russian forum-tracker. Search results only link to a download.php redirect
# (no magnet/hash inline), which forwards anonymously (uid=-1, no login
# required — confirmed live 2026-08-11) to a real .torrent file on
# bulk.nnmclub.to. Needs a tiny bencode decode per result to compute the
# actual info_hash (SHA1 of the bencoded 'info' dict) since the site itself
# never exposes it directly — one extra fetch per candidate beyond the
# search page itself, same cost class as this file's other detail-page-fetch
# sources (isohunt2/yourbittorrent above).
NNMCLUB_BASE = 'https://nnmclub.to/forum'
_RE_NNM_ROW = re.compile(
    r'<a[^>]+href="(viewtopic\.php\?t=\d+)"[^>]*>(?:<b>)?([^<]+)(?:</b>)?</a>.*?'
    r'<a href="(download\.php\?id=\d+)"',
    re.IGNORECASE | re.DOTALL
)


def _bdecode(data, i=0):
    """Minimal bencode decoder — only needs to parse a .torrent file well
    enough to isolate the 'info' dict for hashing, not a general-purpose
    implementation."""
    c = data[i:i + 1]
    if c == b'i':
        end = data.index(b'e', i)
        return int(data[i + 1:end]), end + 1
    if c == b'l':
        i += 1
        items = []
        while data[i:i + 1] != b'e':
            v, i = _bdecode(data, i)
            items.append(v)
        return items, i + 1
    if c == b'd':
        i += 1
        d = {}
        while data[i:i + 1] != b'e':
            k, i = _bdecode(data, i)
            v, i = _bdecode(data, i)
            d[k] = v
        return d, i + 1
    colon = data.index(b':', i)
    length = int(data[i:colon])
    start = colon + 1
    return data[start:start + length], start + length


def _bencode(obj):
    if isinstance(obj, int):
        return b'i' + str(obj).encode() + b'e'
    if isinstance(obj, bytes):
        return str(len(obj)).encode() + b':' + obj
    if isinstance(obj, list):
        return b'l' + b''.join(_bencode(x) for x in obj) + b'e'
    if isinstance(obj, dict):
        out = b'd'
        for k in sorted(obj.keys()):
            out += _bencode(k) + _bencode(obj[k])
        return out + b'e'
    raise TypeError(type(obj))


def _nnm_hash_from_torrent(dl_path):
    """Follows the anonymous download.php redirect and computes the real
    info_hash from the returned .torrent bytes. Deliberately bypasses _get()
    here — that helper always text-decodes the response (r.text), which
    corrupts arbitrary binary bencode data (a .torrent file has no reliable
    text encoding, so a decode+re-encode round trip isn't guaranteed to
    reproduce the original bytes). Fetches raw .content directly instead."""
    try:
        s = _sess()
        if not s:
            return None
        r = s.get('%s/%s' % (NNMCLUB_BASE, dl_path), timeout=10)
        r.raise_for_status()
        data = r.content
        if not data:
            return None
        parsed, _pos = _bdecode(data, 0)
        info = parsed.get(b'info')
        if not info:
            return None
        return hashlib.sha1(_bencode(info)).hexdigest()
    except Exception:
        return None


def search_nnmclub(title, year=None, limit=5, media_type='movie'):
    try:
        from concurrent.futures import ThreadPoolExecutor
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        url = '%s/tracker.php?nm=%s' % (NNMCLUB_BASE, _req.utils.quote(query) if _req else query)
        html = _get(url, timeout=10)
        if not html:
            return []
        rows = _RE_NNM_ROW.findall(html)[:limit * 2]  # slack for quality-filtered drops
        candidates = []
        for _topic, name, dl_path in rows:
            name = name.strip()
            if not name or not _meets_quality(name, media_type):
                continue
            candidates.append((name, dl_path))
            if len(candidates) >= limit:
                break
        if not candidates:
            return []

        def _resolve(item):
            name, dl_path = item
            ih = _nnm_hash_from_torrent(dl_path)
            if not ih:
                return None
            return {
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    _make_magnet(ih, name),
                'seeds':     0,
                'size':      '',
                'source':    'NNMClub',
            }

        results = []
        with ThreadPoolExecutor(max_workers=max(len(candidates), 1)) as pool:
            for r in pool.map(_resolve, candidates, timeout=15):
                if r:
                    results.append(r)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] NNMClub error: %s' % e, xbmc.LOGWARNING)
        return []


# ── DaMagNet (damag.net — DHT-crawl index; two-step like NNMClub above) ──────
#
# Confirmed live 2026-09-03: real, large (67M+ resource) DHT crawl, plain
# server-rendered POST form (no JS rendering needed — same shape as
# NNMClub's own search). The results listing itself only carries a short
# per-item detail-page path (e.g. "/53MOpSe") plus a file count and a raw
# byte size — no magnet/info_hash inline — so each candidate needs a second
# GET to its own detail page (which does inline a bare
# `magnet:?xt=urn:btih:...`, no display name or trackers of its own)
# before it's usable. Resolved via the same bounded thread pool as
# NNMClub's own two-step lookup, for the same reason: N sequential
# per-item GETs here would multiply this source's real latency by N for
# no benefit over a bounded number of them in flight at once. The hidden
# "token" field on the search form was confirmed live to work fine left
# blank (not a per-session CSRF value that gets validated).
DAMAG_BASE = 'https://damag.net'
_RE_DAMAG_ROW = re.compile(
    r'<a href="(/[A-Za-z0-9]+)"\s+target="_blank"\s+id="res\d+">([^<]+)</a>'
    r'.*?<span id="size\d+"[^>]*>(\d+)</span>',
    re.DOTALL
)
_RE_DAMAG_MAGNET = re.compile(r'magnet:\?xt=urn:btih:([A-Fa-f0-9]{40})')


def search_damag(title, year=None, limit=8, media_type='movie'):
    try:
        from concurrent.futures import ThreadPoolExecutor
        s = _sess()
        if not s:
            return []
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        # Origin/Referer are required here — confirmed live 2026-09-03 that
        # a request without them gets silently 302'd to /nsfw (403) instead
        # of running the actual search, regardless of query content (even a
        # plain "ubuntu" hits it) or any cookie/token. Passed per-request
        # rather than via s.headers.update(), since `s` is the module-wide
        # shared session every other concurrently-running source in
        # search_all() also uses — mutating its defaults here would leak
        # damag.net's Origin/Referer into every other source's requests too.
        _dmg_headers = {'Origin': DAMAG_BASE, 'Referer': DAMAG_BASE + '/'}
        home = s.get(DAMAG_BASE + '/', timeout=10, headers=_dmg_headers).text
        tok_m = re.search(r'name="token"\s+value="([^"]*)"', home)
        token = tok_m.group(1) if tok_m else ''
        r = s.post(DAMAG_BASE + '/', data={'token': token, 'q': query, 'wanted': '50'},
                   timeout=15, headers=_dmg_headers)
        r.raise_for_status()
        rows = _RE_DAMAG_ROW.findall(r.text)[:limit * 3]  # slack for quality-filtered drops
        candidates = []
        for path, name, size_b in rows:
            name = name.strip()
            if not name or not _meets_quality(name, media_type):
                continue
            candidates.append((path, name, int(size_b)))
            if len(candidates) >= limit:
                break
        if not candidates:
            return []

        def _resolve(item):
            path, name, size_b = item
            try:
                dr = s.get(DAMAG_BASE + path, timeout=10, headers=_dmg_headers)
                m = _RE_DAMAG_MAGNET.search(dr.text)
            except Exception:
                return None
            if not m:
                return None
            ih = m.group(1).lower()
            size = ''
            if size_b >= 1_073_741_824:
                size = '%.1f GB' % (size_b / 1_073_741_824)
            elif size_b >= 1_048_576:
                size = '%.0f MB' % (size_b / 1_048_576)
            return {
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    _make_magnet(ih, name),
                'seeds':     0,
                'size':      size,
                'source':    'DaMagNet',
            }

        results = []
        with ThreadPoolExecutor(max_workers=max(len(candidates), 1)) as pool:
            for res in pool.map(_resolve, candidates, timeout=15):
                if res:
                    results.append(res)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] DaMagNet error: %s' % e, xbmc.LOGWARNING)
        return []


# ── PublicDomainTorrents.info (real public-domain classic films) ────────────
# Old-school static site (confirmed live 2026-08-28), no login/paywall, no
# CF/JS wall anywhere. No search endpoint exists at all — only category
# browsing (nshowcat.html?category=X) — so the full 'ALL' category listing
# (981 real titles confirmed live, e.g. real IMDB-linked classics like
# "Africa Screams" tt0041098) is fetched once and cached 24h, then matched
# locally by title substring, same "no native search" workaround already
# used elsewhere in this file (myporn_sources.search_myporn_club's
# single-word-tag limitation gets a similar local-filter treatment).
# Detail pages (nshowmovie.html?movieid=<id>) never expose a magnet: URI —
# only real .torrent file downloads at several quality tiers (DivX AVI,
# iPod/PSP MP4, PDA-sized AVI) with the size in MB right in the link text.
# Downloading the largest one and deriving its info_hash from the raw
# bencoded 'info' dict (confirmed live against "Africa Screams" ->
# 07c88d686782bf1345b4c21a9bb2305630c1af98) reuses this file's own
# _bdecode/_bencode helpers — the exact same technique _nnm_hash_from_torrent
# above already uses for NNMClub's identically torrent-file-only downloads.
PDT_BASE = 'https://www.publicdomaintorrents.info'
PDT_DL_BASE = 'http://www.publicdomaintorrents.com'

_RE_PDT_ITEM = re.compile(r'href=nshowmovie\.html\?movieid=(\d+)>([^<]+)</a>')
_RE_PDT_DL = re.compile(
    r"href=\s*(http://www\.publicdomaintorrents\.com/bt/btdownload\.php\?"
    r"type=torrent&file=[^>]+\.torrent)>([^<]+)</a>", re.IGNORECASE)
_RE_PDT_SIZE_MB = re.compile(r'([\d.]+)\s*MB', re.IGNORECASE)


def _pdt_all_listing():
    ck = 'pdt_all_listing'
    if _HAS_CACHE:
        cached = _cache.get(ck)
        if cached is not None:
            return cached or []
    try:
        html = _get(PDT_BASE + '/nshowcat.html?category=ALL', timeout=15)
        items = [{'id': mid, 'title': _html_unescape(name.strip())}
                  for mid, name in _RE_PDT_ITEM.findall(html or '')]
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] PublicDomainTorrents listing error: %s' % e, xbmc.LOGWARNING)
        items = []
    if _HAS_CACHE and items:
        _cache.set(ck, items, 24 * 3600)
    return items


def _html_unescape(s):
    try:
        import html as _html_mod
        return _html_mod.unescape(s)
    except Exception:
        return s


def _pdt_hash_from_torrent(url):
    try:
        s = _sess()
        if not s:
            return None
        r = s.get(url, timeout=15)
        r.raise_for_status()
        data = r.content
        if not data:
            return None
        parsed, _pos = _bdecode(data, 0)
        info = parsed.get(b'info')
        if not info:
            return None
        return hashlib.sha1(_bencode(info)).hexdigest()
    except Exception:
        return None


def search_publicdomaintorrents(title, year=None, limit=5, media_type='movie'):
    if media_type != 'movie':
        return []
    try:
        from concurrent.futures import ThreadPoolExecutor
        listing = _pdt_all_listing()
        if not listing:
            return []
        q_words = [w for w in re.findall(r'[a-z0-9]+', title.lower()) if len(w) > 1]
        if not q_words:
            return []
        candidates = []
        for item in listing:
            t_words = set(re.findall(r'[a-z0-9]+', item['title'].lower()))
            if all(w in t_words for w in q_words):
                candidates.append(item)
            if len(candidates) >= limit:
                break
        if not candidates:
            return []

        def _resolve(item):
            try:
                html = _get(PDT_BASE + '/nshowmovie.html?movieid=%s' % item['id'], timeout=12)
                dls = _RE_PDT_DL.findall(html or '')
                if not dls:
                    return None
                # Pick the largest file by its own stated MB size — the
                # highest-quality option (usually the DivX AVI) also always
                # happens to be listed first, but sizes are compared
                # explicitly rather than assumed to stay in that order.
                def _mb(pair):
                    m = _RE_PDT_SIZE_MB.search(pair[1])
                    return float(m.group(1)) if m else 0.0
                best_url, best_label = max(dls, key=_mb)
                ih = _pdt_hash_from_torrent(best_url)
                if not ih:
                    return None
                size = re.sub(r'\s+', ' ', re.sub(r'^Click for\s+', '', best_label)).strip()
                return {
                    'title':     item['title'],
                    'year':      '',
                    'quality':   'SD',
                    'info_hash': ih,
                    'magnet':    _make_magnet(ih, item['title']),
                    'seeds':     0,
                    'size':      size,
                    'source':    'PublicDomainTorrents',
                }
            except Exception:
                return None

        results = []
        with ThreadPoolExecutor(max_workers=max(len(candidates), 1)) as pool:
            futs = [pool.submit(_resolve, c) for c in candidates]
            for fut in futs:
                try:
                    r = fut.result(timeout=15)
                except Exception:
                    r = None
                if r:
                    results.append(r)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] PublicDomainTorrents error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Snowfl.com — magnet metasearch aggregator (limetorrents/1337x/etc.) ─────
#
# Reputed hard-to-scrape in the Kodi/scraper community (its own homepage's
# click handler builds the real search URL as
# `"/" + <secret> + "/" + query + "/" + <sessionToken> + "/" + page + "/" +
# sort + "/" + top + "/" + nsfw`, with <secret> looking like a rotating/
# hashed value) — but confirmed live 2026-08-15 that <secret> is NOT
# actually computed by any hashing/obfuscation logic at request time: it's
# a literal `var <randomName>="<secret>";` string constant baked directly
# into the plain-text served `b.min.js?v=...` bundle (the query-string
# version, and the JS's own random variable NAME, presumably rotate on
# their own schedule, but the secret ITSELF is always sitting there in
# clear text at request time, extractable by a plain regex against the
# freshly-fetched bundle — no JS interpreter/engine ever needs to run).
# <sessionToken> in the URL is client-generated via `Math.random()`-style
# 8-char string and confirmed live the server accepts literally any
# 8-char alnum value there (tested with a hardcoded "abcd1234", worked
# fine) — it's not validated against any prior request/cookie, just part
# of the URL shape. The response itself is real, clean JSON — a list of
# {magnet, age, name, size, seeder, leecher, type, site, url, nsfw} — with
# a ready-to-use magnet: URI (real btih hash + tracker list) per item,
# already aggregated from multiple trackers (limetorrents, 1337x, etc. per
# the `site` field), and an explicit `nsfw` flag this integration uses for
# the adult-mode request instead of guessing from the title.
SNOWFL_BASE = 'https://snowfl.com'
_RE_SNOWFL_JS = re.compile(r'<script[^>]+src="([^"]+\.min\.js\?v=[^"]+)"')
_RE_SNOWFL_SECRET_IDENT = re.compile(r'"/"\s*\+\s*(\w+)\s*\+\s*\(\s*"/"')

_snowfl_secret_cache = {'value': None, 'ts': 0}


def _snowfl_get_secret():
    """Fetch snowfl.com's homepage + its bundled JS and pull out today's
    secret path segment fresh each time (cached 30 min in-process — long
    enough to avoid re-fetching/re-parsing a ~150KB JS bundle on every
    single search, short enough to notice if the site rotates it)."""
    now = time.time()
    if _snowfl_secret_cache['value'] and (now - _snowfl_secret_cache['ts']) < 1800:
        return _snowfl_secret_cache['value']
    try:
        home = _get(SNOWFL_BASE + '/', timeout=10)
        if not home:
            return None
        m = _RE_SNOWFL_JS.search(home)
        if not m:
            return None
        js = _get('%s/%s' % (SNOWFL_BASE, m.group(1)), timeout=10)
        if not js:
            return None
        m2 = _RE_SNOWFL_SECRET_IDENT.search(js)
        if not m2:
            return None
        ident = m2.group(1)
        m3 = re.search(re.escape(ident) + r'\s*=\s*"([A-Za-z0-9]{20,60})"', js)
        if not m3:
            return None
        secret = m3.group(1)
        _snowfl_secret_cache['value'] = secret
        _snowfl_secret_cache['ts'] = now
        return secret
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Snowfl secret extraction error: %s' % e, xbmc.LOGWARNING)
        return None


def search_snowfl(title, year=None, limit=10, media_type='movie'):
    """Search snowfl.com's aggregator API. Returns standard result dicts;
    magnets come straight from the API already complete (real btih hash +
    tracker list), no per-item follow-up fetch needed."""
    try:
        secret = _snowfl_get_secret()
        if not secret:
            return []
        import random, string
        from urllib.parse import quote as _q
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        token = ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(8))
        nsfw = '1' if media_type == 'adult' else '0'
        url = '%s/%s/%s/%s/0/NONE/NONE/%s' % (SNOWFL_BASE, secret, _q(query), token, nsfw)
        raw = _get(url, timeout=12)
        if not raw:
            return []
        import json
        try:
            items = json.loads(raw)
        except ValueError:
            return []
        if not isinstance(items, list):
            return []
        results = []
        for item in items:
            if len(results) >= limit:
                break
            name = (item.get('name') or '').strip()
            magnet = item.get('magnet') or ''
            if not name or not magnet or 'btih:' not in magnet.lower():
                continue
            if media_type != 'adult' and item.get('nsfw'):
                continue
            if not _meets_quality(name, media_type):
                continue
            m_ih = re.search(r'btih:([a-fA-F0-9]{40})', magnet)
            if not m_ih:
                continue
            ih = m_ih.group(1).lower()
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    magnet,
                'seeds':     int(item.get('seeder') or 0),
                'size':      item.get('size') or '',
                'source':    'Snowfl (%s)' % item.get('site', '') if item.get('site') else 'Snowfl',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Snowfl error: %s' % e, xbmc.LOGWARNING)
        return []


# ── EXT Torrents (extto.com) ─────────────────────────────────────────────────
# The old ext.to domain this used to point at is fully dead now (DNS doesn't
# even resolve, confirmed live 2026-08-04) — this is the same "EXT Torrents"
# site's current live mirror, confirmed clean (no Cloudflare wall at all,
# unlike ext.to's old Turnstile problem). Its magnet links aren't in the
# search-result HTML though (that changed since the old integration was
# written) — every torrent's magnet now has to be fetched per-item via a
# small HMAC-signed AJAX call, same anti-scraping idea as vidhide_bypass.py's
# target but even simpler: the "secret" (window.pageToken) is embedded
# directly in that torrent's own detail-page HTML, and the HMAC is just a
# plain client-side SHA256 (resources/lib/vidhide_bypass.py's docstring has
# more on this pattern of cosmetic-vs-real anti-scraping — this is cosmetic).

EXTTO_BASE = 'https://extto.com'
_EXTTO_CAT = {'movie': 1, 'tv': 2, 'adult': 10}
_RE_EXTTO_ROW_TITLE = re.compile(
    r'<a href="(/[a-z0-9\-]+-(\d+)/)"\s+class="torrent-title-link"[^>]*data-tooltip="([^"]+)"',
    re.IGNORECASE
)
_RE_EXTTO_SEEDS = re.compile(r'file_upload</i>\s*<span[^>]*>(\d+)</span>')
_RE_EXTTO_SIZE  = re.compile(r'storage</i>\s*<span>([^<]+)</span>')
_RE_EXTTO_TOKEN = re.compile(r'pageToken\s*=\s*["\']([^"\']+)["\']')
_RE_EXTTO_CSRF  = re.compile(r'csrfToken\s*=\s*["\']([^"\']+)["\']')


def _extto_get_magnet(detail_path, torrent_id):
    """Reproduces main.min.js's handleTorrentDownload(): fetch the torrent's
    own detail page for its per-page pageToken/csrfToken, compute the same
    plain SHA256 HMAC the site's own JS does, then hit its AJAX endpoint
    directly — confirmed live to return a real, complete magnet link."""
    import time as _time
    import hashlib as _hashlib
    try:
        detail_html = _get(EXTTO_BASE + detail_path, timeout=8)
        if not detail_html:
            return ''
        tok_m = _RE_EXTTO_TOKEN.search(detail_html)
        csrf_m = _RE_EXTTO_CSRF.search(detail_html)
        if not tok_m or not csrf_m:
            return ''
        timestamp = int(_time.time())
        hmac_token = _hashlib.sha256(
            ('%s|%d|%s' % (torrent_id, timestamp, tok_m.group(1))).encode('utf-8')
        ).hexdigest()
        s = _sess()
        if not s:
            return ''
        r = s.post(
            EXTTO_BASE + '/ajax/getTorrentMagnet.php',
            data={
                'torrent_id': torrent_id, 'download_type': 'magnet',
                'timestamp': timestamp, 'hmac': hmac_token, 'sessid': csrf_m.group(1),
            },
            headers={'X-Requested-With': 'XMLHttpRequest', 'Referer': EXTTO_BASE + detail_path},
            timeout=8,
        )
        import json as _json
        data = _json.loads(r.text)
        if data.get('success'):
            return data.get('url') or (
                _make_magnet(data['hash']) if data.get('hash') else ''
            )
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] extto magnet fetch error: %s' % e, xbmc.LOGWARNING)
    return ''


def search_extto(title, year=None, limit=5, media_type='movie'):
    """extto.com ("EXT Torrents") — /browse/?q=...&cat=N (1=Movies, 2=TV,
    10=Adult, needs &with_adult=1 too). Confirmed live: no Cloudflare wall,
    50 real results per search page. Each candidate needs its own
    _extto_get_magnet() call (see that function's docstring) so this stays
    bounded to `limit` candidates, resolved in parallel."""
    try:
        if not _req:
            return []
        q = _req.utils.quote(title)
        cat = _EXTTO_CAT.get(media_type, 1)
        url = '%s/browse/?q=%s&cat=%d&sort=seeds&order=desc' % (EXTTO_BASE, q, cat)
        if media_type == 'adult':
            url += '&with_adult=1'
        html_raw = _get(url, timeout=10)
        if not html_raw:
            return []
        import html as _html

        candidates = []
        for m in _RE_EXTTO_ROW_TITLE.finditer(html_raw):
            if len(candidates) >= limit:
                break
            path, torrent_id, tooltip = m.group(1), m.group(2), m.group(3)
            # data-tooltip is double-HTML-encoded (its own <span> highlight
            # tags come through as literal "&lt;span&gt;" text) — unescape
            # first so the tag-strip regex actually has real "<...>" to match.
            name = re.sub(r'<[^>]+>', '', _html.unescape(tooltip)).strip()
            if not name or not _meets_quality(name, media_type):
                continue
            start = m.end()
            block = html_raw[start:start + 4500]
            seeds_m = _RE_EXTTO_SEEDS.search(block)
            size_m = _RE_EXTTO_SIZE.search(block)
            candidates.append({
                'path': path, 'id': torrent_id, 'name': name,
                'seeds': int(seeds_m.group(1)) if seeds_m else 0,
                'size': size_m.group(1).strip() if size_m else '',
            })

        if not candidates:
            return []

        from concurrent.futures import ThreadPoolExecutor
        results = []
        with ThreadPoolExecutor(max_workers=min(len(candidates), 15)) as pool:
            fmap = {pool.submit(_extto_get_magnet, c['path'], c['id']): c for c in candidates}
            for fut, c in fmap.items():
                try:
                    magnet = fut.result(timeout=10)
                except Exception:
                    magnet = ''
                if not magnet:
                    continue
                ih_m = re.search(r'btih:([a-fA-F0-9]{40})', magnet, re.IGNORECASE)
                results.append({
                    'title': c['name'], 'year': '', 'quality': _extract_quality(c['name']),
                    'info_hash': ih_m.group(1).lower() if ih_m else '', 'magnet': magnet,
                    'seeds': c['seeds'], 'size': c['size'], 'source': 'EXTto',
                })
        return sorted(results, key=lambda x: x['seeds'], reverse=True)
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] extto error: %s' % e, xbmc.LOGWARNING)
        return []


# ── TheRarBG ──────────────────────────────────────────────────────────────────
# The original RARBG shut down permanently in May 2023 — this is an
# actively-run unofficial revival using the same branding (confirmed live
# 2026-08-04: real, current 2026 uploads across Movies/TV/XXX, not a stale
# database dump), not the original site. Fully open, no Cloudflare wall,
# and — unlike extto.com — its detail pages carry the magnet link directly
# inline with no token/HMAC dance needed at all.

THERARBG_BASE = 'https://therarbg.com'
_THERARBG_CAT = {'movie': 'Movies', 'tv': 'TV', 'adult': 'XXX'}
_RE_THERARBG_ROW = re.compile(
    r'href="(/post-detail/[a-z0-9]+/[^"]+)"\s+style="font-weight: 700"\s*>([^<]+)</a>',
    re.IGNORECASE
)
_RE_THERARBG_SIZE = re.compile(r'sizeCell"[^>]*>([^<]+)</td>')
_RE_THERARBG_SEEDS = re.compile(r'color:\s*green">(\d+)</td>')
_RE_THERARBG_MAGNET = re.compile(r'href="(magnet:\?xt=urn:btih:([0-9a-fA-F]{40})[^"]*)"')


def _therarbg_get_magnet(detail_path):
    try:
        html = _get(THERARBG_BASE + detail_path, timeout=8)
        if not html:
            return '', ''
        m = _RE_THERARBG_MAGNET.search(html)
        if not m:
            return '', ''
        return m.group(1).replace('&amp;', '&'), m.group(2).lower()
    except Exception:
        return '', ''


def search_therarbg(title, year=None, limit=5, media_type='movie'):
    """therarbg.com — query syntax is one colon-joined path segment,
    /get-posts/keywords:X:category:Y/ — confirmed live that a
    slash-separated keywords:X/category:Y/ silently falls back to the
    homepage's default listing instead of filtering, so this MUST stay one
    segment. A literal colon in the title (e.g. "Spider-Man: Into the
    Spider-Verse") is safe percent-encoded via quote_plus — confirmed live
    it still filters correctly rather than breaking the site's own
    colon-delimited parsing. Search results already carry size/seeds; only
    the magnet needs a separate per-item detail-page fetch."""
    try:
        if not _req:
            return []
        from urllib.parse import quote_plus as _qp2
        cat = _THERARBG_CAT.get(media_type, 'Movies')
        q = _qp2(re.sub(r'\s+', ' ', title).strip())
        url = '%s/get-posts/keywords:%s:category:%s/' % (THERARBG_BASE, q, cat)
        html_raw = _get(url, timeout=10)
        if not html_raw:
            return []

        matches = list(_RE_THERARBG_ROW.finditer(html_raw))
        candidates = []
        for i, m in enumerate(matches):
            if len(candidates) >= limit:
                break
            name = m.group(2).strip()
            if not name or not _meets_quality(name, media_type):
                continue
            start = m.end()
            end = matches[i + 1].start() if i + 1 < len(matches) else start + 1200
            block = html_raw[start:end]
            size_m = _RE_THERARBG_SIZE.search(block)
            seeds_m = _RE_THERARBG_SEEDS.search(block)
            candidates.append({
                'path': m.group(1), 'name': name,
                'size': size_m.group(1).replace('\xa0', ' ').strip() if size_m else '',
                'seeds': int(seeds_m.group(1)) if seeds_m else 0,
            })

        if not candidates:
            return []

        from concurrent.futures import ThreadPoolExecutor
        results = []
        with ThreadPoolExecutor(max_workers=min(len(candidates), 15)) as pool:
            fmap = {pool.submit(_therarbg_get_magnet, c['path']): c for c in candidates}
            for fut, c in fmap.items():
                try:
                    magnet, info_hash = fut.result(timeout=10)
                except Exception:
                    magnet, info_hash = '', ''
                if not magnet:
                    continue
                results.append({
                    'title': c['name'], 'year': '', 'quality': _extract_quality(c['name']),
                    'info_hash': info_hash, 'magnet': magnet,
                    'seeds': c['seeds'], 'size': c['size'], 'source': 'TheRarBG',
                })
        return sorted(results, key=lambda x: x['seeds'], reverse=True)
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] therarbg error: %s' % e, xbmc.LOGWARNING)
        return []


# ── RARBG Dump (rarbgdump.com — static archive of RARBG's own database,
# 2.8M+ entries; RARBG itself has been dead since 2023) ──────────────────────
#
# Confirmed live 2026-09-03: real JSON API (POST /api/search {"query":...}),
# no Cloudflare interstitial actually in front of it despite the
# challenge-platform scripts the page itself loads — those only ever fired
# their own background telemetry beacons (cdn-cgi/rum) in testing, never
# blocked the API call itself. Every hit already carries a real 40-char
# btih hash plus its own seeders/leechers straight in the response — no
# per-item resolve step needed, unlike DaMagNet elsewhere in this file.
# Since RARBG is dead, this is a frozen 2023 snapshot, not a live crawl:
# seeder counts are whatever they were at RARBG's own last update, not
# current — but the swarms themselves (DHT-level) can still be alive years
# later for anything popular enough, same as any other old-but-real hash.
# Each hit's own 'cat' field (e.g. "movies_x265_4k_hdr", "music_mp3",
# "games_pc_iso", "xxx") is real per-source metadata the archive carries
# for every entry, not a guess from the title — used here to drop the
# non-video categories a plain title-text quality filter can't see (unlike
# most other sources in this file, this one gets to filter on ground truth
# instead of pattern-matching the release name for the same signal).
_RARBGDUMP_API = 'https://rarbgdump.com/api/search'


def search_rarbgdump(title, year=None, limit=10, media_type='movie'):
    try:
        if not _req:
            return []
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        r = _sess().post(_RARBGDUMP_API, json={'query': query}, timeout=12)
        r.raise_for_status()
        items = (r.json() or {}).get('results') or []
        results = []
        for item in items:
            if len(results) >= limit:
                break
            cat = (item.get('cat') or '').lower()
            if media_type == 'adult':
                if not cat.startswith('xxx'):
                    continue
            elif not (cat.startswith('movies') or cat.startswith('tv')):
                continue
            name = (item.get('title') or '').strip()
            ih = (item.get('hash') or '').lower()
            if not name or not ih or not _meets_quality(name, media_type):
                continue
            try:
                size_b = int(item.get('size') or 0)
            except (TypeError, ValueError):
                size_b = 0
            size = ''
            if size_b >= 1_073_741_824:
                size = '%.1f GB' % (size_b / 1_073_741_824)
            elif size_b >= 1_048_576:
                size = '%.0f MB' % (size_b / 1_048_576)
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    _make_magnet(ih, name),
                'seeds':     int(item.get('seeders') or 0),
                'size':      size,
                'source':    'RARBGDump',
            })
        return sorted(results, key=lambda x: x['seeds'], reverse=True)
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] RARBGDump error: %s' % e, xbmc.LOGWARNING)
        return []


# ── TorrentFunk (its HTML search.php is genuinely Cloudflare JS-challenge
# protected, confirmed live -- but the site documents/exposes a free,
# keyless JSON API at /api/search.json with real server-side query search,
# no CF in front of it at all. Ready-to-use magnet + infohash straight in
# the response, no local matching or file-download workaround needed,
# unlike KONTRAST.) ───────────────────────────────────────────────────────────

TORRENTFUNK_API = 'https://www.torrentfunk.com/api/search.json'
_TORRENTFUNK_CAT = {'movie': 1, 'tv': 3, 'adult': 7}


def search_torrentfunk(title, year=None, limit=5, media_type='movie'):
    try:
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        import urllib.parse as _up
        params = {
            'q': query[:100],
            'limit': min(max(limit * 2, 5), 100),
            'sort': 'seeds',
            'order': 'desc',
        }
        cat = _TORRENTFUNK_CAT.get(media_type)
        if cat:
            params['category'] = cat
        url = '%s?%s' % (TORRENTFUNK_API, _up.urlencode(params))
        data = _get_json(url, timeout=8)
        if not data or data.get('status') != 'ok':
            return []
        results = []
        for item in data.get('results', []):
            if len(results) >= limit:
                break
            name = item.get('name', '')
            ih = (item.get('infohash') or '').lower()
            if not name or not ih or not _meets_quality(name, media_type):
                continue
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    item.get('magnet') or _make_magnet(ih, name),
                'seeds':     item.get('seeds', 0),
                'size':      item.get('size', ''),
                'source':    'TorrentFunk',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] TorrentFunk error: %s' % e, xbmc.LOGWARNING)
        return []


# ── TorrentsCSV (clean JSON API, no Cloudflare, no auth -- real infohash and
# seeders straight in the response, same category as TorrentFunk's own
# official API: no scraping or per-item detail fetch needed at all) ──────────

TORRENTSCSV_BASE = 'https://torrents-csv.com/service/search'


def search_torrentscsv(title, year=None, limit=10, media_type='movie'):
    try:
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        import urllib.parse as _up
        url = '%s?%s' % (TORRENTSCSV_BASE, _up.urlencode(
            {'size': min(max(limit * 3, 20), 100), 'q': query}))
        data = _get_json(url, timeout=8)
        if not data:
            return []
        results = []
        for item in data.get('torrents', []):
            if len(results) >= limit:
                break
            name = item.get('name', '')
            ih = (item.get('infohash') or '').lower()
            if not name or not ih or not _meets_quality(name, media_type):
                continue
            b = item.get('size_bytes') or 0
            size = ''
            if b >= 1_073_741_824:
                size = '%.1f GB' % (b / 1_073_741_824)
            elif b >= 1_048_576:
                size = '%.0f MB' % (b / 1_048_576)
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    _make_magnet(ih, name),
                'seeds':     item.get('seeders', 0) or 0,
                'size':      size,
                'source':    'TorrentsCSV',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] TorrentsCSV error: %s' % e, xbmc.LOGWARNING)
        return []


# ── BitTorrented ──────────────────────────────────────────────────────────────

BITTORRENTED_BASE = 'https://bittorrented.com'
_RE_BT_SIZE = re.compile(r'(\d+(?:\.\d+)?)\s*(GB|MB|GiB|MiB)', re.IGNORECASE)


def search_bittorrented(title, year=None, limit=5, media_type='movie'):
    """BitTorrented — HTML scraper, may be CF-protected."""
    try:
        if not _req:
            return []
        q = _req.utils.quote(title)
        url = '%s/search/?q=%s&category=0' % (BITTORRENTED_BASE, q)
        html_raw = _get(url, timeout=10, cf=True)
        if not html_raw:
            return []
        import html as _html
        text = _html.unescape(html_raw)
        parts = re.split(r'(magnet:\?[^"\'<\s]+)', text)
        results = []
        i = 1
        while i < len(parts) - 1 and len(results) < limit:
            raw_magnet = parts[i].replace('&amp;', '&')
            before = parts[i - 1][-800:]
            i += 2
            ih_m = re.search(r'btih:([a-fA-F0-9]{40})', raw_magnet, re.IGNORECASE)
            if not ih_m:
                continue
            info_hash = ih_m.group(1).lower()
            dn_m = re.search(r'[&?]dn=([^&"\'<\s]+)', raw_magnet)
            name = _req.utils.unquote(dn_m.group(1)).replace('+', ' ').strip() if dn_m else ''
            if not name:
                t_m = re.search(r'<a[^>]+class="[^"]*name[^"]*"[^>]*>([^<]{5,80})<', before, re.IGNORECASE)
                if t_m:
                    name = t_m.group(1).strip()
            if not name or not _meets_quality(name, media_type):
                continue
            sz_m = _RE_BT_SIZE.search(before[-400:])
            size = sz_m.group(0) if sz_m else ''
            seeds_m = re.search(r'(\d+)\s*seeder', before[-400:], re.IGNORECASE)
            seeds = int(seeds_m.group(1)) if seeds_m else 0
            results.append({
                'title': name, 'year': '', 'quality': _extract_quality(name),
                'info_hash': info_hash, 'magnet': raw_magnet,
                'seeds': seeds, 'size': size, 'source': 'BitTorrented',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] BitTorrented error: %s' % e, xbmc.LOGWARNING)
        return []


XXXCLUB_BASE = 'https://xxxclub.to'


_SPLIT_SCENE_RE = re.compile(r'\bsplit[\s._-]*scenes?\b', re.IGNORECASE)
_XXXCLUB_HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9',
    'Accept-Encoding': 'gzip, deflate',
}


_XXXCLUB_BROWSE_TTL = 21600  # 6 hours


def browse_xxxclub(cursor='', limit=51):
    """
    Browse latest adult torrents from xxxclub.to via direct HTML scrape.
    cursor: '' or '1' → first page; a long digit string → actual xxxclub cursor
            for subsequent pages (extracted from the site's Next link).
    Returns (results_list, next_site_cursor) where next_site_cursor is the raw
    cursor string from the site's Next link (empty string if no next page).
    """
    import urllib.request as _ureq
    import gzip as _gz

    cat = 3  # Movies/DVD/WEB category

    # Decide whether cursor is a real site cursor (long number) or page 1
    is_page1 = (not cursor) or (cursor.isdigit() and int(cursor) <= 1)
    site_cursor = '' if is_page1 else cursor  # the actual xxxclub cursor for page 2+

    # 'xxxclub_p1v2' key is new (old key was 'xxxclub_browse_1' with wrong cursor baked in)
    ck = 'xxxclub_p1v2' if is_page1 else ('xxxclub_browse_c_%s' % site_cursor[:20])
    if _HAS_CACHE:
        cached = _cache.get(ck)
        if cached is not None:
            results, next_site_cursor = cached
            xbmc.log('[Starfleet/XXXClub] cache hit cursor=%s (%d items)' % (site_cursor or '1', len(results)), xbmc.LOGINFO)
            return results, next_site_cursor

    def _fetch_html(url):
        req = _ureq.Request(url)
        for k, v in _XXXCLUB_HEADERS.items():
            req.add_header(k, v)
        with _ureq.urlopen(req, timeout=12) as resp:
            raw = resp.read()
            if resp.headers.get('Content-Encoding') == 'gzip':
                raw = _gz.decompress(raw)
        return raw.decode('utf-8', errors='replace')

    try:
        if site_cursor:
            url = '%s/torrents/browse/%d/%s' % (XXXCLUB_BASE, cat, site_cursor)
        else:
            url = '%s/torrents/browse/%d/' % (XXXCLUB_BASE, cat)

        html = _fetch_html(url)
        rows = re.findall(
            r'id="#i([a-fA-F0-9]{40})"[^>]*onpointerleave="hideImage\(\)">(.*?)</a>'
            r'.*?src=.(https://imgxclub\.com/[^\'\"]+).'
            r'.*?class="siz[^"]*">([^<]*)</span>'
            r'.*?class="see[^"]*">([^<]*)</span>',
            html, re.DOTALL
        )
        xbmc.log('[Starfleet/XXXClub] direct cursor=%s rows=%d' % (site_cursor or '1', len(rows)), xbmc.LOGWARNING)
        if len(rows) < 3:
            raise ValueError('too few rows')

        results = []
        for ih, title, thumb, size, seeds in rows:
            title = title.strip()
            if not title or _SPLIT_SCENE_RE.search(title):
                continue
            results.append({
                'title': title,
                'info_hash': ih.lower(),
                'magnet': _make_magnet(ih, title),
                'thumb': thumb.strip(),
                'size': size.strip(),
                'seeds': seeds.strip(),
            })
            if len(results) >= limit:
                break

        # Extract the Next page cursor from the real (visible) Next Page link.
        # The site has multiple hidden decoy links (style="position:absolute; left:-99999px")
        # and one real link marked with data-no-instant — match only that one.
        next_m = re.search(r'href=["\']?/torrents/browse/%d/(\d{8,})["\']?[^>]*data-no-instant' % cat, html, re.IGNORECASE)
        next_site_cursor = next_m.group(1) if next_m else ''

        if _HAS_CACHE:
            _cache.set(ck, (results, next_site_cursor), _XXXCLUB_BROWSE_TTL)
        return results, next_site_cursor
    except Exception as e:
        xbmc.log('[Starfleet/XXXClub] direct scrape failed (%s), falling back to Knaben' % e, xbmc.LOGWARNING)
    try:
        offset = (page - 1) * limit
        body = {'query': 'xxx', 'order_by': 'date', 'take': limit, 'skip': offset}
        if not _req:
            return [], ''
        r = _sess().post(KNABEN_API, json=body, headers=_KNABEN_HEADERS, timeout=12)
        if r.status_code >= 400 or not r.text.strip():
            return [], ''
        data = r.json()
        hits = data.get('hits') or data.get('result') or data.get('results') or []
        xbmc.log('[Starfleet/XXXClub] Knaben fallback returned %d hits' % len(hits), xbmc.LOGWARNING)
        results = []
        for entry in hits:
            name = entry.get('title', '').strip()
            if not name or _SPLIT_SCENE_RE.search(name):
                continue
            ih = (entry.get('hash') or '').lower()
            if not ih:
                continue
            magnet = entry.get('magnetUrl') or _make_magnet(ih, name)
            b = entry.get('bytes') or 0
            size = '%.1f GB' % (b / 1_073_741_824) if b >= 1_073_741_824 else '%.0f MB' % (b / 1_048_576) if b >= 1_048_576 else ''
            results.append({'title': name, 'info_hash': ih, 'magnet': magnet, 'thumb': '', 'size': size})
            if len(results) >= limit:
                break
        next_cursor = str(page + 1) if len(hits) >= limit else ''
        if _HAS_CACHE:
            _cache.set(ck, (results, next_cursor), _XXXCLUB_BROWSE_TTL)
        return results, next_cursor
    except Exception as e2:
        xbmc.log('[Starfleet/XXXClub] Knaben fallback error: %s' % e2, xbmc.LOGWARNING)
        return [], ''


def search_xxxclub(title, year=None, limit=10, media_type='movie'):
    """Adult torrent search via direct xxxclub.to HTML scrape."""
    if media_type != 'adult':
        return []
    # Clean here (not just at the ADE-ingestion layer) so a raw search-box
    # query — which never goes through ADE's own title cleaning — gets the
    # same studio/resolution/junk stripping as a canonical ADE title before
    # it's used to build the search query or to match results against.
    title = _clean_adult_title(title) or title
    import urllib.request as _ureq
    import urllib.parse as _uparse
    import gzip as _gz

    query = title

    def _fetch_html(u):
        req = _ureq.Request(u)
        for k, v in _XXXCLUB_HEADERS.items():
            req.add_header(k, v)
        with _ureq.urlopen(req, timeout=14) as resp:
            raw = resp.read()
            if resp.headers.get('Content-Encoding') == 'gzip':
                raw = _gz.decompress(raw)
        return raw.decode('utf-8', errors='replace')

    _LEET_MAP = str.maketrans({'4': 'a', '3': 'e', '1': 'i', '0': 'o', '5': 's', '@': 'a', '!': 'i'})

    def _parse_rows(html, q):
        r = re.findall(
            r'id="#i([a-fA-F0-9]{40})"[^>]*>(.*?)</a>'
            r'.*?class="siz[^"]*">([^<]*)</span>'
            r'.*?class="see[^"]*">([^<]*)</span>',
            html, re.DOTALL
        )
        xbmc.log('[Starfleet/XXXClub] search "%s" html=%d rows=%d' % (q, len(html), len(r)), xbmc.LOGINFO)
        if not r:
            xbmc.log('[Starfleet/XXXClub] search html snippet: %s' % html[:600].replace('\n', ' '), xbmc.LOGWARNING)
        return r

    def _smart_deleet(q):
        # Only translate leet chars inside words that also contain real letters.
        # Standalone digits (e.g. "#4" sequel numbers) are left as-is.
        def _tok(t):
            if re.search(r'[a-zA-Z]', t) and re.search(r'[4310@!5]', t):
                return t.translate(_LEET_MAP)
            return t
        return re.sub(r'[A-Za-z0-9@!]+', lambda m: _tok(m.group()), q)

    def _build_variants(q):
        import html as _hl
        q = _hl.unescape(q)
        deleet = _smart_deleet(q)
        stripped = re.sub(r'[#@!]', ' ', q).strip()
        stripped_deleet = _smart_deleet(stripped)
        seen = set()
        variants = []
        # Try clean variants first (no #/@/!) — special chars cause xxxclub to ignore
        # the episode number entirely, returning the full catalogue instead
        for v in [stripped, stripped_deleet, q, deleet]:
            v = re.sub(r'\s+', ' ', v).strip()
            if v and v not in seen:
                seen.add(v)
                variants.append(v)
        return variants

    try:
        rows = []
        for variant in _build_variants(query):
            v_url = '%s/torrents/search/all/%s' % (XXXCLUB_BASE, _uparse.quote(variant))
            try:
                html = _fetch_html(v_url)
                rows = _parse_rows(html, variant)
            except Exception:
                continue
            if rows:
                break
        import html as _html_mod

        # Normalise query for matching: lowercase, strip non-alphanum, collapse spaces
        def _nc(s):
            return re.sub(r'\s+', ' ', re.sub(r'[^a-z0-9 ]', ' ', s.lower())).strip()

        # Strip resolution/year/studio/codec suffixes from torrent name to get core title
        _SUFFIX_RE = re.compile(
            r'\s*[\(\[]?(19|20)\d{2}[\)\]]?.*$'
            r'|\s+(WEB-?DL|BluRay|BDRip|DVDRip|HDTV|x264|x265|HEVC|AAC|MP4|AVC'
            r'|480p|540p|720p|1080p|2160p|4K|UHD|HDRip|WEBRip|SPLIT)\b.*$',
            re.IGNORECASE)

        norm_query = _nc(query)
        qwords = norm_query.split()

        results = []
        for ih, name, size, seeds in rows:
            name = _html_mod.unescape(name).strip()
            if not name or _SPLIT_SCENE_RE.search(name):
                continue
            # Strip suffixes to get the core torrent title, then normalise
            name = name.replace('<mark>', '').replace('</mark>', '')
            core = _nc(_SUFFIX_RE.sub('', name))
            # Accept if core title exactly equals query, or core starts with query
            # (allows e.g. "Threesomes 7 (Marc DORCEL)" after stripping → "threesomes 7")
            # Reject if extra words appear BEFORE the query words (e.g. "Anal Threesomes 7")
            def _qw_in(w, s):
                """Word match allowing episode-number variants: '97' matches 'E97', '097'."""
                if w in s.split():
                    return True
                if w.isdigit():
                    # (?<!\d)0*97(?!\d) matches "97", "097", "E097" but not "970", "197"
                    return bool(re.search(r'(?<!\d)0*' + re.escape(w) + r'(?!\d)', s))
                return False

            if core == norm_query or core.startswith(norm_query) or norm_query in core:
                pass  # good match — also catches "marc dorcel threesomes 7 xxx" style torrent names
            else:
                # Try: all query words present and core starts with first query word
                if qwords and core.startswith(qwords[0]) and all(_qw_in(w, core) for w in qwords):
                    pass  # "Threesomes 7 Special Edition" / "FacialCasting E097" type match
                else:
                    continue  # skip — too loose
            results.append({
                'title':     name,
                'info_hash': ih.lower(),
                'magnet':    _make_magnet(ih, name),
                'seeds':     int(seeds.strip()) if seeds.strip().isdigit() else 0,
                'size':      size.strip(),
                'source':    'XXXClub',
            })
            if len(results) >= limit:
                break
        xbmc.log('[Starfleet/XXXClub] search "%s" matched %d/%d after title filter' % (
            query, len(results), len(rows)), xbmc.LOGINFO)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/XXXClub] search error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Rintor (adult torrent tracker — plain WordPress, no Cloudflare) ───────────

RINTOR_BASE = 'https://www.rintor.net'

_RE_RINTOR_RESULT = re.compile(
    r'<a[^>]+href="(https://(?:www\.)?rintor\.net/[^"]+\.html)"[^>]*>([^<]{5,120})</a>',
    re.IGNORECASE
)
_RE_RINTOR_MAGNET = re.compile(r'magnet:\?[^"\'<> ]+', re.IGNORECASE)
_RE_RINTOR_XL = re.compile(r'[?&]xl=(\d+)')


def _rintor_human_size(magnet):
    m = _RE_RINTOR_XL.search(magnet)
    if not m:
        return ''
    n = float(m.group(1))
    for unit in ('B', 'KB', 'MB', 'GB'):
        if n < 1024:
            return '%.2f %s' % (n, unit)
        n /= 1024.0
    return '%.2f TB' % n


def _post_rintor_search(query, timeout=12):
    """rintor.net runs DataLife Engine, not WordPress — confirmed live via
    browser that its real search is a POST to / with do=search&
    subaction=search&story=query (a plain GET ?s=query, what this used to
    send, just silently serves the homepage back instead of erroring, so
    the bug was invisible from the addon side: every search "succeeded"
    with an empty result). Posted straight to the canonical non-www host —
    www.rintor.net 301s to rintor.net, and requests' default redirect
    handling downgrades a POST to a bodyless GET on a 301, which would
    reproduce the exact same silent-homepage bug one hop later.

    Explicitly asks for gzip/deflate only (no 'br') — Cloudflare serves
    this response Brotli-encoded whenever the request's Accept-Encoding
    allows it, and decoding that depends on an optional `brotli`/
    `brotlicffi` package that isn't guaranteed to be present in Kodi's
    bundled Python; confirmed live this environment doesn't have it
    either, which silently produced raw compressed garbage where real
    HTML was expected. gzip/deflate are handled natively by
    requests/urllib3 with no extra dependency, and the site accepts it
    fine."""
    data = {'do': 'search', 'subaction': 'search', 'story': query}
    headers = {'Accept-Encoding': 'gzip, deflate'}
    s = _sess()
    if s:
        try:
            r = s.post('https://rintor.net/', data=data, timeout=timeout, headers=headers)
            r.raise_for_status()
            return r.text
        except Exception as e:
            xbmc.log('[Starfleet/Rintor] POST search failed: %s' % e, xbmc.LOGWARNING)
    try:
        import urllib.request as _ur
        import urllib.parse as _up
        req_headers = dict(_BROWSER_HEADERS)
        req_headers.update(headers)
        req = _ur.Request('https://rintor.net/',
                           data=_up.urlencode(data).encode('utf-8'),
                           headers=req_headers)
        with _ur.urlopen(req, timeout=timeout) as resp:
            raw = resp.read()
            if resp.headers.get('Content-Encoding') == 'gzip':
                import gzip as _gz
                raw = _gz.decompress(raw)
            return raw.decode('utf-8', errors='replace')
    except Exception as e:
        xbmc.log('[Starfleet/Rintor] urllib POST fallback failed: %s' % e, xbmc.LOGWARNING)
        return ''


def search_rintor(title, year=None, limit=8, media_type='adult'):
    """Adult torrent search via rintor.net's real search endpoint (see
    _post_rintor_search). Real magnet links sit directly in each result's
    detail page HTML — no Cloudflare, no obfuscation."""
    if media_type != 'adult':
        return []
    try:
        # Same reasoning as search_xxxclub — clean here so a raw search-box
        # query gets the same junk-stripping as a canonical ADE title.
        title = _clean_adult_title(title) or title
        query = re.sub(r'\s+', ' ', title).strip()
        if not query:
            return []
        html = _post_rintor_search(query, timeout=12)
        if not html:
            return []

        seen_urls = set()
        candidates = []
        for m in _RE_RINTOR_RESULT.finditer(html):
            page_url, name = m.group(1), m.group(2).strip()
            if page_url in seen_urls:
                continue
            seen_urls.add(page_url)
            name = name.split('|')[0].strip()
            import html as _html_mod
            name = _html_mod.unescape(name)
            if not name:
                continue
            candidates.append((page_url, name))
            if len(candidates) >= limit * 2:
                break

        if not candidates:
            return []

        def _nc(s):
            return re.sub(r'\s+', ' ', re.sub(r'[^a-z0-9 ]', ' ', s.lower())).strip()

        norm_query = _nc(query)

        def _fetch_magnet(item):
            page_url, name = item
            try:
                dhtml = _get(page_url, timeout=10, cf=True)
                m = _RE_RINTOR_MAGNET.search(dhtml or '')
                if not m:
                    return None
                magnet = m.group(0)
                ih_m = re.search(r'btih:([a-fA-F0-9]{40})', magnet)
                if not ih_m:
                    return None
                return {
                    'title':     name,
                    'magnet':    magnet,
                    'info_hash': ih_m.group(1).lower(),
                    'seeds':     0,
                    'size':      _rintor_human_size(magnet),
                    'source':    'Rintor',
                }
            except Exception:
                return None

        results = []
        from concurrent.futures import ThreadPoolExecutor
        with ThreadPoolExecutor(max_workers=min(8, len(candidates))) as pool:
            for r in pool.map(_fetch_magnet, candidates):
                if not r:
                    continue
                core = _nc(r['title'])
                if norm_query in core or core in norm_query:
                    results.append(r)
                if len(results) >= limit:
                    break
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Rintor] search error: %s' % e, xbmc.LOGWARNING)
        return []


# ── XXXTor (adult torrent tracker — Russian site but content/titles are the
# usual English scene releases, magnets sit directly in the search results
# HTML, no Cloudflare, no per-item detail fetch needed) ──────────────────────

XXXTOR_BASE = 'https://xxxtor.com'

_RE_XXXTOR_MAGNET = re.compile(r'magnet:\?[^"\'<> ]+', re.IGNORECASE)


def search_xxxtor(title, year=None, limit=15, media_type='adult'):
    if media_type != 'adult':
        return []
    try:
        title = _clean_adult_title(title) or title
        query = re.sub(r'\s+', ' ', title).strip()
        if not query:
            return []
        from urllib.parse import quote as _q
        url = '%s/b.php?search=%s&cat=0&page=1' % (XXXTOR_BASE, _q(query))
        html = _get(url, timeout=10)
        if not html:
            return []

        def _nc(s):
            return re.sub(r'\s+', ' ', re.sub(r'[^a-z0-9 ]', ' ', s.lower())).strip()

        norm_query = _nc(query)
        results = []
        for m in _RE_XXXTOR_MAGNET.finditer(html):
            if len(results) >= limit:
                break
            magnet = m.group(0).replace('&amp;', '&')
            ih_m = re.search(r'btih:([a-fA-F0-9]{40})', magnet, re.IGNORECASE)
            dn_m = re.search(r'[&?]dn=([^&"\'<\s]+)', magnet)
            if not ih_m or not dn_m:
                continue
            info_hash = ih_m.group(1).lower()
            import urllib.parse as _up
            name = _up.unquote(dn_m.group(1)).replace('+', ' ').strip()
            if name.lower().endswith('.torrent'):
                name = name[:-len('.torrent')]
            if not name or not _meets_quality(name, media_type):
                continue
            core = _nc(name)
            if norm_query not in core:
                continue
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': info_hash,
                'magnet':    magnet,
                'seeds':     0,
                'size':      '',
                'source':    'XXXTor',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] XXXTor error: %s' % e, xbmc.LOGWARNING)
        return []


# ── FreeJAVTorrent (JAV torrent tracker -- despite the name, its detail pages
# expose neither a magnet nor an info_hash directly. Each one links to
# dl.php?t=<id>, an interstitial ad page whose real "Download Torrent"
# button points at an actual .torrent file on a separate CDN host; this
# downloads that file and bencode-parses it for the info_hash, same
# technique as _torrent_info_hash's other callers.) ──────────────────────────

FREEJAVTORRENT_BASE = 'https://www.freejavtorrent.com'

_RE_FJT_ROW = re.compile(
    r'<div class="image-wrapper"><img src="([^"]*)" alt="([^"]+)">.*?'
    r'<a href="(https://www\.freejavtorrent\.com/[a-z0-9\-]+-(\d+)\.html)" class="overlay"',
    re.IGNORECASE | re.DOTALL
)
_RE_FJT_TORRENT_LINK = re.compile(r"href='(https://j\.freejavtorrent\.com/bt/[^']+\.torrent)'")
_RE_FJT_SIZE = re.compile(r'^\[([\d.]+\s*[A-Za-z]{2,3})\]')


def _fjt_get_bytes(url, timeout=15):
    s = _sess()
    try:
        if s:
            r = s.get(url, timeout=timeout)
            r.raise_for_status()
            return r.content
    except Exception:
        pass
    try:
        import urllib.request as _ur
        req = _ur.Request(url, headers=_BROWSER_HEADERS)
        with _ur.urlopen(req, timeout=timeout) as resp:
            return resp.read()
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] FreeJAVTorrent bytes fetch failed: %s' % e, xbmc.LOGWARNING)
        return b''


def search_freejavtorrent(title, year=None, limit=10, media_type='adult'):
    if media_type != 'adult':
        return []
    try:
        title = _clean_adult_title(title) or title
        query = re.sub(r'\s+', ' ', title).strip()
        if not query:
            return []
        from urllib.parse import quote as _q
        url = '%s/s.php?search=%s' % (FREEJAVTORRENT_BASE, _q(query))
        html = _get(url, timeout=10)
        if not html:
            return []

        def _nc(s):
            return re.sub(r'\s+', ' ', re.sub(r'[^a-z0-9 ]', ' ', s.lower())).strip()

        import html as _html_mod
        norm_query = _nc(query)
        candidates = []
        seen = set()
        for thumb, raw_title, _detail_url, vid in _RE_FJT_ROW.findall(html):
            if vid in seen:
                continue
            seen.add(vid)
            name = _html_mod.unescape(raw_title).strip()
            size_m = _RE_FJT_SIZE.match(name)
            size = size_m.group(1) if size_m else ''
            core_name = _RE_FJT_SIZE.sub('', name).strip()
            if not core_name or norm_query not in _nc(core_name):
                continue
            if not _meets_quality(core_name, media_type):
                continue
            candidates.append((vid, core_name, size))
            if len(candidates) >= limit * 2:
                break
        if not candidates:
            return []

        def _fetch(item):
            vid, name, size = item
            try:
                interstitial = _get('%s/dl.php?t=%s' % (FREEJAVTORRENT_BASE, vid), timeout=10)
                if not interstitial:
                    return None
                m = _RE_FJT_TORRENT_LINK.search(interstitial)
                if not m:
                    return None
                torrent_bytes = _fjt_get_bytes(m.group(1), timeout=15)
                if not torrent_bytes:
                    return None
                info_hash = _torrent_info_hash(torrent_bytes)
                if not info_hash:
                    return None
                return {
                    'title':     name,
                    'year':      '',
                    'quality':   _extract_quality(name),
                    'info_hash': info_hash,
                    'magnet':    _make_magnet(info_hash, name),
                    'seeds':     0,
                    'size':      size,
                    'source':    'FreeJAVTorrent',
                }
            except Exception:
                return None

        results = []
        from concurrent.futures import ThreadPoolExecutor
        with ThreadPoolExecutor(max_workers=min(10, len(candidates))) as pool:
            for r in pool.map(_fetch, candidates):
                if r:
                    results.append(r)
                if len(results) >= limit:
                    break
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] FreeJAVTorrent error: %s' % e, xbmc.LOGWARNING)
        return []


# ── IJAVTorrent (JAV torrent tracker -- real magnets AND real cover art sit
# directly in the search results HTML, no per-item detail fetch needed at
# all. projectjav.com mirrors the exact same backend/content (confirmed
# live: identical info_hashes in the same order), so it's just a fallback
# domain here, not a separate source.) ───────────────────────────────────────

_IJAVTORRENT_MIRRORS = ['https://ijavtorrent.com', 'https://projectjav.com']

_RE_IJAVTORRENT_ROW = re.compile(
    r'data-src="(https://images\.ijavtorrent\.com/data/covers/\d+\.jpg)"[^>]*alt="([^"]+)".*?'
    r'href="(magnet:\?xt=urn:btih:[a-fA-F0-9]{40}[^"]*)"',
    re.IGNORECASE | re.DOTALL
)


def search_ijavtorrent(title, year=None, limit=10, media_type='adult'):
    if media_type != 'adult':
        return []
    try:
        title = _clean_adult_title(title) or title
        query = re.sub(r'\s+', ' ', title).strip()
        if not query:
            return []
        from urllib.parse import quote as _q
        html = ''
        for base in _IJAVTORRENT_MIRRORS:
            html = _get('%s/?s=%s' % (base, _q(query)), timeout=10)
            if html:
                break
        if not html:
            return []

        def _nc(s):
            return re.sub(r'\s+', ' ', re.sub(r'[^a-z0-9 ]', ' ', s.lower())).strip()

        import html as _html_mod
        norm_query = _nc(query)
        results = []
        for _cover, raw_title, raw_magnet in _RE_IJAVTORRENT_ROW.findall(html):
            if len(results) >= limit:
                break
            name = _html_mod.unescape(raw_title).strip()
            if not name or norm_query not in _nc(name):
                continue
            if not _meets_quality(name, media_type):
                continue
            magnet = _html_mod.unescape(raw_magnet).replace('&amp;', '&')
            ih_m = re.search(r'btih:([a-fA-F0-9]{40})', magnet, re.IGNORECASE)
            if not ih_m:
                continue
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih_m.group(1).lower(),
                'magnet':    magnet,
                'seeds':     0,
                'size':      '',
                'source':    'IJAVTorrent',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] IJAVTorrent error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Nyaa.si (anime / Japanese media, also has live-action movies) ─────────────

_NYAA_RSS = 'https://nyaa.si/?page=rss&q={q}&c=0_0&f=0'
_RE_NYAA_HASH  = re.compile(r'<nyaa:infoHash>([a-fA-F0-9]{40})</nyaa:infoHash>', re.IGNORECASE)
_RE_NYAA_SEED  = re.compile(r'<nyaa:seeders>(\d+)</nyaa:seeders>', re.IGNORECASE)
_RE_NYAA_SIZE  = re.compile(r'<nyaa:size>([^<]+)</nyaa:size>', re.IGNORECASE)
_RE_NYAA_TITLE = re.compile(r'<title><!\[CDATA\[([^\]]+)\]\]></title>', re.IGNORECASE)
_RE_NYAA_ITEM  = re.compile(r'<item>(.*?)</item>', re.IGNORECASE | re.DOTALL)


def search_nyaa(title, year=None, limit=8, media_type='movie'):
    """Nyaa.si RSS search — best for anime; also indexes live-action J-movies.
    Confirmed live via kodi.log across many real searches (movies, TV,
    anime and non-anime alike): nyaa.si is consistently unreachable from
    this network right now — every single attempt fails at the TCP
    connect stage (ConnectTimeoutError), never even reaching an HTTP
    response, and it's always the last source search_all() waits on,
    adding its full timeout to every single search. A real, live
    connection attempt succeeds or fails well under a second; a 10s
    timeout on something that never once connects is pure dead time
    tacked onto every search this addon does. Cut way down rather than
    removed outright, in case the block is transient and it recovers."""
    try:
        from urllib.parse import quote as _q
        query = title
        if year and media_type not in ('adult',):
            query = '%s %s' % (title, year)
        url = _NYAA_RSS.format(q=_q(query))
        rss = _get(url, timeout=3)
        if not rss:
            return []
        results = []
        for item_m in _RE_NYAA_ITEM.finditer(rss):
            if len(results) >= limit:
                break
            item = item_m.group(1)
            ih_m = _RE_NYAA_HASH.search(item)
            if not ih_m:
                continue
            ih = ih_m.group(1).lower()
            title_m = _RE_NYAA_TITLE.search(item)
            name = title_m.group(1).strip() if title_m else ''
            if not name or not _meets_quality(name, media_type):
                continue
            seeds_m = _RE_NYAA_SEED.search(item)
            seeds = int(seeds_m.group(1)) if seeds_m else 0
            size_m = _RE_NYAA_SIZE.search(item)
            size = size_m.group(1).strip() if size_m else ''
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    _make_magnet(ih, name),
                'seeds':     seeds,
                'size':      size,
                'source':    'Nyaa',
            })
        return sorted(results, key=lambda x: x['seeds'], reverse=True)
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Nyaa error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Sukebei.Nyaa.si (adult/hentai counterpart to Nyaa, same RSS engine) ──────
# Confirmed live: identical RSS shape to nyaa.si itself (same <nyaa:*> tags,
# same c=0_0&f=0 query params), just a separate adult-only index at a
# different subdomain -- so this reuses the exact same _RE_NYAA_* regexes
# nyaa.si's own scraper already has, no new parsing logic needed.

_SUKEBEI_RSS = 'https://sukebei.nyaa.si/?page=rss&q={q}&c=0_0&f=0'
# Unlike nyaa.si's own <title><![CDATA[...]]></title>, sukebei's feed emits a
# plain, HTML-entity-escaped <title> with no CDATA wrapper -- confirmed live
# (real title came back as "...Okarun&#39;s Thing..." with no CDATA at all),
# so this needs its own regex + html.unescape() rather than reusing
# _RE_NYAA_TITLE, which silently matched nothing against this feed's shape.
_RE_SUKEBEI_TITLE = re.compile(r'<title>([^<]+)</title>', re.IGNORECASE)


def search_sukebei_nyaa(title, year=None, limit=10, media_type='adult'):
    if media_type != 'adult':
        return []
    try:
        from urllib.parse import quote as _q
        import html as _html
        rss = _get(_SUKEBEI_RSS.format(q=_q(title)), timeout=6)
        if not rss:
            return []
        results = []
        for item_m in _RE_NYAA_ITEM.finditer(rss):
            if len(results) >= limit:
                break
            item = item_m.group(1)
            ih_m = _RE_NYAA_HASH.search(item)
            if not ih_m:
                continue
            ih = ih_m.group(1).lower()
            title_m = _RE_SUKEBEI_TITLE.search(item)
            name = _html.unescape(title_m.group(1)).strip() if title_m else ''
            if not name:
                continue
            seeds_m = _RE_NYAA_SEED.search(item)
            seeds = int(seeds_m.group(1)) if seeds_m else 0
            size_m = _RE_NYAA_SIZE.search(item)
            size = size_m.group(1).strip() if size_m else ''
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    _make_magnet(ih, name),
                'seeds':     seeds,
                'size':      size,
                'source':    'Sukebei',
            })
        return sorted(results, key=lambda x: x['seeds'], reverse=True)
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Sukebei error: %s' % e, xbmc.LOGWARNING)
        return []


# ── BitDig (btdig.com) — DHT-crawler search engine ───────────────────────────
# Indexes files actually seen live on the DHT swarm, rather than scraping a
# tracker site's own upload database -- different mechanism than every other
# source in this file, so it surfaces torrents pure tracker-scrapers miss.
# No live seeder count is exposed (a DHT crawler doesn't track ongoing swarm
# health, only "last seen" + the file listing), so seeds is always 0 here;
# debrid resolution doesn't need a seed count and search_all()'s final sort
# just places these after sources that do report a real one. Confirmed live:
# relevance can be loose (BM25-style full-text match against files INSIDE a
# torrent, not just its own name), so this leans on search_all()'s own
# title-match filter to drop anything that doesn't actually match.

_RE_BTDIG_NAME   = re.compile(r'class="torrent_name"[^>]*><a[^>]*>([^<]+)</a>', re.IGNORECASE)
_RE_BTDIG_SIZE   = re.compile(r'class="torrent_size"[^>]*>([^<]+)<', re.IGNORECASE)
_RE_BTDIG_MAGNET = re.compile(r'href="(magnet:\?[^"]+)"', re.IGNORECASE)


def search_btdig(title, year=None, limit=8, media_type='movie'):
    try:
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        import urllib.parse as _up
        url = 'https://btdig.com/search?q=%s' % _up.quote(query)
        html_raw = _get(url, timeout=10)
        if not html_raw:
            return []
        import html as _html
        results = []
        for block in html_raw.split('class="one_result"')[1:]:
            if len(results) >= limit:
                break
            name_m = _RE_BTDIG_NAME.search(block)
            size_m = _RE_BTDIG_SIZE.search(block)
            magnet_m = _RE_BTDIG_MAGNET.search(block)
            if not (name_m and magnet_m):
                continue
            ih_m = re.search(r'btih:([a-fA-F0-9]{40})', magnet_m.group(1), re.IGNORECASE)
            if not ih_m:
                continue
            ih = ih_m.group(1).lower()
            name = _html.unescape(name_m.group(1)).strip()
            if not name or not _meets_quality(name, media_type):
                continue
            size = size_m.group(1).replace('\xa0', ' ').strip() if size_m else ''
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    _make_magnet(ih, name),
                'seeds':     0,
                'size':      size,
                'source':    'BitDig',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] BitDig error: %s' % e, xbmc.LOGWARNING)
        return []


# ── AnimeTosho (animetosho.org) — anime-specific, clean JSON API ─────────────
# feed.animetosho.org/json is a documented, keyless JSON search endpoint --
# no scraping needed. Returns its own 'magnet_uri' with a base32 BTIH
# (incompatible with every other source's hex-based info_hash/dedup), but
# also gives a separate plain hex 'info_hash' field directly, so that's used
# instead and a normal magnet is built via _make_magnet() like everywhere
# else in this file.

_ANIMETOSHO_API = 'https://feed.animetosho.org/json?q={q}'


def search_animetosho(title, year=None, limit=8, media_type='movie'):
    if media_type == 'adult':
        return []
    try:
        from urllib.parse import quote as _q
        query = title
        if year:
            query = '%s %s' % (title, year)
        data = _get_json(_ANIMETOSHO_API.format(q=_q(query)), timeout=8)
        if not data:
            return []
        results = []
        for item in data:
            if len(results) >= limit:
                break
            ih = (item.get('info_hash') or '').lower()
            name = item.get('torrent_name') or item.get('title') or ''
            if not ih or not name or not _meets_quality(name, media_type):
                continue
            b = item.get('total_size') or 0
            size = ''
            if b >= 1_073_741_824:
                size = '%.1f GB' % (b / 1_073_741_824)
            elif b >= 1_048_576:
                size = '%.0f MB' % (b / 1_048_576)
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    _make_magnet(ih, name),
                'seeds':     item.get('seeders', 0) or 0,
                'size':      size,
                'source':    'AnimeTosho',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] AnimeTosho error: %s' % e, xbmc.LOGWARNING)
        return []


# ── LimeTorrents (limetorrents.fun + mirrors) ─────────────────────────────────
# .info/.cc/limetor.com confirmed DNS-dead live (getaddrinfo failure, not
# just blocked) — .fun confirmed live and working (once the Accept-Encoding
# fix above stopped Brotli garbage from masquerading as a dead site). Kept
# the old domains in the list rather than deleting them outright in case
# any of them comes back; .fun just goes first so the common case doesn't
# pay for 3 guaranteed-dead DNS lookups every cache cycle.

_LIME_MIRRORS = [
    'https://limetorrents.fun',
    'https://www.limetorrents.info',
    'https://limetorrents.cc',
    'https://limetor.com',
]
_lime_working = {}

_RE_LIME_ROW  = re.compile(
    r'<div[^>]+class="[^"]*tt-name[^"]*"[^>]*>.*?'
    r'<a[^>]+href="([^"]+/torrent/[^"]+)"[^>]*></a>.*?'
    r'<a[^>]+>([^<]+)</a>.*?'
    r'<td[^>]+class="[^"]*tdseed[^"]*"[^>]*>([,\d]+)<',
    re.IGNORECASE | re.DOTALL
)
_RE_LIME_HASH = re.compile(r'/torrent/([a-fA-F0-9]{40})/*', re.IGNORECASE)
_RE_LIME_SIZE = re.compile(r'(\d+(?:\.\d+)?)\s*(KB|GB|MB|GiB|MiB)', re.IGNORECASE)


def _get_lime_base():
    cached = _lime_working.get('url')
    ts     = _lime_working.get('ts', 0)
    if cached and (time.time() - ts) < 3600:
        return cached
    for mirror in _LIME_MIRRORS:
        try:
            html = _get(mirror + '/', timeout=7)
            if html and 'torrent' in html.lower():
                _lime_working['url'] = mirror
                _lime_working['ts']  = time.time()
                return mirror
        except Exception:
            continue
    # Nothing passed the health check this cycle — fall back to whichever
    # mirror is CURRENTLY confirmed live (.fun), not just the list's first
    # entry, which used to be .info (confirmed DNS-dead) and would have
    # guaranteed the actual search request failed too.
    return 'https://limetorrents.fun'


def search_limetorrents(title, year=None, limit=5, media_type='movie'):
    """LimeTorrents — HTML scrape with mirror rotation."""
    try:
        base  = _get_lime_base()
        query = re.sub(r'\s+', '-', title.lower())
        if year and media_type != 'adult':
            query = '%s-%s' % (query, year)
        url  = '%s/search/all/%s/seeds/1/' % (base, query)
        html = _get(url, timeout=10)
        if not html:
            return []
        results = []
        for row_m in _RE_LIME_ROW.finditer(html):
            if len(results) >= limit:
                break
            path, name, seeds = row_m.group(1), row_m.group(2).strip(), row_m.group(3)
            seeds = seeds.replace(',', '')
            if not _meets_quality(name, media_type):
                continue
            # Hash embedded in torrent detail path
            ih_m = _RE_LIME_HASH.search(path)
            if ih_m:
                ih = ih_m.group(1).lower()
            else:
                # Fetch detail page for hash
                try:
                    detail = _get(base + path, timeout=7)
                    ih_m2  = re.search(r'magnet:.*?btih:([a-fA-F0-9]{40})', detail, re.IGNORECASE)
                    ih     = ih_m2.group(1).lower() if ih_m2 else ''
                except Exception:
                    ih = ''
            if not ih:
                continue
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    _make_magnet(ih, name),
                'seeds':     int(seeds),
                'size':      '',
                'source':    'LimeTorrents',
            })
        return sorted(results, key=lambda x: x['seeds'], reverse=True)
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] LimeTorrents error: %s' % e, xbmc.LOGWARNING)
        return []


# ── TorLock (torlock.com) ─────────────────────────────────────────────────────

_TORLOCK_MIRRORS = ['https://www.torlock.com', 'https://www.torlock2.com']
_torlock_working = {}

_RE_TORLOCK_ROW = re.compile(
    r'<a[^>]+href="/torrent/(\d+)/([^"]+\.html)"[^>]*>([^<]+)</a>'
    r'.*?<td[^>]*>(\d+)</td>',
    re.IGNORECASE | re.DOTALL
)
_RE_TORLOCK_HASH = re.compile(r'<td[^>]*>([a-fA-F0-9]{40})</td>', re.IGNORECASE)
_RE_TORLOCK_MAG  = re.compile(r'href="(magnet:\?[^"]+)"', re.IGNORECASE)


def _get_torlock_base():
    cached = _torlock_working.get('url')
    ts     = _torlock_working.get('ts', 0)
    if cached and (time.time() - ts) < 3600:
        return cached
    for mirror in _TORLOCK_MIRRORS:
        try:
            html = _get(mirror + '/', timeout=7)
            if html and 'torrent' in html.lower():
                _torlock_working['url'] = mirror
                _torlock_working['ts']  = time.time()
                return mirror
        except Exception:
            continue
    return _TORLOCK_MIRRORS[0]


def search_torlock(title, year=None, limit=5, media_type='movie'):
    """TorLock — HTML scrape."""
    try:
        base  = _get_torlock_base()
        query = re.sub(r'\s+', '-', title.lower())
        if year and media_type != 'adult':
            query = '%s-%s' % (query, year)
        cat_path = 'all'
        if media_type == 'movie':
            cat_path = 'movie'
        elif media_type == 'tv':
            cat_path = 'television'
        url  = '%s/%s/torrents/%s.html?sort=seeds' % (base, cat_path, query)
        html = _get(url, timeout=10)
        if not html:
            return []
        results = []
        for row_m in _RE_TORLOCK_ROW.finditer(html):
            if len(results) >= limit:
                break
            tid, _, name, seeds = (
                row_m.group(1), row_m.group(2),
                row_m.group(3).strip(), row_m.group(4)
            )
            if not _meets_quality(name, media_type):
                continue
            # Magnet from detail page
            try:
                detail = _get('%s/torrent/%s/x.html' % (base, tid), timeout=8)
                mag_m  = _RE_TORLOCK_MAG.search(detail)
                if not mag_m:
                    ih_m = _RE_TORLOCK_HASH.search(detail)
                    if ih_m:
                        ih     = ih_m.group(1).lower()
                        magnet = _make_magnet(ih, name)
                    else:
                        continue
                else:
                    magnet = mag_m.group(1).replace('&amp;', '&').split('&tr=')[0]
                    ih_m   = re.search(r'btih:([a-fA-F0-9]{40})', magnet, re.IGNORECASE)
                    ih     = ih_m.group(1).lower() if ih_m else ''
            except Exception:
                continue
            if not ih:
                continue
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    magnet,
                'seeds':     int(seeds),
                'size':      '',
                'source':    'TorLock',
            })
        return sorted(results, key=lambda x: x['seeds'], reverse=True)
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] TorLock error: %s' % e, xbmc.LOGWARNING)
        return []


# ── msearch.vercel.app (meta-search — real backend is Algolia, not a REST API
# of its own) ──────────────────────────────────────────────────────────────
#
# Confirmed live 2026-09-04: the msearch.vercel.app frontend has no API
# route of its own at all — this file's previous implementation guessed 3
# plausible-looking Vercel/Next.js REST paths (`/api/search`, `/api/torrents`,
# `/api/search?category=`), none of which ever existed, which is why this
# source has been silently returning 0 results this whole time despite never
# throwing an error. Reading the site's own tiny JS bundle
# (app.e3e6859d.js) shows the real mechanism: it's an Algolia InstantSearch
# widget, `algoliasearch("7OOB1B3OF6", "4c16fab3a20a692c2e63f48830b554e4")`
# against index "stream" — a public, search-only API key (the same kind
# every Algolia-powered site ships client-side on purpose; this is not a
# secret being exposed). Also confirmed live the SAME day: that Algolia
# application id's own DNS entry (7oob1b3of6-dsn.algolia.net) does not
# resolve at all right now — a different, well-known Algolia app
# (bh4d9od16a-dsn.algolia.net, a public DocSearch demo) resolves fine from
# the same network, so this isn't a local DNS/connectivity problem, it's
# specifically this one Algolia application/cluster being gone (deleted,
# suspended, or migrated) even though the static msearch.vercel.app
# frontend is still up and still references it. So this source is
# currently non-functional either way — but calling the REAL endpoint
# (rather than 3 URLs that never existed to begin with) means this comes
# back to life on its own the moment MSearch's Algolia backend does,
# without needing another round of guessing.
_MSEARCH_ALGOLIA_HOST = 'https://7OOB1B3OF6-dsn.algolia.net/1/indexes/stream/query'
_MSEARCH_HEADERS = {
    'X-Algolia-API-Key':         '4c16fab3a20a692c2e63f48830b554e4',
    'X-Algolia-Application-Id':  '7OOB1B3OF6',
    'Content-Type':              'application/json',
}


def search_msearch_torrents(title, year=None, limit=10, media_type='movie'):
    """
    msearch.vercel.app — meta-search aggregator, real backend is Algolia
    (see the comment above this function for how that was found).
    """
    try:
        if not _req:
            return []
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        body = {'params': 'query=%s&hitsPerPage=%d' % (query, max(limit * 2, 10))}
        r = _sess().post(_MSEARCH_ALGOLIA_HOST, json=body, headers=_MSEARCH_HEADERS, timeout=12)
        r.raise_for_status()
        data = r.json()
        items = data.get('hits') or []
        results = []
        for item in items:
            if len(results) >= limit:
                break
            name = (item.get('title') or item.get('name') or '').strip()
            if not name or not _meets_quality(name, media_type):
                continue
            ih = (item.get('infohash') or item.get('info_hash') or
                  item.get('hash') or '').lower()
            magnet = item.get('download') or item.get('magnet') or ''
            if not ih and magnet:
                ih_m = re.search(r'btih:([a-fA-F0-9]{40})', magnet, re.IGNORECASE)
                if ih_m:
                    ih = ih_m.group(1).lower()
            if not ih:
                continue
            if not magnet:
                magnet = _make_magnet(ih, name)
            seeds = int(item.get('seeders') or item.get('seeds') or 0)
            b     = item.get('size') or item.get('bytes') or 0
            size  = ''
            if isinstance(b, int):
                if b >= 1_073_741_824:
                    size = '%.1f GB' % (b / 1_073_741_824)
                elif b >= 1_048_576:
                    size = '%.0f MB' % (b / 1_048_576)
            elif isinstance(b, str):
                size = b
            results.append({
                'title': name, 'year': '', 'quality': _extract_quality(name),
                'info_hash': ih, 'magnet': magnet,
                'seeds': seeds, 'size': size, 'source': 'MSearch',
            })
        return sorted(results, key=lambda x: x['seeds'], reverse=True)
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] MSearch error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Cleanbay (cleanbay.netlify.app — torrent metasearch: piratebay/yts/eztv/
# linuxtracker/libgen/nyaa) ────────────────────────────────────────────────────
#
# The cleanbay.netlify.app frontend is a static React app with no API of
# its own — every search goes straight from the browser to its actual
# backend, testbay.onrender.com (a separate Render-hosted service, found
# by reading the site's own shipped JS bundle for the literal API URL).
# That backend itself live-queries piratebay/yts/eztv/linuxtracker/libgen/
# nyaa per-request (per its own /docs page: "Cleanbay works by searching
# the torrent indexes on-demand... does not store any torrents or
# associated data") and already returns ready-to-use magnet URIs, so no
# per-item resolve step is needed here (unlike DaMagNet elsewhere in this
# file). Confirmed live 2026-09-03: an unfiltered query for a popular
# title ("inception") returned 0 results — piratebay/yts/linuxtracker/eztv
# all appear dead upstream of this backend right now — but the same
# backend still returned 75 real hits with real magnets/seeders for "one
# piece" (served from nyaa, per each hit's own "uploader" field). Left
# unfiltered (no include_sites) anyway rather than hardcoding site:nyaa,
# since that's the one config that keeps surfacing whatever subset of the
# 6 backing sites is alive at request time without needing its own
# separate maintenance as those sites individually rot further. Render's
# free tier sleeps this backend after inactivity — a cold start alone
# took ~10s in testing — so this is given a longer-than-usual timeout; a
# search_all() run that catches it asleep just times out like any other
# slow source rather than erroring.
_CLEANBAY_API = 'https://testbay.onrender.com/api/v1/search'


def search_cleanbay(title, year=None, limit=10, media_type='movie'):
    try:
        if not _req:
            return []
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        payload = {
            'search_term': query,
            'include_categories': [], 'exclude_categories': [],
            'include_sites': [], 'exclude_sites': [],
        }
        r = _sess().post(_CLEANBAY_API, json=payload, timeout=20)
        r.raise_for_status()
        items = (r.json() or {}).get('data') or []
        results = []
        for item in items:
            if len(results) >= limit:
                break
            name = (item.get('name') or '').strip()
            if not name or not _meets_quality(name, media_type):
                continue
            magnet = item.get('magnet') or ''
            ih_m = re.search(r'btih:([a-fA-F0-9]{40})', magnet, re.IGNORECASE)
            if not ih_m:
                continue
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih_m.group(1).lower(),
                'magnet':    magnet,
                'seeds':     int(item.get('seeders') or 0),
                'size':      item.get('size') or '',
                'source':    'Cleanbay',
            })
        return sorted(results, key=lambda x: x['seeds'], reverse=True)
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Cleanbay error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Torrentio (IMDB-based, requires imdb_id) ──────────────────────────────────

TORRENTIO_BASE = 'https://torrentio.strem.fun'

def search_torrentio(imdb_id, season=None, episode=None, limit=60, media_type='movie'):
    """Query Torrentio API by IMDB ID. Returns magnet list sorted by seeds.
    Torrentio itself is a single, cheap JSON call (not per-item HTML scraping
    like the other sources here), so there's no real cost to keeping a much
    larger slice of what it returns. Confirmed live: a 4K release is a much
    bigger file than a 1080p/720p one of the same title, so it almost always
    has fewer seeders — sorting purely by seeds and truncating to a small
    limit (previously 10-20) systematically threw away the 4K options before
    they ever reached the final quality-based sort in metadata_router.py,
    which is exactly why 4K never showed up here despite Torrentio actually
    having it."""
    if not imdb_id:
        return []
    try:
        import urllib.request as _ureq, json as _json
        if season is not None and episode is not None:
            path = '/stream/series/%s:%d:%d.json' % (imdb_id, int(season), int(episode))
        else:
            path = '/stream/movie/%s.json' % imdb_id
        url = TORRENTIO_BASE + path
        req = _ureq.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with _ureq.urlopen(req, timeout=12) as resp:
            data = _json.loads(resp.read().decode('utf-8'))
        results = []
        for stream in data.get('streams', []):
            ih = stream.get('infoHash', '')
            if not ih:
                continue
            raw_title = stream.get('title', '') or ''
            name = raw_title.split('\n')[0].strip()
            # Torrentio itself doesn't filter by quality — without this, CAM/
            # screener/480p-and-below releases (which real seed counts don't
            # otherwise discourage here) landed in the picker right alongside
            # good encodes, the same gap every other scraper in this file
            # already closes via _meets_quality.
            if not _meets_quality(name, media_type):
                continue
            # Parse seeds from title lines (emoji 👤 + number)
            seeds = 0
            for line in raw_title.split('\n')[1:]:
                m = re.search(r'(\d+)', line)
                if m:
                    seeds = int(m.group(1))
                    break
            magnet = _make_magnet(ih, name)
            results.append({
                'title':     name,
                'quality':   _extract_quality(name),
                'info_hash': ih.lower(),
                'magnet':    magnet,
                'seeds':     seeds,
                'size':      0,
                'source':    'Torrentio',
            })
        results.sort(key=lambda x: x['seeds'], reverse=True)
        return results[:limit]
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Torrentio error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Comet (public Stremio-style meta-search, same protocol as Torrentio) ─────

COMET_BASE = 'https://comet.feels.legal'
_RE_COMET_SIZE = re.compile(r'💾\s*([\d.,]+\s*(?:GB|GiB|MB|MiB))', re.IGNORECASE)


def search_comet(imdb_id, season=None, episode=None, limit=40, media_type='movie'):
    """Comet (comet.feels.legal) — a public Stremio meta-search addon
    aggregating many indexers behind the same 'streams' JSON protocol
    Torrentio uses. Confirmed live: 1000+ real streams for a single
    popular movie. imdb_id required, same as Torrentio — this API shape
    has no free-text search."""
    if not imdb_id:
        return []
    try:
        if season is not None and episode is not None:
            path = '/stream/series/%s:%d:%d.json' % (imdb_id, int(season), int(episode))
        else:
            path = '/stream/movie/%s.json' % imdb_id
        data = _get_json(COMET_BASE + path, timeout=12)
        if not data:
            return []
        results = []
        for stream in data.get('streams', []):
            ih = (stream.get('infoHash') or '').lower()
            if not ih:
                continue
            desc = stream.get('description') or stream.get('name') or ''
            name = re.sub(r'^[^\w(\[]+', '', desc.split('\n')[0]).strip()
            if not name or not _meets_quality(name, media_type):
                continue
            size_m = _RE_COMET_SIZE.search(desc)
            size = size_m.group(1).strip() if size_m else ''
            results.append({
                'title': name, 'year': '', 'quality': _extract_quality(name),
                'info_hash': ih, 'magnet': _make_magnet(ih, name),
                'seeds': 0, 'size': size, 'source': 'Comet',
            })
        return results[:limit]
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Comet error: %s' % e, xbmc.LOGWARNING)
        return []


# ── StremThru (torz.13377001.xyz-style public torrent index proxy) ──────────

TORZ_BASE = 'https://stremthru.13377001.xyz'


def search_torz(imdb_id, season=None, episode=None, limit=40, media_type='movie'):
    """StremThru (stremthru.13377001.xyz) — a public torrent-index proxy,
    keyed by imdb_id like Torrentio/Comet but with a much cleaner JSON
    shape (no emoji-encoded description parsing needed at all)."""
    if not imdb_id:
        return []
    try:
        if season is not None and episode is not None:
            sid = '%s:%d:%d' % (imdb_id, int(season), int(episode))
        else:
            sid = imdb_id
        data = _get_json('%s/v0/torrents?sid=%s' % (TORZ_BASE, sid), timeout=15)
        if not data:
            return []
        items = (data.get('data') or {}).get('items') or []
        results = []
        for item in items:
            if len(results) >= limit:
                break
            ih = (item.get('hash') or '').lower()
            name = item.get('name') or ''
            if not ih or not name or not _meets_quality(name, media_type):
                continue
            b = item.get('size') or 0
            size = ''
            if b >= 1_073_741_824:
                size = '%.1f GB' % (b / 1_073_741_824)
            elif b >= 1_048_576:
                size = '%.0f MB' % (b / 1_048_576)
            results.append({
                'title': name, 'year': '', 'quality': _extract_quality(name),
                'info_hash': ih, 'magnet': _make_magnet(ih, name),
                'seeds': int(item.get('seeders') or 0), 'size': size, 'source': 'StremThru',
            })
        return sorted(results, key=lambda x: x['seeds'], reverse=True)
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] StremThru error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Bitmagnet (public torznab-protocol meta-search, same imdb_id-keyed shape
# as Torrentio/Comet but returns torznab XML instead of the streams-JSON
# protocol) ───────────────────────────────────────────────────────────────────

BITMAGNET_BASE = 'https://bitmagnetfortheweebs.midnightignite.me'


def search_bitmagnet(imdb_id, season=None, episode=None, limit=40, media_type='movie'):
    """Bitmagnet — a public torznab-protocol meta-search addon, keyed by
    imdb_id like Torrentio/Comet/StremThru but speaking the older Newznab/
    torznab XML API shape (item/torznab:attr) instead of a streams JSON
    array."""
    if not imdb_id:
        return []
    try:
        import xml.etree.ElementTree as ET
        if season is not None and episode is not None:
            path = '/torznab/api?t=tvsearch&imdbid=%s&season=%s&ep=%s' % (imdb_id, season, episode)
        else:
            path = '/torznab/api?t=movie&imdbid=%s' % imdb_id
        xml_text = _get(BITMAGNET_BASE + path, timeout=12)
        if not xml_text:
            return []
        root = ET.fromstring(xml_text)
        results = []
        for item in root.iter('item'):
            if len(results) >= limit:
                break
            attr_dict = {}
            title_el = item.find('title')
            if title_el is not None and title_el.text:
                attr_dict['title'] = title_el.text
            for attr in item.findall('{http://torznab.com/schemas/2015/feed}attr'):
                key, val = attr.get('name'), attr.get('value')
                if key:
                    attr_dict[key] = val
            name = attr_dict.get('title') or ''
            ih = (attr_dict.get('infohash') or '').lower()
            if not ih or not name or not _meets_quality(name, media_type):
                continue
            size = ''
            try:
                b = float(attr_dict.get('size') or 0)
                if b >= 1_073_741_824:
                    size = '%.1f GB' % (b / 1_073_741_824)
                elif b >= 1_048_576:
                    size = '%.0f MB' % (b / 1_048_576)
            except Exception:
                pass
            results.append({
                'title': name, 'year': '', 'quality': _extract_quality(name),
                'info_hash': ih, 'magnet': _make_magnet(ih, name),
                'seeds': int(attr_dict.get('seeders') or 0), 'size': size, 'source': 'Bitmagnet',
            })
        return sorted(results, key=lambda x: x['seeds'], reverse=True)
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Bitmagnet error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Zilean (DMM hash-cache proxy, imdb_id-keyed) ─────────────────────────────
# All 5 of Zilean/MediaFusion/Meteor/AIOStreams/TorrentsDB below are public
# meta-search aggregators, not trackers of their own — they re-serve results
# already scraped from the same well-known public sites this file already
# scrapes directly (YTS, EZTV, 1337x, Knaben, LimeTorrents, TPB, RARBG-clones,
# Nyaa, etc. — torrentsdb.py's own upstream docstring lists exactly this set).
# Kept anyway as redundant fallback paths: if one direct scraper gets briefly
# blocked, an aggregator indexing the same site may still surface it.

ZILEAN_BASE = 'https://zileanfortheweebs.midnightignite.me'


def search_zilean(imdb_id, season=None, episode=None, limit=40, media_type='movie'):
    """Zilean — DMM community hash-cache, keyed by imdb_id. Returns a bare
    JSON array (not wrapped in a 'streams' key like the others), with the
    hash/size/raw title already flat on each entry — no description parsing
    needed at all."""
    if not imdb_id:
        return []
    try:
        if season is not None and episode is not None:
            url = '%s/dmm/filtered?ImdbId=%s&Season=%s&Episode=%s' % (ZILEAN_BASE, imdb_id, season, episode)
        else:
            url = '%s/dmm/filtered?ImdbId=%s' % (ZILEAN_BASE, imdb_id)
        data = _get_json(url, timeout=10)
        if not data:
            return []
        results = []
        for f in data:
            if len(results) >= limit:
                break
            ih = (f.get('info_hash') or '').lower()
            name = f.get('raw_title') or ''
            if not ih or not name or not _meets_quality(name, media_type):
                continue
            size = ''
            try:
                b = float(f.get('size') or 0)
                if b >= 1_073_741_824:
                    size = '%.1f GB' % (b / 1_073_741_824)
                elif b >= 1_048_576:
                    size = '%.0f MB' % (b / 1_048_576)
            except Exception:
                pass
            results.append({
                'title': name, 'year': '', 'quality': _extract_quality(name),
                'info_hash': ih, 'magnet': _make_magnet(ih, name),
                'seeds': 0, 'size': size, 'source': 'Zilean',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Zilean error: %s' % e, xbmc.LOGWARNING)
        return []


# ── MediaFusion (imdb_id-keyed, streams-JSON protocol) ───────────────────────

MEDIAFUSION_BASE = 'https://mediafusionfortheweebs.midnightignite.me'
_MEDIAFUSION_TOKEN = (
    'D-h5mpsX35oygOGFiHutl66dLAPiXzjQTODPXKQuKBaQOLjwNBbVkSPi7TJPr0gdykpCFREq8JOh'
    'DHZcvoS_UNZsWpsbjscCAwzgqc9VvP0S3Wt9lz5blcPT8lU6fcHdAHYctp_yde6nWKtSQ1O9Tjeh'
    'GNwajH9TjGZwn6rOybPFmoMpccXfTkB3Xwe9xRhT9O-bKzoYnGnlG8fCDxlNGdzrnlythePc3C7O'
    'phF8b5GyhuSnvBhxD7dTfkI77Dbay8_k_wqS-me9euZQ-oyOJBNTOIsO8HiWQhLGCC8m9rYsqJT6'
    'QF1Xhn-2bNzlukfbSYh_X1kOFdi6Y-YkBeEYokDlQHzzU45qmrj2b1Nz-GALcJHjNDJEMF3h9Eyx'
    '7UcmGWT1qvTpv_tcXjAX37ceqrWH-e_EqwVkvQDjNnmpjOhBWhuUW2R-0KbvxKUn1s5d2jZjLBxC'
    'bMotHIC-G2SrVCLgC_KV0OUainevUHKOKTe0CQmWz1HKV1ju52CFZFZYAWkOAX5cw55qzNnWl_nQ'
    'RnLyngrW_P6aYqghbYyyrAvQ6hCrIbSnVj4GsMFIelcMETvGW4jIXdwZGZA1L8gCzmyCbI9vAqPv'
    'dZxRWb7roc2EnB7gaSYdFtTP9gGoFKKkQ-9aircUEiPXjkP4QWO7lVI4GZri7KKCKjBM7-hWf4nm'
    'ttY7lJS_4Te_H80BeR_qpqeYQ6V0gpVwihARA6cIsZFbWmQXtoYNO16jt1ZqeVztwR6L1IQQnAsH'
    'ANyR5kF7ovGCOnhWlDDxO3nk8fhm3s0k7XewrMisZHy1zNsivTjvJW6KoVwghLn8-QCTf9PEPoPj'
    's6tW5KjciaRvbMg5-mbhpAhYOmPisB4ZyW63vWY6TeU1OBJV0T_fkHtgbvgiTEX5RFoRVDLnhaof'
    '-xHVw2oCc2AdXmBDVROmFjY8x9KEyZ91QfNjHnrTFmGetelcHE'
)
_RE_MF_INFO = re.compile(r'💾.*')
_RE_MF_SEEDS = re.compile(r'👤\s*(\d+)')


def search_mediafusion(imdb_id, season=None, episode=None, limit=40, media_type='movie'):
    if not imdb_id:
        return []
    try:
        if season is not None and episode is not None:
            path = '/%s/stream/series/%s:%s:%s.json' % (_MEDIAFUSION_TOKEN, imdb_id, season, episode)
        else:
            path = '/%s/stream/movie/%s.json' % (_MEDIAFUSION_TOKEN, imdb_id)
        data = _get_json(MEDIAFUSION_BASE + path, timeout=12)
        if not data:
            return []
        results = []
        for stream in data.get('streams', []):
            if len(results) >= limit:
                break
            ih = (stream.get('infoHash') or '').lower()
            if not ih:
                continue
            desc = stream.get('description') or ''
            lines = desc.replace('┈➤', '\n').split('\n')
            name = lines[0].strip() if lines else ''
            if not name or not _meets_quality(name, media_type):
                continue
            info_line = next((l for l in lines if _RE_MF_INFO.search(l)), '')
            seeds_m = _RE_MF_SEEDS.search(info_line)
            seeds = int(seeds_m.group(1)) if seeds_m else 0
            size_m = re.search(r'((?:\d+,\d+\.\d+|\d+\.\d+|\d+,\d+|\d+)\s*(?:GB|GiB|Gb|MB|MiB|Mb))', info_line)
            size = size_m.group(1) if size_m else ''
            results.append({
                'title': name, 'year': '', 'quality': _extract_quality(name),
                'info_hash': ih, 'magnet': _make_magnet(ih, name),
                'seeds': seeds, 'size': size, 'source': 'MediaFusion',
            })
        return sorted(results, key=lambda x: x['seeds'], reverse=True)
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] MediaFusion error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Meteor (imdb_id-keyed, streams-JSON protocol) ────────────────────────────

METEOR_BASE = 'https://meteorfortheweebs.midnightignite.me'
_RE_METEOR_SEEDS = re.compile(r'👥\s*(\d+)')


def search_meteor(imdb_id, season=None, episode=None, limit=40, media_type='movie'):
    if not imdb_id:
        return []
    try:
        if season is not None and episode is not None:
            path = '/stream/series/%s:%s:%s.json' % (imdb_id, season, episode)
        else:
            path = '/stream/movie/%s.json' % imdb_id
        data = _get_json(METEOR_BASE + path, timeout=12)
        if not data:
            return []
        results = []
        for stream in data.get('streams', []):
            if len(results) >= limit:
                break
            ih = (stream.get('infoHash') or '').lower()
            if not ih:
                continue
            desc = stream.get('description') or ''
            lines = desc.split('\n')
            name = lines[0].strip() if lines else ''
            if not name or not _meets_quality(name, media_type):
                continue
            info_line = next((l for l in lines if _RE_MF_INFO.search(l)), '')
            seeds_m = _RE_METEOR_SEEDS.search(info_line)
            seeds = int(seeds_m.group(1)) if seeds_m else 0
            size_m = re.search(r'((?:\d+,\d+\.\d+|\d+\.\d+|\d+,\d+|\d+)\s*(?:GB|GiB|Gb|MB|MiB|Mb))', info_line)
            size = size_m.group(1) if size_m else ''
            results.append({
                'title': name, 'year': '', 'quality': _extract_quality(name),
                'info_hash': ih, 'magnet': _make_magnet(ih, name),
                'seeds': seeds, 'size': size, 'source': 'Meteor',
            })
        return sorted(results, key=lambda x: x['seeds'], reverse=True)
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Meteor error: %s' % e, xbmc.LOGWARNING)
        return []


# ── TorrentsDB (imdb_id-keyed, aggregates YTS/EZTV/1337x/Knaben/LimeTorrent/
# RARBG/ThePirateBay/KickassTorrents/Nyaa/YggTorrent/Rutracker and more) ──────

TORRENTSDB_BASE = 'https://torrentsdb.com'
_RE_TSDB_SEEDS = re.compile(r'👤\s*(\d+)')


def search_torrentsdb(imdb_id, season=None, episode=None, limit=40, media_type='movie'):
    if not imdb_id:
        return []
    try:
        if season is not None and episode is not None:
            path = '/stream/series/%s:%s:%s.json' % (imdb_id, season, episode)
        else:
            path = '/stream/movie/%s.json' % imdb_id
        data = _get_json(TORRENTSDB_BASE + path, timeout=12)
        if not data:
            return []
        results = []
        for stream in data.get('streams', []):
            if len(results) >= limit:
                break
            ih = (stream.get('infoHash') or '').lower()
            if not ih:
                continue
            title_field = stream.get('title') or ''
            lines = title_field.split('\n')
            name = lines[0].strip() if lines else ''
            if not name or not _meets_quality(name, media_type):
                continue
            info_line = next((l for l in lines if _RE_MF_INFO.match(l)), '')
            seeds_m = _RE_TSDB_SEEDS.search(info_line)
            seeds = int(seeds_m.group(1)) if seeds_m else 0
            size_m = re.search(r'((?:\d+,\d+\.\d+|\d+\.\d+|\d+,\d+|\d+)\s*(?:GB|GiB|Gb|MB|MiB|Mb))', info_line)
            size = size_m.group(1) if size_m else ''
            results.append({
                'title': name, 'year': '', 'quality': _extract_quality(name),
                'info_hash': ih, 'magnet': _make_magnet(ih, name),
                'seeds': seeds, 'size': size, 'source': 'TorrentsDB',
            })
        return sorted(results, key=lambda x: x['seeds'], reverse=True)
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] TorrentsDB error: %s' % e, xbmc.LOGWARNING)
        return []


# ── AIOStreams (imdb_id-keyed; needs a special config header — same public
# community demo config already used by gearsscrapers' own port, not
# anything fabricated here) ──────────────────────────────────────────────────

# Community-hosted instances of the same open-source project -- any one of
# these can go dark or get rate-limited at any time (confirmed live: one
# candidate mirror, aiostreamsfortheweak.cloud, was already unreachable when
# checked), so this tries each in turn instead of hardcoding a single host.
AIOSTREAMS_MIRRORS = [
    'https://aiostreamsfortheweebs.midnightignite.me',
    'https://aiostreamsfortheweebsstable.midnightignite.me',
    'https://aiostreams.stremio.ru',
    'https://aiostreams.viren070.me',
    'https://aiostreams.12312023.xyz',
]
# Config adds seadex + neko-bt presets (2026-08-11) on top of the existing
# bitmagnet-only demo config — both are anime-focused sources with no direct
# Starfleet equivalent (unlike comet/zilean/mediafusion/meteor/torrentsdb/
# knaben/stremthru/tgx/animetosho, which duplicate scrapers already run
# directly elsewhere in this file, so weren't added here). AIOStreams itself
# decides server-side whether a searched title is anime and only queries
# these two when it is — no media_type='anime' path needed on our end, this
# fires transparently through the existing movie/tv search flow.
_AIOSTREAMS_HEADERS = {'x-aiostreams-user-data': (
    'eyJzZXJ2aWNlcyI6IFt7ImlkIjogImFsbGRlYnJpZCIsICJlbmFibGVkIjogdHJ1ZSwgImNyZWRlbnRpYWxzIjogeyJhcGlLZXkiOiAic3RhdGljRGVtb0FwaWtleVByZW0ifX1dLCAicHJlc2V0cyI6IFt7InR5cGUiOiAiYml0bWFnbmV0IiwgImluc3RhbmNlSWQiOiAiM2IzIiwgImVuYWJsZWQiOiB0cnVlLCAib3B0aW9ucyI6IHsibmFtZSI6ICJCaXRtYWduZXQiLCAidGltZW91dCI6IDEwMDAwLCAibWVkaWFUeXBlcyI6IFtdfX0sIHsidHlwZSI6ICJzZWFkZXgiLCAiaW5zdGFuY2VJZCI6ICI0N2IiLCAiZW5hYmxlZCI6IHRydWUsICJvcHRpb25zIjogeyJuYW1lIjogIlNlYURleCIsICJ0aW1lb3V0IjogNzAwMCwgIm1lZGlhVHlwZXMiOiBbImFuaW1lIl19fSwgeyJ0eXBlIjogIm5la28tYnQiLCAiaW5zdGFuY2VJZCI6ICI1NmUiLCAiZW5hYmxlZCI6IHRydWUsICJvcHRpb25zIjogeyJuYW1lIjogIm5la29CVCIsICJ0aW1lb3V0IjogNzAwMCwgIm1lZGlhVHlwZXMiOiBbXSwgInNlYXJjaE1vZGUiOiAiYm90aCIsICJ1c2VNdWx0aXBsZUluc3RhbmNlcyI6IGZhbHNlLCAibGVhdmVBdXRvVGl0bGVUYWdzSW5GaWxlbmFtZSI6IGZhbHNlfX1dLCAiZm9ybWF0dGVyIjogeyJpZCI6ICJ0b3JyZW50aW8iLCAiZGVmaW5pdGlvbiI6IHsibmFtZSI6ICIiLCAiZGVzY3JpcHRpb24iOiAiIn19LCAic29ydENyaXRlcmlhIjogeyJnbG9iYWwiOiBbXX19'
)}


def search_aiostreams(imdb_id, season=None, episode=None, limit=40, media_type='movie'):
    if not imdb_id:
        return []
    try:
        if season is not None and episode is not None:
            path = '/api/v1/search?type=series&id=%s:%s:%s' % (imdb_id, season, episode)
        else:
            path = '/api/v1/search?type=movie&id=%s' % imdb_id
        s = _sess()
        if not s:
            return []
        data = None
        for base in AIOSTREAMS_MIRRORS:
            try:
                r = s.get(base + path, headers=_AIOSTREAMS_HEADERS, timeout=12)
                r.raise_for_status()
                candidate = r.json()
                if (candidate.get('data') or {}).get('results'):
                    data = candidate
                    break
                if data is None:
                    data = candidate  # keep the first reachable-but-empty response as a fallback
            except Exception:
                continue
        if not data:
            return []
        files = (data.get('data') or {}).get('results') or []
        results = []
        for f in files:
            if len(results) >= limit:
                break
            ih = (f.get('infoHash') or '').lower()
            name = f.get('folderName') or f.get('filename') or ''
            if not ih or not name or not _meets_quality(name, media_type):
                continue
            size = ''
            try:
                b = float(f.get('size') or 0)
                if b >= 1_073_741_824:
                    size = '%.1f GB' % (b / 1_073_741_824)
                elif b >= 1_048_576:
                    size = '%.0f MB' % (b / 1_048_576)
            except Exception:
                pass
            results.append({
                'title': name, 'year': '', 'quality': _extract_quality(name),
                'info_hash': ih, 'magnet': _make_magnet(ih, name),
                'seeds': int(f.get('seeders') or 0), 'size': size, 'source': 'AIOStreams',
            })
        return sorted(results, key=lambda x: x['seeds'], reverse=True)
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] AIOStreams error: %s' % e, xbmc.LOGWARNING)
        return []


# ── DebridMediaManager (movies only — its TV endpoint is season-level only,
# no per-episode granularity, so it doesn't fit this addon's per-episode
# search model the way it fits a season-pack-capable one) ───────────────────

DMM_BASE = 'https://debridmediamanager.com'


def _dmm_secret():
    """Reproduces DMM's own client-side proof-of-work challenge — a plain
    computed hash pair, not a real secret (the algorithm and salt are both
    shipped in DMM's own public JS), so this is fully reproducible without
    ever touching a browser."""
    import ctypes, math, random, time as _time

    def calc(t, n, const):
        temp = t ^ n
        t = ctypes.c_long(temp * const).value
        t4 = ctypes.c_long(t << 5).value
        t5 = ctypes.c_long((t & 0xFFFFFFFF) >> 27).value
        return t4 | t5

    def slice_(e, t):
        a = math.floor(len(e) / 2)
        s, n = e[0:a], e[a:]
        i, o = t[0:a], t[a:]
        l = ''.join(s[k] + i[k] for k in range(a))
        return l + (o[::-1] + n[::-1])

    def gen_hash(e):
        t = ctypes.c_long(3735928559 ^ len(e)).value
        a = 1103547991 ^ len(e)
        for ch in e:
            n = ord(ch)
            t = calc(t, n, 2654435761)
            a = calc(a, n, 1597334677)
        t = ctypes.c_long(t + ctypes.c_long(a * 1566083941).value | 0).value
        a = ctypes.c_long(a + ctypes.c_long(t * 2024237689).value | 0).value
        return (ctypes.c_long(t ^ a).value & 0xFFFFFFFF) >> 0

    myhex = '%064x' % random.randrange(10 ** 80)
    e = myhex[:8]
    a = '%s-%d' % (e, int(_time.time()))
    s = hex(gen_hash(a)).replace('0x', '')
    n = hex(gen_hash('debridmediamanager.com%%fe7#td00rA3vHz%VmI-' + e)).replace('0x', '')
    return a, slice_(s, n)


def search_dmm(imdb_id, limit=40, media_type='movie'):
    """DebridMediaManager (debridmediamanager.com) — a public debrid-library
    search service, movie catalog only for this addon's purposes."""
    if not imdb_id or media_type not in ('movie', 'adult'):
        return []
    try:
        problem_key, solution = _dmm_secret()
        url = '%s/api/torrents/movie?imdbId=%s&dmmProblemKey=%s&solution=%s' % (
            DMM_BASE, imdb_id, problem_key, solution)
        data = _get_json(url, timeout=10)
        if not data:
            return []
        files = data.get('results') or []
        results = []
        for f in files:
            if len(results) >= limit:
                break
            ih = (f.get('hash') or '').lower()
            name = f.get('title') or ''
            if not ih or not name or not _meets_quality(name, media_type):
                continue
            size = ''
            try:
                b = float(f.get('fileSize') or 0) * 1_048_576
                if b >= 1_073_741_824:
                    size = '%.1f GB' % (b / 1_073_741_824)
                elif b:
                    size = '%.0f MB' % (b / 1_048_576)
            except Exception:
                pass
            results.append({
                'title': name, 'year': '', 'quality': _extract_quality(name),
                'info_hash': ih, 'magnet': _make_magnet(ih, name),
                'seeds': 0, 'size': size, 'source': 'DMM',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] DMM error: %s' % e, xbmc.LOGWARNING)
        return []


# ── TorrentProject2 ───────────────────────────────────────────────────────────

TORRENTPROJECT2_BASE = 'https://torrentproject2.org'
_RE_TP2_LINKS  = re.compile(r'<a\s*href\s*=\s*["\'](.+?torrent\.html)["\']', re.IGNORECASE)
_RE_TP2_HASH   = re.compile(r'<a\s*title\s*=\s*["\']hash:(.+?)\s*torrent', re.IGNORECASE)
_RE_TP2_TITLE  = re.compile(r'<title>(.+?)</title>', re.IGNORECASE)
_RE_TP2_SEEDS  = re.compile(r'["\']tseeders["\']>\s*([0-9,]+)\s*<', re.IGNORECASE)
_RE_TP2_SIZE   = re.compile(r'<div id\s*=\s*["\']torrent-size["\']>(.+?)<', re.IGNORECASE)


def _tp2_get_detail(link, media_type):
    try:
        url = TORRENTPROJECT2_BASE + link
        html = _get(url, timeout=8)
        if not html:
            return None
        hash_m = _RE_TP2_HASH.search(html)
        title_m = _RE_TP2_TITLE.search(html)
        if not hash_m or not title_m:
            return None
        import urllib.parse as _up
        name = _up.unquote_plus(title_m.group(1)).strip()
        if not name or not _meets_quality(name, media_type):
            return None
        seeds_m = _RE_TP2_SEEDS.search(html)
        seeds = int(seeds_m.group(1).replace(',', '')) if seeds_m else 0
        size_m = _RE_TP2_SIZE.search(html)
        size = size_m.group(1).strip() if size_m else ''
        return {
            'title': name, 'year': '', 'quality': _extract_quality(name),
            'info_hash': hash_m.group(1).lower(), 'magnet': _make_magnet(hash_m.group(1).lower(), name),
            'seeds': seeds, 'size': size, 'source': 'TorrentProject2',
        }
    except Exception:
        return None


def search_torrentproject2(title, year=None, limit=5, media_type='movie'):
    """torrentproject2.org — query syntax is one colon-joined path segment
    (same site family/quirk as TheRarBG's), confirmed live no Cloudflare
    wall. Per-candidate detail-page fetch is required for the magnet."""
    try:
        if not _req:
            return []
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        url = '%s/?t=%s&orderby=seeders' % (TORRENTPROJECT2_BASE, _req.utils.quote(query))
        html = _get(url, timeout=10)
        if not html:
            return []
        links = list(dict.fromkeys(_RE_TP2_LINKS.findall(html)))[:limit]
        if not links:
            return []
        from concurrent.futures import ThreadPoolExecutor
        results = []
        with ThreadPoolExecutor(max_workers=min(len(links), 5)) as pool:
            for r in pool.map(lambda l: _tp2_get_detail(l, media_type), links):
                if r:
                    results.append(r)
        return sorted(results, key=lambda x: x['seeds'], reverse=True)
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] TorrentProject2 error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Torrentz2 ─────────────────────────────────────────────────────────────────

TORRENTZ2_BASE = 'https://torrentz2.nz'
_RE_TZ2_ROW    = re.compile(r'href="(/torrent/[a-f0-9]+)"[^>]*>([^<]+)</a>', re.IGNORECASE)
_RE_TZ2_SIZE   = re.compile(r'<span class="s">([^<]+)</span>')
_RE_TZ2_SEEDS  = re.compile(r'<span class="u">(\d+)</span>')
_RE_TZ2_MAGNET = re.compile(r'href="(magnet:[^"]+)"', re.IGNORECASE)
_TORRENTZ2_SERVER_ERR = ('something went wrong', 'Connection timed out', '521: Web server is down', '503 Service Unavailable')


def _tz2_get_magnet(link):
    try:
        html = _get(TORRENTZ2_BASE + link, timeout=8)
        if not html:
            return ''
        m = _RE_TZ2_MAGNET.search(html)
        if not m:
            return ''
        import html as _html_mod
        return _html_mod.unescape(m.group(1))
    except Exception:
        return ''


def search_torrentz2(title, year=None, limit=5, media_type='movie'):
    """torrentz2.nz — search results link out to a /torrent/<id> detail
    page for the (HTML-entity-encoded) magnet, confirmed live 2026-08-04
    that it no longer embeds magnets inline in the listing."""
    try:
        if not _req:
            return []
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        url = '%s/search?q=%s' % (TORRENTZ2_BASE, _req.utils.quote(query))
        html = _get(url, timeout=10)
        if not html or any(v in html for v in _TORRENTZ2_SERVER_ERR):
            return []

        candidates = []
        for m in _RE_TZ2_ROW.finditer(html):
            if len(candidates) >= limit:
                break
            path, name = m.group(1), m.group(2).strip()
            if not name or not _meets_quality(name, media_type):
                continue
            start = m.end()
            block = html[start:start + 600]
            size_m = _RE_TZ2_SIZE.search(block)
            seeds_m = _RE_TZ2_SEEDS.search(block)
            candidates.append({
                'path': path, 'name': name,
                'size': size_m.group(1).replace('\xa0', ' ').strip() if size_m else '',
                'seeds': int(seeds_m.group(1)) if seeds_m else 0,
            })
        if not candidates:
            return []

        from concurrent.futures import ThreadPoolExecutor
        results = []
        with ThreadPoolExecutor(max_workers=min(len(candidates), 15)) as pool:
            fmap = {pool.submit(_tz2_get_magnet, c['path']): c for c in candidates}
            for fut, c in fmap.items():
                try:
                    magnet = fut.result(timeout=10)
                except Exception:
                    magnet = ''
                if not magnet:
                    continue
                ih_m = re.search(r'btih:([a-fA-F0-9]{40})', magnet, re.IGNORECASE)
                results.append({
                    'title': c['name'], 'year': '', 'quality': _extract_quality(c['name']),
                    'info_hash': ih_m.group(1).lower() if ih_m else '', 'magnet': magnet,
                    'seeds': c['seeds'], 'size': c['size'], 'source': 'Torrentz2',
                })
        return sorted(results, key=lambda x: x['seeds'], reverse=True)
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Torrentz2 error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Kickass2 (KAT mirror network) ────────────────────────────────────────────

_KICKASS2_MIRRORS = [
    'kick4ss.com', 'thekat.info', 'kickasst.net', 'kickasshydra.dev',
    'kickasshydra.net', 'kathydra.com', 'kickasstorrents.id', 'thekat.cc',
    'kkat.net', 'kickasstorrents.bz',
]
_kickass2_working = {}
_RE_KA2_ROW = re.compile(
    r'<tr class="[^"]*" id="torrent_latest_torrents">(.*?)</tr>', re.DOTALL
)


def _get_kickass2_base():
    cached = _kickass2_working.get('url')
    ts = _kickass2_working.get('ts', 0)
    if cached and (time.time() - ts) < 3600:
        return cached
    for mirror in _KICKASS2_MIRRORS:
        try:
            url = 'https://%s' % mirror
            html = _get(url + '/', timeout=7)
            title_m = re.search(r'<title>(.+?)</title>', html or '', re.IGNORECASE)
            if title_m and 'kickass' in title_m.group(1).lower():
                _kickass2_working['url'] = url
                _kickass2_working['ts'] = time.time()
                return url
        except Exception:
            continue
    return 'https://' + _KICKASS2_MIRRORS[0]


def search_kickass2(title, year=None, limit=5, media_type='movie'):
    """Kickass2 (KAT mirror network) — magnets are inline in the listing
    row (URL-encoded behind a click-redirect wrapper, so need unquote_plus
    to reveal the literal 'magnet:' string), no detail-page fetch needed.
    No category:movies/category:tv filter — confirmed live it silently
    zeroes out results for common multi-word titles ("Breaking Bad" +
    any category filter = 0 results, same title alone = plenty), the same
    class of site-side query-relevance quirk already documented for 1337x
    elsewhere in this file. Plain keyword search plus this addon's own
    downstream quality/title filtering covers it instead."""
    try:
        if not _req:
            return []
        base = _get_kickass2_base()
        query = title
        if year and media_type == 'movie':
            query = '%s %s' % (title, year)
        url = '%s/usearch/%s/?field=size&sorder=desc' % (base, _req.utils.quote(query))
        html = _get(url, timeout=10)
        if not html:
            return []
        results = []
        for row_m in _RE_KA2_ROW.finditer(html):
            if len(results) >= limit:
                break
            row = row_m.group(1)
            columns = re.findall(r'<td.*?>(.+?)</td>', row, re.DOTALL)
            if not columns:
                continue
            decoded = _req.utils.unquote(columns[0]).replace('&amp;', '&')
            mag_m = re.search(r'(magnet:.+?)&tr=', decoded, re.IGNORECASE)
            if not mag_m:
                continue
            magnet = mag_m.group(1).replace(' ', '.')
            ih_m = re.search(r'btih:([a-fA-F0-9]{40})', magnet, re.IGNORECASE)
            if not ih_m:
                continue
            dn_m = re.search(r'&dn=([^&]+)', magnet)
            name = _req.utils.unquote(dn_m.group(1)).replace('+', ' ').strip() if dn_m else ''
            if not name or not _meets_quality(name, media_type):
                continue
            seeds = 0
            try:
                seeds = int(re.sub(r'<[^>]+>', '', columns[3]).strip().replace(',', ''))
            except Exception:
                pass
            size = ''
            try:
                size = re.sub(r'<[^>]+>', '', columns[1]).strip()
            except Exception:
                pass
            results.append({
                'title': name, 'year': '', 'quality': _extract_quality(name),
                'info_hash': ih_m.group(1).lower(), 'magnet': magnet.split('&tr=')[0],
                'seeds': seeds, 'size': size, 'source': 'Kickass2',
            })
        return sorted(results, key=lambda x: x['seeds'], reverse=True)
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Kickass2 error: %s' % e, xbmc.LOGWARNING)
        return []


# ── ApacheTorrent / RedeTorrent (Brazilian-Portuguese dubbed catalog) ─────────
# Two differently-branded sites confirmed live to share the exact same
# underlying content pool and per-title detail-page template (identical
# image-CDN paths and even identical info_hash values for the same title —
# e.g. "A Origem 4K" nets the SAME btih on both apachetorrent.com and
# redetorrent.com). Both have a real, genuinely-filtering server-rendered
# search (confirmed live against a nonsense query returning an empty result
# set on redetorrent.com, and a title-specific result set on apachetorrent.com
# distinct from its "no query" homepage) — unlike the four other Spanish-
# language sites investigated the same session (divxtotal.wtf, tomadivx.net,
# esmeraldatorrent.com, naranjatorrent.com) which all turned out to be
# mirrors of one shared DonTorrent-based backend whose search silently
# ignores the query entirely and always returns the same generic "recent
# uploads" listing regardless of what's searched (confirmed live on all four
# via both their top-nav ?sec=buscador param and their sidebar
# /peliculas/buscar POST form) — a dead end, not implemented here.
# elitetorrent.com's search DOES genuinely filter too, but every one of its
# download links (.torrent AND magnet) routes through an acortame-esto.com
# link-shortener wrapping multiply-base64-obfuscated payloads — the exact
# ad-gated-redirect dead end this file's other scrapers avoid — so it's
# skipped as well.
#
# Neither site exposes seed/leech counts anywhere (these are direct-download
# dubbed-movie catalogs, not tracker-style indexes), so seeds is always 0.
# Each listing item needs its own detail-page fetch to get the actual
# magnet (never present in the listing itself), resolved in parallel like
# search_extto/search_therarbg already do.

APACHETORRENT_BASE = 'https://apachetorrent.com'
REDETORRENT_BASE = 'https://redetorrent.com'

_RE_APT_ITEM = re.compile(
    r"<h2 class='h6 text-center'><a href='([^']+)'[^>]*>([^<]+?)\s*<br/>\s*\(([^)]*)\)</a></h2>",
    re.IGNORECASE
)
_RE_RT_ITEM = re.compile(
    r"class='capa_lista'>\s*<a href='([^']+)'[^>]*>.*?"
    r"<span class='capa_categoria'>([^<]*)</span>\s*"
    r"<span class='capa_qualidade'>([^<]*)</span>.*?"
    r"<h2 itemprop='headline'>([^<]+)</h2>",
    re.IGNORECASE | re.DOTALL
)
_RE_BR_MAGNET = re.compile(r'(magnet:\?xt=urn:btih:[a-fA-F0-9]{40}[^"\'<>\s]*)', re.IGNORECASE)
_RE_BR_SIZE   = re.compile(r"<strong>Tamanho</strong>:\s*([^<]+)<", re.IGNORECASE)


def _br_dubbed_detail(url, listing_title, cand_year, media_type, source_name):
    """Shared detail-page fetch for the apachetorrent.com/redetorrent.com
    template — real inline magnet link, no ad-gate/shortener in front of it."""
    try:
        detail = _get(url, timeout=8)
        if not detail:
            return None
        mag_m = _RE_BR_MAGNET.search(detail)
        if not mag_m:
            return None
        magnet = mag_m.group(1).replace('&amp;', '&')
        ih_m = re.search(r'btih:([a-fA-F0-9]{40})', magnet, re.IGNORECASE)
        if not ih_m:
            return None
        dn_m = re.search(r'[?&]dn=([^&]+)', magnet)
        if dn_m:
            import urllib.parse as _up
            name = _up.unquote_plus(dn_m.group(1))
        else:
            name = ''
        name = name or listing_title
        if not _meets_quality(name, media_type):
            return None
        size_m = _RE_BR_SIZE.search(detail)
        ih = ih_m.group(1).lower()
        return {
            'title':     name,
            'year':      cand_year or '',
            'quality':   _extract_quality(name),
            'info_hash': ih,
            'magnet':    _make_magnet(ih, name),
            'seeds':     0,
            'size':      size_m.group(1).strip() if size_m else '',
            'source':    source_name,
        }
    except Exception:
        return None


def search_apachetorrent(title, year=None, limit=5, media_type='movie'):
    """apachetorrent.com — WordPress-style ?s=<query> search, confirmed live
    to return genuinely title-filtered results (Brazilian-Portuguese titles,
    e.g. "Inception" search surfaces "A Origem")."""
    if media_type not in ('movie', 'tv'):
        return []
    try:
        if not _req:
            return []
        html = _get('%s/?s=%s' % (APACHETORRENT_BASE, _req.utils.quote(title)), timeout=10)
        if not html:
            return []
        candidates = []
        seen_urls = set()
        for m in _RE_APT_ITEM.finditer(html):
            if len(candidates) >= limit:
                break
            url, name, paren = m.group(1), m.group(2).strip(), m.group(3) or ''
            # Confirmed live the same item can appear twice on this site's
            # own results page (a featured/highlighted section duplicating
            # a row also listed below) — dedupe by detail-page URL, the one
            # value guaranteed unique per real item.
            if url in seen_urls:
                continue
            seen_urls.add(url)
            yr_m = re.search(r'(19|20)\d{2}', paren)
            cand_year = yr_m.group(0) if yr_m else ''
            if year and cand_year and str(year) != cand_year:
                continue
            candidates.append((url, name, cand_year))
        if not candidates:
            return []
        from concurrent.futures import ThreadPoolExecutor
        results = []
        seen_hashes = set()
        with ThreadPoolExecutor(max_workers=min(len(candidates), 10)) as pool:
            futs = [pool.submit(_br_dubbed_detail, u, n, y, media_type, 'ApacheTorrent')
                    for u, n, y in candidates]
            for fut in futs:
                try:
                    r = fut.result(timeout=10)
                except Exception:
                    r = None
                # Confirmed live: two different detail-page URLs on this
                # site can embed the identical magnet (info_hash) - the
                # earlier URL-based dedup above catches duplicate listing
                # rows, this catches duplicate CONTENT under different URLs.
                ih = r.get('info_hash', '') if r else ''
                if r and (not ih or ih not in seen_hashes):
                    if ih:
                        seen_hashes.add(ih)
                    results.append(r)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] ApacheTorrent error: %s' % e, xbmc.LOGWARNING)
        return []


def search_redetorrent(title, year=None, limit=5, media_type='movie'):
    """redetorrent.com — same dubbed-catalog template/content pool as
    ApacheTorrent above (see this section's header comment) but with a
    richer listing that also carries a category badge (Filmes/Séries), used
    here to skip fetching detail pages for the wrong media_type outright.
    Search is a plain GET to index.php?s=<query> (custom PHP, not
    WordPress) — confirmed live to genuinely filter (empty result set for a
    nonsense query)."""
    if media_type not in ('movie', 'tv'):
        return []
    try:
        if not _req:
            return []
        html = _get('%s/index.php?s=%s' % (REDETORRENT_BASE, _req.utils.quote(title)), timeout=10)
        if not html:
            return []
        candidates = []
        seen_urls = set()
        for m in _RE_RT_ITEM.finditer(html):
            if len(candidates) >= limit:
                break
            url, category, _quality_badge, headline = m.groups()
            # Same duplicate-listing quirk as ApacheTorrent (shared template) —
            # dedupe by detail-page URL.
            if url in seen_urls:
                continue
            seen_urls.add(url)
            is_tv = 'rie' in (category or '').strip().lower()  # "Séries"/"Series"
            if is_tv != (media_type == 'tv'):
                continue
            yr_m = re.search(r'\((19|20)\d{2}\)', headline)
            cand_year = yr_m.group(0).strip('()') if yr_m else ''
            if year and cand_year and str(year) != cand_year:
                continue
            name = re.sub(r'\s*\((19|20)\d{2}\)\s*$', '', headline).strip()
            candidates.append((url, name, cand_year))
        if not candidates:
            return []
        from concurrent.futures import ThreadPoolExecutor
        results = []
        seen_hashes = set()
        with ThreadPoolExecutor(max_workers=min(len(candidates), 10)) as pool:
            futs = [pool.submit(_br_dubbed_detail, u, n, y, media_type, 'RedeTorrent')
                    for u, n, y in candidates]
            for fut in futs:
                try:
                    r = fut.result(timeout=10)
                except Exception:
                    r = None
                # Same duplicate-content-under-different-URLs quirk as
                # ApacheTorrent (shared template) - dedupe by info_hash.
                ih = r.get('info_hash', '') if r else ''
                if r and (not ih or ih not in seen_hashes):
                    if ih:
                        seen_hashes.add(ih)
                    results.append(r)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] RedeTorrent error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Torseek (torseek.org) ──────────────────────────────────────────────────
# Next.js 15 App-Router site, fully client-rendered (its own RSC payload for
# /search confirmed live to carry no server-fetched torrent data at all).
# There's no REST search endpoint — the compiled page JS instead calls
# createServerReference("<40-hex id>", ..., "search"), which is Next.js'
# React Server Actions machinery: at runtime that becomes a POST to the
# CURRENT page URL carrying a `Next-Action: <id>` header, with the call's
# arguments JSON-encoded as the raw body (`[query, page]`). Confirmed live
# this is reproducible with a plain POST + those two headers, no browser/JS
# execution needed at all — and the backend is itself a Jackett meta-search
# aggregator (each hit's `jackettindexer` field names the real underlying
# indexer, e.g. TheRarBG/The Pirate Bay), returning genuine magnets with
# real btih hashes, human release names and live seeder counts.
# CAVEAT: that action id is Next.js build output tied to this one specific
# deployment — it WILL silently change whenever Torseek redeploys, at which
# point this scraper degrades to routine POST failures (caught below,
# returns [] like any other dead source) until the id is refreshed by hand.
TORSEEK_BASE = 'https://www.torseek.org'
TORSEEK_SEARCH_ACTION = '60024254f6afa5cc0a7878404013b88cf799b21f57'
_RE_TORSEEK_HASH = re.compile(r'btih:([a-fA-F0-9]{40})', re.IGNORECASE)


def search_torseek(title, year=None, limit=5, media_type='movie'):
    try:
        if not _req:
            return []
        s = _sess()
        if not s:
            return []
        query = title
        if year and media_type == 'movie':
            query = '%s %s' % (title, year)
        url = '%s/search?q=%s' % (TORSEEK_BASE, _req.utils.quote(query))
        import json as _json
        body = _json.dumps([query, 1])
        headers = {
            'Accept':       'text/x-component',
            'Next-Action':  TORSEEK_SEARCH_ACTION,
            'Content-Type': 'text/plain;charset=UTF-8',
            'Origin':       TORSEEK_BASE,
            'Referer':      url,
        }
        r = s.post(url, data=body.encode('utf-8'), headers=headers, timeout=12)
        r.raise_for_status()
        data = None
        for line in r.text.split('\n'):
            if line.startswith('1:') and not line.startswith('1:E'):
                try:
                    data = _json.loads(line[2:])
                except Exception:
                    data = None
                break
        if not data or not isinstance(data, dict):
            return []
        results = []
        for item in data.get('results', []):
            if len(results) >= limit:
                break
            magnet = item.get('magnetLink') or item.get('guid') or ''
            ih_m = _RE_TORSEEK_HASH.search(magnet)
            if not ih_m:
                continue
            name = item.get('title', '')
            if not name or not _meets_quality(name, media_type):
                continue
            try:
                seeds = int(item.get('seeders') or 0)
            except Exception:
                seeds = 0
            size = ''
            try:
                b = int(item.get('size') or 0)
                if b >= 1_073_741_824:
                    size = '%.1f GB' % (b / 1_073_741_824)
                elif b >= 1_048_576:
                    size = '%.0f MB' % (b / 1_048_576)
            except Exception:
                pass
            ih = ih_m.group(1).lower()
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    _make_magnet(ih, name),
                'seeds':     seeds,
                'size':      size,
                'source':    'Torseek',
            })
        return sorted(results, key=lambda x: x['seeds'], reverse=True)
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Torseek error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Unified search ────────────────────────────────────────────────────────────

def filter_by_title_and_episode(results, title, media_type='movie', season=None,
                                 episode=None, key='title', log_tag='Torrents'):
    """Shared title/episode precision filter, extracted out of search_all()
    so non-torrent sources (NZB/Usenet) can apply the exact same strictness
    instead of shipping unfiltered. Confirmed live this was a real, visible
    bug for NZB: searching "Found S01E03" returned "Virgin River S01E03",
    "Happy Tree Friends S01E03", "Eyes of Wakanda S01E03" etc mixed in
    alongside real "Found" results, because Binsearch's own search is a
    loose multi-word match (any post containing similar terms/markers, not
    an exact title match) and nzb_sources.py never filtered its output the
    way every torrent source here already does via this same code.

    See search_all()'s original inline version of this same logic (still
    the copy of record for *why* each individual regex/skip-word/episode
    exists) — this is a straight extraction, not a rewrite, so both callers
    behave identically to how torrents always have.
    """
    # Filter out false matches where the show/movie name doesn't appear as
    # whole words in the result's own title. Prevents e.g. "Farmhouse Rules
    # S04E10" matching search "FROM S04E10" because "from" appears as a
    # substring inside "farmhouse".
    if title:
        _skip_words = {'a', 'an', 'the', 'of', 'in', 'on', 'at', 'to', 'for', 'or', 'and'}
        # Trim leading/trailing filler words only — an interior one (e.g.
        # "Day OF the Dead") stays, so it can still act as flexible filler
        # between two real words below rather than being silently dropped.
        _raw_words = [w.lower() for w in re.split(r'\W+', title) if w]
        while _raw_words and _raw_words[0] in _skip_words:
            _raw_words.pop(0)
        while _raw_words and _raw_words[-1] in _skip_words:
            _raw_words.pop()
        # A trailing sequel/episode number ("Anal Players 9", "Moana 2") is
        # exactly the part that disambiguates one title from another, but
        # `len(w) >= 2` was silently dropping every single-digit number from
        # _search_words entirely. Numeric tokens are now kept regardless of
        # length.
        _search_words = [w for w in _raw_words if len(w) >= 2 or w.isdigit()]
        if _search_words:
            # Bag-of-words matching (each query word present ANYWHERE, any
            # order) let through real false positives. Fix: require the
            # query's words to appear as one contiguous phrase, in the same
            # order, with only optional filler (whitespace/punctuation, a
            # skip-word, or a bare release year) between them.
            _skip_alt = '|'.join(sorted(_skip_words))
            _region_alt = 'us|uk|au|ca|nz|ie'
            _sep = r'[\W_]+(?:(?:(?:' + _skip_alt + r')|(?:' + _region_alt + r')|(?:19|20)\d{2})[\W_]+)*'
            _parts = []
            for w in _search_words:
                if w.isdigit():
                    _parts.append('0*' + re.escape(w))
                else:
                    _parts.append(re.escape(w))
            _PHRASE_RE = re.compile(r'\b' + _sep.join(_parts) + r'\b', re.IGNORECASE)

            def _title_matches(name_in):
                name = name_in.lower()
                # Strip embedded dates before punctuation gets flattened to
                # spaces below — otherwise a date's day/month component
                # becomes a free-floating number that can spuriously
                # satisfy a numeric query word.
                name = re.sub(r'\b\d{1,2}[.\-/]\d{1,2}[.\-/]\d{2,4}\b', ' ', name)
                name = re.sub(r'\b\d{2,4}[.\-/]\d{1,2}[.\-/]\d{1,2}\b', ' ', name)
                name = re.sub(_RE_MONTH_DAY_YEAR, ' ', name)
                name = re.sub(_RE_DAY_MONTH, ' ', name)
                name = re.sub(_RE_NUM_DATE_SPACED, ' ', name)
                # Strip leading release-group/language/quality bracket tags
                # before the position check below.
                name = re.sub(r'^(?:[\[(][^\])]*[\])][\s._\-]*)+', '', name)
                # Also strip wrapping quote characters (straight AND curly/
                # smart) to spaces, same as every other punctuation char
                # here — NZB titles are new to this filter (torrent titles
                # never carried them) and Binsearch wraps its own raw title
                # text in quotes. Confirmed live this was a real 100%-
                # rejection bug: a leading quote glued directly onto the
                # first word (e.g. '"the odyssey...') makes that word its
                # own un-skippable token ('"the' != 'the'), so the
                # prefix-word check below rejected EVERY single NZB
                # candidate regardless of content the moment this filter
                # started running against them.
                norm = re.sub(r'[._\-\[\]()+"“”‘’]', ' ', name)
                norm = re.sub(r'\s+', ' ', norm).strip()
                m = _PHRASE_RE.search(norm)
                if not m:
                    return False
                # The query's phrase must start the (cleaned) title, not
                # sit after another real word — allow anything before the
                # match IF it's made up entirely of the same skip-words
                # already trimmed from our own query.
                prefix_words = norm[:m.start()].split()
                return all(w in _skip_words for w in prefix_words)
            before = len(results)
            results = [r for r in results if _title_matches(r.get(key, ''))]
            filtered = before - len(results)
            if filtered:
                xbmc.log('[Starfleet/%s] Title filter removed %d false matches' % (log_tag, filtered), xbmc.LOGINFO)

    # For a specific TV episode, the title-word filter above only confirms
    # the show name matches — it says nothing about WHICH episode. A
    # release with NO single-episode marker (season pack, "S01-S05",
    # "COMPLETE", etc.) is assumed to legitimately contain the target
    # episode and kept; one WITH a marker must match.
    if media_type == 'tv' and season is not None and episode is not None:
        _target_s, _target_e = int(season), int(episode)
        _RE_EP_MARKER = re.compile(r's0*(\d{1,2})[\s._-]*e0*(\d{1,3})(?!\d)', re.IGNORECASE)

        def _episode_ok(name_in):
            markers = _RE_EP_MARKER.findall(name_in)
            if not markers:
                return True
            return any(int(s) == _target_s and int(e) == _target_e for s, e in markers)

        before_ep = len(results)
        results = [r for r in results if _episode_ok(r.get(key, ''))]
        filtered_ep = before_ep - len(results)
        if filtered_ep:
            xbmc.log('[Starfleet/%s] Episode filter removed %d wrong-episode matches' % (log_tag, filtered_ep), xbmc.LOGINFO)

    return results


# Every individually-toggleable torrent source's settings.xml key suffix
# (Settings > Torrent Sources — each is its own "src_<key>" bool setting).
# Used only to build a stable cache-key signature reflecting exactly which
# sources are currently enabled, so a settings change never serves a
# stale cached result built under a different on/off mix — see
# search_all()'s own cache-key construction below.
_ALL_SOURCE_KEYS = (
    'torrentio', 'comet', 'stremthru', 'bitmagnet', 'zilean', 'mediafusion',
    'meteor', 'torrentsdb', 'aiostreams', 'dmm', 'knaben', 'tpb', 'yts',
    'eztv', '1337x',
    'bitsearch', 'torrentdl', 'limetorrents', 'magnetdl', 'bittorrented',
    'msearch', 'tgx', 'zooqle', 'nyaa', 'extto', 'therarbg',
    'torrentproject2', 'torrentz2', 'kickass2', 'kontrast', 'torrentfunk',
    'torlock', 'torrentscsv', 'btdig', 'animetosho', 'tordl', 'rutor',
    'nnmclub', 'snowfl', 'yourbittorrent', 'apachetorrent', 'redetorrent',
    'torseek', 'filemood', 'publicdomaintorrents',
    'cleanbay', 'damag', 'rarbgdump',
)


def search_all(title, year=None, media_type='movie', max_per_source=5, imdb_id=None,
               season=None, episode=None):
    """
    Search all torrent sources in parallel. Returns combined list sorted by seeds.
    media_type: 'movie', 'tv', or 'adult'
    imdb_id: optional tt... ID for Torrentio
    season/episode: for TV episodes
    """
    from concurrent.futures import ThreadPoolExecutor, as_completed

    # Adult titles get run through the same junk-stripper the ADE-ingestion
    # layer uses, so a raw search-box query is just as clean as a canonical
    # ADE title by the time it's used to build every source's query AND the
    # title-match filter below — search_xxxclub/search_rintor also clean
    # defensively, but generic scrapers (TPB, Knaben, etc.) take `title` as-is.
    if media_type == 'adult' and title:
        title = _clean_adult_title(title) or title

    # Confirmed live this was a real, large, avoidable cost: this function
    # was never cached at all (only the adult XXXClub browse path used
    # _cache anywhere in this whole file) - every single search, even an
    # immediate repeat of the exact same title/episode (retrying after
    # Cancel, autoplay-next-episode re-checking, re-opening the source
    # picker), re-hit all ~30+ live sites from scratch every time. 15
    # minutes is short enough that seed counts/cache availability haven't
    # drifted much, but long enough to make every one of those repeat
    # cases instant instead of paying the full multi-source sweep again.
    # Per-source on/off toggles (Settings > Torrent Sources) — one bool per
    # scraper, defaults matching the "fast core set" this file settled on
    # after a real comparison against gears (core aggregators + Knaben/
    # TPB/YTS/EZTV/1337x default on; the ~20 slower single-site scrapers
    # default off). Lets a user keep the fast default, turn everything
    # back on, or hand-pick their own preferred mix - not just one blanket
    # "extra sources" switch as before.
    try:
        _src_addon = xbmcaddon.Addon('plugin.video.starfleet')
        def _src_on(key):
            return _src_addon.getSetting('src_' + key) == 'true'
    except Exception:
        def _src_on(key):
            return True
    _enabled_sig = tuple(sorted(k for k in _ALL_SOURCE_KEYS if _src_on(k)))
    _ck = ('torrentall_%s_%s_%s_%s_%s_%s_%s_%s' %
           (title, year, media_type, imdb_id, season, episode, max_per_source, _enabled_sig))
    if _HAS_CACHE:
        _cached = _cache.get(_ck)
        if _cached is not None:
            return _cached

    # TPB categories: 500=adult, 201=Movies/HD, 208=TV/HD (205 is broken/empty)
    tpb_cat = 500 if media_type == 'adult' else (201 if media_type == 'movie' else 208)

    # Previously removed for being CF-blocked; re-enabled with cfscraper fallback.
    # TGX: magnets may be JS-rendered on some mirrors — cfscraper handles most.
    # EXTto: the old ext.to domain this pointed at is fully dead now (DNS
    # doesn't even resolve, confirmed 2026-08-04) — moved to extto.com, the
    # site's current live mirror, no Cloudflare wall at all. Its magnets
    # need a per-item HMAC-signed AJAX call now (search_extto's own
    # docstring has the details) instead of the old inline-HTML scrape.
    # TorrentFunk: re-enabled 2026-08-06 -- its HTML search.php is still
    # genuinely CF-JS-challenged, but the site now documents/exposes a free
    # keyless JSON API (search_torrentfunk() hits /api/search.json directly)
    # with real server-side query search, no CF in front of it at all.
    #
    # Dead permanently: isohunt2 (404), EZTV (CF 403), Glodls (glodls.to
    #   redirects to glodls.club, which returns a Cloudflare 522 -- origin
    #   server itself is down/unreachable, not a JS-challenge to bypass),
    #   Bitlord (site rebuilt as a compiled Flutter web app -- no scrapeable
    #   HTML/API surface at all anymore), YourBT (search results now link out
    #   through single-use, per-query-rotating t0r.space subdomains whose
    #   detail pages 404 almost immediately -- not a stale-selector bug,
    #   the site's own link chain doesn't survive a second request)
    # 1337x: re-enabled — the old domain list was genuinely dead/reduced to
    # parked stub pages, but 1377x.to and 1337xx.to are real, live mirrors
    # (confirmed) once search_1337x() was rewritten for the site's new
    # /srch search endpoint and result-row format.
    #
    # Dict insertion order here IS submission order below (pool.submit()
    # iterates tasks.items() in order), and with max_workers capped at 12
    # against typically 13-16 total sources, whichever ones are inserted
    # LAST are the ones that queue and wait for a worker slot instead of
    # starting immediately. Torrentio/Knaben/TPB/YTS/EZTV/1337x are the
    # highest-value sources (see this file's own quality/reliability
    # notes), so they're built FIRST now — previously Torrentio/YTS/EZTV
    # were appended after all 13 lower-priority sources below, meaning the
    # single best source in the whole list was consistently one of the
    # ones most likely to be left queuing instead of running right away.
    tasks = {}

    # Torrentio: API-based, needs IMDB ID, works great for TV and movies.
    # Not scaled off max_per_source (that's sized for per-item HTML-scraping
    # sources) — Torrentio is one cheap JSON call, so it just uses its own
    # generous default limit (see search_torrentio's own docstring for why
    # a small limit here specifically hid 4K results).
    if imdb_id and media_type in ('movie', 'tv'):
        if media_type == 'tv' and season is not None and episode is not None:
            if _src_on('torrentio'):   tasks['Torrentio'] = lambda: search_torrentio(imdb_id, season, episode, media_type=media_type)
            if _src_on('comet'):       tasks['Comet']     = lambda: search_comet(imdb_id, season, episode, media_type=media_type)
            if _src_on('stremthru'):   tasks['StremThru'] = lambda: search_torz(imdb_id, season, episode, media_type=media_type)
            if _src_on('bitmagnet'):   tasks['Bitmagnet'] = lambda: search_bitmagnet(imdb_id, season, episode, media_type=media_type)
            if _src_on('zilean'):      tasks['Zilean']      = lambda: search_zilean(imdb_id, season, episode, media_type=media_type)
            if _src_on('mediafusion'): tasks['MediaFusion'] = lambda: search_mediafusion(imdb_id, season, episode, media_type=media_type)
            if _src_on('meteor'):      tasks['Meteor']      = lambda: search_meteor(imdb_id, season, episode, media_type=media_type)
            if _src_on('torrentsdb'):  tasks['TorrentsDB']  = lambda: search_torrentsdb(imdb_id, season, episode, media_type=media_type)
            if _src_on('aiostreams'):  tasks['AIOStreams']  = lambda: search_aiostreams(imdb_id, season, episode, media_type=media_type)
        elif media_type == 'movie':
            if _src_on('torrentio'):   tasks['Torrentio'] = lambda: search_torrentio(imdb_id, media_type=media_type)
            if _src_on('comet'):       tasks['Comet']     = lambda: search_comet(imdb_id, media_type=media_type)
            if _src_on('stremthru'):   tasks['StremThru'] = lambda: search_torz(imdb_id, media_type=media_type)
            if _src_on('dmm'):         tasks['DMM']       = lambda: search_dmm(imdb_id, media_type=media_type)
            if _src_on('bitmagnet'):   tasks['Bitmagnet'] = lambda: search_bitmagnet(imdb_id, media_type=media_type)
            if _src_on('zilean'):      tasks['Zilean']      = lambda: search_zilean(imdb_id, media_type=media_type)
            if _src_on('mediafusion'): tasks['MediaFusion'] = lambda: search_mediafusion(imdb_id, media_type=media_type)
            if _src_on('meteor'):      tasks['Meteor']      = lambda: search_meteor(imdb_id, media_type=media_type)
            if _src_on('torrentsdb'):  tasks['TorrentsDB']  = lambda: search_torrentsdb(imdb_id, media_type=media_type)
            if _src_on('aiostreams'):  tasks['AIOStreams']  = lambda: search_aiostreams(imdb_id, media_type=media_type)

    if _src_on('knaben'): tasks['Knaben'] = lambda: search_knaben(title, year, media_type, max_per_source * 2)
    if _src_on('tpb'):    tasks['TPB']    = lambda: search_tpb(title, year, tpb_cat, max_per_source, media_type)

    if media_type == 'movie' and _src_on('yts'):
        # YTS is a mainstream-only movie site with zero adult content —
        # confirmed live 2026-09-03 this was previously also gated on
        # media_type=='adult' (a real contributor to the "regular IMDB
        # movies showing up in Adult search results" bug fixed just below
        # in this same function), which could only ever have returned real
        # mainstream movies into an adult search, never anything genuinely
        # adult.
        tasks['YTS'] = lambda: search_yts(title, year, max_per_source, media_type)
    if media_type == 'tv' and _src_on('eztv'):
        # EZTV: API-first when imdb_id is known (no Cloudflare on that
        # endpoint); falls back to the CF-protected HTML search otherwise.
        tasks['EZTV'] = lambda: search_eztv(title, year, max_per_source, imdb_id)

    if _src_on('1337x'): tasks['1337x'] = lambda: search_1337x(title, year, max_per_source, media_type)

    # Lower-priority generic sources — mostly slower/flakier single-site
    # HTML/CF-walled scrapers, unlike the aggregator APIs and Knaben/TPB/
    # YTS/EZTV/1337x above. Confirmed via a real comparison against gears
    # (which queries ~5 fast aggregator sources by default, not ~30+) that
    # this block is the main reason a Starfleet search runs noticeably
    # longer than gears' equivalent search for comparable results - each
    # one is its own individual Settings > Torrent Sources toggle, off by
    # default, rather than one blanket "extra sources" switch - a search
    # stays fast by default but the user can turn any/all of these back on
    # (or use the "Enable All Sources" button for the full ~34-source set).
    if _src_on('yourbittorrent'):  tasks['YourBT']          = lambda: search_yourbittorrent(title, year, max_per_source, media_type)
    if _src_on('bitsearch'):       tasks['Bitsearch']       = lambda: search_bitsearch(title, None, max_per_source, media_type)
    if _src_on('torrentdl'):       tasks['TorrentDL']       = lambda: search_torrentdownloads(title, year, max_per_source, media_type)
    if _src_on('limetorrents'):    tasks['LimeTorrents']    = lambda: search_limetorrents(title, year, max_per_source, media_type)
    if _src_on('magnetdl'):        tasks['MagnetDL']        = lambda: search_magnetdl(title, None, max_per_source, media_type)
    if _src_on('bittorrented'):    tasks['BitTorrented']    = lambda: search_bittorrented(title, None, max_per_source, media_type)
    if _src_on('msearch'):         tasks['MSearch']         = lambda: search_msearch_torrents(title, year, max_per_source * 2, media_type)
    if _src_on('tgx'):             tasks['TGX']             = lambda: search_torrentgalaxy(title, year, max_per_source, media_type)
    if _src_on('zooqle'):          tasks['Zooqle']          = lambda: search_zooqle(title, year, max_per_source, media_type)
    if _src_on('nyaa'):            tasks['Nyaa']            = lambda: search_nyaa(title, year, max_per_source, media_type)
    if _src_on('extto'):           tasks['EXTto']           = lambda: search_extto(title, year, max_per_source, media_type)
    if _src_on('therarbg'):        tasks['TheRarBG']        = lambda: search_therarbg(title, year, max_per_source, media_type)
    if _src_on('torrentproject2'): tasks['TorrentProject2'] = lambda: search_torrentproject2(title, year, max_per_source, media_type)
    if _src_on('torrentz2'):       tasks['Torrentz2']       = lambda: search_torrentz2(title, year, max_per_source, media_type)
    if _src_on('kickass2'):        tasks['Kickass2']        = lambda: search_kickass2(title, year, max_per_source, media_type)
    if _src_on('kontrast'):        tasks['KONTRAST']        = lambda: search_kontrast(title, year, max_per_source, media_type)
    if _src_on('torrentfunk'):     tasks['TorrentFunk']     = lambda: search_torrentfunk(title, year, max_per_source, media_type)
    if _src_on('torlock'):         tasks['Torlock']         = lambda: search_torlock(title, year, max_per_source, media_type)
    if _src_on('torrentscsv'):     tasks['TorrentsCSV']     = lambda: search_torrentscsv(title, year, max_per_source, media_type)
    if _src_on('btdig'):           tasks['BitDig']          = lambda: search_btdig(title, year, max_per_source, media_type)
    if _src_on('animetosho'):      tasks['AnimeTosho']      = lambda: search_animetosho(title, year, max_per_source, media_type)
    # Tordl (torrentdownload.info): already fully written and correct, just
    # never wired in — confirmed live 2026-08-11 with real results (50
    # matches, real 40-char hashes, on "The Matrix 1999") using its existing
    # regex unchanged. Off by default like the rest of this block.
    if _src_on('tordl'):           tasks['Tordl']           = lambda: search_tordl(title, year, max_per_source, media_type)
    # Rutor/NNMClub: confirmed live 2026-08-11 (39 real magnets on Rutor,
    # real anonymous .torrent downloads on NNMClub). Both Russian trackers
    # with mixed Cyrillic/English titles — off by default like the rest of
    # this block, since seeders/mirror uptime for either haven't been
    # observed over any real length of time yet.
    if _src_on('rutor'):           tasks['Rutor']           = lambda: search_rutor(title, year, max_per_source, media_type)
    if _src_on('nnmclub'):         tasks['NNMClub']         = lambda: search_nnmclub(title, year, max_per_source, media_type)
    if media_type == 'movie' and _src_on('publicdomaintorrents'):
        tasks['PublicDomainTorrents'] = lambda: search_publicdomaintorrents(title, year, max_per_source, media_type)
    # Cleanbay/DaMagNet/RARBGDump: confirmed live 2026-09-03 — Cleanbay
    # (real magnets via its testbay.onrender.com backend, though several of
    # the 6 sites it metasearches appear dead upstream right now), DaMagNet
    # (real two-step DHT-index lookup, 67M+ resources), RARBGDump (real
    # JSON API over RARBG's frozen pre-2023 database). See each function's
    # own docstring for the full detail. Off by default like the rest of
    # this block, no track record yet.
    if _src_on('cleanbay'):        tasks['Cleanbay']        = lambda: search_cleanbay(title, year, max_per_source, media_type)
    if _src_on('damag'):           tasks['DaMagNet']        = lambda: search_damag(title, year, max_per_source, media_type)
    if _src_on('rarbgdump'):       tasks['RARBGDump']       = lambda: search_rarbgdump(title, year, max_per_source * 2, media_type)
    # Snowfl: confirmed live 2026-08-15 — real aggregator API (limetorrents/
    # 1337x/etc.), real magnets with real btih hashes; see search_snowfl's
    # own docstring for why this works despite the site's scraper-hostile
    # reputation. Carries adult content too (real `nsfw` flag per result,
    # used both to include it when media_type=='adult' and to filter it
    # back OUT for movie/tv searches) — kept in this generic block AND
    # given its own explicit adult-block entry below since its own filter
    # only works right when it already knows which mode it's in.
    if _src_on('snowfl'):          tasks['Snowfl']          = lambda: search_snowfl(title, year, max_per_source, media_type)
    # ApacheTorrent/RedeTorrent: confirmed live 2026-08-16 — genuinely
    # filtering server-rendered search, real inline magnets (no ad-gate),
    # Brazilian-Portuguese dubbed movie/TV catalog. Torseek: confirmed live
    # same day — Jackett-backed meta-search reachable via its Next.js
    # Server Action (see search_torseek's own docstring for the mechanism
    # and its build-specific fragility caveat). All three off by default
    # like the rest of this block, no track record yet.
    if _src_on('apachetorrent'):   tasks['ApacheTorrent']   = lambda: search_apachetorrent(title, year, max_per_source, media_type)
    if _src_on('redetorrent'):     tasks['RedeTorrent']     = lambda: search_redetorrent(title, year, max_per_source, media_type)
    if _src_on('torseek'):         tasks['Torseek']         = lambda: search_torseek(title, year, max_per_source, media_type)
    # FileMood: confirmed live 2026-08-16 — general DHT file index, no CF
    # bypass needed (see search_filemood's own comment for why that isn't a
    # contradiction despite the site being Cloudflare-fronted), info hash
    # embedded directly in each result's own URL. Off by default like the
    # rest of this block, no track record yet.
    if _src_on('filemood'):        tasks['FileMood']        = lambda: search_filemood(title, year, max_per_source, media_type)

    if media_type == 'adult':
        # Adult gets a completely different scraper mix than movie/tv, not
        # just the previous "movie/tv" mix minus a handful of weak ones.
        # Confirmed live 2026-09-03 this was a real, visible bug: every
        # generic movie/TV source built into `tasks` above (MSearch, TGX,
        # EXTto, TheRarBG, TorrentProject2, Torrentz2, Kickass2,
        # TorrentFunk, Torlock, TorrentsCSV, BitDig, Tordl, Rutor, NNMClub,
        # YourBT, Bitsearch, TorrentDL, LimeTorrents, MagnetDL,
        # BitTorrented, ApacheTorrent, RedeTorrent, Torseek, FileMood,
        # Cleanbay, DaMagNet, RARBGDump, 1337x, and even YTS — a
        # mainstream-only site with zero adult content at all, yet
        # previously explicitly re-added for media_type=='adult' just
        # below here) has no concept of "adult" and applies no adult-aware
        # filtering of its own. _meets_quality() (the one filter these
        # sources DO all run their results through) deliberately returns
        # True unconditionally for media_type=='adult', on the theory that
        # real adult releases don't reliably carry the same
        # resolution/non-video tags movie/tv releases do — but that same
        # blanket pass-through is exactly what let a real IMDB movie or TV
        # show whose title happened to match the search words sail straight
        # into "Adult" search results completely unfiltered, from any of
        # those ~25+ sources. The previous fix here only popped 5 of them
        # (YTS wasn't even one of the 5 — it was being added FOR adult) and
        # left the other ~20 running against the raw adult query. Clearing
        # the whole dict and rebuilding it below from only sources that
        # either are dedicated, adult-only trackers to begin with
        # (XXXClub/Rintor/XXXTor/FreeJAVTorrent/IJAVTorrent/Sukebei — no
        # mainstream catalog to leak from at all) or expose a real,
        # checkable adult signal of their own (TPB's own cat=500 XXX
        # category, Snowfl's own `nsfw` flag) is the actual fix: nothing
        # without at least one of those two guarantees runs for an adult
        # search at all now. Knaben is the one exception kept here despite
        # neither guarantee — its own category filter is broken server-side
        # (see search_knaben's own comment: "category filters are
        # unreliable — returns empty when set") so it's relying on the
        # same title/word match as everything just removed above. Left in
        # because that was already the deliberate, pre-existing choice for
        # this adult mix (not something this fix changed), but it's worth
        # knowing this one source can still theoretically surface a
        # same-titled mainstream result if a search term is generic enough
        # to collide with a real movie/show title.
        tasks = {}
        # Years are unreliable in adult release names (scene numbers get
        # mistaken for them) — query without one for these three, same as
        # search_xxxclub/search_rintor already do defensively on their own.
        tasks['TPB']     = lambda: search_tpb(title, None, tpb_cat, max(max_per_source * 2, 15), media_type)
        tasks['Knaben']  = lambda: search_knaben(title, None, media_type, max(max_per_source * 3, 30))
        tasks['XXXClub'] = lambda: search_xxxclub(title, year, max(max_per_source * 3, 20), media_type)
        tasks['Rintor']  = lambda: search_rintor(title, year, max_per_source, media_type)
        tasks['XXXTor']  = lambda: search_xxxtor(title, year, max(max_per_source * 3, 15), media_type)
        tasks['FreeJAVTorrent'] = lambda: search_freejavtorrent(title, year, max_per_source, media_type)
        tasks['IJAVTorrent'] = lambda: search_ijavtorrent(title, year, max_per_source, media_type)
        tasks['Sukebei'] = lambda: search_sukebei_nyaa(title, None, max(max_per_source * 2, 10), media_type)
        # Snowfl carries real adult content (confirmed live via its own
        # `nsfw` flag) — forced on here same as TPB/Knaben above, regardless
        # of the general Settings toggle, matching this block's existing
        # convention of always running its own known-good adult sources.
        tasks['Snowfl'] = lambda: search_snowfl(title, None, max(max_per_source * 2, 15), media_type)

    all_results = []
    # NOT a `with` block on purpose — same footgun already fixed in
    # metadata_router.py/free_sources.py's own pools (see their comments):
    # ThreadPoolExecutor.__exit__ always calls shutdown(wait=True), which
    # blocks until EVERY submitted task finishes, even ones the code below
    # has already given up on via as_completed's own timeout. Confirmed
    # live this was silently costing two things at once here: (1) the
    # function's real wall-clock time could run well past the 15s the
    # timeout implies, waiting on a slow 1337x mirror probe or an ext.to CF
    # retry that nothing downstream even wants; (2) a fast, reliable source
    # (TPB/EZTV confirmed individually sub-2s live) that simply lost the
    # race to be YIELDED before the 15s mark in one particular run — pure
    # network jitter, not a real slowdown of its own — got silently
    # dropped with no chance to ever show up, since the whole batch's
    # timeout is shared across every task regardless of how fast any one
    # of them individually is. Was raised to 25s for headroom against that
    # jitter; lowered again to 18s once the always-run task list itself
    # was trimmed down to a fast core set (see the torrent_extra_sources
    # setting above) - confirmed live that with only ~14 tasks instead of
    # ~34, the couple of sources having a genuinely bad moment (a real
    # connection timeout, not just slow) were what the full 25s was really
    # buying, at the cost of the picker taking noticeably longer on every
    # single search even when nothing was wrong - 18s matches gears' own
    # 20s external-search ceiling instead of exceeding it. The pool itself
    # is shut down without waiting so a straggler can't block the caller
    # after we've already stopped collecting its result anyway.
    # Every task here is I/O-bound (waiting on a network response, not CPU),
    # so there's no real cost to running them all truly concurrently instead
    # of artificially staggering them in batches. Capping this well below the
    # actual task count (previously 12 against 20-27 real sources once the
    # IMDB meta-search block grew) meant roughly half of every search sat
    # queued waiting for an earlier task to finish before it even started —
    # not a real slowdown of any individual source, just self-inflicted
    # serialization. One worker per task removes that queueing entirely.
    pool = ThreadPoolExecutor(max_workers=len(tasks))
    try:
        futures = {pool.submit(fn): name for name, fn in tasks.items()}
        try:
            for future in as_completed(futures, timeout=18):
                name = futures[future]
                try:
                    results = future.result()
                    xbmc.log('[Starfleet/Torrents] %s: %d results' % (name, len(results)), xbmc.LOGINFO)
                    all_results.extend(results)
                except Exception as e:
                    xbmc.log('[Starfleet/Torrents] %s failed: %s' % (name, e), xbmc.LOGWARNING)
        except Exception as e:
            xbmc.log('[Starfleet/Torrents] search_all timeout: %s' % e, xbmc.LOGWARNING)
    finally:
        pool.shutdown(wait=False)

    # Filter out false matches where the show/movie name doesn't appear as
    # whole words in the torrent title, and (for TV) wrong-episode matches.
    # See filter_by_title_and_episode()'s own docstring for the full
    # rationale — this used to be inline here; extracted so NZB/Usenet
    # search (nzb_sources.py, via debrid_torrent.py) can apply the exact
    # same strictness instead of shipping unfiltered.
    all_results = filter_by_title_and_episode(all_results, title, media_type=media_type,
                                               season=season, episode=episode)

    # Deduplicate by info_hash
    seen = set()
    unique = []
    for r in all_results:
        ih = r.get('info_hash', '').lower()
        if ih and ih not in seen:
            seen.add(ih)
            unique.append(r)

    unique.sort(key=lambda x: x.get('seeds', 0), reverse=True)
    if _HAS_CACHE:
        _cache.set(_ck, unique, 900)
    return unique
