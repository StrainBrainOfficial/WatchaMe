"""
Starfleet Category List Window — Starfleet-themed replacement for the native
Kodi Videos window, for top-level Movies/TV/Sports/Live TV/Adult browsing.

Opened directly in-process via doModal() from home.py's onClick handler —
deliberately NOT a separate RunScript process talking to Kodi's native
Videos window via ActivateWindow/Container.Update. That cross-process
handoff is the exact mechanism behind every navigation reliability issue
chased this session (refused activations, silent Container.Update no-ops,
Home windows left stuck and unresponsive) — Home never closes for this
hop, it's simply paused underneath while this window is modal on top, so
none of that machinery is involved at all for entering or leaving a
top-level category.

Kodi's native video Info dialog (cast photos, director/writer/rating/
genre/studio, Play/Trailer/etc.) is NOT rebuilt here — it isn't tied to
plugin-populated native lists specifically, it reads from whatever
ListItem is focused in ANY list control with a fully-populated
VideoInfoTag, native or custom-window-hosted. As long as items here carry
full info (title/plot/cast/director/etc., same data the existing native
listing already sets), Kodi's own Info action still shows that exact
dialog, unchanged, with zero extra work.
"""
import os
import threading
import xbmc
import xbmcgui
import xbmcaddon

_ID_LIST  = 500
_ID_CAST  = 460
_ID_MORE  = 450

# Local skin-media assets referenced by *relative* path (e.g. "media/x.png")
# were confirmed live to silently fail to render in this window — the
# poster panel, which sources its image from a full remote HTTPS URL via a
# Window Property, rendered perfectly every time, while every local
# media/*.png reference (dividers, highlight bar) never showed up at all,
# even after regenerating them as real pre-baked PNGs. Rather than keep
# chasing why relative skin-media resolution fails here, route local
# assets through the exact mechanism already proven to work: resolve each
# to an absolute filesystem path in Python and hand it to the XML via a
# Window Property, the same way the poster's own URL gets there.
_ASSET_FILES = {
    'sf_asset_focus_row':  'sf_focus_row.png',
    'sf_asset_divider':    'sf_divider.png',
    'sf_asset_dark_wash':  'sf_dark_wash.png',
    'sf_asset_checkmark':  'checkmark.png',
}

# Only fetch full detail (for the plot/cast panel) for the item actually in
# focus, not the whole list up front — same lazy-per-focus pattern Home
# already uses for its hero banner, so opening this window with a long list
# doesn't stall on dozens of detail fetches nobody's looking at yet.


class CategoryListWindow(xbmcgui.WindowXML):

    def __init__(self, *args, **kwargs):
        self._items       = kwargs.pop('items', [])
        self._breadcrumb  = kwargs.pop('breadcrumb', '')
        self._subheader   = kwargs.pop('subheader', '')
        self._media_type  = kwargs.pop('media_type', 'movie')
        self._on_play        = kwargs.pop('on_play', None)        # callable(film) -> None
        self._detail_fetch   = kwargs.pop('detail_fetch', None)   # callable(film) -> dict (cast/plot/etc)
        self._on_actor_click = kwargs.pop('on_actor_click', None) # callable(actor_name) -> None
        self._on_more        = kwargs.pop('on_more', None)        # callable() -> None
        # Lets a caller relabel the "More Sections" button when on_more's
        # actual behavior isn't "jump to another section" — Full Library's
        # pagination reuses this same button/callback for "Next Page"
        # instead of adding a whole separate control, but silently keeping
        # the generic label made that genuinely undiscoverable (confirmed
        # live: reported as "doesn't have a next page feature" even though
        # the mechanism existed, buried under a button that didn't say so).
        self._more_label     = kwargs.pop('more_label', 'More Sections >')
        self._context_menu   = kwargs.pop('context_menu', None)   # callable(film) -> [(label, action), ...]
        self._on_info         = kwargs.pop('on_info', None)        # callable(film) -> None — opens a full detail page
        # Per direct request: selecting a Movies/TV item should open the
        # rich detail screen FIRST (matching the Anticipated widget's own
        # behavior), not play/season-pick immediately — previously the
        # detail screen was only reachable via long-press "Info", every
        # plain select still went straight to _on_play. Opt-in (default
        # False) rather than a blanket change here, since this exact same
        # window class is also reused for Adult/Sports/season/episode
        # lists where a plain select genuinely SHOULD still act
        # immediately — only the 8 Movies/TV category callers in home.py
        # pass this as True.
        self._select_opens_info = kwargs.pop('select_opens_info', False)
        # Episode-list mode: the right panel normally shows each focused
        # item's own poster (per-focus), but an episode doesn't have its
        # own poster — static_poster pins it to the show's own poster once,
        # instead. show_left_thumb adds the episode's own still image above
        # the cast strip (which still shows normally, fed the show's own
        # cast via detail_fetch — same as Movies/Adult), with the plot/
        # metadata text moved below both.
        self._static_poster   = kwargs.pop('static_poster', None)
        self._show_left_thumb = kwargs.pop('show_left_thumb', False)
        self._sel_pos = -1
        self._cast_shown = []  # actors currently populating the 4 cast slots, in slot order
        self._closed = False  # set True the instant Back/close fires — see onAction()
        super(CategoryListWindow, self).__init__(*args, **kwargs)

    # ---------------------------------------------------------------- lifecycle

    def onInit(self):
        try:
            self.setProperty('sf_cat_breadcrumb', self._breadcrumb)
            self.setProperty('sf_cat_subheader', self._subheader)
            self.setProperty('sf_cat_has_more', 'true' if self._on_more else '')
            self.setProperty('sf_cat_more_label', self._more_label)
            if self._static_poster:
                self.setProperty('sf_cat_sel_poster', self._static_poster)
            self._set_asset_paths()
            self._populate_list()
            self._focus_list_with_retry()
            self._update_side_panels(0)
        except Exception as e:
            xbmc.log('[Starfleet/CategoryList] onInit: %s' % e, xbmc.LOGERROR)
            import traceback
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

    def _populate_list(self):
        """Fill the list control from self._items. Shared by onInit() and
        set_items() (the latter re-uses this SAME already-open window for a
        page turn instead of closing and reopening a new one — see that
        method's own docstring for why)."""
        ctrl = self.getControl(_ID_LIST)
        ctrl.reset()
        for film in self._items:
            li = xbmcgui.ListItem(label=self._label_for(film))
            li.setArt({
                'thumb':  film.get('thumb', ''),
                'fanart': film.get('fanart') or film.get('thumb', ''),
                'poster': film.get('thumb', ''),
            })
            info = {
                'title':      film.get('title', ''),
                'plot':       film.get('plot') or film.get('overview', ''),
                'year':       int(film.get('year') or 0) if str(film.get('year', '')).isdigit() else 0,
                'mediatype':  'tv' if self._media_type == 'tv' else 'movie',
            }
            if film.get('runtime'):
                info['duration'] = int(film['runtime']) * 60
            li.setInfo('video', info)
            li.setProperty('film_id', str(film.get('tmdb_id', film.get('id', ''))))
            # Watched/in-progress indicator — 'watched' is a plain bool
            # and 'progress_pct' an int 0-100, both supplied per-item by
            # whichever home.py list-builder populated this window (see
            # watch_history.get_progress()). Only one of the two ever
            # shows: a finished item gets the checkmark, an in-progress
            # one gets the percent label instead, never both.
            li.setProperty('sf_watched', 'true' if film.get('watched') else '')
            pct = film.get('progress_pct') or 0
            li.setProperty('sf_progress_pct', str(int(pct)) if pct and not film.get('watched') else '')
            # context_menu is deliberately NOT computed here per item.
            # Confirmed root cause of "Adult Full Library" nav feeling
            # broken (erratic highlight jumps, Back not responding):
            # _show_context_menu() below already re-derives ctx_items
            # fresh, on demand, for only the one focused item when
            # long-press actually happens — Kodi's native "auto-show the
            # focused item's registered context menu" doesn't apply to
            # this bespoke WindowXML in the first place (see that
            # method's own comment), so the addContextMenuItems() call
            # that used to sit here was computed for EVERY item up front
            # but never displayed by anything. Several context_menu
            # callbacks do real per-item disk/network I/O (e.g.
            # adult_favorites.is_favorite() opens and JSON-parses a file
            # from scratch on every call) — building that for hundreds
            # or thousands of Full Library items during this loop could
            # occupy Kodi's GUI thread for seconds while the window was
            # still opening, during which NO input (Up/Down/Back
            # included) gets processed at all; whatever the user pressed
            # in that window then replayed erratically once onInit
            # finally returned. Dropping this eager, unused computation
            # fixes that for every category that passes context_menu=,
            # not just Adult.
            ctrl.addItem(li)

    def set_items(self, items, breadcrumb=None, subheader=None, more_label=None):
        """Swap this SAME already-open window's content for a new page/list
        (e.g. Full Library's "Next Page") instead of closing this modal and
        opening a brand new one for it.

        Confirmed live 2026-08-28 (real user report): the close-then-reopen
        approach this replaced had two real, visible problems, not just
        one. First, closing THIS window reveals whatever's underneath it in
        the window stack (Home's own custom window, paused, not actually
        gone — see this module's own top docstring) for the brief interval
        before the new page's window opens and takes over again — reported
        back as "reverts to the widget home page and loads a new page and
        then displays it," which is exactly that. Second, it's genuinely
        slower: a full new CategoryListWindow means a full new onInit()
        (asset paths, list rebuild, first-item detail fetch) on top of
        whatever the caller's own fetch_fn/filtering step costs, even when
        that step is now fast on a warm cache — none of that teardown/
        rebuild cost is actually needed for what's fundamentally just
        swapping which slice of an already-fetched list is showing.
        Reusing this window's own already-initialized state (asset
        properties are already set, the window is already on screen) skips
        both problems at once."""
        try:
            self._items = items
            self._sel_pos = -1
            if breadcrumb is not None:
                self._breadcrumb = breadcrumb
                self.setProperty('sf_cat_breadcrumb', breadcrumb)
            if subheader is not None:
                self._subheader = subheader
                self.setProperty('sf_cat_subheader', subheader)
            if more_label is not None:
                self._more_label = more_label
                self.setProperty('sf_cat_more_label', more_label)
            self._populate_list()
            self._focus_list_with_retry()
            self._update_side_panels(0)
        except Exception as e:
            xbmc.log('[Starfleet/CategoryList] set_items: %s' % e, xbmc.LOGERROR)
            import traceback
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

    def _set_asset_paths(self):
        try:
            addon_path = xbmcaddon.Addon('plugin.video.starfleet').getAddonInfo('path')
            media_dir = os.path.join(addon_path, 'resources', 'skins', 'Default', 'media')
            for prop, filename in _ASSET_FILES.items():
                self.setProperty(prop, os.path.join(media_dir, filename))
        except Exception as e:
            xbmc.log('[Starfleet/CategoryList] _set_asset_paths: %s' % e, xbmc.LOGERROR)

    def _focus_list_with_retry(self):
        # Confirmed live: <defaultcontrol>500</defaultcontrol> pointing
        # straight at this dynamically-populated list fails outright —
        # "Control 500 in window ... has been asked to focus, but it can't"
        # — because Kodi's native defaultcontrol focus pass runs before
        # onInit() has populated any items, and a 0-item list can't take
        # focus. That silent failure fell through to the next focusable
        # control in document order (the More Sections button), leaving the
        # list permanently unfocused: no highlight ever visible, arrow keys
        # doing nothing (they were moving/looping within that button, not
        # the list), and the cast strip stuck on whatever onInit's own
        # initial _update_side_panels(0) call had already set. Items exist
        # by the time this runs (called after the addItem loop), but
        # setFocusId() immediately afterward isn't guaranteed to land in the
        # same frame either, so verify and retry a few times — same
        # verify-then-retry idiom already used for Home's own ActivateWindow
        # nav, applied here to a different Kodi API with the same
        # no-synchronous-guarantee behavior.
        for _ in range(6):
            self.setFocusId(_ID_LIST)
            if self.getFocusId() == _ID_LIST:
                return
            xbmc.sleep(50)
        xbmc.log('[Starfleet/CategoryList] could not focus the list after retries', xbmc.LOGWARNING)

    def _label_for(self, film):
        title = film.get('title', '')
        year  = film.get('year', '')
        label = '%s (%s)' % (title, year) if year else title
        if film.get('not_aired'):
            # The single not-yet-aired "up next" episode _open_tv_episodes
            # includes at the end of an otherwise aired-only list — styled
            # distinctly right in the row itself (not just the side panel,
            # which also gets the date via the 'meta' field) since this is
            # the actual list the user scrolls.
            air_date = film.get('ep_air_date', '')
            suffix = ' (Releases %s)' % air_date if air_date else ' (Not Yet Released)'
            label = '[COLOR FFFFFF00][I]%s%s[/I][/COLOR]' % (label, suffix)
        return label

    def onAction(self, action):
        aid = action.getId()
        if aid in (xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK,
                   xbmcgui.ACTION_STOP, xbmcgui.ACTION_PARENT_DIR):
            # Flip this BEFORE close() so any _fetch() thread still in
            # flight (see _update_side_panels below) bails out instead of
            # touching a control on a window that's being torn down —
            # belt-and-suspenders alongside the onInit fix above.
            self._closed = True
            self.close()
            return
        if aid in (xbmcgui.ACTION_MOVE_UP, xbmcgui.ACTION_MOVE_DOWN):
            try:
                pos = self.getControl(_ID_LIST).getSelectedPosition()
                if pos != self._sel_pos:
                    self._update_side_panels(pos)
            except Exception:
                pass
            return
        if aid == 117:  # ACTION_CONTEXT_MENU — 'c' key / long-press OK-or-Select
            self._show_context_menu()
            return
        # Temporary diagnostic: log any action id not already handled above,
        # so a long-press attempt that ISN'T actually action 117 on this
        # particular input setup shows up here instead of silently vanishing.
        xbmc.log('[Starfleet/CategoryList] unhandled action id=%d' % aid, xbmc.LOGINFO)

    def _show_context_menu(self):
        # li.addContextMenuItems() alone does nothing here — the automatic
        # 'show the focused item's registered context menu' behavior lives
        # in Kodi's native video/music window C++ classes (CGUIWindowVideoNav
        # etc), not in the generic WindowXML base this custom window
        # inherits from. Confirmed live: long-press produced no menu at all
        # even with addContextMenuItems() set. So this is handled entirely
        # ourselves — same end result (xbmc.executebuiltin on the chosen
        # action string), just triggered manually instead of relying on
        # native auto-display that doesn't apply to bespoke windows.
        if not self._context_menu and not self._on_info:
            return
        try:
            pos = self.getControl(_ID_LIST).getSelectedPosition()
            if not (0 <= pos < len(self._items)):
                return
            film = self._items[pos]
            ctx_items = list(self._context_menu(film) or []) if self._context_menu else []
            # 'Info' is a real Python callback (opens a doModal() detail
            # window directly), not a RunPlugin(...) action string like
            # everything else in ctx_items — RunPlugin fires through
            # dispatcher.py in a brand new background process, which has
            # no way to open a window on THIS already-running window
            # stack. Handled as its own branch below rather than folded
            # into ctx_items's (label, action-string) shape.
            labels = (['Info'] if self._on_info else []) + [label for label, _ in ctx_items]
            if not labels:
                return
            choice = xbmcgui.Dialog().contextmenu(labels)
            if choice < 0:
                return
            if self._on_info and choice == 0:
                self._on_info(film)
                return
            real_idx = choice - (1 if self._on_info else 0)
            if 0 <= real_idx < len(ctx_items):
                xbmc.executebuiltin(ctx_items[real_idx][1])
        except Exception as e:
            xbmc.log('[Starfleet/CategoryList] _show_context_menu: %s' % e, xbmc.LOGERROR)

    def onClick(self, cid):
        try:
            if cid == _ID_LIST:
                pos = self.getControl(_ID_LIST).getSelectedPosition()
                if 0 <= pos < len(self._items):
                    if self._select_opens_info and self._on_info:
                        self._on_info(self._items[pos])
                    elif self._on_play:
                        self._on_play(self._items[pos])
            elif cid == _ID_CAST:
                slot = self.getControl(_ID_CAST).getSelectedPosition()
                if 0 <= slot < len(self._cast_shown) and self._on_actor_click:
                    actor = self._cast_shown[slot]
                    self._on_actor_click(actor.get('name', ''))
            elif cid == _ID_MORE:
                if self._on_more:
                    self._on_more()
        except Exception as e:
            xbmc.log('[Starfleet/CategoryList] onClick: %s' % e, xbmc.LOGERROR)

    # ---------------------------------------------------------------- panels

    def _update_side_panels(self, pos):
        self._sel_pos = pos
        if not (0 <= pos < len(self._items)):
            return
        film = self._items[pos]
        self.setProperty('sf_cat_sel_title', film.get('title', ''))
        self.setProperty('sf_cat_sel_plot',  film.get('plot') or film.get('overview', ''))
        # Dedicated meta line — release year for movies, air date for TV
        # episodes. Callers may supply an already-formatted 'meta' string
        # (e.g. "Aired: 2024-03-01"); otherwise fall back to the bare year
        # already carried on every item for the title/info dict above.
        meta = film.get('meta') or (str(film.get('year')) if film.get('year') else '')
        self.setProperty('sf_cat_sel_meta', meta)
        # Separate properties for the dedicated poster panel vs the ambient
        # backdrop wash — both used to read the same fanart-preferring
        # value, so the poster panel was showing the wide backdrop image
        # instead of the actual vertical poster art.
        # In episode mode the right panel is pinned to the show's own
        # poster (set once in onInit, never touched here) — an episode
        # doesn't have its own poster, only a still image, which goes in
        # the left panel instead (sf_cat_sel_left_thumb below).
        if not self._static_poster:
            self.setProperty('sf_cat_sel_poster', film.get('thumb', ''))
        self.setProperty('sf_cat_sel_backdrop', film.get('fanart') or film.get('thumb', ''))
        self.setProperty('sf_cat_sel_left_thumb', film.get('thumb', '') if self._show_left_thumb else '')
        self.getControl(_ID_CAST).reset()
        self.setProperty('sf_cat_has_cast', '')
        self._cast_shown = []

        if not self._detail_fetch:
            return

        # Runs the actual fetch on a background thread — confirmed live as
        # a real bug: this used to call self._detail_fetch(film) straight
        # inline here, a real network call (ADE film detail, TMDB cast,
        # Sports venue photo, etc) that blocked THIS SAME thread onAction()
        # runs on. Kodi still moves the list's own highlighted position at
        # the native/C++ level while Python is stuck in that blocking call,
        # so holding Down (or just pressing it twice quickly) could queue
        # up several onAction calls that all then fire back-to-back the
        # instant the fetch finally returned, landing on a stale position
        # and reading as the highlight "jumping back". The staleness guard
        # below (self._sel_pos != pos) already existed for exactly this
        # race — it just never had an actual background thread to race
        # against, since everything ran synchronously on one thread.
        def _fetch(pos=pos, film=film):
            try:
                detail = self._detail_fetch(film) or {}
            except Exception as e:
                xbmc.log('[Starfleet/CategoryList] detail_fetch: %s' % e, xbmc.LOGWARNING)
                return

            # A later focus change may have landed here before this fetch
            # returned (e.g. holding Down) — don't overwrite a newer
            # selection's panel with a stale one's data. Also bail if the
            # window has since been closed (Back pressed while this fetch
            # was still in flight) — touching a control on a torn-down
            # window can throw natively, and doing that from a background
            # thread instead of the main GUI thread is exactly the kind of
            # thing that can wedge Kodi's input handling rather than just
            # log a clean traceback.
            if self._closed or self._sel_pos != pos:
                return

            try:
                if detail.get('overview') or detail.get('plot'):
                    self.setProperty('sf_cat_sel_plot', detail.get('overview', detail.get('plot', '')))
                # Optional lazy poster/backdrop override — e.g. Sports fetches
                # a venue image per-event on focus (a real network call),
                # same lazy pattern as cast photos below, rather than
                # pre-fetching for every item in the list up front.
                if detail.get('poster'):
                    self.setProperty('sf_cat_sel_poster', detail['poster'])
                if detail.get('backdrop'):
                    self.setProperty('sf_cat_sel_backdrop', detail['backdrop'])
                cast = detail.get('cast', [])
                cast_ctrl = self.getControl(_ID_CAST)
                cast_ctrl.reset()
                for actor in cast:
                    cli = xbmcgui.ListItem(label=actor.get('name', ''))
                    cli.setArt({'thumb': actor.get('photo', '')})
                    cast_ctrl.addItem(cli)
                self.setProperty('sf_cat_has_cast', 'true' if cast else '')
                self._cast_shown = cast
            except Exception as e:
                xbmc.log('[Starfleet/CategoryList] _fetch setProperty: %s' % e, xbmc.LOGDEBUG)

        threading.Thread(target=_fetch, daemon=True).start()
