﻿# -*- coding: utf-8 -*-
"""
resources/lib/debrid_torrent.py

Convert magnet links to playable stream URLs via debrid services.
Only uses CACHED torrents (instant availability) — never starts a download.

Supported services (checked in priority order from settings):
  Real-Debrid  — instant availability check → addMagnet → select → unrestrict
  AllDebrid    — instant check → upload magnet → get links → unlock
  Premiumize   — cache check → directdl with magnet src
  TorBox       — check cached → create torrent → request DL link

Public API:
  get_debrid_streams(title, year, media_type) → [{'label', 'url', 'info_hash'}]
"""

import re
import time
import xbmc
import xbmcaddon
import xbmcgui

ADDON = xbmcaddon.Addon('plugin.video.starfleet')

# Set once per Kodi session the first time a debrid service rejects the
# user's own credentials outright (bad/expired/revoked key) -- every magnet
# fails identically in that case, so a per-link exception filter wouldn't
# help; the real fix is the user re-entering a valid key in Settings. This
# just makes that failure mode obvious instead of silently repeating a log
# warning per attempt.
_auth_error_notified = set()


def _notify_bad_apikey(service_name):
    if service_name in _auth_error_notified:
        return
    _auth_error_notified.add(service_name)
    xbmcgui.Dialog().notification(
        'Starfleet', '%s rejected your API key — check Settings > Premium Services' % service_name,
        xbmcgui.NOTIFICATION_ERROR, 6000)

try:
    import requests as _req
except ImportError:
    _req = None

_HEADERS = {'User-Agent': 'plugin.video.starfleet/1.1'}

# A torrent's own file list can include a virus/fake payload (typically a
# .exe posing as a "codec pack" or similar) even when the torrent's overall
# advertised name looks like a legitimate video release — confirmed live:
# AllDebrid resolved and served a torrent's file list whose single BIGGEST
# entry was a ".exe", which Kodi's video player correctly refused to play
# ("error probing input format"), even though nothing about the torrent's
# own display name looked suspicious. Picking "the biggest file" without
# checking its extension is exactly what let that through — every AllDebrid
# file-selection site below now goes through _ad_biggest_video_file()
# instead of a bare max(..., key=size).
_VIDEO_EXTS = ('.mp4', '.mkv', '.avi', '.mov', '.m4v', '.wmv', '.ts', '.webm', '.flv', '.mpg', '.mpeg')
_BAD_FILE_EXTS = ('.exe', '.zip', '.rar', '.bat', '.msi', '.dmg', '.apk', '.iso',
                  '.7z', '.tar', '.gz', '.scr', '.cmd', '.txt', '.nfo',
                  '.jpg', '.jpeg', '.png', '.srt', '.sub')

def _ad_biggest_video_file(files):
    """Largest file that's actually a video — never a bundled fake/virus
    payload or a non-video sidecar (subtitle, poster, .nfo) that happens to
    be the biggest entry. Falls back to 'biggest file not explicitly a
    known-bad extension' if nothing has a recognized video extension
    (some legitimate releases have unusual/missing extensions), and
    returns None only if every file looks actively suspicious."""
    named = [f for f in files if f.get('n')]
    candidates = [f for f in named if f['n'].lower().endswith(_VIDEO_EXTS)]
    if not candidates:
        candidates = [f for f in named if not f['n'].lower().endswith(_BAD_FILE_EXTS)]
    if not candidates:
        return None
    return max(candidates, key=lambda f: f.get('s', 0))


# A torrent correctly matched as "the right show" can still be a season
# pack with one file per episode - picking "just the biggest file" (every
# *_magnet_to_stream below did exactly this) or a hardcoded file index
# with no regard for WHICH episode that file actually is was a real,
# confirmed bug: a real user report of a Comet-sourced season-pack magnet
# playing an entirely different episode than the one requested, even
# though the magnet/torrent itself was genuinely the correct show. This
# mirrors torrent_sources.filter_by_title_and_episode / magnet_library's
# _episode_ok, applied one level deeper - at the individual FILE level
# inside an already-matched torrent, not the torrent's own overall title.
_RE_EP_MARKER = re.compile(r's0*(\d{1,2})[\s._-]*e0*(\d{1,3})(?!\d)', re.IGNORECASE)


def _filter_by_episode(items, season, episode, name_fn):
    """Narrow a torrent's file list to whichever file's OWN name has an
    S/E marker matching the requested episode. Movies (season/episode
    None) and any torrent whose files aren't individually episode-tagged
    at all (a genuine single-episode release, or files with no per-file
    marker) return every item unfiltered - this can only ever narrow down
    a real multi-episode pack, never wrongly reject a normal release."""
    if season is None or episode is None:
        return items
    matched = []
    for item in items:
        name = name_fn(item) or ''
        markers = _RE_EP_MARKER.findall(name)
        if not markers:
            continue
        if any(int(s) == int(season) and int(e) == int(episode) for s, e in markers):
            matched.append(item)
    return matched if matched else items

# How long to keep polling a just-added (not-yet-confirmed-cached) magnet
# before giving up — see rd_magnet_to_stream/ad_magnet_to_stream docstrings.
# Was 30*2.0=60s for both — confirmed live via kodi.log + a direct user
# report: a real, genuinely-uncached torrent ("Invasion S01E01", 1 real
# match found) was still downloading on AllDebrid's own servers when
# Starfleet gave up at ~65s elapsed, then the user checked AllDebrid's own
# site moments later and saw it had just finished — the real download
# simply needed a bit more than the old 60s window. Bumped to 90s for
# both services (kept identical to each other for a consistent wait
# across RD/AD) — long enough to catch this case without turning the
# genuinely-never-going-to-cache case into a multi-minute wait.
_RD_POLL_ATTEMPTS = 45
_RD_POLL_INTERVAL = 2.0
_AD_POLL_ATTEMPTS = 45
_AD_POLL_INTERVAL = 2.0

# ── Credentials ────────────────────────────────────────────────────────────
# Native to this addon's own settings.xml (Settings → Premium Services) —
# same enable-toggle + API-key fields resolvers.py's link-unrestrict path
# reads for these same four services. If a field here is left empty, AD/PM/TB
# fall back to a separate, independently-maintained hoster-resolver module's
# already-stored token for that service (see _ru_key's own docstring) —
# never overrides an explicitly-entered key here, never turns a service on
# that isn't explicitly enabled in this addon's own settings. Real-Debrid is
# deliberately excluded (see _ru_key) since its token there can be a
# short-lived OAuth value that module refreshes on its own schedule.

def _ru_key(resolver_class):
    """See resolvers.py's _ru_token — identical fallback, kept as its own
    small copy here rather than a shared import, matching this file's
    existing pattern of parallel (not shared) credential helpers with
    resolvers.py."""
    try:
        if not xbmc.getCondVisibility("System.HasAddon(script.module.resolveurl)"):
            return ''
        addon = xbmcaddon.Addon('script.module.resolveurl')
        return (addon.getSetting('%s_token' % resolver_class) or '').strip()
    except Exception:
        return ''

def _rd_key():  return ADDON.getSetting('rd_api_key').strip() or _ru_key('RealDebridResolver')
def _ad_key():  return ADDON.getSetting('ad_api_key').strip() or _ru_key('AllDebridResolver')
def _pm_key():  return ADDON.getSetting('pm_api_key').strip() or _ru_key('PremiumizeMeResolver')
def _tb_key():  return ADDON.getSetting('tb_api_key').strip() or _ru_key('TorBoxResolver')
def _rd_on():   return ADDON.getSetting('rd_enabled') == 'true' and bool(_rd_key())
def _ad_on():   return ADDON.getSetting('ad_enabled') == 'true' and bool(_ad_key())
def _pm_on():   return ADDON.getSetting('pm_enabled') == 'true' and bool(_pm_key())
def _tb_on():   return ADDON.getSetting('tb_enabled') == 'true' and bool(_tb_key())

RD_BASE = 'https://api.real-debrid.com/rest/1.0'
AD_BASE = 'https://api.alldebrid.com/v4'
# magnet/status specifically moved to v4.1 — confirmed live: v4/magnet/status
# now returns {"error":{"code":"DISCONTINUED", "message":"...migrate to
# newest API"}}, while the exact same call against v4.1 succeeds with real
# file links. upload/unlock are unaffected — both still work fine on plain
# v4 (also confirmed live) — so only this one endpoint needs the different
# base, not a wholesale version bump.
AD_STATUS_BASE = 'https://api.alldebrid.com/v4.1'
PM_BASE = 'https://www.premiumize.me/api'
TB_BASE = 'https://api.torbox.app/v1/api'

_session = None

def _sess():
    """Real bug found live 2026-08-16 off a Firestick-only kodi.log: every
    *_magnet_to_stream() function silently returned '' with ZERO logging
    whenever this returned None, which happened whenever the module-level
    `import requests as _req` at the top of this file failed once — and
    since that's a one-shot try/except at import time, a single transient
    failure (far more likely on Android/Firestick's slower storage than a
    fast Windows SSD reading the same file) permanently disabled EVERY
    debrid service for the rest of that process's life, even though
    `requests` demonstrably imported and worked fine elsewhere in the exact
    same run (the torrent-site scrapers all succeeded first). Confirmed
    live: AllDebrid AND Premiumize both "tried" and failed within ~2.5s
    each with no [Starfleet/Debrid] log line at all in between - the only
    return path in either function with no logging is this one. Two fixes:
    log clearly when this happens (so it's never silent again), and retry
    the import here instead of trusting the one attempt at module load —
    `import requests` is idempotent and nearly free once any other module
    in the process has already imported it successfully."""
    global _session, _req
    if _req is None:
        try:
            import requests as _req_retry
            _req = _req_retry
            xbmc.log('[Starfleet/Debrid] requests import retry succeeded '
                      '(failed at module load, now available)', xbmc.LOGWARNING)
        except ImportError as e:
            xbmc.log('[Starfleet/Debrid] requests unavailable - every debrid '
                      'magnet resolve will silently fail until this is fixed: %s' % e,
                      xbmc.LOGERROR)
            return None
    if _session is None:
        _session = _req.Session()
        _session.headers.update(_HEADERS)
        a = _req.adapters.HTTPAdapter(pool_connections=2, pool_maxsize=4,
                                      max_retries=_req.adapters.Retry(total=1))
        _session.mount('https://', a)
    return _session


def _rd_auth():
    return {**_HEADERS, 'Authorization': 'Bearer %s' % _rd_key()}

def _tb_auth():
    return {**_HEADERS, 'Authorization': 'Bearer %s' % _tb_key()}


# ── Real-Debrid magnet flow ───────────────────────────────────────────────────
#
# /torrents/instantAvailability used to be a cheap bulk pre-check (mirrored by
# the now-dangling function below) but RD stopped reliably reporting real
# cache status through it — confirmed against other current, actively
# maintained Real-Debrid client implementations, which have all dropped this
# pre-check and go straight to adding the magnet instead. Same bug shape as
# the AllDebrid one above: gating rd_magnet_to_stream() on this set meant RD
# could be silently skipped for every torrent regardless of real cache
# status. Fix: skip the pre-check, rely on addMagnet -> selectFiles ->
# info's own 'downloaded' status (already what _rd_add_magnet_and_get_links
# below does, and already fast — cached torrents flip to 'downloaded'
# within the first poll or two).

def _rd_instant_hashes(hashes):
    """Unused (see note above) — kept only in case RD's bulk check is ever
    restored; nothing calls this anymore."""
    if not hashes or not _rd_on():
        return set()
    try:
        s = _sess()
        if not s:
            return set()
        chunk = '/'.join(hashes[:40])
        r = s.get(RD_BASE + '/torrents/instantAvailability/%s' % chunk,
                  headers=_rd_auth(), timeout=10)
        if r.status_code != 200:
            return set()
        data = r.json()
        cached = set()
        for ih, val in data.items():
            if val and isinstance(val, dict) and val.get('rd'):
                cached.add(ih.lower())
        return cached
    except Exception as e:
        xbmc.log('[Starfleet/Debrid] RD instant check error: %s' % e, xbmc.LOGWARNING)
        return set()


_RD_TERMINAL_ERROR_STATUSES = {'error', 'magnet_error', 'virus', 'dead'}

def _rd_add_magnet_and_get_links(magnet, progress_cb=None):
    """Add a magnet to RD and return (links, files) — direct download URLs
    plus the matching per-file metadata (path/bytes) RD's own /info
    response provides in the same order, both filtered to just the
    selected files. Returning files alongside links (not just links, as
    before) is what lets a caller identify WHICH file a season-pack's
    magnet is handing back before picking one — see _filter_by_episode's
    own docstring. A genuinely cached torrent flips to 'downloaded' almost
    instantly, but an uncached-but-well-seeded one can take real download
    time.

    No fixed attempt/time cap on the poll below (same reasoning as
    ad_magnet_to_stream's own docstring) — confirmed by reading a
    separately-maintained hoster-resolver module's own Real-Debrid
    handling that it never gives up on a torrent that's genuinely still
    downloading, only on a real terminal error status or the user
    cancelling. Loops until 'downloaded', a genuine error status, or
    progress_cb says the user cancelled. progress_cb(message, percent)
    reflects RD's own reported download progress/speed/seeders, not a
    fake time-elapsed percentage."""
    try:
        s = _sess()
        if not s:
            return [], []
        # 1. Add magnet
        r = s.post(RD_BASE + '/torrents/addMagnet',
                   data={'magnet': magnet},
                   headers=_rd_auth(), timeout=10)
        if r.status_code not in (200, 201):
            return [], []
        torrent_id = r.json().get('id', '')
        if not torrent_id:
            return [], []

        # 2. Select all files
        s.post(RD_BASE + '/torrents/selectFiles/%s' % torrent_id,
               data={'files': 'all'},
               headers=_rd_auth(), timeout=10)

        # 3. Poll torrent info until 'downloaded', a real error, or cancel —
        # see docstring above for why this has no attempt-count ceiling.
        while True:
            r2 = s.get(RD_BASE + '/torrents/info/%s' % torrent_id,
                       headers=_rd_auth(), timeout=8)
            info = {}
            if r2.status_code == 200:
                info = r2.json()
                status = info.get('status', '')
                if status == 'downloaded':
                    links = info.get('links', [])
                    if links:
                        # RD's own 'files' array lists EVERY file in the
                        # torrent (selected or not), in a stable order;
                        # 'links' only covers the ones selected (all of
                        # them here, via selectFiles above) in that same
                        # relative order — filtering to selected=1 first
                        # keeps the two lists positionally aligned.
                        all_files = info.get('files', [])
                        selected = [f for f in all_files if f.get('selected')]
                        files = selected if len(selected) == len(links) else all_files[:len(links)]
                        return links, files
                    break
                if status in _RD_TERMINAL_ERROR_STATUSES:
                    break
            if progress_cb:
                pct = int(info.get('progress') or 0)
                status_text = info.get('status', '') or 'Waiting on Real-Debrid…'
                speed = info.get('speed') or 0
                seeders = info.get('seeders')
                extra = ''
                if speed:
                    extra = ' — %.1f MB/s' % (speed / 1_000_000.0)
                if seeders is not None:
                    extra += ' (%s seeders)' % seeders
                if not progress_cb('%s%s' % (status_text, extra), pct):
                    return [], []
            time.sleep(_RD_POLL_INTERVAL)
        return [], []
    except Exception as e:
        xbmc.log('[Starfleet/Debrid] RD add magnet error: %s' % e, xbmc.LOGERROR)
        return [], []


def _rd_unrestrict(link):
    """Unrestrict a single RD link to a direct stream URL."""
    try:
        s = _sess()
        if not s:
            return ''
        r = s.post(RD_BASE + '/unrestrict/link',
                   data={'link': link},
                   headers=_rd_auth(), timeout=10)
        if r.status_code == 200:
            return r.json().get('download', '')
    except Exception as e:
        xbmc.log('[Starfleet/Debrid] RD unrestrict error: %s' % e, xbmc.LOGWARNING)
    return ''


def rd_magnet_to_stream(magnet, info_hash='', progress_cb=None, season=None, episode=None):
    """
    Full RD flow: add → select → poll for 'downloaded' → unrestrict → return
    stream URL. No pre-check — see the note above _rd_instant_hashes: RD's
    instantAvailability no longer reliably reports real cache status, so
    the real add+poll IS the cache check now, same shape as AllDebrid's fix
    below — except this now polls for a real, meaningful window (up to
    _RD_POLL_ATTEMPTS * _RD_POLL_INTERVAL seconds) instead of giving up
    almost immediately, so an enabled debrid service genuinely gets tried
    before ever falling back to Elementum, not just checked for whether it
    happened to already be cached. Returns '' if it never finishes
    downloading in that window (or any step fails).

    season/episode narrow a season-pack's file list to the matching
    episode before picking a link — see _filter_by_episode's own
    docstring; this used to always take links[0] regardless of which
    episode that actually was.
    """
    if not _rd_on():
        return ''
    links, files = _rd_add_magnet_and_get_links(magnet, progress_cb=progress_cb)
    if not links:
        return ''
    if files and len(files) == len(links):
        paired = _filter_by_episode(list(zip(links, files)), season, episode,
                                     lambda pair: pair[1].get('path', ''))
        chosen_link = paired[0][0] if paired else links[0]
    else:
        chosen_link = links[0]
    stream = _rd_unrestrict(chosen_link)
    if stream:
        xbmc.log('[Starfleet/Debrid] RD stream: %s' % stream[:60], xbmc.LOGINFO)
    return stream


def rd_magnet_quick_check(magnet, info_hash='', season=None, episode=None):
    """One-shot check: add + select + a SINGLE immediate status read — no
    polling loop at all. Returns a stream URL if RD already reports this
    magnet as 'downloaded' right now, or '' immediately otherwise (never
    waits). Used to try several same-quality candidate torrents in rapid
    succession so a search with many options is likely to find one that's
    already cached, instead of committing to a real wait on whichever one
    the user happened to click first.

    season/episode: see rd_magnet_to_stream's own docstring."""
    if not _rd_on():
        return ''
    try:
        s = _sess()
        if not s:
            return ''
        r = s.post(RD_BASE + '/torrents/addMagnet', data={'magnet': magnet},
                   headers=_rd_auth(), timeout=10)
        if r.status_code not in (200, 201):
            return ''
        torrent_id = r.json().get('id', '')
        if not torrent_id:
            return ''
        s.post(RD_BASE + '/torrents/selectFiles/%s' % torrent_id,
               data={'files': 'all'}, headers=_rd_auth(), timeout=10)
        r2 = s.get(RD_BASE + '/torrents/info/%s' % torrent_id,
                   headers=_rd_auth(), timeout=8)
        if r2.status_code != 200:
            return ''
        info = r2.json()
        if info.get('status') != 'downloaded':
            return ''
        links = info.get('links', [])
        if not links:
            return ''
        all_files = info.get('files', [])
        selected = [f for f in all_files if f.get('selected')]
        files = selected if len(selected) == len(links) else all_files[:len(links)]
        if files and len(files) == len(links):
            paired = _filter_by_episode(list(zip(links, files)), season, episode,
                                         lambda pair: pair[1].get('path', ''))
            chosen_link = paired[0][0] if paired else links[0]
        else:
            chosen_link = links[0]
        stream = _rd_unrestrict(chosen_link)
        if stream:
            xbmc.log('[Starfleet/Debrid] RD quick-check stream: %s' % stream[:60], xbmc.LOGINFO)
        return stream
    except Exception as e:
        xbmc.log('[Starfleet/Debrid] RD quick-check error: %s' % e, xbmc.LOGWARNING)
        return ''


# ── AllDebrid magnet flow ─────────────────────────────────────────────────────
#
# There used to be a separate bulk pre-check here (_ad_instant_hashes, hitting
# /v4/magnet/instant) mirroring RD's instantAvailability endpoint — confirmed
# live (real API key, direct HTTP call) that /v4/magnet/instant now returns a
# flat 404 "Endpoint doesn't exist". Since ad_magnet_to_stream() was gated on
# "hash must already be in the set _ad_instant_hashes() returned", and that set
# was ALWAYS empty (every call silently failed the status-check and returned
# set()), AllDebrid was being skipped for every single torrent regardless of
# whether it was actually cached — this is the actual bug behind "enabled
# AllDebrid but Elementum still tried to play it".
#
# Fix: /v4/magnet/upload itself reports instant-cache status per magnet via
# its own 'ready' field — no separate bulk-check endpoint needed at all. This
# folds the check into the resolve step (same shape PM/TB already use below,
# via svc_map's needs_set=False), instead of a cheap-bulk-check-then-resolve
# two-phase flow like RD's.

def _ad_extract_files(magnet_info):
    files = []
    for entry in magnet_info.get('files', []):
        for f in (entry.get('e') or [entry]):
            if f.get('l'):
                files.append(f)
    return files


def ad_magnet_to_stream(magnet, info_hash='', progress_cb=None, season=None, episode=None):
    """AllDebrid: upload magnet → poll magnet/status until files are ready
    → unlock the right one. info_hash is accepted for signature parity
    with the other *_magnet_to_stream functions but unused.

    season/episode (TV only) narrow a season-pack magnet's file list down
    to the one matching file BEFORE picking "biggest" - see
    _filter_by_episode's own docstring for why this matters: a torrent
    correctly matched as the right show can still hand back an entirely
    different episode's file if this isn't done (confirmed live via a real
    user report on a Comet-sourced season pack).

    No fixed attempt/time cap on the poll below — confirmed live (both via
    kodi.log timestamps and by reading a separately-maintained hoster-
    resolver module's own AllDebrid handling) that a hard ~90s ceiling gives
    up on plenty of torrents that AllDebrid is genuinely, actively
    downloading and would finish given a real chance — that other module
    just keeps polling with a live download-progress display until the
    transfer actually finishes (or errors, or the user cancels), with no
    artificial deadline at all. Mirrors that here: loop until the magnet
    reports files, hits a genuine error status, or progress_cb says the
    user cancelled (via the existing progress-dialog cancel button) —
    never silently gives up on a torrent that's still making real
    progress. progress_cb(message, percent) now reflects the magnet's
    actual downloaded/size ratio (and speed/seeders when available)
    instead of a fake "time elapsed" percentage."""
    if not _ad_on():
        return ''
    try:
        s = _sess()
        if not s:
            return ''
        base_params = {'agent': 'starfleet', 'apikey': _ad_key()}

        r = s.post(AD_BASE + '/magnet/upload',
                   params=base_params,
                   data={'magnets[]': magnet}, timeout=10)
        if r.status_code != 200:
            xbmc.log('[Starfleet/Debrid] AD upload HTTP %s: %s' %
                     (r.status_code, r.text[:300]), xbmc.LOGWARNING)
            return ''
        data = r.json()
        if data.get('status') != 'success':
            err_code = (data.get('error') or {}).get('code', '')
            xbmc.log('[Starfleet/Debrid] AD upload non-success response: %s' %
                     str(data)[:300], xbmc.LOGWARNING)
            if err_code.startswith('AUTH_'):
                _notify_bad_apikey('AllDebrid')
            return ''
        magnets = data.get('data', {}).get('magnets', [])
        if not magnets:
            xbmc.log('[Starfleet/Debrid] AD upload returned no magnets: %s' %
                     str(data)[:300], xbmc.LOGWARNING)
            return ''
        m = magnets[0]
        if m.get('error'):
            xbmc.log('[Starfleet/Debrid] AD magnet error: %s (full: %s)' %
                     (m['error'].get('message', ''), str(m)[:300]), xbmc.LOGWARNING)
            return ''
        magnet_id = m.get('id', '')
        if not magnet_id:
            xbmc.log('[Starfleet/Debrid] AD upload had no magnet id: %s' % str(m)[:300], xbmc.LOGWARNING)
            return ''

        # Poll magnet/status until it reports files, errors out, or the
        # user cancels via progress_cb — see docstring above for why this
        # deliberately has no attempt-count/time ceiling of its own.
        files = []
        while True:
            r2 = s.get(AD_STATUS_BASE + '/magnet/status',
                       params={**base_params, 'id': magnet_id}, timeout=10)
            magnet_info = {}
            if r2.status_code == 200:
                status_data = r2.json()
                if status_data.get('status') == 'success':
                    magnet_info = status_data.get('data', {}).get('magnets', {})
                    files = _ad_extract_files(magnet_info)
                    status_text = magnet_info.get('status', '')
                    if files or status_text == 'Error':
                        if status_text == 'Error' and not files:
                            xbmc.log('[Starfleet/Debrid] AD magnet_id=%s reported Error status: %s' %
                                     (magnet_id, str(magnet_info)[:400]), xbmc.LOGWARNING)
                        break
                else:
                    xbmc.log('[Starfleet/Debrid] AD status poll non-success: %s' %
                             str(status_data)[:300], xbmc.LOGWARNING)
            else:
                xbmc.log('[Starfleet/Debrid] AD status poll HTTP %s: %s' %
                         (r2.status_code, r2.text[:300]), xbmc.LOGWARNING)
            if progress_cb:
                size = magnet_info.get('size') or 0
                downloaded = magnet_info.get('downloaded') or 0
                pct = int(downloaded * 100 / size) if size else 0
                status_text = magnet_info.get('status', '') or 'Waiting on AllDebrid…'
                speed = magnet_info.get('downloadSpeed') or 0
                seeders = magnet_info.get('seeders')
                extra = ''
                if speed:
                    extra = ' — %.1f MB/s' % (speed / 1_000_000.0)
                if seeders is not None:
                    extra += ' (%s seeders)' % seeders
                if not progress_cb('%s%s' % (status_text, extra), pct):
                    # Real silent-failure path found live 2026-08-16 via a
                    # Firestick kodi.log: this magnet (already confirmed cached
                    # in the user's own AllDebrid account) failed to resolve
                    # with ZERO [Starfleet/Debrid] log output across ~9 real
                    # seconds of polling — every other return path in this
                    # function logs something, this was the only one that
                    # didn't. progress_cb only returns False when the progress
                    # dialog's own iscanceled() is True, so this is either a
                    # real user cancel or (worth ruling out next) a dialog
                    # that never displayed correctly reporting itself as
                    # already-cancelled on that specific device.
                    xbmc.log('[Starfleet/Debrid] AD poll stopped: progress dialog '
                              'reported cancelled (magnet_id=%s)' % magnet_id, xbmc.LOGWARNING)
                    return ''
            time.sleep(_AD_POLL_INTERVAL)

        # Fallback: another current AllDebrid client implementation notes
        # magnet/status can stop returning links and uses a dedicated
        # /magnet/files endpoint instead — our own live test above got real
        # links straight from magnet/status, so that's still tried first,
        # but this covers that case too (may only affect some torrents).
        if not files:
            r2b = s.post(AD_BASE + '/magnet/files',
                         params=base_params, data={'id[]': magnet_id}, timeout=10)
            if r2b.status_code == 200:
                files_data = r2b.json()
                if files_data.get('status') == 'success':
                    for magnet_entry in files_data.get('data', {}).get('magnets', []):
                        def _flatten(nodes):
                            for node in nodes:
                                if node.get('e'):
                                    for sub in _flatten(node['e']):
                                        yield sub
                                elif node.get('l'):
                                    yield node
                        files.extend(_flatten(magnet_entry.get('files', [])))

        if not files:
            return ''
        files = _filter_by_episode(files, season, episode, lambda f: f.get('n', ''))
        biggest = _ad_biggest_video_file(files)
        if not biggest:
            return ''
        raw_link = biggest.get('l', '')
        if not raw_link:
            return ''

        # Unlock the link
        r3 = s.get(AD_BASE + '/link/unlock',
                   params={**base_params, 'link': raw_link}, timeout=10)
        if r3.status_code == 200:
            data3 = r3.json()
            if data3.get('status') == 'success':
                stream = data3.get('data', {}).get('link', '')
                if stream:
                    xbmc.log('[Starfleet/Debrid] AD stream: %s' % stream[:60], xbmc.LOGINFO)
                    return stream
    except Exception as e:
        xbmc.log('[Starfleet/Debrid] AD magnet error: %s' % e, xbmc.LOGERROR)
    return ''


def ad_magnet_quick_check(magnet, info_hash='', season=None, episode=None):
    """One-shot check: upload, and only if AllDebrid's own upload response
    already flags it 'ready', a SINGLE immediate status+unlock — no polling
    loop at all. Returns a stream URL if this magnet is ALREADY cached
    right now, or '' immediately otherwise (never waits). Same rationale
    as rd_magnet_quick_check: try several same-quality candidates fast
    instead of committing to a real wait on just the one picked.

    season/episode narrow a season-pack's file list to the matching
    episode before picking - see ad_magnet_to_stream's own docstring.

    Every early-return path below now logs why, added 2026-08-16 after a
    real report this function couldn't be diagnosed at all: a torrent the
    user directly confirmed as cached in their own AllDebrid account (via
    AllDebrid's own site) still fell through to the slow polling path on
    Firestick, and this function - unlike ad_magnet_to_stream, fixed
    earlier the same day - logged literally nothing on any of its return
    paths, so there was no way to tell which check was actually failing."""
    if not _ad_on():
        return ''
    try:
        s = _sess()
        if not s:
            xbmc.log('[Starfleet/Debrid] AD quick-check: no session (requests unavailable)',
                      xbmc.LOGWARNING)
            return ''
        base_params = {'agent': 'starfleet', 'apikey': _ad_key()}
        r = s.post(AD_BASE + '/magnet/upload', params=base_params,
                   data={'magnets[]': magnet}, timeout=10)
        if r.status_code != 200:
            xbmc.log('[Starfleet/Debrid] AD quick-check upload HTTP %s: %s' %
                      (r.status_code, r.text[:300]), xbmc.LOGWARNING)
            return ''
        data = r.json()
        if data.get('status') != 'success':
            xbmc.log('[Starfleet/Debrid] AD quick-check upload non-success: %s' %
                      str(data)[:300], xbmc.LOGWARNING)
            return ''
        magnets = data.get('data', {}).get('magnets', [])
        if not magnets:
            xbmc.log('[Starfleet/Debrid] AD quick-check upload returned no magnets: %s' %
                      str(data)[:300], xbmc.LOGWARNING)
            return ''
        m = magnets[0]
        if m.get('error') or not m.get('ready'):
            xbmc.log('[Starfleet/Debrid] AD quick-check not ready (error=%s, ready=%s): %s' %
                      (m.get('error'), m.get('ready'), str(m)[:300]), xbmc.LOGINFO)
            return ''
        magnet_id = m.get('id', '')
        if not magnet_id:
            xbmc.log('[Starfleet/Debrid] AD quick-check had no magnet id: %s' % str(m)[:300],
                      xbmc.LOGWARNING)
            return ''
        r2 = s.get(AD_STATUS_BASE + '/magnet/status',
                   params={**base_params, 'id': magnet_id}, timeout=10)
        if r2.status_code != 200:
            xbmc.log('[Starfleet/Debrid] AD quick-check status HTTP %s: %s' %
                      (r2.status_code, r2.text[:300]), xbmc.LOGWARNING)
            return ''
        status_data = r2.json()
        if status_data.get('status') != 'success':
            xbmc.log('[Starfleet/Debrid] AD quick-check status non-success: %s' %
                      str(status_data)[:300], xbmc.LOGWARNING)
            return ''
        magnet_info = status_data.get('data', {}).get('magnets', {})
        files = _ad_extract_files(magnet_info)
        if not files:
            xbmc.log('[Starfleet/Debrid] AD quick-check ready but no files extracted: %s' %
                      str(magnet_info)[:300], xbmc.LOGWARNING)
            return ''
        files = _filter_by_episode(files, season, episode, lambda f: f.get('n', ''))
        biggest = _ad_biggest_video_file(files)
        if not biggest:
            xbmc.log('[Starfleet/Debrid] AD quick-check no video file after episode filter '
                      '(season=%s episode=%s, %d files before filter)' %
                      (season, episode, len(files)), xbmc.LOGWARNING)
            return ''
        raw_link = biggest.get('l', '')
        if not raw_link:
            xbmc.log('[Starfleet/Debrid] AD quick-check biggest file had no link: %s' %
                      str(biggest)[:300], xbmc.LOGWARNING)
            return ''
        stream = _ad_unlock_link(raw_link)
        if stream:
            xbmc.log('[Starfleet/Debrid] AD quick-check stream: %s' % stream[:60], xbmc.LOGINFO)
        return stream
    except Exception as e:
        xbmc.log('[Starfleet/Debrid] AD quick-check error: %s' % e, xbmc.LOGWARNING)
        return ''


# ── AllDebrid: play from the user's own already-finished library ────────────
#
# Confirmed live as a real gap: Starfleet only ever knows about whatever its
# own live torrent-site search happens to find THIS run — it has no way to
# see torrents the user already added directly on AllDebrid's own site (or
# that a previous Starfleet run got all the way to Ready). A user had entire
# season packs already sitting Finished in their own AllDebrid account, but
# Starfleet's live search only found a single, different episode torrent
# that wasn't reliably resolving — with no way to fall back to what was
# already sitting there ready. Checking the user's own library first means
# an already-finished match resolves instantly (no upload/poll wait at all)
# and doesn't depend on live scraping finding the same release again.

def _ad_list_finished_magnets():
    """List every magnet already Ready in the user's own AllDebrid account
    (GET /magnet/status with no id returns the full account list, per
    AllDebrid's own v4 API — statusCode 4 = Ready)."""
    if not _ad_on():
        return []
    try:
        s = _sess()
        if not s:
            return []
        base_params = {'agent': 'starfleet', 'apikey': _ad_key()}
        r = s.get(AD_STATUS_BASE + '/magnet/status', params=base_params, timeout=10)
        if r.status_code != 200:
            return []
        data = r.json()
        if data.get('status') != 'success':
            return []
        magnets = data.get('data', {}).get('magnets', [])
        return [m for m in magnets if m.get('statusCode') == 4]
    except Exception as e:
        xbmc.log('[Starfleet/Debrid] AD list magnets error: %s' % e, xbmc.LOGWARNING)
        return []


def _ad_get_magnet_files(magnet_id):
    """Flat list of {'n': name, 'l': link, 's': size} dicts for a finished
    magnet's actual files via /magnet/files — folders nest their children
    under an 'e' key, same shape ad_magnet_to_stream's own fallback path
    already flattens."""
    try:
        s = _sess()
        if not s:
            return []
        base_params = {'agent': 'starfleet', 'apikey': _ad_key()}
        r = s.post(AD_BASE + '/magnet/files', params=base_params,
                   data={'id[]': magnet_id}, timeout=10)
        if r.status_code != 200:
            return []
        data = r.json()
        if data.get('status') != 'success':
            return []
        out = []
        def _flatten(nodes):
            for node in nodes:
                if node.get('e'):
                    _flatten(node['e'])
                elif node.get('l'):
                    out.append(node)
        for magnet_entry in data.get('data', {}).get('magnets', []):
            _flatten(magnet_entry.get('files', []))
        return out
    except Exception as e:
        xbmc.log('[Starfleet/Debrid] AD get files error: %s' % e, xbmc.LOGWARNING)
        return []


def _ad_unlock_link(raw_link):
    try:
        s = _sess()
        if not s:
            return ''
        base_params = {'agent': 'starfleet', 'apikey': _ad_key()}
        r = s.get(AD_BASE + '/link/unlock', params={**base_params, 'link': raw_link}, timeout=10)
        if r.status_code == 200:
            data = r.json()
            if data.get('status') == 'success':
                return data.get('data', {}).get('link', '')
    except Exception as e:
        xbmc.log('[Starfleet/Debrid] AD unlock error: %s' % e, xbmc.LOGWARNING)
    return ''


def _ad_resolve_from_library(title, season=None, episode=None):
    """Match this title (and season/episode, for TV) against the user's
    own already-finished AllDebrid magnets by filename, and unlock the
    matching file directly — a single-file release matching this exact
    episode unlocks straight away; a season pack (no single-episode
    marker, or explicitly 'complete') gets its own file list checked for
    the specific episode's file instead of just grabbing the biggest one.
    Returns [] if AllDebrid isn't configured, the library is empty, or
    nothing matches — never raises.

    The title-word/episode filtering below is plain local string matching
    (no network calls) and stays a simple sequential loop. What used to
    also live in that same loop — _ad_get_magnet_files()/_ad_unlock_link(),
    two more AllDebrid API round-trips per matching entry — is now
    resolved for every matching entry CONCURRENTLY instead of one at a
    time. Confirmed live via kodi.log this was a real, measurable cost:
    12 sequential matches for one title took ~4.3s of pure network wait
    before the actual multi-site torrent search had even started logging
    results, on every single search that had that many library hits —
    same "I/O-bound, no real serialization cost" reasoning search_all()'s
    own pool already uses."""
    if not _ad_on() or not title:
        return []
    entries = _ad_list_finished_magnets()
    if not entries:
        return []
    norm_title = re.sub(r'[^a-z0-9]+', ' ', title.lower()).strip()
    title_words = [w for w in norm_title.split() if w]
    if not title_words:
        return []
    ep_re = None
    if season is not None and episode is not None:
        ep_re = re.compile(r's0*%d[\s._\-]*e0*%d(?!\d)' % (int(season), int(episode)), re.IGNORECASE)

    matched = []
    for m in entries:
        filename = m.get('filename', '') or ''
        norm_name = re.sub(r'[^a-z0-9]+', ' ', filename.lower())
        if not all(w in norm_name for w in title_words):
            continue
        magnet_id = m.get('id')
        if not magnet_id:
            continue
        matched.append((magnet_id, filename))
    if not matched:
        return []

    def _resolve_one(item):
        magnet_id, filename = item
        try:
            if ep_re and ep_re.search(filename):
                # Single-file release already naming this exact episode.
                files = _ad_get_magnet_files(magnet_id)
                if not files:
                    return None
                biggest = _ad_biggest_video_file(files)
                if not biggest:
                    return None
                link = _ad_unlock_link(biggest.get('l', ''))
                if link:
                    xbmc.log('[Starfleet/Debrid] AllDebrid library match: %s' % filename, xbmc.LOGINFO)
                    return {'label': 'My AllDebrid: %s' % filename, 'url': link, 'info_hash': ''}
                return None

            if ep_re:
                # Could be a season pack — look inside for this episode's own file.
                files = _ad_get_magnet_files(magnet_id)
                matching = [f for f in files if ep_re.search(f.get('n', ''))]
                if not matching:
                    return None
                biggest = _ad_biggest_video_file(matching)
                if not biggest:
                    return None
                link = _ad_unlock_link(biggest.get('l', ''))
                if link:
                    xbmc.log('[Starfleet/Debrid] AllDebrid library match (season pack): %s' % filename, xbmc.LOGINFO)
                    return {'label': 'My AllDebrid: %s' % filename, 'url': link, 'info_hash': ''}
                return None

            # Movie search (no season/episode) — expect a single video file.
            files = _ad_get_magnet_files(magnet_id)
            if not files:
                return None
            biggest = _ad_biggest_video_file(files)
            if not biggest:
                return None
            link = _ad_unlock_link(biggest.get('l', ''))
            if link:
                xbmc.log('[Starfleet/Debrid] AllDebrid library match: %s' % filename, xbmc.LOGINFO)
                return {'label': 'My AllDebrid: %s' % filename, 'url': link, 'info_hash': ''}
            return None
        except Exception as e:
            xbmc.log('[Starfleet/Debrid] AllDebrid library resolve error for %s: %s' % (filename, e),
                     xbmc.LOGWARNING)
            return None

    from concurrent.futures import ThreadPoolExecutor
    results = []
    with ThreadPoolExecutor(max_workers=len(matched)) as pool:
        for r in pool.map(_resolve_one, matched):
            if r:
                results.append(r)
    return results


# ── Premiumize magnet flow ────────────────────────────────────────────────────

def _pm_resolve_from_library(title, season=None, episode=None):
    """Premiumize equivalent of _ad_resolve_from_library() above — match this
    title (and season/episode, for TV) against the user's own already-
    finished Premiumize transfers by name, and return a direct stream link
    for whatever matches, before any live torrent search runs. Same
    'my own library first' shape and rationale as the AllDebrid version;
    see that function's own docstring.

    Confirmed live 2026-08-28 against a real account: /transfer/list
    returns full persistent history (not just active jobs), each entry
    either carrying a 'folder_id' (multi-file torrent — the matching
    episode's own file has to be found inside, same as AllDebrid's magnet
    file-list lookup) or a 'file_id' directly (single-file transfer, e.g.
    one adult clip — already exactly one file, no folder to look inside).
    Both cases end in a real 'link' field usable directly as the stream
    URL, no separate unlock step the way AllDebrid needs (Premiumize's own
    /folder/list and /item/details already return a playable direct link
    per file)."""
    if not _pm_on() or not title:
        return []
    try:
        s = _sess()
        if not s:
            return []
        r = s.get(PM_BASE + '/transfer/list', params={'apikey': _pm_key()}, timeout=15)
        if r.status_code != 200:
            return []
        entries = r.json().get('transfers', []) or []
    except Exception as e:
        xbmc.log('[Starfleet/Debrid] PM library list error: %s' % e, xbmc.LOGWARNING)
        return []
    if not entries:
        return []

    norm_title = re.sub(r'[^a-z0-9]+', ' ', title.lower()).strip()
    title_words = [w for w in norm_title.split() if w]
    if not title_words:
        return []
    ep_re = None
    if season is not None and episode is not None:
        ep_re = re.compile(r's0*%d[\s._\-]*e0*%d(?!\d)' % (int(season), int(episode)), re.IGNORECASE)

    matched = []
    for t in entries:
        if t.get('status') != 'finished':
            continue
        name = t.get('name', '') or ''
        norm_name = re.sub(r'[^a-z0-9]+', ' ', name.lower())
        if not all(w in norm_name for w in title_words):
            continue
        matched.append(t)
    if not matched:
        return []

    def _resolve_one(t):
        name = t.get('name', '') or ''
        try:
            s = _sess()
            if not s:
                return None
            folder_id = t.get('folder_id')
            file_id = t.get('file_id')

            if file_id and not folder_id:
                # Already exactly one file — only worth an extra episode
                # check when the outer transfer name itself didn't already
                # look like a specific-episode match (rare: a season-pack-
                # style name that somehow resolved to a single file_id).
                if ep_re and not ep_re.search(name):
                    return None
                r = s.get(PM_BASE + '/item/details',
                          params={'apikey': _pm_key(), 'id': file_id}, timeout=15)
                if r.status_code != 200:
                    return None
                item = r.json()
                link = item.get('link') or item.get('directlink', '')
                if link:
                    xbmc.log('[Starfleet/Debrid] Premiumize library match: %s' % name, xbmc.LOGINFO)
                    return {'label': 'My Premiumize: %s' % name, 'url': link, 'info_hash': ''}
                return None

            if not folder_id:
                return None
            r = s.get(PM_BASE + '/folder/list',
                      params={'apikey': _pm_key(), 'id': folder_id}, timeout=20)
            if r.status_code != 200:
                return None
            content = [c for c in r.json().get('content', []) if c.get('type') == 'file']
            videos = [c for c in content if (c.get('name', '') or '').lower().endswith(_VIDEO_EXTS)]
            if not videos:
                return None
            if ep_re:
                matching = [v for v in videos if ep_re.search(v.get('name', ''))]
                if not matching:
                    return None
                videos = matching
            biggest = max(videos, key=lambda c: c.get('size', 0))
            link = biggest.get('link') or biggest.get('directlink', '')
            if link:
                xbmc.log('[Starfleet/Debrid] Premiumize library match: %s' % biggest.get('name', name),
                         xbmc.LOGINFO)
                return {'label': 'My Premiumize: %s' % biggest.get('name', name), 'url': link, 'info_hash': ''}
            return None
        except Exception as e:
            xbmc.log('[Starfleet/Debrid] Premiumize library resolve error for %s: %s' % (name, e),
                     xbmc.LOGWARNING)
            return None

    from concurrent.futures import ThreadPoolExecutor
    results = []
    with ThreadPoolExecutor(max_workers=len(matched)) as pool:
        for r in pool.map(_resolve_one, matched):
            if r:
                results.append(r)
    return results


def _pm_check_cache(info_hash):
    """Return True if Premiumize has this hash cached.

    Every early-return here used to be silent, same gap already fixed on
    the AllDebrid side 2026-08-16 — added logging on the same pass after a
    direct report that Premiumize (also enabled) gave zero visibility into
    whether it was even being tried for a magnet that failed to resolve."""
    if not info_hash or not _pm_on():
        return False
    try:
        s = _sess()
        if not s:
            xbmc.log('[Starfleet/Debrid] PM cache check: no session (requests unavailable)',
                      xbmc.LOGWARNING)
            return False
        r = s.post(PM_BASE + '/cache/check',
                   data={'apikey': _pm_key(), 'items[]': info_hash},
                   timeout=10)
        if r.status_code != 200:
            xbmc.log('[Starfleet/Debrid] PM cache check HTTP %s: %s' %
                      (r.status_code, r.text[:300]), xbmc.LOGWARNING)
            return False
        data = r.json()
        if data.get('status') != 'success':
            xbmc.log('[Starfleet/Debrid] PM cache check non-success: %s' % str(data)[:300],
                      xbmc.LOGWARNING)
            return False
        cached = bool(data.get('response', [False])[0])
        xbmc.log('[Starfleet/Debrid] PM cache check hash=%s cached=%s' % (info_hash, cached),
                  xbmc.LOGINFO)
        return cached
    except Exception as e:
        xbmc.log('[Starfleet/Debrid] PM cache check error: %s' % e, xbmc.LOGWARNING)
    return False


_VIDEO_EXTS = ('.mp4', '.mkv', '.avi', '.mov', '.m4v', '.wmv', '.ts', '.webm')

def pm_magnet_to_stream(magnet, info_hash='', progress_cb=None, season=None, episode=None):
    """Premiumize: directdl with magnet as src → return the right video
    file's stream_link. cache/check gates this first (still confirmed live
    via ResolveURL's own current Premiumize resolver, which uses cache/check
    + directdl exactly this way — so unlike RD/AD this one wasn't broken).

    season/episode narrow a season-pack's file list to the matching
    episode before picking "biggest" — see _filter_by_episode's own
    docstring; this used to always take the single biggest file in the
    whole torrent regardless of which episode that actually was."""
    if not _pm_on():
        return ''
    if info_hash and not _pm_check_cache(info_hash):
        # _pm_check_cache itself now logs the actual cached=True/False
        # result (or why the check failed) — nothing further to add here.
        return ''
    try:
        s = _sess()
        if not s:
            xbmc.log('[Starfleet/Debrid] PM: no session (requests unavailable)', xbmc.LOGWARNING)
            return ''
        r = s.post(PM_BASE + '/transfer/directdl',
                   data={'apikey': _pm_key(), 'src': magnet},
                   timeout=15)
        if r.status_code != 200:
            xbmc.log('[Starfleet/Debrid] PM directdl HTTP %s: %s' %
                      (r.status_code, r.text[:300]), xbmc.LOGWARNING)
            return ''
        data = r.json()
        if data.get('status') != 'success':
            xbmc.log('[Starfleet/Debrid] PM directdl non-success: %s' % str(data)[:300],
                      xbmc.LOGWARNING)
            return ''
        content = data.get('content', [])
        videos = [item for item in content
                  if (item.get('path', '') or '').lower().endswith(_VIDEO_EXTS)]
        if not videos:
            videos = content
        videos = _filter_by_episode(videos, season, episode, lambda i: i.get('path', ''))
        if not videos:
            xbmc.log('[Starfleet/Debrid] PM directdl had no video file after episode filter '
                      '(season=%s episode=%s, %d files before filter)' %
                      (season, episode, len(content)), xbmc.LOGWARNING)
            return ''
        biggest = max(videos, key=lambda item: item.get('size', 0))
        stream = biggest.get('stream_link') or biggest.get('link', '')
        if not stream:
            xbmc.log('[Starfleet/Debrid] PM biggest file had no stream_link/link: %s' %
                      str(biggest)[:300], xbmc.LOGWARNING)
            return ''
        xbmc.log('[Starfleet/Debrid] PM stream: %s' % stream[:60], xbmc.LOGINFO)
        return stream
    except Exception as e:
        xbmc.log('[Starfleet/Debrid] PM magnet error: %s' % e, xbmc.LOGERROR)
    return ''


# ── TorBox magnet flow ────────────────────────────────────────────────────────

def _tb_check_cache(info_hash):
    """Return True if TorBox has this hash cached."""
    if not info_hash or not _tb_on():
        return False
    try:
        s = _sess()
        if not s:
            return False
        r = s.get(TB_BASE + '/torrents/checkcached',
                  params={'hash': info_hash, 'format': 'object', 'list_files': False},
                  headers=_tb_auth(), timeout=10)
        if r.status_code == 200:
            data = r.json()
            if data.get('success'):
                return bool(data.get('data'))
    except Exception as e:
        xbmc.log('[Starfleet/Debrid] TB cache check error: %s' % e, xbmc.LOGWARNING)
    return False


def tb_magnet_to_stream(magnet, info_hash='', progress_cb=None, season=None, episode=None):
    """TorBox: create torrent → list its files → request DL link for the
    right one. progress_cb accepted for calling-convention parity with
    rd/ad_magnet_to_stream but unused — TorBox's own checkcached pre-check
    is a reliable, documented cache check (unlike RD/AD's, which needed
    the add-and-poll workaround above), so there's no meaningful wait to
    report progress on here.

    file_id was previously hardcoded to 0 (always "the torrent's first
    file") — for a season-pack magnet with one file per episode, that's
    only ever correct by coincidence. Confirmed via a separately-
    maintained hoster-resolver module's own TorBox handling that file
    listing goes through torrents/mylist (bypass_cache) - not exposed by
    createtorrent's own response - so that's fetched first, filtered to
    the matching episode (see _filter_by_episode's own docstring), then
    the biggest matching file's own id is what's actually requested."""
    if not _tb_on():
        return ''
    if info_hash and not _tb_check_cache(info_hash):
        return ''
    try:
        s = _sess()
        if not s:
            return ''

        # Add torrent
        r = s.post(TB_BASE + '/torrents/createtorrent',
                   data={'magnet': magnet, 'seed': 1, 'allow_zip': False},
                   headers=_tb_auth(), timeout=15)
        if r.status_code not in (200, 201):
            return ''
        data = r.json()
        if not data.get('success'):
            return ''
        torrent_id = data.get('data', {}).get('torrent_id', '')
        if not torrent_id:
            return ''

        # List files so a season-pack torrent's right episode can be
        # identified before requesting a download link — file_id=0 (the
        # old behaviour) falls out naturally below if this lookup fails
        # or the torrent only has one file anyway.
        file_id = 0
        try:
            rf = s.get(TB_BASE + '/torrents/mylist',
                       params={'token': _tb_key(), 'id': torrent_id, 'bypass_cache': True},
                       headers=_tb_auth(), timeout=15)
            if rf.status_code == 200:
                fdata = rf.json()
                if fdata.get('success'):
                    files = (fdata.get('data') or {}).get('files', [])
                    videos = [f for f in files
                              if (f.get('name') or f.get('short_name') or '').lower().endswith(_VIDEO_EXTS)]
                    if not videos:
                        videos = files
                    videos = _filter_by_episode(
                        videos, season, episode,
                        lambda f: f.get('name') or f.get('short_name') or '')
                    if videos:
                        biggest = max(videos, key=lambda f: f.get('size', 0))
                        if biggest.get('id') is not None:
                            file_id = biggest['id']
        except Exception as e:
            xbmc.log('[Starfleet/Debrid] TB file list error: %s' % e, xbmc.LOGWARNING)

        # Request DL link
        r2 = s.get(TB_BASE + '/torrents/requestdl',
                   params={'token': _tb_key(), 'torrent_id': torrent_id,
                           'file_id': file_id, 'zip': False},
                   headers=_tb_auth(), timeout=15)
        if r2.status_code == 200:
            data2 = r2.json()
            if data2.get('success'):
                stream = data2.get('data', '')
                if isinstance(stream, str) and stream:
                    xbmc.log('[Starfleet/Debrid] TB stream: %s' % stream[:60], xbmc.LOGINFO)
                    return stream
    except Exception as e:
        xbmc.log('[Starfleet/Debrid] TB magnet error: %s' % e, xbmc.LOGERROR)
    return ''


# ── NZB/Usenet flow (Premiumize + TorBox only) ────────────────────────────────
#
# Real-Debrid and AllDebrid have no Usenet/NZB support at all (confirmed
# live, both APIs are torrent/hoster-only) — only Premiumize and TorBox do.
# search_nzb_streams() below is the actual gate: it returns [] immediately
# unless at least one of those two is enabled, so nzb_sources.py never even
# gets queried for nothing, matching the same "don't do work nobody can use"
# principle as every other conditional source in this file.

def _pm_nzb_to_stream(nzb_url, progress_cb=None, title='', media_type='movie', season=None, episode=None):
    """Premiumize: upload the actual .nzb file content and poll until it's
    fetched from Usenet, then return the biggest MATCHING video file's link.

    title/media_type/season/episode exist purely to filter the resulting
    folder's contents down to files that actually match what was searched
    for - confirmed live 2026-08-07 this is NOT optional: Premiumize dumps
    every NZB upload's output files into ONE SHARED destination folder in
    the account, not an isolated per-transfer folder. A real run searching
    "Lioness S03E01" correctly found and resolved the right NZB, but
    "pick the biggest video file in the folder" then grabbed a completely
    unrelated 4.83GB "The Death of Robin Hood" file left over from an
    earlier, different test transfer that happened to still be sitting in
    that same shared folder (bigger than the correct 3.26GB Lioness file
    that was ALSO right there). Filtering by the same title/episode
    precision check torrent_sources.py already uses everywhere else
    (matched against each file's own name, e.g. "Lioness S03E01 The
    Spider And The Fly.mkv") is required before picking "biggest", not
    just a nice-to-have.

    NOT the same shape as pm_magnet_to_stream's directdl call, despite the
    docstring this replaced claiming otherwise — confirmed live 2026-08-06
    that /transfer/directdl with src=<binsearch action URL> is REJECTED
    outright ({"status":"error","message":"Unsupported link for direct
    download.","code":"service_unsupported"}), even though the exact same
    URL, fetched directly, serves a perfectly valid .nzb file (confirmed:
    real Content-Type: application/x-nzb, well-formed XML). Premiumize's
    URL-based source detection apparently can't recognize a dynamically-
    generated action URL (Binsearch's /nzb?q=...&id=on form-style link,
    NZBGeek/NZBPlanet's Newznab API links) as a valid NZB source by its
    shape alone.

    The fix, also verified live end-to-end against a real 2.9GB episode:
    fetch the actual .nzb bytes ourselves, then POST them as a multipart
    file upload to /transfer/create (which DOES recognize the content
    correctly - confirmed live: {"status":"success",...,"type":"nzb"}).
    Unlike magnet caching (an instant check against RD/AD/PM/TB's shared
    cache of already-downloaded torrents), Premiumize appears to have NO
    shared cache for Usenet content - confirmed live this is a genuine,
    real-time download from Usenet servers on Premiumize's own end, taking
    over a minute for a ~3GB file (watched /transfer/list's own progress
    message climb from megabytes to gigabytes in real time). This is why
    the old one-shot directdl-style call could never have worked correctly
    even if the URL format issue weren't there - there's no instant result
    to get back. Callers MUST expect a real, potentially multi-minute
    wait here, same as a first-time real torrent download, not the
    near-instant response magnet resolution usually gets."""
    if not _pm_on():
        return ''
    try:
        s = _sess()
        if not s:
            return ''

        if progress_cb and not progress_cb('Downloading .nzb file…', 2):
            return ''
        r0 = s.get(nzb_url, timeout=30)
        if r0.status_code != 200 or not r0.content:
            xbmc.log('[Starfleet/Debrid] PM NZB: could not fetch .nzb content (HTTP %s)' %
                     r0.status_code, xbmc.LOGWARNING)
            return ''

        if progress_cb and not progress_cb('Starting Premiumize transfer…', 5):
            return ''
        r = s.post(PM_BASE + '/transfer/create',
                   data={'apikey': _pm_key()},
                   files={'file': ('starfleet.nzb', r0.content, 'application/x-nzb')},
                   timeout=30)
        if r.status_code != 200:
            return ''
        data = r.json()
        if data.get('status') != 'success':
            _msg = data.get('message', '')
            if 'already added' in _msg.lower():
                # Premiumize rejects a second upload of byte-identical .nzb
                # content outright (confirmed live re-testing the same
                # release twice in one session). The file this originally
                # produced should still exist somewhere in the account, but
                # transfer records don't expose enough to reliably find it
                # back (no stored nzb_url/hash to match against) without
                # risking the exact "grabbed the wrong file" bug this
                # function was just rewritten to fix - reporting clearly
                # here instead of guessing again.
                xbmc.log('[Starfleet/Debrid] PM NZB: already submitted previously - '
                         'not re-resolvable without risking a file mismatch', xbmc.LOGWARNING)
            else:
                xbmc.log('[Starfleet/Debrid] PM NZB transfer/create error: %s' % _msg, xbmc.LOGWARNING)
            return ''
        transfer_id = data.get('id', '')
        if not transfer_id:
            return ''

        # Poll /transfer/list - real Usenet fetch, not an instant cache
        # check, so this can genuinely take minutes (confirmed live: over
        # 50 minutes for a real 9.9GB 4K release) for a large file. Capped
        # at 60 minutes as a sane outer bound.
        #
        # Cancel responsiveness is deliberately decoupled from how often
        # the real API gets hit: checking progress_cb only once per 10s API
        # poll (the first version of this loop) meant clicking Cancel could
        # sit unacknowledged for up to 10s plus whatever the in-flight
        # request itself was still waiting on - confirmed live as a real
        # "Cancel doesn't work" report on a long download. progress_cb is
        # now checked every 1s (cheap, no network call) using the last
        # known status, while the actual Premiumize poll still only runs
        # every ~10s so it doesn't hammer their API.
        last_pct = 10
        last_message = 'Downloading on Premiumize…'
        next_api_poll = 0.0
        deadline = time.time() + 60 * 60
        while time.time() < deadline:
            if progress_cb and not progress_cb(last_message, last_pct):
                # Best-effort cleanup of the abandoned transfer so it
                # doesn't keep consuming the user's Premiumize quota/slot.
                try:
                    s.post(PM_BASE + '/transfer/delete',
                           data={'apikey': _pm_key(), 'id': transfer_id}, timeout=10)
                except Exception:
                    pass
                return ''
            now = time.time()
            if now < next_api_poll:
                time.sleep(1)
                continue
            next_api_poll = now + 10

            rl = s.get(PM_BASE + '/transfer/list', params={'apikey': _pm_key()}, timeout=15)
            if rl.status_code != 200:
                continue
            ldata = rl.json()
            match = next((t for t in ldata.get('transfers', []) if t.get('id') == transfer_id), None)
            if not match:
                continue
            status = match.get('status', '')
            if status == 'finished':
                folder_id = match.get('folder_id', '')
                if not folder_id:
                    return ''
                if progress_cb and not progress_cb('Fetching stream link…', 95):
                    return ''
                rf = s.get(PM_BASE + '/folder/list', params={'apikey': _pm_key(), 'id': folder_id}, timeout=20)
                if rf.status_code != 200:
                    return ''
                fdata = rf.json()
                content = [c for c in fdata.get('content', []) if c.get('type') == 'file']
                videos = [c for c in content if (c.get('name', '') or '').lower().endswith(_VIDEO_EXTS)]
                # Shared-folder problem (see docstring): filter to files
                # that actually match what was searched for before ranking
                # by size - unmatched, leftover files from other transfers
                # can easily be bigger than the correct one. No title to
                # match against (shouldn't happen from a real caller) is
                # the only case that still falls back to plain "biggest".
                if title and videos:
                    try:
                        from resources.lib import torrent_sources as _tsrc
                        matched = _tsrc.filter_by_title_and_episode(
                            videos, title, media_type=media_type, season=season, episode=episode,
                            key='name', log_tag='NZB-PM-folder')
                    except Exception as e:
                        xbmc.log('[Starfleet/Debrid] PM NZB folder title-filter error: %s' % e, xbmc.LOGWARNING)
                        matched = videos
                    if not matched:
                        xbmc.log('[Starfleet/Debrid] PM NZB: no file in shared folder matched "%s" - '
                                 'refusing to guess' % title, xbmc.LOGWARNING)
                        return ''
                    videos = matched
                if videos:
                    biggest = max(videos, key=lambda c: c.get('size', 0))
                    stream = biggest.get('link') or biggest.get('directlink', '')
                    if stream:
                        xbmc.log('[Starfleet/Debrid] PM NZB stream: %s (%s)' %
                                 (stream[:60], biggest.get('name', '')), xbmc.LOGINFO)
                        return stream
                return ''
            if status in ('error', 'deleted', 'banned'):
                xbmc.log('[Starfleet/Debrid] PM NZB transfer failed: status=%s message=%s' %
                         (status, match.get('message', '')), xbmc.LOGWARNING)
                return ''
            # Surface Premiumize's own progress message (e.g. "File 1 of 1:
            # 1.2 GB of 2.9 GB uploaded") so the user sees real download
            # progress, not a frozen-looking dialog for several minutes.
            # Cached into last_pct/last_message so the per-second cancel
            # check above keeps showing it between real API polls too.
            last_pct = max(last_pct, 10 + int((match.get('progress') or 0) * 80))
            last_message = match.get('message') or 'Downloading on Premiumize…'
        return ''
    except Exception as e:
        xbmc.log('[Starfleet/Debrid] PM NZB error: %s' % e, xbmc.LOGWARNING)
    return ''


def _tb_check_cache_nzb(nzb_url):
    """Return True if TorBox has this NZB cached. TorBox's usenet cache
    check has no separate 'give me the source' step the way torrents do
    (an info_hash the tracker already assigns) — its own docs say to hash
    whatever link/file you're about to submit with plain MD5 first, so
    that's exactly what this does before calling the same checkcached
    endpoint shape as the torrent flow, just under /usenet/ instead of
    /torrents/."""
    if not nzb_url or not _tb_on():
        return False
    try:
        import hashlib
        nzb_hash = hashlib.md5(nzb_url.encode('utf-8')).hexdigest()
        s = _sess()
        if not s:
            return False
        r = s.get(TB_BASE + '/usenet/checkcached',
                  params={'hash': nzb_hash, 'format': 'object'},
                  headers=_tb_auth(), timeout=10)
        if r.status_code == 200:
            data = r.json()
            if data.get('success'):
                return bool(data.get('data'))
    except Exception as e:
        xbmc.log('[Starfleet/Debrid] TB NZB cache check error: %s' % e, xbmc.LOGWARNING)
    return False


def _tb_nzb_to_stream(nzb_url):
    """TorBox: create usenet download → request DL link. Same 3-step shape
    as tb_magnet_to_stream, using the /usenet/ endpoint family instead of
    /torrents/."""
    if not _tb_on():
        return ''
    if not _tb_check_cache_nzb(nzb_url):
        return ''
    try:
        s = _sess()
        if not s:
            return ''

        r = s.post(TB_BASE + '/usenet/createusenetdownload',
                   data={'link': nzb_url}, headers=_tb_auth(), timeout=20)
        if r.status_code not in (200, 201):
            return ''
        data = r.json()
        if not data.get('success'):
            return ''
        usenet_id = data.get('data', {}).get('usenet_download_id', '')
        if not usenet_id:
            return ''

        r2 = s.get(TB_BASE + '/usenet/requestdl',
                   params={'token': _tb_key(), 'usenet_id': usenet_id, 'file_id': 0},
                   headers=_tb_auth(), timeout=15)
        if r2.status_code == 200:
            data2 = r2.json()
            if data2.get('success'):
                stream = data2.get('data', '')
                if isinstance(stream, str) and stream:
                    xbmc.log('[Starfleet/Debrid] TB NZB stream: %s' % stream[:60], xbmc.LOGINFO)
                    return stream
    except Exception as e:
        xbmc.log('[Starfleet/Debrid] TB NZB error: %s' % e, xbmc.LOGWARNING)
    return ''


def resolve_nzb(nzb_url, progress_cb=None, title='', media_type='movie', season=None, episode=None):
    """Try Premiumize then TorBox for a stream from this NZB URL. Returns ''
    if neither is enabled or neither can get it — there's no Elementum-style
    fallback for Usenet (no P2P swarm to fall back to), so an empty result
    here just means this specific release isn't playable right now, same as
    an uncached torrent with no debrid enabled.

    progress_cb(message, percent) -> bool, same contract as the magnet
    resolution path's callback (return False to cancel) - unlike magnets,
    Premiumize's NZB fetch is a real, multi-minute Usenet download with no
    instant-cache shortcut (confirmed live), so this can take a while and
    callers should show real progress, not a plain blocking wait.

    title/media_type/season/episode are required for Premiumize specifically
    (see _pm_nzb_to_stream's own docstring) - its NZB uploads all land in
    one shared account folder, so picking the right file back out needs a
    real title/episode match, not just "biggest file", or a completely
    unrelated leftover from a different search can get played instead
    (confirmed live)."""
    if not nzb_url:
        return ''
    if _pm_on():
        stream = _pm_nzb_to_stream(nzb_url, progress_cb=progress_cb, title=title,
                                    media_type=media_type, season=season, episode=episode)
        if stream:
            return stream
    if _tb_on():
        stream = _tb_nzb_to_stream(nzb_url)
        if stream:
            return stream
    return ''


def search_nzb_streams(title, year=None, media_type='movie', limit=10, season=None, episode=None):
    """Search Usenet (binsearch.info) for title and return raw candidate
    entries, same deferred-resolution shape as get_debrid_streams()'s
    torrent results: [{'label', 'url', 'is_nzb': True}] — url is a real
    .nzb download link, actual debrid resolution happens later, only for
    whichever ONE the user picks (via resolve_nzb(), called from
    metadata_router.py's selection handler the same way resolve_magnet()
    already is for torrents).

    Gated on Premiumize or TorBox being enabled — Real-Debrid and
    AllDebrid have no Usenet support at all, so searching NZB sources when
    neither PM nor TB is on would only ever produce results nothing could
    ever play."""
    xbmc.log('[Starfleet/NZB] search_nzb_streams entered: title=%r pm_on=%s tb_on=%s' %
             (title, _pm_on(), _tb_on()), xbmc.LOGINFO)
    if not (_pm_on() or _tb_on()):
        return []
    try:
        from resources.lib import nzb_sources as _nzb
    except Exception:
        return []

    candidates = []
    try:
        candidates += _nzb.search_binsearch_nzb(title, year=year, limit=limit, media_type=media_type)
    except Exception as e:
        xbmc.log('[Starfleet/Debrid] Binsearch NZB search error: %s' % e, xbmc.LOGWARNING)
    try:
        candidates += _nzb.search_nzbindex_nzb(title, year=year, limit=limit, media_type=media_type)
    except Exception as e:
        xbmc.log('[Starfleet/Debrid] NZBIndex search error: %s' % e, xbmc.LOGWARNING)
    try:
        candidates += _nzb.search_nzbking_nzb(title, year=year, limit=limit, media_type=media_type)
    except Exception as e:
        xbmc.log('[Starfleet/Debrid] NZBKing search error: %s' % e, xbmc.LOGWARNING)

    # NZBGeek/NZBPlanet are each their own no-op unless the user has
    # entered their own account's API key in Settings (see nzb_sources.py)
    # — safe to always attempt, costs nothing when not configured.
    try:
        candidates += _nzb.search_nzbgeek(title, year=year, limit=limit, media_type=media_type)
    except Exception as e:
        xbmc.log('[Starfleet/Debrid] NZBGeek search error: %s' % e, xbmc.LOGWARNING)
    try:
        candidates += _nzb.search_nzbplanet(title, year=year, limit=limit, media_type=media_type)
    except Exception as e:
        xbmc.log('[Starfleet/Debrid] NZBPlanet search error: %s' % e, xbmc.LOGWARNING)

    # Binsearch/Newznab search is a loose multi-word match, not an exact
    # title match — confirmed live: searching "Found S01E03" returned
    # "Virgin River S01E03", "Happy Tree Friends S01E03", "Eyes of Wakanda
    # S01E03" mixed in with real "Found" results, because those titles
    # happen to also contain an S01E03 marker (and in one case the literal
    # word "found" elsewhere in an unrelated compound title). Torrent
    # sources already reject exactly this kind of false positive via
    # torrent_sources.filter_by_title_and_episode() — NZB candidates never
    # went through it at all until now.
    try:
        from resources.lib import torrent_sources as _tsrc
        before = len(candidates)
        candidates = _tsrc.filter_by_title_and_episode(
            candidates, title, media_type=media_type, season=season, episode=episode,
            key='title', log_tag='NZB')
        if len(candidates) != before:
            xbmc.log('[Starfleet/Debrid] NZB title/episode filter: %d -> %d candidates' %
                     (before, len(candidates)), xbmc.LOGINFO)
    except Exception as e:
        xbmc.log('[Starfleet/Debrid] NZB title filter error: %s' % e, xbmc.LOGWARNING)

    results = []
    for c in candidates:
        # Must include the real release title, not just source+size - the
        # picker's quality sort/filter (metadata_router._sort_by_quality)
        # regex-scans the label text itself for 2160p/1080p/WEB-DL/etc, and
        # a release's own title is where that tag actually lives (e.g.
        # "Movie.2023.1080p.WEB-DL.x264-GROUP"); a label built from just
        # "[NZB] Binsearch 2.3GB" has no such text anywhere in it, so every
        # NZB result silently ranked as "no quality detected" regardless of
        # what it actually was.
        label = '[NZB] %s (%s, %s)' % (c.get('title', 'Unknown'), c.get('source', 'Usenet'), c.get('size', ''))
        results.append({'label': label.strip(), 'url': c.get('nzb_url', ''), 'is_nzb': True})
    return results


# ── Public: search torrents + resolve via debrid ──────────────────────────────

def get_debrid_streams(title, year=None, media_type='movie', imdb_id=None,
                       season=None, episode=None, tmdb_id=None):
    """
    Search torrent sources for title, check debrid caches, and return
    a list of playable stream dicts:
      [{'label': 'Debrid 1 (RD - YTS 1080p)', 'url': 'https://...', 'info_hash': '...'}]

    Only cached/instant results are included — no downloads are started.
    """
    from resources.lib import torrent_sources as _ts

    # Check the user's OWN already-finished AllDebrid/Premiumize libraries
    # before doing a live torrent search at all — see
    # _ad_resolve_from_library's/_pm_resolve_from_library's own docstrings
    # for why. Cheap (a couple of HTTP calls, no upload/poll wait), so this
    # always runs first regardless of what the live search below finds.
    # Both run — a title already saved to either service's cloud is
    # instant either way, no reason to prefer one over the other here.
    library_results = (_ad_resolve_from_library(title, season=season, episode=episode) +
                        _pm_resolve_from_library(title, season=season, episode=episode))

    # If no IMDB ID, try Cinemeta for a fast lookup — enables Torrentio (most reliable source)
    if not imdb_id and title and media_type != 'adult':
        try:
            from urllib.parse import quote as _cq
            _ctype = 'series' if media_type == 'tv' else 'movie'
            _cm = _ts._get_json(
                'https://v3-cinemeta.strem.io/catalog/%s/top/search=%s.json' % (_ctype, _cq(title)),
                timeout=5
            )
            if _cm:
                for _m in (_cm.get('metas') or []):
                    _mid = _m.get('id', '')
                    if _mid.startswith('tt'):
                        imdb_id = _mid
                        xbmc.log('[Starfleet/Debrid] Cinemeta: "%s" → %s' % (title, imdb_id), xbmc.LOGINFO)
                        break
        except Exception as _ce:
            xbmc.log('[Starfleet/Debrid] Cinemeta lookup failed: %s' % _ce, xbmc.LOGWARNING)

    # max_per_source was capped at 5 back when every result found here got
    # pre-resolved through a debrid poll before the picker could show (more
    # candidates meant a slower search). Now that resolution is deferred to
    # selection time (see below), showing many more raw torrent options
    # costs nothing extra, so raised to pull a much fuller list per source.
    torrents = _ts.search_all(title, year, media_type, max_per_source=40,
                              imdb_id=imdb_id, season=season, episode=episode)

    # Cumulative weekly/daily magnet-library hits (Knaben/EZTV, scraped by
    # the standalone orchestrator). Movie/TV: exact tmdb_id lookup. Adult:
    # fuzzy clean-title match only, deliberately never an id — this addon's
    # own Adult section mixes multiple incompatible id namespaces (ADE vs
    # AFDB vs free-stream stubs), so trusting whichever id a given adult
    # call site happens to have on hand risks silently showing a different
    # title's magnets entirely; a title match can only under-match, never
    # mismatch. Merged in alongside the live search rather than replacing
    # it; duplicate info_hashes across both are harmless here since
    # resolve_magnet_candidates already dedupes by info_hash at selection time.
    if tmdb_id or media_type == 'adult':
        try:
            from resources.lib import magnet_library as _mlib
            library_magnets = _mlib.get_cached_magnets(media_type, tmdb_id=tmdb_id, title=title,
                                                        season=season, episode=episode)
            if library_magnets:
                xbmc.log('[Starfleet/Debrid] %d magnet(s) from cumulative library for "%s"' %
                         (len(library_magnets), title), xbmc.LOGINFO)
                torrents = (torrents or []) + library_magnets
        except Exception as e:
            xbmc.log('[Starfleet/Debrid] magnet_library error: %s' % e, xbmc.LOGWARNING)

    if not torrents:
        if library_results:
            xbmc.log('[Starfleet/Debrid] 0 live torrents found for "%s" — using %d from own AllDebrid/Premiumize library' %
                     (title, len(library_results)), xbmc.LOGINFO)
            return library_results
        xbmc.log('[Starfleet/Debrid] 0 torrents found for "%s"' % title, xbmc.LOGWARNING)
        return []

    # Filter out fake/non-video torrents by checking only the dn= display name,
    # not the full magnet (which would false-positive on tracker .com domains).
    # NOTE: 'com' deliberately excluded from this list — many legitimate uploaders
    # embed a site tag like "www.SomeTracker.com" in the display name, which would
    # otherwise false-positive a real video release as "fake" and silently drop it.
    _BAD_EXT = re.compile(r'\.(?:exe|zip|rar|bat|msi|dmg|apk|iso|7z|tar|gz)\b', re.IGNORECASE)
    def _is_fake(magnet):
        try:
            import urllib.parse as _ul
            dn = _ul.parse_qs(_ul.urlparse(magnet).query).get('dn', [''])[0]
        except Exception:
            dn = magnet
        return bool(_BAD_EXT.search(dn))
    torrents = [t for t in torrents if not _is_fake(t.get('magnet', ''))]
    if not torrents:
        xbmc.log('[Starfleet/Debrid] all torrents filtered as fake/non-video for "%s"' % title, xbmc.LOGWARNING)
        return []

    # For adult searches, filter out TV episode results (S01E01 naming pattern)
    if media_type == 'adult':
        import urllib.parse as _ul2
        _TV_EP = re.compile(r'\bS\d{1,2}E\d{1,2}\b', re.IGNORECASE)
        def _is_tv_ep(magnet):
            try:
                dn = _ul2.parse_qs(_ul2.urlparse(magnet).query).get('dn', [''])[0]
            except Exception:
                dn = magnet
            return bool(_TV_EP.search(dn))
        pre = len(torrents)
        torrents = [t for t in torrents if not _is_tv_ep(t.get('magnet', ''))]
        if pre != len(torrents):
            xbmc.log('[Starfleet/Debrid] adult filter: removed %d TV episode results' % (pre - len(torrents)), xbmc.LOGINFO)

    xbmc.log('[Starfleet/Debrid] %d torrents found for "%s"' % (len(torrents), title), xbmc.LOGINFO)

    # Return raw torrent/magnet entries immediately instead of pre-resolving
    # every candidate through RD/AD/PM/TB here. That pre-resolve batch (up
    # to 10 candidates, 5 workers, each service allowed up to ~90s to poll
    # for real caching) used to gate the WHOLE picker behind a wait that
    # confirmed live at ~100-108s almost every run — regardless of whether
    # services were tried in series or raced concurrently — because with
    # 10 live-found candidates, at least one is virtually always genuinely
    # uncached, and the batch waited close to its own ceiling every time,
    # even though personal/free/embed had already settled in under 2s.
    #
    # Real debrid resolution still happens — just deferred to the moment
    # the user actually picks a torrent from the list, via
    # resolvers.resolve_magnet() (already wired into metadata_router.py's
    # selection handling for any magnet: url), which shows its own
    # progress dialog with a cancel option and falls back to Elementum if
    # nothing's cached. This means the picker shows as fast as the torrent
    # search itself (~8-10s), and only the ONE torrent actually chosen
    # ever pays a debrid poll wait, not all 10 found candidates up front.
    #
    # Not truncated tighter than this: torrent_sources.search_all() sorts
    # its combined list by SEED COUNT, and a 4K release is a much bigger
    # file than a 1080p/720p one of the same title, so it almost always
    # has far fewer seeders — confirmed live, real 4K results from
    # Torrentio/LimeTorrents/Knaben were getting cut here before they ever
    # reached the picker, buried under a much larger number of smaller,
    # higher-seeded releases from the other dozen sources combined. A cap
    # this high (200) only exists as a sane upper bound against a truly
    # pathological result count, not as a meaningful quality filter — this
    # step no longer costs anything since nothing here gets resolved
    # through debrid until the user actually picks one.
    results = []
    for i, torrent in enumerate(torrents[:200], 1):
        magnet = torrent.get('magnet', '')
        if not magnet:
            continue
        quality = torrent.get('quality', '')
        source  = torrent.get('source', '')
        # Seed count appended — without it, every torrent sharing the same
        # source+quality (e.g. several different Torrentio 4K releases)
        # rendered as an IDENTICAL row in the picker, confirmed live as
        # part of a real "shows fewer results" report: a list padded with
        # visually-duplicate entries reads as less choice even when the
        # underlying torrents (and info_hash) are genuinely different.
        # Seeds is the one field search_all()'s sources all populate
        # consistently and is also the most useful thing to differentiate
        # on, so no extra lookup needed beyond what's already on hand.
        seeds = torrent.get('seeds') or 0
        seed_suffix = ' ↑%d' % seeds if seeds else ''
        label = '[Torrent] %s%s' % (
            (('%s %s' % (source, quality)).strip() or 'Torrent %d' % i), seed_suffix)
        results.append({'label': label, 'url': magnet, 'info_hash': torrent.get('info_hash', ''),
                        'quality': quality})

    # NZB candidates — search_nzb_streams() is itself gated on Premiumize
    # or TorBox being enabled, so this is a no-op call (returns []
    # instantly) for everyone else rather than an extra unconditional
    # network round-trip every search pays for nothing.
    nzb_results = []
    try:
        nzb_results = search_nzb_streams(title, year=year, media_type=media_type,
                                          season=season, episode=episode)
    except Exception as e:
        xbmc.log('[Starfleet/Debrid] search_nzb_streams error: %s' % e, xbmc.LOGWARNING)

    # Already-finished matches from the user's own AllDebrid/Premiumize
    # library go first — they need zero upload/poll wait at all, so
    # they're both the fastest and the most certain option in the picker.
    return library_results + results + nzb_results
