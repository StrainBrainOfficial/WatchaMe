# -*- coding: utf-8 -*-
"""
resources/lib/pornkino_sources.py

pornkino.cc adult source — same role as myporn_sources.search_myporn_club():
one more parallel candidate feed into the existing Adult play/search
pipeline, not a separate browsable section.

Site structure (confirmed live 2026-08-28):
  - Real WordPress search: /?s=<query> accepts a full multi-word query
    (unlike myporn.club's /s/<word>, which is really a single-word tag
    browse) and returns real, relevant results with working pagination.
  - Listing/search-result pages parse via plain requests fine (200 OK,
    no Cloudflare/bot-check hit) — the detail (post) pages are a
    different story: confirmed live these hang/timeout under a plain
    requests.get() even at 20-25s, on every post tried, while the exact
    same URL loads fine and fast under cloudscraper (and in a real
    browser). Detail-page fetches in this module always go through
    cloudscraper as a result — plain requests is not attempted there.
  - Each post's actual embed hosts (DoodStream, LuluStream, MixDrop, VOE
    confirmed live) sit in the server-rendered HTML as
    '<a title="... - on <Host>" href="<embed_url>" rel="nofollow"
    id="#iframe">' — the href here is the real per-mirror embed URL
    (e.g. doply.net/e/<code> for DoodStream, luluvid.com/e/<code> for
    LuluStream) already usable by ResolveURL directly, distinct from the
    data-fl-url attribute on the same element (that one is the host's
    OWN canonical domain, used by the page's own client-side dead-link
    checker, not meant for playback). Download-host links (NitroFlare/
    FreeDL/Rapidgator, also present on every post) are file downloads,
    not streamable embeds — not collected here, same scope decision
    myporn_sources.py already makes for magnet links it can't stream.
"""

import re
import html as _html
import urllib.parse as _uparse
from concurrent.futures import ThreadPoolExecutor, as_completed

import xbmc

try:
    from resources.lib.title_utils import clean_adult_title as _clean_adult_title
except Exception:
    def _clean_adult_title(t):
        return t

PK_BASE = 'https://pornkino.cc'

_HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
                  '(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9',
}

_RE_PK_ITEM = re.compile(
    r'<a class="thumb poster-thumb" href="([^"]+)">.*?'
    r'data-src="([^"]+)".*?'
    r'<span class="duration">([^<]*)</span>.*?'
    r'<a class="infos" href="[^"]+" title="([^"]+)">',
    re.S)

_RE_PK_EMBED = re.compile(
    r'<a title="[^"]*- on ([^"]+)" href="(https?://[^"]+)" rel="nofollow" id="#iframe">')

_cf_session = None


def _get_cf_session():
    """Return a Cloudflare/bot-check-bypass session (cloudscraper) if
    available, else None. Lazily created — same pattern as
    torrent_sources._get_cf_session()."""
    global _cf_session
    if _cf_session is not None:
        return _cf_session
    try:
        import cloudscraper as _cs
        _cf_session = _cs.create_scraper(
            browser={'browser': 'chrome', 'platform': 'windows', 'mobile': False}
        )
        xbmc.log('[Starfleet/PornKino] cloudscraper loaded', xbmc.LOGINFO)
        return _cf_session
    except Exception as e:
        xbmc.log('[Starfleet/PornKino] cloudscraper init failed: %s' % e, xbmc.LOGWARNING)
    return None


def _get(url, timeout=12):
    """Listing/search pages work fine under plain requests (confirmed
    live) but always try cloudscraper first anyway since it's a strict
    superset and this module's other fetches (detail pages) require it —
    one code path, no need to special-case which kind of page a URL is."""
    cs = _get_cf_session()
    if cs:
        try:
            r = cs.get(url, headers=_HEADERS, timeout=timeout)
            r.raise_for_status()
            return r.text
        except Exception as e:
            xbmc.log('[Starfleet/PornKino] cloudscraper GET failed (%s): %s' %
                      (url[:70], e), xbmc.LOGWARNING)
    try:
        import requests
        r = requests.get(url, headers=_HEADERS, timeout=timeout)
        r.raise_for_status()
        return r.text
    except Exception as e:
        xbmc.log('[Starfleet/PornKino] GET failed (%s): %s' % (url[:70], e), xbmc.LOGWARNING)
        return ''


def _parse_listing(html_text):
    out = []
    for url, thumb, duration, raw_title in _RE_PK_ITEM.findall(html_text):
        out.append({
            'url': url,
            'thumb': thumb,
            'duration': duration.strip(),
            'title': _html.unescape(raw_title).strip(),
        })
    return out


def _fetch_embeds(post_url):
    """Fetch one post's detail page (cloudscraper required — see module
    docstring) and return its [(host, embed_url), ...] list."""
    html_text = _get(post_url)
    if not html_text:
        return []
    return _RE_PK_EMBED.findall(html_text)


def search_pornkino(title, year=None, limit=8, media_type='adult'):
    """Adult stream search — same {'label','url'} shape as
    myporn_sources.search_myporn_club(), consumed the same way by the
    existing Adult play pipeline's stream picker (embed/hoster URLs
    resolved via ResolveURL).

    Unlike myporn.club, pornkino.cc's /?s=<query> is a real multi-word
    WordPress search — the full title is used as-is, no single-word
    reduction needed. Each matching post needs its own detail-page fetch
    to find its embed links (unlike myporn.club, which embeds them right
    in the listing), so candidate posts are fetched concurrently."""
    if media_type != 'adult':
        return []
    query = _clean_adult_title(title) or title
    if not query:
        return []

    try:
        url = '%s/?s=%s' % (PK_BASE, _uparse.quote_plus(query))
        html_text = _get(url)
        posts = _parse_listing(html_text)
    except Exception as e:
        xbmc.log('[Starfleet/PornKino] search "%s" error: %s' % (query, e), xbmc.LOGWARNING)
        return []
    if not posts:
        return []

    candidates = posts[:max(limit, 8)]
    results = []
    with ThreadPoolExecutor(max_workers=6) as ex:
        futures = {ex.submit(_fetch_embeds, p['url']): p for p in candidates}
        for fut in as_completed(futures):
            post = futures[fut]
            try:
                embeds = fut.result()
            except Exception as e:
                xbmc.log('[Starfleet/PornKino] embed fetch error (%s): %s' %
                          (post['url'][:70], e), xbmc.LOGWARNING)
                continue
            for host, embed_url in embeds:
                results.append({
                    'label': '[PornKino] %s - %s' % (post['title'], host),
                    'url': embed_url,
                })

    return results[:limit]
