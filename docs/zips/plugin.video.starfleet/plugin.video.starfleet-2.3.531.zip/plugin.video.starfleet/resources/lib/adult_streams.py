﻿# -*- coding: utf-8 -*-
"""
resources/lib/adult_streams.py — Adult streaming scrapers

Sources:
  freeomovie.to      — WordPress blog. Film list on homepage/pages.
                       Stream URLs in var TABS = [...] in page <script>.
  xxxmoviestream.org — DooPlay WordPress theme. Films under /movies/.
                       Stream URLs in data-fl-url="..." attributes.
  pornwatch.ws       — DooPlay theme. Film cards use data-movie-id + oldtitle.
                       Stream URLs in data-fl-url="..." on detail pages.
  watchpornfree.info — TPostMv theme. Film cards in <li class="TPostMv">.
                       Stream URLs in data-fl-url="..." on detail pages.
  speedporn.net      — Slug-number URLs. Stream URLs in data-fl-url="...".

Each scraper returns a list of film dicts:
  { 'id', 'title', 'title_norm', 'thumb', 'description', 'url',
    'source', 'streams': [{'label', 'url'}] }

get_all_streams() merges all sources and deduplicates by normalised title.
Merged films carry streams from all matching sources.
"""

import re
import json
import unicodedata
import html as _html_unescape
import xbmc
import xbmcaddon
import xbmcvfs

ADDON    = xbmcaddon.Addon('plugin.video.starfleet')
_PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
_CACHE_DB = _PROFILE + '/cache.db'

import requests
from resources.lib import cache as _cache
from resources.lib.title_utils import clean_adult_title as _clean_title
_cache.init(_CACHE_DB)

FREEO_BASE  = 'https://www.freeomovie.to'
XXXMS_BASE  = 'https://xxxmoviestream.org'
WPW_BASE    = 'https://pornwatch.ws'
ADP_BASE    = 'https://adultdvdparadise.org'
WPF_BASE    = 'https://watchpornfree.info'
SPN_BASE    = 'https://speedporn.net'
XXXSC_BASE  = 'https://xxxscenes.net'
XMOVIX_BASE = 'https://hd.xmovix.net'
PANDA_BASE  = 'https://pandamovies.org'
# Confirmed live 2026-08-15: pandamovies.pw is a literal mirror of
# pandamovies.org — identical WordPress backend, identical
# watch-*-movie-online-free slugs (e.g. watch-busted-my-stalker-watching-
# me-shower-movie-online-free exists verbatim on both domains). Not a
# separate site — used only as a fallback when the primary domain fails.
PANDA_BASE_MIRROR = 'https://pandamovies.pw'
HQPORN_BASE = 'https://hqporner.com'

# ── New site candidates (added 2026-08-15) ──────────────────────────────────
XMFY_BASE    = 'https://xmoviesforyou.com'
PNONE_BASE   = 'https://pornone.com'
TMOVS_BASE   = 'https://www.3movs.com'
PDIG_BASE    = 'https://www.porndig.com'
CUML_BASE    = 'https://www.cumlouder.com'
PHAT_BASE    = 'https://pornhat.com'
OKXXX_BASE   = 'https://ok.xxx'
JPORN_BASE   = 'https://www.justporn.com'
PGO_BASE     = 'https://www.porngo.com'
P00_BASE     = 'https://www.porn00.org'
APS_BASE     = 'https://allpornstream.com'
MANGO_BASE   = 'https://mangoporn.net'
SPVIP_BASE   = 'https://streamporn.vip'
SPF_BASE     = 'https://swingerpornfun.com'
PARADISE_BASE = 'https://en.paradisehill.cc'
PXP_BASE      = 'https://www.pelisxporno.net'

HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/126.0.0.0 Safari/537.36'
    ),
    'Accept': 'text/html,*/*;q=0.8',
}

_RE_STRIP_TAGS = re.compile(r'<[^>]+>')
_RE_WHITESPACE  = re.compile(r'\s+')

# ── HTTP session ──────────────────────────────────────────────────────────────

_session = None
_cf_session = None

def _sess():
    global _session
    if _session is None:
        _session = requests.Session()
        _session.headers.update(HEADERS)
        a = requests.adapters.HTTPAdapter(
            pool_connections=4, pool_maxsize=10,
            max_retries=requests.adapters.Retry(total=0)
        )
        _session.mount('https://', a)
        _session.mount('http://', a)
    return _session


def _cf_sess():
    """Cloudflare-bypass session for protected sites."""
    global _cf_session
    if _cf_session is None:
        try:
            import cloudscraper as _cs
            _cf_session = _cs.create_scraper(
                browser={'browser': 'chrome', 'platform': 'windows', 'mobile': False}
            )
            xbmc.log('[Starfleet/Streams] cloudscraper OK', xbmc.LOGINFO)
        except Exception as e:
            xbmc.log('[Starfleet/Streams] cloudscraper unavailable: %s' % e, xbmc.LOGWARNING)
            _cf_session = _sess()
    return _cf_session


def _get(url, timeout=(5, 8)):
    r = _sess().get(url, timeout=timeout)
    r.raise_for_status()
    return r.text


def _clean(text):
    text = _RE_STRIP_TAGS.sub(' ', text)
    return _RE_WHITESPACE.sub(' ', text).strip()


def _og(html, prop):
    """Extract og: meta property value."""
    m = re.search(
        r'<meta[^>]+property=["\']og:%s["\'][^>]+content=["\']([^"\']+)["\']' % re.escape(prop),
        html, re.IGNORECASE
    )
    if not m:
        m = re.search(
            r'<meta[^>]+content=["\']([^"\']+)["\'][^>]+property=["\']og:%s["\']' % re.escape(prop),
            html, re.IGNORECASE
        )
    return _clean(m.group(1)) if m else ''


# ── Title normalisation for deduplication ─────────────────────────────────────

_RE_NONALNUM = re.compile(r'[^a-z0-9 ]')

# Leet-speak character map used when matching ADE titles to scraper titles.
# Applied to both sides of the comparison so "Pl4y" matches "Play" etc.
_LEET_MAP = str.maketrans({'4': 'a', '3': 'e', '1': 'i', '0': 'o', '5': 's', '@': 'a', '!': 'i'})

def _norm_title(title):
    """Lowercase, strip accents and punctuation, collapse spaces."""
    title = title.lower()
    # Remove accents
    title = ''.join(
        c for c in unicodedata.normalize('NFD', title)
        if unicodedata.category(c) != 'Mn'
    )
    title = _RE_NONALNUM.sub('', title)
    return _RE_WHITESPACE.sub(' ', title).strip()

def _norm_title_leet(title):
    """Like _norm_title but also de-leeted so 'Pl4y' == 'Play'."""
    return _norm_title(title.translate(_LEET_MAP))


# ── freeomovie.to ──────────────────────────────────────────────────────────────

_RE_FREEO_LINKS = re.compile(
    r'href="(https?://(?:www\.)?freeomovie\.to/([a-z0-9][a-z0-9-]+)/)"',
    re.IGNORECASE
)
_FREEO_SKIP = {
    'page', 'category', 'tag', 'author', 'feed', 'wp-json',
    'contact-us', 'legal-notice', 'privacy-policy', 'about',
    'wp-content', 'wp-includes', 'sitemap',
}
_RE_FREEO_TABS = re.compile(r'var\s+TABS\s*=\s*(\[.*?\]);', re.DOTALL)
_RE_FREEO_TITLE = re.compile(
    r'<h1[^>]*>Watch\s+(.*?)\s+(?:free\s+online\s+porn|porn\s+movie|watch\s+online)',
    re.IGNORECASE
)


def _freeo_film_list(page=1):
    ck = 'fstreams_freeo_list_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    url = FREEO_BASE + ('/' if page == 1 else '/page/%d/' % page)
    try:
        html = _get(url)
        films = []
        seen  = set()
        for m in _RE_FREEO_LINKS.finditer(html):
            film_url, slug = m.group(1), m.group(2)
            if slug in _FREEO_SKIP or slug in seen:
                continue
            seen.add(slug)
            films.append({'slug': slug, 'url': film_url})
        _cache.set(ck, films, 6 * 3600)
        xbmc.log('[Starfleet/Streams] freeomovie page %d: %d films' % (page, len(films)), xbmc.LOGINFO)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/Streams] freeomovie list error: %s' % e, xbmc.LOGERROR)
        return []


def _freeo_film_detail(slug, film_url):
    ck = 'fstreams_freeo_detail_%s' % slug
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    try:
        html   = _get(film_url)

        # Title: try <h1> first, then og:title
        title = ''
        m = re.search(r'<h1[^>]*>([^<]+)</h1>', html, re.IGNORECASE)
        if m:
            raw = _clean(m.group(1))
            # Strip "Watch X free online porn" prefix/suffix
            raw = re.sub(r'^Watch\s+', '', raw, flags=re.IGNORECASE)
            raw = re.sub(r'\s+(?:free\s+online\s+porn|porn\s+movie.*|online\s+free.*)$', '',
                         raw, flags=re.IGNORECASE)
            title = raw.strip()
        if not title:
            title = _og(html, 'title')
            title = re.sub(r'\s*[|\-–].*$', '', title).strip()

        thumb = _og(html, 'image')
        if not thumb:
            # og:image is often simply absent (confirmed live) — the post
            # body itself embeds a real content image right after its own
            # "Cast:" line (a fastpic.org-hosted screenshot), used as a
            # fallback poster instead of leaving Full Library's poster
            # panel blank for these.
            mim = re.search(r'(https?://i\d+\.fastpic\.org/[^\s"\'<>]+\.\w{3,4})', html)
            if mim:
                thumb = mim.group(1)
        desc  = _og(html, 'description')

        # Cast — confirmed live 2026-08-28 (real user follow-up asking
        # whether freeomovie.to gets the same cast/poster treatment as
        # PandaMovies): the post body has a clean "<strong>Cast:</strong>
        # Name1, Name2, ..." line, unlike PandaMovies' free-text
        # "Starring:" parsing. No per-performer photo exists here either
        # (no cast profile pages/links), same no-photo fallback as every
        # other source without one.
        cast = []
        mc = re.search(r'<strong>Cast:</strong>\s*([^<]+)', html)
        if mc:
            for name in mc.group(1).split(','):
                name = name.strip()
                if name:
                    cast.append({'name': name, 'photo': ''})

        # Stream URLs from var TABS = [...]
        streams = []
        m = _RE_FREEO_TABS.search(html)
        if m:
            import json
            try:
                tabs = json.loads(m.group(1))
                for tab in tabs:
                    if tab.get('url') and tab.get('label'):
                        streams.append({'label': tab['label'], 'url': tab['url']})
            except (ValueError, KeyError):
                pass

        film = {
            'id':         'freeo_%s' % slug,
            'slug':       slug,
            'title':      _clean_title(title or slug.replace('-', ' ').title()),
            'title_norm': _norm_title(title or slug.replace('-', ' ')),
            'thumb':      thumb,
            'description': desc,
            'cast':       cast,
            'url':        film_url,
            'source':     'freeomovie',
            'streams':    streams,
        }
        _cache.set(ck, film, 24 * 3600)
        return film
    except Exception as e:
        xbmc.log('[Starfleet/Streams] freeomovie detail error (%s): %s' % (slug, e), xbmc.LOGERROR)
        return None


def get_freeo_films(page=1):
    """Return list of film dicts from freeomovie.to, page N."""
    from concurrent.futures import ThreadPoolExecutor
    stubs = _freeo_film_list(page)
    if not stubs:
        return []
    with ThreadPoolExecutor(max_workers=min(len(stubs), 6)) as p:
        results = list(p.map(lambda s: _freeo_film_detail(s['slug'], s['url']), stubs))
    return [d for d in results if d]


# ── xxxmoviestream.org ────────────────────────────────────────────────────────

_RE_XXXMS_CARD = re.compile(
    r'href="(https?://xxxmoviestream\.org/movies/([a-z0-9][a-z0-9-]+)/)"\s*>\s*<img',
    re.IGNORECASE
)
_RE_XXXMS_STREAMS = re.compile(
    r'data-fl-url="(https?://[^"]+)"',
    re.IGNORECASE
)
# Filter out obviously non-player stream URLs
_XXXMS_STREAM_SKIP = re.compile(
    r'(?:rapidgator|nitroflare|frdl\.io|uploaded|keep2share)',
    re.IGNORECASE
)

# Premium-locker hosts (rapidgator/nitroflare/frdl/uploaded/keep2share) —
# every site-specific *_STREAM_SKIP regex above/below matches this same
# family. These require a paid account to download directly, so they used
# to be unconditionally filtered out everywhere below — but Real-Debrid's
# (and AllDebrid's) own unrestrict API genuinely supports unlocking most of
# them directly, confirmed live: ResolveURL's realdebrid.py plugin declares
# domains=['*'], meaning it forwards ANY host straight to Real-Debrid's own
# API and lets THAT decide whether this specific host is supported, rather
# than this addon needing to hardcode a supported-host allowlist. So these
# links are only ever discarded when NO debrid service is paired at all —
# once one is, they're kept and handed to the normal ResolveURL resolve
# step exactly like every other stream link, and either really unlock or
# fail cleanly per-link the same way any other host already can.
_PREMIUM_LOCKER_RE = re.compile(
    r'(?:rapidgator|nitroflare|frdl\.(?:io|to)|uploaded|keep2share)',
    re.IGNORECASE
)


def _skip_locker_unless_debrid(url):
    if not _PREMIUM_LOCKER_RE.search(url):
        return False
    from resources.lib import resolvers as _resolvers
    return not _resolvers.any_debrid_enabled()


def _xxxms_film_list(page=1):
    ck = 'fstreams_xxxms_list_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    url = XXXMS_BASE + ('/movies/' if page == 1 else '/movies/page/%d/' % page)
    try:
        html = _get(url)
        films = []
        seen  = set()
        for m in _RE_XXXMS_CARD.finditer(html):
            film_url, slug = m.group(1), m.group(2)
            if slug not in seen:
                seen.add(slug)
                films.append({'slug': slug, 'url': film_url})
        _cache.set(ck, films, 6 * 3600)
        xbmc.log('[Starfleet/Streams] xxxmoviestream page %d: %d films' % (page, len(films)), xbmc.LOGINFO)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/Streams] xxxmoviestream list error: %s' % e, xbmc.LOGERROR)
        return []


def _xxxms_film_detail(slug, film_url):
    ck = 'fstreams_xxxms_detail_%s' % slug
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    try:
        html  = _get(film_url)

        title = ''
        m = re.search(r'<h1[^>]*>([^<]+)</h1>', html, re.IGNORECASE)
        if m:
            title = _clean(m.group(1))
        if not title:
            title = _og(html, 'title')
            title = re.sub(r'\s*[|\-–].*$', '', title).strip()

        thumb = _og(html, 'image')
        desc  = _og(html, 'description')

        # Stream URLs from data-fl-url="..." attributes
        seen_urls = set()
        streams   = []
        for m in _RE_XXXMS_STREAMS.finditer(html):
            stream_url = m.group(1)
            # Skip file hosters and duplicate/dynamic placeholder lines
            if _skip_locker_unless_debrid(stream_url):
                continue
            if 'deadUrl' in stream_url:
                continue
            if stream_url in seen_urls:
                continue
            seen_urls.add(stream_url)
            # Derive a label from the domain
            domain = re.search(r'https?://(?:www\.)?([^./]+)', stream_url)
            label = domain.group(1).capitalize() if domain else 'Stream'
            streams.append({'label': label, 'url': stream_url})

        film = {
            'id':         'xxxms_%s' % slug,
            'slug':       slug,
            'title':      _clean_title(title or slug.replace('-', ' ').title()),
            'title_norm': _norm_title(title or slug.replace('-', ' ')),
            'thumb':      thumb,
            'description': desc,
            'url':        film_url,
            'source':     'xxxmoviestream',
            'streams':    streams,
        }
        _cache.set(ck, film, 24 * 3600)
        return film
    except Exception as e:
        xbmc.log('[Starfleet/Streams] xxxmoviestream detail error (%s): %s' % (slug, e), xbmc.LOGERROR)
        return None


def get_xxxms_films(page=1):
    """Return list of film dicts from xxxmoviestream.org, page N."""
    from concurrent.futures import ThreadPoolExecutor
    stubs = _xxxms_film_list(page)
    if not stubs:
        return []
    with ThreadPoolExecutor(max_workers=min(len(stubs), 6)) as p:
        results = list(p.map(lambda s: _xxxms_film_detail(s['slug'], s['url']), stubs))
    return [d for d in results if d]


# ── pornwatch.ws ──────────────────────────────────────────────────────────────
# DooPlay theme: film cards use data-movie-id="N" + oldtitle="TITLE" + <img src>
# Detail pages use data-fl-url="..." for stream URLs.

_RE_WPW_CARD = re.compile(
    r'data-movie-id="\d+"[^>]*>.*?'
    r'href="(https?://pornwatch\.ws/([a-z0-9][a-z0-9-]+)/)"[^>]*'
    r'oldtitle="([^"]+)"[^>]*>.*?'
    r'<img[^>]+src="([^"]+)"',
    re.IGNORECASE | re.DOTALL
)
_RE_WPW_STREAMS = re.compile(r'data-fl-url="(https?://[^"]+)"', re.IGNORECASE)
_WPW_STREAM_SKIP = re.compile(
    r'(?:rapidgator|nitroflare|frdl\.io|uploaded|keep2share)', re.IGNORECASE
)


def _wpw_film_list(page=1):
    ck = 'fstreams_wpw_list_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    url = WPW_BASE + ('/movies-2/' if page == 1 else '/movies-2/page/%d/' % page)
    try:
        html  = _get(url)
        films = []
        seen  = set()
        for m in _RE_WPW_CARD.finditer(html):
            film_url, slug, title, thumb = m.group(1), m.group(2), m.group(3), m.group(4)
            if slug in seen:
                continue
            seen.add(slug)
            films.append({'slug': slug, 'url': film_url, 'title': title, 'thumb': thumb})
        _cache.set(ck, films, 6 * 3600)
        xbmc.log('[Starfleet/Streams] pornwatch page %d: %d films' % (page, len(films)), xbmc.LOGINFO)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/Streams] pornwatch list error: %s' % e, xbmc.LOGERROR)
        return []


def _wpw_film_detail(slug, film_url, title='', thumb=''):
    ck = 'fstreams_wpw_detail_%s' % slug
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        html = _get(film_url)
        if not title:
            m = re.search(r'<h1[^>]*>([^<]+)</h1>', html, re.IGNORECASE)
            title = _clean(m.group(1)) if m else slug.replace('-', ' ').title()
        if not thumb:
            thumb = _og(html, 'image')
        desc = _og(html, 'description')
        seen_urls = set()
        streams   = []
        for m in _RE_WPW_STREAMS.finditer(html):
            su = m.group(1)
            if _skip_locker_unless_debrid(su) or 'deadUrl' in su or su in seen_urls:
                continue
            seen_urls.add(su)
            dom = re.search(r'https?://(?:www\.)?([^./]+)', su)
            streams.append({'label': dom.group(1).capitalize() if dom else 'Stream', 'url': su})
        film = {
            'id':         'wpw_%s' % slug,
            'slug':       slug,
            'title':      _clean_title(title),
            'title_norm': _norm_title(title),
            'thumb':      thumb,
            'description': desc,
            'url':        film_url,
            'source':     'pornwatch',
            'streams':    streams,
        }
        _cache.set(ck, film, 24 * 3600)
        return film
    except Exception as e:
        xbmc.log('[Starfleet/Streams] pornwatch detail error (%s): %s' % (slug, e), xbmc.LOGERROR)
        return None


def get_wpw_films(page=1):
    """Return list of film dicts from pornwatch.ws, page N."""
    from concurrent.futures import ThreadPoolExecutor
    stubs = _wpw_film_list(page)
    if not stubs:
        return []
    with ThreadPoolExecutor(max_workers=min(len(stubs), 6)) as p:
        results = list(p.map(
            lambda s: _wpw_film_detail(s['slug'], s['url'], s.get('title', ''), s.get('thumb', '')), stubs))
    return [d for d in results if d]


# ── adultdvdparadise.org ───────────────────────────────────────────────────────
# Same DooPlay theme + dooplayer plugin as pornwatch.ws above, confirmed live:
# detail pages carry the exact same data-fl-url="..." stream attributes
# (doodstream.com links, same host pornwatch's own films already resolve).
# The one real difference is the listing card markup: this site runs the
# WP Fastest Cache Premium plugin, which lazy-loads every <img> behind a
# blank.gif placeholder and stashes the real thumbnail URL in
# data-wpfc-original-src instead of a plain src attribute.

_RE_ADP_CARD = re.compile(
    r'<article class="item" id="post-\d+">.*?'
    r'href="(https?://adultdvdparadise\.org/movies/([a-z0-9][a-z0-9-]+)/)"[^>]*>\s*'
    r'<img[^>]+data-wpfc-original-src="([^"]+)"[^>]*alt="([^"]+)"',
    re.IGNORECASE | re.DOTALL
)


def _adp_film_list(page=1):
    ck = 'fstreams_adp_list_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    url = ADP_BASE + ('/movies/' if page == 1 else '/movies/page/%d/' % page)
    try:
        html  = _get(url)
        films = []
        seen  = set()
        for m in _RE_ADP_CARD.finditer(html):
            film_url, slug, thumb, title = m.group(1), m.group(2), m.group(3), m.group(4)
            if slug in seen:
                continue
            seen.add(slug)
            films.append({'slug': slug, 'url': film_url, 'title': title, 'thumb': thumb})
        _cache.set(ck, films, 6 * 3600)
        xbmc.log('[Starfleet/Streams] adultdvdparadise page %d: %d films' % (page, len(films)), xbmc.LOGINFO)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/Streams] adultdvdparadise list error: %s' % e, xbmc.LOGERROR)
        return []


def _adp_film_detail(slug, film_url, title='', thumb=''):
    ck = 'fstreams_adp_detail_%s' % slug
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        html = _get(film_url)
        if not title:
            m = re.search(r'<h1[^>]*>([^<]+)</h1>', html, re.IGNORECASE)
            title = _clean(m.group(1)) if m else slug.replace('-', ' ').title()
        if not thumb:
            thumb = _og(html, 'image')
        desc = _og(html, 'description')
        seen_urls = set()
        streams   = []
        # Reuses pornwatch's own data-fl-url regex/skip-list -- same
        # DooPlay/dooplayer markup, same attribute, confirmed live.
        for m in _RE_WPW_STREAMS.finditer(html):
            su = m.group(1)
            if _skip_locker_unless_debrid(su) or 'deadUrl' in su or su in seen_urls:
                continue
            seen_urls.add(su)
            dom = re.search(r'https?://(?:www\.)?([^./]+)', su)
            streams.append({'label': dom.group(1).capitalize() if dom else 'Stream', 'url': su})
        film = {
            'id':         'adp_%s' % slug,
            'slug':       slug,
            'title':      _clean_title(title),
            'title_norm': _norm_title(title),
            'thumb':      thumb,
            'description': desc,
            'url':        film_url,
            'source':     'adultdvdparadise',
            'streams':    streams,
        }
        _cache.set(ck, film, 24 * 3600)
        return film
    except Exception as e:
        xbmc.log('[Starfleet/Streams] adultdvdparadise detail error (%s): %s' % (slug, e), xbmc.LOGERROR)
        return None


def get_adp_films(page=1):
    """Return list of film dicts from adultdvdparadise.org, page N."""
    from concurrent.futures import ThreadPoolExecutor
    stubs = _adp_film_list(page)
    if not stubs:
        return []
    with ThreadPoolExecutor(max_workers=min(len(stubs), 6)) as p:
        results = list(p.map(
            lambda s: _adp_film_detail(s['slug'], s['url'], s.get('title', ''), s.get('thumb', '')), stubs))
    return [d for d in results if d]


# ── watchpornfree.info ────────────────────────────────────────────────────────
# TPostMv theme: film cards in <li class="TPostMv"> with href and img alt.
# Detail pages use data-fl-url="..." for stream URLs.

_RE_WPF_CARD = re.compile(
    r'<li[^>]+class="TPostMv"[^>]*>.*?'
    r'<a[^>]+href="(https?://watchpornfree\.info/([a-z0-9][a-z0-9-]+)[^"]*)"[^>]*>.*?'
    r'<img[^>]+src="([^"]+)"[^>]+alt="([^"]*)"',
    re.IGNORECASE | re.DOTALL
)
_RE_WPF_STREAMS = re.compile(r'data-fl-url="(https?://[^"]+)"', re.IGNORECASE)
_WPF_STREAM_SKIP = re.compile(
    # frdl.to added 2026-08-15 (confirmed live on mangoporn.net/streamporn.vip
    # detail pages) — same frdl premium-locker network as frdl.io, just a
    # different TLD, so it belongs in the same skip list for the same reason.
    r'(?:rapidgator|nitroflare|frdl\.(?:io|to)|uploaded|keep2share)', re.IGNORECASE
)


def _wpf_film_list(page=1):
    ck = 'fstreams_wpf_list_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    url = WPF_BASE + ('/' if page == 1 else '/page/%d/' % page)
    try:
        html  = _get(url)
        films = []
        seen  = set()
        for m in _RE_WPF_CARD.finditer(html):
            film_url, slug, thumb, alt = m.group(1), m.group(2), m.group(3), m.group(4)
            if slug in seen:
                continue
            seen.add(slug)
            # alt is "Watch TITLE Porn Online Free" — strip prefix/suffix
            title = re.sub(r'^Watch\s+', '', alt, flags=re.IGNORECASE)
            title = re.sub(r'\s+(?:Porn|Online|Free|Watch).*$', '', title, flags=re.IGNORECASE).strip()
            if not title:
                title = slug.replace('-', ' ').title()
            films.append({'slug': slug, 'url': film_url, 'title': title, 'thumb': thumb})
        _cache.set(ck, films, 6 * 3600)
        xbmc.log('[Starfleet/Streams] watchpornfree page %d: %d films' % (page, len(films)), xbmc.LOGINFO)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/Streams] watchpornfree list error: %s' % e, xbmc.LOGERROR)
        return []


def _wpf_film_detail(slug, film_url, title='', thumb=''):
    ck = 'fstreams_wpf_detail_%s' % slug
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        html = _get(film_url)
        if not title:
            m = re.search(r'<h1[^>]*>([^<]+)</h1>', html, re.IGNORECASE)
            title = _clean(m.group(1)) if m else slug.replace('-', ' ').title()
            title = re.sub(r'^Watch\s+', '', title, flags=re.IGNORECASE)
            title = re.sub(r'\s+(?:Porn|Online|Free).*$', '', title, flags=re.IGNORECASE).strip()
        if not thumb:
            thumb = _og(html, 'image')
        desc = _og(html, 'description')
        seen_urls = set()
        streams   = []
        for m in _RE_WPF_STREAMS.finditer(html):
            su = m.group(1)
            if _skip_locker_unless_debrid(su) or 'deadUrl' in su or su in seen_urls:
                continue
            seen_urls.add(su)
            dom = re.search(r'https?://(?:www\.)?([^./]+)', su)
            streams.append({'label': dom.group(1).capitalize() if dom else 'Stream', 'url': su})
        film = {
            'id':         'wpf_%s' % slug,
            'slug':       slug,
            'title':      _clean_title(title),
            'title_norm': _norm_title(title),
            'thumb':      thumb,
            'description': desc,
            'url':        film_url,
            'source':     'watchpornfree',
            'streams':    streams,
        }
        _cache.set(ck, film, 24 * 3600)
        return film
    except Exception as e:
        xbmc.log('[Starfleet/Streams] watchpornfree detail error (%s): %s' % (slug, e), xbmc.LOGERROR)
        return None


def get_wpf_films(page=1):
    """Return list of film dicts from watchpornfree.info, page N."""
    from concurrent.futures import ThreadPoolExecutor
    stubs = _wpf_film_list(page)
    if not stubs:
        return []
    with ThreadPoolExecutor(max_workers=min(len(stubs), 6)) as p:
        results = list(p.map(
            lambda s: _wpf_film_detail(s['slug'], s['url'], s.get('title', ''), s.get('thumb', '')), stubs))
    return [d for d in results if d]


# ── speedporn.net ─────────────────────────────────────────────────────────────
# Slug-number URLs: /slug-N/ pattern on homepage.
# Detail pages use data-fl-url="..." for stream URLs.

_RE_SPN_CARD = re.compile(
    r'href="(https?://speedporn\.net/([a-z0-9][a-z0-9-]+-\d+)/)"',
    re.IGNORECASE
)
_RE_SPN_IMG = re.compile(r'<img[^>]+src="([^"]+)"', re.IGNORECASE)
_RE_SPN_STREAMS = re.compile(r'data-fl-url="(https?://[^"]+)"', re.IGNORECASE)
_SPN_STREAM_SKIP = re.compile(
    r'(?:rapidgator|nitroflare|frdl\.io|uploaded|keep2share)', re.IGNORECASE
)


def _spn_film_list(page=1):
    ck = 'fstreams_spn_list_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    url = SPN_BASE + ('/' if page == 1 else '/page/%d/' % page)
    try:
        html  = _get(url)
        films = []
        seen  = set()
        for m in _RE_SPN_CARD.finditer(html):
            film_url, slug = m.group(1), m.group(2)
            if slug in seen:
                continue
            seen.add(slug)
            # Thumbnail: look for img in the vicinity (next 300 chars)
            idx   = m.end()
            chunk = html[idx:idx + 300]
            im    = _RE_SPN_IMG.search(chunk)
            thumb = im.group(1) if im else ''
            films.append({'slug': slug, 'url': film_url, 'thumb': thumb})
        _cache.set(ck, films, 6 * 3600)
        xbmc.log('[Starfleet/Streams] speedporn page %d: %d films' % (page, len(films)), xbmc.LOGINFO)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/Streams] speedporn list error: %s' % e, xbmc.LOGERROR)
        return []


def _spn_film_detail(slug, film_url, thumb=''):
    ck = 'fstreams_spn_detail_%s' % slug
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        html = _get(film_url)
        title = ''
        m = re.search(r'<h1[^>]*>([^<]+)</h1>', html, re.IGNORECASE)
        if m:
            title = _clean(m.group(1))
        if not title:
            title = _og(html, 'title')
            title = re.sub(r'\s*[|\-–].*$', '', title).strip()
        if not title:
            # Derive from slug: strip trailing -number
            title = re.sub(r'-\d+$', '', slug).replace('-', ' ').title()
        if not thumb:
            thumb = _og(html, 'image')
        desc = _og(html, 'description')
        seen_urls = set()
        streams   = []
        for m in _RE_SPN_STREAMS.finditer(html):
            su = m.group(1)
            if _skip_locker_unless_debrid(su) or 'deadUrl' in su or su in seen_urls:
                continue
            seen_urls.add(su)
            dom = re.search(r'https?://(?:www\.)?([^./]+)', su)
            streams.append({'label': dom.group(1).capitalize() if dom else 'Stream', 'url': su})
        film = {
            'id':         'spn_%s' % slug,
            'slug':       slug,
            'title':      _clean_title(title),
            'title_norm': _norm_title(title),
            'thumb':      thumb,
            'description': desc,
            'url':        film_url,
            'source':     'speedporn',
            'streams':    streams,
        }
        _cache.set(ck, film, 24 * 3600)
        return film
    except Exception as e:
        xbmc.log('[Starfleet/Streams] speedporn detail error (%s): %s' % (slug, e), xbmc.LOGERROR)
        return None


def get_spn_films(page=1):
    """Return list of film dicts from speedporn.net, page N."""
    from concurrent.futures import ThreadPoolExecutor
    stubs = _spn_film_list(page)
    if not stubs:
        return []
    with ThreadPoolExecutor(max_workers=min(len(stubs), 6)) as p:
        results = list(p.map(
            lambda s: _spn_film_detail(s['slug'], s['url'], s.get('thumb', '')), stubs))
    return [d for d in results if d]


# ── xxxscenes.net ─────────────────────────────────────────────────────────────
# WordPress-based scene/video aggregator. Cards use href slug pattern.
# Stream URLs in data-fl-url="..." or iframe src on detail pages.

_RE_XXXSC_CARD = re.compile(
    r'href="(https?://xxxscenes\.net/([a-z0-9][a-z0-9-]+)/)"[^>]*>\s*<img',
    re.IGNORECASE
)
_RE_XXXSC_IMG = re.compile(
    r'<img[^>]+(?:data-src|src)="(https?://[^"]+(?:\.jpg|\.jpeg|\.png|\.webp)[^"]*)"',
    re.IGNORECASE
)
_RE_XXXSC_STREAMS = re.compile(r'data-fl-url="(https?://[^"]+)"', re.IGNORECASE)
_XXXSC_SKIP_SLUGS = {
    'page', 'category', 'tag', 'author', 'feed', 'wp-json',
    'contact-us', 'privacy-policy', 'about', 'sitemap',
}
_XXXSC_STREAM_SKIP = re.compile(
    r'(?:rapidgator|nitroflare|frdl\.io|uploaded|keep2share)', re.IGNORECASE
)


def _xxxsc_film_list(page=1):
    ck = 'fstreams_xxxsc_list_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    url = XXXSC_BASE + ('/' if page == 1 else '/page/%d/' % page)
    try:
        html  = _get(url)
        films = []
        seen  = set()
        for m in _RE_XXXSC_CARD.finditer(html):
            film_url, slug = m.group(1), m.group(2)
            if slug in _XXXSC_SKIP_SLUGS or slug in seen:
                continue
            seen.add(slug)
            # thumbnail: scan the next 400 chars after the card anchor
            chunk = html[m.start():m.start() + 600]
            im    = _RE_XXXSC_IMG.search(chunk)
            thumb = im.group(1) if im else ''
            films.append({'slug': slug, 'url': film_url, 'thumb': thumb})
        _cache.set(ck, films, 6 * 3600)
        xbmc.log('[Starfleet/Streams] xxxscenes page %d: %d films' % (page, len(films)), xbmc.LOGINFO)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/Streams] xxxscenes list error: %s' % e, xbmc.LOGERROR)
        return []


def _xxxsc_film_detail(slug, film_url, thumb=''):
    ck = 'fstreams_xxxsc_detail_%s' % slug
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    try:
        html  = _get(film_url)

        title = ''
        m = re.search(r'<h1[^>]*>([^<]+)</h1>', html, re.IGNORECASE)
        if m:
            title = _clean(m.group(1))
        if not title:
            title = _og(html, 'title')
            title = re.sub(r'\s*[|\-–].*$', '', title).strip()
        if not title:
            title = slug.replace('-', ' ').title()

        if not thumb:
            thumb = _og(html, 'image')
        desc = _og(html, 'description')

        seen_urls = set()
        streams   = []
        for m in _RE_XXXSC_STREAMS.finditer(html):
            su = m.group(1)
            if _skip_locker_unless_debrid(su) or 'deadUrl' in su or su in seen_urls:
                continue
            seen_urls.add(su)
            dom = re.search(r'https?://(?:www\.)?([^./]+)', su)
            label = dom.group(1).capitalize() if dom else 'Stream'
            streams.append({'label': label, 'url': su})

        # Also pick up iframe embeds
        for m in re.finditer(r'<iframe[^>]+src="(https?://[^"]+)"', html, re.IGNORECASE):
            su = m.group(1)
            if su in seen_urls:
                continue
            seen_urls.add(su)
            dom = re.search(r'https?://(?:www\.)?([^./]+)', su)
            label = dom.group(1).capitalize() if dom else 'Embed'
            streams.append({'label': label, 'url': su})

        film = {
            'id':          'xxxsc_%s' % slug,
            'slug':        slug,
            'title':       _clean_title(title),
            'title_norm':  _norm_title(title),
            'thumb':       thumb,
            'description': desc,
            'url':         film_url,
            'source':      'xxxscenes',
            'streams':     streams,
        }
        _cache.set(ck, film, 24 * 3600)
        return film
    except Exception as e:
        xbmc.log('[Starfleet/Streams] xxxscenes detail error (%s): %s' % (slug, e), xbmc.LOGERROR)
        return None


def get_xxxsc_films(page=1):
    """Return list of film dicts from xxxscenes.net, page N."""
    from concurrent.futures import ThreadPoolExecutor
    stubs = _xxxsc_film_list(page)
    if not stubs:
        return []
    with ThreadPoolExecutor(max_workers=min(len(stubs), 6)) as p:
        results = list(p.map(
            lambda s: _xxxsc_film_detail(s['slug'], s['url'], s.get('thumb', '')), stubs))
    return [d for d in results if d]


def _search_xxxsc_films(title, page=1):
    """Search xxxscenes.net via /?s=title and return matched film dicts.
    `page` is accepted (for a uniform call signature with every other
    search_fn in search_by_title) but deliberately NOT threaded into the
    URL: confirmed live 2026-08-14 this site's own /?s= search already
    returns ZERO matches for _RE_XXXSC_CARD even on page 1 (its search
    results page uses different markup than the listing page the card
    regex was written against) — a pre-existing bug independent of
    pagination. Wiring in a page param would just add fake pagination on
    top of an already-broken 0-result search, so it's left alone per this
    session's "don't guess blindly / don't break what already doesn't
    work" instruction."""
    from urllib.parse import quote as _quote
    try:
        html = _get(XXXSC_BASE + '/?s=' + _quote(title))
        stubs, seen = [], set()
        for m in _RE_XXXSC_CARD.finditer(html):
            film_url, slug = m.group(1), m.group(2)
            if slug not in _XXXSC_SKIP_SLUGS and slug not in seen:
                seen.add(slug)
                stubs.append({'slug': slug, 'url': film_url, 'thumb': ''})
    except Exception as e:
        xbmc.log('[Starfleet/Streams] xxxsc search error: %s' % e, xbmc.LOGWARNING)
        stubs = []
    return _pfetch(stubs, lambda s: _xxxsc_film_detail(s['slug'], s['url'], s.get('thumb', '')), limit=8)


# ── Fast stub catalogue (list pages only, no detail fetches) ─────────────────

# ── xmovix.net scraper ───────────────────────────────────────────────────────

def _xmovix_depack(html_code):
    """Deobfuscate Dean Edwards P,A,C,K,E,D JS to extract stream URLs."""
    m = re.search(
        r"eval\(function\(p,a,c,k,e,d\)\{.*?\}\('(.*?)',(\d+),(\d+),'(.*?)'\.split\('\|'\)\)\)",
        html_code, re.DOTALL
    )
    if not m:
        return ''
    p_str, a_str, _, k_str = m.groups()
    a, k = int(a_str), k_str.split('|')
    def replace(mw):
        w = mw.group(0)
        try:
            n = 0
            for ch in w:
                n = n * a + (int(ch) if ch.isdigit() else ord(ch) - 87)
            return k[n] if n < len(k) and k[n] else w
        except Exception:
            return w
    return re.sub(r'[0-9a-z]+', replace, p_str)


def _xmovix_film_list(page=1):
    ck = 'fstreams_xmovix_list_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        url = XMOVIX_BASE + ('/' if page == 1 else '/page/%d/' % page)
        html = _cf_sess().get(url, timeout=12).text
        films = []
        for film_url, img in re.findall(
            r'href="(https://hd\.xmovix\.net/movies/[^"]+\.html)"[^>]*>\s*<img\s+data-src="([^"]+)"',
            html
        ):
            slug_m = re.search(r'/(\d+[^/]+)\.html', film_url)
            slug = slug_m.group(1) if slug_m else re.sub(r'[^a-z0-9]+', '-', film_url.lower())
            img_slug = re.search(r'/thumbs/([^.]+)\.', img)
            eng_title = img_slug.group(1).replace('-', ' ').title() if img_slug else slug
            films.append({'slug': slug, 'url': film_url, 'thumb': img, 'title': eng_title})
        _cache.set(ck, films, 3600)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/Streams] xmovix list error (page %d): %s' % (page, e), xbmc.LOGWARNING)
        return []


def _xmovix_film_detail(slug, film_url, thumb='', title_hint=''):
    ck = 'fstreams_xmovix_detail_%s' % slug
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        html = _cf_sess().get(film_url, timeout=12).text
        embed_urls = re.findall(r's2\.src\s*=\s*["\' ](https://filmcdm\.top/[^"\' ]+)["\' ]', html)
        if not embed_urls:
            return None
        embed_html = _cf_sess().get(embed_urls[0], timeout=12).text
        title_m = re.search(r'<title>([^<]+)</title>', embed_html)
        title = title_m.group(1).strip() if title_m else title_hint
        title = re.sub(r'\s*\(\d{3,4}p?\)\s*$', '', title).strip() or title_hint
        unpacked = _xmovix_depack(embed_html)
        m3u8_urls = re.findall(r'https://[^"\' ]+\.m3u8[^"\' ]*', unpacked)
        if not m3u8_urls:
            return None
        film = {
            'id': 'xmovix_%s' % slug, 'slug': slug,
            'title': title, 'title_norm': _norm_title(title),
            'thumb': thumb, 'description': '', 'url': film_url,
            'source': 'xmovix',
            'streams': [{'label': 'xmovix HLS', 'url': m3u8_urls[0]}],
        }
        _cache.set(ck, film, 3600)
        return film
    except Exception as e:
        xbmc.log('[Starfleet/Streams] xmovix detail error (%s): %s' % (slug, e), xbmc.LOGWARNING)
        return None


def _search_xmovix_films(title, page=1):
    """Search hd.xmovix.net via /?s=title using cfscrape and return matched
    film dicts. Confirmed live 2026-08-14: same WordPress '/page/N/?s=...'
    pagination as _xmovix_film_list's own listing — page1 vs page2 came
    back mostly disjoint (42/48 different slugs; the small overlap looks
    like recurring sidebar/related items, same as the xhamster and eporner
    checks that session ran alongside this one)."""
    from urllib.parse import quote as _quote
    url = XMOVIX_BASE + (('/?s=' + _quote(title)) if page <= 1
                          else ('/page/%d/?s=' % page) + _quote(title))
    try:
        html = _cf_sess().get(url, timeout=12).text
        stubs, seen = [], set()
        for film_url, img in re.findall(
            r'href="(https://hd\.xmovix\.net/movies/[^"]+\.html)"[^>]*>\s*<img\s+(?:data-src|src)="([^"]+)"',
            html
        ):
            slug_m = re.search(r'/(\d+[^/]+)\.html', film_url)
            slug = slug_m.group(1) if slug_m else re.sub(r'[^a-z0-9]+', '-', film_url.lower())
            if slug in seen:
                continue
            seen.add(slug)
            img_slug = re.search(r'/thumbs/([^.]+)\.', img)
            title_hint = img_slug.group(1).replace('-', ' ').title() if img_slug else slug
            stubs.append({'slug': slug, 'url': film_url, 'thumb': img, 'title': title_hint})
    except Exception as e:
        xbmc.log('[Starfleet/Streams] xmovix search error: %s' % e, xbmc.LOGWARNING)
        stubs = []
    return _pfetch(stubs, lambda s: _xmovix_film_detail(s['slug'], s['url'], s.get('thumb', ''), s.get('title', '')))


def get_all_stream_stubs(page=1):
    """
    Return a deduplicated list of film stubs using ONLY list page data.
    No detail page fetches — title+thumb from the list page, no stream URLs.
    Detail is fetched on demand when the user clicks a film.
    Sources processed in fixed order so newest films appear first.
    """
    from concurrent.futures import ThreadPoolExecutor

    def _freeo_stubs(pg):
        items = _freeo_film_list(pg)
        result = []
        for s in items:
            slug = s['slug']
            title = _clean_title(slug.replace('-', ' ').title())
            result.append({
                'id': 'freeo_%s' % slug, 'slug': slug,
                'title': title, 'title_norm': _norm_title(title),
                'thumb': '', 'description': '', 'url': s['url'],
                'source': 'freeomovie', 'streams': [],
            })
        return result

    def _xxxms_stubs(pg):
        items = _xxxms_film_list(pg)
        result = []
        for s in items:
            slug = s['slug']
            title = _clean_title(slug.replace('-', ' ').title())
            result.append({
                'id': 'xxxms_%s' % slug, 'slug': slug,
                'title': title, 'title_norm': _norm_title(title),
                'thumb': '', 'description': '', 'url': s['url'],
                'source': 'xxxmoviestream', 'streams': [],
            })
        return result

    def _wpw_stubs(pg):
        items = _wpw_film_list(pg)
        result = []
        for s in items:
            slug = s['slug']
            title = _clean_title(s.get('title') or slug.replace('-', ' ').title())
            result.append({
                'id': 'wpw_%s' % slug, 'slug': slug,
                'title': title, 'title_norm': _norm_title(title),
                'thumb': s.get('thumb', ''), 'description': '', 'url': s['url'],
                'source': 'pornwatch', 'streams': [],
            })
        return result

    def _wpf_stubs(pg):
        items = _wpf_film_list(pg)
        result = []
        for s in items:
            slug = s['slug']
            title = _clean_title(s.get('title') or slug.replace('-', ' ').title())
            result.append({
                'id': 'wpf_%s' % slug, 'slug': slug,
                'title': title, 'title_norm': _norm_title(title),
                'thumb': s.get('thumb', ''), 'description': '', 'url': s['url'],
                'source': 'watchpornfree', 'streams': [],
            })
        return result

    def _spn_stubs(pg):
        items = _spn_film_list(pg)
        result = []
        for s in items:
            slug = s['slug']
            title = _clean_title(re.sub(r'-\d+$', '', slug).replace('-', ' ').title())
            result.append({
                'id': 'spn_%s' % slug, 'slug': slug,
                'title': title, 'title_norm': _norm_title(title),
                'thumb': s.get('thumb', ''), 'description': '', 'url': s['url'],
                'source': 'speedporn', 'streams': [],
            })
        return result

    def _xxxsc_stubs(pg):
        items = _xxxsc_film_list(pg)
        result = []
        for s in items:
            slug = s['slug']
            title = _clean_title(slug.replace('-', ' ').title())
            result.append({
                'id': 'xxxsc_%s' % slug, 'slug': slug,
                'title': title, 'title_norm': _norm_title(title),
                'thumb': s.get('thumb', ''), 'description': '', 'url': s['url'],
                'source': 'xxxscenes', 'streams': [],
            })
        return result

    def _xmovix_stubs(pg):
        items = _xmovix_film_list(pg)
        result = []
        for s in items:
            slug = s['slug']
            title = _clean_title(s.get('title') or slug.replace('-', ' ').title())
            result.append({
                'id': 'xmovix_%s' % slug, 'slug': slug,
                'title': title, 'title_norm': _norm_title(title),
                'thumb': s.get('thumb', ''), 'description': '', 'url': s['url'],
                'source': 'xmovix', 'streams': [],
            })
        return result

    stub_fns = [_freeo_stubs, _xxxms_stubs, _wpw_stubs, _wpf_stubs, _spn_stubs, _xxxsc_stubs, _xmovix_stubs]

    # Submit all in parallel but collect in fixed order (newest-first per source)
    with ThreadPoolExecutor(max_workers=len(stub_fns)) as pool:
        futures = [pool.submit(fn, page) for fn in stub_fns]
        source_results = []
        for fn, future in zip(stub_fns, futures):
            try:
                source_results.append(future.result(timeout=12))
            except Exception as e:
                xbmc.log('[Starfleet/Streams] stub error (%s): %s' % (fn.__name__, e), xbmc.LOGWARNING)
                source_results.append([])

    # Merge sources in order: if the same film appears in multiple sources, keep first occurrence
    # but enrich thumb from later sources. This preserves newest-first ordering.
    by_norm = {}
    for source_films in source_results:
        for film in source_films:
            nt = film['title_norm']
            if not nt:
                continue
            if nt not in by_norm:
                by_norm[nt] = dict(film)
            else:
                if not by_norm[nt].get('thumb') and film.get('thumb'):
                    by_norm[nt]['thumb'] = film['thumb']

    return list(by_norm.values())


def fetch_film_detail_on_demand(film_id, film_url=''):
    """
    Fetch a single film's detail page on demand (when not in cache).
    film_id format: 'freeo_slug', 'xxxms_slug', 'wpw_slug', 'wpf_slug', 'spn_slug'.
    film_url is optional; derived from film_id+slug if not provided.
    Returns a film dict with streams, or None on failure.
    """
    if film_id.startswith('freeo_'):
        slug = film_id[6:]
        url = film_url or (FREEO_BASE + '/' + slug + '/')
        return _freeo_film_detail(slug, url)
    elif film_id.startswith('xxxms_'):
        slug = film_id[6:]
        url = film_url or (XXXMS_BASE + '/movies/' + slug + '/')
        return _xxxms_film_detail(slug, url)
    elif film_id.startswith('wpw_'):
        slug = film_id[4:]
        url = film_url or (WPW_BASE + '/' + slug + '/')
        return _wpw_film_detail(slug, url)
    elif film_id.startswith('adp_'):
        slug = film_id[4:]
        url = film_url or (ADP_BASE + '/movies/' + slug + '/')
        return _adp_film_detail(slug, url)
    elif film_id.startswith('wpf_'):
        slug = film_id[4:]
        url = film_url or (WPF_BASE + '/' + slug + '/')
        return _wpf_film_detail(slug, url)
    elif film_id.startswith('spn_'):
        slug = film_id[4:]
        url = film_url or (SPN_BASE + '/' + slug + '/')
        return _spn_film_detail(slug, url)
    elif film_id.startswith('xxxsc_'):
        slug = film_id[6:]
        url = film_url or (XXXSC_BASE + '/' + slug + '/')
        return _xxxsc_film_detail(slug, url)
    elif film_id.startswith('xmovix_'):
        slug = film_id[7:]
        url = film_url or (XMOVIX_BASE + '/movies/hd-1080p/' + slug + '.html')
        return _xmovix_film_detail(slug, url)
    # Added 2026-08-15 (Pattern B / Movies) — these sites always populate
    # 'url' on their list stubs, so film_url is only ever missing here in
    # the rare case the caller genuinely had none; there's no reliable way
    # to derive a URL from just a slug for these sites, so film_url must be
    # present.
    elif film_id.startswith('mango_') and film_url:
        return _mango_film_detail(film_id[6:], film_url)
    elif film_id.startswith('spvip_') and film_url:
        return _spvip_film_detail(film_id[6:], film_url)
    elif film_id.startswith('sf_') and film_url:
        return _sf_film_detail(film_id[3:], film_url)
    elif film_id.startswith('paradise_') and film_url:
        return _paradise_film_detail(film_id[9:], film_url)
    elif film_id.startswith('pxp_') and film_url:
        return _pxp_film_detail(film_id[4:], film_url)
    return None


# ── Merged + deduplicated stream catalogue ────────────────────────────────────

def get_all_streams(page=1):
    """
    Return a merged, deduplicated list of films from all 5 sources.
    Films with the same normalised title are merged into one entry with
    streams combined from every matching source.
    """
    from concurrent.futures import ThreadPoolExecutor, as_completed

    sources = [
        get_freeo_films,
        get_xxxms_films,
        get_wpw_films,
        get_adp_films,
        get_wpf_films,
        get_spn_films,
        get_xxxsc_films,
    ]

    all_films = []
    with ThreadPoolExecutor(max_workers=len(sources)) as pool:
        futures = {pool.submit(fn, page): fn.__name__ for fn in sources}
        try:
            for future in as_completed(futures, timeout=25):
                name = futures[future]
                try:
                    results = future.result()
                    all_films.extend(results)
                    xbmc.log('[Starfleet/Streams] %s: %d films on page %d' % (name, len(results), page), xbmc.LOGINFO)
                except Exception as e:
                    xbmc.log('[Starfleet/Streams] source error (%s): %s' % (name, e), xbmc.LOGWARNING)
        except Exception as e:
            # One source timed out — use what we have rather than crashing
            xbmc.log('[Starfleet/Streams] get_all_streams partial timeout: %s' % e, xbmc.LOGWARNING)

    # Deduplicate by normalised title — merge streams from duplicates
    by_norm = {}
    for film in all_films:
        nt = film['title_norm']
        if not nt:
            continue
        if nt not in by_norm:
            by_norm[nt] = dict(film)
            by_norm[nt]['streams'] = list(film['streams'])
        else:
            seen_urls = {s['url'] for s in by_norm[nt]['streams']}
            for s in film['streams']:
                if s['url'] not in seen_urls:
                    by_norm[nt]['streams'].append(s)
                    seen_urls.add(s['url'])
            # Prefer richer metadata (longer description, non-empty thumb)
            if not by_norm[nt].get('thumb') and film.get('thumb'):
                by_norm[nt]['thumb'] = film['thumb']
            if len(film.get('description', '')) > len(by_norm[nt].get('description', '')):
                by_norm[nt]['description'] = film['description']

    merged_list = list(by_norm.values())

    # Cache each merged film under its own id so adult_stream_sources can retrieve it
    for film in merged_list:
        film_id = film.get('id', '')
        if film_id:
            _cache.set('fstreams_merged_%s' % film_id, film, 24 * 3600)

    return merged_list


# ── Title-based stream search (AFDB → scrapers pipeline) ─────────────────────

def _title_matches(norm_query, norm_film):
    """True if the normalised AFDB title matches a scraper film title closely enough.
    Also tries leet-de-normalised versions so 'Pl4y 4' matches 'Play 4'."""
    if not norm_query or not norm_film:
        return False
    if norm_query == norm_film:
        return True
    q_words = norm_query.split()
    f_words = norm_film.split()
    # All query words present in film title
    if len(q_words) >= 2 and all(w in norm_film for w in q_words):
        return True
    # Film title fully contained in query
    if len(f_words) >= 3 and all(w in norm_query for w in f_words):
        return True
    if len(f_words) >= 2 and all(w in norm_query for w in f_words):
        coverage = len(f_words) / max(len(q_words), 1)
        if coverage >= 0.6:
            return True
    # Retry with leet-de-normalised versions (e.g. "Pl4y" → "Play")
    lq = _norm_title_leet(norm_query)
    lf = _norm_title_leet(norm_film)
    if lq != norm_query or lf != norm_film:
        if lq == lf:
            return True
        lq_words = lq.split()
        lf_words = lf.split()
        if len(lq_words) >= 2 and all(w in lf for w in lq_words):
            return True
        if len(lf_words) >= 2 and all(w in lq for w in lf_words):
            coverage = len(lf_words) / max(len(lq_words), 1)
            if coverage >= 0.6:
                return True
    return False


def _pfetch(stubs, fn, limit=5):
    """Fetch up to limit stubs concurrently."""
    from concurrent.futures import ThreadPoolExecutor
    batch = stubs[:limit]
    if not batch:
        return []
    with ThreadPoolExecutor(max_workers=min(len(batch), 5)) as p:
        results = list(p.map(fn, batch))
    return [d for d in results if d]


def _search_freeo_films(title, page=1):
    """Search freeomovie.to via /?s=title and return matched film dicts.
    Confirmed live 2026-08-14: requesting page 2 via WordPress's own
    '/page/N/?s=...' convention (the same one _freeo_film_list already uses
    for its own listing) returns a genuinely different result set — 0 slug
    overlap between page 1 and page 2 for a real query ("threesome")."""
    from urllib.parse import quote as _quote
    url = FREEO_BASE + (('/?s=' + _quote(title)) if page <= 1
                         else ('/page/%d/?s=' % page) + _quote(title))
    try:
        html = _get(url)
        stubs, seen = [], set()
        for m in _RE_FREEO_LINKS.finditer(html):
            film_url, slug = m.group(1), m.group(2)
            if slug not in _FREEO_SKIP and slug not in seen:
                seen.add(slug)
                stubs.append({'slug': slug, 'url': film_url})
    except Exception as e:
        xbmc.log('[Starfleet/Streams] freeo search error: %s' % e, xbmc.LOGWARNING)
        stubs = []
    return _pfetch(stubs, lambda s: _freeo_film_detail(s['slug'], s['url']), limit=8)


def _search_xxxms_films(title, page=1):
    """Search xxxmoviestream.org via /?s=title and return matched film dicts.
    Confirmed live 2026-08-14: same WordPress '/page/N/?s=...' pagination
    as _xxxms_film_list's own listing — 0 slug overlap page1 vs page2."""
    from urllib.parse import quote as _quote
    url = XXXMS_BASE + (('/?s=' + _quote(title)) if page <= 1
                         else ('/page/%d/?s=' % page) + _quote(title))
    try:
        html = _get(url)
        stubs, seen = [], set()
        for m in _RE_XXXMS_CARD.finditer(html):
            film_url, slug = m.group(1), m.group(2)
            if slug not in seen:
                seen.add(slug)
                stubs.append({'slug': slug, 'url': film_url})
    except Exception as e:
        xbmc.log('[Starfleet/Streams] xxxms search error: %s' % e, xbmc.LOGWARNING)
        stubs = []
    return _pfetch(stubs, lambda s: _xxxms_film_detail(s['slug'], s['url']), limit=8)


def _search_wpw_films(title):
    """Search pornwatch.ws via /?s=title and return matched film dicts."""
    from urllib.parse import quote as _quote
    _wpw_re = re.compile(r'href="(https?://pornwatch\.ws/([a-z0-9][a-z0-9-]+)/)"', re.IGNORECASE)
    try:
        html = _get(WPW_BASE + '/?s=' + _quote(title))
        stubs, seen = [], set()
        for m in _wpw_re.finditer(html):
            film_url, slug = m.group(1), m.group(2)
            if slug not in seen:
                seen.add(slug)
                stubs.append({'slug': slug, 'url': film_url})
    except Exception as e:
        xbmc.log('[Starfleet/Streams] wpw search error: %s' % e, xbmc.LOGWARNING)
        stubs = []
    return _pfetch(stubs, lambda s: _wpw_film_detail(s['slug'], s['url'], '', ''))


def _search_wpf_films(title, page=1):
    """Search watchpornfree.info via /?s=title and return matched film dicts.
    Confirmed live 2026-08-14: same WordPress '/page/N/?s=...' pagination
    as _wpf_film_list's own listing — 0 slug overlap page1 vs page2."""
    from urllib.parse import quote as _quote
    norm_q = _norm_title(title)
    url = WPF_BASE + (('/?s=' + _quote(title)) if page <= 1
                       else ('/page/%d/?s=' % page) + _quote(title))
    try:
        html = _get(url)
        stubs, seen = [], set()
        for m in _RE_WPF_CARD.finditer(html):
            film_url, slug, thumb, alt = m.group(1), m.group(2), m.group(3), m.group(4)
            if slug not in seen:
                seen.add(slug)
                t = re.sub(r'^Watch\s+', '', alt, flags=re.IGNORECASE)
                t = re.sub(r'\s+(?:Porn|Online|Free|Watch).*$', '', t, flags=re.IGNORECASE).strip()
                t = t or slug.replace('-', ' ').title()
                # No local title-text pre-filter here — this is already a
                # result from watchpornfree.info's OWN /?s= search endpoint,
                # which (confirmed live) matches on cast/performer name and
                # genre tags, not just the film's own title text (e.g. a
                # performer-name query correctly surfaces films she's
                # credited in, even when her name never appears in the
                # title itself). A strict title-only re-check here used to
                # throw away almost all of those genuinely relevant hits,
                # keeping only the rare exact-title match. _pfetch()'s own
                # concurrency cap (5 by default) is the real bound on
                # fetch cost, not this filter.
                stubs.append({'slug': slug, 'url': film_url, 'title': t, 'thumb': thumb})
    except Exception as e:
        xbmc.log('[Starfleet/Streams] wpf search error: %s' % e, xbmc.LOGWARNING)
        stubs = []
    return _pfetch(stubs, lambda s: _wpf_film_detail(s['slug'], s['url'], s.get('title', ''), s.get('thumb', '')), limit=8)


def _search_spn_films(title, page=1):
    """Search speedporn.net via /?s=title and return matched film dicts.
    Confirmed live 2026-08-14 (site is slow — needed a >20s read timeout to
    even complete the request, unrelated to pagination itself): same
    WordPress '/page/N/?s=...' pagination as _spn_film_list's own
    listing — 0 slug overlap page1 vs page2."""
    from urllib.parse import quote as _quote
    norm_q = _norm_title(title)
    url = SPN_BASE + (('/?s=' + _quote(title)) if page <= 1
                       else ('/page/%d/?s=' % page) + _quote(title))
    try:
        html = _get(url)
        stubs, seen = [], set()
        for m in _RE_SPN_CARD.finditer(html):
            film_url, slug = m.group(1), m.group(2)
            if slug not in seen:
                seen.add(slug)
                # No local title-text pre-filter — same reasoning as
                # _search_wpf_films() above: this is already a result from
                # speedporn.net's own /?s= search (cast/genre-aware, not
                # title-text-only), so re-filtering by slug-derived title
                # text here just threw away genuinely relevant hits whose
                # title doesn't happen to contain the query words.
                stubs.append({'slug': slug, 'url': film_url})
    except Exception as e:
        xbmc.log('[Starfleet/Streams] spn search error: %s' % e, xbmc.LOGWARNING)
        stubs = []
    return _pfetch(stubs, lambda s: _spn_film_detail(s['slug'], s['url'], ''), limit=8)


# ── pandamovies.org ────────────────────────────────────────────────────────────

# Panda list page: anchor with title= attribute inside ml-item cards.
# Matches either domain (pandamovies.org or its confirmed-identical
# pandamovies.pw mirror) since both serve the exact same watch-*-movie-
# online-free slugs from the same WordPress backend.
_RE_PANDA_CARD = re.compile(
    r'href="(https?://pandamovies\.(?:org|pw)/(watch-[a-z0-9][a-z0-9-]+-(?:movie|scene|online)-[a-z-]*))"[^>]*title="([^"]+)"',
    re.IGNORECASE
)
# Panda detail page: stream tabs loaded by ddajaxtabs — <a href="EMBED_URL"> preceded by img or "Server"
_RE_PANDA_STREAM = re.compile(
    r'<a[^>]+href="(https?://(?!pandamovies)[^"]+)"[^>]*>\s*(?:<img[^>]*>|\s*(?:Server|Play|S)\s*\d)',
    re.IGNORECASE
)


def _panda_get(url):
    """Fetch a pandamovies.org URL, falling back to the pandamovies.pw
    mirror (confirmed live 2026-08-15: identical backend/content) if the
    primary domain errors out."""
    try:
        return _get(url)
    except Exception:
        mirror_url = url.replace('pandamovies.org', 'pandamovies.pw')
        if mirror_url != url:
            return _get(mirror_url)
        raise


def _panda_genres():
    """Return list of (name, url) tuples from pandamovies.org. Cached 24h.
    Pandamovies uses year/category sub-paths; we expose their top-level sections
    (homepage, xxxscenes, most-viewed, and recent years) as browsable genres.
    """
    ck = 'panda_genres'
    cached = _cache.get(ck)
    if cached is not None:
        return cached or []
    try:
        html = _panda_get(PANDA_BASE + '/')
        genres = []
        seen = set()
        # Try to find navigation genre/category links
        for m in re.finditer(
            r'href="(https?://pandamovies\.org/(?:genre|category|tag)/([^/"]+)/?)"[^>]*>([^<]+)<',
            html, re.IGNORECASE
        ):
            url, slug, name = m.group(1), m.group(2), m.group(3).strip()
            if url not in seen and name and len(name) > 1:
                seen.add(url)
                genres.append({'name': name.title(), 'url': url})
        # Also expose known top-level sections
        for path, name in [('/', 'All Movies'), ('/xxxscenes/', 'Scenes'), ('/most-viewed', 'Most Viewed')]:
            url = PANDA_BASE + path
            if url not in seen:
                seen.add(url)
                genres.insert(0 if name == 'All Movies' else len(genres),
                              {'name': name, 'url': url})
        # Add year pages found in navigation
        for m in re.finditer(
            r'href="(https?://pandamovies\.org/release-year/(\d{4})/?)"',
            html, re.IGNORECASE
        ):
            url, year = m.group(1), m.group(2)
            if url not in seen:
                seen.add(url)
                genres.append({'name': year, 'url': url})
        _cache.set(ck, genres or [], 24 * 3600)
        return genres
    except Exception as e:
        xbmc.log('[Starfleet/Panda] genres error: %s' % e, xbmc.LOGWARNING)
        return []


def _panda_movies_for_genre(genre_url, page=1):
    """Return list of film stubs for a pandamovies.org genre page. Cached 4h."""
    ck = 'panda_genre_%s_%d' % (re.sub(r'[^a-z0-9]', '_', genre_url.lower())[-40:], page)
    cached = _cache.get(ck)
    if cached is not None:
        return cached or []
    url = genre_url
    if page > 1:
        url = url.rstrip('/') + '/page/%d' % page
    try:
        html = _panda_get(url)
        films = []
        seen = set()
        for m in _RE_PANDA_CARD.finditer(html):
            film_url, slug, title = m.group(1), m.group(2).strip('/'), m.group(3)
            if slug and slug not in seen:
                seen.add(slug)
                thumb = ''
                reg = html[max(0, m.start()-200):m.end()+500]
                ti = re.search(r'<img[^>]+(?:data-lazy-src|src)="([^"]+)"', reg, re.IGNORECASE)
                if ti:
                    thumb = ti.group(1)
                films.append({'slug': slug, 'url': film_url, 'title': _clean_title(title),
                              'title_norm': _norm_title(title), 'thumb': thumb,
                              'source': 'pandamovies', 'streams': []})
        _cache.set(ck, films, 4 * 3600)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/Panda] genre list error: %s' % e, xbmc.LOGWARNING)
        return []


def _panda_film_detail(slug, url):
    """Fetch pandamovies.org detail page, extract DoodStream/MixDrop/StreamTape links."""
    ck = 'panda_detail_%s' % re.sub(r'[^a-z0-9]', '_', slug)[:60]
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    try:
        html = _panda_get(url)
        title = ''
        m = re.search(r'<h1[^>]*>([^<]+)<', html, re.IGNORECASE)
        if m:
            title = _clean(m.group(1))
        # Real, full-size poster — confirmed live 2026-08-28 the detail
        # page's own og:image is often simply ABSENT (not every post has
        # one), but the Yoast JSON-LD's "thumbnailUrl" is present far more
        # reliably and, when both exist, points at the SAME underlying
        # image with no '?resize=NxN' downscale suffix — i.e. the actual
        # full-resolution file, not the ~320px-wide card thumbnail
        # _panda_movies_for_genre() already carries into every stub. That
        # small listing thumb was the only poster Full Library ever showed
        # for a PandaMovies title (75% of the whole library) since this
        # function always returned an empty thumb whenever og:image
        # happened to be missing — confirmed live across 3 real detail
        # pages that thumbnailUrl was there every time og:image wasn't.
        thumb = ''
        mtn = re.search(r'"thumbnailUrl"\s*:\s*"([^"]+)"', html)
        if mtn:
            thumb = mtn.group(1).replace('\\/', '/')
        else:
            mi = re.search(r'property="og:image"[^>]+content="([^"]+)"', html, re.IGNORECASE)
            if mi:
                thumb = mi.group(1)
        # Real plot + cast — confirmed live 2026-08-28 (real user report:
        # "not all showing metadata" — PandaMovies alone is ~75% of Full
        # Library, and this function used to hardcode description='' and
        # never returned cast at all, so those titles never showed either
        # one). og:description carries a genuine synopsis for the first/
        # main scene followed by " - Duration: N min - Starring: Name1
        # Name2..." for every scene the post actually bundles (some posts
        # are single-scene, some are multi-scene compilations) — the
        # synopsis (everything before the first " - Duration:" marker) is
        # a real plot summary; every "Starring:" segment across all
        # bundled scenes is collected for the cast list (de-duplicated,
        # since the same performer can appear in more than one bundled
        # scene). No per-performer photo exists on this site (no cast
        # profile pages/links at all, confirmed live) — carried with an
        # empty photo, same as this file's other no-photo-available cast
        # entries, which already fall back to Kodi's DefaultActor.png.
        description = ''
        cast = []
        md = re.search(r'property="og:description"[^>]+content="([^"]+)"', html, re.IGNORECASE)
        if md:
            desc_full = _html_unescape.unescape(md.group(1))
            synopsis_m = re.match(r'^(.*?)\s*-\s*Duration:', desc_full, re.S)
            description = _clean(synopsis_m.group(1)) if synopsis_m else _clean(desc_full)
            seen_names = set()
            for seg in re.findall(r'Starring:([^\n]+)', desc_full):
                for name in re.split(r'[\xa0,]+', seg):
                    name = name.strip(' .')
                    if name and name.lower() not in seen_names:
                        seen_names.add(name.lower())
                        cast.append({'name': name, 'photo': ''})
        # Junk placeholder link patterns only — the premium-locker hosts
        # (rapidgator/nitroflare/frdl/uploaded/keep2share) are handled
        # separately by the shared, debrid-aware _skip_locker_unless_debrid()
        # below, not lumped into this always-skip set.
        _PANDA_JUNK_SKIP = re.compile(r'(?:localnews|fallback)', re.I)
        streams = []
        seen_s = set()
        for sm in _RE_PANDA_STREAM.finditer(html):
            stream_url = sm.group(1)
            if not stream_url or stream_url in seen_s:
                continue
            if _PANDA_JUNK_SKIP.search(stream_url) or _skip_locker_unless_debrid(stream_url):
                continue
            seen_s.add(stream_url)
            dom = re.search(r'https?://(?:www\.)?([^./]+)', stream_url)
            label = '[Panda] %s' % (dom.group(1).capitalize() if dom else 'Server')
            streams.append({'label': label, 'url': stream_url})
        film = {
            'id':         'panda_' + slug,
            'slug':       slug,
            'title':      _clean_title(title or slug.replace('-', ' ').title()),
            'title_norm': _norm_title(title or slug),
            'thumb':      thumb,
            'description': description,
            'cast':       cast,
            'url':        url,
            'source':     'pandamovies',
            'streams':    streams,
        }
        _cache.set(ck, film, 12 * 3600)
        return film
    except Exception as e:
        xbmc.log('[Starfleet/Panda] detail error (%s): %s' % (slug, e), xbmc.LOGWARNING)
        return None


def _search_panda_films(title, page=1):
    """Search pandamovies.org and return matched film dicts with streams.
    Confirmed live 2026-08-14: same WordPress '/page/N/?s=...' pagination
    as _panda_movies_for_genre's own genre listing — 0 slug overlap page1
    vs page2."""
    from urllib.parse import quote as _quote
    url = PANDA_BASE + (('/?s=' + _quote(title)) if page <= 1
                         else ('/page/%d/?s=' % page) + _quote(title))
    try:
        html = _panda_get(url)
        stubs, seen = [], set()
        for m in _RE_PANDA_CARD.finditer(html):
            film_url, slug = m.group(1), m.group(2).strip('/')
            if slug and slug not in seen:
                seen.add(slug)
                stubs.append({'slug': slug, 'url': film_url})
    except Exception as e:
        xbmc.log('[Starfleet/Panda] search error: %s' % e, xbmc.LOGWARNING)
        stubs = []
    return _pfetch(stubs, lambda s: _panda_film_detail(s['slug'], s['url']), limit=8)


# ── hqporner.com ───────────────────────────────────────────────────────────────

def _hqporner_categories():
    """Return list of (name, url) tuples from hqporner.com categories. Cached 24h."""
    ck = 'hqporner_cats'
    cached = _cache.get(ck)
    if cached is not None:
        return cached or []
    try:
        html = _get(HQPORN_BASE + '/categories')
        cats = []
        seen = set()
        for m in re.finditer(
            r'class="click-trigger"[^>]+href="(/category/[^"]+)"[^>]*>([^<]+)<',
            html, re.IGNORECASE
        ):
            path, name = m.group(1), m.group(2).strip().title()
            url = HQPORN_BASE + path
            if url not in seen:
                seen.add(url)
                cats.append({'name': name, 'url': url})
        # Also try reverse attr order
        for m in re.finditer(
            r'href="(/category/[^"]+)"[^>]*class="click-trigger"[^>]*>([^<]+)<',
            html, re.IGNORECASE
        ):
            path, name = m.group(1), m.group(2).strip().title()
            url = HQPORN_BASE + path
            if url not in seen:
                seen.add(url)
                cats.append({'name': name, 'url': url})
        _cache.set(ck, cats, 24 * 3600)
        return cats
    except Exception as e:
        xbmc.log('[Starfleet/HQP] categories error: %s' % e, xbmc.LOGWARNING)
        return []


def _hqporner_movies(category_url, page=1):
    """Return film stubs for an hqporner.com category page. Cached 4h."""
    ck = 'hqporner_cat_%s_%d' % (re.sub(r'[^a-z0-9]', '_', category_url)[-40:], page)
    cached = _cache.get(ck)
    if cached is not None:
        return cached or []
    url = category_url
    if page > 1:
        # hqporner.com changed its category pagination scheme (confirmed
        # live 2026-08-28): the old '/page/<n>' suffix now 404s outright on
        # every category — real pagination lives at a bare '/<n>' suffix
        # instead (confirmed distinct, non-overlapping film sets between
        # page 1 and the new page 2 URL). This used to make every cold
        # Full Library load burn ~150+ guaranteed-404 requests (5 pages x
        # every category), which was the dominant cause of "adult library
        # doesn't load and is very slow."
        url = url.rstrip('/') + '/%d' % page
    try:
        html = _get(url)
        films = []
        seen = set()
        # Thumbnails live in a separate <img id="cover_<id>" src="..."> tag
        # that can sit well over 600 chars before its item's click-trigger
        # link (a fixed-size context window around the link match missed it
        # entirely, and also grabbed an unrelated title/alt attribute from
        # whatever happened to be in range instead — confirmed live
        # 2026-08-14, titles were showing as the raw .html slug and every
        # thumbnail was blank). Matching cover_<id> images by their shared
        # numeric id against each item's own <h3 class="meta-data-title">
        # link (whose text IS the real title, no separate alt/title lookup
        # needed) is exact instead of positional guessing.
        thumbs = {}
        for item_id, src in re.findall(r'id="cover_(\d+)"\s+src="([^"]+)"', html, re.IGNORECASE):
            thumbs[item_id] = ('https:' + src) if src.startswith('//') else src
        for path, item_id, title in re.findall(
            r'href="(/hdporn/(\d+)-[^"]+\.html)"[^>]*class="[^"]*click-trigger[^"]*"[^>]*>([^<]+)</a>',
            html, re.IGNORECASE
        ):
            slug = path.strip('/').split('/')[-1]
            if slug.endswith('.html'):
                slug = slug[:-5]
            if not slug or slug in seen:
                continue
            seen.add(slug)
            film_url = HQPORN_BASE + path
            title = title.strip()
            thumb = thumbs.get(item_id, '')
            films.append({'slug': slug, 'url': film_url, 'title': _clean_title(title),
                          'title_norm': _norm_title(title), 'thumb': thumb,
                          'source': 'hqporner', 'streams': []})
        _cache.set(ck, films, 4 * 3600)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/HQP] movies error: %s' % e, xbmc.LOGWARNING)
        return []


def _hqporner_film_detail(slug, url):
    """Fetch hqporner.com detail page and extract direct MP4 video URL."""
    ck = 'hqporner_detail_%s' % slug[:60]
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        html = _get(url)
        title = ''
        m = re.search(r'<h1[^>]*>([^<]+)<', html, re.IGNORECASE)
        if m:
            title = _clean(m.group(1))
        thumb = ''
        mi = re.search(r'property="og:image"[^>]+content="([^"]+)"', html, re.IGNORECASE)
        if not mi:
            mi = re.search(r'content="([^"]+)"[^>]+property="og:image"', html, re.IGNORECASE)
        if mi:
            thumb = mi.group(1)

        streams = []
        # HQPorner embeds via mydaddy.cc player which has bigcdn.cc MP4s in its JS
        mydaddy = re.findall(r'//mydaddy\.cc/video/[a-f0-9]+/', html, re.IGNORECASE)
        for ifr_path in mydaddy[:1]:
            ifr_url = 'https:' + ifr_path
            try:
                ifr_html = _sess().get(ifr_url, headers={'Referer': HQPORN_BASE + '/'}, timeout=(5, 8)).text
                # Extract highest quality bigcdn.cc MP4 URL from escaped JS
                # e.g.: src=\"//s84.bigcdn.cc/pubs/.../1080.mp4\"
                best = None
                for src_m in re.finditer(
                    r'src=\\["\'](//[a-z0-9]+\.bigcdn\.cc/pubs/[^"\'\\]+\.mp4)[\\"\']',
                    ifr_html, re.IGNORECASE
                ):
                    candidate = src_m.group(1)
                    if best is None:
                        best = candidate
                    elif '1080' in candidate:
                        best = candidate
                    elif '720' in candidate and '1080' not in best:
                        best = candidate
                if best:
                    best_url = ('https:' + best) if best.startswith('//') else best
                    streams.append({'label': '[HQPorner] MP4', 'url': best_url})
            except Exception:
                pass

        film = {
            'id':         'hqp_' + slug,
            'slug':       slug,
            'title':      _clean_title(title or slug.replace('-', ' ').title()),
            'title_norm': _norm_title(title or slug),
            'thumb':      thumb,
            'description': '',
            'url':        url,
            'source':     'hqporner',
            'streams':    streams,
        }
        if streams:
            _cache.set(ck, film, 12 * 3600)
        return film
    except Exception as e:
        xbmc.log('[Starfleet/HQP] detail error (%s): %s' % (slug, e), xbmc.LOGWARNING)
        return None


def get_hqporner_category_movies(category_url, page=1, limit=20):
    """Real, playable HQPorner results for a genre/category match in the
    unified Adult search box (e.g. "threesome"/"group" matching HQPorner's
    own "Threesome"/"Group Sex" categories — see afdb_router.py's
    _adult_unified_search_data). _hqporner_movies() only returns list-page
    stubs with streams:[] (a detail fetch is needed per item to populate a
    real stream, same as every other HQPorner listing in this codebase) -
    bounded here the same way _verify_stream_sources elsewhere already
    does it, capped to `limit` items so a broad category doesn't pay for
    a full-page detail fetch when the search screen only shows a handful."""
    from concurrent.futures import ThreadPoolExecutor, as_completed
    stubs = _hqporner_movies(category_url, page)[:limit]
    if not stubs:
        return []
    films = []
    pool = ThreadPoolExecutor(max_workers=min(len(stubs), 16))
    try:
        futures = {pool.submit(_hqporner_film_detail, s['slug'], s['url']): s for s in stubs}
        for future in as_completed(futures, timeout=12):
            try:
                film = future.result()
                if film and film.get('streams'):
                    films.append(film)
            except Exception as e:
                xbmc.log('[Starfleet/HQP] category detail error: %s' % e, xbmc.LOGWARNING)
    except Exception as e:
        xbmc.log('[Starfleet/HQP] category detail timeout: %s' % e, xbmc.LOGWARNING)
    finally:
        pool.shutdown(wait=False)
    return films


def _search_hqporner_films(title, page=1):
    """Search hqporner.com and return matched film dicts with streams.
    `page` is accepted (for a uniform call signature with every other
    search_fn in search_by_title) but deliberately NOT threaded into the
    URL: confirmed live 2026-08-14 that appending '&page=2' to this site's
    /?search= results returns the SAME first-page items (46/46 overlap on
    a real query) — the pagination widget shown on a search-results page
    turned out to be a generic sitewide '/hdporn/N' browse link that
    doesn't carry the search query at all, not a real paginated search.
    Left on page 1 only rather than faking pagination that doesn't work."""
    from urllib.parse import quote as _quote
    try:
        html = _get(HQPORN_BASE + '/?search=' + _quote(title))
        stubs, seen = [], set()
        for m in re.finditer(
            r'href="(/hdporn/[^"]+)"[^>]*class="[^"]*click-trigger[^"]*"',
            html, re.IGNORECASE
        ):
            path = m.group(1)
            slug = path.strip('/').split('/')[-1]
            film_url = HQPORN_BASE + path
            if slug and slug not in seen:
                seen.add(slug)
                stubs.append({'slug': slug, 'url': film_url})
        if not stubs:
            for m in re.finditer(r'href="(/hdporn/[^"]+\.html)"', html, re.IGNORECASE):
                path = m.group(1)
                slug = path.strip('/').split('/')[-1]
                film_url = HQPORN_BASE + path
                if slug and slug not in seen:
                    seen.add(slug)
                    stubs.append({'slug': slug, 'url': film_url})
    except Exception as e:
        xbmc.log('[Starfleet/HQP] search error: %s' % e, xbmc.LOGWARNING)
        stubs = []
    return _pfetch(stubs, lambda s: _hqporner_film_detail(s['slug'], s['url']))


# ── xvideos.com ────────────────────────────────────────────────────────────
#
# Added 2026-08-14. Listing pages (homepage, search results) share the same
# markup: each item is a <div id="video_<eid>" data-id="..."> block. Splitting
# on that boundary and parsing title/thumb/href within each chunk avoids
# needing to correlate separate numeric ids the way HQPorner's cover_<id>
# images required — confirmed live the div's own data-id and the video URL's
# id are actually different values here, so a shared-id join wouldn't work;
# per-item chunking sidesteps that entirely.
# Detail pages carry the classic html5player.setVideoUrlHigh/setVideoHLS JS
# calls — both confirmed live to serve a real, immediately-playable file
# (206, video/mp4 / real HLS manifest, valid header) with just a matching
# Referer, no session or cookie needed.

XVIDEOS_BASE = 'https://www.xvideos.com'

_RE_XVIDEOS_CHUNK = re.compile(r'(?=<div id="video_[a-z0-9]+" data-id=)')
# Listing pages use /video.<eid>/<num>/<num>/<slug>, but search results
# (confirmed live) use a shorter /video.<eid>/<slug> with no numeric
# segments at all — this function is shared by both, so the path match
# can't require them.
_RE_XVIDEOS_LINK = re.compile(r'<p class="title"><a href="(/video\.[a-z0-9]+/[^"]+)" title="([^"]+)"')
_RE_XVIDEOS_THUMB = re.compile(r'data-src="(https?://[^"]+\.jpg)"')
_RE_XVIDEOS_HLS = re.compile(r"setVideoHLS\(['\"]([^'\"]+)")
_RE_XVIDEOS_MP4 = re.compile(r"setVideoUrlHigh\(['\"]([^'\"]+)")


def _xvideos_parse_listing(html):
    films = []
    seen = set()
    for chunk in _RE_XVIDEOS_CHUNK.split(html)[1:]:
        m = _RE_XVIDEOS_LINK.search(chunk)
        if not m:
            continue
        path, title = m.group(1), _html_unescape.unescape(m.group(2).strip())
        slug = path.strip('/')
        if slug in seen:
            continue
        seen.add(slug)
        tm = _RE_XVIDEOS_THUMB.search(chunk)
        thumb = tm.group(1) if tm else ''
        films.append({'slug': slug, 'url': XVIDEOS_BASE + path, 'title': _clean_title(title),
                      'title_norm': _norm_title(title), 'thumb': thumb,
                      'source': 'xvideos', 'streams': []})
    return films


def _xvideos_latest(page=1):
    """Homepage listing, paginated via ?p=<page-1> (0-indexed). Cached 2h."""
    ck = 'xvideos_latest_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached or []
    url = XVIDEOS_BASE + ('/' if page <= 1 else '/?p=%d' % (page - 1))
    try:
        films = _xvideos_parse_listing(_get(url))
        _cache.set(ck, films, 2 * 3600)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/XVideos] latest error: %s' % e, xbmc.LOGWARNING)
        return []


def _xvideos_film_detail(slug, url):
    ck = 'xvideos_detail_%s' % slug[:60]
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        html = _get(url)
        streams = []
        hm = _RE_XVIDEOS_HLS.search(html)
        if hm:
            streams.append({'label': '[XVideos] HLS', 'url': hm.group(1)})
        mm = _RE_XVIDEOS_MP4.search(html)
        if mm:
            streams.append({'label': '[XVideos] MP4', 'url': mm.group(1)})
        tm = re.search(r'"name":\s*"([^"]+)"', html)
        title = _html_unescape.unescape(tm.group(1)) if tm else ''
        film = {
            'id': 'xv_' + slug, 'slug': slug,
            'title': _clean_title(title or slug.replace('-', ' ').title()),
            'title_norm': _norm_title(title or slug),
            'thumb': '', 'description': '', 'url': url, 'source': 'xvideos', 'streams': streams,
        }
        if streams:
            _cache.set(ck, film, 6 * 3600)
        return film
    except Exception as e:
        xbmc.log('[Starfleet/XVideos] detail error (%s): %s' % (slug, e), xbmc.LOGWARNING)
        return None


def _search_xvideos_films(title, page=1):
    """Confirmed live 2026-08-14: search results use the exact same
    '&p=<page-1>' (0-indexed) pagination param as the homepage listing —
    page 2 (p=1) came back with a disjoint set of videos vs page 1."""
    from urllib.parse import quote as _quote
    url = XVIDEOS_BASE + '/?k=' + _quote(title)
    if page > 1:
        url += '&p=%d' % (page - 1)
    try:
        return _xvideos_parse_listing(_get(url))
    except Exception as e:
        xbmc.log('[Starfleet/XVideos] search error: %s' % e, xbmc.LOGWARNING)
        return []


# ── xnxx.com ───────────────────────────────────────────────────────────────
#
# Added 2026-08-14. Sister site to xvideos.com, same tech stack (same
# html5player.setVideoUrlHigh JS call on detail pages — confirmed live
# playable, 206/video-mp4/valid header). The homepage itself is JS-rendered
# (confirmed live: static HTML has no video links at all), but category
# pages like /best are plain static HTML with a real listing and a real
# "Next" pagination link, so those are used as the browse entry point
# instead of the homepage.

XNXX_BASE = 'https://www.xnxx.com'

# Search-result pages (confirmed live) use a completely different item
# wrapper (id="video_<eid>" data-id="...", the same "mozaique" markup
# xvideos.com's search results also use — same underlying platform) instead
# of the regular listing page's id="video-thumb-<n>", and the title link
# there has no class="title" attribute at all — both forms need matching
# since this function is shared by listing AND search.
_RE_XNXX_CHUNK = re.compile(r'(?=<div\s*\n?\tid="video-thumb-\d+")|(?=<div id="video_[a-z0-9]+" data-id=)')
_RE_XNXX_LINK = re.compile(r'<a(?: class="title")? href="(/video-[a-z0-9]+/[^"]+)" title="([^"]+)"')
_RE_XNXX_THUMB = re.compile(r'data-src="(https?://[^"]+\.jpg)"')
_RE_XNXX_MP4 = re.compile(r"setVideoUrlHigh\(['\"]([^'\"]+)")


def _xnxx_parse_listing(html):
    films = []
    seen = set()
    for chunk in _RE_XNXX_CHUNK.split(html)[1:]:
        m = _RE_XNXX_LINK.search(chunk)
        if not m:
            continue
        path, title = m.group(1), _html_unescape.unescape(m.group(2).strip())
        slug = path.strip('/')
        if slug in seen:
            continue
        seen.add(slug)
        tm = _RE_XNXX_THUMB.search(chunk)
        thumb = tm.group(1) if tm else ''
        films.append({'slug': slug, 'url': XNXX_BASE + path, 'title': _clean_title(title),
                      'title_norm': _norm_title(title), 'thumb': thumb,
                      'source': 'xnxx', 'streams': []})
    return films


def _xnxx_latest(page=1):
    """/best category listing. Cached 2h. Pagination beyond page 1 isn't a
    simple page number on this site (it's a date-bucketed path the site
    picks itself) — page>1 requests are served the same first page rather
    than guessing a wrong date bucket, matching this file's fail-soft
    pattern elsewhere for anything not cleanly parametrisable."""
    ck = 'xnxx_latest_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached or []
    try:
        films = _xnxx_parse_listing(_get(XNXX_BASE + '/best'))
        _cache.set(ck, films, 2 * 3600)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/XNXX] latest error: %s' % e, xbmc.LOGWARNING)
        return []


def _xnxx_film_detail(slug, url):
    ck = 'xnxx_detail_%s' % slug[:60]
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        html = _get(url)
        streams = []
        mm = _RE_XNXX_MP4.search(html)
        if mm:
            streams.append({'label': '[XNXX] MP4', 'url': mm.group(1)})
        tm = re.search(r'<h2[^>]*>([^<]+)</h2>', html)
        title = _html_unescape.unescape(tm.group(1).strip()) if tm else ''
        film = {
            'id': 'xnxx_' + slug, 'slug': slug,
            'title': _clean_title(title or slug.replace('-', ' ').title()),
            'title_norm': _norm_title(title or slug),
            'thumb': '', 'description': '', 'url': url, 'source': 'xnxx', 'streams': streams,
        }
        if streams:
            _cache.set(ck, film, 6 * 3600)
        return film
    except Exception as e:
        xbmc.log('[Starfleet/XNXX] detail error (%s): %s' % (slug, e), xbmc.LOGWARNING)
        return None


def _search_xnxx_films(title, page=1):
    """Confirmed live 2026-08-14: unlike /best (see _xnxx_latest's own
    "not cleanly parametrisable" note), search results DO paginate
    cleanly, via a '/search/<query>/<page-1>' (0-indexed) path segment —
    confirmed both by the site's own rendered pagination links and by a
    real page1-vs-page2 fetch (0 slug overlap)."""
    from urllib.parse import quote as _quote
    url = XNXX_BASE + '/search/' + _quote(title)
    if page > 1:
        url += '/%d' % (page - 1)
    try:
        return _xnxx_parse_listing(_get(url))
    except Exception as e:
        xbmc.log('[Starfleet/XNXX] search error: %s' % e, xbmc.LOGWARNING)
        return []


# ── pornhub.com ────────────────────────────────────────────────────────────
#
# Added 2026-08-14. Listing item blocks are <div class="pcVideoListItem...
# data-video-vkey="...">. Detail-page stream URLs are short-lived signed
# tokens (validfrom/validto ~2h window, confirmed live) — resolved fresh at
# play time same as every other source here, never cached long-term.

PORNHUB_BASE = 'https://www.pornhub.com'

# PornHub started intermittently (roughly half the time, confirmed live
# across dozens of samples) serving a JS math-puzzle challenge page instead
# of real content: it hands back a 'p' seed, an 's' value, and 5 randomized
# "if ((s >> bit) & 1) p += A*B; else p -= C*D;" clauses (bit positions,
# operand values, and even the sign of the final adjustment all vary per
# request — the clauses are further scrambled with junk /*...*/ comments
# splitting individual tokens), then sets a cookie to the smallest prime
# factor of the final p alongside p/factor and reloads. No real crypto here
# — it's solvable in plain Python with no JS engine, same as this session's
# eporner hash and txxx literal-escape fixes. Once solved and the resulting
# KEY cookie is set on the SHARED session _sess() returns, every subsequent
# PornHub request (including the many concurrent ones _verify_stream_sources
# fires) reuses it and never gets re-challenged again (confirmed live: 0/8
# follow-up requests re-challenged after one solve).
_RE_PH_COMMENT = re.compile(r'/\*.*?\*/', re.DOTALL)
_RE_PH_WS = re.compile(r'\s+')
_RE_PH_SEED = re.compile(r'varp=(-?\d+);vars=(\d+);')
_RE_PH_CLAUSE = re.compile(r'if\(\(s>>(\d+)\)&1\)p\+=(-?\d+)\*(-?\d+);elsep-=(-?\d+)\*(-?\d+);')
_RE_PH_FINAL = re.compile(r'p([+-])=(-?\d+);n=leastFactor')
_RE_PH_COOKIE_TAIL = re.compile(r'document\.cookie="KEY="\+n\+"\*"\+p/n\+":"\+s\+":(\d+):(\d+)')


def _pornhub_least_factor(n):
    if n == 0:
        return 0
    if n % 1 or n * n < 2:
        return 1
    if n % 2 == 0:
        return 2
    if n % 3 == 0:
        return 3
    if n % 5 == 0:
        return 5
    m = int(n ** 0.5)
    i = 7
    while i <= m:
        for off in (0, 4, 6, 10, 12, 16, 22, 24):
            if n % (i + off) == 0:
                return i + off
        i += 30
    return n


def _pornhub_solve_challenge(html):
    js = _RE_PH_WS.sub('', _RE_PH_COMMENT.sub('', html))
    pm = _RE_PH_SEED.search(js)
    if not pm:
        return None
    p, s = int(pm.group(1)), int(pm.group(2))
    for bit, a1, a2, b1, b2 in _RE_PH_CLAUSE.findall(js):
        if (s >> int(bit)) & 1:
            p += int(a1) * int(a2)
        else:
            p -= int(b1) * int(b2)
    fm = _RE_PH_FINAL.search(js)
    if not fm:
        return None
    p = p + int(fm.group(2)) if fm.group(1) == '+' else p - int(fm.group(2))
    n = _pornhub_least_factor(p)
    if not n:
        return None
    cm = _RE_PH_COOKIE_TAIL.search(js)
    if not cm:
        return None
    return '%d*%d:%d:%s:%s' % (n, p // n, s, cm.group(1), cm.group(2))


def _pornhub_get(url, timeout=(5, 8)):
    """_get(), but transparently solves PornHub's own JS challenge (see
    above) if it gets served one, and retries with the resulting cookie —
    up to 2 solve attempts before giving up and returning whatever HTML it
    last got (same fail-open behavior as every other scraper here)."""
    sess = _sess()
    html = ''
    for _ in range(3):
        r = sess.get(url, timeout=timeout)
        r.raise_for_status()
        html = r.text
        if 'leastFactor' not in html:
            return html
        key = _pornhub_solve_challenge(html)
        if not key:
            return html
        sess.cookies.set('KEY', key, domain='.pornhub.com')
    return html


_RE_PORNHUB_CHUNK = re.compile(r'(?=<li class="pcVideoListItem)')
_RE_PORNHUB_LINK = re.compile(r'href="(/view_video\.php\?viewkey=[^"]+)" title="([^"]+)"')
_RE_PORNHUB_THUMB = re.compile(r'<img\s+[^>]*src="(https?://[^"]+)"')
_RE_PORNHUB_MP4 = re.compile(r'https://ev[^"\'\\]*\.phncdn\.com/[^"\'\\]+\.mp4\?[^"\'\\]+')


def _pornhub_parse_listing(html):
    films = []
    seen = set()
    for chunk in _RE_PORNHUB_CHUNK.split(html)[1:]:
        m = _RE_PORNHUB_LINK.search(chunk)
        if not m:
            continue
        path, title = m.group(1), _html_unescape.unescape(m.group(2).strip())
        slug = re.search(r'viewkey=([a-z0-9]+)', path)
        slug = slug.group(1) if slug else path
        if slug in seen:
            continue
        seen.add(slug)
        tm = _RE_PORNHUB_THUMB.search(chunk)
        thumb = tm.group(1) if tm else ''
        films.append({'slug': slug, 'url': PORNHUB_BASE + path, 'title': _clean_title(title),
                      'title_norm': _norm_title(title), 'thumb': thumb,
                      'source': 'pornhub', 'streams': []})
    return films


def _pornhub_latest(page=1):
    ck = 'pornhub_latest_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached or []
    url = PORNHUB_BASE + ('/' if page <= 1 else '/video?page=%d' % page)
    try:
        films = _pornhub_parse_listing(_pornhub_get(url))
        _cache.set(ck, films, 2 * 3600)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/PornHub] latest error: %s' % e, xbmc.LOGWARNING)
        return []


def _pornhub_film_detail(slug, url):
    # Never cached — the mp4 tokens expire within ~2h, so a cache hit would
    # frequently hand back an already-dead link.
    try:
        html = _pornhub_get(url)
        streams = []
        best = {}
        for m in _RE_PORNHUB_MP4.finditer(html):
            u = m.group(0).replace('&amp;', '&')
            qm = re.search(r'/(\d+)P_', u)
            q = int(qm.group(1)) if qm else 0
            best[q] = u
        for q in sorted(best.keys(), reverse=True)[:3]:
            # Confirmed live: this CDN 404s with no Referer at all (unlike
            # every other site added alongside this one) — 'referer' is
            # picked up by afdb_router's generic scene-site play handler
            # and pipe-appended to the final URL Kodi actually opens.
            streams.append({'label': '[PornHub] %dp' % q, 'url': best[q], 'referer': PORNHUB_BASE + '/'})
        tm = re.search(r'<h1[^>]*>([^<]+)</h1>', html)
        title = _html_unescape.unescape(tm.group(1).strip()) if tm else ''
        return {
            'id': 'ph_' + slug, 'slug': slug,
            'title': _clean_title(title or slug),
            'title_norm': _norm_title(title or slug),
            'thumb': '', 'description': '', 'url': url, 'source': 'pornhub', 'streams': streams,
        }
    except Exception as e:
        xbmc.log('[Starfleet/PornHub] detail error (%s): %s' % (slug, e), xbmc.LOGWARNING)
        return None


def _search_pornhub_films(title, page=1):
    """Confirmed live 2026-08-14: '&page=N' on the search endpoint returns
    a genuinely different result set (0 slug overlap page1 vs page2)."""
    from urllib.parse import quote as _quote
    url = PORNHUB_BASE + '/video/search?search=' + _quote(title)
    if page > 1:
        url += '&page=%d' % page
    try:
        return _pornhub_parse_listing(_pornhub_get(url))
    except Exception as e:
        xbmc.log('[Starfleet/PornHub] search error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Shared Aylo-family stream extraction (YouPorn, Tube8, Thumbzilla) ─────────
#
# All three sites below share the exact same watch-page structure: a
# mediaDefinition entry pointing at /media/mp4/?s=<token>, which itself
# returns THIS video's own real, full-length quality options as JSON.
# Matching raw *.mp4 CDN URLs directly out of the watch page's own HTML (the
# original approach for all three) picks up unrelated ~5-10s preview clips
# from the "related videos" sidebar instead — confirmed live as the actual
# root cause of streams playing as tiny clips instead of the real video.

_RE_AYLO_MEDIA_MP4_URL = re.compile(r'"format":"mp4","videoUrl":"([^"]+)"')


def _aylo_media_streams(html, base_url, label):
    streams = []
    mm = _RE_AYLO_MEDIA_MP4_URL.search(html)
    if not mm:
        return streams
    media_url = mm.group(1).replace('\\/', '/')
    if media_url.startswith('/'):
        media_url = base_url + media_url
    try:
        qdata = json.loads(_get(media_url))
        best = {}
        for item in qdata:
            if item.get('format') != 'mp4':
                continue
            q = int(item.get('quality') or 0)
            vurl = (item.get('videoUrl') or '').replace('\\/', '/')
            if vurl:
                best[q] = vurl
        for q in sorted(best.keys(), reverse=True)[:3]:
            streams.append({'label': '[%s] %dp' % (label, q), 'url': best[q],
                             'referer': base_url + '/'})
    except Exception as e:
        xbmc.log('[Starfleet/Aylo] media token error (%s): %s' % (base_url, e), xbmc.LOGWARNING)
    return streams


# ── youporn.com ────────────────────────────────────────────────────────────
#
# Added 2026-08-14. Same CDN family as PornHub (both Aylo-owned, same
# validfrom/validto short-lived token scheme on stream URLs — never cached
# long-term for the same reason).

YOUPORN_BASE = 'https://www.youporn.com'

_RE_YOUPORN_CHUNK = re.compile(r'(?=<article class="video-box)')
_RE_YOUPORN_ARIA = re.compile(r'aria-label="([^"]+)"')
_RE_YOUPORN_LINK = re.compile(r'href="(/watch/\d+[^"]*)"')
_RE_YOUPORN_THUMB = re.compile(r'data-src="(https?://[^"]+\.jpg)"')
# Stream extraction: see _aylo_media_streams above.
_RE_YOUPORN_MEDIA_MP4_URL = re.compile(r'"format":"mp4","videoUrl":"([^"]+)"')


def _youporn_parse_listing(html):
    films = []
    seen = set()
    for chunk in _RE_YOUPORN_CHUNK.split(html)[1:]:
        lm = _RE_YOUPORN_LINK.search(chunk)
        am = _RE_YOUPORN_ARIA.search(chunk)
        if not lm or not am:
            continue
        path, title = lm.group(1), _html_unescape.unescape(am.group(1).strip())
        slug = re.search(r'/watch/(\d+)', path)
        slug = slug.group(1) if slug else path
        if slug in seen:
            continue
        seen.add(slug)
        tm = _RE_YOUPORN_THUMB.search(chunk)
        thumb = tm.group(1) if tm else ''
        films.append({'slug': slug, 'url': YOUPORN_BASE + path, 'title': _clean_title(title),
                      'title_norm': _norm_title(title), 'thumb': thumb,
                      'source': 'youporn', 'streams': []})
    return films


def _youporn_latest(page=1):
    ck = 'youporn_latest_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached or []
    url = YOUPORN_BASE + ('/' if page <= 1 else '/?page=%d' % page)
    try:
        films = _youporn_parse_listing(_get(url))
        _cache.set(ck, films, 2 * 3600)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/YouPorn] latest error: %s' % e, xbmc.LOGWARNING)
        return []


def _youporn_film_detail(slug, url):
    try:
        html = _get(url)
        streams = _aylo_media_streams(html, YOUPORN_BASE, 'YouPorn')
        am = re.search(r'aria-label="([^"]+)"', html)
        title = _html_unescape.unescape(am.group(1).strip()) if am else ''
        return {
            'id': 'yp_' + slug, 'slug': slug,
            'title': _clean_title(title or slug),
            'title_norm': _norm_title(title or slug),
            'thumb': '', 'description': '', 'url': url, 'source': 'youporn', 'streams': streams,
        }
    except Exception as e:
        xbmc.log('[Starfleet/YouPorn] detail error (%s): %s' % (slug, e), xbmc.LOGWARNING)
        return None


def _search_youporn_films(title, page=1):
    from urllib.parse import quote as _quote
    # Confirmed live: /search/<query>/ 404s — the site's own search box
    # (id="headerSearch") posts to /search/?query=<q>, a query param not a
    # path segment.
    # Pagination confirmed live 2026-08-14: same '&page=N' the listing uses
    # (_youporn_latest) also works on the search endpoint (0 slug overlap
    # page1 vs page2).
    url = YOUPORN_BASE + '/search/?query=' + _quote(title)
    if page > 1:
        url += '&page=%d' % page
    try:
        return _youporn_parse_listing(_get(url))
    except Exception as e:
        xbmc.log('[Starfleet/YouPorn] search error: %s' % e, xbmc.LOGWARNING)
        return []


# ── xhamster.com ───────────────────────────────────────────────────────────
#
# Added 2026-08-14. The whole listing lives as a clean embedded JSON blob
# (videoThumbProps) rather than scattered HTML tags — far more reliable to
# parse than the other sites here. Detail pages serve a genuine HLS master
# playlist directly (confirmed live: 200, application/vnd.apple.mpegurl,
# real quality variants) with no token/session needed beyond a matching
# Referer.

XHAMSTER_BASE = 'https://xhamster.com'

_RE_XHAMSTER_ITEM = re.compile(
    r'"title":"((?:[^"\\]|\\.)+)".*?"pageURL":"((?:[^"\\]|\\.)+)".*?"thumbURL":"((?:[^"\\]|\\.)+)"'
)
_RE_XHAMSTER_HLS = re.compile(r'https://video-nss\.xhcdn\.com/[^"\'\\]+\.m3u8[^"\'\\]*')


def _xhamster_unescape(s):
    return _html_unescape.unescape(s.replace('\\/', '/').replace('\\u0022', '"').replace('\\\'', "'"))


def _xhamster_parse_listing(html):
    films = []
    seen = set()
    for title, page_url, thumb in _RE_XHAMSTER_ITEM.findall(html):
        page_url = _xhamster_unescape(page_url)
        title = _xhamster_unescape(title)
        thumb = _xhamster_unescape(thumb)
        slug = page_url.rstrip('/').split('/')[-1]
        if not slug or slug in seen:
            continue
        seen.add(slug)
        films.append({'slug': slug, 'url': page_url, 'title': _clean_title(title),
                      'title_norm': _norm_title(title), 'thumb': thumb,
                      'source': 'xhamster', 'streams': []})
    return films


def _xhamster_latest(page=1):
    ck = 'xhamster_latest_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached or []
    url = XHAMSTER_BASE + ('/' if page <= 1 else '/?page=%d' % page)
    try:
        films = _xhamster_parse_listing(_get(url))
        _cache.set(ck, films, 2 * 3600)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/xHamster] latest error: %s' % e, xbmc.LOGWARNING)
        return []


def _xhamster_film_detail(slug, url):
    ck = 'xhamster_detail_%s' % slug[:60]
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        html = _get(url)
        streams = []
        hm = _RE_XHAMSTER_HLS.search(html)
        if hm:
            streams.append({'label': '[xHamster] HLS', 'url': _xhamster_unescape(hm.group(0))})
        tm = re.search(r'"title":"((?:[^"\\]|\\.)+)"', html)
        title = _xhamster_unescape(tm.group(1)) if tm else ''
        film = {
            'id': 'xh_' + slug, 'slug': slug,
            'title': _clean_title(title or slug.replace('-', ' ').title()),
            'title_norm': _norm_title(title or slug),
            'thumb': '', 'description': '', 'url': url, 'source': 'xhamster', 'streams': streams,
        }
        if streams:
            _cache.set(ck, film, 6 * 3600)
        return film
    except Exception as e:
        xbmc.log('[Starfleet/xHamster] detail error (%s): %s' % (slug, e), xbmc.LOGWARNING)
        return None


def _search_xhamster_films(title, page=1):
    """Confirmed live 2026-08-14: same '?page=N' the listing uses
    (_xhamster_latest) also works on /search/<query> — mostly disjoint
    result set page1 vs page2 (46/48 non-overlapping)."""
    from urllib.parse import quote as _quote
    url = XHAMSTER_BASE + '/search/' + _quote(title)
    if page > 1:
        url += '?page=%d' % page
    try:
        return _xhamster_parse_listing(_get(url))
    except Exception as e:
        xbmc.log('[Starfleet/xHamster] search error: %s' % e, xbmc.LOGWARNING)
        return []


# ── xerotica.com ───────────────────────────────────────────────────────────
#
# Added 2026-08-14. Confirmed live: direct mp4 URLs need no token/session,
# just a matching Referer — same as xvideos.

XEROTICA_BASE = 'https://www.xerotica.com'

_RE_XEROTICA_LINK = re.compile(
    r'<a href="(https://www\.xerotica\.com/video/[^"]+-\d+\.html)" title="([^"]+)">'
)
_RE_XEROTICA_THUMB = re.compile(r'src="(https?://cdn-media\.xerotica\.com/thumbs/[^"]+\.jpg)"')
_RE_XEROTICA_MP4 = re.compile(r'https://cdn-media\.xerotica\.com/videos/[^"\'\\]+\.mp4\?[^"\'\\]+')


def _xerotica_parse_listing(html):
    films = []
    seen = set()
    items = list(_RE_XEROTICA_LINK.finditer(html))
    for i, m in enumerate(items):
        url, title = m.group(1), _html_unescape.unescape(m.group(2).strip())
        slug = url.rstrip('/').split('/')[-1].rsplit('.html', 1)[0]
        if slug in seen:
            continue
        seen.add(slug)
        window_start = items[i - 1].end() if i > 0 else max(0, m.start() - 1200)
        chunk = html[window_start:m.start()]
        tm = _RE_XEROTICA_THUMB.search(chunk) or _RE_XEROTICA_THUMB.search(html[max(0, m.start() - 1200):m.start()])
        thumb = tm.group(1) if tm else ''
        films.append({'slug': slug, 'url': url, 'title': _clean_title(title),
                      'title_norm': _norm_title(title), 'thumb': thumb,
                      'source': 'xerotica', 'streams': []})
    return films


def _xerotica_latest(page=1):
    ck = 'xerotica_latest_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached or []
    url = XEROTICA_BASE + ('/' if page <= 1 else '/page%d.html' % page)
    try:
        films = _xerotica_parse_listing(_get(url))
        _cache.set(ck, films, 2 * 3600)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/Xerotica] latest error: %s' % e, xbmc.LOGWARNING)
        return []


def _xerotica_film_detail(slug, url):
    ck = 'xerotica_detail_%s' % slug[:60]
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        html = _get(url)
        streams = []
        best = {}
        for m in _RE_XEROTICA_MP4.finditer(html):
            u = m.group(0)
            qm = re.search(r'[?&]ri=(\d+)k', u)
            q = int(qm.group(1)) if qm else 0
            best[q] = u
        for q in sorted(best.keys(), reverse=True)[:3]:
            # Confirmed live: this CDN 403s with no Referer at all — picked
            # up by afdb_router's generic scene-site play handler and
            # pipe-appended to the final URL Kodi actually opens.
            streams.append({'label': '[Xerotica] %dk' % q, 'url': best[q], 'referer': XEROTICA_BASE + '/'})
        tm = re.search(r'<h1[^>]*>([^<]+)</h1>', html)
        title = _html_unescape.unescape(tm.group(1).strip()) if tm else ''
        film = {
            'id': 'xe_' + slug, 'slug': slug,
            'title': _clean_title(title or slug.replace('-', ' ').title()),
            'title_norm': _norm_title(title or slug),
            'thumb': '', 'description': '', 'url': url, 'source': 'xerotica', 'streams': streams,
        }
        if streams:
            _cache.set(ck, film, 6 * 3600)
        return film
    except Exception as e:
        xbmc.log('[Starfleet/Xerotica] detail error (%s): %s' % (slug, e), xbmc.LOGWARNING)
        return None


def _search_xerotica_films(title, page=1):
    from urllib.parse import quote as _quote
    # Confirmed live: /search.html?q= 404s — the site's own search form
    # posts to /searchgate.php?q=<q> instead, which 302s to a real
    # '/search/<query>/' listing page. That listing page's own rendered
    # pagination links (confirmed live 2026-08-14) are relative
    # 'page<N>.html' hrefs, i.e. '/search/<query>/page2.html' etc — NOT
    # '&page=N' on searchgate.php itself (tried first; came back byte-for-
    # byte identical to page 1, 55/55 slug overlap). Page>1 requests build
    # that URL directly instead of relying on the searchgate.php redirect
    # (which has no page param support at all), confirmed live 0 slug
    # overlap page1 vs page2 doing it this way.
    if page <= 1:
        url = XEROTICA_BASE + '/searchgate.php?q=' + _quote(title)
    else:
        url = XEROTICA_BASE + '/search/' + _quote(title) + '/page%d.html' % page
    try:
        return _xerotica_parse_listing(_get(url))
    except Exception as e:
        xbmc.log('[Starfleet/Xerotica] search error: %s' % e, xbmc.LOGWARNING)
        return []


# ── redtube.com ────────────────────────────────────────────────────────────
#
# Added 2026-08-14. Same Aylo/MindGeek stack as pornhub/youporn (this file's
# other two Aylo-family sources), but the listing's own item-id and the
# quality-stream ids embedded further down the SAME item block are two
# different internal numbers -- confirmed live that positionally grabbing
# "the next mp4 URL after this item's id" actually grabs a DIFFERENT,
# unrelated related-video's stream. A backreference (\1) ties the href back
# to the exact id the block started with, which a fixed-offset window can't
# guarantee. The detail page doesn't embed a playable URL directly either
# (confirmed live) -- it embeds a base64 token consumed by a same-origin
# /media/mp4?s=<token> JSON endpoint that hands back the real signed CDN
# URLs (verified live: real 1080p, 206/video-mp4/valid header).

REDTUBE_BASE = 'https://www.redtube.com'

_RE_REDTUBE_ITEM = re.compile(
    r'data-video-id="(\d+)"[\s\S]{1,800}?href="/\1"[\s\S]{1,800}?data-o_thumb="([^"]+)"[\s\S]{0,800}?alt="([^"]+)"'
)
_RE_REDTUBE_TOKEN = re.compile(r'"format":"mp4","videoUrl":"(\\/media\\/mp4\?s=[^"]+)"')


def _redtube_parse_listing(html):
    films = []
    seen = set()
    for vid, thumb, title in _RE_REDTUBE_ITEM.findall(html):
        if vid in seen:
            continue
        seen.add(vid)
        title = _html_unescape.unescape(title.strip())
        films.append({'slug': vid, 'url': REDTUBE_BASE + '/' + vid, 'title': _clean_title(title),
                      'title_norm': _norm_title(title), 'thumb': thumb,
                      'source': 'redtube', 'streams': []})
    return films


def _redtube_latest(page=1):
    ck = 'redtube_latest_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached or []
    url = REDTUBE_BASE + ('/' if page <= 1 else '/?page=%d' % page)
    try:
        films = _redtube_parse_listing(_get(url))
        _cache.set(ck, films, 2 * 3600)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/RedTube] latest error: %s' % e, xbmc.LOGWARNING)
        return []


def _redtube_film_detail(slug, url):
    # Never cached — the mp4 tokens this resolves to expire within ~2h.
    try:
        html = _get(url)
        tm = _RE_REDTUBE_TOKEN.search(html)
        streams = []
        if tm:
            api_path = tm.group(1).replace('\\/', '/')
            try:
                qualities = _sess().get(REDTUBE_BASE + api_path, timeout=10,
                                         headers={'User-Agent': 'Mozilla/5.0', 'Referer': url}).json()
                best = {}
                for q in qualities:
                    qi = int(q.get('quality') or 0)
                    if q.get('videoUrl'):
                        best[qi] = q['videoUrl']
                for qi in sorted(best.keys(), reverse=True)[:3]:
                    streams.append({'label': '[RedTube] %sp' % qi, 'url': best[qi]})
            except Exception as e:
                xbmc.log('[Starfleet/RedTube] media API error: %s' % e, xbmc.LOGWARNING)
        h1 = re.search(r'<h1[^>]*>([^<]+)</h1>', html)
        title = _html_unescape.unescape(h1.group(1).strip()) if h1 else ''
        return {
            'id': 'rt_' + slug, 'slug': slug,
            'title': _clean_title(title or slug),
            'title_norm': _norm_title(title or slug),
            'thumb': '', 'description': '', 'url': url, 'source': 'redtube', 'streams': streams,
        }
    except Exception as e:
        xbmc.log('[Starfleet/RedTube] detail error (%s): %s' % (slug, e), xbmc.LOGWARNING)
        return None


def _search_redtube_films(title, page=1):
    """Confirmed live 2026-08-14: same '&page=N' the listing uses
    (_redtube_latest) also works on /?search= (mostly disjoint result set,
    3/32 overlap page1 vs page2)."""
    from urllib.parse import quote as _quote
    url = REDTUBE_BASE + '/?search=' + _quote(title)
    if page > 1:
        url += '&page=%d' % page
    try:
        return _redtube_parse_listing(_get(url))
    except Exception as e:
        xbmc.log('[Starfleet/RedTube] search error: %s' % e, xbmc.LOGWARNING)
        return []


# ── tube8.com ──────────────────────────────────────────────────────────────
#
# Added 2026-08-14. Same <article class="video-box"> / aria-label listing
# markup as youporn.py above (same Aylo family) — reuses that exact chunking
# approach with tube8's own href/CDN domain. Confirmed live: real playable
# mp4 (206/video-mp4/valid header), same validfrom/validto token scheme.

TUBE8_BASE = 'https://www.tube8.com'

_RE_TUBE8_CHUNK = re.compile(r'(?=<article class="video-box)')
_RE_TUBE8_ARIA = re.compile(r'aria-label="([^"]+)"')
_RE_TUBE8_LINK = re.compile(r'href="(/porn-video/\d+/)"')
_RE_TUBE8_THUMB = re.compile(r'data-src="(https?://[^"]+)"')


def _tube8_parse_listing(html):
    films = []
    seen = set()
    for chunk in _RE_TUBE8_CHUNK.split(html)[1:]:
        lm = _RE_TUBE8_LINK.search(chunk)
        am = _RE_TUBE8_ARIA.search(chunk)
        if not lm or not am:
            continue
        path, title = lm.group(1), _html_unescape.unescape(am.group(1).strip())
        slug = re.search(r'/porn-video/(\d+)/', path).group(1)
        if slug in seen:
            continue
        seen.add(slug)
        tm = _RE_TUBE8_THUMB.search(chunk)
        thumb = tm.group(1) if tm else ''
        films.append({'slug': slug, 'url': TUBE8_BASE + path, 'title': _clean_title(title),
                      'title_norm': _norm_title(title), 'thumb': thumb,
                      'source': 'tube8', 'streams': []})
    return films


def _tube8_latest(page=1):
    ck = 'tube8_latest_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached or []
    url = TUBE8_BASE + ('/' if page <= 1 else '/latest-updates/%d/' % page)
    try:
        films = _tube8_parse_listing(_get(url))
        _cache.set(ck, films, 2 * 3600)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/Tube8] latest error: %s' % e, xbmc.LOGWARNING)
        return []


def _tube8_film_detail(slug, url):
    try:
        html = _get(url)
        streams = _aylo_media_streams(html, TUBE8_BASE, 'Tube8')
        am = re.search(r'aria-label="([^"]+)"', html)
        title = _html_unescape.unescape(am.group(1).strip()) if am else ''
        return {
            'id': 't8_' + slug, 'slug': slug,
            'title': _clean_title(title or slug),
            'title_norm': _norm_title(title or slug),
            'thumb': '', 'description': '', 'url': url, 'source': 'tube8', 'streams': streams,
        }
    except Exception as e:
        xbmc.log('[Starfleet/Tube8] detail error (%s): %s' % (slug, e), xbmc.LOGWARNING)
        return None


def _search_tube8_films(title, page=1):
    from urllib.parse import quote as _quote
    # Confirmed live: /search/<query>/ 404s — the site's own search form
    # posts to /searches.html?q=<q> (a different action path AND a query
    # param, not a path segment).
    # Pagination confirmed live 2026-08-14: '&page=N' on that same endpoint
    # returns a fully disjoint result set (0 slug overlap page1 vs page2).
    url = TUBE8_BASE + '/searches.html?q=' + _quote(title)
    if page > 1:
        url += '&page=%d' % page
    try:
        return _tube8_parse_listing(_get(url))
    except Exception as e:
        xbmc.log('[Starfleet/Tube8] search error: %s' % e, xbmc.LOGWARNING)
        return []


# ── thumbzilla.com ─────────────────────────────────────────────────────────
#
# Added 2026-08-14. Same Aylo family markup again, and confirmed live it
# actually shares youporn's own ypncdn.com CDN entirely — same mp4 token
# scheme, same regex reused with thumbzilla's own href/base.

THUMBZILLA_BASE = 'https://www.thumbzilla.com'

_RE_THUMBZILLA_CHUNK = re.compile(r'(?=<article class="video-box)')
_RE_THUMBZILLA_ARIA = re.compile(r'aria-label="([^"]+)"')
_RE_THUMBZILLA_LINK = re.compile(r'href="(/watch/\d+/)"')
_RE_THUMBZILLA_THUMB = re.compile(r'data-src="(https?://[^"]+)"')


def _thumbzilla_parse_listing(html):
    films = []
    seen = set()
    for chunk in _RE_THUMBZILLA_CHUNK.split(html)[1:]:
        lm = _RE_THUMBZILLA_LINK.search(chunk)
        am = _RE_THUMBZILLA_ARIA.search(chunk)
        if not lm or not am:
            continue
        path, title = lm.group(1), _html_unescape.unescape(am.group(1).strip())
        slug = re.search(r'/watch/(\d+)/', path).group(1)
        if slug in seen:
            continue
        seen.add(slug)
        tm = _RE_THUMBZILLA_THUMB.search(chunk)
        thumb = tm.group(1) if tm else ''
        films.append({'slug': slug, 'url': THUMBZILLA_BASE + path, 'title': _clean_title(title),
                      'title_norm': _norm_title(title), 'thumb': thumb,
                      'source': 'thumbzilla', 'streams': []})
    return films


def _thumbzilla_latest(page=1):
    ck = 'thumbzilla_latest_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached or []
    url = THUMBZILLA_BASE + ('/' if page <= 1 else '/?page=%d' % page)
    try:
        films = _thumbzilla_parse_listing(_get(url))
        _cache.set(ck, films, 2 * 3600)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/Thumbzilla] latest error: %s' % e, xbmc.LOGWARNING)
        return []


def _thumbzilla_film_detail(slug, url):
    try:
        html = _get(url)
        streams = _aylo_media_streams(html, THUMBZILLA_BASE, 'Thumbzilla')
        am = re.search(r'aria-label="([^"]+)"', html)
        title = _html_unescape.unescape(am.group(1).strip()) if am else ''
        return {
            'id': 'tz_' + slug, 'slug': slug,
            'title': _clean_title(title or slug),
            'title_norm': _norm_title(title or slug),
            'thumb': '', 'description': '', 'url': url, 'source': 'thumbzilla', 'streams': streams,
        }
    except Exception as e:
        xbmc.log('[Starfleet/Thumbzilla] detail error (%s): %s' % (slug, e), xbmc.LOGWARNING)
        return None


def _search_thumbzilla_films(title, page=1):
    from urllib.parse import quote as _quote
    # Confirmed live: /search/<query>/ 404s — same Aylo search-box pattern
    # as YouPorn, posts to /search/?query=<q>.
    # Pagination confirmed live 2026-08-14: same '&page=N' as YouPorn's own
    # search (0 slug overlap page1 vs page2) — same Aylo backend.
    url = THUMBZILLA_BASE + '/search/?query=' + _quote(title)
    if page > 1:
        url += '&page=%d' % page
    try:
        return _thumbzilla_parse_listing(_get(url))
    except Exception as e:
        xbmc.log('[Starfleet/Thumbzilla] search error: %s' % e, xbmc.LOGWARNING)
        return []


# ── porntrex.com ───────────────────────────────────────────────────────────
#
# Added 2026-08-14. Confirmed live: real get_file mp4 URLs need no
# token/session, just a matching Referer (same as HQPorner's own CDN).

PORNTREX_BASE = 'https://www.porntrex.com'

# The item's own <a> tag actually carries class="thumb ..." — "video-list"
# is a class on its PARENT div, never on the <a> itself (confirmed live on
# both the browse listing and search results pages).
_RE_PORNTREX_LINK = re.compile(
    r'<a href="(https://www\.porntrex\.com/video/(\d+)/[^"]+)"\s+class="thumb[^"]*"'
)
_RE_PORNTREX_THUMB = re.compile(r'data-src="(//[^"]+\.jpg)"')
_RE_PORNTREX_MP4 = re.compile(r'https://www\.porntrex\.com/get_file/[^"\'\\]+\.mp4/')


def _porntrex_parse_listing(html):
    films = []
    seen = set()
    items = list(_RE_PORNTREX_LINK.finditer(html))
    for i, m in enumerate(items):
        url, vid = m.group(1), m.group(2)
        if vid in seen:
            continue
        seen.add(vid)
        window_end = items[i + 1].start() if i + 1 < len(items) else min(len(html), m.end() + 1200)
        chunk = html[m.end():window_end]
        tm = _RE_PORNTREX_THUMB.search(chunk)
        thumb = ('https:' + tm.group(1)) if tm else ''
        am = re.search(r'alt="([^"]+)"', chunk)
        title = _html_unescape.unescape(am.group(1).strip()) if am else url.rstrip('/').split('/')[-1].replace('-', ' ').title()
        films.append({'slug': vid, 'url': url, 'title': _clean_title(title),
                      'title_norm': _norm_title(title), 'thumb': thumb,
                      'source': 'porntrex', 'streams': []})
    return films


def _porntrex_latest(page=1):
    ck = 'porntrex_latest_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached or []
    url = PORNTREX_BASE + ('/' if page <= 1 else '/%d/' % page)
    try:
        films = _porntrex_parse_listing(_get(url))
        _cache.set(ck, films, 2 * 3600)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/Porntrex] latest error: %s' % e, xbmc.LOGWARNING)
        return []


def _porntrex_film_detail(slug, url):
    ck = 'porntrex_detail_%s' % slug[:60]
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        html = _get(url)
        streams = []
        best = {}
        for m in _RE_PORNTREX_MP4.finditer(html):
            u = m.group(0)
            qm = re.search(r'_(\d+)p\.mp4/$', u)
            q = int(qm.group(1)) if qm else 360
            best[q] = u
        for q in sorted(best.keys(), reverse=True)[:3]:
            streams.append({'label': '[Porntrex] %dp' % q, 'url': best[q]})
        tm = re.search(r'<h1[^>]*>([^<]+)</h1>', html)
        title = _html_unescape.unescape(tm.group(1).strip()) if tm else ''
        film = {
            'id': 'ptx_' + slug, 'slug': slug,
            'title': _clean_title(title or slug),
            'title_norm': _norm_title(title or slug),
            'thumb': '', 'description': '', 'url': url, 'source': 'porntrex', 'streams': streams,
        }
        if streams:
            _cache.set(ck, film, 6 * 3600)
        return film
    except Exception as e:
        xbmc.log('[Starfleet/Porntrex] detail error (%s): %s' % (slug, e), xbmc.LOGWARNING)
        return None


def _search_porntrex_films(title, page=1):
    """Confirmed live 2026-08-14: '/search/<query>/<page>/' (a bare page
    number, same style as the listing's own '/%d/' in _porntrex_latest)
    returns a fully disjoint result set (0 slug overlap page1 vs page2)."""
    from urllib.parse import quote as _quote
    url = PORNTREX_BASE + '/search/' + _quote(title) + '/'
    if page > 1:
        url += '%d/' % page
    try:
        return _porntrex_parse_listing(_get(url))
    except Exception as e:
        xbmc.log('[Starfleet/Porntrex] search error: %s' % e, xbmc.LOGWARNING)
        return []


# ── noodlemagazine.com ─────────────────────────────────────────────────────
#
# Added 2026-08-14. Confirmed live: real signed mp4 URLs need no
# token/session beyond a matching Referer.

NOODLEMAGAZINE_BASE = 'https://noodlemagazine.com'

_RE_NOODLE_LINK = re.compile(r'<a href="(/watch/[^"]+)" class="item_link">')
_RE_NOODLE_THUMB = re.compile(r'data-src="(https?://[^"]+\.jpg)"')
_RE_NOODLE_ALT = re.compile(r'alt="([^"]+)"')
_RE_NOODLE_MP4 = re.compile(r'https://cdn\d*\.pvvstream\.pro/videos/[^"\'\\]+\.mp4\?secure=[^"\'\\]+')


def _noodlemagazine_parse_listing(html):
    films = []
    seen = set()
    items = list(_RE_NOODLE_LINK.finditer(html))
    for i, m in enumerate(items):
        path = m.group(1)
        slug = path.rsplit('/', 1)[-1]
        if slug in seen:
            continue
        seen.add(slug)
        window_end = items[i + 1].start() if i + 1 < len(items) else min(len(html), m.end() + 800)
        chunk = html[m.end():window_end]
        tm = _RE_NOODLE_THUMB.search(chunk)
        thumb = tm.group(1) if tm else ''
        am = _RE_NOODLE_ALT.search(chunk)
        title = _html_unescape.unescape(am.group(1).strip()) if am else slug
        films.append({'slug': slug, 'url': NOODLEMAGAZINE_BASE + path, 'title': _clean_title(title),
                      'title_norm': _norm_title(title), 'thumb': thumb,
                      'source': 'noodlemagazine', 'streams': []})
    return films


def _noodlemagazine_latest(page=1):
    ck = 'noodlemagazine_latest_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached or []
    url = NOODLEMAGAZINE_BASE + ('/home' if page <= 1 else '/home?page=%d' % page)
    try:
        films = _noodlemagazine_parse_listing(_get(url))
        _cache.set(ck, films, 2 * 3600)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/NoodleMagazine] latest error: %s' % e, xbmc.LOGWARNING)
        return []


def _noodlemagazine_film_detail(slug, url):
    # Never cached — 'secure=' tokens are timestamp-signed and short-lived.
    try:
        html = _get(url)
        streams = []
        best = {}
        for m in _RE_NOODLE_MP4.finditer(html):
            u = m.group(0)
            qm = re.search(r'_(\d+)p\.mp4', u)
            q = int(qm.group(1)) if qm else 0
            best[q] = u
        for q in sorted(best.keys(), reverse=True)[:3]:
            streams.append({'label': '[NoodleMagazine] %dp' % q, 'url': best[q], 'referer': NOODLEMAGAZINE_BASE + '/'})
        tm = re.search(r'<h1[^>]*>([^<]+)</h1>', html)
        title = _html_unescape.unescape(tm.group(1).strip()) if tm else ''
        return {
            'id': 'nm_' + slug, 'slug': slug,
            'title': _clean_title(title or slug),
            'title_norm': _norm_title(title or slug),
            'thumb': '', 'description': '', 'url': url, 'source': 'noodlemagazine', 'streams': streams,
        }
    except Exception as e:
        xbmc.log('[Starfleet/NoodleMagazine] detail error (%s): %s' % (slug, e), xbmc.LOGWARNING)
        return None


def _search_noodlemagazine_films(title, page=1):
    """`page` is accepted (uniform call signature) but NOT threaded into
    the URL: confirmed live 2026-08-14 this site's /search/<query> already
    404s even at page 1 — the site's own search form has no visible
    'action' and submits via JS to an endpoint this scraper doesn't call
    (pre-existing bug independent of pagination). Left alone rather than
    adding fake pagination on top of an already-broken search."""
    from urllib.parse import quote as _quote
    try:
        return _noodlemagazine_parse_listing(_get(NOODLEMAGAZINE_BASE + '/search/' + _quote(title)))
    except Exception as e:
        xbmc.log('[Starfleet/NoodleMagazine] search error: %s' % e, xbmc.LOGWARNING)
        return []


# ── letmejizz.co ───────────────────────────────────────────────────────────
#
# Added 2026-08-14. Confirmed live: real HLS manifest needs no
# token/session beyond a matching Referer.

LETMEJIZZ_BASE = 'https://www.letmejizz.co'

# Only the first few items on a listing page carry the bare
# <article class="vc"> tag — confirmed live every item after that has an
# extra data-* attribute before the closing '>' (<article class="vc"
# data-...>), which the old exact 'class="vc">' match silently skipped,
# actual root cause of "only pulling 3 videos" (all real pages have 60+).
_RE_LETMEJIZZ_CHUNK = re.compile(r'(?=<article class="vc")')
_RE_LETMEJIZZ_LINK = re.compile(r'<a href="(/video/([a-z0-9]+)/[^"]+)">')
_RE_LETMEJIZZ_THUMB = re.compile(r'data-src="(https?://[^"]+\.jpg)"')
_RE_LETMEJIZZ_TITLE = re.compile(r'<div class="vc-title">([^<]+)</div>')


def _letmejizz_parse_listing(html):
    films = []
    seen = set()
    for chunk in _RE_LETMEJIZZ_CHUNK.split(html)[1:]:
        lm = _RE_LETMEJIZZ_LINK.search(chunk)
        if not lm:
            continue
        path, slug = lm.group(1), lm.group(2)
        if slug in seen:
            continue
        seen.add(slug)
        tm = _RE_LETMEJIZZ_THUMB.search(chunk)
        thumb = tm.group(1) if tm else ''
        titlem = _RE_LETMEJIZZ_TITLE.search(chunk)
        title = _html_unescape.unescape(titlem.group(1).strip()) if titlem else slug
        films.append({'slug': slug, 'url': LETMEJIZZ_BASE + path, 'title': _clean_title(title),
                      'title_norm': _norm_title(title), 'thumb': thumb,
                      'source': 'letmejizz', 'streams': []})
    return films


def _letmejizz_latest(page=1):
    ck = 'letmejizz_latest_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached or []
    url = LETMEJIZZ_BASE + ('/' if page <= 1 else '/%d/' % page)
    try:
        films = _letmejizz_parse_listing(_get(url))
        _cache.set(ck, films, 2 * 3600)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/LetMeJizz] latest error: %s' % e, xbmc.LOGWARNING)
        return []


def _letmejizz_film_detail(slug, url):
    ck = 'letmejizz_detail_%s' % slug[:60]
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        html = _get(url)
        streams = []
        hm = re.search(r'https?://[^"\'\\]+\.m3u8[^"\'\\]*', html)
        if hm:
            streams.append({'label': '[LetMeJizz] HLS', 'url': hm.group(0), 'referer': LETMEJIZZ_BASE + '/'})
        tm = re.search(r'<h1[^>]*>([^<]+)</h1>', html)
        title = _html_unescape.unescape(tm.group(1).strip()) if tm else ''
        film = {
            'id': 'lmj_' + slug, 'slug': slug,
            'title': _clean_title(title or slug),
            'title_norm': _norm_title(title or slug),
            'thumb': '', 'description': '', 'url': url, 'source': 'letmejizz', 'streams': streams,
        }
        if streams:
            _cache.set(ck, film, 6 * 3600)
        return film
    except Exception as e:
        xbmc.log('[Starfleet/LetMeJizz] detail error (%s): %s' % (slug, e), xbmc.LOGWARNING)
        return None


def _search_letmejizz_films(title, page=1):
    from urllib.parse import quote as _quote
    # Confirmed live: /search/<query>/ 404s — the site's own search form
    # (method="get", input name="q") posts to /search/?q=<q>.
    # Pagination confirmed live 2026-08-14 from the search page's own
    # rendered pagination widget (<a href="/search/?q=...&p=2">2</a>) —
    # NOT '&page=N' (tried first; came back byte-identical, 59/59 slug
    # overlap). '&p=N' gave 0 slug overlap page1 vs page2.
    url = LETMEJIZZ_BASE + '/search/?q=' + _quote(title)
    if page > 1:
        url += '&p=%d' % page
    try:
        return _letmejizz_parse_listing(_get(url))
    except Exception as e:
        xbmc.log('[Starfleet/LetMeJizz] search error: %s' % e, xbmc.LOGWARNING)
        return []


# ── eporner.com ────────────────────────────────────────────────────────────
#
# Added 2026-08-14. The site's own JSON-LD contentUrl 403s no matter what
# headers/session/cookies are sent (confirmed live) — this isn't IP-locking,
# it's a computed-hash gate: the detail page embeds a raw 32-hex-char seed,
# which needs to be split into 4 8-hex-char chunks, each parsed as a hex int
# and re-encoded in base36, then concatenated — that's the real "hash" the
# CDN's own /xhr/video/<id> JSON endpoint expects, and once you have it the
# endpoint hands back real signed CDN URLs with no further protection
# (confirmed live: 1080p, 206/video-mp4/valid header). Found by reading a
# working reference implementation (plugin.video.cumination's eporner.py) —
# same technique, ported and independently reverified live before shipping.

EPORNER_BASE = 'https://www.eporner.com'

_RE_EPORNER_ITEM = re.compile(
    r'href="([^"]+)".+?src="(http[^"]+)".+?alt="([^"]+)"',
    re.DOTALL | re.IGNORECASE
)
_RE_EPORNER_VIDHASH = re.compile(r"vid = '(.+?)'.+?hash = '(.+?)'", re.DOTALL | re.IGNORECASE)
_B36_TABLE = '0123456789abcdefghijklmnopqrstuvwxyz'


def _eporner_b36(num):
    if num == 0:
        return _B36_TABLE[0]
    out = ''
    while num:
        out = _B36_TABLE[num % 36] + out
        num //= 36
    return out


def _eporner_parse_listing(html):
    films = []
    seen = set()
    for chunk in html.split('data-vp=')[1:]:
        m = _RE_EPORNER_ITEM.search(chunk)
        if not m:
            continue
        path, thumb, title = m.group(1), m.group(2), _html_unescape.unescape(m.group(3))
        slug = path.rstrip('/').split('/')[-2] if path.rstrip('/').split('/')[-1].startswith('video-') is False else path.rstrip('/').split('/')[-1]
        vid_m = re.search(r'/video-([A-Za-z0-9]+)/', path)
        slug = vid_m.group(1) if vid_m else path
        if slug in seen:
            continue
        seen.add(slug)
        url = path if path.startswith('http') else EPORNER_BASE + path
        films.append({'slug': slug, 'url': url, 'title': _clean_title(title),
                      'title_norm': _norm_title(title), 'thumb': thumb,
                      'source': 'eporner', 'streams': []})
    return films


def _eporner_latest(page=1):
    ck = 'eporner_latest_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached or []
    url = EPORNER_BASE + '/cat/all/' + ('' if page <= 1 else 'page%d/' % page)
    try:
        films = _eporner_parse_listing(_get(url))
        _cache.set(ck, films, 2 * 3600)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/Eporner] latest error: %s' % e, xbmc.LOGWARNING)
        return []


def _eporner_film_detail(slug, url):
    # Never cached — the CDN URLs the xhr endpoint hands back are signed
    # and short-lived.
    try:
        html = _get(url)
        streams = []
        m = _RE_EPORNER_VIDHASH.search(html)
        if m:
            vid, seed = m.group(1), m.group(2)
            computed_hash = ''.join(_eporner_b36(int(seed[lb:lb + 8], 16)) for lb in range(0, 32, 8))
            xhr_url = (EPORNER_BASE + '/xhr/video/' + vid + '?hash=' + computed_hash +
                       '&domain=www.eporner.com&fallback=false&embed=true&supportedFormats=dash,mp4')
            try:
                jdata = _sess().get(xhr_url, timeout=10, headers={'User-Agent': 'Mozilla/5.0', 'Referer': url}).json()
                best = {}
                for q, info in (jdata.get('sources', {}).get('mp4') or {}).items():
                    src = info.get('src')
                    if not src:
                        continue
                    qm = re.search(r'(\d+)', q)
                    qi = int(qm.group(1)) if qm else 0
                    best[qi] = src
                for qi in sorted(best.keys(), reverse=True)[:3]:
                    streams.append({'label': '[Eporner] %dp' % qi, 'url': best[qi]})
            except Exception as e:
                xbmc.log('[Starfleet/Eporner] xhr error: %s' % e, xbmc.LOGWARNING)
        tm = re.search(r'<h1[^>]*>([^<]+)</h1>', html)
        title = _html_unescape.unescape(tm.group(1).strip()) if tm else ''
        return {
            'id': 'ep_' + slug, 'slug': slug,
            'title': _clean_title(title or slug),
            'title_norm': _norm_title(title or slug),
            'thumb': '', 'description': '', 'url': url, 'source': 'eporner', 'streams': streams,
        }
    except Exception as e:
        xbmc.log('[Starfleet/Eporner] detail error (%s): %s' % (slug, e), xbmc.LOGWARNING)
        return None


def _search_eporner_films(title, page=1):
    """Confirmed live 2026-08-14: '/search/<query>/<page>/' (a bare page
    number — unlike _eporner_latest's own '/cat/all/page%d/', the
    /search/ and /tag/ paths this redirects to do NOT use a 'page' prefix,
    confirmed by testing that form first and getting a redirect back to
    plain page 1) returns a fully disjoint result set (0 slug overlap
    page1 vs page2)."""
    from urllib.parse import quote as _quote
    url = EPORNER_BASE + '/search/' + _quote(title) + '/'
    if page > 1:
        url += '%d/' % page
    try:
        return _eporner_parse_listing(_get(url))
    except Exception as e:
        xbmc.log('[Starfleet/Eporner] search error: %s' % e, xbmc.LOGWARNING)
        return []


# ── beeg.com ───────────────────────────────────────────────────────────────
#
# Added 2026-08-14. beeg.com's own homepage is a JS-rendered app shell with
# nothing in its static HTML (confirmed live) — but that JS is itself just
# calling a clean public JSON API at store.externulls.com, which is what's
# actually used here. The full per-video stream info (hls_resources) is
# already present in the SAME listing response, so unlike every other
# source in this file, no separate detail-page fetch is needed at all — the
# "url" field carries the video's own JSON (base64-encoded) instead of a
# fetchable link, and the detail function just decodes it back out. Found
# by reading a working reference implementation (plugin.video.cumination's
# beeg.py); confirmed independently live before shipping.

BEEG_BASE = 'https://store.externulls.com'
BEEG_SITE = 'https://beeg.com'


def _beeg_parse_listing(jdata):
    import base64 as _b64
    films = []
    for video in jdata:
        try:
            fc_facts = video.get('fc_facts') or []
            if not fc_facts:
                continue
            name = ''
            for d in video.get('file', {}).get('data', []):
                if d.get('cd_column') == 'sf_name':
                    name = d.get('cd_value') or ''
            if not name:
                continue
            thumbs = fc_facts[0].get('fc_thumbs') or [0]
            vid_id = video.get('file', {}).get('id')
            thumb = 'https://thumbs.externulls.com/videos/{0}/{1}.webp?size=480x270'.format(vid_id, thumbs[0])
            slug = str(vid_id)
            encoded = _b64.b64encode(json.dumps(video).encode()).decode()
            films.append({'slug': slug, 'url': encoded, 'title': _clean_title(name),
                          'title_norm': _norm_title(name), 'thumb': thumb,
                          'source': 'beeg', 'streams': []})
        except Exception:
            continue
    return films


def _beeg_latest(page=1):
    ck = 'beeg_latest_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached or []
    offset = (page - 1) * 48
    url = BEEG_BASE + '/facts/tag?id=27173&limit=48&offset=%d' % offset
    try:
        jdata = _sess().get(url, timeout=10, headers={'User-Agent': 'Mozilla/5.0', 'Referer': BEEG_SITE + '/'}).json()
        films = _beeg_parse_listing(jdata)
        _cache.set(ck, films, 2 * 3600)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/Beeg] latest error: %s' % e, xbmc.LOGWARNING)
        return []


def _beeg_film_detail(slug, url):
    import base64 as _b64
    try:
        video = json.loads(_b64.b64decode(url).decode())
        fc_facts = video.get('fc_facts') or []
        streams = []
        videos = {}
        if len(fc_facts) == 1:
            videos = (video.get('file', {}).get('hls_resources')
                      or fc_facts[0].get('hls_resources') or {})
        elif fc_facts:
            # multi-part scene — just offer the first part's resources
            # rather than pulling in this addon's separate part-picker UI.
            videos = fc_facts[0].get('hls_resources') or {}
        videos = {k.replace('fl_cdn_', ''): v for k, v in videos.items()}
        best = {}
        for k, v in videos.items():
            if k.isdigit():
                best[int(k)] = v
        for qi in sorted(best.keys(), reverse=True)[:3]:
            streams.append({'label': '[Beeg] %sp' % qi, 'url': 'https://video.beeg.com/' + best[qi],
                            'referer': BEEG_SITE + '/'})
        if not streams and 'multi' in videos:
            # Some videos only expose a single adaptive-bitrate blob (no
            # separate per-resolution keys) — confirmed live this same
            # https://video.beeg.com/<blob> construction still resolves to
            # a real HLS master playlist on its own, so it's offered
            # directly rather than trying to parse a resolution out of it
            # the way the reference implementation's maxres heuristic did
            # (that heuristic silently produced nothing for this shape of
            # response, confirmed live 2026-08-14).
            streams.append({'label': '[Beeg] Auto', 'url': 'https://video.beeg.com/' + videos['multi'],
                            'referer': BEEG_SITE + '/'})
        name = ''
        for d in video.get('file', {}).get('data', []):
            if d.get('cd_column') == 'sf_name':
                name = d.get('cd_value') or ''
        return {
            'id': 'bg_' + slug, 'slug': slug,
            'title': _clean_title(name or slug),
            'title_norm': _norm_title(name or slug),
            'thumb': '', 'description': '', 'url': url, 'source': 'beeg', 'streams': streams,
        }
    except Exception as e:
        xbmc.log('[Starfleet/Beeg] detail error (%s): %s' % (slug, e), xbmc.LOGWARNING)
        return None


def _search_beeg_films(title, page=1):
    """`page` is accepted (uniform call signature) but NOT threaded into
    the URL: confirmed live 2026-08-14 this site's /facts/search endpoint
    already 404s with 'error.bad_request: no matching operation was
    found' for every query tried, even at offset=0 — a pre-existing API
    breakage independent of pagination (the sibling /facts/tag browse
    endpoint _beeg_latest uses still works fine, so this is search-
    specific). Left alone rather than adding fake pagination on top of an
    already-broken search."""
    from urllib.parse import quote as _quote
    try:
        url = BEEG_BASE + '/facts/search?q=%s&limit=48&offset=0' % _quote(title)
        jdata = _sess().get(url, timeout=10, headers={'User-Agent': 'Mozilla/5.0', 'Referer': BEEG_SITE + '/'}).json()
        return _beeg_parse_listing(jdata)
    except Exception as e:
        xbmc.log('[Starfleet/Beeg] search error: %s' % e, xbmc.LOGWARNING)
        return []


# ── tnaflix.com ────────────────────────────────────────────────────────────
#
# Added 2026-08-14. Confirmed live: the ajax player endpoint's mp4 sources
# need no token/session beyond a matching Referer. Found by reading a
# working reference implementation (plugin.video.cumination's tnaflix.py).

TNAFLIX_BASE = 'https://www.tnaflix.com'

_RE_TNAFLIX_LINK = re.compile(r'href="([^"]+)"')
_RE_TNAFLIX_NAME = re.compile(r'alt="([^"]+)"')
_RE_TNAFLIX_IMG = re.compile(r'src="([^"]+)"\s*alt')
_RE_TNAFLIX_EMBED = re.compile(r'"embedUrl":"([^"]+)"')
_RE_TNAFLIX_SRC = re.compile(r'source src="([^"]+)" type="video/mp4" size="([^"]+)">')


def _tnaflix_parse_listing(html):
    films = []
    seen = set()
    for chunk in html.split('data-vid="')[1:]:
        lm = _RE_TNAFLIX_LINK.search(chunk)
        nm = _RE_TNAFLIX_NAME.search(chunk)
        if not lm or not nm:
            continue
        path = lm.group(1)
        vid_m = re.search(r'/video(\d+)', path)
        slug = vid_m.group(1) if vid_m else path
        if slug in seen:
            continue
        seen.add(slug)
        title = _html_unescape.unescape(nm.group(1).strip())
        im = _RE_TNAFLIX_IMG.search(chunk)
        thumb = im.group(1) if im else ''
        url = path if path.startswith('http') else TNAFLIX_BASE + path
        films.append({'slug': slug, 'url': url, 'title': _clean_title(title),
                      'title_norm': _norm_title(title), 'thumb': thumb,
                      'source': 'tnaflix', 'streams': []})
    return films


def _tnaflix_latest(page=1):
    ck = 'tnaflix_latest_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached or []
    url = TNAFLIX_BASE + '/new/%d' % page
    try:
        films = _tnaflix_parse_listing(_get(url))
        _cache.set(ck, films, 2 * 3600)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/TNAFlix] latest error: %s' % e, xbmc.LOGWARNING)
        return []


def _tnaflix_film_detail(slug, url):
    try:
        html = _get(url)
        streams = []
        em = _RE_TNAFLIX_EMBED.search(html)
        if em:
            embed_url = em.group(1).replace('/video/', '/ajax/video-player/')
            try:
                eh = _sess().get(embed_url, timeout=10,
                                  headers={'User-Agent': 'Mozilla/5.0', 'Referer': url}).text
                eh = eh.replace('\\/', '/').replace('\\"', '"')
                best = {}
                for src, size in _RE_TNAFLIX_SRC.findall(eh):
                    q = 2160 if size == '4' else (int(size) if size.isdigit() else 0)
                    best[q] = src
                for q in sorted(best.keys(), reverse=True)[:3]:
                    streams.append({'label': '[TNAFlix] %dp' % q, 'url': best[q]})
            except Exception as e:
                xbmc.log('[Starfleet/TNAFlix] embed error: %s' % e, xbmc.LOGWARNING)
        tm = re.search(r'<h1[^>]*>([^<]+)</h1>', html)
        title = _html_unescape.unescape(tm.group(1).strip()) if tm else ''
        return {
            'id': 'tf_' + slug, 'slug': slug,
            'title': _clean_title(title or slug),
            'title_norm': _norm_title(title or slug),
            'thumb': '', 'description': '', 'url': url, 'source': 'tnaflix', 'streams': streams,
        }
    except Exception as e:
        xbmc.log('[Starfleet/TNAFlix] detail error (%s): %s' % (slug, e), xbmc.LOGWARNING)
        return None


def _search_tnaflix_films(title, page=1):
    """Confirmed live 2026-08-14 from the search page's own rendered
    pagination widget: <a class="page-link"
    href="https://www.tnaflix.com/search?what=...&page=2">2</a> — same
    '&page=N' param wired in here. (A second live fetch-and-diff to
    confirm distinct results hit this site's own rate limiting — 429 on
    back-to-back requests — but the pagination link itself, straight from
    the site's own markup, is not a guess.)"""
    from urllib.parse import quote as _quote
    url = TNAFLIX_BASE + '/search.php?what=' + _quote(title)
    if page > 1:
        url += '&page=%d' % page
    try:
        return _tnaflix_parse_listing(_get(url))
    except Exception as e:
        xbmc.log('[Starfleet/TNAFlix] search error: %s' % e, xbmc.LOGWARNING)
        return []


# ── txxx.com / hdzog.com ───────────────────────────────────────────────────
#
# Added 2026-08-14. Both sites' homepages are JS-rendered app shells with
# nothing in their static HTML (confirmed live for both) — the real content
# lives behind a clean JSON API both sites share (same underlying platform,
# same API shape, only the base domain differs). The video_url the API
# hands back is base64, but pre-obfuscated by substituting 5 letters
# (M A B C E) for Cyrillic-lookalike \uXXXX ESCAPE TEXT (the literal 6-char
# sequence, not a real Unicode character — confirmed live the raw response
# contains the literal backslash-u-escape text, not decoded Cyrillic) plus
# =/+  / -> ~/./,. Reverse those substitutions and it's a normal base64
# string. Found by reading a working reference implementation
# (plugin.video.cumination's txxx.py + decrypters/txxx.py); confirmed
# independently live before shipping.

_TXXX_FAMILY_BASE = {
    'txxx': 'https://txxx.com',
    'hdzog': 'https://hdzog.com',
}

_RE_TXXX_VIDEOURL = re.compile(r'video_url":"([^"]+)')
_TXXX_REPLACEMAP = {'M': '\\u041c', 'A': '\\u0410', 'B': '\\u0412', 'C': '\\u0421', 'E': '\\u0415',
                     '=': '~', '+': '.', '/': ','}


def _txxx_tdecode(vidurl):
    s = vidurl
    for key, val in _TXXX_REPLACEMAP.items():
        s = s.replace(val, key)
    import base64 as _b64
    return _b64.b64decode(s).decode('utf-8')


def _txxx_parse_listing(jdata, site_key, base):
    films = []
    for item in (jdata.get('videos') or []):
        try:
            vid = item.get('video_id')
            title = item.get('title') or ''
            if not vid or not title:
                continue
            films.append({'slug': str(vid), 'url': base + '/' + str(vid), 'title': _clean_title(title),
                          'title_norm': _norm_title(title), 'thumb': item.get('scr') or '',
                          'source': site_key, 'streams': []})
        except Exception:
            continue
    return films


def _txxx_latest(site_key, page=1):
    base = _TXXX_FAMILY_BASE[site_key]
    ck = '%s_latest_%d' % (site_key, page)
    cached = _cache.get(ck)
    if cached is not None:
        return cached or []
    url = (base + '/api/json/videos/86400/str/latest-updates/60/..%d.all..day.json') % page
    try:
        jdata = _sess().get(url, timeout=10, headers={'User-Agent': 'Mozilla/5.0', 'Referer': base + '/'}).json()
        films = _txxx_parse_listing(jdata, site_key, base)
        _cache.set(ck, films, 2 * 3600)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/%s] latest error: %s' % (site_key, e), xbmc.LOGWARNING)
        return []


def _txxx_film_detail(site_key, slug, url):
    base = _TXXX_FAMILY_BASE[site_key]
    # Never cached — 'ti='-timestamped URLs are short-lived.
    try:
        vurl = base + '/api/videofile.php?video_id=%s&lifetime=8640000' % slug
        html = _sess().get(vurl, timeout=10, headers={'User-Agent': 'Mozilla/5.0', 'Referer': base + '/'}).text
        streams = []
        m = _RE_TXXX_VIDEOURL.search(html)
        if m:
            try:
                real_path = _txxx_tdecode(m.group(1))
                real_url = real_path if real_path.startswith('http') else base + real_path
                streams.append({'label': '[%s] Stream' % site_key.title(), 'url': real_url, 'referer': base + '/'})
            except Exception as e:
                xbmc.log('[Starfleet/%s] tdecode error: %s' % (site_key, e), xbmc.LOGWARNING)
        return {
            'id': site_key[:2] + '_' + slug, 'slug': slug,
            'title': _clean_title(slug), 'title_norm': _norm_title(slug),
            'thumb': '', 'description': '', 'url': url, 'source': site_key, 'streams': streams,
        }
    except Exception as e:
        xbmc.log('[Starfleet/%s] detail error (%s): %s' % (site_key, slug, e), xbmc.LOGWARNING)
        return None


def _search_txxx_films(site_key, title, page=1):
    """Confirmed live 2026-08-14: the '1' sitting just before '.all..' in
    the params path is this endpoint's own page number — same position
    _txxx_latest's '%d' occupies in its own '.../latest-updates/60/..%d.
    all..day.json' URL. Swapping it for the requested page returns a
    fully disjoint result set (0 slug overlap page1 vs page2). Shared by
    both txxx.com and hdzog.com (same API, only site_key/base differ) —
    verified directly against txxx.com; hdzog.com goes through this exact
    same code path so it inherits the same, already-confirmed behavior."""
    base = _TXXX_FAMILY_BASE[site_key]
    from urllib.parse import quote as _quote
    try:
        url = (base + '/api/videos.php?params=259200/str/relevance/60/search..%d.all..&s=%s'
               '&sort=latest-updates&date=all&type=all&duration=all') % (page, _quote(title))
        jdata = _sess().get(url, timeout=10, headers={'User-Agent': 'Mozilla/5.0', 'Referer': base + '/'}).json()
        return _txxx_parse_listing(jdata, site_key, base)
    except Exception as e:
        xbmc.log('[Starfleet/%s] search error: %s' % (site_key, e), xbmc.LOGWARNING)
        return []


# ── 6xtube.com ─────────────────────────────────────────────────────────────
#
# Added 2026-08-14. Confirmed live: video pages embed an <iframe> pointing
# at a trendyporn.com embed, whose page has the real signed mp4 URL inline —
# no token/session needed beyond the chain's own Referer hops. Found by
# reading a working reference implementation
# (plugin.video.cumination's 6xtube.py).

SIXXTUBE_BASE = 'http://www.6xtube.com'

_RE_6XTUBE_LINK = re.compile(r'class="video-link" href="([^"]+)"')
_RE_6XTUBE_TITLE = re.compile(r'title="([^"]+)"')
_RE_6XTUBE_IMG = re.compile(r'src="https:([^"]+)"')
_RE_6XTUBE_IFRAME = re.compile(r'iframe scrolling="no"\s*src="([^"]+)"', re.IGNORECASE | re.DOTALL)
_RE_6XTUBE_SRC = re.compile(r'(?:src:|source src=)\s*"([^"]+)"')


def _6xtube_parse_listing(html):
    films = []
    seen = set()
    for chunk in html.split('<div class="well well-sm"')[1:]:
        lm = _RE_6XTUBE_LINK.search(chunk)
        if not lm:
            continue
        path = lm.group(1)
        if '=modelfeed' in path:
            continue
        slug = path.rstrip('/').rsplit('-', 1)[-1].replace('.html', '')
        if slug in seen:
            continue
        seen.add(slug)
        tm = _RE_6XTUBE_TITLE.search(chunk)
        title = _html_unescape.unescape(tm.group(1).strip()) if tm else slug
        im = _RE_6XTUBE_IMG.search(chunk)
        thumb = ('https:' + im.group(1)) if im else ''
        url = path if path.startswith('http') else SIXXTUBE_BASE + path
        films.append({'slug': slug, 'url': url, 'title': _clean_title(title),
                      'title_norm': _norm_title(title), 'thumb': thumb,
                      'source': '6xtube', 'streams': []})
    return films


def _6xtube_latest(page=1):
    ck = '6xtube_latest_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached or []
    url = SIXXTUBE_BASE + ('/most-recent/' if page <= 1 else '/most-recent/page%d.html' % page)
    try:
        films = _6xtube_parse_listing(_get(url))
        _cache.set(ck, films, 2 * 3600)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/6xtube] latest error: %s' % e, xbmc.LOGWARNING)
        return []


def _6xtube_film_detail(slug, url):
    ck = '6xtube_detail_%s' % slug[:60]
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        html = _sess().get(url, timeout=10, headers={'User-Agent': 'Mozilla/5.0'}, verify=False).text
        streams = []
        im = _RE_6XTUBE_IFRAME.search(html)
        if im:
            embed_url = im.group(1)
            try:
                eh = _sess().get(embed_url, timeout=10,
                                  headers={'User-Agent': 'Mozilla/5.0', 'Referer': url}, verify=False).text
                sm = _RE_6XTUBE_SRC.search(eh)
                if sm:
                    streams.append({'label': '[6xtube] Stream', 'url': sm.group(1), 'referer': embed_url})
            except Exception as e:
                xbmc.log('[Starfleet/6xtube] embed error: %s' % e, xbmc.LOGWARNING)
        tm = re.search(r'<title>([^<]+)</title>', html)
        title = _html_unescape.unescape(tm.group(1).strip()) if tm else ''
        film = {
            'id': '6x_' + slug, 'slug': slug,
            'title': _clean_title(title or slug),
            'title_norm': _norm_title(title or slug),
            'thumb': '', 'description': '', 'url': url, 'source': '6xtube', 'streams': streams,
        }
        if streams:
            _cache.set(ck, film, 6 * 3600)
        return film
    except Exception as e:
        xbmc.log('[Starfleet/6xtube] detail error (%s): %s' % (slug, e), xbmc.LOGWARNING)
        return None


def _search_6xtube_films(title, page=1):
    """Confirmed live 2026-08-14: '/search/<query>/page<N>.html' (same
    'page<N>.html' suffix style as the listing's own
    '/most-recent/page%d.html' in _6xtube_latest) returns a fully disjoint
    result set (0 slug overlap page1 vs page2)."""
    from urllib.parse import quote as _quote
    url = SIXXTUBE_BASE + '/search/' + _quote(title.replace(' ', '-')) + '/'
    if page > 1:
        url += 'page%d.html' % page
    try:
        return _6xtube_parse_listing(_get(url))
    except Exception as e:
        xbmc.log('[Starfleet/6xtube] search error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Public browse helpers (used by afdb_router for category browsing) ─────────

def get_panda_genres():
    return _panda_genres()

def get_panda_movies(genre_url, page=1):
    return _panda_movies_for_genre(genre_url, page)

def get_panda_movie_detail(slug, url):
    return _panda_film_detail(slug, url)

def get_hqporner_categories():
    return _hqporner_categories()

def get_hqporner_movies(category_url, page=1):
    return _hqporner_movies(category_url, page)

def get_hqporner_movie_detail(slug, url):
    return _hqporner_film_detail(slug, url)

def get_xvideos_movies(page=1):
    return _xvideos_latest(page)

def get_xvideos_movie_detail(slug, url):
    return _xvideos_film_detail(slug, url)

def search_xvideos_movies(query, page=1):
    return _search_xvideos_films(query, page)

def get_xnxx_movies(page=1):
    return _xnxx_latest(page)

def get_xnxx_movie_detail(slug, url):
    return _xnxx_film_detail(slug, url)

def search_xnxx_movies(query, page=1):
    return _search_xnxx_films(query, page)

def get_pornhub_movies(page=1):
    return _pornhub_latest(page)

def get_pornhub_movie_detail(slug, url):
    return _pornhub_film_detail(slug, url)

def search_pornhub_movies(query, page=1):
    return _search_pornhub_films(query, page)

def get_youporn_movies(page=1):
    return _youporn_latest(page)

def get_youporn_movie_detail(slug, url):
    return _youporn_film_detail(slug, url)

def search_youporn_movies(query, page=1):
    return _search_youporn_films(query, page)

def get_xhamster_movies(page=1):
    return _xhamster_latest(page)

def get_xhamster_movie_detail(slug, url):
    return _xhamster_film_detail(slug, url)

def search_xhamster_movies(query, page=1):
    return _search_xhamster_films(query, page)

def get_xerotica_movies(page=1):
    return _xerotica_latest(page)

def get_xerotica_movie_detail(slug, url):
    return _xerotica_film_detail(slug, url)

def search_xerotica_movies(query, page=1):
    return _search_xerotica_films(query, page)

def get_redtube_movies(page=1):
    return _redtube_latest(page)

def get_redtube_movie_detail(slug, url):
    return _redtube_film_detail(slug, url)

def search_redtube_movies(query, page=1):
    return _search_redtube_films(query, page)

def get_tube8_movies(page=1):
    return _tube8_latest(page)

def get_tube8_movie_detail(slug, url):
    return _tube8_film_detail(slug, url)

def search_tube8_movies(query, page=1):
    return _search_tube8_films(query, page)

def get_thumbzilla_movies(page=1):
    return _thumbzilla_latest(page)

def get_thumbzilla_movie_detail(slug, url):
    return _thumbzilla_film_detail(slug, url)

def search_thumbzilla_movies(query, page=1):
    return _search_thumbzilla_films(query, page)

def get_porntrex_movies(page=1):
    return _porntrex_latest(page)

def get_porntrex_movie_detail(slug, url):
    return _porntrex_film_detail(slug, url)

def search_porntrex_movies(query, page=1):
    return _search_porntrex_films(query, page)

def get_noodlemagazine_movies(page=1):
    return _noodlemagazine_latest(page)

def get_noodlemagazine_movie_detail(slug, url):
    return _noodlemagazine_film_detail(slug, url)

def search_noodlemagazine_movies(query, page=1):
    return _search_noodlemagazine_films(query, page)

def get_letmejizz_movies(page=1):
    return _letmejizz_latest(page)

def get_letmejizz_movie_detail(slug, url):
    return _letmejizz_film_detail(slug, url)

def search_letmejizz_movies(query, page=1):
    return _search_letmejizz_films(query, page)

def get_eporner_movies(page=1):
    return _eporner_latest(page)

def get_eporner_movie_detail(slug, url):
    return _eporner_film_detail(slug, url)

def search_eporner_movies(query, page=1):
    return _search_eporner_films(query, page)

def get_beeg_movies(page=1):
    return _beeg_latest(page)

def get_beeg_movie_detail(slug, url):
    return _beeg_film_detail(slug, url)

def search_beeg_movies(query, page=1):
    return _search_beeg_films(query, page)

def get_tnaflix_movies(page=1):
    return _tnaflix_latest(page)

def get_tnaflix_movie_detail(slug, url):
    return _tnaflix_film_detail(slug, url)

def search_tnaflix_movies(query, page=1):
    return _search_tnaflix_films(query, page)

def get_txxx_movies(page=1):
    return _txxx_latest('txxx', page)

def get_txxx_movie_detail(slug, url):
    return _txxx_film_detail('txxx', slug, url)

def search_txxx_movies(query, page=1):
    return _search_txxx_films('txxx', query, page)

def get_hdzog_movies(page=1):
    return _txxx_latest('hdzog', page)

def get_hdzog_movie_detail(slug, url):
    return _txxx_film_detail('hdzog', slug, url)

def search_hdzog_movies(query, page=1):
    return _search_txxx_films('hdzog', query, page)

def get_6xtube_movies(page=1):
    return _6xtube_latest(page)

def get_6xtube_movie_detail(slug, url):
    return _6xtube_film_detail(slug, url)

def search_6xtube_movies(query, page=1):
    return _search_6xtube_films(query, page)


def get_pornhat_movies(page=1):
    return _pornhat_latest(page)

def get_pornhat_movie_detail(slug, url):
    return _pornhat_film_detail(slug, url)

def search_pornhat_movies(query, page=1):
    return _search_pornhat_films(query, page)

def get_okxxx_movies(page=1):
    return _okxxx_latest(page)

def get_okxxx_movie_detail(slug, url):
    return _okxxx_film_detail(slug, url)

def search_okxxx_movies(query, page=1):
    return _search_okxxx_films(query, page)

def get_3movs_movies(page=1):
    return _tmovs_latest(page)

def get_3movs_movie_detail(slug, url):
    return _tmovs_film_detail(slug, url)

def search_3movs_movies(query, page=1):
    return _search_tmovs_films(query, page)

def get_justporn_movies(page=1):
    return _jporn_latest(page)

def get_justporn_movie_detail(slug, url):
    return _jporn_film_detail(slug, url)

def search_justporn_movies(query, page=1):
    return _search_jporn_films(query, page)

def get_porn00_movies(page=1):
    return _p00_latest(page)

def get_porn00_movie_detail(slug, url):
    return _p00_film_detail(slug, url)

def search_porn00_movies(query, page=1):
    return _search_p00_films(query, page)

def get_xmoviesforyou_movies(page=1):
    return _xmfy_latest(page)

def get_xmoviesforyou_movie_detail(slug, url):
    return _xmfy_film_detail(slug, url)

def search_xmoviesforyou_movies(query, page=1):
    return _search_xmfy_films(query, page)

def get_pornone_movies(page=1):
    return _pnone_latest(page)

def get_pornone_movie_detail(slug, url):
    return _pnone_film_detail(slug, url)

def search_pornone_movies(query, page=1):
    return _search_pnone_films(query, page)

def get_porndig_movies(page=1):
    return _porndig_latest(page)

def get_porndig_movie_detail(slug, url):
    return _porndig_film_detail(slug, url)

def search_porndig_movies(query, page=1):
    return _search_porndig_films(query, page)

def get_cumlouder_movies(page=1):
    return _cumlouder_latest(page)

def get_cumlouder_movie_detail(slug, url):
    return _cumlouder_film_detail(slug, url)

def search_cumlouder_movies(query, page=1):
    return _search_cumlouder_films(query, page)

def get_porngo_movies(page=1):
    return _porngo_latest(page)

def get_porngo_movie_detail(slug, url):
    return _porngo_film_detail(slug, url)

def search_porngo_movies(query, page=1):
    return _search_porngo_films(query, page)

def get_allpornstream_movies(page=1):
    return _aps_latest(page)

def get_allpornstream_movie_detail(slug, url):
    return _aps_film_detail(slug, url)

def search_allpornstream_movies(query, page=1):
    return _search_aps_films(query, page)


# ═════════════════════════════════════════════════════════════════════════════
# New sites (added 2026-08-15) — all live-verified before wiring in (see the
# investigation this batch came from: 19 candidate URLs checked, dead ends
# reported separately). Two shared "family" backends were confirmed serving
# multiple candidates identically, so a single stream-extraction helper
# covers each family instead of duplicating it per site.
# ═════════════════════════════════════════════════════════════════════════════

# ── shared "GF13" family: pornhat.com / ok.xxx ──────────────────────────────
# Identical WGT-network backend (same get_file/13/... URL shape, same
# thumb-bl-video card markup). Confirmed live 2026-08-15: the quality-
# suffixed get_file URL (_720p/_360p) 302-redirects straight to a real HLS
# manifest with no Referer needed; no acctoken query string involved (unlike
# the GF-token family below).
_RE_GF13_CARD = re.compile(
    r'<a href="(/video/([a-zA-Z0-9-]+)/)" title="([^"]+)"',
    re.IGNORECASE
)
_RE_GF13_STREAM = re.compile(
    r'get_file/13/[a-f0-9]+/\d+/\d+/\d+_(?:720p|360p)\.mp4/',
    re.IGNORECASE
)


def _gf13_best_stream(html, base):
    best = None
    for m in _RE_GF13_STREAM.finditer(html):
        u = m.group(0)
        if '_720p.mp4' in u:
            return base + '/' + u
        if best is None:
            best = base + '/' + u
    return best


def _gf13_latest(base, source, page=1):
    ck = 'gf13_latest_%s_%d' % (source, page)
    cached = _cache.get(ck)
    if cached is not None:
        return cached or []
    url = base + ('/' if page <= 1 else '/%d/' % page)
    try:
        html = _get(url)
        films, seen = [], set()
        for m in _RE_GF13_CARD.finditer(html):
            film_url, slug, title = base + m.group(1), m.group(2), _html_unescape.unescape(m.group(3))
            if slug in seen:
                continue
            seen.add(slug)
            films.append({'slug': slug, 'url': film_url, 'title': _clean_title(title),
                          'title_norm': _norm_title(title), 'thumb': '',
                          'source': source, 'streams': []})
        _cache.set(ck, films, 2 * 3600)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/%s] latest error: %s' % (source, e), xbmc.LOGWARNING)
        return []


def _gf13_film_detail(base, source, slug, url):
    ck = 'gf13_detail_%s_%s' % (source, slug[:60])
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        html = _get(url)
        m = re.search(r'<title>([^<]+)</title>', html, re.IGNORECASE)
        title = m.group(1) if m else slug.replace('-', ' ').title()
        # Site branding bleeds into <title>: pornhat = "HD <emoji> video
        # TITLE - PornHat", okxxx = "Video <emoji> TITLE - OK.XXX" — strip
        # both the leading word+emoji prefix and the trailing " - Site"
        # suffix. The emoji is required in the prefix match so a genuine
        # title that happens to start with "Video"/"HD" (no emoji after)
        # is left alone.
        title = re.sub(r'^\s*(?:HD\s+)?(?:Video\s+)?[^\w\s]+\s*(?:video\s+)?', '', title, flags=re.IGNORECASE)
        title = re.sub(r'\s*-\s*(?:PornHat|OK\.XXX).*$', '', title, flags=re.IGNORECASE).strip()
        if not title:
            title = slug.replace('-', ' ').title()
        title = _html_unescape.unescape(title)
        thumb = _og(html, 'image')
        streams = []
        su = _gf13_best_stream(html, base)
        if su:
            streams.append({'label': '[%s] Stream' % source.title(), 'url': su})
        film = {
            'id': '%s_%s' % (source, slug), 'slug': slug, 'title': _clean_title(title),
            'title_norm': _norm_title(title), 'thumb': thumb, 'description': '',
            'url': url, 'source': source, 'streams': streams,
        }
        _cache.set(ck, film, 12 * 3600)
        return film
    except Exception as e:
        xbmc.log('[Starfleet/%s] detail error (%s): %s' % (source, slug, e), xbmc.LOGWARNING)
        return None


def _gf13_search(base, source, title, page=1):
    """Confirmed live 2026-08-15: /search/<query>/ real search on both
    sites, page N via /search/<query>/N/ — 0 slug overlap page1 vs page2."""
    from urllib.parse import quote as _quote
    url = base + '/search/' + _quote(title) + '/' + ('' if page <= 1 else '%d/' % page)
    try:
        html = _get(url)
        stubs, seen = [], set()
        for m in _RE_GF13_CARD.finditer(html):
            film_url, slug = base + m.group(1), m.group(2)
            if slug not in seen:
                seen.add(slug)
                stubs.append({'slug': slug, 'url': film_url})
    except Exception as e:
        xbmc.log('[Starfleet/%s] search error: %s' % (source, e), xbmc.LOGWARNING)
        stubs = []
    return _pfetch(stubs, lambda s: _gf13_film_detail(base, source, s['slug'], s['url']))


def _pornhat_latest(page=1):
    return _gf13_latest(PHAT_BASE, 'pornhat', page)

def _pornhat_film_detail(slug, url):
    return _gf13_film_detail(PHAT_BASE, 'pornhat', slug, url)

def _search_pornhat_films(title, page=1):
    return _gf13_search(PHAT_BASE, 'pornhat', title, page)


def _okxxx_latest(page=1):
    return _gf13_latest(OKXXX_BASE, 'okxxx', page)

def _okxxx_film_detail(slug, url):
    return _gf13_film_detail(OKXXX_BASE, 'okxxx', slug, url)

def _search_okxxx_films(title, page=1):
    return _gf13_search(OKXXX_BASE, 'okxxx', title, page)


# ── shared "GF-token" family: 3movs.com / justporn.com / porn00.org ─────────
# Identical WGT-network backend, different flavour: get_file URLs carry a
# ?v-acctoken=... query string, and the bare unsuffixed URL always returns a
# 1x2 placeholder gif regardless of headers/cookies (confirmed live
# 2026-08-15, a premium-only quality gate) — only the explicitly quality-
# suffixed _720p/_lq variant actually 302s to a real CDN file.
_RE_GFTOKEN_STREAM = re.compile(
    r'get_file/\d+/[a-f0-9]+/\d+/\d+/\d+_(?:720p|lq)\.mp4/\?v-acctoken=[^"\'&\s]+',
    re.IGNORECASE
)


def _gftoken_best_stream(html, base):
    best = None
    for m in _RE_GFTOKEN_STREAM.finditer(html):
        u = m.group(0)
        if '_720p.mp4' in u:
            return base + '/' + u
        if best is None:
            best = base + '/' + u
    return best


# 3movs.com
_RE_TMOVS_CARD = re.compile(
    r'href="(https://www\.3movs\.com/videos/(\d+)/([a-z0-9-]+)/)"', re.IGNORECASE)


def _tmovs_latest(page=1):
    ck = 'tmovs_latest_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached or []
    url = TMOVS_BASE + '/latest-updates/' + ('' if page <= 1 else '%d/' % page)
    try:
        html = _get(url)
        films, seen = [], set()
        for m in _RE_TMOVS_CARD.finditer(html):
            film_url, vid, slug = m.group(1), m.group(2), m.group(3)
            if vid in seen:
                continue
            seen.add(vid)
            title = slug.replace('-', ' ').title()
            films.append({'slug': vid, 'url': film_url, 'title': _clean_title(title),
                          'title_norm': _norm_title(title), 'thumb': '',
                          'source': '3movs', 'streams': []})
        _cache.set(ck, films, 2 * 3600)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/3movs] latest error: %s' % e, xbmc.LOGWARNING)
        return []


def _tmovs_film_detail(slug, url):
    ck = 'tmovs_detail_%s' % slug[:60]
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        html = _get(url)
        m = re.search(r'<title>([^<]+)</title>', html, re.IGNORECASE)
        title = re.sub(r'\s*-\s*Porn\s*Movies.*$', '', m.group(1), flags=re.IGNORECASE).strip() \
            if m else slug.replace('-', ' ').title()
        title = _html_unescape.unescape(title)
        thumb = _og(html, 'image')
        streams = []
        su = _gftoken_best_stream(html, TMOVS_BASE)
        if su:
            streams.append({'label': '[3movs] MP4', 'url': su})
        film = {
            'id': 'tmovs_' + slug, 'slug': slug, 'title': _clean_title(title),
            'title_norm': _norm_title(title), 'thumb': thumb, 'description': '',
            'url': url, 'source': '3movs', 'streams': streams,
        }
        _cache.set(ck, film, 12 * 3600)
        return film
    except Exception as e:
        xbmc.log('[Starfleet/3movs] detail error (%s): %s' % (slug, e), xbmc.LOGWARNING)
        return None


def _search_tmovs_films(title, page=1):
    """Confirmed live 2026-08-15: /search_videos/?q=X real search;
    &from_videos=<offset> (offset = (page-1)*24) real pagination — 0 slug
    overlap page1 vs offset=24 for a real query ("milf")."""
    from urllib.parse import quote as _quote
    url = TMOVS_BASE + '/search_videos/?q=' + _quote(title)
    if page > 1:
        url += '&from_videos=%d' % ((page - 1) * 24)
    try:
        html = _get(url)
        stubs, seen = [], set()
        for m in _RE_TMOVS_CARD.finditer(html):
            film_url, vid = m.group(1), m.group(2)
            if vid not in seen:
                seen.add(vid)
                stubs.append({'slug': vid, 'url': film_url})
    except Exception as e:
        xbmc.log('[Starfleet/3movs] search error: %s' % e, xbmc.LOGWARNING)
        stubs = []
    return _pfetch(stubs, lambda s: _tmovs_film_detail(s['slug'], s['url']))


# justporn.com
_RE_JPORN_CARD = re.compile(
    r'href="(https://www\.justporn\.com/video/(\d+)/([a-z0-9-]+)/)"', re.IGNORECASE)


def _jporn_latest(page=1):
    ck = 'jporn_latest_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached or []
    url = JPORN_BASE + '/latest-updates/' + ('' if page <= 1 else '%d/' % page)
    try:
        html = _get(url)
        films, seen = [], set()
        for m in _RE_JPORN_CARD.finditer(html):
            film_url, vid, slug = m.group(1), m.group(2), m.group(3)
            if vid in seen:
                continue
            seen.add(vid)
            title = slug.replace('-', ' ').title()
            films.append({'slug': vid, 'url': film_url, 'title': _clean_title(title),
                          'title_norm': _norm_title(title), 'thumb': '',
                          'source': 'justporn', 'streams': []})
        _cache.set(ck, films, 2 * 3600)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/JustPorn] latest error: %s' % e, xbmc.LOGWARNING)
        return []


def _jporn_film_detail(slug, url):
    ck = 'jporn_detail_%s' % slug[:60]
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        html = _get(url)
        m = re.search(r'<title>([^<]+)</title>', html, re.IGNORECASE)
        title = re.sub(r'\s*[|-]\s*Just\s*Porn.*$', '', m.group(1), flags=re.IGNORECASE).strip() \
            if m else slug.replace('-', ' ').title()
        title = _html_unescape.unescape(title)
        thumb = _og(html, 'image')
        streams = []
        su = _gftoken_best_stream(html, JPORN_BASE)
        if su:
            streams.append({'label': '[JustPorn] MP4', 'url': su})
        film = {
            'id': 'jporn_' + slug, 'slug': slug, 'title': _clean_title(title),
            'title_norm': _norm_title(title), 'thumb': thumb, 'description': '',
            'url': url, 'source': 'justporn', 'streams': streams,
        }
        _cache.set(ck, film, 12 * 3600)
        return film
    except Exception as e:
        xbmc.log('[Starfleet/JustPorn] detail error (%s): %s' % (slug, e), xbmc.LOGWARNING)
        return None


def _search_jporn_films(title, page=1):
    """Confirmed live 2026-08-15: /search/<query>/ real search, page N via
    /search/<query>/N/ — 0 slug overlap page1 vs page2."""
    from urllib.parse import quote as _quote
    url = JPORN_BASE + '/search/' + _quote(title) + '/' + ('' if page <= 1 else '%d/' % page)
    try:
        html = _get(url)
        stubs, seen = [], set()
        for m in _RE_JPORN_CARD.finditer(html):
            film_url, vid = m.group(1), m.group(2)
            if vid not in seen:
                seen.add(vid)
                stubs.append({'slug': vid, 'url': film_url})
    except Exception as e:
        xbmc.log('[Starfleet/JustPorn] search error: %s' % e, xbmc.LOGWARNING)
        stubs = []
    return _pfetch(stubs, lambda s: _jporn_film_detail(s['slug'], s['url']))


# porn00.org
_RE_P00_CARD = re.compile(
    r'href="(https://www\.porn00\.org/video/([a-z0-9-]+)/)"', re.IGNORECASE)


def _p00_latest(page=1):
    ck = 'p00_latest_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached or []
    url = P00_BASE + '/latest-vids/' + ('' if page <= 1 else '%d/' % page)
    try:
        html = _get(url)
        films, seen = [], set()
        for m in _RE_P00_CARD.finditer(html):
            film_url, slug = m.group(1), m.group(2)
            if slug in seen:
                continue
            seen.add(slug)
            title = slug.replace('-', ' ').title()
            films.append({'slug': slug, 'url': film_url, 'title': _clean_title(title),
                          'title_norm': _norm_title(title), 'thumb': '',
                          'source': 'porn00', 'streams': []})
        _cache.set(ck, films, 2 * 3600)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/Porn00] latest error: %s' % e, xbmc.LOGWARNING)
        return []


def _p00_film_detail(slug, url):
    ck = 'p00_detail_%s' % slug[:60]
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        html = _get(url)
        m = re.search(r'<title>([^<]+)</title>', html, re.IGNORECASE)
        title = re.sub(r'\s*-\s*Porn00.*$', '', m.group(1), flags=re.IGNORECASE).strip() \
            if m else slug.replace('-', ' ').title()
        title = _html_unescape.unescape(title)
        thumb = _og(html, 'image')
        streams = []
        su = _gftoken_best_stream(html, P00_BASE)
        if su:
            streams.append({'label': '[Porn00] MP4', 'url': su})
        film = {
            'id': 'p00_' + slug, 'slug': slug, 'title': _clean_title(title),
            'title_norm': _norm_title(title), 'thumb': thumb, 'description': '',
            'url': url, 'source': 'porn00', 'streams': streams,
        }
        _cache.set(ck, film, 12 * 3600)
        return film
    except Exception as e:
        xbmc.log('[Starfleet/Porn00] detail error (%s): %s' % (slug, e), xbmc.LOGWARNING)
        return None


def _search_p00_films(title, page=1):
    """Confirmed live 2026-08-15: /search/<query>/ real search, page N via
    /search/<query>/N/ — real (mostly disjoint) result sets page1 vs page2."""
    from urllib.parse import quote as _quote
    url = P00_BASE + '/search/' + _quote(title) + '/' + ('' if page <= 1 else '%d/' % page)
    try:
        html = _get(url)
        stubs, seen = [], set()
        for m in _RE_P00_CARD.finditer(html):
            film_url, slug = m.group(1), m.group(2)
            if slug not in seen:
                seen.add(slug)
                stubs.append({'slug': slug, 'url': film_url})
    except Exception as e:
        xbmc.log('[Starfleet/Porn00] search error: %s' % e, xbmc.LOGWARNING)
        stubs = []
    return _pfetch(stubs, lambda s: _p00_film_detail(s['slug'], s['url']))


# ── xmoviesforyou.com ────────────────────────────────────────────────────────
# Confirmed live 2026-08-15: server-rendered listing + /page/N pagination;
# own search at /search?q=X (page 1) / /search?q=X&page=N (page N), both
# confirmed 0 slug overlap page1 vs page2. Detail pages resolve their real
# HLS stream via a same-origin JSON API (/api/stream/<id>?target=dedi_1)
# that returns a signed CDN node URL — the CDN itself 403s without an
# Origin header (Referer alone isn't enough, confirmed live), so both
# Origin and Referer are baked directly into the stream URL's pipe-tag
# (this codebase's existing url|Key=val&Key2=val2 convention) rather than
# relying on search_by_title's normal single-Referer merge.
_RE_XMFY_CARD = re.compile(
    r'href="(/(?!page|categories|pages|search)[a-z][a-z0-9-]{6,})"[^>]*>[\s\S]{0,300}?'
    r'<img\s+src="([^"]+)"\s+alt="([^"]+)"',
    re.IGNORECASE
)
_RE_XMFY_VIDEOID = re.compile(r'const\s+videoId\s*=\s*"(\d+)"')


def _xmfy_latest(page=1):
    ck = 'xmfy_latest_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached or []
    url = XMFY_BASE + ('/' if page <= 1 else '/page/%d' % page)
    try:
        html = _get(url)
        films, seen = [], set()
        for m in _RE_XMFY_CARD.finditer(html):
            slug, thumb, title = m.group(1).strip('/'), m.group(2), _html_unescape.unescape(m.group(3))
            if slug not in seen:
                seen.add(slug)
                films.append({'slug': slug, 'url': XMFY_BASE + '/' + slug,
                              'title': _clean_title(title), 'title_norm': _norm_title(title),
                              'thumb': thumb, 'source': 'xmoviesforyou', 'streams': []})
        _cache.set(ck, films, 2 * 3600)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/XMFY] latest error: %s' % e, xbmc.LOGWARNING)
        return []


def _xmfy_film_detail(slug, url):
    ck = 'xmfy_detail_%s' % slug[:60]
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        html = _get(url)
        m = re.search(r'<title>([^<]+)</title>', html, re.IGNORECASE)
        title = re.sub(r'\s*-\s*XMoviesForYou\s*$', '', m.group(1)).strip() if m else slug.replace('-', ' ').title()
        title = _html_unescape.unescape(title)
        thumb = _og(html, 'image')
        streams = []
        vid = _RE_XMFY_VIDEOID.search(html)
        if vid:
            try:
                api_html = _get(XMFY_BASE + '/api/stream/%s?target=dedi_1' % vid.group(1))
                data = json.loads(api_html)
                stream_url = data.get('url')
                if stream_url:
                    from urllib.parse import quote as _uq
                    headers = 'Origin=%s&Referer=%s' % (_uq(XMFY_BASE, safe=''), _uq(XMFY_BASE + '/', safe=''))
                    streams.append({'label': '[XMoviesForYou] HLS',
                                    'url': '%s|%s' % (stream_url, headers)})
            except Exception as e:
                xbmc.log('[Starfleet/XMFY] stream api error: %s' % e, xbmc.LOGWARNING)
        film = {
            'id': 'xmfy_' + slug, 'slug': slug, 'title': _clean_title(title),
            'title_norm': _norm_title(title), 'thumb': thumb, 'description': '',
            'url': url, 'source': 'xmoviesforyou', 'streams': streams,
        }
        _cache.set(ck, film, 12 * 3600)
        return film
    except Exception as e:
        xbmc.log('[Starfleet/XMFY] detail error (%s): %s' % (slug, e), xbmc.LOGWARNING)
        return None


def _search_xmfy_films(title, page=1):
    from urllib.parse import quote as _quote
    url = XMFY_BASE + '/search?q=' + _quote(title)
    if page > 1:
        url += '&page=%d' % page
    try:
        html = _get(url)
        stubs, seen = [], set()
        for m in _RE_XMFY_CARD.finditer(html):
            slug = m.group(1).strip('/')
            if slug not in seen:
                seen.add(slug)
                stubs.append({'slug': slug, 'url': XMFY_BASE + '/' + slug})
    except Exception as e:
        xbmc.log('[Starfleet/XMFY] search error: %s' % e, xbmc.LOGWARNING)
        stubs = []
    return _pfetch(stubs, lambda s: _xmfy_film_detail(s['slug'], s['url']))


# ── pornone.com ──────────────────────────────────────────────────────────────
# Confirmed live 2026-08-15: /newest/ + /newest/N/ real pagination; own
# search at /search?q=X (page 1) / /search/N?q=X (page N), both confirmed 0
# slug overlap page1 vs page2. Detail page ships a direct <source> mp4, no
# Referer required (verified via a plain unauthenticated fetch).
_RE_PNONE_CARD = re.compile(
    r'href="(https://pornone\.com/[a-z0-9-]+/([a-z0-9-]+)/(\d+))/(?:\?[^"]*)?"',
    re.IGNORECASE
)
_RE_PNONE_TITLE = re.compile(r'<div class="videotitle\s*">([^<]*)</div>', re.IGNORECASE)
_RE_PNONE_MP4 = re.compile(r'<source\s+src="([^"]+\.mp4[^"]*)"', re.IGNORECASE)


def _pnone_latest(page=1):
    ck = 'pnone_latest_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached or []
    url = PNONE_BASE + '/newest/' + ('' if page <= 1 else '%d/' % page)
    try:
        html = _get(url)
        films, seen = [], set()
        for m in _RE_PNONE_CARD.finditer(html):
            film_url, slug, vid = m.group(1), m.group(2), m.group(3)
            if vid in seen:
                continue
            seen.add(vid)
            window = html[m.end():m.end() + 2000]
            tm = _RE_PNONE_TITLE.search(window)
            title = _clean(tm.group(1)) if tm and tm.group(1).strip() else slug.replace('-', ' ').title()
            films.append({'slug': slug + '-' + vid, 'url': film_url, 'title': _clean_title(title),
                          'title_norm': _norm_title(title), 'thumb': '',
                          'source': 'pornone', 'streams': []})
        _cache.set(ck, films, 2 * 3600)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/PornOne] latest error: %s' % e, xbmc.LOGWARNING)
        return []


def _pnone_film_detail(slug, url):
    ck = 'pnone_detail_%s' % slug[:60]
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        html = _get(url)
        m = re.search(r'<title>([^<]+)</title>', html, re.IGNORECASE)
        title = re.sub(r'\s*&mdash;\s*PornOne.*$', '', m.group(1), flags=re.IGNORECASE).strip() \
            if m else slug.replace('-', ' ').title()
        title = _html_unescape.unescape(title)
        thumb = _og(html, 'image')
        streams = []
        sm = _RE_PNONE_MP4.search(html)
        if sm:
            streams.append({'label': '[PornOne] MP4', 'url': sm.group(1), 'referer': PNONE_BASE + '/'})
        film = {
            'id': 'pnone_' + slug, 'slug': slug, 'title': _clean_title(title),
            'title_norm': _norm_title(title), 'thumb': thumb, 'description': '',
            'url': url, 'source': 'pornone', 'streams': streams,
        }
        _cache.set(ck, film, 12 * 3600)
        return film
    except Exception as e:
        xbmc.log('[Starfleet/PornOne] detail error (%s): %s' % (slug, e), xbmc.LOGWARNING)
        return None


def _search_pnone_films(title, page=1):
    from urllib.parse import quote as _quote
    url = (PNONE_BASE + '/search?q=' + _quote(title)) if page <= 1 \
        else (PNONE_BASE + '/search/%d?q=' % page + _quote(title))
    try:
        html = _get(url)
        stubs, seen = [], set()
        for m in _RE_PNONE_CARD.finditer(html):
            film_url, slug, vid = m.group(1), m.group(2), m.group(3)
            if vid not in seen:
                seen.add(vid)
                stubs.append({'slug': slug + '-' + vid, 'url': film_url})
    except Exception as e:
        xbmc.log('[Starfleet/PornOne] search error: %s' % e, xbmc.LOGWARNING)
        stubs = []
    return _pfetch(stubs, lambda s: _pnone_film_detail(s['slug'], s['url']))


# ── porndig.com ──────────────────────────────────────────────────────────────
# Confirmed live 2026-08-15: homepage itself is infinite-scroll/AJAX for
# further pages (robots.txt explicitly Disallows the load_more_posts AJAX
# endpoint), but the dedicated /video listing page has real static
# pagination at /video/page/N/ (0 slug overlap page1 vs page2). Search at
# /search/<query> works for page 1 (real results, correct <title>) but no
# page-2 convention was found (?page=2/2/page/2/ all return byte-identical
# page-1 content) — search is wired page-1-only.  Detail pages embed the
# real player via an iframe (videos.porndig.com/player/index/...) whose own
# HTML contains signed, quality-tagged mp4 URLs — confirmed live playable
# with no Referer needed.
_RE_PDIG_CARD = re.compile(
    r'<a href="(/videos/(\d+)/[a-z0-9-]+\.html)">([^<]+)</a></h2>', re.IGNORECASE)
_RE_PDIG_EMBED = re.compile(r'"embedUrl":"([^"]+)"')
_RE_PDIG_MP4 = re.compile(
    r'(https?:[^"\']*?_h264_\d+_(\d+)\.mp4\?md5=[^"\'\\]+)', re.IGNORECASE)


def _porndig_latest(page=1):
    ck = 'pdig_latest_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached or []
    url = PDIG_BASE + ('/video' if page <= 1 else '/video/page/%d/' % page)
    try:
        html = _get(url)
        films, seen = [], set()
        for m in _RE_PDIG_CARD.finditer(html):
            film_url, vid, title = PDIG_BASE + m.group(1), m.group(2), _html_unescape.unescape(m.group(3))
            if vid in seen:
                continue
            seen.add(vid)
            films.append({'slug': vid, 'url': film_url, 'title': _clean_title(title),
                          'title_norm': _norm_title(title), 'thumb': '',
                          'source': 'porndig', 'streams': []})
        _cache.set(ck, films, 2 * 3600)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/PornDig] latest error: %s' % e, xbmc.LOGWARNING)
        return []


def _porndig_film_detail(slug, url):
    ck = 'pdig_detail_%s' % slug[:60]
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        html = _get(url)
        m = re.search(r'<title>([^<]+)</title>', html, re.IGNORECASE)
        title = re.sub(r'\s*[:-]\s*PornDig.*$', '', m.group(1), flags=re.IGNORECASE).strip() \
            if m else slug.replace('-', ' ').title()
        title = _html_unescape.unescape(title)
        thumb = _og(html, 'image')
        streams = []
        em = _RE_PDIG_EMBED.search(html)
        if em:
            embed_url = em.group(1).replace('\\/', '/')
            try:
                embed_html = _get(embed_url)
                candidates = []
                for pm in _RE_PDIG_MP4.finditer(embed_html):
                    candidates.append((int(pm.group(2)), pm.group(1).replace('\\/', '/')))
                candidates.sort(key=lambda x: -x[0])
                if candidates:
                    streams.append({'label': '[PornDig] %dp' % candidates[0][0], 'url': candidates[0][1]})
            except Exception as e:
                xbmc.log('[Starfleet/PornDig] embed error: %s' % e, xbmc.LOGWARNING)
        film = {
            'id': 'porndig_' + slug, 'slug': slug, 'title': _clean_title(title),
            'title_norm': _norm_title(title), 'thumb': thumb, 'description': '',
            'url': url, 'source': 'porndig', 'streams': streams,
        }
        _cache.set(ck, film, 12 * 3600)
        return film
    except Exception as e:
        xbmc.log('[Starfleet/PornDig] detail error (%s): %s' % (slug, e), xbmc.LOGWARNING)
        return None


def _search_porndig_films(title, page=1):
    """No confirmed page-2 convention (see module comment above) — only
    page 1 is ever fetched, additional pages return no extra results."""
    if page > 1:
        return []
    from urllib.parse import quote as _quote
    url = PDIG_BASE + '/search/' + _quote(title)
    try:
        html = _get(url)
        stubs, seen = [], set()
        for m in _RE_PDIG_CARD.finditer(html):
            film_url, vid = PDIG_BASE + m.group(1), m.group(2)
            if vid not in seen:
                seen.add(vid)
                stubs.append({'slug': vid, 'url': film_url})
    except Exception as e:
        xbmc.log('[Starfleet/PornDig] search error: %s' % e, xbmc.LOGWARNING)
        stubs = []
    return _pfetch(stubs, lambda s: _porndig_film_detail(s['slug'], s['url']))


# ── cumlouder.com ────────────────────────────────────────────────────────────
# Confirmed live 2026-08-15: homepage + /N/ real pagination (0 slug overlap
# page1 vs page2). Own search (/search/<query>/) is Cloudflare-challenged
# (403 "Just a moment...") — per policy this codebase does not attempt to
# bypass Cloudflare, so cumlouder is wired browse-only, no search. Detail
# page ships a direct <source> mp4 with a signed `secure=` token, confirmed
# playable with no Referer.
_RE_CUML_CARD = re.compile(
    r'href="(https://www\.cumlouder\.com/porn-video/([a-z0-9-]+)/)"', re.IGNORECASE)
_RE_CUML_MP4 = re.compile(r'<source\s+src="([^"]+\.mp4\?secure=[^"]+)"', re.IGNORECASE)


def _cumlouder_latest(page=1):
    ck = 'cuml_latest_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached or []
    url = CUML_BASE + ('/' if page <= 1 else '/%d/' % page)
    try:
        html = _get(url)
        films, seen = [], set()
        for m in _RE_CUML_CARD.finditer(html):
            film_url, slug = m.group(1), m.group(2)
            if slug in seen:
                continue
            seen.add(slug)
            title = slug.replace('-', ' ').title()
            films.append({'slug': slug, 'url': film_url, 'title': _clean_title(title),
                          'title_norm': _norm_title(title), 'thumb': '',
                          'source': 'cumlouder', 'streams': []})
        _cache.set(ck, films, 2 * 3600)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/Cumlouder] latest error: %s' % e, xbmc.LOGWARNING)
        return []


def _cumlouder_film_detail(slug, url):
    ck = 'cuml_detail_%s' % slug[:60]
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        html = _get(url)
        m = re.search(r'<title>([^<]+)</title>', html, re.IGNORECASE)
        title = re.sub(r'\s*[|-]\s*Cumlouder.*$', '', m.group(1), flags=re.IGNORECASE).strip() \
            if m else slug.replace('-', ' ').title()
        title = _html_unescape.unescape(title)
        thumb = _og(html, 'image')
        streams = []
        sm = _RE_CUML_MP4.search(html)
        if sm:
            streams.append({'label': '[Cumlouder] MP4', 'url': sm.group(1)})
        film = {
            'id': 'cumlouder_' + slug, 'slug': slug, 'title': _clean_title(title),
            'title_norm': _norm_title(title), 'thumb': thumb, 'description': '',
            'url': url, 'source': 'cumlouder', 'streams': streams,
        }
        _cache.set(ck, film, 12 * 3600)
        return film
    except Exception as e:
        xbmc.log('[Starfleet/Cumlouder] detail error (%s): %s' % (slug, e), xbmc.LOGWARNING)
        return None


def _search_cumlouder_films(title, page=1):
    """cumlouder.com's own search endpoint is Cloudflare-challenged
    (confirmed live 2026-08-15) — not bypassed per policy, always returns
    no results rather than forcing a broken search."""
    return []


# ── porngo.com ───────────────────────────────────────────────────────────────
# Confirmed live 2026-08-15: /latest-updates/ for page 1, oddly-but-really
# named /private/N/ for page N>1 (that's the site's own "Last"/numbered
# pagination link target, nothing to do with private content) — 0 slug
# overlap page1 vs page2. Search at /search/<query>/ + /search/<query>/N/,
# also 0 overlap. Detail page ships a get_file/1021/... mp4 URL with a
# `cparam` token that 302-redirects (twice) to a real CDN file, confirmed
# playable with no Referer.
_RE_PGO_CARD = re.compile(
    r'href="(https://www\.porngo\.com/videos/(\d+)/([a-z0-9-]+)/)"', re.IGNORECASE)
_RE_PGO_MP4 = re.compile(r"source src='([^']+\.mp4/\?cparam=[^']+)'", re.IGNORECASE)


def _porngo_latest(page=1):
    ck = 'pgo_latest_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached or []
    url = PGO_BASE + '/latest-updates/' if page <= 1 else PGO_BASE + '/private/%d/' % page
    try:
        html = _get(url)
        films, seen = [], set()
        for m in _RE_PGO_CARD.finditer(html):
            film_url, vid, slug = m.group(1), m.group(2), m.group(3)
            if vid in seen:
                continue
            seen.add(vid)
            title = slug.replace('-', ' ').title()
            films.append({'slug': vid, 'url': film_url, 'title': _clean_title(title),
                          'title_norm': _norm_title(title), 'thumb': '',
                          'source': 'porngo', 'streams': []})
        _cache.set(ck, films, 2 * 3600)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/PornGO] latest error: %s' % e, xbmc.LOGWARNING)
        return []


def _porngo_film_detail(slug, url):
    ck = 'pgo_detail_%s' % slug[:60]
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        html = _get(url)
        m = re.search(r'<title>([^<]+)</title>', html, re.IGNORECASE)
        title = re.sub(r'\s*-\s*PornGO.*$', '', m.group(1), flags=re.IGNORECASE).strip() \
            if m else slug.replace('-', ' ').title()
        title = _html_unescape.unescape(title)
        thumb = _og(html, 'image')
        streams = []
        sm = _RE_PGO_MP4.search(html)
        if sm:
            streams.append({'label': '[PornGO] MP4', 'url': sm.group(1)})
        film = {
            'id': 'porngo_' + slug, 'slug': slug, 'title': _clean_title(title),
            'title_norm': _norm_title(title), 'thumb': thumb, 'description': '',
            'url': url, 'source': 'porngo', 'streams': streams,
        }
        _cache.set(ck, film, 12 * 3600)
        return film
    except Exception as e:
        xbmc.log('[Starfleet/PornGO] detail error (%s): %s' % (slug, e), xbmc.LOGWARNING)
        return None


def _search_porngo_films(title, page=1):
    from urllib.parse import quote as _quote
    url = PGO_BASE + '/search/' + _quote(title) + '/' + ('' if page <= 1 else '%d/' % page)
    try:
        html = _get(url)
        stubs, seen = [], set()
        for m in _RE_PGO_CARD.finditer(html):
            film_url, vid = m.group(1), m.group(2)
            if vid not in seen:
                seen.add(vid)
                stubs.append({'slug': vid, 'url': film_url})
    except Exception as e:
        xbmc.log('[Starfleet/PornGO] search error: %s' % e, xbmc.LOGWARNING)
        stubs = []
    return _pfetch(stubs, lambda s: _porngo_film_detail(s['slug'], s['url']))


# ── allpornstream.com ────────────────────────────────────────────────────────
# Confirmed live 2026-08-15: server-rendered listing (Next.js app, but the
# homepage/listing itself ships a full JSON-LD ItemList with every video's
# name/url/thumbnail — no client JS needed to read it) with real /?page=N
# pagination (0-1 slug overlap page1 vs page2). No working search endpoint
# found (?search=X and /search/X both either 404 or silently ignore the
# query and return the same generic listing) — wired browse-only. Detail
# pages embed a `video_urls.iframe[]` JSON array with per-host health
# tracking (hosting_provider + status_text) already baked in by the site
# itself — filtering to entries the site's own system marked "OK" (e.g.
# STREAMTAPE, confirmed live with a real, non-dead embed page) skips the
# dead/unrecognized hosts (e.g. mydaddy.cc, confirmed live to return
# "This domain has been blocked") automatically. The resulting hoster URL
# is passed straight through — same as PandaMovies' own hoster links —
# relying on adult_stream_play's existing ResolveURL chain at play time.
_RE_APS_ITEM = re.compile(
    r'"@type":"VideoObject","position":\d+,"name":"([^"]+)","url":"(/post/[a-f0-9-]+/[a-z0-9-]+)"'
    r'[^}]*?"thumbnailUrl":\["([^"]+)"',
    re.IGNORECASE
)
_RE_APS_IFRAME = re.compile(
    r'"embed_url":"([^"]+)","file_code":[^,]*,"hosting_provider":"([A-Za-z0-9_]+)"[^}]*?"status_text":"OK"',
    re.IGNORECASE
)


def _aps_latest(page=1):
    ck = 'aps_latest_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached or []
    url = APS_BASE + ('/' if page <= 1 else '/?page=%d' % page)
    try:
        html = _get(url)
        films, seen = [], set()
        for m in _RE_APS_ITEM.finditer(html):
            title, path, thumb = m.group(1), m.group(2), m.group(3).replace('\\/', '/')
            slug = path.split('/')[-1]
            if slug in seen:
                continue
            seen.add(slug)
            films.append({'slug': slug, 'url': APS_BASE + path, 'title': _clean_title(title),
                          'title_norm': _norm_title(title), 'thumb': thumb,
                          'source': 'allpornstream', 'streams': []})
        _cache.set(ck, films, 2 * 3600)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/APS] latest error: %s' % e, xbmc.LOGWARNING)
        return []


def _aps_film_detail(slug, url):
    ck = 'aps_detail_%s' % slug[:60]
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        html = _get(url)
        title = _og(html, 'title') or slug.replace('-', ' ').title()
        thumb = _og(html, 'image')
        streams = []
        seen_urls = set()
        for m in _RE_APS_IFRAME.finditer(html):
            embed_url, provider = m.group(1).replace('\\/', '/'), m.group(2)
            if embed_url in seen_urls:
                continue
            seen_urls.add(embed_url)
            streams.append({'label': '[APS] %s' % provider.title(), 'url': embed_url})
        film = {
            'id': 'aps_' + slug, 'slug': slug, 'title': _clean_title(title),
            'title_norm': _norm_title(title), 'thumb': thumb, 'description': '',
            'url': url, 'source': 'allpornstream', 'streams': streams,
        }
        _cache.set(ck, film, 12 * 3600)
        return film
    except Exception as e:
        xbmc.log('[Starfleet/APS] detail error (%s): %s' % (slug, e), xbmc.LOGWARNING)
        return None


def _search_aps_films(title, page=1):
    """No working search endpoint found on allpornstream.com (confirmed
    live 2026-08-15) — always returns no results rather than forcing a
    broken search."""
    return []


# ── mangoporn.net (Pattern B — full movies) ──────────────────────────────────
# DooPlay WordPress theme, same class="item movies" card shape and
# data-fl-url="..." stream-tabs convention already used by watchpornfree.info
# (_RE_WPF_STREAMS/_WPF_STREAM_SKIP below are reused as-is — the regex itself
# has nothing watchpornfree-specific in it). Confirmed live 2026-08-15:
# /movies/ + /movies/page/N/ real pagination (0 overlap page1 vs page2);
# search at /?s=X (page 1) / /page/N/?s=X (page N), both real. Host list on
# detail pages: doodstream/lulustream/voe/mixdrop (ResolveURL-supported) plus
# nitroflare/rapidgator/frdl.io premium lockers, filtered out same as WPF.
_RE_MANGO_CARD = re.compile(
    r'<h3><a href="(https://mangoporn\.net/movies/([a-z0-9-]+)/)">([^<]+)</a></h3>',
    re.IGNORECASE
)
# Search results page uses a different card shape than the /movies/ archive.
_RE_MANGO_SEARCH_CARD = re.compile(
    r'<div class="details">\s*<div class="title">\s*<a href="(https://mangoporn\.net/movies/([a-z0-9-]+)/)">([^<]+)</a>',
    re.IGNORECASE
)


def _mango_film_list(page=1):
    ck = 'mango_list_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached or []
    url = MANGO_BASE + '/movies/' + ('' if page <= 1 else 'page/%d/' % page)
    try:
        html = _get(url)
        films, seen = [], set()
        for m in _RE_MANGO_CARD.finditer(html):
            film_url, slug, title = m.group(1), m.group(2), _html_unescape.unescape(m.group(3))
            if slug in seen:
                continue
            seen.add(slug)
            window = html[max(0, m.start() - 600):m.start()]
            ti = re.search(r'<img[^>]+src="([^"]+)"', window, re.IGNORECASE)
            thumb = ti.group(1) if ti else ''
            films.append({'slug': slug, 'url': film_url, 'title': _clean_title(title), 'thumb': thumb})
        _cache.set(ck, films, 6 * 3600)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/MangoPorn] list error: %s' % e, xbmc.LOGWARNING)
        return []


def _mango_film_detail(slug, film_url, title='', thumb=''):
    ck = 'mango_detail_%s' % slug[:60]
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        html = _get(film_url)
        if not title:
            m = re.search(r'<h1[^>]*>([^<]+)</h1>', html, re.IGNORECASE)
            title = _clean(m.group(1)) if m else slug.replace('-', ' ').title()
        if not thumb:
            thumb = _og(html, 'image')
        desc = _og(html, 'description')
        seen_urls, streams = set(), []
        for m in _RE_WPF_STREAMS.finditer(html):
            su = m.group(1)
            if _skip_locker_unless_debrid(su) or 'deadUrl' in su or su in seen_urls:
                continue
            seen_urls.add(su)
            dom = re.search(r'https?://(?:www\.)?([^./]+)', su)
            streams.append({'label': dom.group(1).capitalize() if dom else 'Stream', 'url': su})
        film = {
            'id': 'mango_%s' % slug, 'slug': slug, 'title': _clean_title(title),
            'title_norm': _norm_title(title), 'thumb': thumb, 'description': desc,
            'url': film_url, 'source': 'mangoporn', 'streams': streams,
        }
        _cache.set(ck, film, 24 * 3600)
        return film
    except Exception as e:
        xbmc.log('[Starfleet/MangoPorn] detail error (%s): %s' % (slug, e), xbmc.LOGWARNING)
        return None


def get_mango_films(page=1):
    stubs = _mango_film_list(page)
    if not stubs:
        return []
    return _pfetch(stubs, lambda s: _mango_film_detail(s['slug'], s['url'], s.get('title', ''), s.get('thumb', '')),
                   limit=len(stubs))


def _search_mango_films(title, page=1):
    """Confirmed live 2026-08-15: the search RESULTS page uses a different
    card markup (<div class="details"><div class="title"><a href=...) than
    the /movies/ category archive (<h3><a href=...) — needs its own regex,
    not _RE_MANGO_CARD."""
    from urllib.parse import quote as _quote
    url = MANGO_BASE + (('/?s=' + _quote(title)) if page <= 1 else ('/page/%d/?s=' % page) + _quote(title))
    try:
        html = _get(url)
        stubs, seen = [], set()
        for m in _RE_MANGO_SEARCH_CARD.finditer(html):
            film_url, slug, mtitle = m.group(1), m.group(2), _html_unescape.unescape(m.group(3))
            if slug not in seen:
                seen.add(slug)
                stubs.append({'slug': slug, 'url': film_url, 'title': mtitle})
    except Exception as e:
        xbmc.log('[Starfleet/MangoPorn] search error: %s' % e, xbmc.LOGWARNING)
        stubs = []
    return _pfetch(stubs, lambda s: _mango_film_detail(s['slug'], s['url'], s.get('title', '')), limit=8)


# ── streamporn.vip (Pattern B — full movies) ─────────────────────────────────
# Same "pornwatch.ws" DooPlay-family card shape (data-movie-id + oldtitle +
# class="ml-mask jt") and the same data-fl-url stream-tabs convention.
# Confirmed live 2026-08-15: /movies/ + /movies/page/N/ real pagination;
# search at /?s=X (page 1) / /page/N/?s=X (page N), both real (0 overlap).
# Site is slow (occasionally needs a long read timeout) but genuinely live.
_RE_SPVIP_CARD = re.compile(
    r'data-movie-id="\d+"[^>]*>.*?'
    r'href="(https?://streamporn\.vip/(watch-[a-z0-9-]+)/)"[^>]*'
    r'oldtitle="([^"]+)"',
    re.IGNORECASE | re.DOTALL
)


def _spvip_film_list(page=1):
    ck = 'spvip_list_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached or []
    url = SPVIP_BASE + ('/movies/' if page <= 1 else '/movies/page/%d/' % page)
    try:
        html = _get(url, timeout=(5, 20))
        films, seen = [], set()
        for m in _RE_SPVIP_CARD.finditer(html):
            film_url, slug, title = m.group(1), m.group(2), _html_unescape.unescape(m.group(3))
            if slug in seen:
                continue
            seen.add(slug)
            films.append({'slug': slug, 'url': film_url, 'title': _clean_title(title), 'thumb': ''})
        _cache.set(ck, films, 6 * 3600)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/StreamPorn] list error: %s' % e, xbmc.LOGWARNING)
        return []


def _spvip_film_detail(slug, film_url, title='', thumb=''):
    ck = 'spvip_detail_%s' % slug[:60]
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        html = _get(film_url, timeout=(5, 20))
        if not title:
            m = re.search(r'<h1[^>]*>([^<]+)</h1>', html, re.IGNORECASE)
            title = _clean(m.group(1)) if m else slug.replace('-', ' ').title()
        if not thumb:
            thumb = _og(html, 'image')
        desc = _og(html, 'description')
        seen_urls, streams = set(), []
        for m in _RE_WPF_STREAMS.finditer(html):
            su = m.group(1)
            if _skip_locker_unless_debrid(su) or 'deadUrl' in su or su in seen_urls:
                continue
            seen_urls.add(su)
            dom = re.search(r'https?://(?:www\.)?([^./]+)', su)
            streams.append({'label': dom.group(1).capitalize() if dom else 'Stream', 'url': su})
        film = {
            'id': 'spvip_%s' % slug, 'slug': slug, 'title': _clean_title(title),
            'title_norm': _norm_title(title), 'thumb': thumb, 'description': desc,
            'url': film_url, 'source': 'streamporn', 'streams': streams,
        }
        _cache.set(ck, film, 24 * 3600)
        return film
    except Exception as e:
        xbmc.log('[Starfleet/StreamPorn] detail error (%s): %s' % (slug, e), xbmc.LOGWARNING)
        return None


def get_streamporn_films(page=1):
    stubs = _spvip_film_list(page)
    if not stubs:
        return []
    return _pfetch(stubs, lambda s: _spvip_film_detail(s['slug'], s['url'], s.get('title', ''), s.get('thumb', '')),
                   limit=len(stubs))


def _search_spvip_films(title, page=1):
    from urllib.parse import quote as _quote
    url = SPVIP_BASE + (('/?s=' + _quote(title)) if page <= 1 else ('/page/%d/?s=' % page) + _quote(title))
    try:
        html = _get(url, timeout=(5, 30))
        stubs, seen = [], set()
        for m in _RE_SPVIP_CARD.finditer(html):
            film_url, slug, mtitle = m.group(1), m.group(2), _html_unescape.unescape(m.group(3))
            if slug not in seen:
                seen.add(slug)
                stubs.append({'slug': slug, 'url': film_url, 'title': mtitle})
    except Exception as e:
        xbmc.log('[Starfleet/StreamPorn] search error: %s' % e, xbmc.LOGWARNING)
        stubs = []
    return _pfetch(stubs, lambda s: _spvip_film_detail(s['slug'], s['url'], s.get('title', '')), limit=8)


# ── swingerpornfun.com (Pattern B — full movies) ─────────────────────────────
# Plain WordPress blog theme (date-based permalinks). Confirmed live
# 2026-08-15: homepage + /page/N/ real pagination; own search at ?s=X +
# /page/N/?s=X, both real. Detail pages embed 2-3 real third-party player
# iframes (streamwish/doodstream/streamtape-style clone domains, all under
# an /e/<code> embed path — ad iframes on the same page use a different path
# shape so a plain /e/ path match cleanly excludes them) — passed straight
# through to adult_stream_play's existing ResolveURL chain, same as every
# other hoster-embed site in this file.
_RE_SPF_CARD = re.compile(
    r'<a href="(https://swingerpornfun\.com/\d{4}/\d{2}/\d{2}/([a-z0-9-]+)/)" title="([^"]+)">',
    re.IGNORECASE
)
_RE_SPF_STREAMS = re.compile(r'<iframe src="(https?://[a-z0-9.-]+/e/[a-zA-Z0-9=/_-]+)"', re.IGNORECASE)


def _sf_film_list(page=1):
    ck = 'sf_list_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached or []
    url = SPF_BASE + ('/' if page <= 1 else '/page/%d/' % page)
    try:
        html = _get(url)
        films, seen = [], set()
        for m in _RE_SPF_CARD.finditer(html):
            film_url, slug, title = m.group(1), m.group(2), _html_unescape.unescape(m.group(3))
            if slug in seen:
                continue
            seen.add(slug)
            window = html[m.end():m.end() + 500]
            ti = re.search(r'<img[^>]+src="([^"]+)"', window, re.IGNORECASE)
            thumb = ti.group(1) if ti else ''
            films.append({'slug': slug, 'url': film_url, 'title': _clean_title(title), 'thumb': thumb})
        _cache.set(ck, films, 6 * 3600)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/SwingerPornFun] list error: %s' % e, xbmc.LOGWARNING)
        return []


def _sf_film_detail(slug, film_url, title='', thumb=''):
    ck = 'sf_detail_%s' % slug[:60]
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        html = _get(film_url)
        if not title:
            m = re.search(r'<h1[^>]*>([^<]+)</h1>', html, re.IGNORECASE)
            title = _clean(m.group(1)) if m else slug.replace('-', ' ').title()
        if not thumb:
            thumb = _og(html, 'image')
        desc = _og(html, 'description')
        seen_urls, streams = set(), []
        for m in _RE_SPF_STREAMS.finditer(html):
            su = m.group(1)
            if su in seen_urls:
                continue
            seen_urls.add(su)
            dom = re.search(r'https?://(?:www\.)?([^./]+)', su)
            streams.append({'label': dom.group(1).capitalize() if dom else 'Stream', 'url': su})
        film = {
            'id': 'sf_%s' % slug, 'slug': slug, 'title': _clean_title(title),
            'title_norm': _norm_title(title), 'thumb': thumb, 'description': desc,
            'url': film_url, 'source': 'swingerpornfun', 'streams': streams,
        }
        _cache.set(ck, film, 24 * 3600)
        return film
    except Exception as e:
        xbmc.log('[Starfleet/SwingerPornFun] detail error (%s): %s' % (slug, e), xbmc.LOGWARNING)
        return None


def get_sf_films(page=1):
    stubs = _sf_film_list(page)
    if not stubs:
        return []
    return _pfetch(stubs, lambda s: _sf_film_detail(s['slug'], s['url'], s.get('title', ''), s.get('thumb', '')),
                   limit=len(stubs))


def _search_sf_films(title, page=1):
    from urllib.parse import quote as _quote
    url = SPF_BASE + (('/?s=' + _quote(title)) if page <= 1 else ('/page/%d/?s=' % page) + _quote(title))
    try:
        html = _get(url)
        stubs, seen = [], set()
        for m in _RE_SPF_CARD.finditer(html):
            film_url, slug, mtitle = m.group(1), m.group(2), _html_unescape.unescape(m.group(3))
            if slug not in seen:
                seen.add(slug)
                stubs.append({'slug': slug, 'url': film_url, 'title': mtitle})
    except Exception as e:
        xbmc.log('[Starfleet/SwingerPornFun] search error: %s' % e, xbmc.LOGWARNING)
        stubs = []
    return _pfetch(stubs, lambda s: _sf_film_detail(s['slug'], s['url'], s.get('title', '')), limit=8)


# ── en.paradisehill.cc (Pattern B — full movies) ─────────────────────────────
# Every HTML page (browse/search/detail) is gated behind an 18+ confirmation
# that sets a session cookie via POST /is18/ with a CSRF token scraped from
# the gate page itself (confirmed live 2026-08-15) — the video CDN itself
# (v1.paradisehill.cc) is NOT gated, only the HTML pages are. The gate flow
# runs once per addon-lifetime on a dedicated session, then every subsequent
# call reuses the cookie. Confirmed live: /popular/?filter=all&sort=by_likes
# + &page=N real pagination; own search at /search/?pattern=X&what=1 (Films
# only) + &page=N, both real. Detail pages ship a direct mp4 in a `videoList`
# JS var, confirmed playable with no Referer/cookie needed for the CDN URL
# itself.
_paradise_session = None
_paradise_gated = False

_RE_PARADISE_CARD = re.compile(
    r'<a href="(/([a-z0-9_]+)/)">\s*<picture>\s*<img itemprop="image" src="([^"]+)"[^>]*>'
    r'\s*</picture>\s*<span class="mask">\s*<div><span itemprop="name">([^<]*)</span>',
    re.IGNORECASE
)
_RE_PARADISE_MP4 = re.compile(r'"src":"(https:[^"]+\.mp4)"', re.IGNORECASE)


def _paradise_sess():
    global _paradise_session
    if _paradise_session is None:
        _paradise_session = requests.Session()
        _paradise_session.headers.update(HEADERS)
    return _paradise_session


def _paradise_get(url):
    global _paradise_gated
    s = _paradise_sess()
    if not _paradise_gated:
        try:
            r = s.get(PARADISE_BASE + '/', timeout=(5, 8))
            m = re.search(r'csrf-token"\s+content="([^"]+)"', r.text)
            if m:
                s.post(PARADISE_BASE + '/is18/', data={'_csrf-frontend': m.group(1), 'is18': 'yes'},
                       timeout=(5, 8))
        except Exception as e:
            xbmc.log('[Starfleet/ParadiseHill] age-gate error: %s' % e, xbmc.LOGWARNING)
        _paradise_gated = True
    r = s.get(url, timeout=(5, 8))
    r.raise_for_status()
    return r.text


def _paradise_film_list(page=1):
    ck = 'paradise_list_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached or []
    url = PARADISE_BASE + '/popular/?filter=all&sort=by_likes'
    if page > 1:
        url += '&page=%d' % page
    try:
        html = _paradise_get(url)
        films, seen = [], set()
        for m in _RE_PARADISE_CARD.finditer(html):
            path, slug, thumb = m.group(1), m.group(2), m.group(3)
            title = _html_unescape.unescape(_clean(m.group(4)))
            if slug in seen or not title:
                continue
            seen.add(slug)
            if thumb.startswith('/'):
                thumb = PARADISE_BASE + thumb
            films.append({'slug': slug, 'url': PARADISE_BASE + path, 'title': _clean_title(title), 'thumb': thumb})
        _cache.set(ck, films, 6 * 3600)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/ParadiseHill] list error: %s' % e, xbmc.LOGWARNING)
        return []


def _paradise_film_detail(slug, film_url, title='', thumb=''):
    ck = 'paradise_detail_%s' % slug[:60]
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        html = _paradise_get(film_url)
        if not title:
            m = re.search(r'itemprop="name">([^<]+)<', html, re.IGNORECASE)
            title = _html_unescape.unescape(_clean(m.group(1))) if m else slug.replace('_', ' ').title()
        if not thumb:
            thumb = _og(html, 'image')
            if thumb.startswith('/'):
                thumb = PARADISE_BASE + thumb
        desc = _og(html, 'description')
        streams = []
        sm = _RE_PARADISE_MP4.search(html)
        if sm:
            streams.append({'label': '[ParadiseHill] MP4', 'url': sm.group(1).replace('\\/', '/')})
        film = {
            'id': 'paradise_%s' % slug, 'slug': slug, 'title': _clean_title(title),
            'title_norm': _norm_title(title), 'thumb': thumb, 'description': desc,
            'url': film_url, 'source': 'paradisehill', 'streams': streams,
        }
        _cache.set(ck, film, 24 * 3600)
        return film
    except Exception as e:
        xbmc.log('[Starfleet/ParadiseHill] detail error (%s): %s' % (slug, e), xbmc.LOGWARNING)
        return None


def get_paradise_films(page=1):
    stubs = _paradise_film_list(page)
    if not stubs:
        return []
    return _pfetch(stubs, lambda s: _paradise_film_detail(s['slug'], s['url'], s.get('title', ''), s.get('thumb', '')),
                   limit=len(stubs))


def _search_paradise_films(title, page=1):
    from urllib.parse import quote as _quote
    url = PARADISE_BASE + '/search/?pattern=' + _quote(title) + '&what=1'
    if page > 1:
        url += '&page=%d' % page
    try:
        html = _paradise_get(url)
        stubs, seen = [], set()
        for m in _RE_PARADISE_CARD.finditer(html):
            path, slug, thumb = m.group(1), m.group(2), m.group(3)
            mtitle = _html_unescape.unescape(_clean(m.group(4)))
            if slug not in seen and mtitle:
                seen.add(slug)
                if thumb.startswith('/'):
                    thumb = PARADISE_BASE + thumb
                stubs.append({'slug': slug, 'url': PARADISE_BASE + path, 'title': mtitle, 'thumb': thumb})
    except Exception as e:
        xbmc.log('[Starfleet/ParadiseHill] search error: %s' % e, xbmc.LOGWARNING)
        stubs = []
    return _pfetch(stubs, lambda s: _paradise_film_detail(s['slug'], s['url'], s.get('title', ''), s.get('thumb', '')), limit=8)


# ── pelisxporno.net (full-length Spanish-language movies) ────────────────────
# Confirmed live 2026-08-15: standard WP video theme (wpst), server-rendered
# listing with a real ?s=<query> search (WP core search, real title-matched
# results). Detail pages embed the actual player directly in the HTML (no
# AJAX hop), but the host varies per film — confirmed two different ones on
# two different films (myvidplay.com, imperioporno.tv) with only ONE iframe
# present each time, no per-film "choose a server" list. myvidplay.com
# already matches this codebase's own generic embed resolver
# (embed_resolver.py's 'vidplay.' substring check); imperioporno.tv isn't a
# recognized host anywhere in this codebase, so films using it will fail to
# resolve at play time same as any other genuinely-unsupported host — this
# grabs whichever iframe is actually present rather than hardcoding one
# host, so myvidplay-hosted films (and any other host embed_resolver/
# resolveurl already knows) still work.
_RE_PXP_CARD = re.compile(
    r'<article[^>]+data-main-thumb="([^"]+)"[^>]*>\s*<a href="([^"]+)" title="([^"]+)">',
    re.IGNORECASE
)
_RE_PXP_IFRAME = re.compile(r'<iframe[^>]+src="(https://[^"]+)"', re.IGNORECASE)


def _pxp_get(url, timeout=(5, 8)):
    import requests
    headers = dict(HEADERS)
    r = requests.get(url, headers=headers, timeout=timeout)
    r.raise_for_status()
    return r.text


def _pxp_slug_from_url(url):
    return url.rstrip('/').rsplit('/', 1)[-1]


def _pxp_film_list(page=1):
    ck = 'pxp_list_%d' % page
    cached = _cache.get(ck)
    if cached is not None:
        return cached or []
    url = PXP_BASE + ('/' if page <= 1 else '/page/%d/' % page)
    try:
        html = _pxp_get(url)
        films, seen = [], set()
        for m in _RE_PXP_CARD.finditer(html):
            thumb, film_url, title = m.group(1), m.group(2), m.group(3)
            title = _html_unescape.unescape(_clean(title))
            slug = _pxp_slug_from_url(film_url)
            if slug in seen or not title:
                continue
            seen.add(slug)
            films.append({'slug': slug, 'url': film_url, 'title': _clean_title(title), 'thumb': thumb})
        _cache.set(ck, films, 6 * 3600)
        return films
    except Exception as e:
        xbmc.log('[Starfleet/PelisXPorno] list error: %s' % e, xbmc.LOGWARNING)
        return []


def _pxp_film_detail(slug, film_url, title='', thumb=''):
    ck = 'pxp_detail_%s' % slug[:60]
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        html = _pxp_get(film_url)
        if not title:
            m = re.search(r'itemprop="name"\s+content="([^"]+)"', html, re.IGNORECASE)
            title = _html_unescape.unescape(_clean(m.group(1))) if m else slug.replace('-', ' ').title()
        if not thumb:
            thumb = _og(html, 'image')
        desc = _og(html, 'description')
        streams = []
        sm = _RE_PXP_IFRAME.search(html)
        if sm:
            streams.append({'label': '[PelisXPorno] MyVidPlay', 'url': sm.group(1)})
        film = {
            'id': 'pxp_%s' % slug, 'slug': slug, 'title': _clean_title(title),
            'title_norm': _norm_title(title), 'thumb': thumb, 'description': desc,
            'url': film_url, 'source': 'pelisxporno', 'streams': streams,
        }
        _cache.set(ck, film, 24 * 3600)
        return film
    except Exception as e:
        xbmc.log('[Starfleet/PelisXPorno] detail error (%s): %s' % (slug, e), xbmc.LOGWARNING)
        return None


def get_pxp_films(page=1):
    stubs = _pxp_film_list(page)
    if not stubs:
        return []
    return _pfetch(stubs, lambda s: _pxp_film_detail(s['slug'], s['url'], s.get('title', ''), s.get('thumb', '')),
                   limit=len(stubs))


def _search_pxp_films(title, page=1):
    from urllib.parse import quote as _quote
    url = PXP_BASE + '/?s=' + _quote(title)
    if page > 1:
        url = PXP_BASE + '/page/%d/?s=' % page + _quote(title)
    try:
        html = _pxp_get(url)
        stubs, seen = [], set()
        for m in _RE_PXP_CARD.finditer(html):
            thumb, film_url, mtitle = m.group(1), m.group(2), m.group(3)
            mtitle = _html_unescape.unescape(_clean(mtitle))
            slug = _pxp_slug_from_url(film_url)
            if slug not in seen and mtitle:
                seen.add(slug)
                stubs.append({'slug': slug, 'url': film_url, 'title': mtitle, 'thumb': thumb})
    except Exception as e:
        xbmc.log('[Starfleet/PelisXPorno] search error: %s' % e, xbmc.LOGWARNING)
        stubs = []
    return _pfetch(stubs, lambda s: _pxp_film_detail(s['slug'], s['url'], s.get('title', ''), s.get('thumb', '')), limit=8)


# Sources that are themselves stream providers (never filtered out of the library)
STREAM_SOURCE_NAMES = frozenset({
    'pandamovies', 'hqporner', 'freeomovie', 'xxxmoviestream',
    'pornwatch', 'adultdvdparadise', 'watchpornfree', 'speedporn', 'xxxscenes', 'xmovix',
    'xvideos', 'xnxx', 'pornhub', 'youporn', 'xhamster', 'xerotica',
    'redtube', 'tube8', 'thumbzilla', 'porntrex', 'noodlemagazine', 'letmejizz',
    'eporner', 'beeg', 'tnaflix', 'txxx', 'hdzog', '6xtube',
    # Added 2026-08-15 (Scenes)
    'pornhat', 'okxxx', '3movs', 'justporn', 'porn00', 'xmoviesforyou',
    'pornone', 'porndig', 'cumlouder', 'porngo', 'allpornstream',
    # Added 2026-08-15 (Movies)
    'mangoporn', 'streamporn', 'swingerpornfun', 'paradisehill', 'pelisxporno',
})


def get_library_stubs_bulk(max_pages=15):
    """
    Bulk-fetch list-page stubs from ALL free stream sources, pandamovies, and
    hqporner WITHOUT hitting detail pages.  Returns a flat list of library-
    compatible film dicts (title, thumb, slug, url, source, id).

    Called once by _build_full_library; results are cached inside each source's
    own list-page cache (6 h), so repeat calls are instant.
    """
    from concurrent.futures import ThreadPoolExecutor

    def _to_stub(src, slug, url, title='', thumb=''):
        t = title or slug.replace('-', ' ').title()
        return {
            'id':         '%s_%s' % (src, slug),
            'slug':       slug,
            'title':      t,
            'title_norm': _norm_title(t),
            'thumb':      thumb,
            'description': '',
            'url':        url,
            'source':     src,
            'streams':    [],
        }

    all_stubs = []

    # ── Free stream sources: fetch list pages in parallel ────────────────────
    free_jobs = []
    for pg in range(1, max_pages + 1):
        free_jobs.append(('freeo',       pg, lambda p: _freeo_film_list(p)))
        free_jobs.append(('xxxms',       pg, lambda p: _xxxms_film_list(p)))
        free_jobs.append(('wpw',         pg, lambda p: _wpw_film_list(p)))
        free_jobs.append(('adp',         pg, lambda p: _adp_film_list(p)))
        free_jobs.append(('wpf',         pg, lambda p: _wpf_film_list(p)))
        free_jobs.append(('spn',         pg, lambda p: _spn_film_list(p)))
        free_jobs.append(('xxxsc',       pg, lambda p: _xxxsc_film_list(p)))
        # Added 2026-08-15 (Pattern B / Movies) — paradisehill is a genuine
        # full-length-movie source, same content type as the sources above.
        # mangoporn/streamporn.vip/swingerpornfun were also added here
        # initially but corrected per direct confirmation: those three are
        # scenes/clip sites, not full movies, so they don't belong in the
        # Full Library free-movies feed (would surface short clips mixed in
        # among real movies).
        free_jobs.append(('paradise',    pg, lambda p: _paradise_film_list(p)))
        free_jobs.append(('pxp',         pg, lambda p: _pxp_film_list(p)))

    # Capture loop variables correctly
    def _fetch_free(src_key, page, fn):
        try:
            return src_key, fn(page)
        except Exception:
            return src_key, []

    _SRC_MAP = {
        'freeo':  'freeomovie',
        'xxxms':  'xxxmoviestream',
        'wpw':    'pornwatch',
        'adp':    'adultdvdparadise',
        'wpf':    'watchpornfree',
        'spn':    'speedporn',
        'xxxsc':  'xxxscenes',
        'paradise': 'paradisehill',
        'pxp':      'pelisxporno',
    }

    # Confirmed live 2026-08-28 (real user report: full library load still
    # slow even after the hqporner/sync-verify fixes) — 'for fut in futs:
    # fut.result(timeout=20)' iterates in SUBMISSION order, not completion
    # order. With 135 jobs across 9 sites at only 24 workers, if even one
    # early-submitted job is slow that particular run (real site
    # rate-limiting/latency), this loop blocks on IT for up to 20s before
    # even checking the next job — even though dozens of later jobs had
    # already finished on their own worker threads seconds earlier. This
    # is exactly why two loads 9 minutes apart (same job set, same cache
    # state) measured 13.0s and 42.1s — whichever job happened to be the
    # slow one that run dictated the whole phase's time. as_completed()
    # fixes this by yielding whichever future finishes next, regardless of
    # submission order.
    from concurrent.futures import as_completed as _as_completed
    with ThreadPoolExecutor(max_workers=24) as pool:
        futs = [pool.submit(_fetch_free, sk, pg, fn) for sk, pg, fn in free_jobs]
        try:
            for fut in _as_completed(futs, timeout=20):
                try:
                    src_key, items = fut.result()
                    src = _SRC_MAP.get(src_key, src_key)
                    for s in (items or []):
                        all_stubs.append(_to_stub(
                            src, s['slug'], s['url'],
                            s.get('title', ''), s.get('thumb', '')
                        ))
                except Exception:
                    pass
        except Exception:
            pass

    # ── PandaMovies: enumerate genres then fetch pages 1-8 per genre ─────────
    try:
        genres = _panda_genres()
        panda_jobs = []
        for g in genres:
            for pg in range(1, 9):
                panda_jobs.append((g['url'], pg))

        def _fetch_panda(gurl, pg):
            try:
                return _panda_movies_for_genre(gurl, pg)
            except Exception:
                return []

        # Same as_completed fix as the free-sources loop above — same
        # symptom (this is the LARGER of the two job sets, up to ~160
        # genre*page jobs at 20 workers, so an early straggler here has
        # even more room to inflate the whole phase).
        from concurrent.futures import as_completed as _as_completed2
        with ThreadPoolExecutor(max_workers=20) as pool:
            futs = [pool.submit(_fetch_panda, gu, pg) for gu, pg in panda_jobs]
            try:
                for fut in _as_completed2(futs, timeout=20):
                    try:
                        for film in (fut.result() or []):
                            all_stubs.append({
                                'id':         'pandamovies_%s' % film['slug'],
                                'slug':       film['slug'],
                                'title':      film.get('title', ''),
                                'title_norm': _norm_title(film.get('title', '')),
                                'thumb':      film.get('thumb', ''),
                                'description': '',
                                'url':        film.get('url', ''),
                                'source':     'pandamovies',
                                'streams':    [],
                            })
                    except Exception:
                        pass
            except Exception:
                pass
    except Exception:
        pass

    # HQPorner deliberately NOT scraped here (removed 2026-08-28, per direct
    # confirmation) — it's a scenes/clips site, not full movies, same
    # exclusion reasoning already applied to mangoporn/streamporn.vip/
    # swingerpornfun above. This alone used to cost every cold Full Library
    # load ~40 categories x 5 pages = ~200 requests (most of them guaranteed
    # 404s under the old, now-fixed pagination scheme — see
    # _hqporner_movies()'s own fix), for content that never belonged in this
    # movies-only feed to begin with. HQPorner is still fully usable
    # elsewhere (its own browse/search, get_hqporner_category_movies() for
    # the unified Adult search) — only this bulk full-library scrape is
    # affected.

    xbmc.log('[Starfleet/Library] get_library_stubs_bulk: %d raw stubs' % len(all_stubs), xbmc.LOGWARNING)
    return all_stubs


def search_by_title(title, page=1):
    """
    Search all adult scrapers + scraper_sources for streams matching `title`.
    Uses each site's own search endpoint (/?s=title) rather than page 1 catalog,
    so films anywhere in the archive can be found, not just the most recent.
    scraper_sources (cuevana3, hdtodayz, netmirror, zaxflix, rarefilmm, 1shows,
    456movie, msearch) are also searched as supplementary sources.
    Returns list of {'label': str, 'url': str} dicts.

    `page` (added 2026-08-14) is threaded into every underlying search_fn
    call below — both the 8 legacy free-stream sites' own
    _search_*_films(title, page) and each Scenes-registry tube site's
    search(query, page) — so a single call with page=2 genuinely re-scrapes
    page 2 from every site that supports it, all in the same concurrent
    pool as page 1, not a no-op page param. Verified live 2026-08-14
    site-by-site (see each _search_*_films'/search_*_movies' own docstring
    for the specific evidence): of the 18 Scenes tube sites, 16 got real,
    working pagination (xvideos, xnxx, pornhub, youporn, xhamster,
    xerotica, redtube, tube8, thumbzilla, porntrex, letmejizz, eporner,
    tnaflix, txxx, hdzog, 6xtube); noodlemagazine and beeg did NOT because
    their search endpoints are already broken independent of pagination
    (noodlemagazine's /search/<query> 404s even at page 1; beeg's
    /facts/search API returns a bad_request error for every query tried) —
    both are left on page 1 only rather than papering over a pre-existing
    break with fake pagination. Of the 8 legacy sites, 6 got real
    pagination (freeo, xxxms, wpf, spn, xmovix, panda); xxxscenes' search
    was already returning 0 results before this change (unrelated bug) and
    hqporner's search page ignores a page param entirely (confirmed live:
    identical results with or without it) — both stay page 1 only for the
    same reason.
    """
    from concurrent.futures import ThreadPoolExecutor, as_completed

    norm_query = _norm_title(title)
    if not norm_query:
        return []

    search_fns = [
        _search_freeo_films,
        _search_xxxms_films,
        _search_wpf_films,
        _search_spn_films,
        _search_xxxsc_films,
        _search_panda_films,
        # _search_xmovix_films / _search_hqporner_films deliberately NOT
        # listed here — confirmed live both sites' own search endpoints
        # return the exact same top results regardless of what's actually
        # searched (tested a real query against several different nonsense
        # strings; hd.xmovix.net's /?s= and hqporner.com's /?search= both
        # came back byte-for-byte identical every time), unlike every
        # other site here whose results genuinely change with the query.
        # Since the local title-text filter that used to mask this was
        # removed (see search_by_title()'s merge loop below), leaving
        # these wired in would inject the same handful of unrelated
        # "trending" titles into every single search. Their own browse/
        # listing functions (get_xmovix_films/get_hqporner_films) are
        # untouched — only their broken SEARCH contribution is dropped.
        # Added 2026-08-15 (Pattern B / Movies — mangoporn.net, streamporn.vip,
        # swingerpornfun.com, en.paradisehill.cc; all four confirmed live with
        # real search + real page-N pagination)
        _search_mango_films,
        _search_spvip_films,
        _search_sf_films,
        _search_paradise_films,
        _search_pxp_films,
        # NOTE: pornhat/okxxx/3movs/justporn/porn00/xmoviesforyou/pornone/
        # porndig/cumlouder/porngo/allpornstream are deliberately NOT listed
        # here even though each has its own _search_<x>_films function —
        # those are already reached automatically below via
        # _adult_scene_site_registry() (each registry entry's own 'search'
        # key is a thin wrapper around the exact same function, e.g.
        # search_pornhat_movies() just calls _search_pornhat_films()).
        # Listing them again here would search the same site twice per
        # query for no benefit — caught and reverted 2026-08-15 after
        # initially double-wiring them.
    ]

    # The Scenes picker's 18 tube sites (xvideos/xnxx/pornhub/youporn/
    # xhamster/xerotica/redtube/tube8/thumbzilla/porntrex/noodlemagazine/
    # letmejizz/eporner/beeg/tnaflix/txxx/hdzog/6xtube) were never reachable
    # from this top-level Adult search box — confirmed live, searching e.g.
    # "threesome" or a performer name only ever hit the 8 legacy free-stream
    # stubs above, never any of these. Registry is defined in afdb_router.py
    # (lazy-imported here, same as afdb_router's own lazy import of this
    # module, to avoid a circular import at module-load time) — each site's
    # own search() already exists (used by the Scenes picker's per-site
    # "Search X" entry), it just needed wiring in here too.
    try:
        from resources.lib.afdb_router import _adult_scene_site_registry
        for _site_key, _site_info in _adult_scene_site_registry().items():
            # `p` (positional, matching how every search_fn below is called
            # — pool.submit(fn, title, page)) is threaded straight into
            # this site's own search(query, page) shim, so a single
            # search_by_title(title, page=2) call really does re-scrape
            # page 2 from every one of these 18 sites concurrently, not
            # just the 8 legacy ones above.
            def _scene_search_fn(t, p=1, _sk=_site_key, _si=_site_info):
                try:
                    stubs = _si['search'](t, p) or []
                except Exception as e:
                    xbmc.log('[Starfleet/Streams] %s search error: %s' % (_sk, e), xbmc.LOGWARNING)
                    return []
                return _pfetch(stubs, lambda s, d=_si['detail']: d(s['slug'], s['url']))
            _scene_search_fn.__name__ = 'scene_' + _site_key
            search_fns.append(_scene_search_fn)
    except Exception as e:
        xbmc.log('[Starfleet/Streams] scene registry import error: %s' % e, xbmc.LOGWARNING)

    streams   = []
    seen_urls = set()

    # Deliberately NOT a 'with ThreadPoolExecutor(...) as pool:' block —
    # that form calls shutdown(wait=True) on exit, which blocks until EVERY
    # submitted task finishes, regardless of the as_completed(timeout=30)
    # below already giving up. Confirmed live as the actual root cause of
    # "search takes forever": a single slow site (e.g. Eporner, currently
    # taking 200+s on its own — see the dns_fallback/eporner investigation)
    # occupies one of the worker threads, and the old with-block silently
    # kept the whole function blocked for that entire duration even though
    # the soft 30s cutoff had long since been logged. shutdown(wait=False)
    # lets this function return promptly once the soft cutoff hits; any
    # still-running searches keep going in the background and their results
    # are simply discarded when they eventually land, since nothing reads
    # `futures` after this point.
    # Soft cutoff kept well under 20s (not the 20s this used to be) —
    # confirmed live as a real bug: this whole function is itself called
    # from afdb_router.py's unified adult search box, wrapped in an OUTER
    # 20s cutoff around the ENTIRE search_by_title() call (both this phase
    # AND the scraper_sources supplementary phase below). A cold-cache
    # query (e.g. a performer never searched before) reliably took the
    # full 20s here alone, leaving zero margin for the second phase and
    # guaranteeing the outer collector abandoned the whole result — even
    # though the underlying scrape/match logic was completely correct the
    # whole time (confirmed live: calling this function directly with no
    # surrounding time pressure returns real, correct results in 10-20s).
    #
    # Deliberately NOT raised further (2026-08-24) despite this only
    # returning 15 of a possible 430 streams when run for real, alongside
    # the other 5 top-level Adult-search phases (actor/AFDB-title/ADE-
    # title/torrent/myporn) inside afdb_router.py's own shared pool — all
    # 6 of those phases genuinely compete for the same machine's CPU/
    # network at once, so every individual site responds real-world
    # slower under that combined load than this function's own isolated
    # timing ever showed. Tried raising both this and the outer caller's
    # timeout to compensate (up to 35s outer / 30s here) - confirmed live
    # this DOES recover far more results (225 streams, 42 titles) but
    # pushes total wait past 45s, which risks looking exactly like the
    # "search initiates, nothing ever shows" complaint this was meant to
    # fix, just from Kodi's own plugin-call patience running out instead
    # of a code crash. Reverted back to the original tighter budget - a
    # smaller, fast, reliable first page plus genuinely working Next Page
    # pagination (confirmed live: a second page surfaces dozens more
    # distinct titles neither request showed) is the right tradeoff over
    # one large, slow, contention-prone request.
    pool = ThreadPoolExecutor(max_workers=min(len(search_fns), 16))
    futures = {pool.submit(fn, title, page): fn.__name__ for fn in search_fns}
    try:
        for future in as_completed(futures, timeout=12):
            name = futures[future]
            try:
                films = future.result() or []
                for film in films:
                    if not film:
                        continue
                    # No title-text re-check here — every search_fns entry
                    # is already a result from that SITE's OWN /?s= search
                    # endpoint (or, for the Scenes registry sites below, an
                    # equivalent per-site search()), which matches on
                    # cast/performer name and genre tags, not just title
                    # text (confirmed live: a performer-name query
                    # correctly surfaces films she's credited in even when
                    # her name never appears in the title). Re-filtering by
                    # title text here used to throw away almost every one
                    # of those genuinely relevant hits, keeping only the
                    # rare exact-title match — see this function's own
                    # per-site pre-filters (now removed for the same
                    # reason, WPF/SPN) for the other half of this fix.
                    film_title = film.get('title', '')
                    for s in film.get('streams', []):
                        if s.get('url') and s['url'] not in seen_urls:
                            seen_urls.add(s['url'])
                            # Confirmed live 2026-08-15: at least 9 sites
                            # (PornHub, the Aylo family YouPorn/Tube8/
                            # Thumbzilla, Xerotica, NoodleMagazine,
                            # LetMeJizz, Beeg, 6xtube) attach their own
                            # 'referer' to each stream dict because their
                            # CDN 403s without it - this merge step was
                            # silently dropping that field, so search
                            # correctly FOUND a real, working stream URL
                            # for these sites but playback still failed
                            # (reported: "pornhub still doesn't work",
                            # even though a direct test of the same
                            # search+detail chain returned a valid MP4
                            # URL every time). Carried through via this
                            # codebase's existing url|Referer=... pipe
                            # convention (same as DaddyLive/FalconStreams/
                            # SportSurge) instead of a plain URL.
                            url = s['url']
                            referer = s.get('referer')
                            if referer:
                                from urllib.parse import quote as _uq
                                url = '%s|Referer=%s' % (url, _uq(referer, safe=''))
                            host_label = s.get('label', name)
                            label = '%s - %s' % (film_title, host_label) if film_title else host_label
                            streams.append({'label': label, 'url': url})
                    xbmc.log('[Starfleet/Streams] matched "%s" in %s' % (film_title, name), xbmc.LOGINFO)
            except Exception as e:
                xbmc.log('[Starfleet/Streams] search error (%s): %s' % (name, e), xbmc.LOGWARNING)
    except Exception as e:
        xbmc.log('[Starfleet/Streams] search_by_title timeout: %s' % e, xbmc.LOGWARNING)
    finally:
        pool.shutdown(wait=False)

    # Also search scraper_sources (movies/TV streaming sites) as supplementary
    # adult sources — bounded independently to a short 6s budget rather than
    # trusting search_all_scrapers()'s own internal ~35s soft cutoff directly.
    # Confirmed live as the other half of the timing bug fixed above: this
    # phase used to run synchronously and unbounded from this function's own
    # perspective, so it alone could push total real duration to 30-50+s,
    # every bit of which still counted against the outer 20s deadline
    # search_by_title() is called under. A dedicated short-lived pool +
    # future.result(timeout=...) here means this phase either contributes
    # whatever it finds within its own small budget or is cleanly abandoned
    # (same "soft cutoff, discard stragglers" pattern the phase above uses),
    # instead of blocking this function's return on it indefinitely.
    try:
        from resources.lib.scraper_sources import search_all_scrapers as _sc_search
        sc_pool = ThreadPoolExecutor(max_workers=1)
        try:
            sc_streams = sc_pool.submit(_sc_search, title, 'adult').result(timeout=6)
        except Exception:
            sc_streams = []
        finally:
            sc_pool.shutdown(wait=False)
        for s in sc_streams:
            if s.get('url') and s['url'] not in seen_urls:
                seen_urls.add(s['url'])
                streams.append({'label': s.get('label', s.get('source', 'Scrapers')), 'url': s['url']})
    except Exception as e:
        xbmc.log('[Starfleet/Streams] scraper_sources adult search error: %s' % e, xbmc.LOGWARNING)

    xbmc.log('[Starfleet/Streams] search_by_title "%s" → %d streams' % (title, len(streams)), xbmc.LOGINFO)
    return streams


# ── Source availability index (for AFDB listing filter) ──────────────────────

_title_index = None   # set of normalised titles known to have sources (None = not built yet)


def prewarm_title_index():
    """
    Build (or return cached) a set of normalised titles known to have at least
    one cached stream source. Uses only already-cached data — no HTTP requests.
    Cached in module memory between calls (reuselanguageinvoker keeps it warm).
    """
    global _title_index
    if _title_index is not None:
        return

    from resources.lib import cache as _c
    index = set()

    # Walk cache keys for all 5 scrapers' film lists (pages 1-5 to be thorough)
    _PREFIXES = [
        ('fstreams_freeo_list_%d',   'fstreams_freeo_detail_%s',   'freeo_'),
        ('fstreams_xxxms_list_%d',   'fstreams_xxxms_detail_%s',   'xxxms_'),
        ('fstreams_wpw_list_%d',     'fstreams_wpw_detail_%s',     'wpw_'),
        ('fstreams_wpf_list_%d',     'fstreams_wpf_detail_%s',     'wpf_'),
        ('fstreams_spn_list_%d',     'fstreams_spn_detail_%s',     'spn_'),
        ('fstreams_xxxsc_list_%d',   'fstreams_xxxsc_detail_%s',   'xxxsc_'),
        ('fstreams_xmovix_list_%d',  'fstreams_xmovix_detail_%s',  'xmovix_'),
        ('panda_genre_%s_1',         'panda_detail_%s',            'panda_'),
        ('hqporner_cat_%s_1',        'hqporner_detail_%s',         'hqp_'),
    ]

    for list_tpl, detail_tpl, prefix in _PREFIXES:
        for pg in range(1, 6):
            film_list = _c.get(list_tpl % pg)
            if not film_list:
                continue
            for item in film_list:
                # film_list items are {'slug': ..., 'url': ...} dicts
                slug = item.get('slug', '') if isinstance(item, dict) else str(item)
                if not slug:
                    continue
                detail = _c.get(detail_tpl % slug)
                if detail and detail.get('streams'):
                    t = detail.get('title', '')
                    if t:
                        index.add(_norm_title(t))

    # Also check the merged cache from get_all_streams
    for pg in range(1, 6):
        merged = _c.get('fstreams_merged_list_%d' % pg)
        if not merged:
            continue
        if isinstance(merged, list):
            for film in merged:
                if film.get('streams') and film.get('title'):
                    index.add(_norm_title(film['title']))

    _title_index = index


def _no_source_cache_key(norm_title):
    return 'no_source_confirmed_%s' % norm_title


def mark_no_source_confirmed(title):
    """Record that a real search_by_title() call was made for this title and
    came back with nothing — an actual, deliberate negative result, not just
    "not yet looked at". Called from the background prewarm in
    _filter_films_with_sources after a real (if empty) search."""
    from resources.lib import cache as _c
    _c.set(_no_source_cache_key(_norm_title(title)), True, 24 * 3600)


def has_cached_source(title):
    """
    Check if a title has a known stream source.
    Returns True if confirmed present (in the passive detail-page index),
    False ONLY if a real search_by_title() call was actually made for this
    exact title and came back empty (see mark_no_source_confirmed) — NOT
    just because it's absent from the passive index, which only reflects
    whatever detail pages happen to already be cached from past browsing
    and is never an exhaustive check. Treating "not yet looked at" the same
    as "confirmed absent" was confirmed live to make listings collapse to
    almost nothing after a few hours of real use, once that passive index
    stopped being empty but was still far from complete.
    Returns None (show it, unchecked) in every other case.
    """
    global _title_index
    norm = _norm_title(title)

    from resources.lib import cache as _c
    if _c.get(_no_source_cache_key(norm)):
        return False

    if _title_index and norm in _title_index:
        return True

    return None
