'''#####-----Build File-----#####'''
buildfile = 'https://thechains24.com/BUILDS/19%20builds/19%20Chains%20Builds%20Matrix.xml'

'''#####-----Videos File-----#####'''
videos_url = 'http://'

'''#####-----Notification File-----#####'''
notify_url  = 'https://thechains24.com/notify.txt'

'''#####-----Changelog Directory-----#####'''
changelog_dir  = 'https://thechains24.com/changelog.txt'

'''#####-----Excludes-----#####'''
excludes  = ['']
