from json import dumps
import logging
import requests
from requests.auth import HTTPBasicAuth
from urllib.parse import quote


class TorrServer(object):
    def __init__(self, host, port, username, password, ssl_enabled=False, session=None):
        self._base_url = "{}://{}:{}".format(
            "https" if ssl_enabled else "http", host, port
        )
        self._username = username
        self._password = password
        self._auth = HTTPBasicAuth(self._username, self._password)
        self._session = session or requests

    @property
    def torr_version(self):
        """tests server status"""
        return self._get("/echo").content

    def add_magnet(self, magnet, title="", poster="", data="", category=None):
        payload = {
            "action": "add",
            "link": magnet,
            "title": title,
            "poster": poster,
            "save_to_db": True,
        }
        if category is not None:
            payload["category"] = category
        return self._parse_json_response(
            self._post(
                "/torrents",
                data=dumps(payload),
            ),
            "/torrents",
        )["hash"]

    def add_torrent(self, path, title="", poster="", data=""):
        with open(path, "rb") as file:
            return self._parse_json_response(
                self._post(
                    "/torrent/upload",
                    files={"file": file},
                    data={
                        "save": "true",
                        "title": title,
                        "poster": poster,
                    },
                ),
                "/torrent/upload",
            )["hash"]

    def add_torrent_obj(self, obj, title="", poster="", data="", category=None):
        payload = {
            "save": "true",
            "title": title,
            "poster": poster,
        }
        if category is not None:
            payload["category"] = category
        return self._parse_json_response(
            self._post(
                "/torrent/upload",
                files={"file": obj},
                data=payload,
            ),
            "/torrent/upload",
        )["hash"]

    def torrents(self):
        """read info about all torrents (doesn't fill file_stats info)

        Returns the raw list from TorrServer. Unlike single-object endpoints,
        /torrents list returns a proper JSON array — pass it through as-is.
        """
        response = self._post("/torrents", data=dumps({"action": "list"}))
        if response.status_code != 200:
            raise TorrServerError(
                "TorrServer /torrents returned HTTP {}".format(response.status_code),
                status_code=response.status_code,
            )
        return response.json()

    def search(self, query):
        """search torrents via Rutor (GET /search/?query=...).

        Requires EnableRutorSearch=true in TorrServer settings. Returns the
        raw JSON list from TorrServer. Empty list when search is disabled or
        no results — do NOT use _parse_json_response (it raises on empty list).

        TorrServer returns HTTP 400 with body [] when Rutor search is
        disabled; treat that as an empty result rather than an error so the
        caller can show the localized 'enable Rutor' hint instead of a raw
        HTTP 400 message.
        """
        logging.info("TorrServer search: query=%r base_url=%s", query, self._base_url)
        response = self._get("/search/", params={"query": query})
        logging.info(
            "TorrServer search: HTTP %d, body[:200]=%r",
            response.status_code,
            getattr(response, "text", "")[:200],
        )
        if response.status_code not in (200, 400):
            raise TorrServerError(
                "TorrServer /search returned HTTP {}".format(response.status_code),
                status_code=response.status_code,
            )
        try:
            result = response.json()
        except ValueError:
            raise TorrServerError(
                "TorrServer /search returned invalid JSON",
                status_code=response.status_code,
            )
        logging.info(
            "TorrServer search: parsed %d results",
            len(result) if isinstance(result, list) else -1,
        )
        return result

    def get_torrent_info_by_hash(self, hash):
        """not extended info"""
        return self._parse_json_response(
            self._post("/torrents", data=dumps({"action": "get", "hash": hash})),
            "/torrents",
        )

    def set_torrent(self, hash, title=None, poster=None, category=None, data=None):
        """update torrent metadata (title/poster/category) via the 'set' action"""
        payload = {"action": "set", "hash": hash}
        if title is not None:
            payload["title"] = title
        if poster is not None:
            payload["poster"] = poster
        if category is not None:
            payload["category"] = category
        return self._parse_json_response(
            self._post("/torrents", data=dumps(payload)),
            "/torrents",
        )

    def get_torrent_info(self, link):
        """read extended info of one torrent"""
        return self._parse_json_response(
            self._get("/stream", params={"link": link, "stat": "true"}),
            "/stream",
        )

    def get_torrent_file_info(self, link, file_index=1):
        """read extended info of file of torrent"""
        return self._parse_json_response(
            self._get(
                "/stream",
                params={"link": link, "index": file_index, "stat": "true"},
            ),
            "/stream",
        )

    def drop_torrent(self, hash):
        return self._post("/torrents", data=dumps({"action": "drop", "hash": hash}))

    def remove_torrent(self, info_hash, save_to_db=True):
        """delete torrent from TorrServer"""
        return self._post(
            "/torrents",
            data=dumps({"action": "rem", "hash": info_hash, "save_to_db": save_to_db}),
        )

    def download_file(self, hash, file_id):
        """stream a specific file's content from a torrent (GET /play/{hash}/{id})"""
        return self._get("/play/{}/{}".format(hash, file_id), stream=True)

    def play_torrent(self, hash, id):
        """Play given torrent referenced by hash"""
        """ application/octet-stream """
        return self._get("/play", params={"hash": hash, "id": id})

    def play_stream(self, link, title="", poster=""):
        """Play given torrent referenced by link"""
        """ application/octet-stream """
        return self._get(
            "/stream",
            params={"link": link, "title": title, "poster": poster, "play": "true"},
        )

    def preload_torrent(self, link, file_id=1, title=""):
        """preload torrent"""
        return self._get(
            "/stream",
            params={
                "link": link,
                "index": file_id,
                "title": title,
                "stat": "true",
                "preload": "true",
            },
        )

    def get_stream_url(self, link, path, file_id):
        """returns the stream url"""
        return f"{self._base_url}/stream/{quote(path)}?link={link}&index={file_id}&play"

    def get_settings(self):
        res = self._post("/settings", data=dumps({"action": "get"}))
        return self._parse_json_response(res, "/settings")

    def _parse_json_response(self, response, endpoint):
        status_code = getattr(response, "status_code", None)
        text = getattr(response, "text", "") or ""
        snippet = text[:200].strip().replace("\n", " ")

        if status_code != 200:
            raise TorrServerError(
                "TorrServer {} returned HTTP {}{}".format(
                    endpoint,
                    status_code,
                    ": {}".format(snippet) if snippet else "",
                ),
                status_code=status_code,
            )

        try:
            result = response.json()
        except ValueError:
            raise TorrServerError(
                "TorrServer {} returned invalid JSON{}".format(
                    endpoint,
                    ": {}".format(snippet) if snippet else "",
                ),
                status_code=status_code,
            )

        # Some TorrServer versions return a list instead of a dict.
        # Normalize by taking the first element so callers can always
        # access keys like ["hash"] without type errors.
        if isinstance(result, list):
            if not result:
                raise TorrServerError(
                    "TorrServer {} returned empty list".format(endpoint),
                    status_code=status_code,
                )
            result = result[0]

        return result

    def _post(self, url, **kwargs):
        return self._request("post", url, **kwargs)

    def _put(self, url, **kwargs):
        return self._request("put", url, **kwargs)

    def _get(self, url, **kwargs):
        return self._request("get", url, **kwargs)

    def _delete(self, url, **kwargs):
        return self._request("delete", url, **kwargs)

    def _request(self, method, url, **kwargs):
        try:
            return self._session.request(
                method, self._base_url + url, auth=self._auth, **kwargs
            )
        except Exception as e:
            raise TorrServerError(str(e))


class TorrServerError(Exception):
    def __init__(self, message, status_code=None):
        super(TorrServerError, self).__init__(message)
        self.status_code = status_code
