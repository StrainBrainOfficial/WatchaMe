"""Tests for Jacktorr TorrServer API client.

Regression tests for issue #193: TorrServer may return a JSON list
instead of a dict, causing TypeError when accessing ["hash"].
"""

import json
from unittest.mock import MagicMock, patch, mock_open

import pytest

from lib.torrserver.api import TorrServer, TorrServerError


def _make_response(json_data, status_code=200, text=None):
    """Create a mock requests.Response with the given json data and status code."""
    response = MagicMock()
    response.json.return_value = json_data
    response.status_code = status_code
    response.text = text or json.dumps(json_data)
    return response


@pytest.fixture
def torrserver():
    """Create a TorrServer instance with a mock session."""
    session = MagicMock()
    return TorrServer(
        host="localhost",
        port=8090,
        username="admin",
        password="pass",
        ssl_enabled=False,
        session=session,
    )


class TestParseJsonResponse:
    """Tests for TorrServer._parse_json_response."""

    def test_dict_response_passthrough(self, torrserver):
        """Dict responses pass through unchanged."""
        response = _make_response({"hash": "abc123", "stat": 3})
        result = torrserver._parse_json_response(response, "/torrent/upload")
        assert result == {"hash": "abc123", "stat": 3}

    def test_list_with_one_element_unwrapped(self, torrserver):
        """A single-element list is unwrapped to its first element."""
        response = _make_response([{"hash": "abc123", "stat": 3}])
        result = torrserver._parse_json_response(response, "/torrent/upload")
        assert result == {"hash": "abc123", "stat": 3}

    def test_list_with_multiple_elements_takes_first(self, torrserver):
        """A multi-element list takes only the first element."""
        response = _make_response([{"hash": "first"}, {"hash": "second"}])
        result = torrserver._parse_json_response(response, "/torrent/upload")
        assert result == {"hash": "first"}

    def test_empty_list_raises_error(self, torrserver):
        """An empty list raises TorrServerError."""
        response = _make_response([])
        with pytest.raises(TorrServerError, match="empty list"):
            torrserver._parse_json_response(response, "/torrent/upload")

    def test_non_200_status_raises_error(self, torrserver):
        """HTTP 500 raises TorrServerError with endpoint info."""
        response = _make_response({"error": "internal"}, status_code=500)
        with pytest.raises(TorrServerError, match="/torrent/upload.*HTTP 500") as exc:
            torrserver._parse_json_response(response, "/torrent/upload")
        assert exc.value.status_code == 500

    def test_invalid_json_raises_error(self, torrserver):
        """Invalid JSON raises TorrServerError."""
        response = MagicMock()
        response.status_code = 200
        response.text = "not json"
        response.json.side_effect = ValueError("invalid json")
        with pytest.raises(TorrServerError, match="invalid JSON") as exc:
            torrserver._parse_json_response(response, "/torrent/upload")
        assert exc.value.status_code == 200


class TestTorrServerError:
    def test_legacy_constructor_defaults_status_code_to_none(self):
        error = TorrServerError("legacy")
        assert str(error) == "legacy"
        assert error.status_code is None

    def test_constructor_keeps_explicit_status_code(self):
        error = TorrServerError("unavailable", status_code=503)
        assert str(error) == "unavailable"
        assert error.status_code == 503


class TestAddMagnet:
    """Tests for TorrServer.add_magnet with normalized responses."""

    def test_add_magnet_dict_response(self, torrserver):
        """add_magnet handles standard dict response."""
        torrserver._session.request.return_value = _make_response(
            {"hash": "magnet_hash_1"}
        )
        result = torrserver.add_magnet(
            "magnet:?xt=urn:btih:abc123", title="Test", category="tv"
        )
        assert result == "magnet_hash_1"
        sent_data = json.loads(torrserver._session.request.call_args.kwargs["data"])
        assert sent_data["category"] == "tv"

    def test_add_magnet_list_response(self, torrserver):
        """add_magnet handles list response from TorrServer (issue #193)."""
        torrserver._session.request.return_value = _make_response(
            [{"hash": "magnet_hash_1"}]
        )
        result = torrserver.add_magnet("magnet:?xt=urn:btih:abc123", title="Test")
        assert result == "magnet_hash_1"
        sent_data = json.loads(torrserver._session.request.call_args.kwargs["data"])
        assert "category" not in sent_data

    def test_data_argument_is_accepted_but_not_sent_to_torrserver(self, torrserver):
        torrserver._session.request.return_value = _make_response({"hash": "magnet_hash_1"})

        torrserver.add_magnet("magnet:?xt=urn:btih:abc123", data="legacy")

        sent_data = json.loads(torrserver._session.request.call_args.kwargs["data"])
        assert "data" not in sent_data


class TestAddTorrentObj:
    """Tests for TorrServer.add_torrent_obj with normalized responses."""

    def test_add_torrent_obj_dict_response(self, torrserver):
        """add_torrent_obj handles standard dict response."""
        torrserver._session.request.return_value = _make_response(
            {"hash": "torrent_hash_1"}
        )
        mock_file = MagicMock()
        result = torrserver.add_torrent_obj(mock_file, category="movie")
        assert result == "torrent_hash_1"
        assert torrserver._session.request.call_args.kwargs["data"]["category"] == "movie"

    def test_add_torrent_obj_list_response(self, torrserver):
        """add_torrent_obj handles list response (issue #193)."""
        torrserver._session.request.return_value = _make_response(
            [{"hash": "torrent_hash_1"}]
        )
        mock_file = MagicMock()
        result = torrserver.add_torrent_obj(mock_file)
        assert result == "torrent_hash_1"
        assert "category" not in torrserver._session.request.call_args.kwargs["data"]

    def test_add_torrent_obj_empty_list_raises_error(self, torrserver):
        """add_torrent_obj raises error on empty list."""
        torrserver._session.request.return_value = _make_response([])
        mock_file = MagicMock()
        with pytest.raises(TorrServerError):
            torrserver.add_torrent_obj(mock_file)


class TestAddTorrent:
    """Tests for TorrServer.add_torrent with normalized responses."""

    def test_add_torrent_dict_response(self, torrserver, tmp_path):
        """add_torrent handles standard dict response."""
        torrserver._session.request.return_value = _make_response(
            {"hash": "file_hash_1"}
        )
        torrent_file = tmp_path / "test.torrent"
        torrent_file.write_bytes(b"d8:announce17:http://test.com4:info6:teste")
        result = torrserver.add_torrent(str(torrent_file))
        assert result == "file_hash_1"

    def test_add_torrent_list_response(self, torrserver, tmp_path):
        """add_torrent handles list response (issue #193)."""
        torrserver._session.request.return_value = _make_response(
            [{"hash": "file_hash_1"}]
        )
        torrent_file = tmp_path / "test.torrent"
        torrent_file.write_bytes(b"d8:announce17:http://test.com4:info6:teste")
        result = torrserver.add_torrent(str(torrent_file))
        assert result == "file_hash_1"


class TestGetTorrentInfo:
    """Tests for TorrServer info methods with normalized responses."""

    def test_get_torrent_info_dict(self, torrserver):
        """get_torrent_info handles dict response."""
        expected = {"hash": "abc123", "stat": 3, "file_stats": []}
        torrserver._session.request.return_value = _make_response(expected)
        result = torrserver.get_torrent_info("abc123")
        assert result == expected

    def test_get_torrent_info_list(self, torrserver):
        """get_torrent_info handles list response (defensive)."""
        expected_inner = {"hash": "abc123", "stat": 3, "file_stats": []}
        torrserver._session.request.return_value = _make_response([expected_inner])
        result = torrserver.get_torrent_info("abc123")
        assert result == expected_inner

    def test_torrents_dict(self, torrserver):
        """torrents() handles dict response."""
        expected = {"torrents": []}
        torrserver._session.request.return_value = _make_response(expected)
        result = torrserver.torrents()
        assert result == expected

    def test_torrents_list(self, torrserver):
        """torrents() returns raw list from the list endpoint."""
        expected = [{"hash": "abc123"}]
        torrserver._session.request.return_value = _make_response(expected)
        result = torrserver.torrents()
        assert result == expected

    def test_torrents_empty_list(self, torrserver):
        """torrents() handles empty list gracefully (no TorrServerError)."""
        torrserver._session.request.return_value = _make_response([])
        result = torrserver.torrents()
        assert result == []

    def test_get_torrent_info_by_hash_dict(self, torrserver):
        """get_torrent_info_by_hash handles dict response."""
        expected = {"hash": "abc123", "stat": 3}
        torrserver._session.request.return_value = _make_response(expected)
        result = torrserver.get_torrent_info_by_hash("abc123")
        assert result == expected

    def test_get_torrent_info_by_hash_list(self, torrserver):
        """get_torrent_info_by_hash handles list response (defensive)."""
        expected_inner = {"hash": "abc123", "stat": 3}
        torrserver._session.request.return_value = _make_response([expected_inner])
        result = torrserver.get_torrent_info_by_hash("abc123")
        assert result == expected_inner


class TestSetTorrent:
    """Tests for TorrServer.set_torrent (issue #7 Part B1)."""

    def test_set_poster_sends_set_action_with_poster(self, torrserver):
        torrserver._session.request.return_value = _make_response(
            {"hash": "abc", "poster": "http://example.com/p.jpg"}
        )
        result = torrserver.set_torrent("abc", poster="http://example.com/p.jpg")
        assert result == {"hash": "abc", "poster": "http://example.com/p.jpg"}
        sent_data = json.loads(torrserver._session.request.call_args.kwargs["data"])
        assert sent_data["action"] == "set"
        assert sent_data["hash"] == "abc"
        assert sent_data["poster"] == "http://example.com/p.jpg"

    def test_set_torrent_omits_none_fields(self, torrserver):
        torrserver._session.request.return_value = _make_response({"hash": "abc"})
        torrserver.set_torrent("abc", poster="http://example.com/p.jpg")
        sent_data = json.loads(torrserver._session.request.call_args.kwargs["data"])
        assert "title" not in sent_data
        assert "category" not in sent_data
        assert "data" not in sent_data

    def test_set_torrent_list_response(self, torrserver):
        torrserver._session.request.return_value = _make_response(
            [{"hash": "abc", "poster": "http://example.com/p.jpg"}]
        )
        result = torrserver.set_torrent("abc", poster="http://example.com/p.jpg")
        assert result == {"hash": "abc", "poster": "http://example.com/p.jpg"}


class TestSetTorrentCategory:
    """Tests for TorrServer.set_torrent category kwarg (Phase 5)."""

    def test_set_category_sends_set_action_with_category(self, torrserver):
        torrserver._session.request.return_value = _make_response({"ok": True})
        torrserver.set_torrent("abc", category="movies")
        call = torrserver._session.request.call_args
        assert call.args[0] == "post"
        sent_data = json.loads(call.kwargs["data"])
        assert sent_data["action"] == "set"
        assert sent_data["hash"] == "abc"
        assert sent_data["category"] == "movies"
        assert "poster" not in sent_data
        assert "title" not in sent_data


class TestAddMagnetPoster:
    """Regression: add_magnet forwards poster to TorrServer (issue #7 Part B1)."""

    def test_add_magnet_includes_poster_in_payload(self, torrserver):
        torrserver._session.request.return_value = _make_response({"hash": "h1"})
        torrserver.add_magnet(
            "magnet:?xt=urn:btih:abc123", poster="http://example.com/p.jpg"
        )
        sent_data = json.loads(torrserver._session.request.call_args.kwargs["data"])
        assert sent_data["action"] == "add"
        assert sent_data["poster"] == "http://example.com/p.jpg"


class TestDownloadFile:
    """Tests for TorrServer.download_file (GET /play/{hash}/{id})."""

    def test_download_file_uses_play_path_endpoint(self, torrserver):
        """download_file issues a GET to /play/{hash}/{id} with stream=True."""
        torrserver._session.request.return_value = _make_response({"ok": True})
        torrserver.download_file("abc", 2)
        call = torrserver._session.request.call_args
        assert call.args[0] == "get"
        assert call.args[1] == "http://localhost:8090/play/abc/2"
        assert call.kwargs["stream"] is True


class TestDropTorrent:
    """Regression guard for drop_torrent arity (1-arg, hash-only contract)."""

    def test_drop_torrent_sends_drop_action_with_hash(self, torrserver):
        """drop_torrent POSTs to /torrents with body {action: drop, hash: ...}."""
        torrserver._session.request.return_value = _make_response({"ok": True})
        torrserver.drop_torrent("abc")
        call = torrserver._session.request.call_args
        assert call.args[0] == "post"
        assert call.args[1] == "http://localhost:8090/torrents"
        sent_data = json.loads(call.kwargs["data"])
        assert sent_data == {"action": "drop", "hash": "abc"}


class TestSearch:
    """Tests for TorrServer.search (GET /search/?query=...)."""

    def test_search_returns_raw_list(self, torrserver):
        """search issues a GET to /search/ with the query param and returns the raw list."""
        torrserver._session.request.return_value = _make_response(
            [{"Title": "X", "Magnet": "magnet:..."}]
        )
        result = torrserver.search("matrix")
        assert isinstance(result, list)
        assert result[0]["Title"] == "X"
        call = torrserver._session.request.call_args
        assert call.args[0] == "get"
        assert "/search/" in call.args[1]
        assert call.kwargs["params"] == {"query": "matrix"}

    def test_search_empty_list_when_no_results(self, torrserver):
        """search returns [] — must NOT raise (unlike _parse_json_response)."""
        torrserver._session.request.return_value = _make_response([])
        result = torrserver.search("nothing")
        assert result == []

    def test_search_400_disabled_returns_empty_list(self, torrserver):
        """TorrServer returns HTTP 400 + [] when Rutor search is disabled —
        treat as an empty result so the caller can show the localized hint
        instead of a raw 'HTTP 400' error."""
        torrserver._session.request.return_value = _make_response([], status_code=400)
        result = torrserver.search("x")
        assert result == []

    def test_search_raises_on_http_error(self, torrserver):
        """Non-200/400 status raises TorrServerError."""
        torrserver._session.request.return_value = _make_response({}, status_code=500)
        with pytest.raises(TorrServerError) as exc:
            torrserver.search("x")
        assert exc.value.status_code == 500
