"""SPELUNKR.tv integration — channel lineup + live schedule.

spelunkr.tv has no server EPG: "what's playing now" is computed client-side
by their JS engine (epochMs + per-item durations + seeded bump/ad breaks).
This module is a straight Python port of that engine (Pr/Ln/ya/tu/Gm/og/wa/
_a/vg/Zt/Ji) so Kodi can show the same now-playing titles and join a channel
at the correct file offset.

Data (all public JSON):
  broadcast/lineup.json                    — channels + version pointers
  broadcast/manifests/<id>/v<N>.json       — items, channel bumps, ads, block
  broadcast/platform/<hash>.json           — platform bump slides
  broadcast/details/<id>/v<N>.json         — per-item descriptions

Streams are plain archive.org MP4s: https://archive.org/download/<id>/<file>

Stdlib-only on purpose (no xbmc import) so it runs outside Kodi for testing.
"""

import datetime
import json
import math
import os
import threading
import time
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor

_USER_AGENT = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
    '(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
)
_BASES = (
    'https://spelunkr.tv/broadcast/',
    'https://jbuopkuluyfjwgsrigry.supabase.co/storage/v1/object/public/broadcast/',
)
IA_DOWNLOAD = 'https://archive.org/download/'
IA_METADATA = 'https://archive.org/metadata/'
LINEUP_PATH = 'lineup.json'
LINEUP_TTL_S = 900          # lineup (version pointers) refreshes daily upstream
_HTTP_TIMEOUT_S = 15

# --- engine constants (from spelunkr bundle) --------------------------------
_JM, _BM, _HM = 2500, 1500, 55          # ya(text) slide timing
_UC, _PS, _AI, _H = 3500, 1000, 1000, 300   # Km() bump-break timing
_YM = (3, 6)                            # ad decade tolerances
_DC = 20 * 60 * 1000                    # default ad gapMs
_RU = 336 * 3600 * 1000                 # ad round length (healthy)
_NT = 1000000
_GS = 20000
_NH = 24 * 3600 * 1000                  # ad recent window
_XM = 3600 * 1000
_HG = 5                                 # engine >= 5 uses the bump deck
_MAX_CYCLES = 64                        # safety cap when walking fwd cycles

_cache_dir = None
_mem = {}                               # path -> (ts, text)
_mem_lock = threading.Lock()
_state_lock = threading.Lock()
_states = {}                            # channel_id -> version state


def set_cache_dir(path):
    """Point the module at a writable directory (addon profile). Optional."""
    global _cache_dir
    _cache_dir = path
    try:
        if path and not os.path.isdir(path):
            os.makedirs(path)
    except Exception:
        _cache_dir = None


# --- fetch + cache -----------------------------------------------------------

def _disk_path(path):
    if not _cache_dir:
        return None
    safe = path.replace('/', '_').replace('\\', '_').replace(':', '_')
    return os.path.join(_cache_dir, safe)


def _http_get(url):
    req = urllib.request.Request(url, headers={'User-Agent': _USER_AGENT})
    with urllib.request.urlopen(req, timeout=_HTTP_TIMEOUT_S) as resp:
        return resp.read().decode('utf-8', 'replace')


def fetch_text(path, ttl_s=None):
    """Fetch a broadcast/ file: memory cache, then disk, then network."""
    with _mem_lock:
        hit = _mem.get(path)
    if hit is not None and (ttl_s is None or time.time() - hit[0] < ttl_s):
        return hit[1]
    dp = _disk_path(path)
    if dp and os.path.isfile(dp):
        try:
            age = time.time() - os.path.getmtime(dp)
            if ttl_s is None or age < ttl_s:
                with open(dp, 'r', encoding='utf-8') as f:
                    text = f.read()
                with _mem_lock:
                    _mem[path] = (time.time() - age, text)
                return text
        except Exception:
            pass
    last_err = None
    for base in _BASES:
        try:
            text = _http_get(base + urllib.parse.quote(path, safe='/'))
            break
        except Exception as e:
            last_err = e
            text = None
    if text is None:
        # stale disk copy beats nothing (channels keep working offline)
        if dp and os.path.isfile(dp):
            try:
                with open(dp, 'r', encoding='utf-8') as f:
                    return f.read()
            except Exception:
                pass
        raise RuntimeError(f'spelunkr fetch failed for {path}: {last_err}')
    with _mem_lock:
        _mem[path] = (time.time(), text)
    if dp:
        try:
            with open(dp, 'w', encoding='utf-8') as f:
                f.write(text)
        except Exception:
            pass
    return text


def _fetch_json(path, ttl_s=None):
    return json.loads(fetch_text(path, ttl_s=ttl_s))


# --- 32-bit helpers (JS semantics) -------------------------------------------

def _i32(x):
    x &= 0xFFFFFFFF
    return x - 0x100000000 if x >= 0x80000000 else x


def _u32(x):
    return x & 0xFFFFFFFF


def _imul(a, b):
    return _i32(a * b)


def _utf16_units(s):
    b = s.encode('utf-16-le')
    return [b[i] | (b[i + 1] << 8) for i in range(0, len(b), 2)]


def _ln(s):
    """JS Ln(): string hash over UTF-16 code units."""
    t = 0
    for cu in _utf16_units(s):
        t = _i32((t << 5) - t + cu)
    return t


def _pr(seed):
    """JS Pr(): deterministic PRNG (state carried per closure)."""
    t = _i32(seed)

    def rnd():
        nonlocal t
        t = _i32(t + 1831565813)
        n = _imul(t ^ (_u32(t) >> 15), _i32(1 | t))
        n = _i32(n ^ _i32(n + _imul(n ^ (_u32(n) >> 7), _i32(61 | n))))
        return _u32(n ^ (_u32(n) >> 14)) / 4294967296.0

    return rnd


def _is_int(x):
    return isinstance(x, int) and not isinstance(x, bool)


# --- slide / bump timing -----------------------------------------------------

def _ya(text):
    return max(_JM, _BM + len(_utf16_units(text)) * _HM)


def _ri(slides):
    return sum(_ya(s.get('text') or '') for s in (slides or []))


def _km(ch_bump, plat_bump):
    return _UC + _ri(ch_bump.get('slides')) + _PS + _AI + _H + \
        _ri(plat_bump.get('slides')) + _PS + _AI


# --- seasonal bump filtering (Ph/ba/xh) -------------------------------------

def _js_date_ms(s):
    """Date.parse of 'YYYY-MM-DDTHH:MM:SS[.mmm]Z' -> epoch ms."""
    ms = 0
    if '.' in s:
        base, frac = s.split('.', 1)
        frac = frac.rstrip('Z') or '0'
        ms = int((frac + '000')[:3])
    else:
        base = s.rstrip('Z')
    dt = datetime.datetime.strptime(base, '%Y-%m-%dT%H:%M:%S')
    return int(dt.replace(tzinfo=datetime.timezone.utc).timestamp() * 1000) + ms


def _in_date_range(rng, t_ms):
    a, b = rng
    if a[:2].isdigit() and a[2:4] == '-':  # /^\d{4}-/
        return (_js_date_ms(a + 'T00:00:00Z') <= t_ms <=
                _js_date_ms(b + 'T23:59:59.999Z'))
    def md(s):
        m, d = s.split('-')
        return int(m) * 100 + int(d)
    dt = datetime.datetime.fromtimestamp(t_ms / 1000, datetime.timezone.utc)
    cur = (dt.month) * 100 + dt.day
    ca, cb = md(a), md(b)
    return (ca <= cur <= cb) if ca <= cb else (cur >= ca or cur <= cb)


def _ph(bumps):
    live = [b for b in bumps if b.get('active') is not False]
    year_round = [b for b in live if not b.get('date_range')]
    seasonal = [b for b in live if b.get('date_range')]
    return live, year_round, seasonal


def _eligible(bumps, t_ms):
    live, year_round, seasonal = _ph(bumps)
    if any(_in_date_range(b['date_range'], t_ms) for b in seasonal):
        return [b for b in live if not b.get('date_range')
                or _in_date_range(b['date_range'], t_ms)]
    return year_round


def _tu(bumps, break_index, channel_id, seed, t_ms):
    """Random bump pick keyed by (channel, break index, seed, time)."""
    if not bumps:
        return None
    elig = _eligible(bumps, t_ms)
    if not elig:
        return None
    rnd = _pr(_ln(f'{channel_id}-break-{break_index}-{seed}'))
    return elig[int(math.floor(rnd() * len(elig)))]


# --- bump deck (qm/zm/Gm): avoids repeating the same bump --------------------

def _qm(pool, recent, seed):
    rnd = _pr(seed)
    s = list(pool)
    for i in range(len(s) - 1, 0, -1):
        j = int(math.floor(rnd() * (i + 1)))
        s[i], s[j] = s[j], s[i]
    half = len(s) // 2
    ranks = {}
    for k in range(min(half, len(recent)), 0, -1):
        ranks[id(recent[len(recent) - k])] = half + 1 - k
    if not ranks:
        return s
    def rank(x):
        return ranks.get(id(x), 0)
    for k in range(1, min(half, len(recent)) + 1):
        u = recent[len(recent) - k]
        d = next((i for i, x in enumerate(s) if x is u), -1)
        if d < 0 or d >= rank(u):
            continue
        cand = [p for p in range(rank(u), len(s)) if rank(s[p]) <= d]
        if not cand:
            continue
        h = cand[int(math.floor(rnd() * len(cand)))]
        s[d], s[h] = s[h], s[d]
    return s


def _deck_pick(deck, bumps, channel_id, seed, t_ms):
    if not bumps:
        return None
    elig = _eligible(bumps, t_ms)
    if not elig:
        return None
    _, _, seasonal = _ph(bumps)
    act = [b for b in seasonal if _in_date_range(b['date_range'], t_ms)]
    key = '|'.join(b['id'] for b in act) if act else ''
    if deck['key'] != key or deck['pos'] >= len(deck['order']):
        deck['order'] = _qm(elig, deck['recent'],
                            _ln(f'{channel_id}-deck-{seed}-{deck["rounds"]}'))
        deck['rounds'] += 1
        deck['pos'] = 0
        deck['key'] = key
    pick = deck['order'][deck['pos']]
    deck['pos'] += 1
    deck['recent'].append(pick)
    if len(deck['recent']) > len(deck['order']):
        deck['recent'].pop(0)
    return pick


def _deck_state(carry):
    if carry:
        return {'order': list(carry.get('order') or []),
                'pos': carry.get('pos', 0),
                'key': carry.get('key'),
                'recent': list(carry.get('recent') or []),
                'rounds': 0}
    return {'order': [], 'pos': 0, 'key': None, 'recent': [], 'rounds': 0}


def _sting_pick(stings, break_index, channel_id, seed):
    if not stings:
        return None
    rnd = _pr(_ln(f'{channel_id}-card-{break_index}-{seed}'))
    return stings[int(math.floor(rnd() * len(stings)))]


# --- ad selection (tg/Qm/eg/ng/su/rg/sg) -------------------------------------

def _ci(item):
    try:
        return int(str(item.get('year') or '').strip())
    except (TypeError, ValueError):
        return None


def _ad_phase_rank(slices):
    def zm(sl):
        return int(math.floor(_pr(_ln(f'ad-{sl["id"]}'))() * _NT))
    order = list(range(len(slices)))
    order.sort(key=lambda i: (zm(slices[i]), slices[i].get('id', ''), i))
    phases = [0] * len(slices)
    n = len(slices)
    for pos, orig in enumerate(order):
        phases[orig] = math.floor(pos * _NT / n)
    return phases


def _tg_rates(lineup, block=None, gap_ms=_DC, slice_ms=105000):
    s = i = o = c = 0
    by_year = {}
    n = len(lineup)
    for idx, u in enumerate(lineup):
        f = u['duration'] * 1000
        s += f
        i += f
        o += f
        if block and idx < n - 1 and o < block['lengthMs']:
            s += block['cardMs']
            i += block['cardMs']
            o += block['cardMs']
            continue
        o = 0
        nxt = lineup[(idx + 1) % n]
        if (u.get('offAir') is not True and nxt.get('offAir') is not True
                and i >= gap_ms):
            c += 1
            yr = _ci(u)
            by_year[yr] = by_year.get(yr, 0) + 1
            s += _GS + slice_ms
            i = _GS // 2
        else:
            s += _GS
            i += _GS
    return {'cycleMs': s, 'total': c, 'byYear': by_year}


def _ad_start_ms(start, channel_id):
    if _is_int(start) and 0 <= start < 1000:
        v = start
    else:
        v = _u32(_ln(f'ads-{channel_id}')) % 1000
    return v * (_NT // 1000)


def _ad_plan(slices, lineup, block, gap_ms, channel_id, start, decades):
    phases = _ad_phase_rank(slices)
    avg = sum(sl['lengthMs'] for sl in slices) / len(slices)
    rates = _tg_rates(lineup, block=block, gap_ms=gap_ms, slice_ms=avg)
    years = [_ci(sl) for sl in slices]
    memo = {}
    dec_tol = f'd{decades}' if _is_int(decades) and decades >= 1 else None

    def make_tier(g, tol):
        key = (g, tol)
        if key in memo:
            return memo[key]
        w = int(tol[1:]) if isinstance(tol, str) else None
        def y(n_val):
            if tol == float('inf'):
                return True
            if n_val is None or g is None:
                return False
            if w is not None:
                return abs(n_val // 10 - g // 10) <= w
            return abs(n_val - g) <= tol
        idxs = [i for i in range(len(slices))
                if slices[i].get('anywhere') is True or y(years[i])]
        idxs.sort(key=lambda i: (phases[i], slices[i].get('id', ''), i))
        t_sum = sum(cnt for yr, cnt in rates['byYear'].items() if y(yr))
        need = t_sum * _RU / rates['cycleMs'] if rates['cycleMs'] > 0 else 0
        healthy = len(idxs) > 0 and len(idxs) >= need
        if healthy or not idxs:
            round_ms = _RU
        else:
            round_ms = max(_XM, math.floor(len(idxs) * rates['cycleMs'] / t_sum))
        tier = {'tol': tol, 'list': idxs,
                'places': [phases[i] for i in idxs],
                'roundMs': round_ms, 'healthy': healthy}
        memo[key] = tier
        return tier

    def tiers(year):
        if year in memo and isinstance(memo.get(year), list):
            return memo[year]
        if year is None:
            cands = [make_tier(None, float('inf'))]
        else:
            tls = [3, 6] + ([dec_tol] if dec_tol else []) + [float('inf')]
            cands = [make_tier(year, t) for t in tls]
        start_i = 0
        for i, t in enumerate(cands):
            if t['healthy'] or t['tol'] == float('inf'):
                start_i = i
                break
        out = cands[start_i:]
        memo[year] = out
        return out

    return {'phases': phases, 'start': _ad_start_ms(start, channel_id),
            'rates': rates, 'tiers': tiers}


def _su(e, t, n):
    r = ((e % t) + t) % t
    return (math.floor(r * _NT / t) + n) % _NT


def _rg(arr, target):
    lo, hi = 0, len(arr)
    while lo < hi:
        mid = (lo + hi) // 2
        if arr[mid] < target:
            lo = mid + 1
        else:
            hi = mid
    return lo


def _sg(plan, recent, year, r, s=None):
    if s is None:
        s = r
    if len(recent) >= len(plan['phases']):
        recent.clear()
    tiers = [t for t in plan['tiers'](year) if t['list']]
    starts = []
    for tier in tiers:
        u = len(tier['list'])
        d = _su(s, tier['roundMs'], plan['start'])
        f = _su(r, tier['roundMs'], plan['start'])
        if r <= s:
            h = 0
        elif r - s >= tier['roundMs']:
            h = _NT
        else:
            h = (f - d + _NT) % _NT
        p = math.floor(min(_NH, tier['roundMs']) * _NT / tier['roundMs'])
        m = _rg(tier['places'], d + 1)
        starts.append(m)
        for g in range(u):
            v = (m + g) % u
            val = (tier['places'][v] - d + _NT) % _NT
            if (val or _NT) > h:
                break
            if tier['list'][v] not in recent:
                recent.add(tier['list'][v])
                return tier['list'][v]
        for g in range(1, u + 1):
            v = (m - g + u * 2) % u
            if (d - tier['places'][v] + _NT) % _NT >= p:
                break
            if tier['list'][v] not in recent:
                recent.add(tier['list'][v])
                return tier['list'][v]
    for li, tier in enumerate(tiers):
        u = len(tier['list'])
        for f in range(1, u + 1):
            cand = tier['list'][(starts[li] - f + u * 2) % u]
            if cand not in recent:
                recent.add(cand)
                return cand
    return -1


# --- schedule engine (og/wa/_a/gg/vg/Zt/Ji) ---------------------------------

def _og(items, t):
    """Interleave videos with bump breaks / up-next cards / ads."""
    if not t or not t.get('channelBumps') or not t.get('platformBumps'):
        return [dict(m, type='video') for m in items]
    n = t['channelBumps']
    r = t['platformBumps']
    o = t['channelId']
    c = t['seed']
    block = t.get('block')
    first = t.get('firstIndex') or 0
    f = t.get('cycleStartMs') or 0
    h = 0
    card_i = 0
    out = []
    ads = t.get('ads')
    slices = ads.get('slices') if ads else None
    g = slices if slices else None
    v = t.get('adCarry') if g else None
    recent = set()
    if v:
        for pair in (v.get('recent') or []):
            if _is_int(pair[0]) and 0 <= pair[0] < len(g):
                recent.add(pair[0])
    w = v.get('fromMs') if v and _is_int(v.get('fromMs')) else None
    picked = []
    gap = ads.get('gapMs') if ads and _is_int(ads.get('gapMs')) else _DC
    plan = t.get('_plan') if g else None
    if g and plan is None:
        plan = _ad_plan(g, t.get('adLineup') or items, block, gap, o,
                        ads.get('start'), ads.get('decades'))
    i_since_ad = 0
    deck = _deck_state(t.get('deckCarry')) if t.get('deck') else None
    n_items = len(items)
    wrap = t.get('wrapItem')
    for W, M in enumerate(items):
        j = first + W
        out.append(dict(M, type='video'))
        dur = M['duration'] * 1000
        f += dur
        h += dur
        i_since_ad += dur
        if block and W < n_items - 1 and h < block['lengthMs']:
            sting = _sting_pick(block.get('stings'), j, o, c)
            x = sting['lengthMs'] if sting else block['cardMs']
            out.append({'type': 'up-next', 'breakIndex': j, 'cardIndex': card_i,
                        'durationMs': x})
            card_i += 1
            f += x
            h += x
            i_since_ad += x
            continue
        h = 0
        x = f
        if deck:
            q = _deck_pick(deck, n, o, c, x)
        else:
            q = _tu(n, j, o, c, x)
        ae = _tu(r, j, 'spelunkr', c, x)
        if q and ae:
            nxt = items[W + 1] if W < n_items - 1 else wrap
            if (g is not None and M.get('offAir') is not True
                    and (nxt is None or nxt.get('offAir') is not True)
                    and i_since_ad >= gap):
                me = _sg(plan, recent, _ci(M), f,
                         w if w is not None else f - i_since_ad)
                w = None
                if 0 <= me < len(g):
                    picked.append((me, f))
                    ne = g[me]
                    z = _UC + _ri(q.get('slides')) + _PS + _AI
                    vlen = _ri(ae.get('slides')) + _PS + _AI
                    out.append({'type': 'bump-break', 'half': 'open',
                                'breakIndex': j, 'durationMs': z})
                    out.append({'type': 'ad', 'breakIndex': j, 'slice': ne,
                                'sliceIndex': me, 'durationMs': ne['lengthMs']})
                    out.append({'type': 'bump-break', 'half': 'close',
                                'breakIndex': j, 'durationMs': vlen})
                    f += z + ne['lengthMs'] + vlen
                    i_since_ad = vlen
                    if t.get('adOut') is not None:
                        t['adOut']['fromMs'] = f
                    continue
            e_km = _km(q, ae)
            out.append({'type': 'bump-break', 'breakIndex': j,
                        'channelBump': q, 'platformBump': ae,
                        'durationMs': e_km})
            f += e_km
            i_since_ad += e_km
    if g is not None and t.get('adOut') is not None:
        ad_out = t['adOut']
        if not picked:
            ad_out['fromMs'] = w if w is not None else (t.get('cycleStartMs') or 0)
        cutoff = f - _NH
        prior = list((v.get('recent') or []) if v else [])
        ad_out['recent'] = [p for p in prior + picked if p[1] >= cutoff]
    if deck is not None and t.get('deckOut') is not None:
        t['deckOut'].update({'order': deck['order'], 'pos': deck['pos'],
                             'key': deck['key'], 'recent': deck['recent']})
    return out


def _wa(vs, cyc, opts):
    r = vs['startIndex'] if cyc == 0 else 0
    items = vs['items']
    sliced = items[r:] if r else items
    has_ads = bool(vs.get('ads') and vs.get('bumps') and cyc >= 0)
    ad_out = {} if has_ads else None
    deck_on = bool(vs.get('bumps') and vs.get('engine', 0) >= _HG)
    deck_out = {} if (deck_on and cyc >= 0) else None
    if vs.get('bumps'):
        o = dict(vs['bumps'])
        o.update({'block': vs.get('block'), 'channelId': vs['channelId'],
                  'seed': f"{vs['v']}.{cyc}", 'firstIndex': r})
        if vs.get('ads'):
            o.update({'ads': vs['ads'], 'adLineup': items,
                      'wrapItem': items[0],
                      'adCarry': vs['adCarry'].get(cyc) if cyc >= 1 else None,
                      'adOut': ad_out, '_plan': vs.get('_plan')})
        if deck_on:
            o.update({'deck': True,
                      'deckCarry': vs['deckCarry'].get(cyc) if cyc >= 1 else None,
                      'deckOut': deck_out})
        o.update(opts)
        entries = _og(sliced, o)
    else:
        entries = _og(sliced, None)
    if has_ads and (cyc + 1) not in vs['adCarry']:
        vs['adCarry'][cyc + 1] = ad_out
    if deck_on and (cyc + 1) not in vs['deckCarry']:
        vs['deckCarry'][cyc + 1] = deck_out
    return entries


def _entry_dur(e):
    if _is_int(e.get('durationMs')):
        return e['durationMs']
    return e['duration'] * 1000


def _ou(entries):
    return sum(_entry_dur(e) for e in entries)


def _ensure_cycle(vs, idx):
    fwd = vs['fwd']
    while len(fwd) <= idx and len(fwd) < _MAX_CYCLES:
        start = (fwd[-1]['startMs'] + fwd[-1]['lengthMs'] if fwd
                 else vs['epochMs'])
        entries = _wa(vs, len(fwd), {'cycleStartMs': start})
        vi = vs['startIndex'] if not fwd else 0
        for e in entries:
            if e.get('type') == 'video':
                e['videoIndex'] = vi
                vi += 1
        fwd.append({'startMs': start, 'lengthMs': _ou(entries),
                    'entries': entries})
    if idx >= len(fwd):
        raise RuntimeError(f'{vs["channelId"]}: schedule walk exceeded '
                           f'{_MAX_CYCLES} cycles')
    return fwd[idx]


def _find_cycle(vs, t_ms):
    _ensure_cycle(vs, 0)
    i = 0
    while True:
        cyc = _ensure_cycle(vs, i)
        if t_ms < cyc['startMs'] + cyc['lengthMs']:
            return i
        i += 1


def _zstate(vs, t_ms):
    """Port of Zt(): the entry on air at t_ms."""
    cyc_i = _find_cycle(vs, t_ms)
    cyc = vs['fwd'][cyc_i]
    entries = cyc['entries']
    rel = t_ms - cyc['startMs']
    lo, hi = 0, len(entries) - 1
    while lo < hi:
        mid = (lo + hi + 1) // 2
        if _entry_off(entries, mid) <= rel:
            lo = mid
        else:
            hi = mid - 1
    ent = entries[lo]
    start = cyc['startMs'] + _entry_off(entries, lo)
    end = start + _entry_dur(ent)
    return {'entry': ent, 'index': lo, 'cycle': cyc_i, 'start_ms': start,
            'end_ms': end, 'offset_s': max(0, (t_ms - start)) // 1000}


_off_cache = {}


def _entry_off(entries, i):
    key = id(entries)
    offs = _off_cache.get(key)
    if offs is None or len(offs) != len(entries):
        offs = []
        acc = 0
        for e in entries:
            offs.append(acc)
            acc += _entry_dur(e)
        _off_cache[key] = offs
    return offs[i]


def _pick_version(channel, t_ms):
    vers = sorted(channel.get('versions') or [], key=lambda v: v['v'])
    chosen = None
    for v in vers:
        if v.get('effectiveAtMs', v.get('epochMs', 0)) <= t_ms:
            chosen = v
    if chosen is None and vers:
        chosen = min(vers, key=lambda v: v.get('effectiveAtMs', 0))
    cap = None
    if chosen:
        for v in vers:
            if v['v'] > chosen['v'] and v.get('effectiveAtMs', 0) > t_ms:
                cap = v['effectiveAtMs'] if cap is None else min(cap, v['effectiveAtMs'])
    return chosen, cap


def _build_version_state(channel, v_ptr):
    manifest = _fetch_json(v_ptr['manifest'])
    bumps = None
    ch_bumps = manifest.get('bumps') or []
    plat_path = manifest.get('platform')
    plat_bumps = []
    if plat_path:
        plat_bumps = (_fetch_json(plat_path) or {}).get('bumps') or []
    if ch_bumps and plat_bumps:
        bumps = {'channelBumps': ch_bumps, 'platformBumps': plat_bumps}
    ads = manifest.get('ads')
    if ads and not ads.get('slices'):
        ads = None
    vs = {'channelId': channel['id'], 'v': v_ptr['v'],
          'epochMs': v_ptr['epochMs'],
          'effectiveAtMs': v_ptr.get('effectiveAtMs', v_ptr['epochMs']),
          'startIndex': v_ptr.get('startIndex') or 0,
          'items': manifest.get('items') or [],
          'bumps': bumps, 'block': manifest.get('block'),
          'ads': ads, 'engine': manifest.get('engine', 1),
          'fwd': [], 'adCarry': {}, 'deckCarry': {}}
    if ads and bumps:
        vs['_plan'] = _ad_plan(ads['slices'], vs['items'], vs['block'],
                               ads.get('gapMs') if _is_int(ads.get('gapMs'))
                               else _DC, channel['id'],
                               ads.get('start'), ads.get('decades'))
    return vs


def _channel_state(channel, t_ms):
    with _state_lock:
        st = _states.get(channel['id'])
    v_ptr, cap = _pick_version(channel, t_ms)
    if v_ptr is None:
        raise RuntimeError(f'{channel["id"]}: no versions')
    if st is None or st['v'] != v_ptr['v']:
        st = _build_version_state(channel, v_ptr)
        st['cap_ms'] = cap
        with _state_lock:
            _states[channel['id']] = st
    return st


# --- public data API ---------------------------------------------------------

def get_lineup():
    return _fetch_json(LINEUP_PATH, ttl_s=LINEUP_TTL_S)


def visible_channels():
    """Public (non-debug) channels with versions, sorted by dial."""
    out = []
    for ch in (get_lineup().get('channels') or []):
        if ch.get('debugOnly') or ch.get('comingSoon'):
            continue
        if not ch.get('versions'):
            continue
        out.append(ch)
    out.sort(key=lambda c: (c.get('dial') is None, c.get('dial') or 0))
    return out


def _archive_url(item):
    name = item.get('file') or item.get('mp4')
    if not item.get('id') or not name:
        return None
    return IA_DOWNLOAD + urllib.parse.quote(str(item['id']), safe='') + '/' + \
        urllib.parse.quote(str(name), safe="!*'()")


def _ad_url(sl):
    return IA_DOWNLOAD + urllib.parse.quote(str(sl.get('tape') or ''), safe='') + \
        '/' + urllib.parse.quote(str(sl.get('file') or ''), safe="!*'()")


def _next_videos(vs, cyc_i, index, count):
    """Upcoming video entries (skipping breaks), across cycle edges."""
    out = []
    ci, i = cyc_i, index + 1
    while len(out) < count and ci < _MAX_CYCLES:
        cyc = _ensure_cycle(vs, ci)
        entries = cyc['entries']
        while i < len(entries) and len(out) < count:
            e = entries[i]
            if e.get('type') == 'video':
                out.append({'entry': e, 'start_ms':
                            cyc['startMs'] + _entry_off(entries, i)})
            i += 1
        ci += 1
        i = 0
        if ci >= len(vs['fwd']) and ci >= _MAX_CYCLES:
            break
        if ci < _MAX_CYCLES:
            _ensure_cycle(vs, ci)
    return out


def channel_now(channel, t_ms=None, next_count=3):
    """Now/up-next schedule for one lineup channel (pure computation)."""
    t_ms = int(t_ms if t_ms is not None else time.time() * 1000)
    vs = _channel_state(channel, t_ms)
    st = _zstate(vs, t_ms)
    ent = st['entry']
    play = None
    now = None
    nxt = _next_videos(vs, st['cycle'], st['index'], next_count)
    if ent.get('type') == 'video':
        item = vs['items'][ent['videoIndex']]
        url = _archive_url(item)
        seek = st['offset_s'] + (item.get('inS') or 0)
        if item.get('outS'):
            seek = min(seek, max(0, item['outS'] - 5))
        else:
            seek = min(seek, max(0, item['duration'] - 5))
        now = {'kind': 'video', 'title': item.get('title') or item.get('id'),
               'year': item.get('year'), 'start_ms': st['start_ms'],
               'end_ms': st['end_ms'], 'offset_s': st['offset_s']}
        play = {'url': url, 'seek': max(0, seek),
                'title': now['title']} if url else None
    else:
        kind = ent.get('type')
        label = {'ad': 'Commercial break', 'bump-break': 'SPELUNKR break',
                 'up-next': 'Program break'}.get(kind, 'Break')
        now = {'kind': kind, 'title': label, 'year': None,
               'start_ms': st['start_ms'], 'end_ms': st['end_ms'],
               'offset_s': st['offset_s']}
        if nxt:
            nxt_item = nxt[0]['entry']
            item = vs['items'][nxt_item['videoIndex']]
            url = _archive_url(item)
            if url:
                play = {'url': url, 'seek': item.get('inS') or 0,
                        'title': item.get('title') or item.get('id')}
    upcoming = []
    for n in nxt:
        item = vs['items'][n['entry']['videoIndex']]
        upcoming.append({'title': item.get('title') or item.get('id'),
                         'start_ms': n['start_ms']})
    det = _channel_details(channel, vs['v'])
    desc = ''
    if det:
        di = ent.get('videoIndex')
        if di is None and nxt:
            di = nxt[0]['entry'].get('videoIndex')
        if _is_int(di) and 0 <= di < len(det):
            desc = (det[di] or {}).get('description') or ''
    now['desc'] = desc
    return {'now': now, 'upcoming': upcoming, 'play': play}


_det_cache = {}


def _channel_details(channel, v):
    key = (channel['id'], v)
    if key not in _det_cache:
        path = None
        for vp in channel.get('versions') or []:
            if vp['v'] == v:
                path = vp.get('details')
                break
        try:
            det = _fetch_json(path) if path else None
            _det_cache[key] = det.get('items') if det else None
        except Exception:
            _det_cache[key] = None
    return _det_cache[key]


def all_now(t_ms=None, workers=8):
    """Schedule for every visible channel. Fetches are parallelized."""
    t_ms = int(t_ms if t_ms is not None else time.time() * 1000)
    chans = visible_channels()
    # warm manifest/platform/details caches in parallel before computing
    def warm(ch):
        try:
            v_ptr, _cap = _pick_version(ch, t_ms)
            if v_ptr:
                _fetch_json(v_ptr['manifest'])
                det = v_ptr.get('details')
                if det:
                    _fetch_json(det)
                man = _fetch_json(v_ptr['manifest'])
                if man.get('platform'):
                    _fetch_json(man['platform'])
        except Exception:
            pass
    with ThreadPoolExecutor(max_workers=workers) as ex:
        list(ex.map(warm, chans))
    rows = []
    for ch in chans:
        try:
            rows.append({'channel': ch, 'schedule': channel_now(ch, t_ms)})
        except Exception as e:
            rows.append({'channel': ch, 'error': str(e)})
    return rows


def play_target(channel_id, t_ms=None):
    """Fresh play target at click time: {url, seek, title} or None."""
    t_ms = int(t_ms if t_ms is not None else time.time() * 1000)
    for ch in visible_channels():
        if ch['id'] == channel_id:
            sched = channel_now(ch, t_ms)
            return sched['play']
    return None


# --- formatting helpers ------------------------------------------------------

def fmt_time(ms):
    return datetime.datetime.fromtimestamp(ms / 1000).strftime('%I:%M %p').lstrip('0')


def fmt_range(start_ms, end_ms):
    return f'{fmt_time(start_ms)} - {fmt_time(end_ms)}'


if __name__ == '__main__':
    t0 = time.time()
    for row in all_now():
        ch = row['channel']
        if 'error' in row:
            print(f'{ch.get("dial")} {ch.get("name")}: ERROR {row["error"]}')
            continue
        s = row['schedule']
        now = s['now']
        print(f'{ch.get("dial"):>4} {ch.get("name")}: {now["title"]} '
              f'[{fmt_range(now["start_ms"], now["end_ms"])}]')
        for up in s['upcoming'][:1]:
            print(f'         next: {up["title"]} @ {fmt_time(up["start_ms"])}')
    print(f'({time.time() - t0:.1f}s)')
