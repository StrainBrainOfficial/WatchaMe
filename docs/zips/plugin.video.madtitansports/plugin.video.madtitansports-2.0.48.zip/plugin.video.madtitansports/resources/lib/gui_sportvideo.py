import os
import re
import urllib.parse

import xbmc
import xbmcgui

from resources.lib.tool import log
from resources.lib.gui_helpers import strip_color_tags, get_route_for_item, navigate_to_results
from resources.lib import loading_overlay

ADDON_ID = "plugin.video.madtitansports"


class SportVideoMixin:

    def _sportvideo_menu_push(self, title, items):
        gui_items = []
        for item in items:
            route = get_route_for_item(item)
            gui_items.append({
                'title': item.get('title', ''),
                'thumbnail': item.get('thumbnail', item.get('icon', '')),
                'fanart': item.get('fanart', ''),
                'summary': item.get('summary', ''),
                'route': route,
                'raw': item,
            })
        navigate_to_results(self, gui_items, title)

    def _sportvideo_menu(self):
        log('_sportvideo_menu called')
        menu_items = [
            {
                'title': '[COLOR yellow]Search Sport-Video.org.ua[/COLOR]',
                'type': 'item',
                'sportvideo': 'search_input',
                'summary': 'Search sports torrents, play via debrid',
            },
        ]
        self._sportvideo_menu_push('Sport Torrent Search', menu_items)

    def _sportvideo_search(self):
        log('_sportvideo_search called')
        query = xbmcgui.Dialog().input("Search sport-video.org.ua")
        if not query:
            return
        self._sportvideo_search_term(query)

    def _sportvideo_search_term(self, term):
        log(f'_sportvideo_search_term called with term={term}')
        from resources.lib.plugins.sportvideo import search_all, build_result_item
        progress = xbmcgui.DialogProgress()
        progress.create("Sport Search", f"Searching for '{term}'...")
        try:
            progress.update(20, "Searching sport-video + rutor...")
            games = search_all(term)
            if not games:
                progress.close()
                xbmcgui.Dialog().ok("Sport Search", f"No results for '{term}'")
                return
            progress.update(80, f"Found {len(games)} result(s)")
            jen_list = [build_result_item(g) for g in games]
            progress.close()
            log(f'_sportvideo_search_term: {len(jen_list)} results for "{term}"')
            self._sportvideo_menu_push(f'Sport Search: {term}', jen_list)
        except Exception as e:
            progress.close()
            log(f'_sportvideo_search_term error: {e}', level=xbmc.LOGERROR)
            xbmcgui.Dialog().ok("Sport Search", f"Search failed: {e}")

    def _sportvideo_play(self, route_val, raw=None):
        log(f'_sportvideo_play called with route_val={route_val}')
        raw = raw or {}
        page = route_val or ''
        if page.startswith('play/'):
            page = page[len('play/'):]
        page = urllib.parse.unquote(page)
        if not page:
            xbmcgui.Dialog().ok("Sport Search", "No page URL provided.")
            return
        title = strip_color_tags(raw.get('title', ''))
        title = re.sub(r'\s*\((?:rutor|sport-video)\)\s*$', '', title).strip()
        from resources.lib.plugins.sportvideo import get_playable_link, _display_title, _is_rutor_url
        title = _display_title(title) if title else os.path.basename(page)
        progress = xbmcgui.DialogProgress()
        progress.create("Sport Search", "Fetching torrent...")
        try:
            if _is_rutor_url(page):
                progress.update(40, "Fetching rutor magnet...")
            else:
                progress.update(40, "Downloading .torrent file...")
            link, err = get_playable_link(page, title=title)
            if err or not link:
                progress.close()
                xbmcgui.Dialog().ok("Sport Search", err or "Could not build link.")
                return
            progress.update(80, "Resolving via debrid...")
            import resolveurl
            if resolveurl.HostedMediaFile(link).valid_url():
                url = resolveurl.HostedMediaFile(link).resolve()
                progress.close()
                if not url:
                    xbmcgui.Dialog().ok(
                        "Sport Search",
                        "Debrid service did not return a stream.\nEnable torrent/magnet support in your ResolveURL debrid settings.",
                    )
                    return
                liz = xbmcgui.ListItem(title)
                liz.setInfo('video', {'title': title})
                liz.setArt({'thumb': raw.get('thumbnail', ''), 'icon': raw.get('thumbnail', '')})
                liz.setProperty('IsPlayable', 'true')
                log(f"_sportvideo_play: Resolved URL via resolveurl for '{title}'", level=xbmc.LOGINFO)
                loading_overlay.show()
                xbmc.Player().play(url, liz)
            else:
                progress.close()
                xbmcgui.Dialog().ok(
                    "Sport Search",
                    "No debrid resolver accepted this magnet.\nEnable torrent/magnet support in ResolveURL (Real-Debrid, AllDebrid, Premiumize, TorBox, etc.).",
                )
        except Exception as e:
            progress.close()
            log(f'_sportvideo_play error: {e}', level=xbmc.LOGERROR)
            xbmcgui.Dialog().ok("Sport Search", f"Error: {e}")
