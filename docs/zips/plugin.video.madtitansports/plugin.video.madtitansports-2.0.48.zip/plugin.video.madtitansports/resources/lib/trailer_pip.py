"""Small picture-in-picture preview while browsing the GUI.

Movies: 2s debounce on the Trending row fetches the TMDB/YouTube trailer key
and resolves it via YouTube's InnerTube ANDROID client (plugin.video.youtube
fallback), then plays windowed — xbmc.Player().play(url, li, windowed=True) —
so the GUI keeps focus.

Live channels: 1.5s debounce on the TV-networks grid (Sports Networks /
Live TV) matches the channel name against timstreams_data.db; direct links
play as-is, embed links go through the TimStreams extractor + ResolveURL.
Local-IPTV store channels (MyIPTV / HomeIPTV / Telegram) route through the
JetProxy service (127.0.0.1:49777, external interpreter) when it is up —
its keep-alive manifest re-fetch + UA rotation stops portals from dropping
the stream after 10-30s; direct play is the fallback when the service is
down. Channels started from the context menu ("Play in Preview (Pin)") stay
pinned while scrolling; auto-preview never interrupts a pinned preview.
Kodi has a single video player, so only one PiP window can ever show at a
time.

The skin's <control type="videowindow"> renders it, gated on the
madtitan_pip_on window property (set BEFORE the first frame: a hidden video
window starves the player buffer) plus the current preview_mode.
"""
import os
import re
import sqlite3
import threading
import time
from urllib.parse import quote
import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from resources.lib.gui_helpers import strip_color_tags
from resources.lib.tool import log

ADDON_ID = 'plugin.video.madtitansports'
PROP = 'madtitan_pip_on'
DELAY = 2.0      # seconds a movie must stay highlighted before resolving
LIVE_DELAY = 2.5  # seconds a channel must stay highlighted
WATCHDOG = 15.0  # hide the window if no media appeared after play()
TS_DB = 'special://home/userdata/addon_data/script.module.jetextractors/timstreams_data.db'
B2_DB = 'special://home/userdata/addon_data/script.module.jetextractors/backdoor2_data.db'

# Quality/region words dropped from BOTH sides of channel-name matching so
# guide 'ESPN HD' == TimStreams 'ESPN' == 24/7 'ESPN USA',
# 'MLB Network HD' == 'MLB Network USA', etc. 'dt' = ATSC broadcast suffix
# ('KTLA-DT' == 'KTLA').
_NORM_DROP = {'hd', 'fhd', 'uhd', 'hdtv', 'sd', '4k', '8k', 'hdr', 'hevc',
              '1080p', '1080i', '720p', '576p', '480p', 'usa', 'dt', 'national'}

# Guide-title abbreviations expanded (word-boundary, case-insensitive) on
# BOTH sides before matching; the rest of the name is kept as-is:
#   'SkySp Football HD' -> 'Sky Sports Football' == DB 'Sky Sports Football'
#   'SkySp Golf'        -> 'Sky Sports Golf'     == DB 'Sky Sports Golf'
# Add new abbreviation pairs here as the guide data uses them.
_NAME_ALIASES = {
    'skysp': 'sky sports',
    'sky sp': 'sky sports',
    'abc national feed': 'abc',
    'nbc east stream': 'nbc',
    'cbs streaming': 'cbs',
    'new england sports network': 'nesn'
}

# OTA-style guide titles carry the market callsign in parens:
# 'NBC 4 (WNBC) New York', 'CBS 2 (WCBS) New York' — used to match the
# local-IPTV stores (MyIPTV / HomeIPTV / Telegram) by callsign.
_CALLSIGN_RE = re.compile(r'\(([A-Za-z0-9]{3,5})\)')

# Same UA JetProxy injects (plugin.video.jetproxy server.py DEFAULT_UA) —
# used for the DIRECT-play fallback of local-store streams when the
# JetProxy service is down (never a local proxy in this interpreter —
# keeps post-close Stats pure-C++, GUI_PIP rules C/E).
_PREVIEW_UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
               '(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36')

# JetProxy service (plugin.video.jetproxy) hosts the HLS keep-alive proxy
# in ITS OWN interpreter (service.py, boot-started) — same proxy the main
# jet play path uses for jetproxy:// links: fresh manifest re-fetch, UA
# rotation on 403/404, header injection → portals stop dropping streams at
# 10-30s. TWO ports: 49777 = control plane (endpoints /playstart,
# /playstop, /pipopen, /pipstop — always listening); 49778 = PiP data
# plane (preview URLs). /pipstop closes the 49778 listener BEFORE
# player.stop() so the post-close Stat is kernel-refused instantly — the
# service demonstrably stops serving for the whole stop window otherwise
# (log 2026-10-29 18:04:34–18:05:14: zero handler activity for 40s,
# instant answers right after stop() returned), and kernel refusal needs
# no Python (GUI_PIP rules C/H). /pipopen rebinds before the next play.
# NO proxy is hosted in THIS interpreter (rules C/E hold).
JETPROXY = 'http://127.0.0.1:49777'       # control plane (never paused)
JETPROXY_PIP = 'http://127.0.0.1:49778'   # data plane (paused across stops)

# Local-IPTV stores consulted after TimStreams AND 24/7 miss/fail:
# (python module, display label) — all xtream rows (portal/user/pass/stream_id).
_LOCAL_STORES = (
    ('jetextractors.util.myiptv_store', 'MyIPTV'),
    ('jetextractors.util.homeiptv_store', 'HomeIPTV'),
    ('jetextractors.util.TelegramStore', 'Telegram'),
)


class _PipPlayer(xbmc.Player):
    """Callbacks fire for every playback on the device, so each handler
    gates on the window's own _on flag."""

    def __init__(self, pip):
        xbmc.Player.__init__(self)
        self._pip = pip

    def onAVStarted(self):
        self._pip.av_started()

    def onPlayBackEnded(self):
        self._pip.finished()

    def onPlayBackStopped(self):
        self._pip.finished()

    def onPlayBackError(self):
        self._pip.finished()


class TrailerPIP:
    def __init__(self, win):
        self.win = win
        self._token = 0
        self._timer = None
        self._watch = None
        self._player = None
        self._on = False
        self._for = ''
        self._pending = ''
        self._muted = False
        self._pinned = False
        self._ts = None
        self._ts_mtime = -1
        self._ts_missing_logged = False
        self._b2 = None
        self._b2_mtime = -1
        self._fallback = None
        self._stream = None
        self._label = ''
        self._handed_off = False

    def enabled(self):
        try:
            return xbmcaddon.Addon(ADDON_ID).getSetting('pip_trailers') == 'true'
        except Exception:
            return False

    def enabled_live(self):
        try:
            return xbmcaddon.Addon(ADDON_ID).getSetting('pip_live') == 'true'
        except Exception:
            return False

    # ------------------------------------------------------------------ api

    def schedule(self, m):
        """Highlight settled on movie m: arm (or keep) its trailer.
        SCROLL-SAFE: never tears the playing preview down here — the old
        trailer keeps playing until the new worker swaps it (deferral:
        highlight churn must not block the GUI on player.stop())."""
        tid = str(m.get('id') or m.get('tmdb_id') or '')
        if not tid.isdigit():
            self.stop()
            return
        if self._pending == tid or (self._on and self._for == tid):
            return                       # already pending / playing this title
        self._cancel_pending()
        if not self.enabled():
            self.stop()
            return
        media = 'tv' if m.get('media_type') == 'tv' else 'movie'
        token = self._token
        t = threading.Timer(DELAY, self._worker, args=(token, tid, media, m.get('title', '')))
        t.daemon = True
        self._timer = t
        self._pending = tid
        t.start()

    def schedule_channel(self, title):
        """Highlight settled on a TV-networks channel: auto-preview unless
        a preview was pinned from the context menu.
        SCROLL-SAFE: only supersedes the pending schedule — the current
        preview keeps playing through fast scrolling; teardown/swap runs on
        the worker thread after the dwell (LIVE_DELAY), so the GUI thread
        never blocks on player.stop() while you move."""
        if self._pinned or not title:
            return
        clean = strip_color_tags(title)
        # Already pending, or already PLAYING this guide title (_label holds
        # the clean guide title — _for holds the DB name, which differs).
        if (self._on and (self._for == title or self._label == clean)) \
                or self._pending == title:
            return
        self._cancel_pending()
        if not self.enabled_live():
            self.stop()
            return
        token = self._token
        t = threading.Timer(LIVE_DELAY, self._channel_worker, args=(token, title))
        t.daemon = True
        self._timer = t
        self._pending = title
        t.start()

    def pin_channel(self, title):
        """Context-menu 'Play in Preview': start (or switch to) this channel
        and keep it playing while the user scrolls. The swap (stop old +
        play new) runs on the worker thread, not the GUI."""
        if not title:
            return
        self._cancel_pending()
        self._pinned = True
        token = self._token
        t = threading.Timer(0.2, self._channel_worker, args=(token, title))
        t.daemon = True
        self._timer = t
        self._pending = title
        t.start()

    def _cancel_pending(self):
        """Supersede any in-flight schedule WITHOUT touching the currently
        playing preview: bump the token (kills in-flight workers/fallbacks)
        and cancel only the pending schedule timer — never the playing
        preview's watchdog, proxies, or player. Also clears _pending so the
        same title can be re-scheduled later (a cleared timer with a stale
        pending would early-return in schedule/schedule_channel and never
        arm again)."""
        self._token += 1
        self._pending = ''
        t = self._timer
        self._timer = None
        if t is not None:
            try:
                t.cancel()
            except Exception:
                pass

    def cancel_pending(self):
        """Public: kill any armed auto-preview schedule without touching the
        playing preview — used when focus rests on a non-channel tile (the
        guide-label separators in the channel rows): the previous channel's
        dwell timer must not fire while the user is scrolling."""
        self._cancel_pending()

    def is_pinned(self):
        return self._pinned

    def is_playing(self):
        """True while a preview stream is actively playing (context-menu
        'Play Current Stream' entry gate)."""
        return bool(self._on and self._stream)

    def handoff_fullscreen(self):
        """Give the currently playing preview to the fullscreen player
        WITHOUT a player restart. Restarting (`Player.play(windowed=False)`)
        re-creates the player-close deadlock: closing the old file issues
        post-close CCurlFile::Stats against the SAME in-process proxy while
        the play() call holds this interpreter's GIL — accept loop frozen →
        20s black-holed Stat → new open's manifest fetch starves too →
        freeze + eof (log 2026-10-25 18:34/18:46). Instead: detach preview
        state and activate Kodi's fullscreen video window, which renders the
        SAME active player — playback never stops, no proxy churn, no GIL
        wait. Activation is POSTED to Kodi's GUI message queue, so poll for
        it (an instant check false-negatived and hit the restart fallback —
        log 18:46:51). If it never takes, restore the preview instead of
        restarting: the stream is still playing, so the PiP just continues.
        stop() skips proxy teardown while handed-off playback has video;
        finished()/stop() clean the proxies when that playback ends."""
        if not self._on or self._player is None or not self._stream:
            return False
        stream = self._stream
        prev_for, prev_pinned = self._for, self._pinned
        # Detach (flags/timers first). Property + mute stay as-is for now —
        # they are only committed on success, so a failed activation can
        # restore the preview exactly as it was.
        self._pinned = False
        self._token += 1
        self._pending = ''
        for attr in ('_timer', '_watch'):
            t = getattr(self, attr)
            if t is not None:
                try:
                    t.cancel()
                except Exception:
                    pass
                setattr(self, attr, None)
        self._on = False
        self._for = ''
        self._fallback = None
        self._handed_off = True
        try:
            xbmc.executebuiltin('ActivateWindow(fullscreenvideo)')
        except Exception:
            pass
        activated = False
        for _ in range(25):                 # up to ~2.5s for the GUI queue
            try:
                if xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)'):
                    activated = True
                    break
            except Exception:
                break
            time.sleep(0.1)                 # GIL-friendly; GUI thread drains
        if not activated:
            log('trailer_pip: fullscreen window did not activate - restoring preview',
                level=xbmc.LOGWARNING)
            try:
                xbmcgui.Dialog().notification(
                    'Channel Preview', 'Fullscreen did not open - preview continues',
                    xbmcgui.NOTIFICATION_WARNING, 3000)
            except Exception:
                pass
            self._on = True                 # stream never stopped: PiP resumes
            self._for = prev_for
            self._pinned = prev_pinned
            self._handed_off = False
            return False
        try:
            self.win.setProperty(PROP, '')   # hide skin videowindow control
        except Exception:
            pass
        if self._muted:
            self._set_mute(False)            # fullscreen should be audible
        log(f'trailer_pip: fullscreen window activated (no restart) '
            f'[{prev_for or "preview"}]')
        return True

    def stop_if_unpinned(self):
        """Channel-grid leave: keep a pinned preview alive."""
        if self._pinned:
            return False
        return self.stop()

    @staticmethod
    def _best_name_match(title_n, m):
        """Shared guide-title → channel-DB name matching (used for both the
        TimStreams and 24/7 maps). Order: exact → longest DB key embedded at
        the start of the guide title (≥6 chars so 'Fox' can't hijack FOX*
        entries; 'Fox Sports 1 HD' must pick 'Fox Sports 1') → nearest DB
        key wrapping a shorter guide title → containment fallback for front
        aliases ('FS1 Fox Sports 1 HD' → 'Fox Sports 1')."""
        if not title_n:
            return None
        hit = m.get(title_n)
        if hit:
            return hit
        if len(title_n) >= 4:
            embedded = [k for k in m if len(k) >= 6 and title_n.startswith(k)]
            if embedded:
                return m[max(embedded, key=len)]
            wraps = [k for k in m if k.startswith(title_n)]
            if wraps:
                return m[min(wraps, key=len)]
            subs = [k for k in m
                    if (len(k) >= 9 and k in title_n)
                    or (len(title_n) >= 6 and title_n in k)]
            if subs:
                return m[max(subs, key=len)]
        return None

    def match_timstreams(self, title):
        """Guide channel name -> (stream_url, db name) from timstreams DB."""
        return self._best_name_match(self._norm(strip_color_tags(title)),
                                     self._ts_map())

    def match_backdoor2(self, title):
        """Guide channel name -> (embed_url, db name) from the 24/7
        (Backdoor2) DB — fallback when TimStreams has no match or its
        resolve/playback fails."""
        return self._best_name_match(self._norm(strip_color_tags(title)),
                                     self._b2_map())

    @staticmethod
    def _callsign(s):
        """Market callsign from parens in a guide title: 'NBC 4 (WNBC) New
        York' -> 'WNBC' (raw string — runs before norm strips punctuation)."""
        m = _CALLSIGN_RE.search(s or '')
        return m.group(1) if m else None

    @staticmethod
    def _jetproxy_up():
        """Ensure the service is up AND the 49778 data-plane listener is
        listening (GET /pipopen on the control port — rebinds after a
        /pipstop pause, so NO cache: a cached 'up' would hand out 49778
        URLs while the listener is closed). New servers answer 200; older
        servers answer 400 'missing url' — treat those as DOWN so previews
        fall back to direct play instead of stalling on missing endpoints
        (log 2026-10-28 19:45/19:46). Runs once per channel match (worker
        thread), never on the scroll path."""
        try:
            r = requests.get(JETPROXY + '/pipopen', timeout=1)
            if r.status_code == 200:
                return True
            log(f'trailer_pip: jetproxy service outdated (HTTP {r.status_code} '
                'on /pipopen) - restart Kodi; previews play direct until then',
                level=xbmc.LOGWARNING)
        except Exception:
            pass
        return False

    @staticmethod
    def _jetproxy_signal(path):
        """Fire-and-forget GET on the JetProxy control port (/playstart,
        /pipstop). Worker/callback thread only — never the GUI. 1s timeout:
        a dead service fails instantly and play/stop proceeds without it."""
        try:
            requests.get(JETPROXY + path, timeout=1)
        except Exception:
            pass

    @staticmethod
    def _xtream_url(row):
        """xtream row -> playable preview URL. When the JetProxy service is
        up, route through the 49778 PiP data plane (…:49778/?url=…) — the
        same proxy/headers the main jet play path uses for jetproxy:// links:
        it re-fetches the manifest on every refresh and rotates the UA on
        403/404, which stops portals from dropping the stream after 10-30s.
        A dedicated port lets /pipstop kernel-refuse the post-close Stat
        (pause the listener across stop() — rules C/H). Direct play (raw URL
        + JetProxy's UA) is the fallback when the service is down — no proxy
        is ever hosted in THIS interpreter (rules C/E)."""
        portal = (row.get('portal') or '').rstrip('/')
        user = row.get('username') or ''
        pwd = row.get('password') or ''
        sid = row.get('stream_id') or ''
        if not (portal and user and pwd and sid):
            return None
        url = f'{portal}/live/{user}/{pwd}/{sid}.m3u8'
        if TrailerPIP._jetproxy_up():
            return f'{JETPROXY_PIP}/?url={quote(url, safe="")}'
        log('trailer_pip: jetproxy service down - local-store preview plays direct '
            '(no keep-alive: portals may drop it after 10-30s)', level=xbmc.LOGINFO)
        return (f'{url}|User-Agent={quote(_PREVIEW_UA)}'
                f'&Referer={quote(portal + "/")}')

    def _match_store(self, title_clean, callsign, search, label):
        """One local-IPTV store: SQL LIKE (store's own search_channels —
        cheap even on Telegram's 556k rows) with the guide title first, then
        the callsign; rows scored by the shared matcher, then — if still no
        hit — by callsign presence + guide-token overlap so
        'NBC 4 (WNBC) New York' picks 'NBC 4 (WNBC) NEW YORK' over a
        generic national feed. Returns (url, name, label) or None."""
        queries = [title_clean]
        if callsign and callsign.lower() != title_clean.lower():
            queries.append(callsign)
        # Guide-only suffixes defeat SQL substring search: 'KTLA-DT' matches
        # no row as '%KTLA-DT%' — fall back to the longest significant token
        # ('KTLA', len>=4, not a drop word, not the callsign already tried).
        token = None
        for w in re.split(r'[^A-Za-z0-9]+', title_clean or ''):
            lw = w.lower()
            if len(w) >= 4 and lw not in _NORM_DROP and lw != (callsign or '').lower():
                if token is None or len(w) > len(token):
                    token = w
        if token and token.lower() != title_clean.lower():
            queries.append(token)
        seen = set()
        for q in queries:
            if q in seen:
                continue
            seen.add(q)
            try:
                rows = search(q) or []
            except Exception as e:
                log(f'trailer_pip: {label} search error: {e}', level=xbmc.LOGWARNING)
                rows = []
            if not rows:
                continue
            sub = {}
            for r in rows:
                if isinstance(r, dict):
                    key = self._norm(r.get('name') or '')
                    if key:
                        sub.setdefault(key, r)
            if not sub:
                continue
            row = self._best_name_match(self._norm(title_clean), sub)
            if row is None:
                # Needle containment: guide 'KTLA-DT' (norm 'ktla', too short
                # for the shared matcher's guards) must reach compound store
                # keys — 'CW KTLA' / 'CA - KTLA HD' / 'US - KTLA 5 …'.
                # Needle = callsign from parens, else the search token.
                needle = (callsign or token or '').lower()
                if len(needle) >= 4:
                    cand = [k for k in sub if needle in k]
                    if cand:
                        toks = [w for w in re.split(r'[^a-z0-9]+', title_clean.lower())
                                if len(w) >= 3 and w not in _NORM_DROP]
                        # most guide tokens present in the key wins, then shortest
                        scored = [(sum(1 for t in toks if t in k), -len(k), k)
                                  for k in cand]
                        top = max(scored)
                        # token needles must actually fit the title when it has
                        # several significant words: 'DirecTV - MLB Extra
                        # Innings' must NOT grab a bare 'DirecTV' row (score 1
                        # of 5). A lone station token (KTLA-DT) or a parens
                        # callsign is specific enough at score 1.
                        big = [w for w in re.split(r'[^a-z0-9]+', title_clean.lower())
                               if len(w) >= 4 and w not in _NORM_DROP]
                        min_score = 1 if (callsign or len(big) <= 1) else 2
                        if top[0] >= min_score:
                            row = sub[top[2]]
            if row is None:
                continue
            url = self._xtream_url(row)
            if url:
                log(f'trailer_pip: {label} matched "{row.get("name")}"')
                return url, row.get('name') or title_clean, label
        return None

    def _match_local_stores(self, title, skip=None):
        """Local/OTA channels from the IPTV stores (MyIPTV, HomeIPTV,
        Telegram) — called when TimStreams AND 24/7 have nothing.
        skip = store label that just died — don't re-play it on retry.
        Returns (url, name, label) or None."""
        clean = strip_color_tags(title)
        callsign = self._callsign(clean)
        for mod_path, label in _LOCAL_STORES:
            if label == skip:
                continue
            try:
                mod = __import__(mod_path, fromlist=['search_channels'])
                search = getattr(mod, 'search_channels', None)
            except Exception:
                continue
            if not callable(search):
                continue
            hit = self._match_store(clean, callsign, search, label)
            if hit:
                return hit
        return None

    def _resolve_secondary(self, title, token=None, skip=None):
        """Secondary preview sources when TimStreams misses or fails:
        24/7 (Backdoor2) first, then local-IPTV stores (direct play URLs).
        skip = source label that just died ('24/7' / 'MyIPTV' / ...) —
        the death-retry never re-plays the dead source, it falls through
        to the next tier (dead 24/7 URL → straight to the stores).
        Returns (stream, display_name, label) or None."""
        if skip != '24/7':
            b2 = self.match_backdoor2(title)
            if b2:
                url, name = b2
                stream = self._resolve_jet(url, 'BckDr2', token)
                if token is not None and token != self._token:
                    return None
                if stream:
                    return stream, name, '24/7'
        local = self._match_local_stores(title, skip=skip)
        if local and (token is None or token == self._token):
            return local
        return None

    def stop(self):
        """Cancel pending schedule state AND kill the current preview
        (flags first, so the resulting stop callback is ignored).
        Use for explicit stops only (leaving the grid, disabled settings,
        worker failures) — scroll paths use _cancel_pending() instead so the
        GUI never blocks here on player teardown."""
        self._pinned = False
        self._token += 1
        self._pending = ''
        for attr in ('_timer', '_watch'):
            t = getattr(self, attr)
            if t is not None:
                try:
                    t.cancel()
                except Exception:
                    pass
                setattr(self, attr, None)
        return self._stop_current()

    def _stop_current(self):
        """Kill the CURRENT preview only — does NOT touch the schedule
        token/timers (workers call it on their own thread to swap previews).
        Player API only touched for our own stream.
        ORDER: refuse NEW proxy connections first (_stop_listening — kernel
        refusals need no Python, so the post-close Stats can't black-hole
        while player.stop() holds this interpreter's GIL), then player.stop()
        while established source sockets are still alive (the old full
        kill-first order made Android's player block on the dead source
        socket for tens of seconds per channel switch, log 2026-10-24 21:40),
        then full teardown. Bounded: listen-closed Stats are refused by the
        kernel instantly, so stop returns in Kodi's own ~4-5s Stat/OnStop
        cadence, with the 8s force-teardown as
        backstop."""
        was = self._on
        self._on = False                 # pre-ignore the stop callback
        self._for = ''
        self._fallback = None
        w = self._watch
        self._watch = None
        if w is not None:
            try:
                w.cancel()
            except Exception:
                pass
        if was and self._player is not None:
            # Close the xyz listen socket FIRST (client connections kept):
            self._stop_listening()
            # Pause JetProxy's 49778 listener BEFORE player.stop(): the
            # post-close CCurlFile::Stat then gets an instant kernel
            # ECONNREFUSED (rule C for the external proxy). The service
            # demonstrably stops serving for the WHOLE stop window even with
            # stop-armed probe logic — log 2026-10-29 18:04:34–18:05:14:
            # /playstop armed, CloseFile done in 70ms, yet zero handler
            # activity until HEADs were answered the moment player.stop()
            # returned (2×20s Stat timeouts = 40s swap stall, force-teardown
            # GIL-starved). Kernel refusal needs no Python → freeze-proof.
            if self._stream and str(self._stream).startswith(JETPROXY_PIP):
                log('trailer_pip: signaling jetproxy /pipstop (arm + pause '
                    '49778 listener) before player.stop()')
                self._jetproxy_signal('/pipstop')
            # player.stop() gets an 8s watchdog: with listen-closed Stats
            # kernel-refused, normal stops finish in Kodi's own ~4-5s
            # Stat/OnStop cadence — 3s false-fired on every swap (log
            # 2026-10-25 19:51/19:52/19:53); 8s only fires on a genuine
            # stall, forcing source teardown so OnStop can dispatch.
            force = threading.Timer(8.0, self._force_teardown)
            force.daemon = True
            force.start()
            try:
                self._player.stop()      # source sockets kept alive → fast clean stop
            except Exception:
                pass
            try:
                force.cancel()
            except Exception:
                pass
        # A handed-off fullscreen stream still owns its proxies (they live in
        # THIS interpreter): tearing them down here would kill the video the
        # user is watching. They self-clean later via the _poll_tick
        # stop-flag / proxy idle timers when that playback ends.
        if not (self._handed_off and xbmc.getCondVisibility('Player.HasVideo')):
            self._handed_off = False
            self._abort_proxies()          # only now tear the source down
        self._stream = None
        try:
            self.win.setProperty(PROP, '')
        except Exception:
            pass
        if self._muted:
            self._set_mute(False)
        return was

    def finished(self):
        if not self._on:
            # Handed-off fullscreen playback ended (Back stops video) →
            # its proxies are no longer serving anything: tear them down.
            if self._handed_off and not xbmc.getCondVisibility('Player.HasVideo'):
                if self._stream and str(self._stream).startswith(JETPROXY_PIP):
                    self._jetproxy_signal('/pipstop')  # Stats after Back kernel-refused
                self._handed_off = False
                self._abort_proxies()
            return
        # Capture/clear the death-retry BEFORE teardown so a dead stream
        # retries once through the other sources (stop() paths never reach
        # here — they pre-clear _on). One retry only: the fallback sets no
        # new one.
        fb = self._fallback
        self._fallback = None
        pending = self._pending   # newer armed schedule (cleared below)
        # Best-effort: arm JetProxy stopped-state so its post-close Stats
        # 404 instantly (natural stream death — no player.stop() from us).
        if self._stream and str(self._stream).startswith(JETPROXY_PIP):
            self._jetproxy_signal('/pipstop')
        w = self._watch
        self._watch = None
        if w is not None:
            try:
                w.cancel()
            except Exception:
                pass
        self._abort_proxies()   # FIRST: close proxy listen sockets (ISSUE_FREEZE)
        self._on = False
        self._for = ''
        self._pending = ''
        self._stream = None
        try:
            self.win.setProperty(PROP, '')
        except Exception:
            pass
        if self._muted:
            self._set_mute(False)
        if fb and fb.get('title'):
            # Retry unless a NEWER schedule owns the preview. Token match =
            # untouched since play. Token bumped with NOTHING armed =
            # separator-focus cancel_pending() (silent, no log) — the
            # preview is still current, so the retry must survive it
            # (this silent bump is what used to kill the retry with no
            # log at all). Token bumped + something armed = a new dwell
            # (channel or movie) will play it — don't race it.
            if fb.get('token') == self._token or not pending:
                log(f'trailer_pip: stream died (src={fb.get("src") or "?"}) '
                    '- retrying via other sources')
                fb['token'] = self._token   # re-stamp: worker re-checks it
                t = threading.Timer(0.5, self._fallback_worker, args=(fb,))
                t.daemon = True
                self._timer = t       # stop() cancels it if the user scrolls away
                t.start()
            else:
                log(f'trailer_pip: stream died but "{pending}" superseded it - no retry')

    def _force_teardown(self):
        """Timer watchdog: player.stop() has hung >8s (should never happen
        now that pre-stop listen closure kernel-refuses the post-close
        Stats). Kill the proxy sources NOW so OnStop can dispatch — the
        GUI/worker must never be stuck in stop(). Sources are dead either
        way: the user already asked for this preview to stop."""
        log('trailer_pip: player.stop() stalled 8s - force-aborting proxies')
        self._abort_proxies()

    @staticmethod
    def _stop_listening():
        """Refuse new proxy connections before player.stop() (kernel-level
        ECONNREFUSED for the post-close Stat — no Python/GIL involved).
        StreamProxy: abort() RSTs the player's tracked source sockets
        (immediate reset beats its 20s timeout — ISSUE_FREEZE design), then
        _finalize() closes its listen socket NOW because its 30s drain-503
        handlers cannot run while player.stop() freezes this interpreter's
        GIL. Targets EVERY StreamProxy instance in THIS interpreter (jet
        plays run in RunPlugin's own interpreter, so instances here are
        only trailer previews) — the active registry alone proved
        unreliable (it can be cleared by an earlier abort/finalize cycle
        while the instance keeps serving; a skipped finalize left its
        listen open and the post-close Stat black-holed for 20s, log
        19:34:41). xyz: listen socket only (client connections
        kept — the player is still closing its established source; the old
        full-kill first made Android block on the dead source)."""
        TrailerPIP._stream_teardown_all()
        try:
            from jetextractors.util.xyz_proxy import _stop_xyz_listening
            _stop_xyz_listening()
        except Exception:
            pass

    @staticmethod
    def _stream_teardown_all():
        """Abort + finalize EVERY StreamProxy instance in THIS interpreter
        (jet plays run in RunPlugin's own interpreter, so instances here are
        only trailer previews). abort(): RST tracked source sockets + 503
        flag; _finalize(): closes the listen socket NOW — its 30s drain-503
        handlers cannot run while player.stop() freezes this interpreter's
        GIL, and a listen left open black-holes the post-close Stat for 20s.
        Each step is individually guarded so one failure can't skip the
        rest, and we never depend on the active registry (it can be stale —
        log 2026-10-25 19:34:41)."""
        try:
            from jetextractors.util import proxy_server as _ps
            with _ps._proxy_lock:
                proxies = list(_ps._proxy_instances.values())
            for p in proxies:
                try:
                    p.abort()
                except Exception:
                    pass
                try:
                    p._finalize()
                except Exception:
                    pass
        except Exception:
            pass

    @staticmethod
    def _abort_proxies():
        """Callback-safe proxy teardown: preview streams play through the
        XYZ/Stream proxies registered in THIS (GUI) interpreter; closing
        their listen sockets at stop gives Kodi's post-close Stat an instant
        ECONNREFUSED instead of a 20s freeze."""
        TrailerPIP._stream_teardown_all()
        try:
            from jetextractors.util.xyz_proxy import _shutdown_xyz_proxy
            _shutdown_xyz_proxy()
        except Exception:
            pass

    def av_started(self):
        if self._on:
            try:
                self.win.setProperty(PROP, 'true')
            except Exception:
                pass

    # -------------------------------------------------------------- worker

    def _worker(self, token, tid, media, title):
        try:
            if token != self._token:
                return
            from resources.lib.plugins.tmdb_plugin import TMDB_API
            detail = TMDB_API().get(f'{media}/{tid}', paginated=False, full_meta=True)
            key = self._pick_trailer(detail if isinstance(detail, dict) else None)
            if token != self._token:
                return
            if not key:
                self.stop()              # no trailer: end the stale preview
                return
            stream = self._resolve(key, token)
            if token != self._token:
                return
            if not stream:
                self.stop()
                return
            if xbmc.getCondVisibility('Player.HasMedia') and not self._on:
                self.stop()              # real playback started meanwhile
                return
            if self._on:
                # Swap on THIS worker thread (deferral): the old trailer kept
                # playing through scrolling; bounded stop, GUI unaffected.
                self._stop_current()
            self._start_play(stream, title, tid, token)
        except Exception as e:
            log(f'trailer_pip worker error: {e}', level=xbmc.LOGERROR)
            self.stop()

    def _channel_worker(self, token, title):
        try:
            if token != self._token:
                return
            # Dwell reached: tear the OLD preview down FIRST, on this worker
            # thread (scroll path never blocks), THEN resolve. ORDER MATTERS:
            # xyz/StreamProxy are per-interpreter singletons — resolving
            # first registers the NEW stream's proxy, and this teardown then
            # kills it → every second channel failed with 'Couldn't connect
            # to server(7)' (log 2026-10-25 19:34/19:40).
            if self._on:
                self._stop_current()
            clean = strip_color_tags(title)
            had_match = False
            stream = None
            used_name = ''
            src = ''
            hit = self.match_timstreams(title)
            if hit and token == self._token:
                had_match = True
                url, ts_name = hit
                stream = self._resolve_live(url, token)
                used_name = ts_name
                if stream:
                    src = 'TimStreams'
                if not stream:
                    log(f'trailer_pip: TimStreams resolve failed for "{clean}" - trying 24/7/IPTV')
            # TimStreams missed or failed → 24/7 (Backdoor2), then the
            # local-IPTV stores (MyIPTV/HomeIPTV/Telegram — OTA channels
            # like 'NBC 4 (WNBC) New York').
            if not stream and token == self._token:
                sec = self._resolve_secondary(title, token)
                if sec:
                    had_match = True
                    stream, s_name, s_label = sec
                    used_name = s_name
                    if stream:
                        src = s_label
                        log(f'trailer_pip: using {s_label} fallback for "{clean}"')
            if token != self._token:
                return                    # superseded: a newer schedule owns
            if not stream:
                if not had_match:
                    log(f'trailer_pip: no TimStreams/24/7/IPTV match for "{clean}"')
                    if self._pinned:
                        if not self.ts_db_loaded():
                            xbmcgui.Dialog().notification(
                                'Channel Preview',
                                'TimStreams data not loaded — open TimStreams Channels once',
                                xbmcgui.NOTIFICATION_WARNING, 4500)
                        else:
                            xbmcgui.Dialog().notification(
                                'Channel Preview',
                                f'No preview source (TimStreams/24/7/IPTV) for {clean}',
                                xbmcgui.NOTIFICATION_WARNING, 3500)
                elif self._pinned:
                    xbmcgui.Dialog().notification(
                        'Channel Preview', 'Could not resolve channel stream',
                        xbmcgui.NOTIFICATION_WARNING, 3500)
                self.stop()               # full cleanup (also drops any proxy
                return                    # a failed resolve registered)
            if xbmc.getCondVisibility('Player.HasMedia') and not self._on:
                self.stop()
                return
            # Arm a one-shot death-retry for EVERY channel stream (TS or
            # secondary): when it dies, finished() retries once through
            # _resolve_secondary with skip=src so the dead source is never
            # re-picked (dead 24/7 URL → straight to the IPTV stores).
            self._fallback = {'token': token, 'title': title, 'src': src}
            self._start_play(stream, clean or used_name, used_name, token)
        except Exception as e:
            log(f'trailer_pip channel worker error: {e}', level=xbmc.LOGERROR)
            self.stop()

    def _fallback_worker(self, fb):
        """Retry a dead channel preview through the secondary sources,
        SKIPPING the source that just died (fb['src'] — e.g. a dead 24/7
        URL falls straight through to the local-IPTV stores). One shot:
        _fallback is cleared before this runs, so a dead retry just closes.
        """
        try:
            if fb.get('token') != self._token:
                return
            title = fb.get('title', '')
            sec = self._resolve_secondary(title, fb.get('token'),
                                          skip=fb.get('src'))
            if not sec or fb.get('token') != self._token:
                log(f'trailer_pip: no secondary source (24/7/IPTV) for "{strip_color_tags(title)}"',
                    level=xbmc.LOGWARNING)
                if self._pinned:
                    xbmcgui.Dialog().notification(
                        'Channel Preview', 'Preview fallback could not resolve',
                        xbmcgui.NOTIFICATION_WARNING, 3500)
                return
            stream, s_name, s_label = sec
            if xbmc.getCondVisibility('Player.HasMedia') and not self._on:
                return
            log(f'trailer_pip: retrying preview via {s_label} for "{strip_color_tags(title)}"')
            self._start_play(stream, strip_color_tags(title) or s_name, s_name,
                             fb.get('token'))
        except Exception as e:
            log(f'trailer_pip secondary fallback error: {e}', level=xbmc.LOGERROR)

    def _start_play(self, stream, label, for_id, token):
        if token != self._token:
            return                       # superseded between resolve and play
        if self._player is None:
            self._player = _PipPlayer(self)
        try:
            if xbmcaddon.Addon(ADDON_ID).getSetting('pip_trailers_mute') == 'true':
                self._set_mute(True)
        except Exception:
            pass
        self._on = True
        self._for = for_id
        self._stream = stream              # stored for fullscreen handoff
        self._label = label
        self._handed_off = False            # a fresh preview owns state again
        self.win.setProperty(PROP, 'true')   # window BEFORE first frame
        li = xbmcgui.ListItem(label=label)
        log(f'trailer_pip: windowed play "{label}"')
        if stream.startswith(JETPROXY_PIP):
            # Grant JetProxy's post-stop-probe filter a startup grace window
            # (cross-interpreter state — /playstart on the control port;
            # also clears any stopped_ts from a previous /pipstop). Listener
            # itself is already up: _jetproxy_up GET /pipopen before play.
            self._jetproxy_signal('/playstart')
        self._player.play(stream, li, True)
        w = threading.Timer(WATCHDOG, self._watchdog, args=(token,))
        w.daemon = True
        self._watch = w
        w.start()

    def _watchdog(self, token):
        try:
            if token == self._token and self._on and not xbmc.getCondVisibility('Player.HasMedia'):
                log('trailer_pip: stream never started - hiding window')
                self.finished()
        except Exception:
            pass

    # ------------------------------------------------------------ internals

    @staticmethod
    def _pick_trailer(detail):
        videos = ((detail or {}).get('videos') or {}).get('results') or []
        first_en = first = None
        for v in videos:
            if v.get('site') != 'YouTube' or not v.get('key'):
                continue
            if v.get('type') not in ('Trailer', 'Teaser'):
                continue
            en = str(v.get('language', '')).startswith('en')
            if v.get('official') and en:
                return v.get('key')
            if en and first_en is None:
                first_en = v.get('key')
            if first is None:
                first = v.get('key')
        return first_en or first

    def _resolve(self, key, token=None):
        """Direct stream via YouTube's InnerTube ANDROID client — works on
        this Kodi's Python 3.8, where every yt-dlp release past 2024.12
        refuses to run (3.9+ required) and old ones fail all clients.
        Falls back to plugin.video.youtube when installed."""
        stream = self._innertube(key)
        if token is not None and token != self._token:
            return None
        if stream:
            log('trailer_pip: resolved via innertube android client')
            return stream
        if xbmc.getCondVisibility('System.HasAddon(plugin.video.youtube)'):
            return f'plugin://plugin.video.youtube/play/?video_id={key}'
        log('trailer_pip: no stream resolved (innertube failed, plugin.video.youtube not installed)',
            level=xbmc.LOGWARNING)
        return None

    @staticmethod
    def _innertube(key):
        import json
        payload = json.dumps({
            'context': {'client': {
                'clientName': 'ANDROID', 'clientVersion': '20.10.38',
                'androidSdkVersion': 30, 'androidRelease': '11',
                'hl': 'en', 'gl': 'US'}},
            'videoId': key, 'contentCheckOk': True, 'racyCheckOk': True,
        })
        headers = {
            'Content-Type': 'application/json',
            'User-Agent': 'com.google.android.youtube/20.10.38 (Linux; U; Android 11) en_US',
        }
        for url in (
            'https://www.youtube.com/youtubei/v1/player?key=AIzaSyA8eiZmM1FaDVjRy-df2KTyQ_vz_yYM39w',
            'https://www.youtube.com/youtubei/v1/player',
        ):
            try:
                r = requests.post(url, data=payload, headers=headers, timeout=10)
                if r.status_code != 200:
                    continue
                sd = (r.json() or {}).get('streamingData') or {}
                best, best_h = None, -1
                for f in sd.get('formats') or []:
                    u = f.get('url')
                    if not u:
                        continue
                    h = f.get('height') or 0
                    if h > best_h:
                        best, best_h = u, h
                if best or sd.get('hlsManifestUrl'):
                    stream = best or sd.get('hlsManifestUrl')
                    return stream + '|User-Agent=' + headers['User-Agent']
            except Exception as e:
                log(f'trailer_pip innertube error: {e}', level=xbmc.LOGWARNING)
        return None

    # -------------------------------------------------------- live channels

    @staticmethod
    def _norm(s):
        """Lowercase alnum, alias-expanded (_NAME_ALIASES — e.g. SkySp ->
        Sky Sports), quality/region words (HD/USA/...) dropped on BOTH sides
        so 'ESPN HD' == 'ESPN USA' == 'ESPN'. Falls back to raw norm when
        every word was dropped."""
        low = (s or '').lower()
        for alias, expansion in _NAME_ALIASES.items():
            pat = r'\b' + r'\s+'.join(re.escape(w) for w in alias.split()) + r'\b'
            low = re.sub(pat, expansion, low)
        words = re.sub(r'[^a-z0-9]+', ' ', low).split()
        keep = [w for w in words if w not in _NORM_DROP]
        return ''.join(keep) or re.sub(r'[^a-z0-9]', '', (s or '').lower())

    def _ts_map(self):
        """norm name -> (stream_url, db name), cached; reloads on DB change.
        Cross-platform (Windows + Android): plain sqlite3.connect on the
        real path — the old hand-built 'file:...' URI was Windows-only and
        resolves POSIX paths (file://storage/...) as an invalid sqlite
        authority on Android."""
        path = ''
        mtime = 0
        try:
            path = xbmcvfs.translatePath(TS_DB)
        except Exception as e:
            log(f'trailer_pip: translatePath failed: {e}', level=xbmc.LOGWARNING)
        try:
            if path:
                mtime = os.path.getmtime(path)
        except Exception:
            mtime = 0
        if self._ts is not None and mtime and mtime == self._ts_mtime:
            return self._ts
        m = {}
        if path and os.path.exists(path):
            try:
                conn = sqlite3.connect(path, timeout=2.0)
                try:
                    cur = conn.cursor()
                    cur.execute('SELECT name, stream_url FROM channels')
                    for name, url in cur.fetchall():
                        if name and url:
                            m[self._norm(name)] = (url, name)
                finally:
                    conn.close()
                log(f'trailer_pip: loaded {len(m)} TimStreams channels')
                self._ts_missing_logged = False
            except Exception as e:
                log(f'trailer_pip: timstreams db error ({path}): {e}', level=xbmc.LOGWARNING)
        else:
            if not self._ts_missing_logged:
                self._ts_missing_logged = True
                log(f'trailer_pip: timstreams_data.db not found at "{path}" — '
                    'open Jetextractors > TimStreams Channels once to populate it',
                    level=xbmc.LOGWARNING)
        self._ts = m
        self._ts_mtime = mtime
        return m

    def ts_db_loaded(self):
        """True once the TimStreams DB has been read and has channels."""
        return bool(self._ts_map())

    def _b2_map(self):
        """norm name -> (embed_url, db name) from the 24/7 (Backdoor2) DB,
        cached; reloads on DB change. Same cross-platform plain-sqlite
        approach as _ts_map."""
        path = ''
        mtime = 0
        try:
            path = xbmcvfs.translatePath(B2_DB)
        except Exception as e:
            log(f'trailer_pip: translatePath(b2) failed: {e}', level=xbmc.LOGWARNING)
        try:
            if path:
                mtime = os.path.getmtime(path)
        except Exception:
            mtime = 0
        if self._b2 is not None and mtime and mtime == self._b2_mtime:
            return self._b2
        m = {}
        if path and os.path.exists(path):
            try:
                conn = sqlite3.connect(path, timeout=2.0)
                try:
                    cur = conn.cursor()
                    cur.execute('SELECT name, embed_url FROM channels')
                    for name, url in cur.fetchall():
                        if name and url:
                            m.setdefault(self._norm(name), (url, name))
                finally:
                    conn.close()
                log(f'trailer_pip: loaded {len(m)} 24/7 (Backdoor2) channels')
            except Exception as e:
                log(f'trailer_pip: backdoor2 db error ({path}): {e}', level=xbmc.LOGWARNING)
        self._b2 = m
        self._b2_mtime = mtime
        return m

    def _resolve_live(self, url, token=None):
        """TimStreams resolve (delegates to _resolve_jet)."""
        return self._resolve_jet(url, 'TimStreams', token)

    def _resolve_jet(self, url, extractor_name, token=None):
        """Direct m3u8/mp4 play as-is; embeds via the named jet extractor +
        ResolveURL (same chain the jet play path uses, minus the link
        dialog — one silent stream for the preview)."""
        low = url.lower()
        if '.m3u8' in low or '.mp4' in low:
            return url
        try:
            import resolveurl
            from jetextractors import extractor as jet_extractor
            from jetextractors.models import JetLink
            jl = JetLink.from_dict({'address': url, 'name': 'Preview',
                                    'resolveurl': True, 'extractor': extractor_name})
            e = None
            try:
                e = jet_extractor.get_extractor(extractor_name)
            except Exception:
                e = None
            if e is None:
                try:
                    e = jet_extractor.find_extractor(jl)
                except Exception:
                    e = None
            if e is not None:
                jl = e.get_link(jl)
                if token is not None and token != self._token:
                    return None
            if jl is None:
                return None
            if getattr(jl, 'resolveurl', False):
                hmf = resolveurl.HostedMediaFile(jl.address)
                if hmf:
                    return hmf.resolve()
                return jl.address
            return jl.address
        except Exception as e:
            log(f'trailer_pip resolve error ({extractor_name}): {e}', level=xbmc.LOGWARNING)
            return None

    def _set_mute(self, mute):
        try:
            if mute:
                cur = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Application.GetProperties","params":{"properties":["muted"]},"id":1}')
                if '"muted":true' in cur.replace(' ', ''):
                    return               # viewer already muted: leave alone
                self._muted = True
            else:
                self._muted = False
            xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Application.SetMute","params":{"mute":%s},"id":1}' % ('true' if mute else 'false'))
        except Exception:
            pass
