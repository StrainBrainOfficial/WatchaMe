import xbmcgui
import xbmc
import xbmcaddon
import threading
import time

ADDON_ID = "plugin.video.madtitansports"
ADDON_PATH = xbmcaddon.Addon(id=ADDON_ID).getAddonInfo('path')

COLOR_BAR_ANIMATION = [
    "FF0066FF",  # blue
    "FF00AAFF",  # light blue
    "FF00CCFF",  # cyan
    "FF00FFAA",  # teal
    "FF00FF66",  # green
    "FF88FF00",  # lime
    "FFCCFF00",  # yellow
    "FFFFAA00",  # orange
    "FFFF3300",  # red
    "FFFF0066",  # pink
    "FFCC00FF",  # magenta
    "FF9933FF",  # purple
    "FF6666FF",  # lavender
]

BAR_ANIMATION_INTERVAL_MS = 300
AUTO_CLOSE_POLL_MS = 500
AUTO_CLOSE_TIMEOUT_S = 25
PLAYBACK_CONFIRM_S = 4

_active_overlay = None
_overlay_lock = threading.Lock()

_busy_dismiss_timer = None
_busy_dismiss_running = False
_busy_dismiss_stop = threading.Event()


def _dismiss_busy():
    try:
        xbmc.executebuiltin('Dialog.Close(busydialog)')
    except Exception:
        pass


def _busy_dismiss_tick():
    global _busy_dismiss_running
    if _busy_dismiss_stop.is_set():
        _busy_dismiss_running = False
        return
    _dismiss_busy()
    t = threading.Timer(0.5, _busy_dismiss_tick)
    t.daemon = True
    t.start()


def start_busy_dismiss():
    """Idempotent: at most ONE dismiss chain exists per interpreter.
    (Previous build started a new chain per overlay show and never stopped
    it on auto-close — dozens of zombie 0.5s chains accumulated per
    session, spawning threads forever and blocking invoker teardown with
    'waiting on thread' spam for minutes after the GUI closed.)"""
    global _busy_dismiss_running
    _busy_dismiss_stop.clear()
    if _busy_dismiss_running:
        return
    _busy_dismiss_running = True
    _dismiss_busy()
    _busy_dismiss_tick()


def stop_busy_dismiss():
    _busy_dismiss_stop.set()


class LoadingOverlay(xbmcgui.WindowXMLDialog):
    def __init__(self, xml_file, addon_path):
        xbmcgui.WindowXMLDialog.__init__(self, xml_file, addon_path, "Default", "720p")
        self._bar_index = 0
        self._animation_timer = None
        self._auto_close_timer = None
        self._closing = False
        self._start_time = 0
        self._playback_detected_time = 0

    def onInit(self):
        try:
            self._start_time = time.time()
            self._start_animation()
            self._start_auto_close()
        except Exception as e:
            xbmc.log(f"[MadTitan] LoadingOverlay onInit error: {e}", level=xbmc.LOGERROR)

    def onAction(self, action):
        action_id = action.getId()
        if action_id in (xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK, 92):
            xbmc.Player().stop()
            self._close_overlay()

    def onClick(self, control_id):
        pass

    def onFocus(self, control_id):
        pass

    def _start_animation(self):
        self._bar_index = 0
        self._animation_tick()

    def _animation_tick(self):
        if self._closing:
            return
        try:
            color = COLOR_BAR_ANIMATION[self._bar_index % len(COLOR_BAR_ANIMATION)]
            self.getControl(5100).setColorDiffuse(color)
            self._bar_index += 1
        except Exception:
            pass
        self._animation_timer = threading.Timer(BAR_ANIMATION_INTERVAL_MS / 1000.0, self._animation_tick)
        self._animation_timer.daemon = True
        self._animation_timer.start()

    def _start_auto_close(self):
        self._auto_close_tick()

    def _auto_close_tick(self):
        if self._closing:
            return
        try:
            elapsed = time.time() - self._start_time
            if elapsed > AUTO_CLOSE_TIMEOUT_S:
                xbmc.log("[MadTitan] LoadingOverlay: timeout, closing overlay", level=xbmc.LOGDEBUG)
                self._close_overlay()
                return
            # SAFETY: this runs on a threading.Timer thread. Never call
            # xbmc.Player() APIs here — isPlaying() from a background thread
            # can deadlock against CloseFile on the main thread and froze all
            # of Kodi for ~40s at player stop. getCondVisibility is a
            # lightweight state query with no Player-object registration.
            if xbmc.getCondVisibility('Player.HasVideo'):
                if self._playback_detected_time == 0:
                    self._playback_detected_time = time.time()
                    xbmc.log("[MadTitan] LoadingOverlay: playback detected, closing overlay", level=xbmc.LOGDEBUG)
                since_detect = time.time() - self._playback_detected_time
                if since_detect >= 2.0:
                    xbmc.log(f"[MadTitan] LoadingOverlay: playback confirmed, closing overlay", level=xbmc.LOGDEBUG)
                    self._close_overlay()
                    return
        except Exception:
            pass
        self._auto_close_timer = threading.Timer(AUTO_CLOSE_POLL_MS / 1000.0, self._auto_close_tick)
        self._auto_close_timer.daemon = True
        self._auto_close_timer.start()

    def _stop_timers(self):
        if self._animation_timer:
            self._animation_timer.cancel()
            self._animation_timer = None
        if self._auto_close_timer:
            self._auto_close_timer.cancel()
            self._auto_close_timer = None

    def _close_overlay(self):
        if self._closing:
            return
        self._closing = True
        self._stop_timers()
        # LEAK FIX: the auto-close path (playback detected / timeout / Back)
        # never ran module close() — the busy-dismiss chain survived the
        # overlay forever. Stop it here so every close path is covered.
        stop_busy_dismiss()
        try:
            self.close()
        except Exception:
            pass
        global _active_overlay
        with _overlay_lock:
            _active_overlay = None


def show():
    global _active_overlay
    with _overlay_lock:
        if _active_overlay is not None:
            return
        try:
            start_busy_dismiss()
            _active_overlay = LoadingOverlay("loading_overlay.xml", ADDON_PATH)
            _active_overlay.show()
        except Exception as e:
            xbmc.log(f"[MadTitan] LoadingOverlay show error: {e}", level=xbmc.LOGERROR)
            _active_overlay = None


def close():
    global _active_overlay
    with _overlay_lock:
        if _active_overlay is not None:
            _active_overlay._close_overlay()
    stop_busy_dismiss()
