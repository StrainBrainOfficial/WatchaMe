"""IPTV play path - click-time resolution of channel payloads (D1).

Payload shapes (see iptv_m3u): {"ch": id} looks up the current programme;
click_target() then picks the action: direct url / real magnet via
ResolveURL / - when there is no REAL magnet (placeholder btih:aaaa or
none) - a MicroJen scraper SEARCH on the slot title, so no bogus magnet
is ever sent to the debrid. Playlist refs stay stable; links can't expire.

Runs in both contexts: GUI route iptv_play (gui_iptv mixin) and the
plugin route /iptv_play/<payload> - the plugin:// URL form carried
inside M3U playlists.
"""
import json
import os
import threading
import time

import xbmc
import xbmcaddon
import xbmcgui

from resources.lib import iptv_m3u
from resources.lib import loading_overlay
from resources.lib.plugin import Plugin
from resources.lib.playback_monitor import track
from resources.lib.tool import log

try:
    from urllib.parse import unquote
except ImportError:  # pragma: no cover
    from urllib import unquote

_GUIDE_LOADED = False

# --- scrape bumper (silent search animation in the skin videowindow) ------
# resources/media/scrape_bumper.mp4 (60s seamless loop, no audio) plays
# windowed under the skin control gated on BUMPER_PROP while MicroJen
# scrapes. The REAL stream replaces it (single Kodi player) the moment a
# link is found; hide() clears the property and stops the bumper ONLY if
# it is still the active video (JSON-RPC file identity — never stops the
# real stream, never a Player API, safe on any thread/context).
BUMPER_PROP = 'madtitan_scrape_on'
BUMPER_FILE = 'scrape_bumper.mp4'


def _bumper_path():
    try:
        p = os.path.join(
            xbmcaddon.Addon('plugin.video.madtitansports').getAddonInfo('path'),
            'resources', 'media', BUMPER_FILE)
        return p if os.path.exists(p) else ''
    except Exception:
        return ''


def _video_item_file(playerid):
    """JSON-RPC: current video item's file ('' on any failure)."""
    try:
        r = json.loads(xbmc.executeJSONRPC(json.dumps({
            'jsonrpc': '2.0', 'id': 1, 'method': 'Player.GetItem',
            'params': {'playerid': playerid, 'properties': ['file']}})))
        return (((r.get('result') or {}).get('item') or {}).get('file') or '')
    except Exception:
        return ''


def scrape_bumper_show():
    """Start the search animation (windowed, silent). Returns True when
    it is actually playing (caller can then hide the scraping dialog —
    the animation IS the feedback). Skips when a real video is already
    playing (never hijack it), the setting is off, or the file is missing."""
    try:
        if xbmcaddon.Addon('plugin.video.madtitansports').getSetting(
                'scrape_bumper') != 'true':
            return False
    except Exception:
        return False
    if xbmc.getCondVisibility('Player.HasVideo'):
        return False                 # something real is playing: don't replace it
    path = _bumper_path()
    if not path:
        return False
    try:
        xbmcgui.Window(13000).setProperty(BUMPER_PROP, 'true')  # before frame 1
        li = xbmcgui.ListItem(label='Searching for links...')
        pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        pl.clear()
        for _ in range(10):          # 10 x 60s = 10 min: covers any scrape/picker
            pl.add(path, li)
        xbmc.Player().play(pl, li, True)   # windowed -> skin videowindow
        log('iptv_play: scrape bumper shown')
        return True
    except Exception as e:
        log(f'iptv_play: scrape bumper error: {e}', level=xbmc.LOGWARNING)
        try:
            xbmcgui.Window(13000).clearProperty(BUMPER_PROP)
        except Exception:
            pass
        return False


def scrape_bumper_hide(settle=False):
    """End the search animation. Clears the property always; stops the
    player ONLY when the active video IS the bumper (on success the real
    stream is replacing/has replaced it — never stop that). settle=True
    polls ~2s for the file to change first: play_video() returns right
    AFTER its fire-and-forget Player().play(), so the real stream may
    still be opening while the player still reports the bumper. Also
    empties the bumper playlist so a later EOF can't resume it."""
    try:
        xbmcgui.Window(13000).clearProperty(BUMPER_PROP)
    except Exception:
        pass

    def _bumper_pid():
        try:
            r = json.loads(xbmc.executeJSONRPC(
                '{"jsonrpc":"2.0","id":1,'
                '"method":"Player.GetActivePlayers"}'))
            for p in r.get('result') or []:
                if p.get('type') != 'video':
                    continue
                pid = p.get('playerid', 1)
                if BUMPER_FILE in _video_item_file(pid):
                    return pid
                return None            # a real video owns the player
        except Exception:
            return None

    try:
        if settle:
            for _ in range(20):        # ~2s: wait for the real file to show up
                if _bumper_pid() is None:
                    break              # real stream took over (or nothing plays)
                time.sleep(0.1)
        pid = _bumper_pid()
        if pid is not None:
            xbmc.executeJSONRPC(json.dumps({
                'jsonrpc': '2.0', 'id': 1, 'method': 'Player.Stop',
                'params': {'playerid': pid}}))
            log('iptv_play: scrape bumper stopped')
        xbmc.PlayList(xbmc.PLAYLIST_VIDEO).clear()
    except Exception as e:
        log(f'iptv_play: scrape bumper hide error: {e}',
            level=xbmc.LOGWARNING)

# Auto-advance session (module-level; GUI-interpreter play path).
# gen increments per new play so stale watchers exit silently (same
# pattern as gui_main._spelunkr_gen / _iptv_gen). A session is armed
# ONLY for schedule-driven plays (ch payload + prog): when that
# playback reaches natural EOF we jump to the next slot; a user stop
# leaves active False via the pos check below - no surprise plays.
_SESSION = {'gen': 0, 'active': False, 'ch': '', 'slot_start': None}


def arm_session(ch_id, slot_start):
    """Arm auto-advance for a schedule-driven play. Returns the gen the
    watcher for this play must carry (stale gens exit immediately)."""
    _SESSION['gen'] += 1
    _SESSION['active'] = True
    _SESSION['ch'] = ch_id or ''
    _SESSION['slot_start'] = slot_start
    return _SESSION['gen']


def disarm_session(gen=None):
    if gen is None or _SESSION.get('gen') == gen:
        _SESSION['active'] = False


def _fmt_clock(secs):
    secs = max(0, int(secs))
    hh, rem = divmod(secs, 3600)
    mm, ss = divmod(rem, 60)
    return f'{hh}:{mm:02d}:{ss:02d}' if hh else f'{mm}:{ss:02d}'


def _watch_until_eod(gen, poll=1.0, grace_s=6.0):
    """End-of-data watcher for one armed session (daemon thread).

    JSON-RPC only - no xbmc.Player APIs (GIL rule, same as the seek
    worker). Tracks the playing video's position/total; decides:
      natural EOF (pos >= total-10)  -> return True (advance)
      user stop / no video / stale    -> False (stay on menu)
    Fast-forwarding to the end and letting it finish IS a natural EOF -
    the check is purely position-based. grace_s bridges the brief
    no-player gap Kodi shows between CloseFile and the window restoring;
    a user stop also has no video, so the decision is made on the LAST
    SEEN position at the gap.
    """
    last_pos, last_total = -1.0, 0.0
    owned_file = None   # our stream's file path, captured on first sight
    gap_since = None
    saw_video = False
    read_fails = 0
    started_at = time.time()
    deadline = started_at + 86400.0

    def _players():
        r = json.loads(xbmc.executeJSONRPC(
            '{"jsonrpc":"2.0","id":1,'
            '"method":"Player.GetActivePlayers"}'))
        return r.get('result') or []

    def _pos_total(pid):
        # ONLY time/totaltime here. Requesting 'file' from
        # Player.GetProperties makes Kodi reject the WHOLE call (file is
        # a Player.GetItem property) -> pos/total read as 0 and a
        # natural EOF gets misjudged as a user stop (2026-10-31 log:
        # 'pos=0:00/0:00 -> stopped' right after 'eof reading from
        # demuxer'). A missing result returns None so the caller keeps
        # the last GOOD values instead of zeroing them.
        r = json.loads(xbmc.executeJSONRPC(json.dumps({
            'jsonrpc': '2.0', 'id': 1, 'method': 'Player.GetProperties',
            'params': {'playerid': pid,
                       'properties': ['time', 'totaltime']}})))
        res = r.get('result')
        if res is None:
            return None

        def _secs(t):
            return (t.get('hours', 0) * 3600 + t.get('minutes', 0) * 60
                    + t.get('seconds', 0) + t.get('milliseconds', 0) / 1000.0)
        return _secs(res.get('time') or {}), _secs(res.get('totaltime') or {})

    def _file(pid):
        r = json.loads(xbmc.executeJSONRPC(json.dumps({
            'jsonrpc': '2.0', 'id': 1, 'method': 'Player.GetItem',
            'params': {'playerid': pid, 'properties': ['file']}})))
        return (((r.get('result') or {}).get('item') or {})
                .get('file') or '')

    try:
        while time.time() < deadline:
            if _SESSION.get('gen') != gen or not _SESSION.get('active'):
                return False
            ps = [p for p in _players() if p.get('type') == 'video']
            if ps:
                pid = ps[0].get('playerid', 1)
                got = _pos_total(pid)
                if got is None:
                    read_fails += 1
                    if read_fails == 5:
                        log('iptv_play EOD: position reads failing '
                            '(JSON-RPC error) - keeping last good value',
                            level=xbmc.LOGWARNING)
                else:
                    read_fails = 0
                    last_pos, last_total = got
                # identity guard: once OUR file is known, any other file
                # (user stopped + started something else, PiP trailer...)
                # ends the session - no advance for someone else's video
                f = _file(pid)
                if f:
                    if owned_file is None:
                        owned_file = f
                    elif f != owned_file:
                        log('iptv_play EOD: different playback detected - '
                            'disarming session', level=xbmc.LOGINFO)
                        return False
                saw_video = True
                gap_since = None
                time.sleep(poll)
                continue
            if not saw_video:
                # playback hasn't started yet (scrape/resolve still going);
                # give up after 10 min - failed play, nothing to advance from
                if time.time() - started_at > 600:
                    log('iptv_play EOD: playback never started - '
                        'disarming session', level=xbmc.LOGWARNING)
                    return False
                time.sleep(poll)
                continue
            if gap_since is None:
                gap_since = time.time()
                time.sleep(poll)
                continue
            # video gone: EOF or user stop? use the last seen position.
            if time.time() - gap_since < grace_s:
                time.sleep(poll)
                continue
            eof = (last_total > 0 and last_pos >= last_total - 10)
            log(f'iptv_play EOD: pos={_fmt_clock(last_pos)}/'
                f'{_fmt_clock(last_total)} -> '
                f'{"natural end, advancing" if eof else "stopped, no advance"}',
                level=xbmc.LOGINFO)
            return eof
    except Exception as e:
        log(f'iptv_play EOD watcher error: {e}', level=xbmc.LOGWARNING)
    return False


def _advance_worker(gen):
    """Runs off-thread after natural EOF: find the next slot, then play
    it through the SAME click decision (seek join included)."""
    try:
        if not _watch_until_eod(gen):
            disarm_session(gen)
            return
        if _SESSION.get('gen') != gen or not _SESSION.get('active'):
            return
        ch = _SESSION.get('ch') or ''
        after = _SESSION.get('slot_start')
        nxt = iptv_m3u.next_program(ch, after) if ch and after else None
        if not nxt:
            disarm_session(gen)
            xbmcgui.Dialog().notification(
                'IPTV', 'Schedule has no next programme',
                xbmcgui.NOTIFICATION_INFO, 4000)
            return
        nxt_title = nxt.get('title') or 'next programme'
        xbmcgui.Dialog().notification(
            'IPTV', f'Up next: {nxt_title}',
            xbmcgui.NOTIFICATION_INFO, 4000)
        log(f'iptv_play: advancing to "{nxt_title}" '
            f'({iptv_m3u.fmt_time(nxt["start"])})', level=xbmc.LOGINFO)
        # disarm BEFORE play: _play_decision re-arms for the new slot
        disarm_session(gen)
        data = {'ch': ch, '_prog': nxt}
        decision = iptv_m3u.click_target(data, nxt)
        _play_decision(decision, data)
    except Exception as e:
        log(f'iptv_play advance error: {e}', level=xbmc.LOGERROR)
        disarm_session(gen)


def seek_after_play(seek, url='', label='IPTV'):
    """Join the slot at its live offset - port of the PROVEN
    gui_main._spelunkr_seek routine (JSON-RPC only; no xbmc.Player APIs
    on this thread - GIL rule). Timing rule: wait until playback is
    CONFIRMED progressing (time >= 1s), seek ONCE, verify, single delayed
    retry - never rapid-fire. Kodi's Time schema rejects seconds>59, so
    h/m/s split is mandatory. If the seek never takes and we know the
    resolved url, restart WITHOUT the offset so playback doesn't stall."""
    if seek <= 5:
        return

    def worker():
        try:
            def _players():
                r = json.loads(xbmc.executeJSONRPC(
                    '{"jsonrpc":"2.0","id":1,'
                    '"method":"Player.GetActivePlayers"}'))
                return r.get('result') or []

            def _ptime(pid):
                r = json.loads(xbmc.executeJSONRPC(json.dumps({
                    'jsonrpc': '2.0', 'id': 1, 'method': 'Player.GetProperties',
                    'params': {'playerid': pid, 'properties': ['time']}})))
                t = (r.get('result') or {}).get('time') or {}
                return (t.get('hours', 0) * 3600 + t.get('minutes', 0) * 60
                        + t.get('seconds', 0))

            def _do_seek(pid):
                total = max(0, int(seek))
                hh, rem = divmod(total, 3600)
                mm, ss = divmod(rem, 60)
                xbmc.executeJSONRPC(json.dumps({
                    'jsonrpc': '2.0', 'id': 1, 'method': 'Player.Seek',
                    'params': {'playerid': pid,
                               'value': {'time': {'hours': hh, 'minutes': mm,
                                                  'seconds': ss,
                                                  'milliseconds': 0}}}}))

            # 1) wait until playback is actually progressing
            pid = None
            cur = -1
            for _ in range(60):                 # up to ~15s
                ps = [p for p in _players() if p.get('type') == 'video']
                if ps:
                    pid = ps[0].get('playerid', 1)
                    try:
                        cur = _ptime(pid)
                    except Exception:
                        cur = -1
                    if cur >= 1:
                        break
                time.sleep(0.25)
            if pid is None or cur < 1:
                return
            if abs(cur - seek) < 90:            # already at target
                return
            # 2) single seek, verify, one delayed retry
            _do_seek(pid)
            time.sleep(1.2)
            try:
                cur = _ptime(pid)
            except Exception:
                return
            if abs(cur - seek) < 90:
                return
            time.sleep(2.5)
            _do_seek(pid)
            # 3) recovery: if the player never reaches the target, restart
            #    WITHOUT the offset (moov-at-end files can resolve a
            #    mid-file seek to time 0 = eternal buffering otherwise).
            for _ in range(2):
                time.sleep(2.0)
                try:
                    ps = [p for p in _players() if p.get('type') == 'video']
                    if not ps:
                        return
                    cur = _ptime(ps[0].get('playerid', 1))
                except Exception:
                    return
                if abs(cur - seek) < 90:
                    return
            if url:
                log(f'{label}: seek never took - restarting stream '
                    'without offset', level=xbmc.LOGWARNING)
                xbmc.executeJSONRPC(json.dumps({
                    'jsonrpc': '2.0', 'id': 1, 'method': 'Player.Open',
                    'params': {'item': {'file': url}}}))
                xbmcgui.Dialog().notification(
                    label, 'Join unavailable - starting from the beginning',
                    xbmcgui.NOTIFICATION_INFO, 5000)
        except Exception as e:
            log(f'{label} seek error: {e}', level=xbmc.LOGWARNING)

    threading.Thread(target=worker, daemon=True).start()


def _ensure_program(data):
    """Current programme for a {"ch": ...} payload.

    In the GUI context the guide is already cached by _open_iptv. In a
    cold RunPlugin context (favorites / raw plugin:// URL) fetch the
    server config + EPG once so the magnet can still be found.
    """
    global _GUIDE_LOADED
    ch = data.get('ch') or ''
    if not ch:
        return None
    prog = iptv_m3u.current_program(ch)
    if prog:
        return prog
    if _GUIDE_LOADED:
        return None
    _GUIDE_LOADED = True
    try:
        cfg = iptv_m3u.load_server_config()
        epg_url = cfg.get('epg_url') or ''
        if epg_url:
            _, programmes = iptv_m3u.parse_xmltv(iptv_m3u.fetch_text(epg_url))
            iptv_m3u.set_epg(programmes)
        return iptv_m3u.current_program(ch)
    except Exception as e:
        log(f'iptv_play guide load error: {e}', level=xbmc.LOGWARNING)
        return None


def _play_magnet(magnet, title, art='', seek=0):
    """ResolveURL chain - identical pattern to plugins/sportvideo.py.
    Returns True if playback was started."""
    import resolveurl
    loading_overlay.show()
    try:
        if not resolveurl.HostedMediaFile(magnet).valid_url():
            loading_overlay.close()
            xbmcgui.Dialog().ok(
                'IPTV',
                'No debrid resolver accepted this magnet.\n'
                'Enable torrent/magnet support in ResolveURL (Real-Debrid, '
                'AllDebrid, Premiumize, TorBox, etc.).',
            )
            return False
        url = resolveurl.HostedMediaFile(magnet).resolve()
    except Exception as e:
        loading_overlay.close()
        log(f'iptv_play resolve error: {e}', level=xbmc.LOGERROR)
        xbmcgui.Dialog().ok('IPTV', f'Resolve failed: {e}')
        return False
    if not url:
        loading_overlay.close()
        xbmcgui.Dialog().ok(
            'IPTV',
            'Debrid service did not return a stream.\n'
            'Enable torrent/magnet support in your ResolveURL debrid '
            'settings, and make sure the torrent is cached on your account.',
        )
        return False
    track('play', channel_name=title, url=url, source='iptv')
    liz = xbmcgui.ListItem(title)
    liz.setInfo('video', {'title': title})
    if art:
        liz.setArt({'thumb': art, 'icon': art})
    liz.setProperty('IsPlayable', 'true')
    log(f"iptv_play: resolved URL via resolveurl for '{title}'",
        level=xbmc.LOGINFO)
    xbmc.Player().play(url, liz)
    if seek > 5:
        log(f'iptv_play: joining at +{seek}s (live slot offset)',
            level=xbmc.LOGINFO)
        seek_after_play(seek, url, label='IPTV')
    return True


def _play_direct(url, title, art='', seek=0):
    """Returns True (playback handed to Kodi)."""
    track('play', channel_name=title, url=url, source='iptv')
    liz = xbmcgui.ListItem(title)
    liz.setInfo('video', {'title': title})
    if art:
        liz.setArt({'thumb': art, 'icon': art})
    liz.setProperty('IsPlayable', 'true')
    loading_overlay.show()
    xbmc.Player().play(url, liz)
    if seek > 5:
        log(f'iptv_play: joining at +{seek}s (live slot offset)',
            level=xbmc.LOGINFO)
        seek_after_play(seek, url, label='IPTV')
    return True


def _search_microjen(spec, title, seek=0):
    """Scraper fallback: search MicroJen for the slot title instead of
    resolving any magnet (auto-pick best non-4K link per addon settings).
    item shape matches what microjen_scrapers.play_video() expects.
    Returns True if playback was started."""
    from resources.lib.plugins.microjen_scrapers import MicroJenScrapers
    item = {
        'title': spec['title'],
        'content': spec['content'],
        'year': spec.get('year', ''),
        'imdb_id': '',
        'tmdb_id': '',
        'link': 'search',
    }
    if spec['content'] == 'episode':
        item['tv_show_title'] = spec.get('show', '')
        item['season'] = spec.get('season', '')
        item['episode'] = spec.get('episode', '')
        item['premiered'] = ''
    log(f"iptv_play: MicroJen search for '{item['title']}' "
        f"({item['content']})", level=xbmc.LOGINFO)
    track('play', channel_name=item['title'], url='', source='iptv')
    # Bumper playing = quiet scrape: the animation replaces the scraping
    # dialog entirely (user sees no sources/links-found text). When the
    # bumper can't show (setting off/file missing/real video playing),
    # MicroJen keeps its normal progress dialog.
    bumper = scrape_bumper_show()
    try:
        ok = MicroJenScrapers().play_video(json.dumps(item), quiet=bumper)
    except Exception as e:
        log(f'iptv_play MicroJen search error: {e}', level=xbmc.LOGERROR)
        scrape_bumper_hide(settle=True)
        xbmcgui.Dialog().notification(
            'IPTV', 'Search failed', xbmcgui.NOTIFICATION_WARNING, 4000)
        return False
    # settle=True: play_video's Player().play is fire-and-forget — poll ~2s
    # for the real file to appear before deciding whether the bumper is
    # still the active video (also covers picker-cancel: returns True but
    # never played, so the bumper must be stopped).
    scrape_bumper_hide(settle=True)
    if not ok:
        xbmcgui.Dialog().notification(
            'IPTV', f'No links found for {item["title"]}',
            xbmcgui.NOTIFICATION_WARNING, 5000)
        return False
    if seek > 5:
        # MicroJen resolved internally - no url for restart recovery, but
        # the seek itself (JSON-RPC) doesn't need it.
        log(f'iptv_play: joining at +{seek}s (live slot offset)',
            level=xbmc.LOGINFO)
        seek_after_play(seek, '', label='IPTV')
    return True


def _play_decision(decision, data):
    """Execute a click_target decision. Schedule-driven magnet/search
    plays (ch payload + programme) arm the auto-advance session: when
    that playback reaches natural EOF the next slot plays automatically;
    a user stop disarms (no surprise play)."""
    action = decision.get('action')
    title = decision.get('title') or 'IPTV'
    seek = int(decision.get('seek') or 0)
    art = data.get('art') or ''
    ch = data.get('ch') or ''
    prog = data.get('_prog')  # stashed by play_payload for arming
    schedule_driven = bool(ch and prog is not None
                           and action in ('magnet', 'search'))
    gen = arm_session(ch, prog['start']) if schedule_driven else None

    if action == 'direct':
        ok = _play_direct(decision['url'], title, art, seek)
    elif action == 'magnet':
        ok = _play_magnet(decision['magnet'], title, art, seek)
    elif action == 'search':
        ok = _search_microjen(decision['spec'], title, seek)
    else:
        ok = False
        xbmcgui.Dialog().notification(
            'IPTV',
            'Nothing scheduled on this channel right now',
            xbmcgui.NOTIFICATION_INFO, 4000)

    if gen is not None:
        if ok:
            threading.Thread(target=_advance_worker,
                             args=(gen,), daemon=True).start()
        else:
            disarm_session(gen)
    return ok


def play_payload(payload, title_hint=''):
    """Decode one b64url payload and play it (click-time resolution)."""
    try:
        data = iptv_m3u.decode_payload(payload)
    except Exception as e:
        log(f'iptv_play bad payload: {e}', level=xbmc.LOGWARNING)
        xbmcgui.Dialog().notification(
            'IPTV', 'Bad channel payload', xbmcgui.NOTIFICATION_WARNING, 3000)
        return
    if not data.get('title') and title_hint:
        data['title'] = title_hint
    prog = None
    if data.get('ch') and not data.get('url') and not data.get('magnet'):
        prog = _ensure_program(data)
    data['_prog'] = prog
    decision = iptv_m3u.click_target(data, prog)
    return _play_decision(decision, data)


class IPTVPlugin(Plugin):
    name = 'iptv'
    description = 'IPTV M3U channel play (debrid resolve at click)'

    def routes(self, plugin):
        @plugin.route('/iptv_play/<path:payload>')
        def iptv_play(payload):
            play_payload(unquote(payload))
