
import json
import os
import requests
from ..util.dialogs import link_dialog, remove_name
from ..plugin import Plugin
import xbmcgui
from resources.lib.plugin import run_hook
# from resources.lib import k
from xbmcvfs import translatePath
import xbmcaddon
from datetime import datetime, timezone
import urllib
import xbmc

class SearchJSON(Plugin):
    name = "search_json"
    priority = 100
    user_agent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36'


    def get_cache_path(self) -> str:
        user_path = translatePath(xbmcaddon.Addon().getAddonInfo("profile")) or "."
        config_path = os.path.join(user_path, f"{self.name}_cache.json")
        return config_path

    def process_item(self, item):
        if self.name in item:
            query = item.get(self.name, "*")
            thumbnail = item.get("thumbnail", "")
            fanart = item.get("fanart", "")
            dialog = query.startswith("dialog:")
            if dialog:
                query = query.replace("dialog:", "")
                
            item["link"] = f"{self.name}/{item.get('link')}?query={query}&dialog={str(dialog).lower()}"
            item["is_dir"] = not dialog
            item["list_item"] = xbmcgui.ListItem(item.get("title", item.get("name", "")))
            item["list_item"].setArt({"thumb": thumbnail, "fanart": fanart})
            
            return item

    def save_to_cache(self, query, jen_list):
        cache_path = self.get_cache_path()
        if not os.path.exists(cache_path):
            cache = []
        else:
            with open(cache_path, "r+") as f:
                cache = json.load(f)
        entry = {
            "query": query,
            "time": int(datetime.now(timezone.utc).timestamp()),
            "items": jen_list
        }
        cache.insert(0, entry)
        if len(cache) > 10:
            cache.pop()
        with open(cache_path, "w") as f:
            json.dump(cache, f)

    def routes(self, plugin):
        @plugin.route(f"/{self.name}/<path:dir>")
        def directory(dir):
            jen_list = []
            dir = urllib.parse.unquote_plus(dir)
            query = plugin.args["query"][0] if "query" in plugin.args else None
            if query is None or query == "*":
                query = xbmcgui.Dialog().input("Search").lower()
                if query == "":
                    return
            dialog = plugin.args["dialog"][0] == "true" if "dialog" in plugin.args else False
            ch_title = plugin.args.get("ch_title", [None])[0]

            r = requests.get(dir)
            # if r.content[0] == 0x40:
            #     items = json.loads(k.dfzxujsdfzio(r.content).decode("utf-8"))["items"]
            # else:
            items = r.json()["items"]
            
            jen_list = list(filter(lambda x: query in x.get("title", x.get("name", "")).lower(), items))
            if dialog:
                idx = link_dialog([res["title"] for res in jen_list], return_idx=True, hide_links=False)
                if idx is None:
                    return True
                item = jen_list[idx]
                if isinstance(item.get("link", ""), list):
                    idx = link_dialog([res for res in item["link"]], return_idx=True, hide_links=True)
                    if idx is None:
                        return True
                    item["link"] = remove_name(item["link"][idx])
                xbmc.log(f'[MadTitan] search_json: ch_title={ch_title}, item_link={str(item.get("link", ""))[:80]}, sj={bool(item.get("sportjetextractors"))}', xbmc.LOGINFO)
                if ch_title:
                    try:
                        from resources.lib.stream_prefs import StreamPreferences
                        sp = StreamPreferences()
                        xbmc.log(f'[MadTitan] search_json: auto_play_prefs enabled={sp.is_enabled()}', xbmc.LOGINFO)
                        if sp.is_enabled():
                            pref_url = None
                            link_val = item.get("link", "")
                            sj_val = item.get("sportjetextractors", [])
                            if isinstance(link_val, str) and link_val.startswith("plugin://"):
                                extracted = sp.extract_url_from_plugin(link_val)
                                if extracted and sp.is_playable_url(extracted):
                                    pref_url = extracted
                            if not pref_url and isinstance(sj_val, list) and sj_val:
                                first_link = sj_val[0] if isinstance(sj_val[0], str) else None
                                if first_link and sp.is_playable_url(first_link):
                                    pref_url = first_link
                            if not pref_url and isinstance(link_val, str) and sp.is_playable_url(link_val):
                                pref_url = link_val
                            if pref_url:
                                sp.save_preference(ch_title, 0, pref_url, ch_title)
                                xbmc.log(f'[MadTitan] search_json: saved pref for "{ch_title}" url={pref_url[:80]}', xbmc.LOGINFO)
                    except Exception as e:
                        xbmc.log(f'[MadTitan] search_json: pref save error: {e}', xbmc.LOGERROR)
                sj_val = item.get("sportjetextractors")
                needs_process = any(k in item for k in ("file_iptv", "tele_iptv", "iptv_s")) or (sj_val and isinstance(sj_val, str))

                if needs_process:
                    processed = run_hook("process_item", item)
                    if processed:
                        item = processed
                        item = run_hook("get_metadata", item, return_item_on_failure=True)

                        if isinstance(item, dict) and "list_item" in item:
                            item = dict(item)
                            item.pop("list_item", None)

                if isinstance(item, dict) and item.get("is_dir"):
                    nav_link = item.get("link", "")
                    if nav_link:
                        xbmc.executebuiltin(f'RunPlugin(plugin://plugin.video.madtitansports/{nav_link})')
                    return True

                run_hook("play_video", json.dumps(item))
            else:
                jen_list = [run_hook("process_item", item) for item in jen_list]
                jen_list = [run_hook("get_metadata", item, return_item_on_failure=True) for item in jen_list]
                run_hook("display_list", jen_list)

        @plugin.route(f"/{self.name}/cache")
        def cache():
            cache_path = self.get_cache_path()
            jen_list = []
            if os.path.exists(cache_path):
                with open(cache_path, "r") as f:
                    items = json.load(f)
                for i, item in enumerate(items):
                    jen_list.append({
                        "title": f"Query:[COLORred] {item['query'].upper()}[/COLOR] [COLORyellow]  ({len(item['items'])} links)[/COLOR]\nTime: {datetime.fromtimestamp(item['time']).strftime('%m/%d %I:%M %p')}",
                        "type": "dir",
                        self.name: f"cache/{i}"
                    })
            jen_list = [run_hook("process_item", item) for item in jen_list]
            jen_list = [run_hook("get_metadata", item, return_item_on_failure=True) for item in jen_list]
            run_hook("display_list", jen_list)

        @plugin.route(f"/{self.name}/cache/<entry>")
        def cache_entry(entry):
            entry = int(entry)
            cache_path = self.get_cache_path()
            with open(cache_path, "r") as f:
                items = json.load(f)
            jen_list = items[entry]["items"]
            jen_list = [run_hook("process_item", item) for item in jen_list]
            jen_list = [run_hook("get_metadata", item, return_item_on_failure=True) for item in jen_list]
            run_hook("display_list", jen_list)

        @plugin.route(f"/{self.name}/clear")
        def clear():
            addon = xbmcaddon.Addon()
            USER_DATA_DIR = translatePath(addon.getAddonInfo("profile"))
            if os.path.exists(os.path.join(USER_DATA_DIR, f"{self.name}_cache.json")):
                os.remove(os.path.join(USER_DATA_DIR, f"{self.name}_cache.json"))
            xbmcgui.Dialog().ok("Clear", "You are now [COLORred]clearing[/COLOR] your previous searches.")
            