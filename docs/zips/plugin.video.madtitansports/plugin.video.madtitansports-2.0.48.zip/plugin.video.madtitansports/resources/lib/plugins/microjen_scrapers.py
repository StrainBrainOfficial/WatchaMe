##########################################
# GIVE CREDIT WHERE CREDIT IS DUE                                
# Thanks and respect to Crucial Minds for permission    
# to use the Base Code for the scraper module  
# (script.module.microjenscrapers) and to The Jen Crew for their      
# valuable contributions in bringing this project together 
# and for ongoing  maintenance / development                        
#########################################

from ..plugin import Plugin
import json, re, xbmc
import xbmcaddon
try:
    from resources.lib.util.common import *
except ImportError:
    from .resources.lib.util.common import *

debrid_only = ownAddon.getSetting('debrid.only') or 'false'
addon_name = xbmcaddon.Addon().getAddonInfo('name')

TIMEOUT = 8 # 10


def _reap_threads(threads, budget_s=3.0):
    """Bounded join of scraper threads left after cancel/timeout so hung
    scrapers don't outlive the search and keep the script invoker in
    'waiting on thread' teardown. Total wait is capped, not per-thread."""
    import time as _time
    deadline = _time.monotonic() + budget_s
    for t in threads:
        try:
            t[0].join(timeout=max(0.0, deadline - _time.monotonic()))
        except Exception:
            pass

class _NullProgress:
    """Drop-in for xbmcgui.DialogProgress when the IPTV scrape bumper
    video is showing — the animation IS the feedback, so the scraping
    dialog (sources/links found) stays hidden. All methods no-op;
    iscanceled() always False (auto-pick scrapes are short)."""

    @staticmethod
    def create(*args, **kwargs):
        pass

    @staticmethod
    def update(*args, **kwargs):
        pass

    @staticmethod
    def close():
        pass

    @staticmethod
    def iscanceled():
        return False


class MicroJenScrapers(Plugin):
    name = "microjenscrapers"
    description = "Scrape with MicroJen Scrapers"
    priority = 101

    hostprDict = [
        "1fichier.com",
        "dailyuploads.net",
        "ddl.to",
        "ddownload.com",
        "dropapk.to",
        "earn4files.com",
        "filefactory.com",
        "hexupload.net",
        "mega.io",
        "mega.nz",
        "multiup.org",
        "nitroflare.com",
        "oboom.com",
        "rapidgator.net",
        "rg.to",
        "rockfile.co",
        "rockfile.eu",
        "turbobit.net",
        "ul.to",
        "uploaded.net",
        "uploaded.to",
        "uploadgig.com",
        "uploadrocket.net",
        "usersdrive.com",
    ]
    # hostprDict = [] 
    hostDict = []

    def play_video(self, item, quiet=False):
        item = json.loads(item)
        
        link = item.get("link")
        if link and link.startswith("search"):
            import microjenscrapers
            import xbmcgui
            import concurrent.futures
            import resolveurl
            import operator
            import time

            self.hostDict = resolveurl.relevant_resolvers(order_matters=True)
            # quiet=True: the scrape bumper video is playing — hide the
            # scraping dialog (IPTV path). All progress calls no-op.
            progress = _NullProgress() if quiet else xbmcgui.DialogProgress()
            sources = microjenscrapers.sources()
            all_sources = []
            search_title = re.sub("(\[.+?\])", "", item.get("title")) 
            do_log(f'{self.name} - search_title = \n' + str(search_title) )  
            
            if item.get("content").lower() == "movie":
                sources = [(i[0], i[1], getattr(i[1], "movie", None)) for i in sources]
                sources = list(filter(lambda source: source[2], sources))
                all_sources = []
                num_sources = len(sources)
                counter = 0
                progress.create(
                    f"{addon_name}",
                    f"Scraping for {item.get('title')}\n[I][COLOR orange](Sources : {num_sources - counter} / {num_sources} left)[/I][COLOR white] > [COLOR lawngreen]{len(all_sources)} links found[/COLOR]",
                )
                # progress.create(
                    # "MicroJen",
                    # f"Scraping for {item.get('title')}\n{num_sources}/{num_sources} left\n 0 links found",
                # )
                threads = [
                    self.get_movie_source(
                        # item.get("title"),
                        search_title,
                        item.get("year"),
                        item.get("imdb_id"),
                        i[0],
                        i[1],
                    )
                    for i in sources
                ]
                for t in threads:
                    t[0].start()
                end_time = TIMEOUT + time.monotonic()
                while True:
                    if not threads:
                        break
                    for t in threads:
                        if progress.iscanceled():
                            break
                        wait_timeout = end_time - time.monotonic()
                        if wait_timeout < 0:
                            break
                        if t[0].is_alive():
                            continue
                        else:
                            result = t[1]
                            threads.remove(t)
                            if result:
                                all_sources.extend(result)
                            counter += 1
                            percent = int((counter / num_sources) * 100)
                            progress.update(
                                percent,
                                f"Scraping for {item.get('title')}\n[I][COLOR orange](Sources : {num_sources - counter} / {num_sources} left)[/I][COLOR white] > [COLOR lawngreen]{len(all_sources)} links found[/COLOR]",
                            )
                            # progress.update(
                                # percent,
                                # f"Scraping for {item.get('title')}\n{num_sources - counter}/{num_sources} left\n {len(all_sources)} links found",
                            # )
                    else:
                        continue
                    break
                progress.close()
                _reap_threads(threads)
                all_sources = list(filter(lambda source: source, all_sources))
            elif item.get("content").lower() == "episode":
                sources = [(i[0], i[1], getattr(i[1], "tvshow", None)) for i in sources]
                sources = list(filter(lambda source: source[2], sources))
                all_sources = []
                num_sources = len(sources)
                counter = 0
                name = f'{item.get("tv_show_title")} - S{item.get("season")}E{item.get("episode")}'
                progress.create(
                    f"{addon_name}",
                    f"Scraping for {item.get('title')}\n[I][COLOR orange](Sources : {num_sources - counter} / {num_sources} left)[/I][COLOR white] > [COLOR lawngreen]{len(all_sources)} links found[/COLOR]",
                )
                # progress.create(
                    # "MicroJen",
                    # f"Scraping for {item.get('title')}\n{num_sources}/{num_sources} left\n 0 links found",
                # )
                threads = [
                    self.get_episode_source(
                        item.get("title"),
                        item.get("tv_show_title"),
                        item.get("year"),
                        item.get("imdb_id"),
                        item.get("tmdb_id"),
                        item.get("premiered"),
                        item.get("season"),
                        item.get("episode"),
                        i[0],
                        i[1],
                    )
                    for i in sources
                ]
                for t in threads:
                    t[0].start()
                end_time = TIMEOUT + time.monotonic()
                while True:
                    for t in threads:
                        if progress.iscanceled():
                            break
                        wait_timeout = end_time - time.monotonic()
                        if wait_timeout < 0:
                            break
                        if t[0].is_alive():
                            continue
                        else:
                            result = t[1]
                            threads.remove(t)
                            if result:
                                all_sources.extend(result)
                            counter += 1
                            percent = int((counter / num_sources) * 100)
                            progress.update(
                                percent,
                                f"Scraping for {item.get('title')}\n[I][COLOR orange](Sources : {num_sources - counter} / {num_sources} left)[/I][COLOR white] > [COLOR lawngreen]{len(all_sources)} links found[/COLOR]",
                            )
                            # progress.update(
                                # percent,
                                # f"Scraping for {item.get('title')}\n{num_sources - counter}/{num_sources} left\n {len(all_sources)} links found",
                            # )
                    else:
                        continue
                    break
                progress.close()
                _reap_threads(threads)
                all_sources = list(filter(lambda source: source, all_sources))

            if not all_sources:
                return False

            # Link handling (addon settings, "MicroJen Scrapers" category):
            #   microjen.link_mode     0 = auto-pick best source (default) | 1 = ask via picker
            #   microjen.pref_quality  auto-mode quality cap: 0=480p 1=720p 2=1080p 3=4K allowed
            link_mode = ownAddon.getSetting("microjen.link_mode") or "0"
            qpref = ownAddon.getSetting("microjen.pref_quality") or "2"
            cap = {"0": 480, "1": 720, "2": 1080, "3": 2160}.get(qpref, 1080)

            def _qnum(src):
                m = re.search(r"\d+", str(src.get("quality") or ""))
                return int(m.group()) if m else 0

            ordered = sorted(all_sources, key=lambda s: -_qnum(s))

            if link_mode == "1":
                # picker: numeric best-first display order
                play_sources = [
                    f"{s['origin']} - {s['source']} - {str(s.get('quality') or '').replace('.','')} - {s.get('info', 'Size Unknown')}"
                    for s in ordered
                ]
                selected = xbmcgui.Dialog().select("Select a Link", play_sources)
                if selected == -1:
                    return True
                candidates = [ordered[selected]]
            else:
                at_or_below = [s for s in ordered if _qnum(s) <= cap]
                above = [s for s in ordered if _qnum(s) > cap]
                candidates = at_or_below + above  # cap = preference, above = last resort
                do_log(
                    f"{self.name} - auto-pick (max {cap}p): "
                    f"{len(at_or_below)}/{len(all_sources)} at or below cap, trying best first"
                )

            import xbmc
            import xbmcaddon
            default_icon = xbmcaddon.Addon().getAddonInfo('icon')
            title = item["title"]
            thumbnail = item.get("thumbnail", default_icon)
            plot = item.get("summary", "")
            if item.get("infolabels", ""):
                plot = item["infolabels"]["plot"]
            liz = xbmcgui.ListItem(title)
            liz.setInfo('video', {'title': title, "plot": plot})
            liz.setArt({'thumb': thumbnail, 'icon': thumbnail})

            for src in candidates:
                link = src.get("url")
                if not link:
                    continue
                try:
                    if resolveurl.HostedMediaFile(link).valid_url():
                        url = resolveurl.HostedMediaFile(link).resolve()
                        if url:
                            do_log(
                                f"{self.name} - playing {src.get('origin')} "
                                f"{src.get('quality')} ({src.get('info', '')})"
                            )
                            xbmc.Player().play(url, liz)
                            return True
                        continue
                    if src.get("direct"):
                        do_log(
                            f"{self.name} - playing direct {src.get('origin')} "
                            f"{src.get('quality')}"
                        )
                        xbmc.Player().play(link, liz)
                        return True
                except Exception as e:
                    do_log(f"{self.name} - resolve failed ({src.get('origin')}): {e}")
                    continue
            do_log(f"{self.name} - no source could be resolved")
            return False
    
    def routes(self, plugin):
        @plugin.route(f"/{self.name}/play/<path:query>")
        def play(query):
            q = query.split("|")
            item = {"title": q[1], "content": q[0], "imdb_id": q[2], "year": q[3], "link": "search"}
            self.play_video(json.dumps(item))

    def get_movie_source(self, title, year, imdb, source_name, source_object):
        from threading import Thread

        result = []
        thread = Thread(
            target=self._get_movie_source_threaded,
            args=(
                title,
                year,
                imdb,
                source_name,
                source_object,
                result,
            ),
            daemon=True,
        )
        return (thread, result)

    def _get_movie_source_threaded(
        self, title, year, imdb, source_name, source_object, outlist
    ):
        url = source_object.movie(imdb, title, title, "", year)
        sources = source_object.sources(url, self.hostDict, self.hostprDict)
        if sources:
            for item in sources:
                item["origin"] = source_name
            outlist.extend(sources)
        return sources

    def get_episode_source(
        self,
        title,
        tv_show_title,
        year,
        imdb,
        tmdb,
        premiered,
        season,
        episode,
        source_name,
        source_object,
    ):
        from threading import Thread

        result = []
        thread = Thread(
            target=self._get_episode_source_threaded,
            args=(
                title,
                tv_show_title,
                year,
                imdb,
                tmdb,
                premiered,
                season,
                episode,
                source_name,
                source_object,
                result,
            ),
            daemon=True,
        )
        return (thread, result)

    def _get_episode_source_threaded(
        self,
        title,
        tv_show_title,
        year,
        imdb,
        tmdb,
        premiered,
        season,
        episode,
        source_name,
        source_object,
        outlist,
    ):
        tv_show_url = source_object.tvshow(
            imdb, tmdb, tv_show_title, tv_show_title, "", year
        )
        episode_url = source_object.episode(
            tv_show_url, imdb, tmdb, title, premiered, season, episode
        )
        sources = source_object.sources(episode_url, self.hostDict, self.hostprDict)
        if sources:
            for item in sources:
                item["origin"] = source_name
            outlist.extend(sources)
        return sources
