# -*- coding: utf-8 -*-
"""Mad Titan Dailymotion playback through Go + the JetExtractors HLS proxy.

Adapted for plugin.video.madtitansports/resources/lib/plugins/dailymotion.py.
This is Mad Titan's Plugin.play_video interface, NOT a ResolveURL plugin.
The full HLS master uses the selected engine when audio-safe.
Requires the companion custom JetExtractors build and script.module.go.
"""
from ..plugin import Plugin
import json
import os
import sys
from urllib.parse import urlparse

import xbmc
import xbmcgui


def _jet_helpers():
    """Load the installed addon library when Kodi hasn't added its lib/ path."""
    try:
        from jetextractors.extractors.basketballreplays import (
            get_dailymotion_manifest, fetch_dailymotion_master_bytes,
            get_dailymotion_proxy, get_dailymotion_playback_engine)
        return (get_dailymotion_manifest, fetch_dailymotion_master_bytes,
                get_dailymotion_proxy, get_dailymotion_playback_engine)
    except ImportError:
        import xbmcaddon
        import xbmcvfs
        root = xbmcvfs.translatePath(
            xbmcaddon.Addon('script.module.jetextractors').getAddonInfo('path'))
        lib = os.path.join(root, 'lib')
        if lib not in sys.path:
            sys.path.insert(0, lib)
        from jetextractors.extractors.basketballreplays import (
            get_dailymotion_manifest, fetch_dailymotion_master_bytes,
            get_dailymotion_proxy, get_dailymotion_playback_engine)
        return (get_dailymotion_manifest, fetch_dailymotion_master_bytes,
                get_dailymotion_proxy, get_dailymotion_playback_engine)


def _valid_dailymotion(link):
    if not isinstance(link, str):
        return False
    host = (urlparse(link).hostname or '').lower()
    return (urlparse(link).scheme in ('http', 'https') and
            (host in ('dailymotion.com', 'dai.ly') or
             host.endswith('.dailymotion.com')))


def _has_separate_audio_rendition(manifest_bytes):
    """Whether HLS advertises a separately fetchable audio rendition.

    Dailymotion can send fMP4 variants with AAC multiplexed alongside H.264,
    without EXT-X-MEDIA:TYPE=AUDIO. FFmpegDirect demuxes those variants with
    sound, but InputStream Adaptive may expose a silent/stalled audio stream.
    Prefer FFmpegDirect for that layout without changing the saved preference.
    """
    if isinstance(manifest_bytes, bytes):
        text = manifest_bytes.decode('utf-8', 'replace')
    else:
        text = str(manifest_bytes or '')
    for line in text.splitlines():
        tag = line.strip()
        if not tag.upper().startswith('#EXT-X-MEDIA:'):
            continue
        attrs = tag.split(':', 1)[1]
        # Match HLS attribute names at comma boundaries without splitting a
        # signed, quoted URI that might contain commas.
        import re
        audio_type = re.search(r'(?:^|,)\s*TYPE\s*=\s*AUDIO\s*(?:,|$)',
                               attrs, re.IGNORECASE)
        audio_uri = re.search(r'(?:^|,)\s*URI\s*=\s*(?:"[^"]+"|[^,\s]+)',
                              attrs, re.IGNORECASE)
        if audio_type and audio_uri:
            return True
    return False


def _stream_url(link):
    # The shared helper accepts /video/ID and /embed/video/ID, but not the
    # dai.ly/ID abbreviation. Canonicalise the latter without fetching an
    # untrusted redirect and without changing the signed manifest URL.
    parsed = urlparse(link)
    if (parsed.hostname or '').lower() == 'dai.ly':
        import re
        video_id = parsed.path.strip('/').split('/')[0]
        if not re.fullmatch(r'[A-Za-z0-9]+', video_id):
            raise ValueError('Invalid Dailymotion video ID')
        link = 'https://www.dailymotion.com/video/' + video_id
    manifest, fetch, proxy, get_engine = _jet_helpers()
    result = manifest(link, 'Mozilla/5.0')
    if not result:
        raise RuntimeError('Dailymotion metadata unavailable')
    master_url, headers = result
    data = fetch(master_url, headers)
    if not data:
        raise RuntimeError('Dailymotion master audio playlist unavailable')
    master_bytes, final_url = data
    # Honour Adaptive only when the master explicitly provides a separate
    # audio rendition. A muxed H.264/AAC variant needs FFmpegDirect here;
    # otherwise Kodi 21 InputStream Adaptive can play picture without sound.
    engine = get_engine()
    if engine == 'adaptive' and not _has_separate_audio_rendition(master_bytes):
        xbmc.log('[Mad Titan Dailymotion] Master has muxed/implicit audio; '
                 'using FFmpegDirect to retain sound (Adaptive preference unchanged)',
                 xbmc.LOGINFO)
        engine = 'ffmpeg'
    proxied, _ = proxy(master_bytes, headers, master_url=final_url)
    if not proxied:
        raise RuntimeError('Unable to cache Dailymotion HLS master')
    return proxied, engine


def play_dailymotion_url(link, title=""):
    """Play a direct Dailymotion URL, including one selected via JetExtractors."""
    url, engine = _stream_url(link)
    list_item = xbmcgui.ListItem(label=title or "Dailymotion", path=url)
    list_item.setMimeType('application/vnd.apple.mpegurl')
    list_item.setContentLookup(False)
    if engine == 'adaptive':
        list_item.setProperty('inputstream', 'inputstream.adaptive')
        list_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
    else:
        engine = 'ffmpeg'
        list_item.setProperty('inputstream', 'inputstream.ffmpegdirect')
        list_item.setProperty('inputstream.ffmpegdirect.manifest_type', 'hls')
        list_item.setProperty('inputstream.ffmpegdirect.open_mode', 'ffmpeg')
    xbmc.log('[Mad Titan Dailymotion] Player={} full HLS master'.format(engine), xbmc.LOGINFO)
    xbmc.Player().play(url, list_item)
    return True


class dailymotion(Plugin):
    name = 'dailymotion'
    priority = 100

    def play_video(self, video):
        try:
            item = json.loads(video) if isinstance(video, (str, bytes)) else video
            link = item.get('link') if isinstance(item, dict) else None
            if isinstance(link, list):
                link = next((x for x in link if _valid_dailymotion(x)), None)
            if not _valid_dailymotion(link):
                return False
            return play_dailymotion_url(link, title=item.get('title', ''))
        except Exception as exc:
            xbmc.log('[Mad Titan Dailymotion] {}: {}'.format(
                type(exc).__name__, str(exc)[:160]), xbmc.LOGERROR)
            xbmcgui.Dialog().notification(
                'Mad Titan Dailymotion', 'Dailymotion playback failed',
                xbmcgui.NOTIFICATION_ERROR, 5000)
            return False
