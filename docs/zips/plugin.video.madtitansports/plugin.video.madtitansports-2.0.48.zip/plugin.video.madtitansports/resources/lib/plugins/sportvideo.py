import hashlib
import os
import re
import time
import urllib.parse
from concurrent.futures import ThreadPoolExecutor, as_completed

import requests
import xbmc
import xbmcaddon
import xbmcgui
from xbmcvfs import translatePath

from resources.lib.plugin import Plugin, run_hook

BASE_URL = "https://sport-video.org.ua"
SEARCH_INDEX_URL = f"{BASE_URL}/searchindex.js"
# Rutor disabled 2026-10-05: results were mostly years old across categories.
# Flip to True to re-enable as a second combined source.
ENABLE_RUTOR = False
RUTOR_MIRRORS = ("http://new-rutor.org", "http://4.new-rutor.org")
BROWSER_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
INDEX_CACHE_FILE = os.path.join(
    translatePath(xbmcaddon.Addon().getAddonInfo("profile")),
    "sportvideo_searchindex.js",
)
INDEX_CACHE_TTL = 6 * 3600
MAX_RESULTS = 25
MAX_COMBINED = 30
MAX_PAGE_WORKERS = 6

_SEARCHPAGE_RE = re.compile(
    r'new SearchPage\(\s*"([^"]+)"\s*,\s*"((?:[^"\\]|\\.)*)"\s*,\s*"((?:[^"\\]|\\.)*)"\s*,\s*"((?:[^"\\]|\\.)*)"',
    re.DOTALL,
)
_GENERIC_PAGES = {
    "start.html", "index.html", "index-blank.html", "oldergames.html",
    "schedule.html", "schedulem-t.html", "schedulef-s.html",
}
_RUTOR_TORRENT_RE = re.compile(r'href="(/torrent/\d+/[^"]+)"[^>]*>([^<]+)</a>')
_RUTOR_MAGNET_RE = re.compile(r'href="(magnet:\?xt=urn:btih:[^"]+)"')
_RUTOR_TORRENT_DL_RE = re.compile(r'href="(/parse/d\.rutor\.org/download/\d+)"')
_RUTOR_PREFIX_RE = re.compile(
    r'^(?:Американский футбол|Баскетбол|Хоккей|Бейсбол|Футбол|Теннис|Формула 1|'
    r'Смешанные единоборства|Велоспорт|Легкая атлетика|Бокс|Регби|Гольф|'
    r'Снукер|Другие виды спорта)\.\s*',
    re.IGNORECASE,
)


def _log(msg):
    xbmc.log(f"[SportVideo] {msg}", xbmc.LOGINFO)


def _unescape_js(s):
    return (
        s.replace('\\"', '"')
        .replace("\\'", "'")
        .replace("\\n", " ")
        .replace("\\/", "/")
    )


def _bdecode(data, i=0):
    if i >= len(data):
        raise ValueError("bencode: unexpected end")
    c = data[i:i + 1]
    if c == b"i":
        j = data.index(b"e", i)
        return int(data[i + 1:j]), j + 1
    if c == b"l":
        i += 1
        out = []
        while data[i:i + 1] != b"e":
            v, i = _bdecode(data, i)
            out.append(v)
        return out, i + 1
    if c == b"d":
        i += 1
        out = {}
        while data[i:i + 1] != b"e":
            k, i = _bdecode(data, i)
            v, i = _bdecode(data, i)
            out[k] = v
        return out, i + 1
    if c.isdigit():
        j = data.index(b":", i)
        n = int(data[i:j])
        start = j + 1
        return data[start:start + n], start + n
    raise ValueError(f"bencode: bad token at {i}: {c!r}")


def _extract_info_bytes(data):
    if not data.startswith(b"d"):
        return None
    i = 1
    while i < len(data) and data[i:i + 1] != b"e":
        key, i = _bdecode(data, i)
        start = i
        _, end = _bdecode(data, i)
        if key == b"info":
            return data[start:end]
        i = end
    return None


def _bdecode_to_str(v):
    if isinstance(v, bytes):
        try:
            return v.decode("utf-8")
        except Exception:
            return v.decode("latin-1", "replace")
    return v


def torrent_bytes_to_magnet(torrent_bytes, fallback_name=""):
    info_raw = _extract_info_bytes(torrent_bytes)
    if not info_raw:
        return None
    infohash = hashlib.sha1(info_raw).hexdigest()
    try:
        meta, _ = _bdecode(torrent_bytes, 0)
    except Exception:
        meta = {}
    info = meta.get(b"info", {}) if isinstance(meta, dict) else {}
    name = _bdecode_to_str(info.get(b"name", b"")) if isinstance(info, dict) else ""
    name = (name or fallback_name or "").strip()
    trackers = []
    announce = meta.get(b"announce", b"") if isinstance(meta, dict) else b""
    if isinstance(announce, bytes) and announce:
        trackers.append(_bdecode_to_str(announce))
    alist = meta.get(b"announce-list", []) if isinstance(meta, dict) else []
    if isinstance(alist, list):
        for tier in alist:
            entries = tier if isinstance(tier, list) else [tier]
            for t in entries:
                if isinstance(t, bytes) and t:
                    u = _bdecode_to_str(t)
                    if u and u not in trackers:
                        trackers.append(u)
    magnet = f"magnet:?xt=urn:btih:{infohash}"
    if name:
        magnet += f"&dn={urllib.parse.quote(name)}"
    for t in trackers:
        magnet += f"&tr={urllib.parse.quote(t, safe='')}"
    return magnet


def _load_search_index(force=False):
    try:
        if not force and os.path.exists(INDEX_CACHE_FILE):
            age = time.time() - os.path.getmtime(INDEX_CACHE_FILE)
            if age < INDEX_CACHE_TTL:
                with open(INDEX_CACHE_FILE, "r", encoding="utf-8", errors="replace") as f:
                    return f.read()
    except Exception:
        pass
    resp = requests.get(SEARCH_INDEX_URL, headers={"User-Agent": BROWSER_UA}, timeout=30)
    resp.raise_for_status()
    text = resp.content.decode("utf-8", "replace")
    try:
        os.makedirs(os.path.dirname(INDEX_CACHE_FILE), exist_ok=True)
        with open(INDEX_CACHE_FILE, "w", encoding="utf-8") as f:
            f.write(text)
    except Exception:
        pass
    return text


def _title_date_rank(title):
    title = title or ""
    m = re.search(r"(\d{2})\.(\d{2})\.(\d{4})", title)
    if m:
        return f"{m.group(3)}{m.group(2)}{m.group(1)}"
    m = re.search(r"\[(\d{2})\.(\d{2})\]\s*\((\d{4})\)", title)
    if m:
        return f"{m.group(3)}{m.group(2)}{m.group(1)}"
    return "00000000"


def _display_title(title):
    display = title or ""
    display = _RUTOR_PREFIX_RE.sub("", display)
    display = re.sub(r"\s+Torrent.*$", "", display, flags=re.I).strip()
    display = re.sub(r"\s+Live Stream Video.*$", "", display, flags=re.I).strip()
    display = re.sub(r"\s+", " ", display).strip()
    return display or (title or "Sport")


def page_thumbnail(page_url):
    if not page_url or "rutor" in page_url or "/torrent/" in page_url:
        return ""
    path = page_url if page_url.startswith("http") else f"{BASE_URL}/{page_url.lstrip('./')}"
    base = os.path.basename(urllib.parse.urlparse(path).path)
    if base.lower().endswith(".html"):
        base = base[:-5]
    return f"{BASE_URL}/images/{base}l.jpg" if base else ""


def _is_rutor_url(page_url):
    low = (page_url or "").lower()
    return "rutor" in low or "/torrent/" in low


def search_sportvideo(query, limit=MAX_RESULTS):
    text = _load_search_index()
    terms = [t for t in re.split(r"\s+", (query or "").strip().lower()) if t]
    if not terms:
        return []
    matches = []
    for m in _SEARCHPAGE_RE.finditer(text):
        url = _unescape_js(m.group(1)).strip()
        title = _unescape_js(m.group(2)).strip()
        keywords = _unescape_js(m.group(3))
        description = _unescape_js(m.group(4))
        hay = f"{title} {keywords} {description}".lower()
        if not all(t in hay for t in terms):
            continue
        low = url.lower()
        if low in _GENERIC_PAGES or low.startswith("schedule") or low.startswith("blocks"):
            continue
        if not low.endswith(".html"):
            continue
        matches.append({"page": url, "title": title, "source": "sport-video"})
    matches.sort(key=lambda r: _title_date_rank(r["title"]), reverse=True)
    return matches[:limit]


def search_rutor(query, limit=MAX_RESULTS):
    q = (query or "").strip()
    if len(q) < 3:
        return []
    encoded = urllib.parse.quote(q)
    for base in RUTOR_MIRRORS:
        try:
            url = f"{base}/search/0/13/000/0/{encoded}"
            resp = requests.get(url, headers={"User-Agent": BROWSER_UA}, timeout=30)
            if resp.status_code != 200 or not resp.text:
                continue
            html = resp.text
            results = []
            seen = set()
            for m in _RUTOR_TORRENT_RE.finditer(html):
                href = m.group(1)
                title = m.group(2).strip()
                if not title or title in ("D", "S", "L") or href in seen:
                    continue
                if len(title) < 10:
                    continue
                seen.add(href)
                results.append({
                    "page": f"{base}{href}",
                    "title": title,
                    "source": "rutor",
                })
                if len(results) >= limit:
                    break
            if results:
                _log(f"rutor search '{q}' -> {len(results)} results via {base}")
                return results
        except Exception as e:
            _log(f"rutor search error via {base}: {e}")
            continue
    return []


def search_all(query, per_source=MAX_RESULTS, total=MAX_COMBINED):
    results = []
    try:
        results.extend(search_sportvideo(query, limit=per_source))
    except Exception as e:
        _log(f"sport-video search failed: {e}")
    if ENABLE_RUTOR:
        try:
            results.extend(search_rutor(query, limit=per_source))
        except Exception as e:
            _log(f"rutor search failed: {e}")
    results.sort(key=lambda r: _title_date_rank(r["title"]), reverse=True)
    return results[:total]


def get_rutor_playable_link(page_url, title=""):
    resp = requests.get(page_url, headers={"User-Agent": BROWSER_UA}, timeout=30)
    resp.raise_for_status()
    html = resp.text
    m = _RUTOR_MAGNET_RE.search(html)
    if m:
        magnet = m.group(1).replace("&amp;", "&")
        return magnet, None
    m = _RUTOR_TORRENT_DL_RE.search(html)
    if m:
        parsed = urllib.parse.urlparse(page_url)
        base = f"{parsed.scheme}://{parsed.netloc}"
        torrent_url = f"{base}{m.group(1)}"
        tresp = requests.get(torrent_url, headers={"User-Agent": BROWSER_UA}, timeout=30)
        tresp.raise_for_status()
        magnet = torrent_bytes_to_magnet(tresp.content, fallback_name=title or "")
        if magnet:
            return magnet, None
        return torrent_url, None
    return None, "No magnet or torrent link found on rutor page."


def get_sportvideo_playable_link(page_url, title=""):
    if page_url.startswith("http"):
        page_full = page_url
    else:
        page_full = f"{BASE_URL}/{page_url.lstrip('./')}"
    resp = requests.get(page_full, headers={"User-Agent": BROWSER_UA}, timeout=30)
    resp.raise_for_status()
    html = resp.text
    hrefs = re.findall(r'href="([^"]+\.torrent)"', html, re.I)
    if not hrefs:
        hrefs = re.findall(r"href='([^']+\.torrent)'", html, re.I)
    if not hrefs:
        return None, "No .torrent link found on page."
    href = hrefs[0]
    if href.startswith("./"):
        href = href[2:]
    if href.startswith("http"):
        torrent_url = href
    else:
        torrent_url = f"{BASE_URL}/{href}"
    torrent_url = torrent_url.replace(" ", "%20")
    tresp = requests.get(torrent_url, headers={"User-Agent": BROWSER_UA}, timeout=30)
    tresp.raise_for_status()
    fallback_name = title or os.path.basename(urllib.parse.urlparse(torrent_url).path)
    magnet = torrent_bytes_to_magnet(tresp.content, fallback_name=fallback_name)
    if magnet:
        return magnet, None
    return torrent_url, None


def get_playable_link(page_url, title=""):
    """Resolve a game page URL to a magnet/.torrent link for debrid."""
    if _is_rutor_url(page_url):
        return get_rutor_playable_link(page_url, title=title)
    return get_sportvideo_playable_link(page_url, title=title)


def build_result_item(g):
    page = g["page"]
    display = _display_title(g["title"])
    source = g.get("source", "sport-video")
    if source == "rutor":
        source_tag = "rutor"
    else:
        source_tag = "sport-video"
    thumb = page_thumbnail(page)
    return {
        "title": f"[COLOR yellow]{display}[/COLOR] [COLOR gray]({source_tag})[/COLOR]",
        "thumbnail": thumb,
        "fanart": thumb,
        "summary": g["title"],
        "type": "item",
        "sportvideo": f"play/{page}",
        "link": "",
    }


class sportvideo(Plugin):
    name = "sportvideo"
    priority = 100

    def process_item(self, item):
        if self.name in item:
            link = item.get(self.name, "")
            item["link"] = f"{self.name}/{urllib.parse.quote(str(link), safe='/')}"
            if str(link).startswith("play/"):
                item["is_dir"] = False
            else:
                item["is_dir"] = True
            item["list_item"] = xbmcgui.ListItem(item.get("title", item.get("name", "")), offscreen=True)
            return item

    def _do_search_and_display(self, query):
        try:
            games = search_all(query)
        except Exception as e:
            xbmcgui.Dialog().ok("Sport Search", f"Search failed: {e}")
            return
        if not games:
            xbmcgui.Dialog().ok("Sport Search", f"No results for '{query}'")
            return
        jen_list = [build_result_item(g) for g in games]
        jen_list = [run_hook("process_item", item) for item in jen_list]
        jen_list = [run_hook("get_metadata", item, return_item_on_failure=True) for item in jen_list]
        run_hook("display_list", jen_list)

    def routes(self, plugin):
        @plugin.route(f"/{self.name}/menu")
        def menu():
            jen_list = [
                {"title": "[COLOR yellow]Search Sport-Video.org.ua[/COLOR]", self.name: "search_input", "type": "dir"},
            ]
            jen_list = [run_hook("process_item", item) for item in jen_list]
            jen_list = [run_hook("get_metadata", item, return_item_on_failure=True) for item in jen_list]
            run_hook("display_list", jen_list)

        @plugin.route(f"/{self.name}/search_input")
        @plugin.route(f"/{self.name}/*")
        def search_input():
            query = xbmcgui.Dialog().input("Search sport-video.org.ua")
            if not query:
                return
            self._do_search_and_display(query)

        @plugin.route(f"/{self.name}/search/<path:query>")
        def search(query):
            query = urllib.parse.unquote_plus(query)
            if query in ("*", ""):
                query = xbmcgui.Dialog().input("Search sport-video.org.ua")
                if not query:
                    return
            self._do_search_and_display(query)

        @plugin.route(f"/{self.name}/menu/<path:query>")
        def menu_search(query):
            query = urllib.parse.unquote_plus(query)
            if query in ("*", ""):
                query = xbmcgui.Dialog().input("Search sport-video.org.ua")
                if not query:
                    return
            self._do_search_and_display(query)

        @plugin.route(f"/{self.name}/play/<path:page_url>")
        def play(page_url):
            page_url = urllib.parse.unquote(page_url)
            if page_url.startswith("play/"):
                page_url = page_url[len("play/"):]
            title = _display_title(os.path.basename(urllib.parse.urlparse(page_url).path) if _is_rutor_url(page_url) else page_url)
            progress = xbmcgui.DialogProgress()
            progress.create("Sport Search", "Fetching torrent...")
            try:
                if _is_rutor_url(page_url):
                    progress.update(40, "Fetching rutor magnet...")
                else:
                    progress.update(40, "Downloading .torrent file...")
                link, err = get_playable_link(page_url, title=title)
                if err or not link:
                    progress.close()
                    xbmcgui.Dialog().ok("Sport Search", err or "Could not build link.")
                    return
                progress.update(80, "Resolving via debrid...")
                import resolveurl
                if resolveurl.HostedMediaFile(link).valid_url():
                    url = resolveurl.HostedMediaFile(link).resolve()
                    progress.close()
                    if not url:
                        xbmcgui.Dialog().ok(
                            "Sport Search",
                            "Debrid service did not return a stream.\nEnable torrent/magnet support in your ResolveURL debrid settings.",
                        )
                        return
                    liz = xbmcgui.ListItem(title)
                    liz.setInfo("video", {"title": title})
                    liz.setProperty("IsPlayable", "true")
                    xbmc.log(f"[SportVideo] Resolved URL via resolveurl for '{title}'", xbmc.LOGINFO)
                    xbmc.Player().play(url, liz)
                else:
                    progress.close()
                    xbmcgui.Dialog().ok(
                        "Sport Search",
                        "No debrid resolver accepted this magnet.\nEnable torrent/magnet support in ResolveURL (Real-Debrid, AllDebrid, Premiumize, TorBox, etc.).",
                    )
            except Exception as e:
                progress.close()
                xbmcgui.Dialog().ok("Sport Search", f"Error: {e}")
