"""Remote IPTV (M3U + XMLTV) GUI - Phase 1 of IPTV_REMOTE_PLAN.md (Option D1).

Root entry lists channels from the server-published playlist (server JSON
"iptv": {playlist_url, epg_url}); falls back to the built-in Avengers
Collection fixture until the server publishes one. Rows mirror SPELUNKR:
`CHANNEL  |  now-playing title`, preview summary = NOW range + description
+ NEXT x3. Click resolves at click-time via ResolveURL (plugins/iptv_play).
"""
import threading
import time
import traceback

import xbmc
import xbmcgui

from resources.lib import iptv_m3u
from resources.lib.gui_helpers import (
    fix_kodi_markup, navigate_to_results, strip_color_tags)
from resources.lib.tool import log

ADDON_ID = 'plugin.video.madtitansports'


class IPTVMixin:

    def _inject_iptv_to(self, target_list):
        target_list[:] = [i for i in target_list
                          if i.get('route', (None,))[0] not in ('iptv', 'iptv_play')]
        target_list.append({
            'title': '[COLOR cyan]IPTV[/COLOR] Channels',
            'thumbnail': '',
            'fanart': '',
            'summary': 'Custom live channels from the remote M3U/XMLTV '
                       'lineup. Shows what is on now - click plays the '
                       'current program (debrid slots resolve fresh on '
                       'every click).',
            'route': ('iptv', ''),
            'raw': {},
        })

    def _inject_iptv(self):
        self._inject_iptv_to(self._root_items)

    def _iptv_item(self, ch):
        ch_id = ch.get('tvg_id') or ''
        name = ch.get('tvg_name') or ch.get('name') or ch_id or 'Channel'
        nn = iptv_m3u.now_next(ch_id) if ch_id else {'now': None, 'upcoming': []}
        now = nn.get('now')
        logo = ch.get('tvg_logo') or ''
        if now:
            now_title = fix_kodi_markup(str(now.get('title') or ''))
            title = f'{name}  [COLOR grey]|[/COLOR]  {now_title}'
            lines = [
                f'[COLOR red][B]NOW[/B][/COLOR]  '
                f'{iptv_m3u.fmt_range(now["start"], now["stop"])}',
                f'[B]{now_title}[/B]',
            ]
            desc = (now.get('desc') or '').strip()
            if desc:
                if len(desc) > 220:
                    desc = desc[:217] + '...'
                lines.append(desc)
            nxt = nn.get('upcoming') or []
            if nxt:
                lines.append('')
                for nu in nxt[:3]:
                    lines.append(f'[COLOR grey]NEXT[/COLOR]  '
                                 f'{iptv_m3u.fmt_time(nu["start"])}: '
                                 f'{fix_kodi_markup(nu["title"])}')
        else:
            title = name
            lines = ['[COLOR grey]No guide data for this channel[/COLOR]']
        group = (ch.get('group_title') or '').strip()
        if group:
            lines.append('')
            lines.append(f'[COLOR grey]{group}[/COLOR]')
        return {
            'title': title,
            'thumbnail': logo,
            'fanart': logo,
            'summary': '\n'.join(lines),
            'route': ('iptv_play', iptv_m3u.payload_for_channel(ch)),
            'raw': {'iptv_channel': ch},
        }

    def _open_iptv(self):
        if getattr(self, '_iptv_loading', False):
            return
        self._iptv_loading = True
        gen = getattr(self, '_iptv_gen', 0) + 1
        self._iptv_gen = gen
        placeholder = {
            'title': '[COLOR grey]Loading IPTV channels...[/COLOR]',
            'thumbnail': '', 'fanart': '',
            'summary': 'Fetching the playlist and guide',
            'route': ('noop', ''), 'raw': {},
        }
        navigate_to_results(self, [placeholder], 'IPTV')

        def work():
            channels = []
            err = None
            used_fixture = False
            # Load with ONE retry: the first IPTV open after a GUI relaunch
            # has thrown a transient error that never reproduces on the next
            # open (2026-11-01 log: "'NoneType' object is not callable" at
            # 09:41:27, clean open at 09:39:56 and after any manual retry).
            # Retry once, and log the FULL traceback so a recurrence names
            # the exact line instead of just the message.
            for attempt in (1, 2):
                try:
                    cfg = iptv_m3u.load_server_config()
                    playlist_url = cfg.get('playlist_url') or ''
                    epg_url = cfg.get('epg_url') or ''
                    epg_text = ''
                    if playlist_url:
                        m3u_text = iptv_m3u.fetch_text(playlist_url)
                        if epg_url:
                            try:
                                epg_text = iptv_m3u.fetch_text(epg_url)
                            except Exception as e:
                                # guide is optional: list channels without it
                                log(f'_open_iptv: EPG fetch failed ({e}) - '
                                    'channels listed without guide data',
                                    level=xbmc.LOGWARNING)
                    else:
                        used_fixture = True
                        log('_open_iptv: no server "iptv" config - using '
                            'built-in Avengers fixture', level=xbmc.LOGWARNING)
                        m3u_text = iptv_m3u.fixture_m3u()
                        epg_text = iptv_m3u.fixture_xmltv()
                    channels = iptv_m3u.parse_m3u(m3u_text)
                    if epg_text:
                        _ch_map, programmes = iptv_m3u.parse_xmltv(epg_text)
                        iptv_m3u.set_epg(programmes)
                    else:
                        iptv_m3u.clear_epg()
                    err = None
                    break
                except Exception as e:
                    err = e
                    log(f'_open_iptv load error (attempt {attempt}/2): {e}\n'
                        f'{traceback.format_exc()}',
                        level=xbmc.LOGERROR)
                    if attempt == 1:
                        time.sleep(1.5)
            if (getattr(self, '_iptv_gen', 0) != gen
                    or self.current_title != 'IPTV'):
                self._iptv_loading = False
                return
            items = []
            if not err:
                for ch in channels:
                    try:
                        items.append(self._iptv_item(ch))
                    except Exception as e:
                        log(f'_open_iptv item error: {e}',
                            level=xbmc.LOGWARNING)
            self._iptv_loading = False
            if err or not items:
                xbmcgui.Dialog().notification(
                    'IPTV',
                    (str(err)[:120] if err else 'No channels loaded'),
                    xbmcgui.NOTIFICATION_WARNING, 5000)
                return
            self.items_data = items
            self.populate_list()
            self.update_preview(0)
            suffix = ' (test fixture)' if used_fixture else ''
            log(f'_open_iptv: showing {len(items)} channels{suffix}')

        threading.Thread(target=work, daemon=True).start()

    def _play_iptv(self, payload, title=''):
        try:
            from resources.lib.plugins.iptv_play import play_payload
            play_payload(payload, title_hint=strip_color_tags(title or ''))
        except Exception as e:
            log(f'_play_iptv error: {e}', level=xbmc.LOGERROR)
            xbmcgui.Dialog().notification(
                'IPTV', 'Play failed', xbmcgui.NOTIFICATION_WARNING, 4000)
