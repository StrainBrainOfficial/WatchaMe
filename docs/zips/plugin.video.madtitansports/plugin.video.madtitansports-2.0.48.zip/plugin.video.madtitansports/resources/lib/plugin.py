import abc
import json
import xbmcgui
from resources.lib.DI import DI

from typing import List, Tuple, Any, Optional, Union, Dict

abstractstaticmethod = abc.abstractmethod


class abstractclassmethod(classmethod):
    __isabstractmethod__ = True

    def __init__(self, callable):
        callable.__isabstractmethod__ = True
        super(abstractclassmethod, self).__init__(callable)


class Plugin:
    __metaclass__ = abc.ABCMeta
    name = "Plugin"
    description = ""
    priority = 100
    subclasses = []

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        cls.subclasses.append(cls)

    def get_list(self, url: str) -> Optional[str]:
        pass

    def parse_list(self, url: str, response: str) -> Optional[List[Dict[str, str]]]:
        pass

    def process_item(
        self, item: Dict[str, str]
    ) -> Optional[Dict[str, Union[str, xbmcgui.ListItem]]]:
        pass

    def get_metadata(
        self, item: Dict[str, Union[str, xbmcgui.ListItem]]
    ) -> Optional[Dict[str, Union[str, xbmcgui.ListItem]]]:
        pass

    def display_list(
        self, jen_list: List[Optional[Dict[str, Union[str, xbmcgui.ListItem]]]]
    ) -> Optional[bool]:
        pass

    def play_video(self, video: str) -> Optional[bool]:
        pass

    def pre_play(self, video: str) -> Optional[bool]:
        pass


plugin_cache = {}


def get_plugins() -> List[Plugin]:
    from . import plugins

    klasses = Plugin.subclasses
    plugins = []
    for klass in klasses:
        if klass in plugin_cache:
            plugins.append(plugin_cache[klass])
        else:
            plugin_cache[klass] = klass()
            plugins.append(plugin_cache[klass])
    return plugins

def _apply_dailymotion_player_setting():
    """Reconcile Kodi's View Set-style selector with JetExtractors on a Loop run.

    Only called as part of the normal add-on invocation. No service, polling,
    background threads or file monitor. JetExtractors remains the sole playback
    settings.json, and actual HLS playback code remains unchanged.
    """
    try:
        import xbmcaddon
        from jetextractors.tools import (
            get_dailymotion_playback_engine,
            set_dailymotion_playback_engine,
        )
    except ImportError:
        # Older JetExtractors versions don't expose the Dailymotion preference.
        return
    try:
        addon = xbmcaddon.Addon('plugin.video.the-loop')
        selected = addon.getSetting('dailymotion_player_engine')
        if selected not in ('0', '1'):
            return
        last_applied = addon.getSetting('dailymotion_player_last_applied')
        requested_engine = 'adaptive' if selected == '1' else 'ffmpeg'
        installed_engine = get_dailymotion_playback_engine()
        if last_applied not in ('0', '1') or selected != last_applied:
            # First use / explicit Loop change: The Loop's current selection wins.
            if installed_engine != requested_engine:
                set_dailymotion_playback_engine(requested_engine)
            addon.setSetting('dailymotion_player_last_applied', selected)
        else:
            # Loop unchanged but another JetExtractors menu was changed:
            # display the actual engine without overwriting it.
            actual = '1' if installed_engine == 'adaptive' else '0'
            if actual != selected:
                addon.setSetting('dailymotion_player_engine', actual)
                addon.setSetting('dailymotion_player_last_applied', actual)
    except Exception as exc:
        try:
            import xbmc
            xbmc.log('[The Loop] Dailymotion player setting update failed: {}'.format(exc),
                     xbmc.LOGWARNING)
        except Exception:
            pass


def register_routes(plugin_route):
    _apply_dailymotion_player_setting()
    plugins = get_plugins()
    for plugin in plugins:
        if hasattr(plugin, "routes"): plugin.routes(plugin_route)


def _track_play_video(raw):
    """Central analytics for every play_video dispatch (all plugins funnel here)."""
    try:
        from resources.lib.playback_monitor import track
        item = json.loads(raw) if isinstance(raw, str) else raw
        if not isinstance(item, dict):
            return
        title = item.get("title") or item.get("name") or ""
        link = item.get("link") or ""
        summary = item.get("summary") or ""
        if not title and not link:
            return
        track(
            "play",
            channel_name=summary or title,
            url=link if isinstance(link, str) else "",
            source="play_video",
            event_label=title or "",
        )
    except Exception:
        pass


def run_hook(*args: Tuple[str, ...], return_item_on_failure=False) -> Any:
    plugins = get_plugins()
    function_name = args[0]
    other_args = args[1:]
    if function_name == "play_video" and other_args:
        _track_play_video(other_args[0])
    plugins = sorted(plugins, key=lambda plugin: plugin.priority, reverse=True)
    for plugin in plugins:
        result = getattr(plugin, function_name)(*other_args)
        if result:
            return result
    if return_item_on_failure:
        if len(other_args) == 1:
            return other_args[0]
        else:
            return other_args
    return False
