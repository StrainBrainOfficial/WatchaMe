"""IPTV M3U + XMLTV - pure stdlib (no xbmc imports; testable outside Kodi).

Phase 1 of IPTV_REMOTE_PLAN.md (Option D1 - debrid-backed channels,
resolve at click). Channel identity comes from the M3U; the guide comes
from XMLTV; per-slot debrid refs ride in the xtv:magnet extension element
(Kodi's XMLTV reader ignores unknown elements). Click-time resolution via
ResolveURL lives in gui_main (sportvideo/microjen pattern) - never bake a
debrid URL into the playlist (they expire; magnets/refs are stable).
"""
import base64
import json
import re
import urllib.request
from datetime import datetime, timedelta, timezone

# ---------------------------------------------------------------------------
# payloads (base64url JSON - the stable channel/direct refs in M3U URLs)
# ---------------------------------------------------------------------------
# {"ch": "<tvg-id>"}  -> resolve current programme's xtv:magnet from EPG
# {"magnet": "..."}   -> direct-flavor channel (magnet rides in the payload)
# {"url": "..."}      -> plain http(s)/rtmp stream, plays as-is


def encode_payload(obj):
    return base64.urlsafe_b64encode(
        json.dumps(obj, separators=(',', ':')).encode('utf-8')
    ).decode('utf-8').rstrip('=')


def decode_payload(s):
    s = (s or '').strip()
    s += '=' * (-len(s) % 4)
    return json.loads(base64.urlsafe_b64decode(s.encode('utf-8')).decode('utf-8'))


def payload_for_channel(ch):
    """Build the click payload for one parsed M3U channel."""
    url = (ch.get('url') or '').strip()
    title = ch.get('tvg_name') or ch.get('name') or ''
    low = url.lower()
    if low.startswith('magnet:'):
        return encode_payload({'magnet': url, 'title': title})
    if low.startswith('plugin://') and '/iptv_play/' in url:
        return url.split('/iptv_play/', 1)[1]
    if low.startswith(('http://', 'https://', 'rtmp://', 'rtmps://', 'rtsp://')):
        return encode_payload({'url': url, 'title': title})
    if ch.get('tvg_id'):
        return encode_payload({'ch': ch['tvg_id'], 'title': title})
    return encode_payload({'url': url, 'title': title})


# ---------------------------------------------------------------------------
# M3U
# ---------------------------------------------------------------------------
_EXTINF_RE = re.compile(r'#EXTINF:\s*(-?\d+)\s*(.*?)\s*,\s*(.*)$')
_ATTR_RE = re.compile(r'([A-Za-z0-9_-]+)="([^"]*)"')


def parse_m3u(text):
    """Parse an extended M3U playlist into channel dicts.

    Each channel: tvg_id, tvg_name, tvg_logo, group_title, name, url.
    """
    channels = []
    pending = None
    for raw in (text or '').splitlines():
        line = raw.strip()
        if not line:
            continue
        if line.upper().startswith('#EXTINF'):
            m = _EXTINF_RE.match(line)
            if not m:
                pending = None
                continue
            attrs = dict(_ATTR_RE.findall(m.group(2) or ''))
            pending = {
                'tvg_id': attrs.get('tvg-id', ''),
                'tvg_name': attrs.get('tvg-name', ''),
                'tvg_logo': attrs.get('tvg-logo', ''),
                'group_title': attrs.get('group-title', ''),
                'name': (m.group(3) or '').strip(),
            }
        elif line.startswith('#'):
            continue
        elif pending is not None:
            pending['url'] = line
            channels.append(pending)
            pending = None
    return channels


# ---------------------------------------------------------------------------
# XMLTV
# ---------------------------------------------------------------------------
_XTV_MAGNET_TAG = '{https://madtitan.tv/xmltv-ext}magnet'


# XMLTV ts: '20261101060000 -0500' (offset colon-optional, per xmltv.org).
# NOTE: parse_xmltv_ts deliberately does NOT use datetime.strptime — on
# Kodi's embedded Python, exiting the GUI interpreter can null out
# datetime.strptime in shared module state, so the NEXT addon session dies
# with "TypeError: 'NoneType' object is not callable" inside strptime
# (kodi.log 2026-11-01 10:25:15; reboot was the only cure). Integer
# slicing + datetime() construction needs no strptime and is immune.
_XMLTV_TS_RE = re.compile(
    r'^(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})'
    r'(?:\s*([+-])(\d{2}):?(\d{2})?)?$')


def parse_xmltv_ts(s):
    """'20261101060000 -0500' -> aware datetime; None on garbage.
    No-strptime implementation (see _XMLTV_TS_RE note)."""
    m = _XMLTV_TS_RE.match((s or '').strip())
    if not m:
        return None
    try:
        dt = datetime(int(m.group(1)), int(m.group(2)), int(m.group(3)),
                      int(m.group(4)), int(m.group(5)), int(m.group(6)))
    except ValueError:               # e.g. month 13, day 32
        return None
    if m.group(7):                   # explicit offset -> aware as-is
        sign = 1 if m.group(7) == '+' else -1
        off = timedelta(hours=int(m.group(8)),
                        minutes=int(m.group(9) or 0))
        return dt.replace(tzinfo=timezone(sign * off))
    return dt.astimezone()           # no offset -> interpret as local


def _local_offset(dt):
    return dt.strftime('%z')  # '+0500' / '-0500'


_EPISODE_NUM_RE = re.compile(
    r'(?:(\d+)\s*[xX]\s*(\d+))|(?:[Ss](\d+)\s*[Ee](\d+))')


def _parse_episode_num(el):
    """episode-num element -> ('', '') or (season, episode) strings.

    Handles the common shapes: xmltv_ns '1.5.' (season.episode.part),
    'S02E05', '2x05'.
    """
    if el is None or not (el.text or '').strip():
        return '', ''
    txt = el.text.strip()
    if el.get('system') == 'xmltv_ns' or re.match(r'^\d+\.\d+', txt):
        parts = txt.split('.')
        if len(parts) >= 2 and parts[0].isdigit() and parts[1].isdigit():
            return str(int(parts[0]) + 1), str(int(parts[1]) + 1)
    m = _EPISODE_NUM_RE.search(txt)
    if m:
        if m.group(1) is not None:
            return str(int(m.group(1))), str(int(m.group(2)))
        return str(int(m.group(3))), str(int(m.group(4)))
    return '', ''


def parse_xmltv(text):
    """Parse XMLTV into (channels, programmes).

    channels: {id: {'name': str, 'icon': str}}
    programmes: [{channel, start, stop, title, desc, date, length, magnet}]
    sorted by start. Consumes the xtv:magnet extension element; everything
    else is standard XMLTV (Kodi PVR readers ignore xtv:*).
    """
    import xml.etree.ElementTree as ET
    root = ET.fromstring(text)
    channels = {}
    for ch in root.findall('channel'):
        cid = ch.get('id') or ''
        if not cid:
            continue
        disp = ch.find('display-name')
        icon = ch.find('icon')
        channels[cid] = {
            'name': (disp.text or '').strip() if disp is not None else '',
            'icon': (icon.get('src') or '') if icon is not None else '',
        }
    programmes = []
    for p in root.findall('programme'):
        cid = p.get('channel') or ''
        start = parse_xmltv_ts(p.get('start'))
        stop = parse_xmltv_ts(p.get('stop'))
        if not cid or start is None or stop is None:
            continue

        def _txt(tag):
            el = p.find(tag)
            return (el.text or '').strip() if el is not None and el.text else ''

        magnet_el = p.find(_XTV_MAGNET_TAG)
        if magnet_el is None:
            magnet_el = p.find('magnet')  # no-namespace fallback
        length_el = p.find('length')
        length = ''
        if length_el is not None and length_el.text:
            length = length_el.text.strip()
        sub_el = p.find('sub-title')
        season, episode = _parse_episode_num(p.find('episode-num'))
        programmes.append({
            'channel': cid,
            'start': start,
            'stop': stop,
            'title': _txt('title'),
            'sub_title': (sub_el.text or '').strip()
                         if sub_el is not None and sub_el.text else '',
            'season': season,
            'episode': episode,
            'desc': _txt('desc'),
            'date': _txt('date'),
            'length': length,
            'magnet': (magnet_el.text or '').strip()
                      if magnet_el is not None and magnet_el.text else '',
        })
    programmes.sort(key=lambda x: x['start'])
    return channels, programmes


# ---------------------------------------------------------------------------
# EPG cache (module-level so the play route sees the guide the GUI loaded)
# ---------------------------------------------------------------------------
_EPG = {}   # channel_id -> [programmes]


def set_epg(programmes):
    grouped = {}
    for p in programmes or []:
        grouped.setdefault(p['channel'], []).append(p)
    for lst in grouped.values():
        lst.sort(key=lambda x: x['start'])
    _EPG.clear()
    _EPG.update(grouped)


def clear_epg():
    _EPG.clear()


def now_next(ch_id, ts=None):
    """Current programme + next 3 for a channel (spelunkr-style summary)."""
    ts = ts or datetime.now().astimezone()
    progs = _EPG.get(ch_id) or []
    cur = None
    idx = -1
    for i, p in enumerate(progs):
        if p['start'] <= ts < p['stop']:
            cur = p
            idx = i
            break
    upcoming = progs[idx + 1:idx + 4] if idx >= 0 else []
    return {'now': cur, 'upcoming': upcoming}


def current_program(ch_id, ts=None):
    ts = ts or datetime.now().astimezone()
    for p in _EPG.get(ch_id) or []:
        if p['start'] <= ts < p['stop']:
            return p
    return None


def next_program(ch_id, after_start, ts=None):
    """Auto-advance target after a slot finishes (live-TV "up next").

    Priority: the programme airing RIGHT NOW if it's a later slot than
    the one just watched (join at its live offset); else the next slot
    in schedule order that hasn't fully elapsed yet (plays from its
    start if not yet aired - playlist behavior); None when the guide
    has nothing left (schedule exhausted or only elapsed slots remain).
    """
    ts = ts or datetime.now().astimezone()
    cur = current_program(ch_id, ts)
    if cur and cur['start'] > after_start:
        return cur
    for p in _EPG.get(ch_id) or []:
        if p['start'] > after_start and p['stop'] > ts:
            return p
    return None


# ---------------------------------------------------------------------------
# click decision - what a channel click should DO (pure, testable)
# ---------------------------------------------------------------------------
def is_placeholder_magnet(magnet):
    """True for the fixture's fake btih:aaaa... refs - these must never be
    sent to a debrid service (they'd fail or pollute the account history)."""
    m = (magnet or '').lower()
    if 'btih:' not in m:
        return False
    btih = m.split('btih:', 1)[1].split('&', 1)[0]
    return bool(btih) and set(btih) <= {'a'}


def search_spec(prog, default_content='movie'):
    """MicroJen search request for a programme: {title, content, year,
    show, season, episode} - the item shape plugins/microjen_scrapers.py
    play_video() expects (link='search' added by the caller)."""
    if not prog:
        return None
    title = (prog.get('title') or '').strip()
    if not title:
        return None
    season = (prog.get('season') or '').strip()
    episode = (prog.get('episode') or '').strip()
    if season and episode:
        return {
            'title': (prog.get('sub_title') or title),
            'content': 'episode',
            'year': (prog.get('date') or '')[:4],
            'show': title,
            'season': season,
            'episode': episode,
        }
    return {
        'title': title,
        'content': default_content,
        'year': (prog.get('date') or '')[:4],
        'show': '',
        'season': '',
        'episode': '',
    }


def seek_offset(prog, ts=None):
    """Live-TV join point: seconds into the slot (now - slot start).

    0 = play from the beginning (slot just started, no prog, or no guide).
    Matches the spelunkr 'join at live offset' behavior.
    """
    if not prog or prog.get('start') is None:
        return 0
    ts = ts or datetime.now().astimezone()
    off = int((ts - prog['start']).total_seconds())
    if off < 90:            # just started - joining adds nothing
        return 0
    stop = prog.get('stop')
    if stop is not None:    # never seek past the slot's own end
        off = min(off, int((stop - prog['start']).total_seconds()) - 30)
    return max(0, off)


def click_target(data, prog=None, ts=None):
    """Resolve a decoded payload + current programme into a play decision.

    Priority (D1 + scraper fallback, 2026-10-31):
      1. direct http(s)/rtmp url  -> {'action': 'direct', url, title}
      2. REAL magnet in payload   -> {'action': 'magnet', magnet, title}
      3. programme has REAL magnet (xtv:magnet) -> magnet (resolve at click)
      4. otherwise                -> MicroJen SEARCH on the slot title
         (placeholder magnets and magnet-less slots land here - no bogus
         ref ever reaches the debrid; scrapers find a playable link)
      5. nothing at all           -> {'action': 'none'}

    Every decision also carries 'seek' = seconds into the current slot
    (live-TV join point, 0 = from start) so playback can jump to the
    point the schedule says the show should be at right now.
    """
    data = data or {}
    title = (data.get('title') or '').strip()
    url = (data.get('url') or '').strip()
    magnet = (data.get('magnet') or '').strip()
    seek = seek_offset(prog, ts)
    if url and not magnet:
        return {'action': 'direct', 'url': url, 'title': title, 'seek': 0}
    if magnet and not is_placeholder_magnet(magnet):
        return {'action': 'magnet', 'magnet': magnet, 'title': title,
                'seek': seek}
    if prog:
        pm = (prog.get('magnet') or '').strip()
        if pm and not is_placeholder_magnet(pm):
            return {'action': 'magnet', 'magnet': pm,
                    'title': prog.get('title') or title, 'seek': seek}
        spec = search_spec(prog)
        if spec:
            return {'action': 'search', 'spec': spec,
                    'title': spec['title'], 'seek': seek}
    if magnet:  # placeholder only, no guide slot to search from
        return {'action': 'none', 'title': title, 'seek': 0}
    return {'action': 'none', 'title': title, 'seek': 0}


# ---------------------------------------------------------------------------
# fetch + display helpers
# ---------------------------------------------------------------------------
def fetch_text(url, timeout=25):
    req = urllib.request.Request(
        url, headers={'User-Agent': 'Mozilla/5.0 (Kodi MadTitan IPTV)'})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read().decode('utf-8', 'replace')


def load_server_config(timeout=15):
    """Read the root server JSON's "iptv" key: {playlist_url, epg_url}.

    The addon never hardcodes an endpoint - URLs arrive at runtime here
    (existing server_url pattern). {} when the server has no iptv key
    yet (callers fall back to the built-in fixture).
    """
    from resources.lib.endpoints import ROOT_JSON
    try:
        data = json.loads(fetch_text(ROOT_JSON, timeout=timeout))
    except Exception:
        return {}
    cfg = data.get('iptv') or {}
    return cfg if isinstance(cfg, dict) else {}


def fmt_time(dt):
    # Display in THIS machine's wall clock - XMLTV files may carry any
    # UTC offset; strftime on the raw dt would show the file's zone time
    # (e.g. a -0500 file shows 9:03 while your clock says 6:03).
    try:
        dt = dt.astimezone()
    except Exception:
        pass
    return dt.strftime('%I:%M %p').lstrip('0')


def fmt_range(start, stop):
    return f'{fmt_time(start)} - {fmt_time(stop)}'


# ---------------------------------------------------------------------------
# Test fixture: "The Avengers Collection" (IPTV_REMOTE_PLAN.md worked example)
# TMDB collection 86311 - real lineup runtimes 143/141/149/181 min.
# Manual-slot EPG: cycle starts 06:00 local, loops all day
# (06:00 / 08:23 / 10:44 / 13:13 then repeat - the plan's exact slot table).
# Magnets are placeholders (btih:aaaa...) until real cached ones land.
# ---------------------------------------------------------------------------
_FIXTURE_CH_ID = 'avengers-collection.madtitan'
_FIXTURE_CH_NAME = 'The Avengers Collection'
_FIXTURE_LOGO = 'https://image.tmdb.org/t/p/w780/tyVu1sYV41OphN7l2F241r6Pqy.jpg'
_FIXTURE_TZ_NAME = 'America/New_York'  # cosmetic only; times are local-time
_FIXTURE_BTIH = 'a' * 40

_FIXTURE_MOVIES = (
    # (title, year, minutes, desc, dn)
    ('The Avengers', 2012, 143,
     "Nick Fury assembles Earth's mightiest heroes against Loki's Chitauri "
     'invasion.', 'The.Avengers.2012.1080p'),
    ('Avengers: Age of Ultron', 2015, 141,
     'The Avengers face Ultron, a self-aware AI whose peacekeeping plan is '
     'the extinction of humanity.', 'Avengers.Age.of.Ultron.2015.1080p'),
    ('Avengers: Infinity War', 2018, 149,
     'Thanos hunts the Infinity Stones as the Avengers make their last stand '
     'against the coming Snap.', 'Avengers.Infinity.War.2018.1080p'),
    ('Avengers: Endgame', 2019, 181,
     'After the Snap the surviving Avengers scheme one final stand against '
     'Thanos to restore the universe.', 'Avengers.Endgame.2019.1080p'),
)


def _fixture_payload():
    return encode_payload({'ch': _FIXTURE_CH_ID})


def fixture_m3u():
    return (
        '#EXTM3U x-tvg-url="https://your-server.example/titanserver/epg/'
        'avengers.xmltv"\n'
        f'#EXTINF:-1 tvg-id="{_FIXTURE_CH_ID}" tvg-name="{_FIXTURE_CH_NAME}" '
        f'tvg-logo="{_FIXTURE_LOGO}" group-title="Movie Channels",'
        f'{_FIXTURE_CH_NAME}\n'
        f'plugin://plugin.video.madtitansports/iptv_play/{_fixture_payload()}\n'
    )


def fixture_xmltv(days=2, start=None):
    """Generate the manual-slot day schedule (plan slot table, local tz)."""
    now = datetime.now().astimezone()
    day = (start or now).replace(hour=6, minute=0, second=0, microsecond=0)
    day = day - timedelta(days=1)
    end = now + timedelta(days=days)
    out = [
        '<?xml version="1.0" encoding="UTF-8"?>',
        '<tv generator-info-name="MadTitan" '
        'xmlns:xtv="https://madtitan.tv/xmltv-ext">',
        f'  <channel id="{_FIXTURE_CH_ID}">',
        f'    <display-name>{_FIXTURE_CH_NAME}</display-name>',
        f'    <icon src="{_FIXTURE_LOGO}"/>',
        '  </channel>',
    ]
    i = 0
    while day < end:
        title, year, mins, desc, dn = _FIXTURE_MOVIES[i % len(_FIXTURE_MOVIES)]
        stop = day + timedelta(minutes=mins)
        magnet = f'magnet:?xt=urn:btih:{_FIXTURE_BTIH}&dn={dn}'
        out.append(
            f'  <programme start="{day.strftime("%Y%m%d%H%M%S")} '
            f'{_local_offset(day)}" stop="{stop.strftime("%Y%m%d%H%M%S")} '
            f'{_local_offset(stop)}" channel="{_FIXTURE_CH_ID}">'
        )
        out.append(f'    <title>{title}</title>')
        out.append(f'    <date>{year}</date>')
        out.append(f'    <length units="minutes">{mins}</length>')
        out.append(f'    <desc>{desc}</desc>')
        out.append(f'    <xtv:magnet>{magnet.replace("&", "&amp;")}</xtv:magnet>')
        out.append('  </programme>')
        day = stop
        i += 1
    out.append('</tv>')
    return '\n'.join(out)


# ---------------------------------------------------------------------------
# self-test: python -m resources.lib.iptv_m3u  (or run this file directly)
# ---------------------------------------------------------------------------
if __name__ == '__main__':
    # payload roundtrip
    p = encode_payload({'ch': _FIXTURE_CH_ID})
    assert decode_payload(p) == {'ch': _FIXTURE_CH_ID}, 'payload roundtrip'

    # M3U fixture parses to one channel with a plugin payload
    chans = parse_m3u(fixture_m3u())
    assert len(chans) == 1, chans
    ch = chans[0]
    assert ch['tvg_id'] == _FIXTURE_CH_ID
    assert ch['tvg_name'] == _FIXTURE_CH_NAME
    assert ch['group_title'] == 'Movie Channels'
    pay = payload_for_channel(ch)
    assert decode_payload(pay) == {'ch': _FIXTURE_CH_ID}

    # direct flavors
    assert decode_payload(payload_for_channel(
        {'url': 'magnet:?xt=urn:btih:bb&dn=x', 'tvg_name': 'M'}))['magnet'] \
        .startswith('magnet:')
    assert decode_payload(payload_for_channel(
        {'url': 'https://cdn.example/live.m3u8', 'tvg_name': 'H'}))['url'] \
        .endswith('.m3u8')

    # XMLTV fixture: slot math matches the plan table
    epg_ch, progs = parse_xmltv(fixture_xmltv())
    assert _FIXTURE_CH_ID in epg_ch
    assert len(progs) >= 8, len(progs)
    # find a full cycle boundary at 06:00
    boundary = None
    for p0 in progs:
        if p0['start'].hour == 6 and p0['start'].minute == 0:
            boundary = p0
            break
    assert boundary is not None, 'no 06:00 slot'
    assert boundary['title'] == 'The Avengers'
    mins = [m[2] for m in _FIXTURE_MOVIES]
    acc = boundary['start']
    for (title, _y, m, _d, _dn), expect in zip(_FIXTURE_MOVIES, mins):
        hit = next(p0 for p0 in progs if p0['start'] == acc)
        assert hit['title'] == title, (hit['title'], title)
        assert int(hit['length']) == expect
        assert hit['stop'] == acc + timedelta(minutes=m)
        assert hit['magnet'].startswith('magnet:?xt=urn:btih:aaaa')
        acc = hit['stop']
    # plan example: 06:00+143m = 08:23, +141 = 10:44, +149 = 13:13, +181 = 16:14
    assert boundary['start'] + timedelta(minutes=143) == \
        boundary['start'].replace(hour=8, minute=23)

    # now/next through the cache
    set_epg(progs)
    probe = boundary['start'] + timedelta(minutes=30)
    nn = now_next(_FIXTURE_CH_ID, ts=probe)
    assert nn['now']['title'] == 'The Avengers'
    assert [u['title'] for u in nn['upcoming']] == [
        'Avengers: Age of Ultron', 'Avengers: Infinity War', 'Avengers: Endgame']
    prog = current_program(_FIXTURE_CH_ID, ts=probe)
    assert prog['magnet']
    clear_epg()

    # --- click decision (the anti-bogus-magnet contract) ---
    assert is_placeholder_magnet(prog['magnet'])  # fixture btih:aaaa...
    assert not is_placeholder_magnet(
        'magnet:?xt=urn:btih:87d6f50611d2f5a070a00e49a7ff40a5dbd6c53a&dn=x')
    # channel payload + placeholder magnet -> SEARCH the slot title
    dec = click_target({'ch': _FIXTURE_CH_ID, 'title': 'The Avengers Collection'}, prog)
    assert dec['action'] == 'search', dec
    assert dec['spec']['title'] == 'The Avengers'
    assert dec['spec']['content'] == 'movie'
    assert dec['spec']['year'] == '2012'
    # real magnet in the guide -> magnet resolve at click
    real = dict(prog, magnet='magnet:?xt=urn:btih:' + 'b' * 40 + '&dn=x')
    dec = click_target({'ch': _FIXTURE_CH_ID}, real)
    assert dec['action'] == 'magnet' and dec['magnet'].endswith('&dn=x')
    # direct flavors
    assert click_target({'url': 'https://cdn/x.m3u8'})['action'] == 'direct'
    assert click_target({'magnet': 'magnet:?xt=urn:btih:' + 'c' * 40},
                        )['action'] == 'magnet'
    # placeholder magnet with NO guide slot -> none (never hits debrid)
    dec = click_target({'magnet': prog['magnet']})
    assert dec['action'] == 'none', dec
    assert click_target({'ch': 'x'})['action'] == 'none'
    # episode detection -> microjen episode search shape
    spec = search_spec({'title': 'The Show', 'sub_title': 'Pilot',
                        'date': '20200101', 'season': '1', 'episode': '3'})
    assert spec == {'title': 'Pilot', 'content': 'episode', 'year': '2020',
                    'show': 'The Show', 'season': '1', 'episode': '3'}, spec

    # --- live-TV join offset (seek) ---
    # slot started 06:00, probe 06:30 -> join at 30 min
    probe = boundary['start'] + timedelta(minutes=30)
    assert seek_offset(prog, ts=probe) == 1800, seek_offset(prog, ts=probe)
    # your log example: 9:41 start, 11:37 now -> 1h56m = 6960s
    assert seek_offset(prog, ts=prog['start'] + timedelta(minutes=116)) == 6960
    # just started (<90s) -> 0, play from the beginning
    assert seek_offset(prog, ts=prog['start'] + timedelta(seconds=30)) == 0
    assert seek_offset(None, ts=probe) == 0
    # never past the slot's own end (stop - 30s cap)
    late = seek_offset(prog, ts=prog['stop'] + timedelta(minutes=60))
    assert late <= (prog['stop'] - prog['start']).total_seconds() - 30
    # click decisions carry the seek
    dec = click_target({'ch': _FIXTURE_CH_ID}, prog, ts=probe)
    assert dec['action'] == 'search' and dec['seek'] == 1800, dec
    dec = click_target({'url': 'https://cdn/x.m3u8'})
    assert dec['seek'] == 0  # live direct streams: no seek

    # --- auto-advance target (next_program) ---
    set_epg(progs)  # re-seeded: the earlier now/next block cleared the cache
    # watched slot 0 (06:00), now still inside slot 0 (early finish):
    # next = slot 1, not yet aired -> play from start
    got = next_program(_FIXTURE_CH_ID, boundary['start'],
                       ts=boundary['start'] + timedelta(minutes=100))
    assert got['title'] == 'Avengers: Age of Ultron' and got['start'] > boundary['start']
    assert seek_offset(got, ts=got['start'] - timedelta(minutes=5)) == 0  # not aired yet
    # watched slot 0, now well into slot 1 -> slot 1 with live join
    ts_mid = progs[1]['start'] + timedelta(minutes=30)
    got = next_program(_FIXTURE_CH_ID, boundary['start'], ts=ts_mid)
    assert got is progs[1], (got['title'], ts_mid)
    assert seek_offset(got, ts=ts_mid) == 1800
    # schedule exhausted: after the last slot, nothing remains
    last = progs[-1]
    assert next_program(_FIXTURE_CH_ID, last['start'],
                        ts=last['stop'] + timedelta(minutes=5)) is None
    # elapsed-only guard: future slots all in the past relative to ts
    # (after last stop) -> None (covered above); and a slot that fully
    # elapsed before ts is never returned as "next"
    ts_late = last['start'] + timedelta(days=3)
    assert next_program(_FIXTURE_CH_ID, progs[0]['start'], ts=ts_late) is None

    # episode-num shapes
    import xml.etree.ElementTree as ET
    assert _parse_episode_num(ET.fromstring(
        '<episode-num system="xmltv_ns">0.5.</episode-num>')) == ('1', '6')
    assert _parse_episode_num(ET.fromstring(
        '<episode-num>S02E05</episode-num>')) == ('2', '5')
    assert _parse_episode_num(ET.fromstring(
        '<episode-num>3x07</episode-num>')) == ('3', '7')
    assert _parse_episode_num(ET.fromstring(
        '<episode-num></episode-num>')) == ('', '')
    assert _parse_episode_num(None) == ('', '')

    # --- parse_xmltv_ts: no-strptime parser (Kodi datetime.strptime bug) ---
    ts = parse_xmltv_ts('20261101060000 -0500')
    assert (ts.year, ts.month, ts.day, ts.hour, ts.minute) == (2026, 11, 1, 6, 0)
    assert ts.utcoffset() == timedelta(hours=-5)
    # colon offset variant + UTC
    assert parse_xmltv_ts('20261101060000 +00:00').utcoffset() == timedelta(0)
    assert parse_xmltv_ts('20261101060000 +0530').utcoffset() == timedelta(hours=5, minutes=30)
    # no offset -> aware (local)
    assert parse_xmltv_ts('20261101060000').tzinfo is not None
    # garbage / invalid dates -> None, never raises
    for bad in ('', None, 'not-a-date', '20261301060000 -0500',
                '20261132060000 -0500', '202611010600'):
        assert parse_xmltv_ts(bad) is None, bad
    # datetime is constructed, never via strptime (survives Kodi's
    # post-teardown None-strptime sessions)
    assert 'strptime(' not in parse_xmltv_ts.__code__.co_names

    print('iptv_m3u self-test: OK  '
          f'({len(progs)} programmes, slot cycle + click-decision verified)')
