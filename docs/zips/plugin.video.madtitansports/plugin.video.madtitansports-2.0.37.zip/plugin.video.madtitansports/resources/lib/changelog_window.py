import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
import os
import json
import threading
import re
import urllib.request
from resources.lib.tool import log
from resources.lib.endpoints import CHANGELOG_URL, CHANGELOG_URL_2

ADDON_ID = "plugin.video.madtitansports"
ADDON = xbmcaddon.Addon(id=ADDON_ID)

CHANGELOG_VERSION_PATH = xbmcvfs.translatePath(
    f"special://userdata/addon_data/{ADDON_ID}/changelog_version.json"
)

CHANGELOG_LOCAL_PATH = xbmcvfs.translatePath(
    f"special://home/addons/{ADDON_ID}/docs/CHANGELOG.md"
)
NAVIGATION_LOCAL_PATH = xbmcvfs.translatePath(
    f"special://home/addons/{ADDON_ID}/docs/navigation.md"
)
PAGES = [
    {"label": "Changelog", "local_path": CHANGELOG_LOCAL_PATH, "url": None},
    {"label": "Navigation and Settings", "local_path": NAVIGATION_LOCAL_PATH, "url": None},
    {"label": "More Info", "local_path": None, "url": CHANGELOG_URL},
    {"label": "Extra Info", "local_path": None, "url": CHANGELOG_URL_2},
]

COLOR_HEADER = "FFFF6D00"
COLOR_SUBHEADER = "FFFFAB40"
COLOR_BOLD = "FFFF6D00"
COLOR_BULLET = "FF80CBC4"
COLOR_TEXT = "FFFFFFFF"

VISIBLE_LINES = 18
SCROLL_STEP = 3
AUTO_SCROLL_DELAY = 8.0
AUTO_SCROLL_SPEED = 1.0
SCROLL_BAR_TOP = 145
SCROLL_BAR_BOTTOM = 505
SCROLL_BAR_HEIGHT = 30

_active_changelog_window = None


def _ensure_dir(path):
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
    except Exception:
        pass


def parse_markdown_to_kodi(text):
    lines = text.split('\n')
    result = []
    for line in lines:
        stripped = line.strip()
        if stripped.startswith('## '):
            result.append(f'[COLOR={COLOR_HEADER}][B]{stripped[3:]}[/B][/COLOR]')
        elif stripped.startswith('### '):
            result.append(f'[COLOR={COLOR_SUBHEADER}][B]{stripped[4:]}[/B][/COLOR]')
        elif stripped.startswith('-'):
            inner = stripped[2:]
            inner = re.sub(r'\*\*(.+?)\*\*', rf'[COLOR={COLOR_BOLD}][B]\1[/B][/COLOR]', inner)
            result.append(f'[COLOR={COLOR_BULLET}]  \u2022 [/COLOR]{inner}')
        elif stripped.startswith('---'):
            result.append(f'[COLOR={COLOR_BULLET}]{"─" * 60}[/COLOR]')
        elif stripped.startswith('**') and stripped.endswith('**'):
            result.append(f'[COLOR={COLOR_BOLD}][B]{stripped[2:-2]}[/B][/COLOR]')
        else:
            inner = re.sub(r'\*\*(.+?)\*\*', rf'[COLOR={COLOR_BOLD}][B]\1[/B][/COLOR]', stripped)
            result.append(f'[COLOR={COLOR_TEXT}]{inner}[/COLOR]')
    return '\n'.join(result)


def _fetch_page_text(page):
    if page.get("local_path") and xbmcvfs.exists(page["local_path"]):
        with xbmcvfs.File(page["local_path"], "r") as f:
            return f.read()
    if page.get("url"):
        cache_path = xbmcvfs.translatePath(
            f"special://userdata/addon_data/{ADDON_ID}/changelog_cache_{PAGES.index(page)}.txt"
        )
        headers = {'User-Agent': 'Mozilla/5.0'}
        req = urllib.request.Request(page["url"], headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=10) as response:
                text = response.read().decode('utf-8')
            _ensure_dir(cache_path)
            with open(cache_path, 'w', encoding='utf-8') as f:
                f.write(text)
            return text
        except Exception as e:
            log(f"Failed to fetch {page['label']}: {e}", level=xbmc.LOGERROR)
            if os.path.exists(cache_path):
                with open(cache_path, 'r', encoding='utf-8') as f:
                    return f.read()
    return f"Failed to load {page.get('label', 'page')}."


class ChangelogWindow(xbmcgui.WindowXML):
    def __init__(self, xml_file, addon_path):
        xbmcgui.WindowXML.__init__(self, xml_file, addon_path, "Default", "720p")
        self._page_index = 0
        self._full_text = ""
        self._display_lines = []
        self._scroll_offset = 0
        self._auto_scroll_timer = None
        self._auto_scroll_running = False
        self._manual_scroll_timer = None

    def _update_textbox(self):
        end = self._scroll_offset + VISIBLE_LINES
        visible = '\n'.join(self._display_lines[self._scroll_offset:end])
        self.getControl(5000).setText(visible)
        max_offset = max(1, len(self._display_lines) - VISIBLE_LINES)
        ratio = self._scroll_offset / max_offset
        bar_y = int(SCROLL_BAR_TOP + ratio * (SCROLL_BAR_BOTTOM - SCROLL_BAR_TOP - SCROLL_BAR_HEIGHT))
        self.getControl(5004).setPosition(1240, bar_y)

    def _start_auto_scroll(self):
        self._stop_auto_scroll()
        self._auto_scroll_running = True
        self._auto_scroll_timer = threading.Timer(AUTO_SCROLL_DELAY, self._auto_scroll_tick)
        self._auto_scroll_timer.daemon = True
        self._auto_scroll_timer.start()

    def _stop_auto_scroll(self):
        self._auto_scroll_running = False
        if self._auto_scroll_timer:
            self._auto_scroll_timer.cancel()
            self._auto_scroll_timer = None

    def _auto_scroll_tick(self):
        if not self._auto_scroll_running:
            return
        max_offset = max(0, len(self._display_lines) - VISIBLE_LINES)
        if self._scroll_offset < max_offset:
            self._scroll_offset += 1
        else:
            self._scroll_offset = 0
        self._update_textbox()
        self._auto_scroll_timer = threading.Timer(AUTO_SCROLL_SPEED, self._auto_scroll_tick)
        self._auto_scroll_timer.daemon = True
        self._auto_scroll_timer.start()

    def _schedule_auto_scroll(self):
        if self._manual_scroll_timer:
            self._manual_scroll_timer.cancel()
        self._manual_scroll_timer = threading.Timer(AUTO_SCROLL_DELAY, self._start_auto_scroll)
        self._manual_scroll_timer.daemon = True
        self._manual_scroll_timer.start()

    def _manual_scroll(self, direction):
        self._stop_auto_scroll()
        if self._manual_scroll_timer:
            self._manual_scroll_timer.cancel()
        max_offset = max(0, len(self._display_lines) - VISIBLE_LINES)
        self._scroll_offset = max(0, min(max_offset, self._scroll_offset + direction * SCROLL_STEP))
        self._update_textbox()
        self._schedule_auto_scroll()

    def _show_page(self, index):
        self._stop_auto_scroll()
        if self._manual_scroll_timer:
            self._manual_scroll_timer.cancel()
        self._page_index = index % len(PAGES)
        page = PAGES[self._page_index]
        raw_text = _fetch_page_text(page)
        self._full_text = parse_markdown_to_kodi(raw_text)
        self._display_lines = self._full_text.split('\n')
        self._scroll_offset = 0
        self._update_textbox()
        next_page = PAGES[(self._page_index + 1) % len(PAGES)]
        self.getControl(8000).setLabel(f"[B]Next Page: {next_page['label']}[/B]")
        self.getControl(5005).setLabel(f"[B]{page['label']}[/B]")
        log(f"Showing page {self._page_index}: {page['label']}")
        self._start_auto_scroll()

    def onInit(self):
        try:
            log("ChangelogWindow onInit started")
            current_version = ADDON.getAddonInfo('version')
            self.setProperty('version', current_version)
            self._show_page(0)
            log("ChangelogWindow onInit complete")
            self.setFocusId(9000)
        except Exception as e:
            log(f"Error initializing changelog: {e}", level=xbmc.LOGERROR)

    def onAction(self, action):
        action_id = action.getId()
        if action_id in (xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK, 92):
            self._stop_auto_scroll()
            if self._manual_scroll_timer:
                self._manual_scroll_timer.cancel()
            save_dont_show_again()
            self.close()
        elif action_id in (xbmcgui.ACTION_SELECT_ITEM, xbmcgui.ACTION_MOUSE_LEFT_CLICK):
            focused = self.getFocusId()
            if focused == 9000:
                self._stop_auto_scroll()
                if self._manual_scroll_timer:
                    self._manual_scroll_timer.cancel()
                save_dont_show_again()
                xbmc.sleep(300)
                self.close()
            elif focused == 8000:
                self._show_page(self._page_index + 1)
            elif focused == 5001:
                self._manual_scroll(-1)
            elif focused == 5002:
                self._manual_scroll(1)
        elif action_id == xbmcgui.ACTION_MOVE_UP:
            focused = self.getFocusId()
            if focused == 5000:
                self._manual_scroll(-1)
            elif focused == 5002:
                self._manual_scroll(-1)
        elif action_id == xbmcgui.ACTION_MOVE_DOWN:
            focused = self.getFocusId()
            if focused == 5000:
                self._manual_scroll(1)
            elif focused == 5001:
                self._manual_scroll(1)
        elif action_id in (xbmcgui.ACTION_MOUSE_WHEEL_UP, xbmcgui.ACTION_MOUSE_WHEEL_DOWN):
            focused = self.getFocusId()
            if focused in (5000, 5001, 5002):
                direction = -1 if action_id == xbmcgui.ACTION_MOUSE_WHEEL_UP else 1
                self._manual_scroll(direction)


def get_saved_version():
    try:
        if os.path.exists(CHANGELOG_VERSION_PATH):
            with open(CHANGELOG_VERSION_PATH, 'r') as f:
                data = json.load(f)
                return data.get('version')
    except Exception:
        pass
    return None


def save_dont_show_again():
    try:
        _ensure_dir(CHANGELOG_VERSION_PATH)
        current_version = ADDON.getAddonInfo('version')
        with open(CHANGELOG_VERSION_PATH, 'w') as f:
            json.dump({'version': current_version, 'dont_show': True}, f)
        log(f"Saved changelog dont_show for version {current_version}")
    except Exception as e:
        log(f"Error saving changelog state: {e}", level=xbmc.LOGERROR)


def check_and_show_changelog(addon_path):
    try:
        current_version = ADDON.getAddonInfo('version')
        log(f"check_and_show_changelog: current={current_version}")

        saved = None
        if os.path.exists(CHANGELOG_VERSION_PATH):
            with open(CHANGELOG_VERSION_PATH, 'r') as f:
                try:
                    saved = json.load(f)
                except Exception:
                    saved = None
            log(f"Saved state: {saved}")
        else:
            log("No changelog_version.json found")

        show = True
        if saved and saved.get('version') == current_version and saved.get('dont_show'):
            show = False

        log(f"Should show changelog: {show}")

        if show:
            _ensure_dir(CHANGELOG_VERSION_PATH)
            with open(CHANGELOG_VERSION_PATH, 'w') as f:
                json.dump({'version': current_version, 'dont_show': False}, f)
            log(f"Creating ChangelogWindow, addon_path={addon_path}")
            global _active_changelog_window
            _active_changelog_window = ChangelogWindow("changelog.xml", addon_path)
            log("Calling ChangelogWindow.doModal()")
            _active_changelog_window.doModal()
            log("ChangelogWindow.doModal() returned")
            _active_changelog_window = None
    except Exception as e:
        log(f"Error showing changelog: {e}", level=xbmc.LOGERROR)
        import traceback
        log(f"{traceback.format_exc()}", level=xbmc.LOGERROR)


def show_changelog_from_tools(addon_path):
    try:
        win = ChangelogWindow("changelog.xml", addon_path)
        win.doModal()
        del win
    except Exception as e:
        log(f"Error showing changelog: {e}", level=xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Error", f"Failed to show changelog: {str(e)}")
