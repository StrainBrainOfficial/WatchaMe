import xbmcgui
import xbmc
import xbmcaddon
import json
from resources.lib.tool import log
from resources.lib import loading_overlay

ADDON_ID = "plugin.video.madtitansports"


class ScraperMixin:

    def _display_scraper_results(self):
        log('_display_scraper_results called')
        win = xbmcgui.Window(10000)
        results_json = win.getProperty('madtitan_scraper_results')
        sources_json = win.getProperty('madtitan_scraper_sources')
        item_json = win.getProperty('madtitan_scraper_item')
        title = win.getProperty('madtitan_scraper_title')
        if not results_json or not sources_json:
            return
        try:
            results = json.loads(results_json)
            sources = json.loads(sources_json)
            item_data = json.loads(item_json) if item_json else {}
        except Exception as e:
            log(f'Failed to parse scraper results: {e}', level=xbmc.LOGERROR)
            return

        items = []
        for i, label in enumerate(results):
            source_data = sources[i] if i < len(sources) else {}
            items.append({
                'title': label,
                'thumbnail': '',
                'fanart': '',
                'summary': '',
                'route': ('scraper_result', source_data),
                'raw': {'title': title, 'source': source_data, 'item': item_data},
            })

        if not items:
            xbmcgui.Dialog().ok("No Results", "No streams found.")
            return

        self.nav_stack.append({
            'items': self.items_data,
            'title': self.current_title,
            'url': self.current_url,
            'selected_idx': self.getControl(100).getSelectedPosition(),
        })

        self.items_data = items
        self.current_title = f'Streams: {title}'
        self.current_url = ''
        self.populate_list()
        self.update_preview(0)

    def _play_scraper_result(self, raw_item):
        log('_play_scraper_result called')
        source_data = raw_item.get('source', {})
        item_info = raw_item.get('item', {})
        url = source_data.get('url', '')
        if not url:
            xbmcgui.Dialog().ok("Error", "No URL available for this source.")
            return

        import resolveurl
        default_icon = xbmcaddon.Addon().getAddonInfo('icon')
        title = item_info.get("title", "Video")
        thumbnail = item_info.get("thumbnail", default_icon)
        plot = item_info.get("summary", "")

        liz = xbmcgui.ListItem(title)
        liz.setInfo('video', {'title': title, 'plot': plot})
        liz.setArt({'thumb': thumbnail, 'icon': thumbnail})

        if resolveurl.HostedMediaFile(url).valid_url():
            url = resolveurl.HostedMediaFile(url).resolve()
            loading_overlay.show()
            xbmc.Player().play(url, liz)
        elif source_data.get("direct"):
            loading_overlay.show()
            xbmc.Player().play(url, liz)
        else:
            xbmcgui.Dialog().ok("Error", "Unable to resolve this source.")
