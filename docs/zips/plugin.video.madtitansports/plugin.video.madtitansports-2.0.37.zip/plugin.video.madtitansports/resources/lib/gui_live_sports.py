import xbmcgui
import xbmc
import xbmcaddon
import re
import time
import json
import base64
import threading
from resources.lib.tool import log
from resources.lib.gui_helpers import strip_color_tags
from resources.lib.playback_monitor import track
from resources.lib import loading_overlay
from resources.lib.endpoints import SPORTS_NBA, SPORTS_COLLEGE_BASEBALL, SPORTS_SOCCER, SPORTS_LEAGUE

ADDON_ID = "plugin.video.madtitansports"


class LiveSportsMixin:

    def _is_live_item(self):
        lst = self.getControl(100)
        idx = lst.getSelectedPosition()
        if idx < 0 or idx >= len(self.items_data):
            return False
        return 'live sports' in strip_color_tags(self.items_data[idx].get('title', '')).lower()

    def _update_top_game(self):
        if not self._live_inprogress:
            return
        idx = self._live_top_idx % len(self._live_inprogress)
        g = self._live_inprogress[idx]
        log(f'Top game #{idx}: {g.get("team1")} vs {g.get("team2")} ({g.get("status")})')
        self.setProperty('live_team1', g.get('team1', ''))
        self.setProperty('live_team2', g.get('team2', ''))
        score_parts = g.get('score', '0 - 0').split(' - ')
        self.setProperty('live_score1', score_parts[0].strip() if len(score_parts) > 0 else '0')
        self.setProperty('live_score2', score_parts[1].strip() if len(score_parts) > 1 else '0')
        self.setProperty('live_status', g.get('status', ''))
        self.setProperty('live_sport', g.get('sport', ''))
        self.setProperty('live_team1_logo', g.get('team1_logo', ''))
        self.setProperty('live_team2_logo', g.get('team2_logo', ''))
        self.setProperty('live_top_label', f'{idx + 1}/{len(self._live_inprogress)}')

        full = g.get('full_status', '')
        if full in ('In Progress', 'Halftime'):
            self.setProperty('live_status_color', 'FF00FF00')
        elif full == 'Final':
            self.setProperty('live_status_color', 'FF888888')
        else:
            self.setProperty('live_status_color', 'FFFFFF00')

    def _show_game_in_preview(self, game_idx):
        if game_idx < 0 or game_idx >= len(self._live_games):
            return
        g = self._live_games[game_idx]
        self.setProperty('live_team1', g.get('team1', ''))
        self.setProperty('live_team2', g.get('team2', ''))
        score_parts = g.get('score', '0 - 0').split(' - ')
        self.setProperty('live_score1', score_parts[0].strip() if len(score_parts) > 0 else '0')
        self.setProperty('live_score2', score_parts[1].strip() if len(score_parts) > 1 else '0')
        self.setProperty('live_status', g.get('status', ''))
        self.setProperty('live_sport', g.get('sport', ''))
        self.setProperty('live_team1_logo', g.get('team1_logo', ''))
        self.setProperty('live_team2_logo', g.get('team2_logo', ''))
        self.setProperty('live_top_label', f'{game_idx + 1}/{len(self._live_games)}')
        full = g.get('full_status', '')
        if full in ('In Progress', 'Halftime'):
            self.setProperty('live_status_color', 'FF00FF00')
        elif full == 'Final':
            self.setProperty('live_status_color', 'FF888888')
        else:
            self.setProperty('live_status_color', 'FFFFFF00')

    def _populate_game_list(self):
        try:
            game_list = self.getControl(510)
            game_list.reset()
            for g in self._live_games[:50]:
                li = xbmcgui.ListItem(label=f"{g['team1']} vs {g['team2']}")
                li.setProperty('game_team1', g.get('team1', ''))
                li.setProperty('game_team2', g.get('team2', ''))
                li.setProperty('game_score', g.get('score', ''))
                li.setProperty('game_sport', g.get('sport', ''))
                status = g.get('status', '')
                full_status = g.get('full_status', '')
                if full_status in ('In Progress', 'Halftime'):
                    li.setProperty('game_status', f'[COLOR lime]{status}[/COLOR]')
                elif full_status == 'Final':
                    li.setProperty('game_status', f'[COLOR gray]{status}[/COLOR]')
                else:
                    li.setProperty('game_status', f'[COLOR yellow]{status}[/COLOR]')
                game_list.addItem(li)
            log(f'Added {game_list.size()} games to game list')
        except Exception as e:
            log(f'Failed to populate game list: {e}', level=xbmc.LOGERROR)

    def _start_live_rotation(self):
        self._live_rotating = False
        xbmc.sleep(100)
        self._live_rotating = True
        self._live_rotation_count = 0
        threading.Thread(target=self._live_rotation_loop, daemon=True).start()

    def _live_rotation_loop(self):
        while self._live_rotating and not self._closing:
            if not self._live_inprogress:
                return
            if not self._is_live_item():
                self._live_rotating = False
                return
            if self._focused_game_list:
                for _ in range(50):
                    if not self._live_rotating or self._closing:
                        return
                    xbmc.sleep(100)
                continue
            self._update_top_game()
            self._live_rotation_count += 1
            if self._live_rotation_count % max(len(self._live_inprogress), 1) == 0:
                self._live_loaded = False
                self._live_rotating = False
                if self._is_live_item():
                    self.load_live_sports()
                return
            self._live_top_idx = (self._live_top_idx + 1) % len(self._live_inprogress)
            for _ in range(50):
                if not self._live_rotating or self._closing:
                    return
                xbmc.sleep(100)

    def _get_enabled_sports(self):
        sports = []
        settings_map = {
            'ls_nfl': 'NFL', 'ls_mlb': 'MLB', 'ls_nba': 'NBA',
            'ls_nhl': 'NHL', 'ls_ncaab': 'NCAAB', 'ls_wnba': 'WNBA',
            'ls_mls': 'MLS', 'ls_cfl': 'CFL', 'ls_ncaabase': 'NCAABASE',
            'ls_la_liga': 'La Liga', 'ls_bundesliga': 'Bundesliga',
            'ls_serie_a': 'Serie A', 'ls_ligue_1': 'Ligue 1',
            'ls_champions_league': 'Champions League',
            'ls_world': 'World'
        }
        settings_found = False
        try:
            addon = xbmcaddon.Addon(id=ADDON_ID)
            for setting_id, sport_name in settings_map.items():
                raw = addon.getSetting(setting_id)
                if raw is not None and raw != '':
                    settings_found = True
                if addon.getSettingBool(setting_id):
                    sports.append(sport_name)
        except Exception:
            pass
        if not sports and not settings_found:
            sports = ['NFL', 'MLB', 'NBA', 'NHL', 'NCAAB', 'WNBA', 'MLS', 'World']
        return sports

    def load_live_sports(self):
        if self._live_loaded or self._live_loading:
            return
        self._live_loading = True
        gen = self._preview_generation
        log('load_live_sports called')
        threading.Thread(target=self._load_live_sports_thread, args=(gen,), daemon=True).start()

    def _load_live_sports_thread(self, gen):
        self.setProperty('live_state', 'loading')
        try:
            from resources.lib.espn_api import fetch_all_scores
        except ImportError:
            try:
                from .resources.lib.espn_api import fetch_all_scores
            except ImportError as e:
                log(f'Failed to import espn_api: {e}', level=xbmc.LOGERROR)
                self._live_loading = False
                self.setProperty('live_state', 'error')
                return

        sports = self._get_enabled_sports()
        log(f'Enabled sports: {sports}')

        if not sports:
            log('No sports enabled')
            self.setProperty('live_state', 'no_sports')
            self._live_loading = False
            return

        try:
            games = fetch_all_scores(sports)
            log(f'fetch_all_scores returned {len(games)} games')
        except Exception as e:
            log(f'fetch_all_scores failed: {e}', level=xbmc.LOGERROR)
            import traceback
            log(traceback.format_exc(), level=xbmc.LOGERROR)
            self._live_loading = False
            self.setProperty('live_state', 'error')
            return

        if gen != self._preview_generation:
            log('load_live_sports: stale generation after fetch, aborting')
            self._live_loading = False
            return

        def _game_sort_key(g):
            fs = g.get('full_status', '')
            if fs in ('In Progress', 'Halftime'):
                return 0
            if fs == 'Final':
                return 2
            return 1
        games.sort(key=_game_sort_key)

        self._live_games = games
        self._live_inprogress = [g for g in games if g.get('full_status', '') in ('In Progress', 'Halftime')]
        if self._live_top_idx >= len(self._live_inprogress):
            self._live_top_idx = 0
        self._live_loaded = True
        self._live_loading = False

        if not games:
            log('No games returned, clearing live properties')
            self.clearProperty('live_team1')
            self.clearProperty('live_team2')
            self.clearProperty('live_score1')
            self.clearProperty('live_score2')
            self.clearProperty('live_status')
            self.clearProperty('live_sport')
            self.clearProperty('live_team1_logo')
            self.clearProperty('live_team2_logo')
            self.clearProperty('live_status_color')
            self.clearProperty('live_top_label')
            self.setProperty('live_state', 'no_games')
            return

        self._live_needs_populate = True
        self.setProperty('live_state', 'loaded')

    def play_sports_event_from_game(self, team1_name, team2_name, sport):
        log(f'play_sports_event_from_game: {team1_name} vs {team2_name} ({sport})')

        def _clean_team(name):
            return re.sub(r"\s*\(.*?\)", "", name).strip().lower()

        team1_name = _clean_team(team1_name)
        team2_name = _clean_team(team2_name)

        if not team1_name or not team2_name:
            return

        def _fuzzy_match(title, t1, t2):
            t = re.sub(r'\[/?[a-z]+.*?\]', '', title.lower())
            t = re.sub(r'[^a-z0-9 ]', '', t)
            t1c = re.sub(r'[^a-z0-9 ]', '', t1)
            t2c = re.sub(r'[^a-z0-9 ]', '', t2)
            return (t1c in t or (t1c.split() and t1c.split()[-1] in t)) and (
                t2c in t or (t2c.split() and t2c.split()[-1] in t))

        sport_lower = sport.lower().strip()
        if "wnba" in sport_lower:
            url = SPORTS_NBA
        elif "ncaabase" in sport_lower or "college baseball" in sport_lower:
            url = SPORTS_COLLEGE_BASEBALL
        elif sport_lower in ["mls", "premier league", "la liga", "bundesliga",
                             "serie a", "ligue 1", "champions league", "world", "world cup", "uefa", "europa league", "fifa"]:
            url = SPORTS_SOCCER
        else:
            sport_key = sport_lower.replace(" ", "")
            url = SPORTS_LEAGUE.format(sport_key)

        import requests
        progress = xbmcgui.DialogProgress()
        progress.create('Searching Streams', f'Searching for {team1_name} vs {team2_name}...')
        try:
            response = requests.get(url, timeout=10)
            response.raise_for_status()
            data = response.json()
        except Exception as e:
            progress.close()
            xbmcgui.Dialog().ok("Error", f"Failed to load game data: {str(e)}")
            return

        stream_links = []
        stream_names = []
        items = data.get('items', [])
        if not items:
            progress.close()
            xbmcgui.Dialog().ok("No Streams", "No games found in data source")
            return

        for idx, game in enumerate(items):
            if progress.iscanceled():
                progress.close()
                return
            progress.update(
                25 + int((idx / float(max(1, len(items)))) * 70),
                f'Checking game {idx + 1} of {len(items)}...'
            )
            if (game.get('type') == 'item' and game.get('title')
                    and _fuzzy_match(game.get('title', ''), team1_name, team2_name)):
                for i, link in enumerate(game.get('link', [])):
                    clean_url = link
                    stream_name = f"Stream {i + 1}"
                    if '(' in link and ')' in link:
                        stream_name = link[link.rindex('(')+1:link.rindex(')')].strip()
                        clean_url = link[:link.rindex('(')].strip()
                    elif '[COLOR' in link and '[/COLOR]' in link:
                        clean_url = re.sub(r'\[COLOR.*?\](.*?)\[/COLOR\]', r'\1', link).strip()
                        if '(' in clean_url and ')' in clean_url:
                            stream_name = clean_url[clean_url.rindex('(')+1:clean_url.rindex(')')].strip()
                            clean_url = clean_url[:clean_url.rindex('(')].strip()
                    stream_links.append(clean_url)
                    stream_names.append(stream_name)

        progress.close()
        if not stream_links:
            xbmcgui.Dialog().ok("No Streams", "No streams found for this game")
            return

        choice = xbmcgui.Dialog().select('Choose Stream', stream_names)
        if choice is not None and choice >= 0:
            selected_url = stream_links[choice]
            game_title = f"{team1_name} vs {team2_name}"
            jet_link = {"address": selected_url, "name": game_title}
            play_item = {"title": game_title, "sportjetextractors": [jet_link]}
            encoded = base64.urlsafe_b64encode(json.dumps(play_item).encode()).decode()
            fallback_plugin = f'plugin://{ADDON_ID}/play_video/{encoded}'
            self._pending_recently_played = {'title': game_title, 'thumbnail': '', 'fallback_link': fallback_plugin, 'time': time.time()}
            self._save_state(0)
            track("play", channel_name=game_title, url=selected_url, source="espn_live", sport=sport)
            xbmc.Player().stop()
            loading_overlay.show()
            if selected_url.lower().startswith('plugin://'):
                if selected_url.lower().startswith(f'plugin://{ADDON_ID.lower()}/'):
                    xbmc.executebuiltin(f'RunPlugin({selected_url})')
                else:
                    play_item = {"title": game_title, "link": selected_url}
                    enc = base64.urlsafe_b64encode(json.dumps(play_item).encode()).decode()
                    xbmc.executebuiltin(f'RunPlugin(plugin://{ADDON_ID}/play_video/{enc})')
            else:
                list_item = xbmcgui.ListItem(game_title)
                list_item.setInfo('video', {'title': game_title})
                list_item.setProperty('IsPlayable', 'true')
                try:
                    from youtube_guide import cancel_youtube_playback
                    cancel_youtube_playback()
                except Exception:
                    pass
                xbmc.Player().play(selected_url, list_item)
