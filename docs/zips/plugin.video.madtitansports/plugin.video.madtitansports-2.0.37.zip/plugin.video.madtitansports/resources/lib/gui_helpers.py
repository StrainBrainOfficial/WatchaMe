import re
import json
import base64
import urllib.parse

ADDON_ID = "plugin.video.madtitansports"


def strip_color_tags(text):
    if not text:
        return ''
    text = re.sub(r'\[/?COLOR[^\]]*\]', '', text)
    text = re.sub(r'\[/?B\]', '', text)
    text = re.sub(r'\[/?I\]', '', text)
    return text.strip()


def get_route_for_item(item):
    link = item.get('link', '')
    item_type = item.get('type', '')
    pvr_search = item.get('pvr_sport_search', '')
    file_iptv = item.get('file_iptv', '')
    sportjetextractors = item.get('sportjetextractors', '')

    if pvr_search:
        return ('pvr_search', pvr_search)

    if file_iptv:
        country = item.get('country', '*')
        if file_iptv == 'recent':
            return ('file_iptv_recent', '')
        elif file_iptv == '*':
            return ('file_iptv_search_country', '')
        else:
            return ('file_iptv_search', file_iptv)

    search_music = item.get('search_music', '')
    if search_music:
        return ('search_music', search_music)

    ytdlp = item.get('ytdlp', '')
    if ytdlp == 'search':
        return ('youtube_search', '')
    elif ytdlp and ytdlp != 'search':
        return ('youtube_play', ytdlp)

    fmstream = item.get('fmstream', '')
    if fmstream.startswith('search'):
        return ('fmstream_search', fmstream)
    elif fmstream == 'featured':
        return ('fmstream_featured', '')
    elif fmstream.startswith('country'):
        return ('fmstream_country', fmstream)
    elif fmstream:
        return ('fmstream_country', fmstream)

    fmstream_next = item.get('fmstream_next', '')
    if fmstream_next:
        return ('fmstream_next', fmstream_next)

    espn = item.get('ESPN', '')
    if espn:
        return ('espn_plus', espn)

    jetextractors_settings = item.get('jetextractors_settings', '')
    if jetextractors_settings:
        return ('jetextractors_manage', jetextractors_settings)

    telegram_server_filter = item.get('telegram_server_filter', '')
    if telegram_server_filter:
        return ('telegram_filter', telegram_server_filter)

    homeiptv_server_filter = item.get('homeiptv_server_filter', '')
    if homeiptv_server_filter:
        return ('homeiptv_filter', homeiptv_server_filter)

    xtream = item.get('xtream', '')
    if xtream and isinstance(xtream, dict):
        action = xtream.get('action', '')
        address = xtream.get('address', '')
        username = xtream.get('username', '')
        password = xtream.get('password', '')
        cat = xtream.get('cat', '')
        if action in ('input', 'previous', 'clear'):
            return ('xtream_action', json.dumps({'action': action}))
        elif action in ('categories', 'category') and address:
            val = {'action': action, 'address': address, 'username': username, 'password': password}
            if cat:
                val['cat'] = cat
            return ('xtream_genres', json.dumps(val))

    mac = item.get('mac', '')
    if mac and isinstance(mac, dict):
        action = mac.get('action', '')
        address = mac.get('address', '')
        mac_addr = mac.get('mac', '')
        username = mac.get('username', '')
        password = mac.get('password', '')
        genre = mac.get('genre', '')
        page = mac.get('page', '')
        mac_link = mac.get('link', '')
        title = mac.get('title', '')
        if action in ('input', 'previous', 'clear'):
            return ('mac_action', json.dumps({'action': action}))
        elif action in ('genres', 'genre') and address:
            val = {'action': action, 'address': address, 'mac': mac_addr, 'username': username, 'password': password}
            if genre:
                val['genre'] = genre
            if page:
                val['page'] = page
            return ('mac_genres', json.dumps(val))
        elif action == 'play' and address:
            val = {'action': 'play', 'address': address, 'mac': mac_addr, 'username': username, 'password': password, 'link': mac_link}
            if title:
                val['title'] = title
            return ('mac_play', json.dumps(val))

    myiptv_remote = item.get('myiptv_remote', '')
    if myiptv_remote:
        if myiptv_remote == 'menu':
            return ('myiptv_remote_menu', '')
        elif myiptv_remote == 'search_input' or myiptv_remote == '*':
            return ('myiptv_remote_search', '')
        elif myiptv_remote == 'categories':
            return ('myiptv_remote_categories', '')
        elif myiptv_remote.startswith('genre/'):
            return ('myiptv_remote_genre', myiptv_remote)
        elif myiptv_remote == 'full_search_input':
            return ('plugin', f'plugin://{ADDON_ID}/myiptv_remote/full_search_input')
        elif myiptv_remote == 'recent':
            return ('plugin', f'plugin://{ADDON_ID}/myiptv_remote/recent')
        elif myiptv_remote.startswith('search/'):
            term = myiptv_remote.replace('search/', '', 1)
            return ('myiptv_remote_search_term', term)
        elif myiptv_remote.startswith('full_search/'):
            term = myiptv_remote.replace('full_search/', '', 1)
            return ('plugin', f'plugin://{ADDON_ID}/myiptv_remote/full_search/{term}')
        else:
            return ('plugin', f'plugin://{ADDON_ID}/myiptv_remote/{myiptv_remote}')

    if sportjetextractors and isinstance(sportjetextractors, str):
        return ('jet_action', sportjetextractors)

    if sportjetextractors and isinstance(sportjetextractors, list):
        return ('list_pick', sportjetextractors)

    if not link or link == 'ignore':
        return None

    link_str = str(link)

    if link_str.startswith('tmdb/') or link_str.startswith('tmdb/tv'):
        return ('tmdb', link_str)

    if link_str.startswith('trakt/'):
        return ('trakt', link_str)

    if item_type == 'dir' and isinstance(link, str):
        return ('dir', link)

    if item_type == 'script' and isinstance(link, str):
        script_item = urllib.parse.quote_plus(link)
        return ('action', f'/run_script/{script_item}')

    if item_type == 'plugin' and isinstance(link, str):
        link_lower = link.lower()
        if link_lower == 'resolveurl_auth':
            return ('resolveurl_auth', '')
        elif link_lower == 'resolveurl_settings':
            return ('resolveurl_settings', '')
        else:
            plug_item = urllib.parse.quote_plus(link)
            return ('action', f'/run_plug/{plug_item}')

    if isinstance(link, list):
        return ('list_pick', link)

    if item_type == 'item' or item_type == '':
        link_str = str(link)
        if link_str.lower() == 'settings':
            return ('action', '/settings')
        elif link_str.lower() == 'clear_cache':
            return ('action', '/clear_cache')
        elif link_str.lower() == 'refresh_menu' or link_str.lower() == f'plugin://{ADDON_ID}/refresh_menu':
            return ('action', '/refresh_menu')
        elif link_str.lower().startswith('message/'):
            return ('action', f'/show_message/{link_str}')
        elif link_str.lower().startswith('pvr_sport_search/'):
            pvr_val = link_str[len('pvr_sport_search/'):]
            return ('pvr_search', pvr_val)
        elif link_str.lower().startswith('search_json/'):
            return ('action', f'/{link_str}')
        elif link_str.lower().startswith('plugin://'):
            return ('plugin', link_str)
        elif link_str.lower().startswith('is_ffmpeg://'):
            encoded = base64.urlsafe_b64encode(
                bytes(json.dumps({"link": link_str}), 'utf-8')
            ).decode('utf-8')
            return ('action', f'/play_video/{encoded}')
        else:
            encoded = base64.urlsafe_b64encode(
                bytes(json.dumps(item), 'utf-8')
            ).decode('utf-8')
            return ('action', f'/play_video/{encoded}')

    return None


def fetch_json(url, use_cache=False, db=None, session=None):
    if use_cache and db:
        cached = db.get(url)
        if cached:
            return cached[0]
    try:
        response = session.get(url, timeout=15).text
        if use_cache and db:
            db.set(url, response)
        return response
    except Exception:
        return None
