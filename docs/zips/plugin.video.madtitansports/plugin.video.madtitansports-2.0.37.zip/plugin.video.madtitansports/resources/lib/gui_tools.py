import xbmcgui
import xbmc
import xbmcaddon
import os
import json
from resources.lib.tool import log
from resources.lib.gui_helpers import strip_color_tags
from xbmcvfs import translatePath

ADDON_ID = "plugin.video.madtitansports"


class ToolsPreviewMixin:
    """Mixin for Tools and Addon Settings preview panel and grid content."""

    def _populate_settings_grid(self):
        """Populate control 531 with settings items."""
        grid = self.getControl(531)
        grid.reset()
        for ch in self._tvnet_channels:
            li = xbmcgui.ListItem(label=ch['title'])
            li.setProperty('setting_value', ch.get('setting_value', ''))
            grid.addItem(li)
        log(f'_populate_settings_grid: {grid.size()} items')

    def _load_tools_preview(self):
        """Load File IPTV Settings preview and populate grid with current values."""
        if self._tvnet_settings_mode == 'file_iptv' and self._tvnet_channels:
            log('_load_tools_preview: already loaded, skipping')
            return
        log('_load_tools_preview: loading File IPTV settings preview')
        self.setProperty('preview_mode', 'tv_networks')
        self.setProperty('preview_title', 'FILE IPTV SETTINGS')
        self.setProperty('tvnet_title', 'FILE IPTV SETTINGS')
        self.setProperty('tvnet_settings', 'file_iptv')

        self._tvnet_channels = []
        self._tvnet_settings_mode = 'file_iptv'

        config = {}
        try:
            from resources.lib.plugins.file_iptv import config as fiptv_config
            config = fiptv_config
        except ImportError as e:
            log(f'_load_tools_preview: failed to import file_iptv config: {e}')
        servers_txt = config.get('servers_txt', '')
        if servers_txt:
            masked_servers_txt = "." * max(8, min(len(servers_txt), 24))
        else:
            masked_servers_txt = ""
        sp_count = 0
        try:
            from resources.lib.stream_prefs import StreamPreferences
            sp_count = StreamPreferences().count()
        except Exception:
            pass

        settings_items = [
            ('─── Stream Preferences ───────', None, 'separator'),
            (f'[COLOR yellow]Manage Stream Preferences[/COLOR]  ({sp_count} saved)', 'action_manage_stream_prefs', 'action'),
            ('Total results per search', 'total_result_limit', 'int'),
            ('Per-server result cap', 'per_address_limit', 'int'),
            ('Servers TXT', 'masked_servers_txt', 'str'),
            ('Recheck interval (hours)', 'recheck_hours', 'int'),
            ('Min connections', 'min_connections', 'int'),
            ('Max servers per update', 'max_servers_per_update', 'int'),
            ('Stream check', 'stream_check_enabled', 'bool'),
            ('Stream check candidates', 'stream_check_candidates', 'int'),
            ('Proxy mode', 'proxy_mode', 'select'),
            ('Auto-update', 'auto_update_enabled', 'bool'),
            ('Exclude groups', 'exclude_groups', 'list'),
            ('Exclude names', 'exclude_names', 'list'),
            ('Test channel keywords', 'test_channel_keywords', 'list'),
            ('M3U sources', 'm3u_sources', 'list'),
            ('Debug logging', 'debug_logging', 'bool'),
            ('─── Actions ──────────────────', None, 'separator'),
            ('[COLOR yellow]Update Servers Now[/COLOR]', 'action_update', 'action'),
            ('[COLOR yellow]Manage Servers[/COLOR]', 'action_manage', 'action'),
            ('[COLOR yellow]Reset / Delete Database[/COLOR]', 'action_reset', 'action'),
            ('[COLOR yellow]View Config File[/COLOR]', 'action_open_config', 'action'),
            ('[COLOR yellow]View DB Info[/COLOR]', 'action_open_db', 'action'),
            ('─── Stream Preferences ───────', None, 'separator'),
            (f'[COLOR yellow]Manage Stream Preferences[/COLOR]  ({sp_count} saved)', 'action_manage_stream_prefs', 'action'),
        ]

        for i, (name, key, type_) in enumerate(settings_items):
            if type_ == 'separator':
                self._tvnet_channels.append({
                    'title': name,
                    'thumbnail': '',
                    'channel_number': '',
                    'now_show': '',
                    'setting_value': '',
                    'now_time': '',
                    'now_plot': '',
                    'raw': {'setting_name': name, 'setting_key': None, 'setting_type': 'separator', 'current_value': None},
                })
                continue

            if type_ == 'action':
                self._tvnet_channels.append({
                    'title': name,
                    'thumbnail': '',
                    'channel_number': '',
                    'now_show': '[COLOR yellow]Click to run[/COLOR]',
                    'setting_value': '',
                    'now_time': '',
                    'now_plot': '',
                    'raw': {'setting_name': name, 'setting_key': key, 'setting_type': 'action', 'current_value': None},
                })
                continue

            value = config.get(key, '')
            if type_ == 'bool':
                display = '[COLOR lime]ON[/COLOR]' if value else '[COLOR red]OFF[/COLOR]'
                raw_display = 'ON' if value else 'OFF'
            elif type_ == 'select':
                display = f'[COLOR cyan]{value}[/COLOR]'
                raw_display = str(value)
            elif type_ == 'list':
                if isinstance(value, list):
                    display = f'[COLOR cyan]{", ".join(value)}[/COLOR]' if value else '[COLOR grey]empty[/COLOR]'
                    raw_display = str(value)
                else:
                    display = f'[COLOR cyan]{value}[/COLOR]'
                    raw_display = str(value)
            else:
                display = f'[COLOR cyan]{value}[/COLOR]'
                raw_display = str(value)

            self._tvnet_channels.append({
                'title': f'{i+1:02d}. {name}',
                'thumbnail': '',
                'channel_number': f'{i+1:02d}',
                'now_show': display,
                'setting_value': display,
                'now_time': '',
                'now_plot': '',
                'raw': {'setting_name': name, 'setting_key': key, 'setting_type': type_, 'current_value': config.get(key)},
            })

        self._tvnet_loaded = True
        self._tvnet_loading = False
        self._tvnet_idx = 0
        log(f'_load_tools_preview: populated {len(self._tvnet_channels)} settings items')

        self._populate_settings_grid()
        if self._tvnet_channels:
            self._update_featured_tool(0)
        self.setProperty('tvnet_count', f'{len(self._tvnet_channels)} Settings')

    def _load_addon_settings_preview(self):
        """Load Addon Settings preview and populate grid with current values."""
        if self._tvnet_settings_mode == 'addon' and self._tvnet_channels:
            log('_load_addon_settings_preview: already loaded, skipping')
            return
        log('_load_addon_settings_preview: loading addon settings preview')
        self.setProperty('preview_mode', 'tv_networks')
        self.setProperty('preview_title', 'ADDON SETTINGS')
        self.setProperty('tvnet_title', 'ADDON SETTINGS')
        self.setProperty('tvnet_settings', 'addon')

        self._tvnet_channels = []
        self._tvnet_settings_mode = 'addon'

        addon = xbmcaddon.Addon(id=ADDON_ID)
        
        config = {}
        try:
            from resources.lib.plugins.file_iptv import config as fiptv_config
            config = fiptv_config
        except ImportError as e:
            log(f'_load_tools_preview: failed to import file_iptv config: {e}')
        servers_txt = config.get('servers_txt', '')
        if servers_txt:
            masked_servers_txt = "." * max(8, min(len(servers_txt), 24))
        else:
            masked_servers_txt = ""
        sp_count = 0
        try:
            from resources.lib.stream_prefs import StreamPreferences
            sp_count = StreamPreferences().count()
        except Exception:
            pass

        settings_categories = [
            ('Preferences', [
                ('─── Stream Preferences ───────', None, 'separator'),
                (f'[COLOR yellow]Manage Stream Preferences[/COLOR]  ({sp_count} saved)', 'action_manage_stream_prefs', 'action'),
                ('Auto-play preferences', 'auto_play_prefs', 'bool'),
                ('Disable Preview Panel', 'disable_preview', 'bool'),
                
            ]),
            ('GUI Settings', [
                ('───[COLORaqua] GUI Settings[/COLOR] ──────────────────', None, 'separator'),
                ('Enable GUI', 'use_gui', 'bool'),
                
                # ('Server URL', 'server_front_url', 'str'),
                ('Recently Played count', 'recently_played_count', 'int'),
            ]),
            ('Live Scores', [
                ('─── [COLORaqua]Cache Time for[/COLOR]', None, 'separator'),
                ('[COLORaqua]    grabbing scores[/COLOR]. [COLORorange]5 mins default[/COLOR] ──────────────────', None, 'separator'),
                ('Cache TTL', 'ls_cache_ttl', 'int'),
                ('─── [COLORaqua]Sports Selection[/COLOR] ──────────────────', None, 'separator'),
                ('NFL', 'ls_nfl', 'bool'),
                ('MLB', 'ls_mlb', 'bool'),
                ('NBA', 'ls_nba', 'bool'),
                ('NHL', 'ls_nhl', 'bool'),
                ('NCAAB', 'ls_ncaab', 'bool'),
                ('WNBA', 'ls_wnba', 'bool'),
                ('MLS', 'ls_mls', 'bool'),
                ('CFL', 'ls_cfl', 'bool'),
                ('College Baseball', 'ls_ncaabase', 'bool'),
                ('La Liga', 'ls_la_liga', 'bool'),
                ('Bundesliga', 'ls_bundesliga', 'bool'),
                ('Serie A', 'ls_serie_a', 'bool'),
                ('Ligue 1', 'ls_ligue_1', 'bool'),
                ('Champions League', 'ls_champions_league', 'bool'),
                ('World', 'ls_world', 'bool'),
            ]),
            ('Dev Mode', [
                ('─── [COLORaqua]Debugging[/COLOR] ──────────────────', None, 'separator'),
                ('Debug Logging', 'debug_logging', 'bool'),
                ('Debugging Mode', 'debug', 'bool'),
            ]),
            ('─── Actions ──────────────────', [
                ('─── [COLORaqua]Actions[/COLOR] ──────────────────', None, 'separator'),
                ('[COLOR yellow]Clear All Cache[/COLOR]', 'action_clear_cache', 'action'),
                ('[COLOR yellow]Clear All Cache (2)[/COLOR]', 'action_clear_cache2', 'action'),
            ]),
        ]

        num = 1
        for category, items in settings_categories:
            for name, key, type_ in items:
                if type_ == 'separator':
                    self._tvnet_channels.append({
                        'title': name,
                        'thumbnail': '',
                        'channel_number': '',
                        'now_show': '',
                        'setting_value': '',
                        'now_time': '',
                        'now_plot': '',
                        'raw': {'setting_name': name, 'setting_key': None, 'setting_type': 'separator', 'current_value': None},
                    })
                    continue

                if type_ == 'action':
                    self._tvnet_channels.append({
                        'title': f'{num:02d}. {name}',
                        'thumbnail': '',
                        'channel_number': f'{num:02d}',
                        'now_show': '[COLOR yellow]Click to run[/COLOR]',
                        'setting_value': '',
                        'now_time': category,
                        'now_plot': '',
                        'raw': {'setting_name': name, 'setting_key': key, 'setting_type': 'action', 'current_value': None, 'category': category},
                    })
                    num += 1
                    continue

                raw_val = addon.getSetting(key)
                if type_ == 'bool':
                    display = '[COLOR lime]ON[/COLOR]' if raw_val == 'true' else '[COLOR red]OFF[/COLOR]'
                elif type_ == 'int':
                    display = f'[COLOR cyan]{raw_val}[/COLOR]'
                else:
                    display = f'[COLOR cyan]{raw_val}[/COLOR]'

                self._tvnet_channels.append({
                    'title': f'{num:02d}. {name}',
                    'thumbnail': '',
                    'channel_number': f'{num:02d}',
                    'now_show': display,
                    'setting_value': display,
                    'now_time': category,
                    'now_plot': '',
                    'raw': {'setting_name': name, 'setting_key': key, 'setting_type': type_, 'current_value': raw_val, 'category': category},
                })
                num += 1

        self._tvnet_loaded = True
        self._tvnet_loading = False
        self._tvnet_idx = 0
        log(f'_load_addon_settings_preview: populated {len(self._tvnet_channels)} settings items')

        self._populate_settings_grid()
        if self._tvnet_channels:
            self._update_featured_tool(0)
        self.setProperty('tvnet_count', f'{len(self._tvnet_channels)} Settings')

    def _update_featured_tool(self, idx):
        """Update preview panel with selected settings item info."""
        if idx < 0 or idx >= len(self._tvnet_channels):
            return
        ch = self._tvnet_channels[idx]
        self.setProperty('tvnet_logo', ch['thumbnail'] or '')
        self.setProperty('tvnet_name', ch['title'])
        self.setProperty('tvnet_number', ch['channel_number'])
        self.setProperty('tvnet_show', ch.get('setting_value', ''))
        self.setProperty('tvnet_time', ch.get('now_time', ''))
        self.setProperty('tvnet_plot', '')
        total = len(self._tvnet_channels)
        self.setProperty('tvnet_count', f'{idx + 1}/{total} Settings')
        log(f'_update_featured_tool idx={idx} setting="{ch["title"]}"')

    def _handle_settings_click(self, idx):
        """Handle click on a settings item - show inline edit dialog."""
        if idx < 0 or idx >= len(self._tvnet_channels):
            return
        ch = self._tvnet_channels[idx]
        raw = ch.get('raw', {})
        setting_type = raw.get('setting_type', '')
        setting_key = raw.get('setting_key', '')
        setting_name = raw.get('setting_name', '')
        current_value = raw.get('current_value', '')

        if setting_type == 'separator':
            return

        if setting_type == 'action':
            if setting_key == 'action_clear_cache':
                self._clear_all_cache()
            elif setting_key == 'action_clear_cache2':
                self._clear_all_cache2()
            elif setting_key == 'revalidate':
                self._edit_jetextractors_setting(idx, setting_key, setting_name, current_value)
            elif setting_key == 'revalidate_homeiptv':
                self._edit_jetextractors_setting(idx, setting_key, setting_name, current_value)
            else:
                self._handle_file_iptv_action(setting_key)
            return

        if setting_type == 'toggle_filter':
            self._toggle_server_filter(idx, setting_key, raw.get('filter_type', ''))
            return

        if self._tvnet_settings_mode == 'file_iptv':
            self._edit_file_iptv_setting(idx, setting_key, setting_name, current_value)
        elif self._tvnet_settings_mode == 'addon':
            self._edit_addon_setting(idx, setting_key, setting_name, current_value)
        elif self._tvnet_settings_mode == 'jetextractors settings':
            self._edit_jetextractors_setting(idx, setting_key, setting_name, current_value)

    def _toggle_server_filter(self, idx, server_addr, filter_type):
        """Toggle block/unblock for a server in Telegram or HomeIPTV filter."""
        addon_icon = xbmcaddon.Addon().getAddonInfo('icon')
        ch = self._tvnet_channels[idx]
        raw = ch.get('raw', {})
        is_blocked = raw.get('current_value', False)

        try:
            if filter_type == 'telegram':
                from jetextractors.util.TelegramStore import (
                    get_excluded_portals, add_excluded_portal, remove_excluded_portal,
                )
            elif filter_type == 'homeiptv':
                from jetextractors.util.homeiptv_store import (
                    get_excluded_portals, add_excluded_portal, remove_excluded_portal,
                )
            elif filter_type == 'myiptv':
                from jetextractors.util.myiptv_store import (
                    get_excluded_portals, add_excluded_portal, remove_excluded_portal,
                )
            else:
                return

            if is_blocked:
                remove_excluded_portal(server_addr)
                raw['current_value'] = False
                new_status = '[COLOR lime]active[/COLOR]'
                xbmc.executebuiltin(
                    'Notification(%s Filter,Unblocked %s,3000,%s)' % (filter_type.title(), server_addr, addon_icon)
                )
            else:
                add_excluded_portal(server_addr)
                raw['current_value'] = True
                new_status = '[COLOR red]BLOCKED[/COLOR]'
                xbmc.executebuiltin(
                    'Notification(%s Filter,Blocked %s,3000,%s)' % (filter_type.title(), server_addr, addon_icon)
                )

            ch['now_show'] = new_status
            ch['setting_value'] = new_status
            grid = self.getControl(531)
            if idx < grid.size():
                grid.getListItem(idx).setLabel(ch['title'])
            self._update_featured_tool(idx)
            log(f'_toggle_server_filter: {filter_type} {server_addr} -> blocked={not is_blocked}')
        except ImportError as e:
            log(f'_toggle_server_filter: import failed: {e}')
            xbmcgui.Dialog().ok('Server Filter', f'Module not available:\n{e}')

    def _handle_file_iptv_action(self, action_key):
        """Handle File IPTV action button clicks."""
        # from xbmcvfs import translatePath
        import sqlite3 as _sqlite3

        addon = xbmcaddon.Addon(id=ADDON_ID)

        if action_key == 'action_update':
            dlg = xbmcgui.Dialog()
            if not dlg.yesno('Update Servers', 'Run a full server update now?\nThis may take a while.'):
                return
            try:
                from resources.lib.plugins.file_iptv import FileIPTV, init_db, update_m3u_playlists
                init_db()
                fiptv = FileIPTV()
                stats = fiptv.update_servers(show_progress=True, show_summary=True)
                update_m3u_playlists()
                dlg.notification('File IPTV', 'Update complete', xbmcgui.NOTIFICATION_INFO, 5000)
                log(f'_handle_file_iptv_action: update done, stats={stats}')
                self._refresh_settings_grid('file_iptv')
            except Exception as e:
                log(f'_handle_file_iptv_action: update failed: {e}')
                dlg.ok('Update Error', str(e))

        elif action_key == 'action_manage':
            try:
                from resources.lib.plugins.file_iptv import DB_PATH, validate_server, store_server_channels
                self._manage_servers(DB_PATH, validate_server, store_server_channels)
            except Exception as e:
                log(f'_handle_file_iptv_action: manage failed: {e}')
                xbmcgui.Dialog().ok('Manage Servers', f'Error: {e}')

        elif action_key == 'action_reset':
            dlg = xbmcgui.Dialog()
            if not dlg.yesno('Reset Database', 'Delete the File IPTV database?\nAll servers and channels will be removed.'):
                return
            try:
                from resources.lib.plugins.file_iptv import DB_PATH
                if os.path.exists(DB_PATH):
                    os.remove(DB_PATH)
                    log(f'_handle_file_iptv_action: deleted DB: {DB_PATH}')
                dlg.ok('Reset Complete', 'Database deleted.\nRun Update Servers to rebuild.')
                self._refresh_settings_grid('file_iptv')
            except Exception as e:
                log(f'_handle_file_iptv_action: reset failed: {e}')
                dlg.ok('Reset Error', str(e))

        elif action_key == 'action_open_config':
            try:
                from resources.lib.plugins.file_iptv import CONFIG_PATH
                if os.path.exists(CONFIG_PATH):
                    with open(CONFIG_PATH, 'r', encoding='utf-8') as f:
                        content = f.read()
                    dlg = xbmcgui.Dialog()
                    dlg.textviewer('file_iptv_config.json', content)
                    log(f'_handle_file_iptv_action: showed config file')
                else:
                    xbmcgui.Dialog().ok('Config File', f'Not found:\n{CONFIG_PATH}')
            except Exception as e:
                log(f'_handle_file_iptv_action: open config failed: {e}')

        elif action_key == 'action_open_db':
            try:
                from resources.lib.plugins.file_iptv import DB_PATH
                if os.path.exists(DB_PATH):
                    size_kb = os.path.getsize(DB_PATH) / 1024
                    servers = 0
                    channels = 0
                    valid = 0
                    try:
                        with _sqlite3.connect(DB_PATH) as conn:
                            cur = conn.cursor()
                            cur.execute('SELECT COUNT(*) FROM servers')
                            servers = cur.fetchone()[0]
                            cur.execute('SELECT COUNT(*) FROM channels')
                            channels = cur.fetchone()[0]
                            cur.execute('SELECT COUNT(*) FROM servers WHERE is_valid = 1')
                            valid = cur.fetchone()[0]
                    except Exception:
                        pass
                    profile = translatePath(addon.getAddonInfo('profile'))
                    xbmcgui.Dialog().ok(
                        'Database Info',
                        f'Path: {DB_PATH}\n\n'
                        f'Size: {size_kb:.1f} KB\n'
                        f'Total Servers: {servers}\n'
                        f'Valid Servers: {valid}\n'
                        f'Total Channels: {channels}\n\n'
                        f'Folder: {profile}'
                    )
                else:
                    xbmcgui.Dialog().ok('Database', 'DB file does not exist yet.\nRun Update Servers first.')
            except Exception as e:
                log(f'_handle_file_iptv_action: db info failed: {e}')

        elif action_key == 'action_manage_stream_prefs':
            try:
                from resources.lib.stream_prefs import show_manage_dialog
                show_manage_dialog()
            except Exception as e:
                log(f'_handle_file_iptv_action: stream prefs manage failed: {e}')
                xbmcgui.Dialog().ok('Stream Preferences', f'Error: {e}')

    def _manage_servers(self, DB_PATH, validate_server_fn, store_server_channels_fn):
        """Manage File IPTV servers: test, update, delete, toggle visibility."""
        import sqlite3 as _sqlite3
        import time as _time

        with _sqlite3.connect(DB_PATH) as conn:
            conn.row_factory = _sqlite3.Row
            cur = conn.cursor()
            cur.execute("""
                SELECT s.address,
                       s.username,
                       s.password,
                       s.last_checked,
                       s.is_valid,
                       COALESCE(s.search_enabled, 1) AS search_enabled,
                       COALESCE(s.max_connections, 0) AS max_connections
                FROM servers s
                GROUP BY s.address, s.username, s.password
                ORDER BY s.last_checked DESC
                LIMIT 200
            """)
            servers = [dict(r) for r in cur.fetchall()]

        if not servers:
            xbmcgui.Dialog().ok('Manage Servers', 'No servers in database.\nRun Update Servers first.')
            return

        server_list = []
        for row in servers:
            ts = _time.strftime(
                '%Y-%m-%d %H:%M',
                _time.localtime(row['last_checked']),
            ) if row['last_checked'] else 'Never'
            valid = row.get('is_valid', 0)
            visible = '[COLORgreen]ON[/COLOR]' if row.get('search_enabled', 1) else '[COLORred]OFF[/COLOR]'
            status = '[COLORlime]Valid[/COLOR]' if valid else '[COLORred]Invalid[/COLOR]'
            server_list.append(f'[{visible}] [{status}] {row["address"]} ({row["username"][:12]}...) - {ts}')

        while True:
            idx = xbmcgui.Dialog().select('Manage Servers', server_list)
            if idx is None or idx < 0:
                break

            selected = servers[idx]
            addr = selected['address']
            user = selected['username']
            pw = selected['password']

            action = xbmcgui.Dialog().select(
                f'Server: {addr}',
                [
                    'Test server',
                    'Update server now',
                    'Delete server',
                    'Toggle in search results',
                    'Back',
                ],
            )
            if action is None or action < 0 or action == 4:
                continue

            if action == 0:
                result = validate_server_fn((addr, user, pw))
                if isinstance(result, tuple):
                    panel_data, max_conn = result
                    ch_count = len(panel_data.get('available_channels', {}))
                    xbmcgui.Dialog().ok('Test Server', f'Server OK\nMax connections: {max_conn}\nChannels: {ch_count}')
                elif result is False:
                    xbmcgui.Dialog().ok('Test Server', 'Server failed validation.\n(See log for details.)')
                else:
                    xbmcgui.Dialog().ok('Test Server', 'Transient error.\n(See log for details.)')
                continue

            if action == 1:
                result = validate_server_fn((addr, user, pw))
                if isinstance(result, tuple):
                    panel_data, max_conn = result
                    ch_count = len(panel_data.get('available_channels', {}))
                    stored = store_server_channels_fn((addr, user, pw), panel_data, max_conn)
                    if stored:
                        xbmcgui.Dialog().ok('Update Server', f'Updated.\nChannels: {ch_count}')
                    else:
                        xbmcgui.Dialog().ok('Update Server', 'Validated but failed to store channels.')
                elif result is False:
                    try:
                        with _sqlite3.connect(DB_PATH) as conn:
                            cur = conn.cursor()
                            cur.execute('UPDATE servers SET is_valid = 0 WHERE address = ? AND username = ? AND password = ?', (addr, user, pw))
                            cur.execute('DELETE FROM channels WHERE address = ? AND username = ? AND password = ?', (addr, user, pw))
                            conn.commit()
                        xbmcgui.Dialog().ok('Update Server', 'Server invalid. Marked invalid and channels removed.')
                        selected['is_valid'] = 0
                    except Exception as e:
                        xbmcgui.Dialog().ok('Update Server', f'Error: {e}')
                else:
                    xbmcgui.Dialog().ok('Update Server', 'Transient error.')
                continue

            if action == 2:
                if not xbmcgui.Dialog().yesno('Delete Server', f'Delete {addr}?\nAll channels will be removed.'):
                    continue
                try:
                    with _sqlite3.connect(DB_PATH) as conn:
                        cur = conn.cursor()
                        cur.execute('DELETE FROM channels WHERE address = ? AND username = ? AND password = ?', (addr, user, pw))
                        cur.execute('DELETE FROM servers WHERE address = ? AND username = ? AND password = ?', (addr, user, pw))
                        conn.commit()
                    del servers[idx]
                    del server_list[idx]
                    xbmcgui.Dialog().ok('Delete Server', f'Deleted {addr}')
                    if not servers:
                        break
                except Exception as e:
                    xbmcgui.Dialog().ok('Delete Server', f'Error: {e}')
                continue

            if action == 3:
                try:
                    with _sqlite3.connect(DB_PATH) as conn:
                        cur = conn.cursor()
                        cur.execute('UPDATE servers SET search_enabled = CASE COALESCE(search_enabled, 1) WHEN 1 THEN 0 ELSE 1 END WHERE address = ? AND username = ? AND password = ?', (addr, user, pw))
                        conn.commit()
                    current = 1 if selected.get('search_enabled', 1) else 0
                    new_val = 0 if current else 1
                    selected['search_enabled'] = new_val
                    vis = '[COLORgreen]ON[/COLOR]' if new_val else '[COLORred]OFF[/COLOR]'
                    valid_s = '[COLORlime]Valid[/COLOR]' if selected.get('is_valid', 0) else '[COLORred]Invalid[/COLOR]'
                    ts = _time.strftime('%Y-%m-%d %H:%M', _time.localtime(selected['last_checked'])) if selected['last_checked'] else 'Never'
                    server_list[idx] = f'[{vis}] [{valid_s}] {addr} ({user[:12]}...) - {ts}'
                except Exception as e:
                    xbmcgui.Dialog().ok('Toggle Error', str(e))

    def _edit_file_iptv_setting(self, idx, key, name, current_value):
        """Edit a File IPTV config setting inline."""
        try:
            from resources.lib.plugins.file_iptv import config, save_config
        except ImportError as e:
            log(f'_edit_file_iptv_setting: failed to import: {e}')
            xbmcgui.Dialog().ok('Error', 'File IPTV module not available.')
            return

        dlg = xbmcgui.Dialog()

        if key in ('total_result_limit', 'per_address_limit', 'recheck_hours', 'min_connections', 'max_servers_per_update', 'stream_check_candidates'):
            new_val = dlg.input(name, str(current_value), type=xbmcgui.INPUT_NUMERIC)
            if new_val is None or new_val == '':
                return
            try:
                config[key] = int(new_val)
            except ValueError:
                config[key] = 0
            save_config()
            log(f'_edit_file_iptv_setting: {key} = {config[key]}')

        elif key == 'masked_servers_txt':
            new_val = dlg.input(name, str(current_value))
            if new_val is None:
                return
            if new_val.strip():
                config['servers_txt'] = new_val.strip()
                save_config()
                log(f'_edit_file_iptv_setting: servers_txt = {config["servers_txt"]}')

        elif key in ('stream_check_enabled', 'auto_update_enabled', 'debug_logging'):
            config[key] = not current_value
            save_config()
            log(f'_edit_file_iptv_setting: {key} = {config[key]}')

        elif key == 'proxy_mode':
            options = ['auto', 'jetproxy', 'direct']
            pick = dlg.select(name, options)
            if pick is None or pick < 0:
                return
            config[key] = options[pick]
            save_config()
            log(f'_edit_file_iptv_setting: {key} = {config[key]}')

        elif key in ('exclude_groups', 'exclude_names', 'test_channel_keywords', 'm3u_sources'):
            current_str = ', '.join(current_value) if isinstance(current_value, list) else str(current_value)
            new_val = dlg.input(name, current_str)
            if new_val is None:
                return
            config[key] = [x.strip() for x in new_val.split(',') if x.strip()]
            save_config()
            log(f'_edit_file_iptv_setting: {key} = {config[key]}')

        self._refresh_settings_grid('file_iptv')

    def _edit_addon_setting(self, idx, key, name, current_value):
        """Edit an addon setting inline."""
        addon = xbmcaddon.Addon(id=ADDON_ID)
        dlg = xbmcgui.Dialog()

        if key in ('use_gui', 'ls_nfl', 'ls_mlb', 'ls_nba', 'ls_nhl',
                    'ls_ncaab', 'ls_wnba', 'ls_mls', 'ls_cfl',
                    'ls_ncaabase', 'ls_la_liga', 'ls_bundesliga',
                    'ls_serie_a', 'ls_ligue_1', 'ls_champions_league', 'ls_world',
                    'debug_logging', 'debug', 'auto_play_prefs', 'disable_preview'):
            new_val = 'false' if current_value == 'true' else 'true'
            addon.setSetting(key, new_val)
            log(f'_edit_addon_setting: {key} = {new_val}')

        elif key in ('recently_played_count', 'ls_cache_ttl'):
            new_val = dlg.input(name, str(current_value), type=xbmcgui.INPUT_NUMERIC)
            if new_val is None or new_val == '':
                return
            addon.setSetting(key, str(new_val))
            log(f'_edit_addon_setting: {key} = {new_val}')

        elif key == 'server_front_url':
            new_val = dlg.input(name, str(current_value))
            if new_val is None:
                return
            if new_val.strip():
                addon.setSetting(key, new_val.strip())
                log(f'_edit_addon_setting: {key} = {new_val.strip()}')

        self._refresh_settings_grid('addon')

    def _load_jetextractors_settings_preview(self):
        """Load JetExtractors settings preview and populate grid with current values."""
        if self._tvnet_settings_mode == 'jetextractors' and self._tvnet_channels:
            log('_load_jetextractors_settings_preview: already loaded, skipping')
            return
        log('_load_jetextractors_settings_preview: loading jetextractors settings preview')
        self.setProperty('preview_mode', 'tv_networks')
        self.setProperty('preview_title', 'JETEXTRACTORS SETTINGS')
        self.setProperty('tvnet_title', 'JETEXTRACTORS SETTINGS')
        self.setProperty('tvnet_settings', 'jetextractors settings')

        self._tvnet_channels = []
        self._tvnet_settings_mode = 'jetextractors settings'

        try:
            from jetextractors.tools import (
                is_debug_enabled, set_debug_logging,
                is_telegramxtream_enabled, set_telegramxtream_enabled,
                is_homeiptv_enabled, set_homeiptv_enabled,
                is_myiptv_enabled, set_myiptv_enabled,
                revalidate_telegramxtream, revalidate_homeiptv,
            )

            settings_items = [
                ('Debug Logging', 'debug_logging', 'bool', is_debug_enabled, set_debug_logging),
                ('TelegramXtream Extractor', 'telegramxtream_enabled', 'bool', is_telegramxtream_enabled, set_telegramxtream_enabled),
                ('HomeIPTV Extractor', 'homeiptv_enabled', 'bool', is_homeiptv_enabled, set_homeiptv_enabled),
                ('MyIPTV Extractor', 'myiptv_enabled', 'bool', is_myiptv_enabled, set_myiptv_enabled),
                ('Revalidate TelegramXtream', 'revalidate', 'action', None, None),
                ('Revalidate HomeIPTV', 'revalidate_homeiptv', 'action', None, None),
            ]

            num = 1
            for name, key, type_, getter, setter in settings_items:
                if type_ == 'action':
                    display = '[COLOR cyan]Click to run[/COLOR]'
                    value = None
                else:
                    value = getter()
                    display = '[COLOR lime]ON[/COLOR]' if value else '[COLOR red]OFF[/COLOR]'

                self._tvnet_channels.append({
                    'title': f'{num:02d}. {name}',
                    'thumbnail': '',
                    'channel_number': f'{num:02d}',
                    'now_show': display,
                    'setting_value': display,
                    'now_time': 'JetExtractors',
                    'now_plot': '',
                    'raw': {'setting_name': name, 'setting_key': key, 'setting_type': type_, 'current_value': value},
                })
                num += 1

        except ImportError as e:
            log(f'_load_jetextractors_settings_preview: import failed: {e}')
            self._tvnet_channels.append({
                'title': 'Module not available',
                'thumbnail': '',
                'channel_number': '',
                'now_show': f'[COLOR red]{e}[/COLOR]',
                'setting_value': '',
                'now_time': '',
                'now_plot': '',
                'raw': {'setting_name': 'error', 'setting_key': '', 'setting_type': 'error', 'current_value': None},
            })

        self._tvnet_loaded = True
        self._tvnet_loading = False
        self._tvnet_idx = 0
        log(f'_load_jetextractors_settings_preview: populated {len(self._tvnet_channels)} settings items')

        self._populate_settings_grid()
        if self._tvnet_channels:
            self._update_featured_tool(0)
        self.setProperty('tvnet_count', f'{len(self._tvnet_channels)} Settings')

    def _load_telegram_filter_preview(self):
        """Load Telegram server filter preview and populate grid with server status."""
        if self._tvnet_settings_mode == 'telegram_filter':
            log('_load_telegram_filter_preview: already loaded, skipping')
            return
        log('_load_telegram_filter_preview: loading telegram filter preview')
        self._tvnet_settings_mode = 'telegram_filter'
        self.setProperty('preview_mode', 'tv_networks')
        self.setProperty('preview_title', 'TELEGRAM SERVERS')
        self.setProperty('tvnet_title', 'TELEGRAM SERVERS')
        self.setProperty('tvnet_settings', 'telegram_filter')

        self._tvnet_channels = []

        try:
            from jetextractors.util.TelegramStore import (
                get_excluded_portals, load_channels,
            )
            data = load_channels()
            portals = {}
            for ch in data.get("channels", []):
                p = ch.get("portal", "")
                if p and p not in portals:
                    portals[p] = ch.get("name", "")
            excluded = set(get_excluded_portals())
            sorted_portals = sorted(portals.keys())

            for i, addr in enumerate(sorted_portals, 1):
                is_blocked = addr in excluded
                status = '[COLOR red]BLOCKED[/COLOR]' if is_blocked else '[COLOR lime]active[/COLOR]'
                self._tvnet_channels.append({
                    'title': f'{i:02d}. {addr}',
                    'thumbnail': '',
                    'channel_number': f'{i:02d}',
                    'now_show': status,
                    'setting_value': status,
                    'now_time': 'Telegram',
                    'now_plot': '',
                    'raw': {'setting_name': addr, 'setting_key': addr, 'setting_type': 'toggle_filter', 'current_value': is_blocked, 'filter_type': 'telegram'},
                })
        except ImportError as e:
            log(f'_load_telegram_filter_preview: import failed: {e}')
            self._tvnet_channels.append({
                'title': 'Module not available',
                'thumbnail': '',
                'channel_number': '',
                'now_show': f'[COLOR red]{e}[/COLOR]',
                'setting_value': '',
                'now_time': '',
                'now_plot': '',
                'raw': {'setting_name': 'error', 'setting_key': '', 'setting_type': 'error', 'current_value': None},
            })

        self._tvnet_loaded = True
        self._tvnet_loading = False
        self._tvnet_idx = 0
        log(f'_load_telegram_filter_preview: populated {len(self._tvnet_channels)} server items')

        self._populate_settings_grid()
        if self._tvnet_channels:
            self._update_featured_tool(0)
        self.setProperty('tvnet_count', f'{len(self._tvnet_channels)} Servers')

    def _load_homeiptv_filter_preview(self):
        """Load HomeIPTV server filter preview and populate grid with server status."""
        if self._tvnet_settings_mode == 'homeiptv_filter':
            log('_load_homeiptv_filter_preview: already loaded, skipping')
            return
        log('_load_homeiptv_filter_preview: loading homeiptv filter preview')
        self._tvnet_settings_mode = 'homeiptv_filter'
        self.setProperty('preview_mode', 'tv_networks')
        self.setProperty('preview_title', 'HOMEIPTV SERVERS')
        self.setProperty('tvnet_title', 'HOMEIPTV SERVERS')
        self.setProperty('tvnet_settings', 'homeiptv_filter')

        self._tvnet_channels = []

        try:
            from jetextractors.util.homeiptv_store import (
                get_excluded_portals, load_channels,
            )
            data = load_channels()
            portals = {}
            for ch in data.get("channels", []):
                p = ch.get("portal", "")
                if p and p not in portals:
                    portals[p] = ch.get("name", "")
            excluded = set(get_excluded_portals())
            sorted_portals = sorted(portals.keys())

            for i, addr in enumerate(sorted_portals, 1):
                is_blocked = addr in excluded
                status = '[COLOR red]BLOCKED[/COLOR]' if is_blocked else '[COLOR lime]active[/COLOR]'
                self._tvnet_channels.append({
                    'title': f'{i:02d}. {addr}',
                    'thumbnail': '',
                    'channel_number': f'{i:02d}',
                    'now_show': status,
                    'setting_value': status,
                    'now_time': 'HomeIPTV',
                    'now_plot': '',
                    'raw': {'setting_name': addr, 'setting_key': addr, 'setting_type': 'toggle_filter', 'current_value': is_blocked, 'filter_type': 'homeiptv'},
                })
        except ImportError as e:
            log(f'_load_homeiptv_filter_preview: import failed: {e}')
            self._tvnet_channels.append({
                'title': 'Module not available',
                'thumbnail': '',
                'channel_number': '',
                'now_show': f'[COLOR red]{e}[/COLOR]',
                'setting_value': '',
                'now_time': '',
                'now_plot': '',
                'raw': {'setting_name': 'error', 'setting_key': '', 'setting_type': 'error', 'current_value': None},
            })

        self._tvnet_loaded = True
        self._tvnet_loading = False
        self._tvnet_idx = 0
        log(f'_load_homeiptv_filter_preview: populated {len(self._tvnet_channels)} server items')

        self._populate_settings_grid()
        if self._tvnet_channels:
            self._update_featured_tool(0)
        self.setProperty('tvnet_count', f'{len(self._tvnet_channels)} Servers')

    def _load_myiptv_filter_preview(self):
        """Load MyIPTV server filter preview and populate grid with server status."""
        if self._tvnet_settings_mode == 'myiptv_filter':
            log('_load_myiptv_filter_preview: already loaded, skipping')
            return
        log('_load_myiptv_filter_preview: loading myiptv filter preview')
        self._tvnet_settings_mode = 'myiptv_filter'
        self.setProperty('preview_mode', 'tv_networks')
        self.setProperty('preview_title', 'MYIPTV SERVERS')
        self.setProperty('tvnet_title', 'MYIPTV SERVERS')
        self.setProperty('tvnet_settings', 'myiptv_filter')

        self._tvnet_channels = []

        try:
            from jetextractors.util.myiptv_store import (
                get_excluded_portals, load_channels,
            )
            data = load_channels()
            portals = {}
            for ch in data.get("channels", []):
                p = ch.get("portal", "")
                if p and p not in portals:
                    portals[p] = ch.get("name", "")
            excluded = set(get_excluded_portals())
            sorted_portals = sorted(portals.keys())

            for i, addr in enumerate(sorted_portals, 1):
                is_blocked = addr in excluded
                status = '[COLOR red]BLOCKED[/COLOR]' if is_blocked else '[COLOR lime]active[/COLOR]'
                self._tvnet_channels.append({
                    'title': f'{i:02d}. {addr}',
                    'thumbnail': '',
                    'channel_number': f'{i:02d}',
                    'now_show': status,
                    'setting_value': status,
                    'now_time': 'MyIPTV',
                    'now_plot': '',
                    'raw': {'setting_name': addr, 'setting_key': addr, 'setting_type': 'toggle_filter', 'current_value': is_blocked, 'filter_type': 'myiptv'},
                })
        except ImportError as e:
            log(f'_load_myiptv_filter_preview: import failed: {e}')
            self._tvnet_channels.append({
                'title': 'Module not available',
                'thumbnail': '',
                'channel_number': '',
                'now_show': f'[COLOR red]{e}[/COLOR]',
                'setting_value': '',
                'now_time': '',
                'now_plot': '',
                'raw': {'setting_name': 'error', 'setting_key': '', 'setting_type': 'error', 'current_value': None},
            })

        self._tvnet_loaded = True
        self._tvnet_loading = False
        self._tvnet_idx = 0
        log(f'_load_myiptv_filter_preview: populated {len(self._tvnet_channels)} server items')

        self._populate_settings_grid()
        if self._tvnet_channels:
            self._update_featured_tool(0)
        self.setProperty('tvnet_count', f'{len(self._tvnet_channels)} Servers')

    def _edit_jetextractors_setting(self, idx, key, name, current_value):
        """Edit a JetExtractors setting inline via jetextractors.tools."""
        addon_icon = xbmcaddon.Addon().getAddonInfo('icon')

        try:
            from jetextractors.tools import (
                is_debug_enabled, set_debug_logging,
                is_telegramxtream_enabled, set_telegramxtream_enabled,
                is_homeiptv_enabled, set_homeiptv_enabled,
                is_myiptv_enabled, set_myiptv_enabled,
                revalidate_telegramxtream,
            )
        except ImportError as e:
            log(f'_edit_jetextractors_setting: import failed: {e}')
            xbmcgui.Dialog().ok('JetExtractors', f'Module not available:\n{e}')
            return

        if key == 'debug_logging':
            new_val = not bool(current_value)
            set_debug_logging(new_val)
            state = 'enabled' if new_val else 'disabled'
            xbmc.executebuiltin(
                'Notification(JetExtractors,Debug Logging %s,3000,%s)' % (state, addon_icon)
            )
            log(f'_edit_jetextractors_setting: debug_logging = {new_val}')

        elif key == 'telegramxtream_enabled':
            new_val = not bool(current_value)
            set_telegramxtream_enabled(new_val)
            state = 'enabled' if new_val else 'disabled'
            xbmc.executebuiltin(
                'Notification(JetExtractors,TelegramXtream %s,3000,%s)' % (state, addon_icon)
            )
            if new_val:
                try:
                    revalidate_telegramxtream()
                    xbmc.executebuiltin(
                        'Notification(JetExtractors,Revalidating TelegramXtream...,5000,%s)' % addon_icon
                    )
                except Exception as e:
                    log(f'_edit_jetextractors_setting: revalidate_telegramxtream failed: {e}', level=xbmc.LOGERROR)
            log(f'_edit_jetextractors_setting: telegramxtream_enabled = {new_val}')

        elif key == 'homeiptv_enabled':
            new_val = not bool(current_value)
            set_homeiptv_enabled(new_val)
            state = 'enabled' if new_val else 'disabled'
            xbmc.executebuiltin(
                'Notification(JetExtractors,HomeIPTV %s,3000,%s)' % (state, addon_icon)
            )
            if new_val:
                try:
                    revalidate_homeiptv()
                    xbmc.executebuiltin(
                        'Notification(JetExtractors,Revalidating HomeIPTV...,5000,%s)' % addon_icon
                    )
                except Exception as e:
                    log(f'_edit_jetextractors_setting: revalidate_homeiptv failed: {e}', level=xbmc.LOGERROR)
            log(f'_edit_jetextractors_setting: homeiptv_enabled = {new_val}')

        elif key == 'myiptv_enabled':
            new_val = not bool(current_value)
            set_myiptv_enabled(new_val)
            state = 'enabled' if new_val else 'disabled'
            xbmc.executebuiltin(
                'Notification(JetExtractors,MyIPTV %s,3000,%s)' % (state, addon_icon)
            )
            log(f'_edit_jetextractors_setting: myiptv_enabled = {new_val}')

        elif key == 'revalidate':
            try:
                revalidate_telegramxtream()
                xbmc.executebuiltin(
                    'Notification(JetExtractors,Revalidating TelegramXtream...,3000,%s)' % addon_icon
                )
            except Exception as e:
                xbmc.executebuiltin(
                    'Notification(JetExtractors,Error: %s,3000,%s)' % (str(e), addon_icon)
                )
            log(f'_edit_jetextractors_setting: revalidate triggered')

        elif key == 'revalidate_homeiptv':
            try:
                revalidate_homeiptv()
                xbmc.executebuiltin(
                    'Notification(JetExtractors,Revalidating HomeIPTV...,3000,%s)' % addon_icon
                )
            except Exception as e:
                xbmc.executebuiltin(
                    'Notification(JetExtractors,Error: %s,3000,%s)' % (str(e), addon_icon)
                )
            log(f'_edit_jetextractors_setting: revalidate_homeiptv triggered')

        else:
            log(f'_edit_jetextractors_setting: unknown key {key}')
            return

        self._refresh_settings_grid('jetextractors')

    def _refresh_settings_grid(self, settings_mode):
        """Refresh the settings grid after a value change."""
        self._tvnet_channels = []
        self._tvnet_loaded = False
        self._tvnet_settings_mode = None

        if settings_mode == 'file_iptv':
            self._load_tools_preview()
        elif settings_mode == 'addon':
            self._load_addon_settings_preview()
        elif settings_mode == 'jetextractors settings':
            self._load_jetextractors_settings_preview()
        elif settings_mode == 'telegram_filter':
            self._load_telegram_filter_preview()
        elif settings_mode == 'homeiptv_filter':
            self._load_homeiptv_filter_preview()
        elif settings_mode == 'myiptv_filter':
            self._load_myiptv_filter_preview()

        grid = self.getControl(531)
        if grid.size() > 0:
            grid.selectItem(0)
            self._update_featured_tool(0)
        self._focused_channel_grid = True
        self.setFocus(grid)
        
    def _clear_all_cache2(self):
        """Clear all addon cache files from userdata."""
        dlg = xbmcgui.Dialog()
        if not dlg.yesno('Clear All Cache2', 'Clear all addon cache?\n\nThis will remove:\n- Settings\n- Jetconfig\n- IPTV db\n- TELE IPTV db\n- USERDATA\n\nSettings.'):
            return

        # from xbmcvfs import translatePath
        cleared = []
        errors = []

        addon = xbmcaddon.Addon(id=ADDON_ID)
        profile = translatePath(addon.getAddonInfo('profile'))
        addon_path = addon.getAddonInfo('path') 
        
        cache_files2 = [
            ('Settings', os.path.join(profile, 'settings.xml')),
            ('Jetconfig', os.path.join(profile, 'config.json')),
            ('IPTV db', os.path.join(profile, 'file_iptv.db')),
            ('TELE IPTV db', os.path.join(profile, 'tele_iptv.db')),
            ('USERDATA', os.path.join(profile, 'user_uuid.txt')),
        ]
        for name, path in cache_files2:
            try:
                if os.path.exists(path):
                    os.remove(path)
                    cleared.append(name)
            except Exception as e:
                errors.append(f'{name}: {e}')  
                
        summary = f'Cleared {len(cleared)} item(s):' + '\n' + ', '.join(cleared)
        if errors:
            summary += f'\n\n{len(errors)} error(s):' + '\n' + ', '.join(errors)

        dlg.notification('MadTitan', f'{len(cleared)} cache(s) cleared', addon.getAddonInfo('icon'), 4000, sound=False)
        log(f'_clear_all_cache2: cleared={cleared}, errors={errors}')
        self._refresh_settings_grid('addon')

    def _clear_all_cache(self):
        """Clear all addon cache files from userdata."""
        dlg = xbmcgui.Dialog()
        if not dlg.yesno('Clear All Cache', 'Clear all addon cache?\n\nThis will remove:\n- URL response cache\n- ESPN scores cache\n- ESPN+ cache\n- Recently played history\n- PVR search history\n- File/Tele IPTV search history\n- Changelog cache\n\nSettings and server data will NOT be affected.'):
            return

        # from xbmcvfs import translatePath
        cleared = []
        errors = []

        addon = xbmcaddon.Addon(id=ADDON_ID)
        profile = translatePath(addon.getAddonInfo('profile'))
        addon_path = addon.getAddonInfo('path')

        cache_files = [
            ('ESPN Scores Cache', os.path.join(profile, 'scores_cache.json')),
            ('ESPN+ Cache', os.path.join(profile, 'espn_plus_cache.json')),
            ('Recently Played', os.path.join(profile, 'recently_played.json')),
            ('PVR Search Cache', os.path.join(profile, 'pvr_sport_search_cache.json')),
            ('File IPTV Recent', os.path.join(profile, 'file_iptv_recent.json')),
            ('Tele IPTV Recent', os.path.join(profile, 'tele_iptv_recent.json')),
            ('Changelog Version', os.path.join(profile, 'changelog_version.json')),
            ('Changelog Cache 1', os.path.join(profile, 'changelog_cache_1.txt')),
            ('Changelog Cache 2', os.path.join(profile, 'changelog_cache_2.txt')),
            ('Changelog Cache 3', os.path.join(profile, 'changelog_cache_3.txt')),
            ('Changelog Cache 4', os.path.join(profile, 'changelog_cache_4.txt')),
            ('Changelog Cache 5', os.path.join(profile, 'changelog_cache_5.txt'))
        ]
        

        for name, path in cache_files:
            try:
                if os.path.exists(path):
                    os.remove(path)
                    cleared.append(name)
            except Exception as e:
                errors.append(f'{name}: {e}')

        in_memory_caches = [
            ('TV Network Cache', '_tvnet_cache'),
            ('Live Games Cache', '_live_games'),
            ('TMDB Movies Cache', '_tmdb_movies'),
        ]
        for attr_name, attr_key in in_memory_caches:
            try:
                if hasattr(self, attr_key):
                    val = getattr(self, attr_key)
                    if isinstance(val, (list, dict)):
                        val.clear()
                        cleared.append(attr_name)
            except Exception as e:
                errors.append(f'{attr_name}: {e}')

        try:
            if self.db:
                self.db.cache_reset('clear')
                cleared.append('DI URL Cache')
        except Exception as e:
            errors.append(f'DI Cache: {e}')

        try:
            from resources.lib.espn_api import clear_cache as espn_clear
            espn_clear()
            cleared.append('ESPN API Cache')
        except Exception as e:
            errors.append(f'ESPN API Cache: {e}')

        summary = f'Cleared {len(cleared)} item(s):' + '\n' + ', '.join(cleared)
        if errors:
            summary += f'\n\n{len(errors)} error(s):' + '\n' + ', '.join(errors)

        dlg.notification('MadTitan', f'{len(cleared)} cache(s) cleared', addon.getAddonInfo('icon'), 4000, sound=False)
        log(f'_clear_all_cache: cleared={cleared}, errors={errors}')
        self._refresh_settings_grid('addon')

    def _jetextractors_manage(self, action_val):
        """Handle JetExtractors Settings items in the GUI."""
        log('_jetextractors_manage: opening JetExtractors settings')
        try:
            from jetextractors.tools import (
                is_debug_enabled, set_debug_logging,
                is_telegramxtream_enabled, set_telegramxtream_enabled,
                is_homeiptv_enabled, set_homeiptv_enabled,
                revalidate_telegramxtream, revalidate_homeiptv,
            )
            addon_icon = xbmcaddon.Addon().getAddonInfo('icon')

            settings = [
                {"key": "debug_logging", "label": "Debug Logging", "getter": is_debug_enabled, "setter": set_debug_logging, "type": "toggle"},
                {"key": "telegramxtream_enabled", "label": "TelegramXtream Extractor", "getter": is_telegramxtream_enabled, "setter": set_telegramxtream_enabled, "type": "toggle"},
                {"key": "homeiptv_enabled", "label": "HomeIPTV Extractor", "getter": is_homeiptv_enabled, "setter": set_homeiptv_enabled, "type": "toggle"},
                {"key": "revalidate", "label": "Revalidate TelegramXtream", "action": revalidate_telegramxtream, "type": "action"},
                {"key": "revalidate_homeiptv", "label": "Revalidate HomeIPTV", "action": revalidate_homeiptv, "type": "action"},
            ]

            while True:
                items = []
                for setting in settings:
                    if setting.get("type") == "action":
                        label = f"[COLOR cyan]{setting['label']}[/COLOR]"
                    else:
                        enabled = setting["getter"]()
                        status = "[COLOR lime]ON[/COLOR]" if enabled else "[COLOR red]OFF[/COLOR]"
                        label = f"{status}  {setting['label']}"
                    items.append(label)

                chosen = xbmcgui.Dialog().select(
                    "JetExtractors Settings (select to toggle)",
                    items,
                    preselect=-1,
                )

                if chosen == -1:
                    break

                selected = settings[chosen]
                if selected.get("type") == "action":
                    try:
                        selected["action"]()
                    except Exception as e:
                        xbmc.executebuiltin(
                            'Notification(JetExtractors,Error: %s,3000,%s)' % (str(e), addon_icon)
                        )
                    else:
                        xbmc.executebuiltin(
                            'Notification(JetExtractors,%s running...,3000,%s)' % (selected["label"], addon_icon)
                        )
                else:
                    current = selected["getter"]()
                    selected["setter"](not current)
                    new_state = "enabled" if not current else "disabled"
                    xbmc.executebuiltin(
                        'Notification(JetExtractors,%s %s,3000,%s)' % (selected["label"], new_state, addon_icon)
                    )
                    if not current and selected["key"] == "telegramxtream_enabled":
                        try:
                            revalidate_telegramxtream()
                            xbmc.executebuiltin(
                                'Notification(JetExtractors,Revalidating TelegramXtream...,5000,%s)' % addon_icon
                            )
                        except Exception as e:
                            log(f'_jetextractors_manage: revalidate_telegramxtream failed: {e}', level=xbmc.LOGERROR)
                    elif not current and selected["key"] == "homeiptv_enabled":
                        try:
                            revalidate_homeiptv()
                            xbmc.executebuiltin(
                                'Notification(JetExtractors,Revalidating HomeIPTV...,5000,%s)' % addon_icon
                            )
                        except Exception as e:
                            log(f'_jetextractors_manage: revalidate_homeiptv failed: {e}', level=xbmc.LOGERROR)
        except ImportError as e:
            log(f'_jetextractors_manage: import failed: {e}')
            xbmcgui.Dialog().ok('JetExtractors Settings', f'Module not available:\n{e}')

    def _telegram_filter(self, action_val):
        """Handle Telegram Server Filter items in the GUI."""
        log('_telegram_filter: opening Telegram server filter')
        try:
            from jetextractors.util.TelegramStore import (
                get_excluded_portals, add_excluded_portal, remove_excluded_portal,
                load_channels, remove_portal_channels,
            )
            addon_icon = xbmcaddon.Addon().getAddonInfo('icon')

            data = load_channels()
            portals = {}
            for ch in data.get("channels", []):
                p = ch.get("portal", "")
                if p and p not in portals:
                    portals[p] = ch.get("name", "")

            excluded = set(get_excluded_portals())

            if not portals:
                xbmcgui.Dialog().ok("Server Filter", "No servers found. Run a Telegram search first.")
                return

            sorted_portals = sorted(portals.keys())

            while True:
                items = []
                for addr in sorted_portals:
                    status = "[COLOR red]BLOCKED[/COLOR]" if addr in excluded else "[COLOR lime]active[/COLOR]"
                    label = f"{status}  {addr}"
                    items.append(label)

                chosen = xbmcgui.Dialog().select(
                    "Telegram Servers (select to toggle block)",
                    items,
                    preselect=-1,
                )

                if chosen == -1:
                    break

                selected_addr = sorted_portals[chosen]

                if selected_addr in excluded:
                    remove_excluded_portal(selected_addr)
                    excluded.discard(selected_addr)
                    xbmc.executebuiltin('Notification(Server Filter,Unblocked %s,3000,%s)' % (selected_addr, addon_icon))
                else:
                    add_excluded_portal(selected_addr)
                    excluded.add(selected_addr)
                    try:
                        remove_portal_channels(selected_addr)
                    except Exception:
                        pass
                    xbmc.executebuiltin('Notification(Server Filter,Blocked %s,3000,%s)' % (selected_addr, addon_icon))
        except ImportError as e:
            log(f'_telegram_filter: import failed: {e}')
            xbmcgui.Dialog().ok('Telegram Server Filter', f'Module not available:\n{e}')

    def _homeiptv_filter(self, action_val):
        """Handle HomeIPTV Server Filter items in the GUI."""
        log('_homeiptv_filter: opening HomeIPTV server filter')
        try:
            from jetextractors.util.homeiptv_store import (
                get_excluded_portals, add_excluded_portal, remove_excluded_portal,
                load_channels, remove_portal_channels,
            )
            addon_icon = xbmcaddon.Addon().getAddonInfo('icon')

            data = load_channels()
            portals = {}
            for ch in data.get("channels", []):
                p = ch.get("portal", "")
                if p and p not in portals:
                    portals[p] = ch.get("name", "")

            excluded = set(get_excluded_portals())

            if not portals:
                xbmcgui.Dialog().ok("HomeIPTV Server Filter", "No servers found. Run a HomeIPTV search first.")
                return

            sorted_portals = sorted(portals.keys())

            while True:
                items = []
                for addr in sorted_portals:
                    status = "[COLOR red]BLOCKED[/COLOR]" if addr in excluded else "[COLOR lime]active[/COLOR]"
                    label = f"{status}  {addr}"
                    items.append(label)

                chosen = xbmcgui.Dialog().select(
                    "HomeIPTV Servers (select to toggle block)",
                    items,
                    preselect=-1,
                )

                if chosen == -1:
                    break

                selected_addr = sorted_portals[chosen]

                if selected_addr in excluded:
                    remove_excluded_portal(selected_addr)
                    excluded.discard(selected_addr)
                    xbmc.executebuiltin('Notification(HomeIPTV Server Filter,Unblocked %s,3000,%s)' % (selected_addr, addon_icon))
                else:
                    add_excluded_portal(selected_addr)
                    excluded.add(selected_addr)
                    try:
                        remove_portal_channels(selected_addr)
                    except Exception:
                        pass
                    xbmc.executebuiltin('Notification(HomeIPTV Server Filter,Blocked %s,3000,%s)' % (selected_addr, addon_icon))
        except ImportError as e:
            log(f'_homeiptv_filter: import failed: {e}')
            xbmcgui.Dialog().ok('HomeIPTV Server Filter', f'Module not available:\n{e}')

    def _myiptv_filter(self, action_val):
        """Handle MyIPTV Server Filter items in the GUI."""
        log('_myiptv_filter: opening MyIPTV server filter')
        try:
            from jetextractors.util.myiptv_store import (
                get_excluded_portals, add_excluded_portal, remove_excluded_portal,
                load_channels,
            )
            addon_icon = xbmcaddon.Addon().getAddonInfo('icon')

            data = load_channels()
            portals = {}
            for ch in data.get("channels", []):
                p = ch.get("portal", "")
                if p and p not in portals:
                    portals[p] = ch.get("name", "")

            excluded = set(get_excluded_portals())

            if not portals:
                xbmcgui.Dialog().ok("MyIPTV Server Filter", "No servers found. Run a MyIPTV search first.")
                return

            sorted_portals = sorted(portals.keys())

            while True:
                items = []
                for addr in sorted_portals:
                    status = "[COLOR red]BLOCKED[/COLOR]" if addr in excluded else "[COLOR lime]active[/COLOR]"
                    label = f"{status}  {addr}"
                    items.append(label)

                chosen = xbmcgui.Dialog().select(
                    "MyIPTV Servers (select to toggle block)",
                    items,
                    preselect=-1,
                )

                if chosen == -1:
                    break

                selected_addr = sorted_portals[chosen]

                if selected_addr in excluded:
                    remove_excluded_portal(selected_addr)
                    excluded.discard(selected_addr)
                    xbmc.executebuiltin('Notification(MyIPTV Server Filter,Unblocked %s,3000,%s)' % (selected_addr, addon_icon))
                else:
                    add_excluded_portal(selected_addr)
                    excluded.add(selected_addr)
                    xbmc.executebuiltin('Notification(MyIPTV Server Filter,Blocked %s,3000,%s)' % (selected_addr, addon_icon))
        except ImportError as e:
            log(f'_myiptv_filter: import failed: {e}')
            xbmcgui.Dialog().ok('MyIPTV Server Filter', f'Module not available:\n{e}')
