import xbmcgui
import xbmc
import xbmcaddon
import os
import json
import re
import time
from datetime import datetime
from resources.lib.tool import log, debug_log
from resources.lib.gui_helpers import strip_color_tags
from xbmcvfs import translatePath

ADDON_ID = "plugin.video.madtitansports"


class StreamPreferences:
    """Manages saved stream preferences for auto-play."""

    FILENAME = "stream_preferences.json"

    def __init__(self):
        self.addon = xbmcaddon.Addon(id=ADDON_ID)
        self._profile = translatePath(self.addon.getAddonInfo('profile'))
        self._filepath = os.path.join(self._profile, self.FILENAME)
        self._prefs = self._load()

    @staticmethod
    def is_enabled():
        try:
            return xbmcaddon.Addon(id=ADDON_ID).getSettingBool('auto_play_prefs')
        except Exception:
            return True

    def _load(self):
        if not os.path.exists(self._filepath):
            return {}
        try:
            with open(self._filepath, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception:
            return {}

    def _save(self):
        try:
            if not os.path.exists(self._profile):
                os.makedirs(self._profile)
            with open(self._filepath, 'w', encoding='utf-8') as f:
                json.dump(self._prefs, f, indent=2)
        except Exception as e:
            log(f'StreamPreferences._save error: {e}', level=xbmc.LOGERROR)

    @staticmethod
    def make_key(title, link_index):
        clean = strip_color_tags(title).strip()
        clean = re.sub(r'\s+', ' ', clean)
        return f'{clean}||{link_index}'

    @staticmethod
    def is_playable_url(url):
        if not url:
            return False
        lower = url.lower()
        return lower.startswith('http') or lower.startswith('jetproxy') or lower.startswith('magnet:') or lower.startswith('links://')

    @staticmethod
    def extract_url_from_plugin(plugin_url):
        if not plugin_url or not plugin_url.lower().startswith('plugin://'):
            return None
        try:
            from urllib.parse import urlparse, parse_qs, unquote
            parsed = urlparse(plugin_url)
            params = parse_qs(parsed.query)
            urls = params.get('urls', [])
            if urls:
                url = unquote(urls[0])
                for prefix in ('direct://', 'ffmpegdirect://'):
                    if url.lower().startswith(prefix):
                        url = url[len(prefix):]
                return url
        except Exception:
            pass
        return None

    @staticmethod
    def to_runnable_url(url):
        if not url:
            return url
        lower = url.lower()
        if lower.startswith('jetproxy') or lower.startswith('links://'):
            from urllib.parse import quote
            encoded = quote(url, safe='')
            return f'plugin://{ADDON_ID}/sportjetextractors/play?urls={encoded}&title=AutoPlay'
        return url

    def get_preference(self, title, link_index, require_playable=False, match_any_index=False):
        key = self.make_key(title, link_index)
        pref = self._prefs.get(key)
        if pref:
            if not require_playable or self.is_playable_url(pref.get('url', '')):
                return pref
        clean_title = strip_color_tags(title).strip()
        for k, v in self._prefs.items():
            parts = k.split('||', 1)
            if len(parts) == 2:
                saved_title = parts[0].strip()
                saved_idx = parts[1]
                if not match_any_index and saved_idx != str(link_index):
                    continue
                if require_playable and not self.is_playable_url(v.get('url', '')):
                    continue
                if clean_title == saved_title:
                    return v
                if re.search(r'(?<![a-zA-Z0-9])' + re.escape(saved_title) + r'(?![a-zA-Z0-9])', clean_title, re.IGNORECASE):
                    return v
                if re.search(r'(?<![a-zA-Z0-9])' + re.escape(clean_title) + r'(?![a-zA-Z0-9])', saved_title, re.IGNORECASE):
                    return v
        return None

    def save_preference(self, title, link_index, url, label=''):
        if not self.is_enabled():
            return
        key = self.make_key(title, link_index)
        self._prefs[key] = {
            'url': url,
            'label': strip_color_tags(label),
            'saved_date': datetime.now().strftime('%Y-%m-%d %H:%M'),
            'title': strip_color_tags(title),
            'link_index': link_index,
        }
        self._save()
        log(f'StreamPreferences: saved pref for "{title}" index={link_index}')

    def delete_preference(self, key):
        if key in self._prefs:
            del self._prefs[key]
            self._save()
            log(f'StreamPreferences: deleted pref key={key}')
            return True
        return False

    def clear_all(self):
        count = len(self._prefs)
        self._prefs = {}
        self._save()
        log(f'StreamPreferences: cleared all ({count} prefs)')
        return count

    def get_all(self):
        return dict(self._prefs)

    def count(self):
        return len(self._prefs)


def show_manage_dialog():
    prefs = StreamPreferences()
    all_prefs = prefs.get_all()

    if not all_prefs:
        xbmcgui.Dialog().ok('Stream Preferences', 'No saved stream preferences.')
        return

    while True:
        all_prefs = prefs.get_all()
        if not all_prefs:
            xbmcgui.Dialog().ok('Stream Preferences', 'No saved stream preferences.')
            return

        entries = sorted(all_prefs.items(), key=lambda x: x[1].get('saved_date', ''), reverse=True)
        labels = []
        keys = []
        for key, data in entries:
            title = data.get('title', '?')
            label = data.get('label', '?')
            date = data.get('saved_date', '')
            labels.append(f'{title}  |  {label}  |  {date}')
            keys.append(key)

        idx = xbmcgui.Dialog().select('Manage Stream Preferences', labels)
        if idx is None or idx < 0:
            break

        selected_key = keys[idx]
        selected = all_prefs[selected_key]

        action = xbmcgui.Dialog().select(
            f'{selected.get("title", "?")} - {selected.get("label", "?")}',
            ['Delete this preference', 'Clear all preferences', 'Back'],
        )
        if action == 0:
            yesno = xbmcgui.Dialog().yesno(
                'Delete Preference',
                f'Delete saved preference for\n{selected.get("title", "?")}?',
            )
            if yesno:
                prefs.delete_preference(selected_key)
        elif action == 1:
            count = prefs.count()
            yesno = xbmcgui.Dialog().yesno(
                'Clear All',
                f'Delete all {count} saved stream preferences?',
            )
            if yesno:
                prefs.clear_all()
                xbmcgui.Dialog().notification('Stream Preferences', f'Cleared {count} preferences')
                return
        else:
            continue
