import xbmcgui
import xbmc
import xbmcaddon
import json
import os
import time
import re
import requests
from datetime import datetime
from resources.lib.tool import log, debug_log
from resources.lib.gui_helpers import strip_color_tags


ESPN_API = "https://espn.xyzstreams.st/"
ESPN_CACHE_TTL = 3600
ADDON_ID = "plugin.video.madtitansports"

ESPN_HEADERS = {
    "Accept": "application/json",
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
}


def _get_cache_path():
    addon = xbmcaddon.Addon(id=ADDON_ID)
    profile_dir = addon.getAddonInfo('profile')
    try:
        from xbmcvfs import translatePath
        profile_dir = translatePath(profile_dir)
    except ImportError:
        pass
    if not os.path.exists(profile_dir):
        os.makedirs(profile_dir, exist_ok=True)
    return os.path.join(profile_dir, 'espn_plus_cache.json')


def _read_cache():
    path = _get_cache_path()
    try:
        if os.path.exists(path):
            with open(path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            age = time.time() - data.get('timestamp', 0)
            if age < ESPN_CACHE_TTL:
                return data.get('events', []), age
    except Exception as e:
        log(f'ESPN+ cache read error: {e}', level=xbmc.LOGWARNING)
    return None, None


def _write_cache(events):
    path = _get_cache_path()
    try:
        with open(path, 'w', encoding='utf-8') as f:
            json.dump({'events': events, 'timestamp': time.time()}, f)
    except Exception as e:
        log(f'ESPN+ cache write error: {e}', level=xbmc.LOGWARNING)


def _parse_iso8601(ts_str):
    if not ts_str or not isinstance(ts_str, str):
        return 0
    try:
        ts_str = ts_str.strip()
        ts_str = re.sub(r'\.\d+', '', ts_str)
        ts_str = ts_str.replace('Z', '+00:00')
        dt = datetime.fromisoformat(ts_str)
        return int(dt.timestamp())
    except Exception:
        pass
    try:
        for fmt in ('%Y-%m-%dT%H:%M:%S%z', '%Y-%m-%dT%H:%M:%S', '%Y-%m-%d %H:%M:%S', '%Y-%m-%d'):
            try:
                dt = datetime.strptime(ts_str.replace('Z', ''), fmt.replace('%z', ''))
                return int(dt.timestamp())
            except ValueError:
                continue
    except Exception:
        pass
    return 0


def _parse_duration(dur):
    if isinstance(dur, (int, float)):
        return int(dur)
    if not dur or not isinstance(dur, str):
        return 0
    dur = dur.strip()
    m = re.match(r'^PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?$', dur)
    if m:
        hours = int(m.group(1) or 0)
        mins = int(m.group(2) or 0)
        secs = int(m.group(3) or 0)
        return hours * 3600 + mins * 60 + secs
    m = re.match(r'^(\d+):(\d+):(\d+)$', dur)
    if m:
        return int(m.group(1)) * 3600 + int(m.group(2)) * 60 + int(m.group(3))
    m = re.match(r'^(\d+):(\d+)$', dur)
    if m:
        return int(m.group(1)) * 60 + int(m.group(2))
    try:
        return int(dur)
    except ValueError:
        return 0


def _format_time_range(start_ts, duration_secs, utc_offset):
    if not start_ts:
        return ''
    start_dt = datetime.utcfromtimestamp(start_ts + utc_offset)
    today = datetime.utcfromtimestamp(time.time() + utc_offset).date()
    start_date = start_dt.date()
    if start_date == today:
        day_label = 'Today'
    elif (start_date - today).days == 1:
        day_label = 'Tomorrow'
    else:
        day_label = start_dt.strftime('%a %b %d')
    if duration_secs:
        end_dt = datetime.utcfromtimestamp(start_ts + duration_secs + utc_offset)
        if end_dt.date() != start_date:
            time_str = f"{start_dt.strftime('%I:%M %p')} - {end_dt.strftime('%b %d %I:%M %p')}"
        else:
            time_str = f"{start_dt.strftime('%I:%M %p')} - {end_dt.strftime('%I:%M %p')}"
    else:
        time_str = start_dt.strftime('%I:%M %p')
    return f"{day_label}, {time_str}"


class ESPNPlusMixin:

    def _espn_plus_open(self, route_val):
        log(f'_espn_plus_open called with route_val={route_val}')
        progress = None
        try:
            cached, cache_age = _read_cache()
            if cached is not None:
                log(f'ESPN+ cache hit, age={cache_age:.0f}s')
                events = cached
            else:
                progress = xbmcgui.DialogProgress()
                progress.create("ESPN+", "Fetching ESPN+ events...")
                progress.update(0, "Connecting to ESPN API...")

                response = requests.get(ESPN_API, headers=ESPN_HEADERS, timeout=15)
                response.raise_for_status()
                data = response.json()

                progress.update(50, "Processing events...")

                events = data.get("itemListElement", []) if isinstance(data, dict) else data
                _write_cache(events)
                log(f'ESPN+ API fetched and cached {len(events)} events')

            now = time.time()
            utc_offset = (datetime.fromtimestamp(now) - datetime.utcfromtimestamp(now)).total_seconds()

            jen_list = []
            for event in events:
                name = event.get("name", event.get("title", "Unknown"))
                thumbnail = event.get("thumbnail", event.get("thumbnailUrl", event.get("image", "")))
                content_url = event.get("contentUrl", event.get("url", event.get("stream", "")))
                raw_start = event.get("startTime", event.get("date", ""))
                raw_duration = event.get("duration", "")

                if not content_url:
                    continue

                start_ts = _parse_iso8601(raw_start) if isinstance(raw_start, str) else (int(raw_start) if isinstance(raw_start, (int, float)) else 0)
                dur_secs = _parse_duration(raw_duration)

                if start_ts and dur_secs:
                    end_ts = start_ts + dur_secs
                    if end_ts <= now:
                        status = "FINAL"
                    elif start_ts <= now < end_ts:
                        status = "LIVE"
                    else:
                        status = "UPCOMING"
                elif start_ts:
                    if start_ts <= now:
                        status = "LIVE"
                    else:
                        status = "UPCOMING"
                else:
                    status = ""

                time_range = _format_time_range(start_ts, dur_secs, utc_offset)

                summary_parts = []
                if time_range:
                    summary_parts.append(f'[COLORyellow]{time_range}[/COLOR]')
                if status:
                    summary_parts.append(f'[COLORlime]{status}[/COLOR]')
                summary = '\n'.join(summary_parts)

                guidedata_entry = {
                    "label": f"[COLOR=lime]{name}[/COLOR]",
                }
                if start_ts:
                    guidedata_entry["starttime"] = start_ts
                if dur_secs:
                    guidedata_entry["duration"] = dur_secs

                jen_data = {
                    "type": "item",
                    "title": f"[COLOR=lime]>[/COLOR] {name}",
                    "link": f"plugin://plugin.video.madtitansports/sportjetextractors/play?urls=links://{content_url}",
                    "thumbnail": thumbnail,
                    "summary": summary,
                    "sportjetextractors": [{"address": f"links://{content_url}", "name": name}],
                }
                if start_ts and dur_secs:
                    jen_data["guidedata"] = [guidedata_entry]

                jen_list.append(jen_data)

            if progress:
                progress.update(90, f"Found {len(jen_list)} events...")
                xbmc.sleep(300)
                progress.close()

        except requests.exceptions.RequestException as e:
            log(f'ESPN+ API request failed: {e}', level=xbmc.LOGERROR)
            if progress:
                try:
                    progress.close()
                except Exception:
                    pass
            xbmcgui.Dialog().ok("ESPN+ Error", f"Failed to fetch events: {str(e)}")
            return
        except json.JSONDecodeError as e:
            log(f'ESPN+ JSON decode failed: {e}', level=xbmc.LOGERROR)
            if progress:
                try:
                    progress.close()
                except Exception:
                    pass
            xbmcgui.Dialog().ok("ESPN+ Error", f"Invalid API response: {str(e)}")
            return
        except Exception as e:
            log(f'ESPN+ error: {e}', level=xbmc.LOGERROR)
            if progress:
                try:
                    progress.close()
                except Exception:
                    pass
            xbmcgui.Dialog().ok("ESPN+ Error", f"Failed: {str(e)}")
            return

        if not jen_list:
            xbmcgui.Dialog().ok("ESPN+", "No events found.")
            return

        self._pvr_display_results(jen_list, 'ESPN+')
