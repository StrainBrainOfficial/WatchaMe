import xbmcgui
import xbmc
import xbmcaddon
import xbmcvfs
import json
import base64
import re
import os
import time
import threading
from datetime import datetime
from resources.lib.tool import log, debug_log
from resources.lib.gui_helpers import strip_color_tags, get_route_for_item, fetch_json
from resources.lib.playback_monitor import track, track_error, track_feature, flush_session
from resources.lib.gui_live_sports import LiveSportsMixin
from resources.lib.gui_tmdb import TMDBMixin
from resources.lib.gui_trakt import TraktMixin
from resources.lib.gui_file_iptv import FileIPTVMixin
from resources.lib.gui_pvr import PVRSearchMixin
from resources.lib.gui_jet import JetExtractorMixin
from resources.lib.gui_scraper import ScraperMixin
from resources.lib.gui_tools import ToolsPreviewMixin
from resources.lib.gui_myiptv_remote import MyIPTVRemoteMixin
from resources.lib.gui_espn_plus import ESPNPlusMixin
from resources.lib.stream_prefs import StreamPreferences
from resources.lib import loading_overlay
from resources.lib.endpoints import ROOT_JSON, TVGUIDE_US_ENTERTAINMENT, REPLAY_REWIND

ADDON_ID = "plugin.video.madtitansports"



class MadTitanGUI(
    LiveSportsMixin,
    TMDBMixin,
    TraktMixin,
    FileIPTVMixin,
    PVRSearchMixin,
    JetExtractorMixin,
    ScraperMixin,
    ToolsPreviewMixin,
    MyIPTVRemoteMixin,
    ESPNPlusMixin,
    xbmcgui.WindowXML,
):
    def __init__(self, xml_filename, script_path, defaulttheme=False):
        super().__init__(xml_filename, script_path, defaulttheme)
        self.items_data = []
        self.nav_stack = []
        self.current_url = None
        self.current_title = 'MAD TITAN SPORTS'
        self._closing = False
        self._live_games = []
        self._live_inprogress = []
        self._live_loaded = False
        self._focused_game_list = False
        self._live_top_idx = 0
        self._saved_state = None
        self._saved_selected_idx = 0
        self._tmdb_movies = []
        self._tmdb_movie_idx = 0
        self._tmdb_movies_loaded = False
        self._movie_rotating = False
        self._movie_rotation_count = 0
        self._focused_movie_list = False
        self._last_movie_idx = -1
        self._last_game_idx = -1
        self._scraper_results_pending = False
        self._live_loading = False
        self._live_rotating = False
        self._live_rotation_count = 0
        self._live_needs_populate = False
        self._tmdb_loading = False
        self._tvnet_channels = []
        self._tvnet_idx = 0
        self._tvnet_loaded = False
        self._tvnet_loading = False
        self._focused_channel_grid = False
        self._last_channel_idx = -1
        self._root_items = []
        self._tvnet_settings_mode = None
        self._preview_generation = 0
        self._tvnet_cache = {}
        self._pvr_searching = False
        self._tvnet_cache_ttl = 300
        self._poll_timer = None
        self._refresh_recently_pending = False
        self._stream_prefs_cache = None
        self._pending_recently_played = None

    def _get_stream_prefs(self):
        if self._stream_prefs_cache is None:
            self._stream_prefs_cache = StreamPreferences()
        return self._stream_prefs_cache

    def onInit(self):
        log('onInit called')
        try:
            from resources.lib.DI import DI
            self.session = DI.session
            self.db = DI.db
            log('DI session/db loaded')
        except ImportError:
            self.session = __import__('requests').Session()
            self.db = None
            log('Fallback session created')

        self.addon = xbmcaddon.Addon(id=ADDON_ID)
        self.use_cache = self.addon.getSettingBool('use_cache')
        self.server_url = (
            self.addon.getSetting('server_front_url')
            or ROOT_JSON
        )
        # log(f'server_url={self.server_url}')
        log(f'server_url= TITAN')

        self.setProperty('preview_mode', 'default')
        self.load_items(self.server_url, is_root=True)
        self._inject_recently_played()
        self.items_data = list(self._root_items)
        if self.items_data:
            self.populate_list()
        if not self._restore_state():
            self._restore_state_from_disk()
        self._start_poll()
        self._update_player_button()
        # Playback monitor is started by service.py so it survives window restarts

    def _start_poll(self):
        self._last_idx = -1
        self._poll_tick()

    def _update_player_button(self):
        try:
            control = self.getControl(201)
            player = xbmc.Player()
            if player.isPlaying():
                playing_file = player.getPlayingFile()
                channel_name = playing_file.split('/')[-1][:30]
                try:
                    jsonrpc = {
                        'jsonrpc': '2.0',
                        'method': 'Player.GetItem',
                        'params': {'playerid': 1},
                        'id': 1
                    }
                    result = xbmc.executeJSONRPC(json.dumps(jsonrpc))
                    data = json.loads(result)
                    item = data.get('result', {}).get('item', {})
                    label = item.get('label', '')
                    if label:
                        channel_name = label
                except Exception:
                    pass
                if channel_name:
                    control.setLabel(f"[B]{channel_name}[/B]\n[B]Tap to Restore[/B]")
                else:
                    control.setLabel("[B]Tap to Restore[/B]")
            else:
                control.setLabel("[B]Tap to Restore[/B]")
        except Exception:
            pass

    def _poll_tick(self):
        if self._closing:
            return
        try:
            self._update_player_button()
            if self._pending_recently_played:
                if xbmc.Player().isPlaying():
                    try:
                        win = xbmcgui.Window(10000)
                        resolved = win.getProperty('madtitan_resolved_url')
                        win.clearProperty('madtitan_resolved_url')
                        prp = self._pending_recently_played
                        self._pending_recently_played = None
                        if resolved and '127.0.0.1' not in resolved:
                            self._save_recently_played(prp['title'], resolved, prp.get('thumbnail', ''))
                        else:
                            self._save_recently_played(prp['title'], prp['fallback_link'], prp.get('thumbnail', ''))
                    except Exception:
                        prp = self._pending_recently_played
                        self._pending_recently_played = None
                        self._save_recently_played(prp['title'], prp['fallback_link'], prp.get('thumbnail', ''))
                elif (time.time() - self._pending_recently_played.get('time', 0)) > 120:
                    xbmcgui.Window(10000).clearProperty('madtitan_resolved_url')
                    prp = self._pending_recently_played
                    self._pending_recently_played = None
                    self._save_recently_played(prp['title'], prp['fallback_link'], prp.get('thumbnail', ''))
            if self._refresh_recently_pending:
                self._refresh_recently_pending = False
                self._do_refresh_root_recently()

            if not self._pvr_searching:
                if self._live_needs_populate:
                    self._live_needs_populate = False
                    self._populate_game_list()
                    self._start_live_rotation()

                win = xbmcgui.Window(10000)
                scraper_results = win.getProperty('madtitan_scraper_results')
                if scraper_results and not self._scraper_results_pending:
                    self._scraper_results_pending = True
                    self._display_scraper_results()
                    win.clearProperty('madtitan_scraper_results')
                    win.clearProperty('madtitan_scraper_sources')
                    win.clearProperty('madtitan_scraper_item')
                elif not scraper_results and self._scraper_results_pending:
                    self._scraper_results_pending = False

                focused_id = self.getFocusId()
                if focused_id == 510 and self._tvnet_channels and not self._live_games and not self._live_loading:
                    self.setFocus(self.getControl(530))
                    self._focused_channel_grid = True
                    return
                if focused_id == 520 and self._tmdb_movies:
                    self._focused_movie_list = True
                    movie_list = self.getControl(520)
                    m_idx = movie_list.getSelectedPosition()
                    if m_idx != self._last_movie_idx and 0 <= m_idx < len(self._tmdb_movies):
                        self._last_movie_idx = m_idx
                        self._tmdb_movie_idx = m_idx
                        self._movie_rotating = False
                        self._update_featured_movie()
                elif focused_id == 510:
                    self._focused_game_list = True
                    game_list = self.getControl(510)
                    g_idx = game_list.getSelectedPosition()
                    if g_idx != self._last_game_idx and g_idx < len(self._live_games):
                        self._last_game_idx = g_idx
                        self._show_game_in_preview(g_idx)
                elif focused_id == 530 and self._tvnet_channels:
                    self._focused_channel_grid = True
                    ch_grid = self.getControl(530)
                    c_idx = ch_grid.getSelectedPosition()
                    if c_idx != self._last_channel_idx and c_idx < len(self._tvnet_channels):
                        self._last_channel_idx = c_idx
                        self._tvnet_idx = c_idx
                        if self._tvnet_settings_mode:
                            self._update_featured_tool(c_idx)
                        else:
                            self._update_featured_channel(c_idx)
                elif focused_id == 531 and self._tvnet_channels and self._tvnet_settings_mode:
                    self._focused_channel_grid = True
                    settings_grid = self.getControl(531)
                    s_idx = settings_grid.getSelectedPosition()
                    if s_idx != self._last_channel_idx and s_idx < len(self._tvnet_channels):
                        self._last_channel_idx = s_idx
                        self._tvnet_idx = s_idx
                        self._update_featured_tool(s_idx)
                else:
                    if self._focused_movie_list:
                        self._focused_movie_list = False
                        self._last_movie_idx = -1
                    if self._focused_game_list:
                        self._focused_game_list = False
                        self._last_game_idx = -1
                    if self._focused_channel_grid:
                        self._focused_channel_grid = False
                        self._last_channel_idx = -1
                    lst = self.getControl(100)
                    idx = lst.getSelectedPosition()
                    if idx != self._last_idx and idx >= 0:
                        self._last_idx = idx
                        self.update_preview(idx)
        except Exception as e:
            debug_log(f'_poll_tick error: {e}', level=xbmc.LOGERROR)
        if not self._closing:
            self._poll_timer = threading.Timer(0.25, self._poll_tick)
            self._poll_timer.daemon = True
            self._poll_timer.start()

    def load_items(self, url, is_root=False, push_nav=True):
        response = fetch_json(
            url,
            use_cache=self.use_cache,
            db=self.db,
            session=self.session,
        )

        if not response:
            xbmcgui.Dialog().ok("Error", "Failed to load data")
            return

        try:
            data = json.loads(response)
            raw_items = data.get('items', [])
        except json.JSONDecodeError:
            raw_items = []

        items = []
        for item in raw_items:
            if not item.get('title') and not item.get('name'):
                continue
            route = get_route_for_item(item)
            if route:
                title = item.get('title', item.get('name', ''))
                thumbnail = item.get('thumbnail', '')
                summary = item.get('summary', '')
                fanart = item.get('fanart', '')
                items.append({
                    'title': title,
                    'thumbnail': thumbnail,
                    'fanart': fanart,
                    'summary': summary,
                    'route': route,
                    'raw': item,
                })

        if not items:
            if not is_root:
                xbmcgui.Dialog().ok("Empty", "No items found")
            return

        if push_nav and self.items_data:
            lst = self.getControl(100)
            self.nav_stack.append({
                'items': self.items_data,
                'title': self.current_title,
                'url': self.current_url,
                'selected_idx': lst.getSelectedPosition(),
            })

        self.items_data = items
        if is_root:
            self._root_items = list(items)
        self.current_url = url

        if is_root:
            self.current_title = 'MAD TITAN SPORTS'
        else:
            self.current_title = items[0]['title'] if items else 'Menu'

        self.populate_list()
        self.update_preview(0)

    def populate_list(self, no_focus=False):
        lst = self.getControl(100)
        lst.reset()

        for item_data in self.items_data:
            li = xbmcgui.ListItem(label=item_data['title'])
            art = {}
            if item_data['thumbnail']:
                art['icon'] = item_data['thumbnail']
                art['thumb'] = item_data['thumbnail']
            if item_data.get('fanart'):
                art['fanart'] = item_data['fanart']
            if art:
                li.setArt(art)
            lst.addItem(li)

        if not no_focus:
            self.setFocus(lst)

    def _parse_link(self, lnk_str):
        lnk_str = str(lnk_str)
        if '(' in lnk_str and lnk_str.endswith(')'):
            parts = lnk_str.split('(')
            url = parts[0]
            raw_label = parts[-1].rstrip(')')
            label = strip_color_tags(raw_label)
            if not label:
                label = 'Link'
        else:
            url = lnk_str
            clean = strip_color_tags(lnk_str)
            label = clean.split('/')[-1].split('?')[0] or 'Link'
        return label, url

    def _show_link_dialog(self):
        lst = self.getControl(100)
        idx = lst.getSelectedPosition()
        if idx < 0 or idx >= len(self.items_data):
            return
        item_data = self.items_data[idx]
        raw = item_data.get('raw', {})
        link_list = raw.get('link', [])

        if isinstance(link_list, list) and link_list:
            labels = []
            urls = []
            for lnk in link_list:
                label, url = self._parse_link(str(lnk))
                labels.append(label)
                urls.append(url)
            log(f'_show_link_dialog: {len(labels)} link items')

            sp = self._get_stream_prefs()
            pref = sp.get_preference(item_data['title'], 0, require_playable=True)
            for li_i, lnk in enumerate(link_list):
                p = sp.get_preference(item_data['title'], li_i, require_playable=True)
                if p:
                    pref = p
                    pref['_index'] = li_i
                    break

            auto_played = False
            if pref and pref.get('url'):
                saved_url = pref['url']
                saved_idx = pref.get('_index', 0)
                saved_label = pref.get('label', labels[saved_idx] if saved_idx < len(labels) else '?')
                runnable_url = sp.to_runnable_url(saved_url)
                log(f'_show_link_dialog: auto-play pref index={saved_idx} label={saved_label} url={saved_url[:80]} runnable={runnable_url[:80]}')
                self._save_state(idx)
                track("play", channel_name=strip_color_tags(item_data['title']), url=saved_url, source="link_dialog_pref")
                xbmc.Player().stop()
                loading_overlay.show()
                if saved_url.lower().startswith('http'):
                    xbmc.Player().play(saved_url)
                else:
                    xbmc.executebuiltin(f'RunPlugin({runnable_url})')
                for _ in range(8):
                    xbmc.sleep(500)
                    if xbmc.Player().isPlaying():
                        break
                if xbmc.Player().isPlaying():
                    log(f'_show_link_dialog: auto-play succeeded')
                    auto_played = True
                else:
                    loading_overlay.close()
                    log(f'_show_link_dialog: auto-play failed, showing dialog')
                    xbmcgui.Dialog().notification('Stream Preferences', 'Preferred stream failed, showing picker', xbmcgui.NOTIFICATION_WARNING, 3000)

            if not auto_played:
                pick = xbmcgui.Dialog().select(item_data['title'], labels)
            else:
                pick = -1
            if pick >= 0:
                log(f'_show_link_dialog: picked {pick} -> {urls[pick][:80]}...')
                self._save_state(idx)
                selected_url = urls[pick]
                self._save_recently_played(item_data['title'], selected_url, item_data.get('thumbnail', ''))
                track("play", channel_name=strip_color_tags(item_data['title']), url=selected_url, source="link_dialog")
                xbmc.Player().stop()
                loading_overlay.show()
                play_item = {"title": raw.get("title", item_data['title']), "link": selected_url}
                encoded = base64.urlsafe_b64encode(bytes(json.dumps(play_item), 'utf-8')).decode('utf-8')
                xbmc.executebuiltin(f'RunPlugin(plugin://{ADDON_ID}/play_video/{encoded})')
                if sp.is_playable_url(selected_url):
                    sp.save_preference(item_data['title'], pick, selected_url, labels[pick])
                else:
                    jet_list = raw.get('sportjetextractors', [])
                    if jet_list and pick < len(jet_list):
                        jet_url = jet_list[pick].get('address', '')
                        if jet_url and sp.is_playable_url(jet_url):
                            sp.save_preference(item_data['title'], pick, jet_url, labels[pick])
                    else:
                        actual = sp.extract_url_from_plugin(selected_url)
                        if actual and sp.is_playable_url(actual):
                            sp.save_preference(item_data['title'], pick, actual, labels[pick])
            return

        sportjetextractors = raw.get('sportjetextractors', [])
        if sportjetextractors:
            labels = []
            for i, link in enumerate(sportjetextractors):
                if isinstance(link, dict):
                    labels.append(link.get('name', f'Link {i + 1}'))
                else:
                    labels.append(f'Link {i + 1}')

            sp = self._get_stream_prefs()
            pref = None
            for li_i in range(len(sportjetextractors)):
                p = sp.get_preference(item_data['title'], li_i, require_playable=True)
                if p:
                    pref = p
                    pref['_index'] = li_i
                    break

            auto_played = False
            if len(labels) == 1 and not pref:
                pick = 0
            else:
                if pref and pref.get('url'):
                    saved_url = pref['url']
                    saved_idx = pref.get('_index', 0)
                    saved_label = pref.get('label', labels[saved_idx] if saved_idx < len(labels) else '?')
                    runnable_url = sp.to_runnable_url(saved_url)
                    log(f'_show_link_dialog: jet auto-play pref index={saved_idx} label={saved_label} url={saved_url[:80]} runnable={runnable_url[:80]}')
                    self._save_state(idx)
                    xbmc.Player().stop()
                    loading_overlay.show()
                    if saved_url.lower().startswith('http'):
                        xbmc.Player().play(saved_url)
                    else:
                        xbmc.executebuiltin(f'RunPlugin({runnable_url})')
                    for _ in range(8):
                        xbmc.sleep(500)
                        if xbmc.Player().isPlaying():
                            break
                    if xbmc.Player().isPlaying():
                        log(f'_show_link_dialog: jet auto-play succeeded')
                        auto_played = True
                    else:
                        loading_overlay.close()
                        log(f'_show_link_dialog: jet auto-play failed, showing dialog')
                        xbmcgui.Dialog().notification('Stream Preferences', 'Preferred stream failed, showing picker', xbmcgui.NOTIFICATION_WARNING, 3000)

                if not auto_played:
                    pick = xbmcgui.Dialog().select(item_data['title'], labels)
                else:
                    pick = -1
            if pick >= 0:
                selected = sportjetextractors[pick]
                fallback_name = strip_color_tags(item_data.get('title', '')) or selected.get('name', '') or strip_color_tags(str(raw.get('title', ''))) or 'Unknown'
                play_item = {"title": fallback_name, "sportjetextractors": [selected]}
                encoded = base64.urlsafe_b64encode(bytes(json.dumps(play_item), 'utf-8')).decode('utf-8')
                full_plugin_url = f'plugin://{ADDON_ID}/play_video/{encoded}'
                self._save_state(idx)
                actual_url = selected.get('address', '')
                self._save_recently_played(item_data['title'], actual_url or full_plugin_url, item_data.get('thumbnail', ''))
                xbmc.Player().stop()
                loading_overlay.show()
                xbmc.executebuiltin(f'RunPlugin({full_plugin_url})')
                if actual_url:
                    sp.save_preference(item_data['title'], pick, actual_url, selected.get('name', f'Link {pick + 1}'))
            return

    def _show_context_menu(self):
        lst = self.getControl(100)
        idx = lst.getSelectedPosition()
        if idx < 0 or idx >= len(self.items_data):
            return
        item_data = self.items_data[idx]
        route_type, route_val = item_data['route']
        raw = item_data.get('raw', {})

        options = []
        if route_type == 'dir':
            options.append(('Open', 'open'))
        elif route_type in ('xtream_genres', 'mac_genres'):
            options.append(('Open', 'open'))
        elif route_type in ('list_pick', 'jet_action', 'mac_play') or raw.get('sportjetextractors'):
            options.append(('Play', 'play'))
        elif route_type in ('action', 'plugin', 'resolveurl_auth', 'resolveurl_settings', 'xtream_action', 'mac_action'):
            options.append(('Run', 'play'))
        elif route_type in ('myiptv_remote_search', 'myiptv_remote_search_term', 'myiptv_remote_full_search', 'myiptv_remote_full_search_term', 'myiptv_remote_recent', 'myiptv_remote_menu', 'myiptv_remote_action', 'myiptv_remote_categories', 'myiptv_remote_genre'):
            options.append(('Run', 'play'))
        else:
            options.append(('Play', 'play'))

        options.append(('Add to Kodi Favorites', 'add_fav'))

        choice = xbmcgui.Dialog().select(
            strip_color_tags(item_data['title']),
            [o[0] for o in options]
        )
        if choice < 0:
            return

        action = options[choice][1]
        if action == 'play':
            self._execute_item(idx)
        elif action == 'add_fav':
            self._add_to_kodi_favorites(item_data)

    def _execute_item(self, idx):
        item_data = self.items_data[idx]
        route_type, route_val = item_data['route']
        raw = item_data.get('raw', {})

        if route_type == 'pvr_play':
            self._pvr_play(route_val)
        elif route_type == 'list_pick':
            self._show_link_dialog()
        elif route_type == 'pvr_search':
            self._save_state(idx)
            self._pvr_search(route_val)
        elif route_type == 'dir':
            self.load_items(route_val, is_root=False, push_nav=True)
        elif route_type == 'action':
            if route_val == '/refresh_menu':
                self._refresh_menu()
            else:
                self._save_state(idx)
                raw_link = item_data.get('raw', {}).get('link', '')
                if 'links://' in str(raw_link):
                    loading_overlay.show()
                xbmc.executebuiltin(f'RunPlugin(plugin://{ADDON_ID}{route_val})')
        elif route_type == 'resolveurl_auth':
            xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)')
        elif route_type == 'resolveurl_settings':
            xbmcaddon.Addon('script.module.resolveurl').openSettings()
        elif route_type == 'plugin':
            self._save_state(idx)
            if route_val.lower().startswith(f'plugin://{ADDON_ID.lower()}/'):
                xbmc.executebuiltin(f'RunPlugin({route_val})')
            else:
                plug_play_item = {"title": item_data.get('title', ''), "link": route_val}
                plug_enc = base64.urlsafe_b64encode(bytes(json.dumps(plug_play_item), 'utf-8')).decode('utf-8')
                xbmc.executebuiltin(f'RunPlugin(plugin://{ADDON_ID}/play_video/{plug_enc})')
        elif route_type == 'file_iptv_search':
            self._save_state(idx)
            self._file_iptv_search(route_val)
        elif route_type == 'file_iptv_search_country':
            self._save_state(idx)
            self._file_iptv_search_country()
        elif route_type == 'file_iptv_recent':
            self._save_state(idx)
            self._file_iptv_recent()
        elif route_type == 'file_iptv_play':
            self._file_iptv_play(raw)
        elif route_type == 'search_music':
            self._save_state(idx)
            self._search_music_search(route_val, raw)
        elif route_type == 'youtube_search':
            self._save_state(idx)
            self._youtube_search()
        elif route_type == 'youtube_play':
            self._save_state(idx)
            track("play", channel_name=strip_color_tags(item_data['title']), url=f'plugin://plugin.video.youtube/play/?video_id={route_val}', source="youtube")
            xbmc.executebuiltin(f'RunPlugin(plugin://plugin.video.youtube/play/?video_id={route_val})')
        elif route_type == 'fmstream_search':
            self._save_state(idx)
            self._fmstream_search(route_val)
        elif route_type == 'fmstream_next':
            self._save_state(idx)
            self._fmstream_next(route_val)
        elif route_type == 'fmstream_featured':
            self._save_state(idx)
            self._fmstream_featured()
        elif route_type == 'fmstream_country':
            self._save_state(idx)
            self._fmstream_country(route_val)
        elif route_type == 'espn_plus':
            self._save_state(idx)
            self._espn_plus_open(route_val)
        elif route_type == 'tmdb':
            self._save_state(idx)
            self._tmdb_open(route_val)
        elif route_type == 'trakt':
            self._save_state(idx)
            self._trakt_open(route_val)
        elif route_type == 'tmdb_item':
            self._tmdb_item_play(raw)
        elif route_type == 'scraper_result':
            self._play_scraper_result(raw)
        elif route_type == 'jet_action':
            self._save_state(idx)
            self._jet_action(route_val)
        elif route_type == 'jetextractors_manage':
            self._save_state(idx)
            self._jetextractors_manage(route_val)
        elif route_type == 'telegram_filter':
            self._save_state(idx)
            self._telegram_filter(route_val)
        elif route_type == 'homeiptv_filter':
            self._save_state(idx)
            self._homeiptv_filter(route_val)
        elif route_type == 'xtream_action':
            self._xtream_action(route_val)
        elif route_type == 'xtream_genres':
            self._save_state(idx)
            self._xtream_genres(route_val)
        elif route_type == 'mac_action':
            self._mac_action(route_val)
        elif route_type == 'mac_genres':
            self._save_state(idx)
            self._mac_genres(route_val)
        elif route_type == 'mac_play':
            self._save_state(idx)
            self._mac_play(route_val)
        elif route_type == 'recently_played':
            self._open_recently_played(raw)
        elif route_type == 'play_http':
            self._save_state(idx)
            track("play", channel_name=strip_color_tags(item_data['title']), url=route_val, source="recently_played")
            xbmc.Player().stop()
            loading_overlay.show()
            xbmc.Player().play(route_val)
        elif route_type == 'myiptv_remote_menu':
            self._save_state(idx)
            self._myiptv_remote_menu()

        elif route_type == 'myiptv_remote_search':
            self._save_state(idx)
            self._myiptv_remote_search()

        elif route_type == 'myiptv_remote_categories':
            self._save_state(idx)
            self._myiptv_remote_categories()

        elif route_type == 'myiptv_remote_genre':
            self._save_state(idx)
            self._myiptv_remote_genre(route_val)

        elif route_type == 'myiptv_remote_full_search':
            self._save_state(idx)
            self._myiptv_remote_search()

        elif route_type == 'myiptv_remote_search_term':
            self._save_state(idx)
            self._myiptv_remote_search_term(route_val)

        elif route_type == 'myiptv_remote_full_search_term':
            self._save_state(idx)
            self._myiptv_remote_full_search_term(route_val)

        elif route_type == 'myiptv_remote_recent':
            self._save_state(idx)
            self._myiptv_remote_recent()

        elif route_type == 'myiptv_remote_action':
            self._save_state(idx)
            self._myiptv_remote_action(route_val)

    def _add_to_kodi_favorites(self, item_data):
        raw = item_data.get('raw', {})
        clean_title = strip_color_tags(item_data['title'])

        name = xbmcgui.Dialog().input(
            'Name for Kodi favorite',
            defaultt=clean_title
        )
        if not name:
            return

        link = raw.get('link', '')
        item_type = raw.get('type', '')
        sportjetextractors = raw.get('sportjetextractors', [])
        fav_command = None

        if item_type == 'dir' and isinstance(link, str) and link:
            fav_command = f'ActivateWindow(10025,"plugin://{ADDON_ID}/get_list/{link}",return)'
        elif isinstance(link, str) and link:
            fav_command = f'RunPlugin("plugin://{ADDON_ID}/play_video/{self._encode_fav_item(raw)}")'
        elif isinstance(link, list) and link:
            fav_command = f'RunPlugin("plugin://{ADDON_ID}/play_video/{self._encode_fav_item(raw)}")'
        elif isinstance(sportjetextractors, list) and sportjetextractors:
            fav_command = f'RunPlugin("plugin://{ADDON_ID}/play_video/{self._encode_fav_item(raw)}")'

        if not fav_command:
            xbmcgui.Dialog().notification(
                'Kodi Favorites',
                'Cannot save this item — no link data',
                xbmcgui.NOTIFICATION_WARNING,
                3000
            )
            return

        thumb = item_data.get('thumbnail', '')
        name_attr = f' name="{name}"'
        thumb_attr = f' thumb="{thumb}"' if thumb else ''
        new_entry = f'    <favourite{name_attr}{thumb_attr}>{fav_command}</favourite>'

        fav_path = xbmcvfs.translatePath("special://userdata/favourites.xml")
        if xbmcvfs.exists(fav_path):
            try:
                with open(fav_path, 'r', encoding='utf-8') as f:
                    content = f.read()
            except Exception:
                content = ''
        else:
            content = ''

        if '</favourites>' in content:
            content = content.replace('</favourites>', f'{new_entry}\n</favourites>')
        elif '<favourites>' in content:
            content = content.replace('<favourites>', f'<favourites>\n{new_entry}')
        else:
            content = f'<?xml version="1.0" encoding="utf-8"?>\n<favourites>\n{new_entry}\n</favourites>\n'

        with open(fav_path, 'w', encoding='utf-8') as f:
            f.write(content)

        log(f'_add_to_kodi_favorites: saved "{name}" to favourites.xml')
        xbmcgui.Dialog().notification(
            'Kodi Favorites',
            f'"{name}" added to Kodi Favorites',
            xbmcgui.NOTIFICATION_INFO,
            3000
        )

    def _encode_fav_item(self, raw):
        fav_raw = {}
        for k, v in raw.items():
            if k == 'guidedata':
                continue
            fav_raw[k] = v
        return base64.urlsafe_b64encode(
            bytes(json.dumps(fav_raw), 'utf-8')
        ).decode('utf-8')

    def update_preview(self, idx):
        if idx < 0 or idx >= len(self.items_data):
            return
        item = self.items_data[idx]
        thumb = item.get('thumbnail') or item.get('fanart', '')
        if not thumb:
            thumb = xbmcaddon.Addon(ADDON_ID).getAddonInfo('fanart')
        title = item.get('title', '')
        summary = item.get('summary', '')
        if not summary:
            summary = 'Click to open this category.'
        self.setProperty('preview_thumb', thumb)
        self.setProperty('preview_title', title)
        self.setProperty('preview_summary', summary)

        raw = item.get('raw', {})
        guidedata = raw.get('guidedata', [])
        if guidedata:
            ch_thumb = raw.get('thumbnail', '') or raw.get('art', {}).get('thumb', '')
            if ch_thumb:
                self.setProperty('preview_thumb', ch_thumb)
            ch_title2 = raw.get('title2', '') or raw.get('ch_id', '') or strip_color_tags(title)
            ch_number = raw.get('channel_number', '')
            header = f'[B]{ch_title2}[/B]'
            if ch_number:
                header += f'  (Ch {ch_number})'
            ts = time.time()
            utc_offset = (datetime.fromtimestamp(ts) - datetime.utcfromtimestamp(ts)).total_seconds()
            today = datetime.utcfromtimestamp(ts + utc_offset).date()
            now_show = ''
            now_plot = ''
            now_time = ''
            schedule_lines = []
            for prog in guidedata:
                start_ts = prog.get('starttime', 0)
                duration = prog.get('duration', 0)
                end_ts = start_ts + duration
                if end_ts <= ts:
                    continue
                start_dt = datetime.utcfromtimestamp(start_ts + utc_offset)
                end_dt = datetime.utcfromtimestamp(end_ts + utc_offset)
                start_date = start_dt.date()
                if start_date == today:
                    day_label = ''
                elif (start_date - today).days == 1:
                    day_label = 'Tomorrow '
                else:
                    day_label = start_dt.strftime('%a %b %d, ')
                time_str = f'{day_label}{start_dt.strftime("%I:%M %p")} - {end_dt.strftime("%I:%M %p")}'
                label = prog.get('label', '')
                if start_ts <= ts < end_ts:
                    now_show = label
                    now_time = time_str
                    now_plot = strip_color_tags(prog.get('plot', ''))
                    schedule_lines.append(f'[COLORlime][B]{time_str}: {label}[/B][/COLOR]')
                else:
                    schedule_lines.append(f'{time_str}: {label}')
                if len(schedule_lines) >= 9:
                    break
            summary_parts = [header]
            if now_show:
                summary_parts.append(f'[COLORyellow]NOW PLAYING:[/COLOR] {now_show}')
                if now_time:
                    summary_parts.append(f'[COLORgrey]{now_time}[/COLOR]')
                if now_plot:
                    summary_parts.append(now_plot[:300])
            if schedule_lines:
                summary_parts.append('')
                summary_parts.append('[B]Upcoming:[/B]')
                summary_parts.extend(schedule_lines[:8])
            self.setProperty('preview_summary', '\n'.join(summary_parts))

        log(f'update_preview idx={idx} title="{title}"')

        try:
            disable_preview = xbmcaddon.Addon(ADDON_ID).getSetting('disable_preview') == 'true'
        except Exception:
            disable_preview = False
        if disable_preview:
            self.setProperty('preview_mode', 'default')
            return

        if idx != getattr(self, '_last_preview_idx', -1):
            self._preview_generation += 1
            self._last_preview_idx = idx
        raw = item.get('raw', {})
        link = raw.get('link', '')
        is_tmdb_movie = isinstance(link, str) and link.startswith('tmdb/') and (
            '/movie/' in link or link.startswith('tmdb/collection/') or link.startswith('tmdb/person/') or '/tv/' in link
        )
        is_trakt = isinstance(link, str) and link.startswith('trakt/')
        title_lower = strip_color_tags(title).lower()

        if 'live sports' in title_lower:
            log('Detected LIVE SPORTS item, calling load_live_sports')
            self.setProperty('preview_mode', 'live_sports')
            self.load_live_sports()
        elif 'file iptv settings' in title_lower:
            self._load_tools_preview()
        elif 'addon settings' in title_lower or 'tools' in title_lower:
            self._load_addon_settings_preview()
        elif 'jetextractors settings' in title_lower:
            self._load_jetextractors_settings_preview()
        elif 'telegram' in title_lower and ('server' in title_lower or 'block' in title_lower or 'filter' in title_lower):
            self._load_telegram_filter_preview()
        elif 'homeiptv' in title_lower and ('server' in title_lower or 'block' in title_lower or 'filter' in title_lower):
            self._load_homeiptv_filter_preview()
        elif any(kw in title_lower for kw in ('sports networks', 'sport networks','replay rewind', 'tvnet', 'live tv', 'us entertainment', 'us movies', 'us local', 'news channels', 'channel list', 'uk entertainment', 'uk movies','file iptv')):
            display_title = strip_color_tags(title).upper()
            data_link = link
            target_link = None
            for old, new in (('LIVE TV', 'US ENTERTAINMENT'), ('SPORTS NETWORKS', 'SPORTS NETWORKS'), ('SPORT NETWORKS', 'SPORTS NETWORKS')):
                if old in display_title:
                    display_title = new
                    break
            if 'live tv' in title_lower:
                target_link = None

                # Primary: hardcoded US Entertainment URL
                data_link = TVGUIDE_US_ENTERTAINMENT
                # log(f'Redirecting Live TV -> hardcoded US Entertainment link: {data_link}')
                log(f'Redirecting Live TV -> US Entertainment link')
            elif 'replay rewind' in title_lower:
                data_link = REPLAY_REWIND
                # log(f'Redirecting Live TV -> hardcoded Replay Rewind link: {data_link}')
                log(f'Redirecting Live TV -> Replay Rewind link')
            else:
                log('Live TV redirect: no US Entertainment item found; using Live TV link')
            if isinstance(data_link, list) and data_link:
                data_link = data_link[0]
            if isinstance(data_link, str):
                _, data_link = self._parse_link(data_link)
            if isinstance(data_link, str) and (data_link.startswith('plugin://') or not data_link.startswith('http')):
                # log(f'TV Networks skip: non-HTTP URL (individual channel), link={data_link[:80] if data_link else "(empty)"}')
                log(f'TV Networks skip: non-HTTP URL (individual channel)')
                self.setProperty('preview_mode', 'default')
            else:
                # log(f'Detected TV Networks item, link={data_link}, display={display_title}')
                log(f'Detected TV Networks item, link=NETWORKS, display={display_title}')

                self.setProperty('preview_mode', 'tv_networks')
                self.setProperty('preview_title', display_title)
                self.setProperty('tvnet_title', display_title)
                self.setProperty('tvnet_settings', '')
                self._tvnet_settings_mode = None
                self._focused_channel_grid = False
                self._last_channel_idx = -1
                if data_link != getattr(self, '_tvnet_last_url', None):
                    self._tvnet_loaded = False
                    self._tvnet_loading = False
                    self._tvnet_channels = []
                    self._tvnet_last_url = data_link
                    self.getControl(530).reset()
                    self.getControl(531).reset()
                    self.setProperty('tvnet_name', '')
                    self.setProperty('tvnet_logo', '')
                    self.setProperty('tvnet_number', '')
                    self.setProperty('tvnet_show', '')
                    self.setProperty('tvnet_time', '')
                    self.setProperty('tvnet_plot', '')
                    self.setProperty('tvnet_count', '')
                    self._load_tv_networks(data_link)
                elif self._tvnet_loaded:
                    self._populate_tvnet_grid()
                    if self._tvnet_channels:
                        self._update_featured_channel(0)
        elif 'movies section' in title_lower or 'tv shows section' in title_lower or is_tmdb_movie:
            # log(f'Detected TMDB movie item, link={link}')
            log(f'Detected TMDB movie item, link=TMDB')
            self.setProperty('preview_mode', 'tmdb_movies')
            self._movie_rotating = False
            self._tmdb_movies_loaded = False
            self._tmdb_loading = False
            self.setProperty('tmdb_title', '')
            self.setProperty('tmdb_poster', '')
            self.setProperty('tmdb_year', '')
            self.setProperty('tmdb_rating', '')
            self.setProperty('tmdb_overview', '')
            self.setProperty('tmdb_top_label', '')
            self._load_tmdb_movies()
        elif is_trakt:
            # log(f'Detected Trakt item, link={link}')
            log(f'Detected Trakt item, link=TRAKT')
            self.setProperty('preview_mode', 'tmdb_movies')
            self._movie_rotating = False
            self._tmdb_movies_loaded = False
            self._tmdb_loading = False
            self.setProperty('tmdb_title', '')
            self.setProperty('tmdb_poster', '')
            self.setProperty('tmdb_year', '')
            self.setProperty('tmdb_rating', '')
            self.setProperty('tmdb_overview', '')
            self.setProperty('tmdb_top_label', '')
            self._load_trakt_items(link)
        else:
            self._live_loaded = False
            self._live_loading = False
            self._live_top_idx = 0
            self._movie_rotating = False
            self._tmdb_movies_loaded = False
            self._tmdb_loading = False
            self._tvnet_loaded = False
            self._tvnet_loading = False
            self._tvnet_last_url = None
            self._tvnet_settings_mode = None
            self._focused_channel_grid = False
            self._last_channel_idx = -1
            self.getControl(530).reset()
            self.getControl(531).reset()
            self.setProperty('tvnet_settings', '')
            self.setProperty('preview_mode', 'default')

    def _search_music_search(self, query_val, raw_item):
        log(f'_search_music_search called with query_val={query_val}')
        dir_url = raw_item.get('link', '')
        if not dir_url:
            xbmcgui.Dialog().ok("JSON Search", "No search URL configured.")
            return

        query = xbmcgui.Dialog().input("Search")
        if not query:
            return

        query = query.lower()

        import requests
        from bs4 import BeautifulSoup
        from concurrent.futures import ThreadPoolExecutor, as_completed

        progress = xbmcgui.DialogProgress()
        progress.create("JSON Search", f"Searching for: {query}...")
        jen_list = []

        try:
            if dir_url.lower().endswith(('.json', '.enc')):
                progress.update(10, f"Fetching JSON file...")
                try:
                    response = requests.get(dir_url, timeout=15)
                    if response.status_code == 200:
                        items = response.json().get("items", [])
                        jen_list = [x for x in items if query in x.get("title", x.get("name", "")).lower()]
                except Exception as e:
                    log(f'Failed to fetch JSON from {dir_url}: {e}', level=xbmc.LOGERROR)
            else:
                if not dir_url.endswith('/'):
                    dir_url += '/'
                progress.update(10, "Fetching directory listing...")
                try:
                    response = requests.get(dir_url, timeout=15)
                    if response.status_code == 200:
                        soup = BeautifulSoup(response.text, 'html.parser')
                        json_files = [dir_url + link.get('href') for link in soup.find_all('a')
                                      if link.get('href', '').lower().endswith(('.json', '.enc'))]

                        total = len(json_files)
                        def process_json_file(json_file):
                            try:
                                resp = requests.get(json_file, timeout=15)
                                if resp.status_code == 200:
                                    items = resp.json().get("items", [])
                                    return [x for x in items if query in x.get("title", x.get("name", "")).lower()]
                            except Exception:
                                pass
                            return []

                        with ThreadPoolExecutor(max_workers=10) as executor:
                            future_to_url = {executor.submit(process_json_file, url): url for url in json_files}
                            for i, future in enumerate(as_completed(future_to_url)):
                                if progress.iscanceled():
                                    break
                                pct = int((i + 1) / total * 100) if total else 100
                                progress.update(pct, f"Processing {i + 1}/{total} files...")
                                matched_items = future.result()
                                if matched_items:
                                    jen_list.extend(matched_items)
                except Exception as e:
                    log(f'Failed to fetch directory from {dir_url}: {e}', level=xbmc.LOGERROR)
        except Exception as e:
            log(f'JSON Search error: {e}', level=xbmc.LOGERROR)

        progress.close()

        if not jen_list:
            xbmcgui.Dialog().ok("JSON Search", f"No results found for '{query}'")
            return

        self._pvr_display_results(jen_list, f'JSON Search: {query}')

    def _youtube_search(self):
        log('_youtube_search called')
        query = xbmcgui.Dialog().input("Search YouTube")
        if not query:
            return
        progress = None
        try:
            from resources.lib.external import yt_dlp
            progress = xbmcgui.DialogProgress()
            progress.create("YouTube Search", f"Searching for: {query}...")
            progress.update(0, "Fetching results...")
            with yt_dlp.YoutubeDL({"noplaylist": True, "extract_flat": "in_playlist", "quiet": True}) as ydl:
                info = ydl.extract_info("ytsearch50:" + query, download=False)
            xbmc.sleep(500)
            progress.close()
        except Exception as e:
            log(f'YouTube search failed: {e}', level=xbmc.LOGERROR)
            if progress:
                try:
                    progress.close()
                except Exception:
                    pass
            xbmcgui.Dialog().ok("YouTube Search Error", f"Search failed: {str(e)}")
            return
        jen_list = [{
            "title": entry.get("title", ""),
            "thumbnail": entry.get("thumbnails", [{}])[0].get("url", "") if entry.get("thumbnails") else "",
            "fanart": entry.get("thumbnails", [{}])[0].get("url", "") if entry.get("thumbnails") else "",
            "ytdlp": entry.get("id", ""),
            "type": "item"
        } for entry in info.get("entries", []) if entry]
        if not jen_list:
            xbmcgui.Dialog().ok("YouTube Search", f"No results found for '{query}'")
            return
        self._pvr_display_results(jen_list, f'YouTube: {query}')

    def _fmstream_fetch_page(self, query, offset=0):
        import requests as _requests
        import re as _re
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36'}
        params = {"s": query}
        if offset > 0:
            params["n"] = str(offset)
        import time as _time
        for attempt in range(4):
            resp = _requests.get("https://fmstream.org/index.php", params=params, headers=headers, timeout=15)
            if resp.status_code == 429:
                _time.sleep(3 * (attempt + 1))
                continue
            resp.raise_for_status()
            break
        else:
            raise Exception("Rate limited by fmstream.org. Please wait and try again.")
        page = resp.text
        m = _re.search(r'const\s+fetchIds\s*=\s*"([^"]*)"', page)
        if not m or not m.group(1).strip():
            return [], -1
        fetch_ids = m.group(1).strip().split(",")
        next_offset = -1
        next_m = _re.search(r'href="\?[^"]*n=(\d+)"[^>]*>Next', page)
        if next_m:
            next_offset = int(next_m.group(1))
        return fetch_ids, next_offset

    def _fmstream_build_station_list(self, fetch_ids, query, next_offset):
        import requests as _requests
        import json as _json
        from urllib.parse import quote as _url_quote
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36'}
        fetch_ids_str = ",".join(fetch_ids)
        data = _requests.post(
            "https://fmstream.org/stations2.php",
            data={"ids": fetch_ids_str, "app": "fmstream"},
            headers=headers,
            timeout=30
        ).json()
        if not data or (isinstance(data, dict) and data.get("error")):
            return []
        jen_list = []
        full_plugin = f"plugin://{ADDON_ID}"
        for row in data:
            try:
                program = row[1] or "Unknown"
                city = row[3] or ""
                reg = row[4] or ""
                itu = row[5] or ""
                style = row[6] or ""
                frq = row[7] or ""
                homepage = row[8] or ""
                branding = row[9] or ""
                slogan = row[10] or ""
                description = row[11] or ""
                urls_raw = row[2] if len(row) > 2 else []
                if isinstance(urls_raw, str):
                    try:
                        urls_raw = _json.loads(urls_raw)
                    except Exception:
                        urls_raw = []
                streams = []
                for u in urls_raw:
                    try:
                        raw_url = u[0] or ""
                        codec = u[1] or "web"
                        bitrate = u[2] if len(u) > 2 and u[2] else 0
                        profile = u[7] if len(u) > 7 else None
                        active = u[8] if len(u) > 8 else 1
                        if not raw_url or codec == "web":
                            continue
                        if active == 0:
                            continue
                        full_url = raw_url if raw_url.startswith("http") else f"http://{raw_url}"
                        if 'myradiostream.com' in full_url:
                            full_url = full_url.replace('https://', 'http://').replace(':/', ':').rstrip(';/')
                            if not full_url.endswith('/listen.mp3'):
                                full_url += '/listen.mp3'
                        br_kbps = int(round(bitrate / 1000)) if bitrate else 0
                        codec_label = profile if profile else codec.upper()
                        streams.append((full_url, br_kbps, codec_label))
                    except Exception:
                        continue
                if not streams and homepage:
                    hp = homepage if homepage.startswith("http") else f"http://{homepage}"
                    streams.append((hp, 0, "WEB"))
                if not streams:
                    continue
                summary_parts = []
                loc = ", ".join(filter(None, [city, reg, itu]))
                if loc:
                    summary_parts.append(loc)
                if style:
                    summary_parts.append(style)
                if frq:
                    summary_parts.append(f"Freq: {frq}")
                if description:
                    summary_parts.append(description[:200] + "..." if len(description) > 200 else description)
                if branding:
                    summary_parts.append(branding)
                if slogan:
                    summary_parts.append(slogan)
                if homepage:
                    summary_parts.append(homepage)
                summary = " | ".join(summary_parts).strip() or "No description available."
                best = streams[0][0]
                stream_label = f"{streams[0][1]}kbps {streams[0][2]}" if streams[0][1] else streams[0][2]
                if len(streams) > 1:
                    stream_label += f" (+{len(streams)-1} more)"
                if best.endswith(('.m3u8', '.mp3', '.aac', '.pls')):
                    stream_link = best
                else:
                    stream_link = f"{full_plugin}/fmstream/play/{_url_quote(best)}"
                jen_data = {
                    "title": f"[{stream_label}] [COLOR=cyan]{program}[/COLOR]",
                    "link": stream_link,
                    "type": "item",
                    "summary": summary
                }
                jen_list.append(jen_data)
            except Exception:
                continue
        if next_offset >= 0:
            jen_list.append({
                "title": "Next Page >>",
                "fmstream_next": f"/fmstream/next/{_url_quote(query)}/{next_offset}",
                "type": "item",
                "summary": "Load next 50 results from fmstream.org"
            })
        return jen_list

    def _fmstream_search(self, fmstream_val):
        log(f'_fmstream_search called with fmstream_val={fmstream_val}')
        query_part = fmstream_val.replace('search', '', 1).strip('/')
        if query_part == '*':
            query = xbmcgui.Dialog().input("Enter query")
            if not query:
                return
        else:
            query = query_part
        xbmcgui.Dialog().ok("FMStream - Rate Limit Notice", "Searching fmstream.org...\n\nPlease avoid rapid or repeated searches. The site may temporarily block your IP if hit too frequently.\n\nClick OK to continue.")
        progress = None
        try:
            progress = xbmcgui.DialogProgress()
            progress.create("Radio Search", f"Searching for: {query}...")
            progress.update(0, "Fetching station IDs...")
            fetch_ids, next_offset = self._fmstream_fetch_page(query, 0)
        except Exception as e:
            log(f'FMStream search failed: {e}', level=xbmc.LOGERROR)
            if progress:
                try:
                    progress.close()
                except Exception:
                    pass
            xbmcgui.Dialog().ok("Radio Search Error", f"Failed to fetch search results: {str(e)}")
            return
        if not fetch_ids:
            if progress:
                try:
                    progress.close()
                except Exception:
                    pass
            xbmcgui.Dialog().ok("No Results", "No stations found for this query.")
            return
        try:
            progress.update(50, f"Fetching station data for {len(fetch_ids)} stations...")
            jen_list = self._fmstream_build_station_list(fetch_ids, query, next_offset)
            xbmc.sleep(500)
            progress.close()
        except Exception as e:
            log(f'FMStream build list failed: {e}', level=xbmc.LOGERROR)
            if progress:
                try:
                    progress.close()
                except Exception:
                    pass
            xbmcgui.Dialog().ok("Radio Search Error", f"Failed to fetch station data: {str(e)}")
            return
        if not jen_list:
            xbmcgui.Dialog().ok("No Results", "No stations found for this query. Try a different term (e.g., 'bbc' or 'pop').")
            return
        self._pvr_display_results(jen_list, f'Radio: {query}')

    def _fmstream_next(self, route_val):
        log(f'_fmstream_next called with route_val={route_val}')
        import urllib.parse as _urllib_parse
        parts = route_val.strip('/').split('/')
        if len(parts) >= 4:
            query = _urllib_parse.unquote_plus(parts[2])
            offset = int(parts[3])
        else:
            return
        progress = None
        is_country = len(query) == 3 and query.isalpha() and query.isupper()
        try:
            progress = xbmcgui.DialogProgress()
            progress.create("Radio", f"Loading next page...")
            progress.update(0, "Fetching station IDs...")
            if is_country:
                fetch_ids, next_offset = self._fmstream_fetch_country(query, offset)
            else:
                fetch_ids, next_offset = self._fmstream_fetch_page(query, offset)
        except Exception as e:
            log(f'FMStream next page failed: {e}', level=xbmc.LOGERROR)
            if progress:
                try:
                    progress.close()
                except Exception:
                    pass
            xbmcgui.Dialog().ok("Radio Error", f"Failed to fetch next page: {str(e)}")
            return
        if not fetch_ids:
            if progress:
                try:
                    progress.close()
                except Exception:
                    pass
            xbmcgui.Dialog().ok("No More Results", "No more stations found.")
            return
        try:
            progress.update(50, f"Fetching station data for {len(fetch_ids)} stations...")
            jen_list = self._fmstream_build_station_list(fetch_ids, query, next_offset)
            xbmc.sleep(500)
            progress.close()
        except Exception as e:
            log(f'FMStream build list failed: {e}', level=xbmc.LOGERROR)
            if progress:
                try:
                    progress.close()
                except Exception:
                    pass
            xbmcgui.Dialog().ok("Radio Error", f"Failed to fetch station data: {str(e)}")
            return
        if not jen_list:
            xbmcgui.Dialog().ok("No More Results", "No more stations found.")
            return
        self._pvr_display_results(jen_list, f'Radio: {query}')

    def _fmstream_fetch_featured(self):
        import requests as _requests
        import re as _re
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36'}
        import time as _time
        for attempt in range(4):
            resp = _requests.get("https://fmstream.org/index.php", params={"li": "FT"}, headers=headers, timeout=15)
            if resp.status_code == 429:
                _time.sleep(3 * (attempt + 1))
                continue
            resp.raise_for_status()
            break
        else:
            raise Exception("Rate limited by fmstream.org. Please wait and try again.")
        page = resp.text
        m = _re.search(r'const\s+fetchIds\s*=\s*"([^"]*)"', page)
        if not m or not m.group(1).strip():
            return []
        return m.group(1).strip().split(",")

    def _fmstream_featured(self):
        log('_fmstream_featured called')
        xbmcgui.Dialog().ok("FMStream - Rate Limit Notice", "Loading featured stations from fmstream.org...\n\nClick OK to continue.")
        progress = None
        try:
            progress = xbmcgui.DialogProgress()
            progress.create("Radio Featured", "Fetching featured stations...")
            progress.update(0, "Fetching station IDs...")
            fetch_ids = self._fmstream_fetch_featured()
        except Exception as e:
            log(f'FMStream featured failed: {e}', level=xbmc.LOGERROR)
            if progress:
                try:
                    progress.close()
                except Exception:
                    pass
            xbmcgui.Dialog().ok("Radio Featured Error", f"Failed to fetch featured stations: {str(e)}")
            return
        if not fetch_ids:
            if progress:
                try:
                    progress.close()
                except Exception:
                    pass
            xbmcgui.Dialog().ok("No Results", "No featured stations found.")
            return
        try:
            progress.update(50, f"Fetching station data for {len(fetch_ids)} stations...")
            jen_list = self._fmstream_build_station_list(fetch_ids, "featured", -1)
            xbmc.sleep(500)
            progress.close()
        except Exception as e:
            log(f'FMStream build list failed: {e}', level=xbmc.LOGERROR)
            if progress:
                try:
                    progress.close()
                except Exception:
                    pass
            xbmcgui.Dialog().ok("Radio Featured Error", f"Failed to fetch station data: {str(e)}")
            return
        if not jen_list:
            xbmcgui.Dialog().ok("No Results", "No featured stations found.")
            return
        self._pvr_display_results(jen_list, 'Radio: Featured Stations')

    def _fmstream_get_country_code(self, name):
        COUNTRY_CODES = {
            "usa": "USA", "us": "USA", "united states": "USA",
            "canada": "CAN", "can": "CAN",
            "uk": "G", "united kingdom": "G", "britain": "G", "england": "G", "great britain": "G",
            "australia": "AUS", "aus": "AUS",
            "germany": "D", "deutschland": "D",
            "france": "F",
            "japan": "J",
            "india": "IND",
            "brazil": "BR",
            "mexico": "MEX",
            "spain": "E", "espana": "E",
            "italy": "I",
            "netherlands": "H", "holland": "H",
            "ireland": "IRL",
            "new zealand": "NZL",
            "south africa": "ZA",
            "sweden": "S",
            "norway": "NOR",
            "denmark": "DK",
            "finland": "FIN",
            "poland": "PL",
            "portugal": "P",
            "russia": "RUS",
            "china": "CHN",
            "south korea": "KOR", "korea": "KOR",
            "argentina": "RA",
            "colombia": "CO",
            "chile": "RCH",
            "philippines": "PHL",
            "nigeria": "NGA",
            "kenya": "EAK",
            "jamaica": "JA",
            "trinidad": "TT", "trinidad and tobago": "TT",
            "puerto rico": "PR",
            "cuba": "CUB",
            "greece": "GR",
            "turkey": "TR",
            "egypt": "EGY",
            "pakistan": "PK",
            "bangladesh": "BD",
            "sri lanka": "CL",
            "singapore": "SGP",
            "malaysia": "MAL",
            "thailand": "THA",
            "vietnam": "VN",
            "indonesia": "RI",
        }
        name_lower = name.lower().strip()
        if name_lower in COUNTRY_CODES:
            return COUNTRY_CODES[name_lower]
        if len(name_lower) <= 3 and name_lower.isalpha():
            return name_lower.upper()
        return name_lower.upper()[:3]

    def _fmstream_fetch_country(self, country_code, offset=0):
        import requests as _requests
        import re as _re
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36'}
        params = {"c": country_code, "o": "top"}
        if offset > 0:
            params["n"] = str(offset)
        import time as _time
        for attempt in range(4):
            resp = _requests.get("https://fmstream.org/index.php", params=params, headers=headers, timeout=15)
            if resp.status_code == 429:
                _time.sleep(3 * (attempt + 1))
                continue
            resp.raise_for_status()
            break
        else:
            raise Exception("Rate limited by fmstream.org. Please wait and try again.")
        page = resp.text
        m = _re.search(r'const\s+fetchIds\s*=\s*"([^"]*)"', page)
        if not m or not m.group(1).strip():
            return [], -1
        fetch_ids = m.group(1).strip().split(",")
        next_offset = -1
        next_m = _re.search(r'href="\?[^"]*n=(\d+)"[^>]*>Next', page)
        if next_m:
            next_offset = int(next_m.group(1))
        return fetch_ids, next_offset

    def _fmstream_country(self, country_name):
        log(f'_fmstream_country called with country_name={country_name}')
        if country_name.startswith("country/"):
            country_name = country_name[len("country/"):]
        if country_name == "*":
            country_name = xbmcgui.Dialog().input("Enter country name")
            if not country_name:
                return
        country_code = self._fmstream_get_country_code(country_name)
        country_label = country_name.upper()
        xbmcgui.Dialog().ok("FMStream - Rate Limit Notice", f"Loading top stations from {country_label}...\n\nClick OK to continue.")
        progress = None
        try:
            progress = xbmcgui.DialogProgress()
            progress.create("Radio Country", f"Fetching top stations from {country_label}...")
            progress.update(0, "Fetching station IDs...")
            fetch_ids, next_offset = self._fmstream_fetch_country(country_code, 0)
        except Exception as e:
            log(f'FMStream country failed: {e}', level=xbmc.LOGERROR)
            if progress:
                try:
                    progress.close()
                except Exception:
                    pass
            xbmcgui.Dialog().ok("Radio Country Error", f"Failed to fetch stations for {country_label}: {str(e)}")
            return
        if not fetch_ids:
            if progress:
                try:
                    progress.close()
                except Exception:
                    pass
            xbmcgui.Dialog().ok("No Results", f"No stations found for {country_label}.")
            return
        try:
            progress.update(50, f"Fetching station data for {len(fetch_ids)} stations...")
            jen_list = self._fmstream_build_station_list(fetch_ids, country_label, next_offset)
            xbmc.sleep(500)
            progress.close()
        except Exception as e:
            log(f'FMStream build list failed: {e}', level=xbmc.LOGERROR)
            if progress:
                try:
                    progress.close()
                except Exception:
                    pass
            xbmcgui.Dialog().ok("Radio Country Error", f"Failed to fetch station data: {str(e)}")
            return
        if not jen_list:
            xbmcgui.Dialog().ok("No Results", f"No stations found for {country_label}.")
            return
        self._pvr_display_results(jen_list, f'Radio: {country_label} Top Stations')

    def _xtream_action(self, route_val):
        log(f'_xtream_action called with route_val={route_val}')
        data = json.loads(route_val)
        action = data.get('action', '')
        if action == 'input':
            xbmc.executebuiltin(f'RunPlugin(plugin://{ADDON_ID}/xtream/input)')
        elif action == 'previous':
            xbmc.executebuiltin(f'RunPlugin(plugin://{ADDON_ID}/xtream/previous)')
        elif action == 'clear':
            xbmc.executebuiltin(f'RunPlugin(plugin://{ADDON_ID}/xtream/clear)')

    def _xtream_genres(self, route_val):
        log(f'_xtream_genres called')
        data = json.loads(route_val)
        action = data.get('action', '')
        address = data.get('address', '')
        username = data.get('username', '')
        password = data.get('password', '')
        cat = data.get('cat', '')
        progress = None
        try:
            progress = xbmcgui.DialogProgress()
            progress.create("Xtream", "Loading categories...")
            progress.update(0, "Connecting to server...")
            import requests as _requests
            r = _requests.get(address + f"/panel_api.php?username={username}&password={password}", timeout=15).json()
            if action in ('categories', 'categories'):
                jen_list = []
                for key, value in r.get('categories', {}).items():
                    for cat_item in value:
                        jen_list.append({
                            "title": f"{key.capitalize()} | {cat_item['category_name']}",
                            "xtream": {
                                "address": address,
                                "username": username,
                                "password": password,
                                "action": "category",
                                "cat": cat_item["category_id"]
                            },
                            "type": "dir"
                        })
                progress.close()
                if jen_list:
                    self._pvr_display_results(jen_list, 'Xtream Categories')
                else:
                    xbmcgui.Dialog().ok("Xtream", "No categories found.")
            elif action == 'category' and cat:
                progress.update(50, "Loading channels...")
                r2 = _requests.get(address + f"/panel_api.php?username={username}&password={password}", timeout=15).json()
                jen_list = []
                for channel_id, channel in r2.get('available_channels', {}).items():
                    if channel.get('category_id') != cat:
                        continue
                    jen_list.append({
                        "title": channel['name'],
                        "icon": channel.get('stream_icon', ''),
                        "sportjetextractors": [f"jetproxy://{address}/live/{username}/{password}/{channel_id}.m3u8?&Connection=keep-alive|X-Forwarded-For=24.37.42.200"],
                        "type": "item"
                    })
                progress.close()
                if jen_list:
                    self._pvr_display_results(jen_list, 'Xtream Channels')
                else:
                    xbmcgui.Dialog().ok("Xtream", "No channels in this category.")
        except Exception as e:
            log(f'_xtream_genres error: {e}', level=xbmc.LOGERROR)
            if progress:
                try:
                    progress.close()
                except Exception:
                    pass
            xbmcgui.Dialog().ok("Xtream Error", f"Failed: {str(e)}")

    def _mac_action(self, route_val):
        log(f'_mac_action called with route_val={route_val}')
        data = json.loads(route_val)
        action = data.get('action', '')
        if action == 'input':
            xbmc.executebuiltin(f'RunPlugin(plugin://{ADDON_ID}/mac/input)')
        elif action == 'previous':
            xbmc.executebuiltin(f'RunPlugin(plugin://{ADDON_ID}/mac/previous)')
        elif action == 'clear':
            xbmc.executebuiltin(f'RunPlugin(plugin://{ADDON_ID}/mac/clear)')

    def _mac_genres(self, route_val):
        log(f'_mac_genres called')
        data = json.loads(route_val)
        action = data.get('action', '')
        address = data.get('address', '')
        mac_addr = data.get('mac', '')
        username = data.get('username', '')
        password = data.get('password', '')
        genre = data.get('genre', '')
        page = data.get('page', 1)
        progress = None
        try:
            from resources.lib.plugins.mac import Server
            progress = xbmcgui.DialogProgress()
            progress.create("MAC Server", "Loading genres...")
            progress.update(0, "Connecting to server...")
            server = Server(address, mac_addr, username if username else '', password if password else '')
            if not username or not password:
                server.init()
                username = server.username
                password = server.password
            if action in ('genres', 'genres'):
                genres = server.api_request("get_genres", "itv")
                jen_list = []
                for g in genres:
                    jen_list.append({
                        "title": f"{g['id']} | {g['title']}",
                        "mac": {
                            "address": address,
                            "mac": mac_addr,
                            "username": username,
                            "password": password,
                            "action": "genre",
                            "genre": g["id"],
                        },
                        "type": "dir"
                    })
                progress.close()
                if jen_list:
                    self._pvr_display_results(jen_list, 'MAC Genres')
                else:
                    xbmcgui.Dialog().ok("MAC Server", "No genres found.")
            elif action == 'genre' and genre:
                progress.update(50, "Loading channels...")
                genre_listing = server.api_request("get_ordered_list", "itv", {"genre": genre, "p": int(page) if page else 1})
                jen_list = []
                for item in genre_listing.get('data', []):
                    link = item['cmd'].replace('ffmpeg ', '')
                    if 'localhost' in item['cmd']:
                        jen_list.append({
                            "title": item['name'],
                            "icon": item.get('logo', ''),
                            "mac": {
                                "address": address,
                                "mac": mac_addr,
                                "username": username,
                                "password": password,
                                "action": "play",
                                "link": link,
                                "title": item['name']
                            },
                            "type": "item"
                        })
                    else:
                        jen_list.append({
                            "title": item['name'],
                            "icon": item.get('logo', ''),
                            "link": link.replace('extension=ts', 'extension=m3u8'),
                            "type": "item"
                        })
                import math as _math
                total_items = genre_listing.get('total_items', 0)
                max_page = genre_listing.get('max_page_items', 50)
                pages = _math.ceil(total_items / max_page) if max_page else 1
                cur_page = int(page) if page else 1
                if cur_page * max_page < total_items:
                    jen_list.append({
                        "title": f"Page {cur_page + 1}/{pages}",
                        "mac": {
                            "address": address,
                            "mac": mac_addr,
                            "username": username,
                            "password": password,
                            "action": "genre",
                            "genre": genre,
                            "page": cur_page + 1
                        },
                        "type": "dir"
                    })
                progress.close()
                if jen_list:
                    self._pvr_display_results(jen_list, 'MAC Channels')
                else:
                    xbmcgui.Dialog().ok("MAC Server", "No channels found.")
        except Exception as e:
            log(f'_mac_genres error: {e}', level=xbmc.LOGERROR)
            if progress:
                try:
                    progress.close()
                except Exception:
                    pass
            xbmcgui.Dialog().ok("MAC Error", f"Failed: {str(e)}")

    def _mac_play(self, route_val):
        log(f'_mac_play called')
        data = json.loads(route_val)
        address = data.get('address', '')
        mac_addr = data.get('mac', '')
        username = data.get('username', '')
        password = data.get('password', '')
        link = data.get('link', '')
        title = data.get('title', 'MAC')
        try:
            from resources.lib.plugins.mac import Server
            server = Server(address, mac_addr, username if username else '', password if password else '')
            link_req = server.api_request("create_link", "itv", {"cmd": link})
            stream_url = link_req['cmd'].replace('ffmpeg ', '').replace('extension=ts', 'extension=m3u8')
            track("play", channel_name=strip_color_tags(title), url=stream_url, source="mac_play")
            xbmc.Player().stop()
            loading_overlay.show()
            liz = xbmcgui.ListItem(title)
            xbmc.Player().play(stream_url, liz)
        except Exception as e:
            log(f'_mac_play error: {e}', level=xbmc.LOGERROR)
            xbmcgui.Dialog().ok("MAC Play Error", f"Failed: {str(e)}")

    def _load_tv_networks(self, url):
        if self._tvnet_loading or self._tvnet_loaded:
            return

        import time
        now = time.time()
        cached = self._tvnet_cache.get(url)
        if cached and (now - cached['ts']) < self._tvnet_cache_ttl:
            # log(f'_load_tv_networks: using cached data for {url} ({len(cached["channels"])} channels)')
            log(f'_load_tv_networks: using cached data  ({len(cached["channels"])} channels)')
            self._tvnet_channels = cached['channels']
            self._tvnet_loaded = True
            self._tvnet_loading = False
            self._tvnet_idx = 0
            self._populate_tvnet_grid()
            if self._tvnet_channels:
                self._update_featured_channel(0)
            self.setProperty('tvnet_count', f'{len(self._tvnet_channels)} Channels')
            return

        self._tvnet_loading = True
        gen = self._preview_generation
        self.setProperty('tvnet_name', 'Loading...')
        self.setProperty('tvnet_show', 'Fetching channel data...')
        self.setProperty('tvnet_count', '')
        # log(f'_load_tv_networks: fetching {url}')
        log(f'_load_tv_networks: fetching (generation={gen})')

        def fetch():
            try:
                import datetime
                import time as _time
                response = fetch_json(
                    url,
                    use_cache=self.use_cache,
                    db=self.db,
                    session=self.session,
                )
                if not response:
                    self._tvnet_loading = False
                    if gen == self._preview_generation:
                        xbmc.executebuiltin('Notification(MadTitan,Failed to load channel data,3000)')
                    return

                data = json.loads(response)
                raw_items = data.get('items', [])

                channels = []
                ts = _time.time()
                utc_offset = (datetime.datetime.fromtimestamp(ts) - datetime.datetime.utcfromtimestamp(ts)).total_seconds()

                for item in raw_items:
                    title2 = item.get('title2', item.get('ch_id', ''))
                    thumbnail = item.get('thumbnail', '')
                    channel_number = item.get('channel_number', '')
                    guidedata = item.get('guidedata', [])

                    now_show = ''
                    now_time = ''
                    now_plot = ''
                    for prog in guidedata:
                        if prog.get('starttime', 0) <= ts < prog.get('starttime', 0) + prog.get('duration', 0):
                            start = datetime.datetime.utcfromtimestamp(prog['starttime'] + utc_offset)
                            end = datetime.datetime.utcfromtimestamp(prog['starttime'] + prog['duration'] + utc_offset)
                            now_show = strip_color_tags(prog.get('label', ''))
                            now_time = f"{start.strftime('%I:%M %p')} - {end.strftime('%I:%M %p')}"
                            now_plot = strip_color_tags(prog.get('plot', ''))
                            break

                    channels.append({
                        'title': title2 or strip_color_tags(item.get('title', '')),
                        'thumbnail': thumbnail,
                        'channel_number': channel_number,
                        'now_show': now_show,
                        'now_time': now_time,
                        'now_plot': now_plot,
                        'raw': item,
                    })

                self._tvnet_cache[url] = {'channels': channels, 'ts': _time.time()}

                if gen != self._preview_generation:
                    log('_load_tv_networks: stale generation, but data cached for next time')
                    self._tvnet_loading = False
                    return

                if self._tvnet_settings_mode:
                    log(f'_load_tv_networks: settings mode active ({self._tvnet_settings_mode}), skipping channel update')
                    self._tvnet_loading = False
                    return

                self._tvnet_channels = channels
                self._tvnet_loaded = True
                self._tvnet_loading = False
                self._tvnet_idx = 0
                log(f'_load_tv_networks: loaded {len(channels)} channels')

                self._populate_tvnet_grid()
                if channels:
                    self._update_featured_channel(0)
                self.setProperty('tvnet_count', f'{len(channels)} Channels')
            except Exception as e:
                log(f'_load_tv_networks error: {e}', level=xbmc.LOGERROR)
                self._tvnet_loading = False

        threading.Thread(target=fetch, daemon=True).start()

    def _populate_tvnet_grid(self):
        grid = self.getControl(530)
        grid.reset()
        for ch in self._tvnet_channels:
            li = xbmcgui.ListItem(label=ch['title'])
            if ch['thumbnail']:
                li.setArt({'icon': ch['thumbnail'], 'thumb': ch['thumbnail']})
            li.setProperty('ch_number', ch['channel_number'])
            li.setProperty('ch_show', ch['now_show'])
            grid.addItem(li)
        log(f'_populate_tvnet_grid: {grid.size()} items')

    def _update_featured_channel(self, idx):
        if idx < 0 or idx >= len(self._tvnet_channels):
            return
        ch = self._tvnet_channels[idx]
        self.setProperty('tvnet_logo', ch['thumbnail'])
        self.setProperty('tvnet_name', ch['title'])
        self.setProperty('tvnet_number', ch['channel_number'])
        self.setProperty('tvnet_show', ch['now_show'] or '')
        self.setProperty('tvnet_time', ch['now_time'])
        self.setProperty('tvnet_plot', ch['now_plot'])
        total = len(self._tvnet_channels)
        self.setProperty('tvnet_count', f'{idx + 1}/{total} Channels')
        log(f'_update_featured_channel idx={idx} ch="{ch["title"]}"')

    def _get_state_file(self):
        profile = xbmcvfs.translatePath(self.addon.getAddonInfo('profile'))
        if not os.path.exists(profile):
            os.makedirs(profile)
        return os.path.join(profile, 'gui_state.json')

    def _save_state(self, selected_idx):
        self._saved_state = {
            'items': list(self.items_data),
            'title': self.current_title,
            'url': self.current_url,
            'nav_stack': list(self.nav_stack),
            'selected_idx': selected_idx,
        }
        try:
            state = {
                'url': self.current_url or '',
                'title': self.current_title or '',
                'selected_idx': selected_idx,
            }
            with open(self._get_state_file(), 'w') as f:
                json.dump(state, f)
        except Exception as e:
            log(f'_save_state disk write error: {e}', level=xbmc.LOGERROR)

    def _restore_state(self):
        if self._saved_state:
            self.items_data = self._saved_state['items']
            self.current_title = self._saved_state['title']
            self.current_url = self._saved_state['url']
            self.nav_stack = self._saved_state['nav_stack']
            self.populate_list()
            lst = self.getControl(100)
            idx = self._saved_state.get('selected_idx', 0)
            if idx < lst.size():
                lst.selectItem(idx)
            self.update_preview(idx)
            self._saved_state = None
            log(f'Restored state: title="{self.current_title}", idx={idx}')
            return True
        return False

    def _restore_state_from_disk(self):
        try:
            state_file = self._get_state_file()
            if not os.path.exists(state_file):
                return False
            with open(state_file, 'r') as f:
                state = json.load(f)
            saved_url = state.get('url', '')
            saved_idx = state.get('selected_idx', 0)
            saved_title = state.get('title', '')
            if not saved_url:
                return False
            if saved_url == self.server_url or saved_url == self.current_url:
                if saved_idx >= 0 and saved_idx < len(self.items_data):
                    lst = self.getControl(100)
                    lst.selectItem(saved_idx)
                    self.update_preview(saved_idx)
                    log(f'Restored root state: idx={saved_idx}')
                    return True
                return False
            self.load_items(saved_url, is_root=False, push_nav=True)
            lst = self.getControl(100)
            if saved_idx >= 0 and saved_idx < lst.size():
                lst.selectItem(saved_idx)
                self.update_preview(saved_idx)
            log(f'Restored disk state: url="{saved_url}", title="{saved_title}", idx={saved_idx}')
            return True
        except Exception as e:
            log(f'_restore_state_from_disk error: {e}', level=xbmc.LOGERROR)
            return False

    def _clear_state_file(self):
        try:
            state_file = self._get_state_file()
            if os.path.exists(state_file):
                os.remove(state_file)
                log('_clear_state_file: removed gui_state.json')
        except Exception as e:
            log(f'_clear_state_file error: {e}', level=xbmc.LOGERROR)

    def _refresh_menu(self):
        if self.db:
            try:
                self.db.refresh_menu()
            except Exception as e:
                log(f'refresh_menu cache clear error: {e}', level=xbmc.LOGERROR)
        if self.current_url:
            self.load_items(self.current_url, is_root=(not self.nav_stack), push_nav=False)
        else:
            self.load_items(self.server_url, is_root=True, push_nav=False)
        log('_refresh_menu: reloaded items')

    def _is_tvnet_item(self):
        lst = self.getControl(100)
        idx = lst.getSelectedPosition()
        if idx < 0 or idx >= len(self.items_data):
            return False
        item = self.items_data[idx]
        title = strip_color_tags(item.get('title', '')).lower()
        raw = item.get('raw', {})
        link = raw.get('link', '')
        if isinstance(link, list) and link:
            link = link[0]
        tvnet_keywords = [
            'sports networks', 'tvnet', 'sport networks', 'us entertainment',
            'news channels', 'us movies', 'us local', 'live tv', 'channel list', 'replay rewind',
            'tools', 'addon settings', 'uk entertainment','uk movies',
            'jetextractors',
            'telegram server', 'homeiptv server','file iptv',
        ]
        if any(kw in title for kw in tvnet_keywords):
            return True
        if isinstance(link, str) and (link.startswith('plugin://') or not link.startswith('http')):
            return False
        return False

    def onClose(self):
        self._closing = True
        self._stream_prefs_cache = None
        if self._poll_timer:
            self._poll_timer.cancel()
            self._poll_timer = None
        threading.Thread(target=flush_session, daemon=True).start()

    def onClick(self, control_id):
        if control_id == 200:
            self._closing = True
            if not self.nav_stack:
                self._clear_state_file()
            if self._poll_timer:
                self._poll_timer.cancel()
                self._poll_timer = None
            threading.Thread(target=flush_session, daemon=True).start()
            self.close()
            return

        if control_id == 201:
            player = xbmc.Player()
            if player.isPlaying():
                xbmc.executebuiltin('ActivateWindow(fullscreenvideo)')
            return

        if control_id == 510:
            game_list = self.getControl(510)
            g_idx = game_list.getSelectedPosition()
            if g_idx < 0 or g_idx >= len(self._live_games):
                return
            g = self._live_games[g_idx]
            self.play_sports_event_from_game(
                g.get('team1', ''), g.get('team2', ''), g.get('sport', '')
            )
            return

        if control_id == 100:
            lst = self.getControl(100)
            idx = lst.getSelectedPosition()
            if idx < 0 or idx >= len(self.items_data):
                return

            item_data = self.items_data[idx]
            route_type, route_val = item_data['route']

            if route_type == 'dir':
                self.load_items(route_val, is_root=False, push_nav=True)

            elif route_type == 'action':
                if route_val == '/refresh_menu':
                    self._refresh_menu()
                else:
                    self._save_state(idx)
                    track("play", channel_name=strip_color_tags(item_data['title']), url=route_val, source="action")
                    raw_link = item_data.get('raw', {}).get('link', '')
                    if 'links://' in str(raw_link):
                        loading_overlay.show()
                    xbmc.executebuiltin(
                        f'RunPlugin(plugin://{ADDON_ID}{route_val})'
                    )
                    self._pending_recently_played = {'title': item_data['title'], 'thumbnail': item_data.get('thumbnail', ''), 'fallback_link': f'plugin://{ADDON_ID}{route_val}', 'time': time.time()}

            elif route_type == 'resolveurl_auth':
                xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)')

            elif route_type == 'resolveurl_settings':
                import xbmcaddon
                xbmcaddon.Addon('script.module.resolveurl').openSettings()

            elif route_type == 'plugin':
                self._save_state(idx)
                track("play", channel_name=strip_color_tags(item_data['title']), url=route_val, source="plugin")
                if route_val.lower().startswith(f'plugin://{ADDON_ID.lower()}/'):
                    xbmc.executebuiltin(f'RunPlugin({route_val})')
                else:
                    plug_play_item2 = {"title": item_data.get('title', ''), "link": route_val}
                    plug_enc2 = base64.urlsafe_b64encode(bytes(json.dumps(plug_play_item2), 'utf-8')).decode('utf-8')
                    xbmc.executebuiltin(f'RunPlugin(plugin://{ADDON_ID}/play_video/{plug_enc2})')
                self._pending_recently_played = {'title': item_data['title'], 'thumbnail': item_data.get('thumbnail', ''), 'fallback_link': route_val, 'time': time.time()}

            elif route_type == 'list_pick':
                self._show_link_dialog()

            elif route_type == 'pvr_search':
                self._save_state(idx)
                self._pvr_search(route_val)

            elif route_type == 'pvr_play':
                self._show_link_dialog()

            elif route_type == 'file_iptv_search':
                self._save_state(idx)
                self._file_iptv_search(route_val)

            elif route_type == 'file_iptv_search_country':
                self._save_state(idx)
                self._file_iptv_search_country()

            elif route_type == 'file_iptv_recent':
                self._save_state(idx)
                self._file_iptv_recent()

            elif route_type == 'file_iptv_play':
                self._file_iptv_play(item_data.get('raw', {}))

            elif route_type == 'search_music':
                self._save_state(idx)
                self._search_music_search(route_val, item_data.get('raw', {}))

            elif route_type == 'youtube_search':
                self._save_state(idx)
                self._youtube_search()

            elif route_type == 'youtube_play':
                self._save_state(idx)
                track("play", channel_name=strip_color_tags(item_data['title']), url=f'plugin://plugin.video.youtube/play/?video_id={route_val}', source="youtube")
                xbmc.executebuiltin(f'RunPlugin(plugin://plugin.video.youtube/play/?video_id={route_val})')

            elif route_type == 'fmstream_search':
                self._save_state(idx)
                self._fmstream_search(route_val)

            elif route_type == 'fmstream_next':
                self._save_state(idx)
                self._fmstream_next(route_val)

            elif route_type == 'fmstream_featured':
                self._save_state(idx)
                self._fmstream_featured()

            elif route_type == 'fmstream_country':
                self._save_state(idx)
                self._fmstream_country(route_val)

            elif route_type == 'espn_plus':
                self._save_state(idx)
                self._espn_plus_open(route_val)

            elif route_type == 'tmdb':
                self._save_state(idx)
                self._tmdb_open(route_val)

            elif route_type == 'trakt':
                self._save_state(idx)
                self._trakt_open(route_val)

            elif route_type == 'tmdb_item':
                self._tmdb_item_play(item_data.get('raw', {}))

            elif route_type == 'scraper_result':
                self._play_scraper_result(item_data.get('raw', {}))

            elif route_type == 'jet_action':
                self._save_state(idx)
                self._jet_action(route_val)

            elif route_type == 'jetextractors_manage':
                self._save_state(idx)
                self._jetextractors_manage(route_val)

            elif route_type == 'telegram_filter':
                self._save_state(idx)
                self._telegram_filter(route_val)

            elif route_type == 'homeiptv_filter':
                self._save_state(idx)
                self._homeiptv_filter(route_val)

            elif route_type == 'xtream_action':
                self._xtream_action(route_val)

            elif route_type == 'xtream_genres':
                self._save_state(idx)
                self._xtream_genres(route_val)

            elif route_type == 'mac_action':
                self._mac_action(route_val)

            elif route_type == 'mac_genres':
                self._save_state(idx)
                self._mac_genres(route_val)

            elif route_type == 'mac_play':
                self._save_state(idx)
                self._mac_play(route_val)

            elif route_type == 'recently_played':
                self._open_recently_played(item_data.get('raw', {}))

            elif route_type == 'play_http':
                self._save_state(idx)
                track("play", channel_name=strip_color_tags(item_data['title']), url=route_val, source="recently_played")
                xbmc.Player().stop()
                loading_overlay.show()
                xbmc.Player().play(route_val)

            elif route_type == 'myiptv_remote_search':
                self._save_state(idx)
                self._myiptv_remote_search()

            elif route_type == 'myiptv_remote_search_term':
                self._save_state(idx)
                self._myiptv_remote_search_term(route_val)

            elif route_type == 'myiptv_remote_full_search_term':
                self._save_state(idx)
                self._myiptv_remote_full_search_term(route_val)

            elif route_type == 'myiptv_remote_recent':
                self._save_state(idx)
                self._myiptv_remote_recent()

            elif route_type == 'myiptv_remote_menu':
                self._save_state(idx)
                self._myiptv_remote_menu()

            elif route_type == 'myiptv_remote_categories':
                self._save_state(idx)
                self._myiptv_remote_categories()

            elif route_type == 'myiptv_remote_genre':
                self._save_state(idx)
                self._myiptv_remote_genre(route_val)

            elif route_type == 'myiptv_remote_full_search':
                self._save_state(idx)
                self._myiptv_remote_search()

            elif route_type == 'myiptv_remote_action':
                self._save_state(idx)
                self._myiptv_remote_action(route_val)
                self._file_iptv_play(item_data['raw'])

            elif route_type == 'search_music':
                self._save_state(idx)
                self._search_music_search(route_val, item_data['raw'])

            elif route_type == 'youtube_search':
                self._save_state(idx)
                self._youtube_search()

            elif route_type == 'youtube_play':
                self._save_recently_played(item_data['title'], f'plugin://plugin.video.youtube/play/?video_id={route_val}', item_data.get('thumbnail', ''))
                self._save_state(idx)
                track("play", channel_name=strip_color_tags(item_data['title']), url=f'plugin://plugin.video.youtube/play/?video_id={route_val}', source="youtube")
                xbmc.executebuiltin(f'RunPlugin(plugin://plugin.video.youtube/play/?video_id={route_val})')

            elif route_type == 'fmstream_search':
                self._save_state(idx)
                self._fmstream_search(route_val)

            elif route_type == 'fmstream_next':
                self._save_state(idx)
                self._fmstream_next(route_val)

            elif route_type == 'fmstream_featured':
                self._save_state(idx)
                self._fmstream_featured()

            elif route_type == 'fmstream_country':
                self._save_state(idx)
                self._fmstream_country(route_val)

            elif route_type == 'espn_plus':
                self._save_state(idx)
                self._espn_plus_open(route_val)

            elif route_type == 'tmdb':
                self._save_state(idx)
                self._tmdb_open(route_val)

            elif route_type == 'trakt':
                self._save_state(idx)
                self._trakt_open(route_val)

            elif route_type == 'tmdb_item':
                self._tmdb_item_play(item_data['raw'])

            elif route_type == 'scraper_result':
                self._play_scraper_result(item_data['raw'])

            elif route_type == 'jet_action':
                self._save_state(idx)
                self._jet_action(route_val)

            elif route_type == 'jetextractors_manage':
                self._save_state(idx)
                self._jetextractors_manage(route_val)

            elif route_type == 'telegram_filter':
                self._save_state(idx)
                self._telegram_filter(route_val)

            elif route_type == 'homeiptv_filter':
                self._save_state(idx)
                self._homeiptv_filter(route_val)

            elif route_type == 'xtream_action':
                self._xtream_action(route_val)

            elif route_type == 'xtream_genres':
                self._save_state(idx)
                self._xtream_genres(route_val)

            elif route_type == 'mac_action':
                self._mac_action(route_val)

            elif route_type == 'mac_genres':
                self._save_state(idx)
                self._mac_genres(route_val)

            elif route_type == 'mac_play':
                self._save_state(idx)
                self._mac_play(route_val)

            elif route_type == 'recently_played':
                self._open_recently_played(item_data['raw'])

            elif route_type == 'play_http':
                self._save_state(idx)
                track("play", channel_name=strip_color_tags(item_data['title']), url=route_val, source="recently_played")
                xbmc.Player().stop()
                loading_overlay.show()
                xbmc.Player().play(route_val)

        if control_id == 531:
            grid = self.getControl(531)
            g_idx = grid.getSelectedPosition()
            log(f'Settings grid click: g_idx={g_idx}, total={len(self._tvnet_channels)}')
            if g_idx < 0 or g_idx >= len(self._tvnet_channels):
                return
            self._handle_settings_click(g_idx)
            return

        if control_id == 520:
            movie_list = self.getControl(520)
            m_idx = movie_list.getSelectedPosition()
            log(f'Movie widget click: m_idx={m_idx}, total={len(self._tmdb_movies)}')
            if m_idx < 0 or m_idx >= len(self._tmdb_movies):
                return
            m = self._tmdb_movies[m_idx]
            link = m.get('link', '')
            tmdb_id = m.get('id', m.get('tmdb_id', ''))
            if not tmdb_id and 'ids' in m:
                tmdb_id = m['ids'].get('tmdb', '')
            media_type = m.get('media_type', m.get('type', m.get('content', '')))
            if not media_type or media_type not in ('tv', 'tvshow', 'movie', 'item', 'dir'):
                if m.get('first_air_date'):
                    media_type = 'tv'
                elif m.get('release_date'):
                    media_type = 'movie'
                else:
                    media_type = 'movie'
            title = m.get('title', m.get('name', ''))

            # log(f'Movie widget item: title="{title}", tmdb_id={tmdb_id}, media_type={media_type}, link={link}')
            log(f'Movie widget item: title="{title}", tmdb_id={tmdb_id}, media_type={media_type}, link=LINK')


            if isinstance(link, str) and link.startswith('trakt/'):
                log(f'Movie widget: Trakt link detected, calling _trakt_open')
                self._trakt_open(link)
            elif isinstance(link, str) and link.startswith('tmdb/'):
                log(f'Movie widget: TMDB link detected, calling _tmdb_open')
                self._tmdb_open(link)
            elif media_type in ('tv', 'tvshow'):
                log(f'Movie widget: TV show detected, navigating to seasons')
                self._tmdb_open(f'tmdb/tv/{tmdb_id}')
            else:
                raw_item = {
                    'tmdb_id': str(tmdb_id),
                    'title': title,
                    'content': 'movie',
                }
                log(f'Movie widget playing movie: {raw_item["title"]} (tmdb_id={raw_item["tmdb_id"]})')
                self._tmdb_item_play(raw_item)

        if control_id == 530:
            ch_grid = self.getControl(530)
            c_idx = ch_grid.getSelectedPosition()
            main_idx = self.getControl(100).getSelectedPosition()
            log(f'Channel grid click: c_idx={c_idx}, total={len(self._tvnet_channels)}')
            if c_idx < 0 or c_idx >= len(self._tvnet_channels):
                return
            if self._tvnet_settings_mode:
                self._handle_settings_click(c_idx)
                return
            ch = self._tvnet_channels[c_idx]
            raw = ch.get('raw', {})
            link_list = raw.get('link', [])
            ch_title = ch.get('title', '')
            if isinstance(link_list, list) and link_list:
                if len(link_list) == 1:
                    selected_url = str(link_list[0])
                    if '(' in selected_url and selected_url.endswith(')'):
                        _, selected_url = self._parse_link(selected_url)

                    if selected_url.lower().startswith('plugin://'):
                        sp = self._get_stream_prefs()
                        pref = sp.get_preference(ch_title, 0, require_playable=True, match_any_index=True)
                        if not pref:
                            import re as _re
                            m = _re.search(r'file_iptv/search/[^:]*:::(.+?)(?:/|$)', selected_url, _re.IGNORECASE)
                            if m:
                                search_term = m.group(1)
                                pref = sp.get_preference(search_term, 0, require_playable=True, match_any_index=True)
                                if pref:
                                    log(f'Channel grid: found pref by search term "{search_term}"')

                        if pref and pref.get('url'):
                            saved_url = pref['url']
                            saved_label = pref.get('label', ch_title)
                            runnable_url = sp.to_runnable_url(saved_url)
                            log(f'Channel grid: single-link auto-play pref for "{ch_title}" url={saved_url[:80]} runnable={runnable_url[:80]}')
                            self._save_state(main_idx)
                            track("play", channel_name=strip_color_tags(ch_title), url=saved_url, source="channel_pref")
                            xbmc.Player().stop()
                            is_links = saved_url.lower().startswith('links://')
                            loading_overlay.show()
                            if saved_url.lower().startswith('http'):
                                xbmc.Player().play(saved_url)
                            else:
                                xbmc.executebuiltin(f'RunPlugin({runnable_url})')
                            if is_links:
                                log(f'Channel grid: single-link links:// pref, JetExtractors will handle playback')
                                return
                            for _ in range(8):
                                xbmc.sleep(500)
                                if xbmc.Player().isPlaying():
                                    break
                            if xbmc.Player().isPlaying():
                                log(f'Channel grid: single-link auto-play succeeded')
                                return
                            else:
                                loading_overlay.close()
                                log(f'Channel grid: single-link auto-play failed, running original')
                                xbmcgui.Dialog().notification('Stream Preferences', 'Preferred stream failed, trying default', xbmcgui.NOTIFICATION_WARNING, 3000)

                    self._open_channel_link(selected_url, raw, c_idx, ch_title=ch_title)
                    log(f'Channel grid: single-link after _open_channel_link url={selected_url[:80]}')
                    try:
                        if selected_url.lower().startswith('plugin://'):
                            _sp = self._get_stream_prefs()
                            actual_url = _sp.extract_url_from_plugin(selected_url)
                            log(f'Channel grid: single-link actual_url={actual_url[:80] if actual_url else "None"}')
                            if actual_url and _sp.is_playable_url(actual_url):
                                _sp.save_preference(ch_title, 0, actual_url, ch_title)
                                log(f'Channel grid: saved pref for "{ch_title}" url={actual_url[:80]}')
                        elif self._get_stream_prefs().is_playable_url(selected_url):
                            self._get_stream_prefs().save_preference(ch_title, 0, selected_url, ch_title)
                    except Exception as e:
                        log(f'Channel grid: single-link save error: {e}', level=xbmc.LOGERROR)
                else:
                    labels = []
                    urls = []
                    for lnk in link_list:
                        label, url = self._parse_link(str(lnk))
                        labels.append(label)
                        urls.append(url)

                    sp = self._get_stream_prefs()
                    pref = None
                    for li_i in range(len(link_list)):
                        p = sp.get_preference(ch_title, li_i, require_playable=True)
                        if p:
                            pref = p
                            pref['_index'] = li_i
                            break

                    auto_played = False
                    if pref and pref.get('url'):
                        saved_url = pref['url']
                        saved_idx = pref.get('_index', 0)
                        saved_label = pref.get('label', labels[saved_idx] if saved_idx < len(labels) else '?')
                        runnable_url = sp.to_runnable_url(saved_url)
                        log(f'Channel grid: auto-play pref index={saved_idx} label={saved_label} url={saved_url[:80]} runnable={runnable_url[:80]}')
                        self._save_state(main_idx)
                        track("play", channel_name=strip_color_tags(ch_title), url=saved_url, source="channel_pref")
                        xbmc.Player().stop()
                        is_links = saved_url.lower().startswith('links://')
                        loading_overlay.show()
                        if saved_url.lower().startswith('http'):
                            xbmc.Player().play(saved_url)
                        else:
                            xbmc.executebuiltin(f'RunPlugin({runnable_url})')
                        if is_links:
                            log(f'Channel grid: multi-link links:// pref, JetExtractors will handle playback')
                            auto_played = True
                        else:
                            for _ in range(8):
                                xbmc.sleep(500)
                                if xbmc.Player().isPlaying():
                                    break
                            if xbmc.Player().isPlaying():
                                log(f'Channel grid: auto-play succeeded')
                                auto_played = True
                            else:
                                loading_overlay.close()
                                log(f'Channel grid: auto-play failed, showing dialog')
                                xbmcgui.Dialog().notification('Stream Preferences', 'Preferred stream failed, showing picker', xbmcgui.NOTIFICATION_WARNING, 3000)

                    if not auto_played:
                        pick = xbmcgui.Dialog().select(ch_title, labels)
                    else:
                        pick = -1
                    if pick >= 0:
                        log(f'Channel grid: multi-link pick={pick} url={urls[pick][:80] if pick < len(urls) else "?"}')
                        self._open_channel_link(urls[pick], raw, c_idx, ch_title=ch_title)
                        try:
                            if sp.is_playable_url(urls[pick]):
                                log(f'Channel grid: multi-link saving directly playable url')
                                sp.save_preference(ch_title, pick, urls[pick], labels[pick])
                            else:
                                jet_list = raw.get('sportjetextractors', [])
                                log(f'Channel grid: multi-link jet_list={jet_list} pick={pick}')
                                if jet_list and pick < len(jet_list):
                                    jet_url = jet_list[pick].get('address', '')
                                    log(f'Channel grid: multi-link jet_url={jet_url[:80] if jet_url else "empty"}')
                                    if jet_url and sp.is_playable_url(jet_url):
                                        sp.save_preference(ch_title, pick, jet_url, labels[pick])
                                        log(f'Channel grid: multi-link saved jet pref')
                                else:
                                    actual = sp.extract_url_from_plugin(urls[pick])
                                    log(f'Channel grid: multi-link extracted={actual[:80] if actual else "None"}')
                                    if actual and sp.is_playable_url(actual):
                                        sp.save_preference(ch_title, pick, actual, labels[pick])
                                        log(f'Channel grid: multi-link saved extracted pref for "{ch_title}"')
                        except Exception as e:
                            log(f'Channel grid: multi-link save error: {e}', level=xbmc.LOGERROR)
            elif isinstance(link_list, str) and link_list:
                selected_url = str(link_list)
                log(f'Channel grid: string-link path url={selected_url[:80]}')
                if selected_url.lower().startswith('plugin://'):
                    sp = self._get_stream_prefs()
                    pref = sp.get_preference(ch_title, 0, require_playable=True, match_any_index=True)
                    if not pref:
                        import re as _re
                        m = _re.search(r'file_iptv/search/[^:]*:::(.+?)(?:/|$)', selected_url, _re.IGNORECASE)
                        if m:
                            search_term = m.group(1)
                            pref = sp.get_preference(search_term, 0, require_playable=True, match_any_index=True)

                    auto_played = False
                    if pref and pref.get('url'):
                        saved_url = pref['url']
                        runnable_url = sp.to_runnable_url(saved_url)
                        log(f'Channel grid: str-link auto-play pref for "{ch_title}" url={saved_url[:80]} runnable={runnable_url[:80]}')
                        self._save_state(main_idx)
                        track("play", channel_name=strip_color_tags(ch_title), url=saved_url, source="channel_pref")
                        xbmc.Player().stop()
                        loading_overlay.show()
                        if saved_url.lower().startswith('http'):
                            xbmc.Player().play(saved_url)
                        else:
                            xbmc.executebuiltin(f'RunPlugin({runnable_url})')
                        for _ in range(8):
                            xbmc.sleep(500)
                            if xbmc.Player().isPlaying():
                                break
                        if xbmc.Player().isPlaying():
                            log(f'Channel grid: str-link auto-play succeeded')
                            auto_played = True
                        else:
                            loading_overlay.close()
                            xbmcgui.Dialog().notification('Stream Preferences', 'Preferred stream failed, trying default', xbmcgui.NOTIFICATION_WARNING, 3000)

                    if not auto_played:
                        self._open_channel_link(selected_url, raw, c_idx, ch_title=ch_title)
                    try:
                        actual_url = sp.extract_url_from_plugin(selected_url)
                        log(f'Channel grid: str-link extracted={actual_url[:80] if actual_url else "None"} from {selected_url[:60]}')
                        if actual_url and sp.is_playable_url(actual_url):
                            sp.save_preference(ch_title, 0, actual_url, ch_title)
                            log(f'Channel grid: str-link saved pref for "{ch_title}" url={actual_url[:80]}')
                        else:
                            log(f'Channel grid: str-link NOT saved: actual_url={actual_url}, playable={sp.is_playable_url(actual_url) if actual_url else "N/A"}')
                    except Exception as e:
                        log(f'Channel grid: str-link save error: {e}', level=xbmc.LOGERROR)
                else:
                    self._open_channel_link(selected_url, raw, c_idx, ch_title=ch_title)
            return

    def _open_channel_link(self, url, raw, idx, ch_title=''):
        log(f'_open_channel_link v2: url={url[:100]}')
        title = strip_color_tags(str(ch_title or raw.get('title2', raw.get('title', raw.get('ch_id', 'Unknown')))))
        thumbnail = raw.get('thumbnail', '')
        main_idx = self.getControl(100).getSelectedPosition()
        track_feature("channel_click", action=title, url=url)

        # --- Stream preference: check for saved auto-play ---
        auto_played = False
        try:
            from resources.lib.stream_prefs import StreamPreferences as _SP
            sp = _SP()
            if sp.is_enabled():
                pref = sp.get_preference(title, 0, require_playable=True, match_any_index=True)
                if not pref:
                    import re as _re
                    m = _re.search(r'file_iptv/search/[^:]*:::(.+?)(?:/|$)', url, _re.IGNORECASE)
                    if m:
                        pref = sp.get_preference(m.group(1), 0, require_playable=True, match_any_index=True)
                        if pref:
                            log(f'_open_channel_link v2: found pref by search term "{m.group(1)}"')
                if pref and pref.get('url'):
                    saved_url = pref['url']
                    runnable_url = sp.to_runnable_url(saved_url)
                    log(f'_open_channel_link v2: auto-play pref for "{title}" url={saved_url[:80]}')
                    self._save_state(main_idx)
                    track("play", channel_name=title, url=saved_url, source="channel_pref")
                    xbmc.Player().stop()
                    is_http = saved_url.lower().startswith('http')
                    is_links = saved_url.lower().startswith('links://')
                    loading_overlay.show()
                    if is_http:
                        xbmc.Player().play(saved_url)
                    else:
                        xbmc.executebuiltin(f'RunPlugin({runnable_url})')
                    if is_links:
                        log(f'_open_channel_link v2: links:// pref, JetExtractors will handle playback for "{title}"')
                        auto_played = True
                    else:
                        wait_limit = 8 if is_http else 20
                        for _ in range(wait_limit):
                            xbmc.sleep(500)
                            if xbmc.Player().isPlaying():
                                break
                        if xbmc.Player().isPlaying():
                            if not is_http:
                                xbmc.sleep(3000)
                            if xbmc.Player().isPlaying():
                                log(f'_open_channel_link v2: auto-play succeeded for "{title}"')
                                auto_played = True
                            else:
                                loading_overlay.close()
                                log(f'_open_channel_link v2: auto-play stream died for "{title}", deleting bad pref')
                                xbmcgui.Dialog().notification('Stream Preferences', 'Preferred stream failed, removing it', xbmcgui.NOTIFICATION_WARNING, 3000)
                                try:
                                    _sp2 = self._get_stream_prefs()
                                    _sp2.delete_preference(_sp2.make_key(title, 0))
                                except Exception:
                                    pass
                        else:
                            loading_overlay.close()
                            log(f'_open_channel_link v2: auto-play failed for "{title}", deleting bad pref')
                            xbmcgui.Dialog().notification('Stream Preferences', 'Preferred stream failed, removing it', xbmcgui.NOTIFICATION_WARNING, 3000)
                            try:
                                _sp2 = self._get_stream_prefs()
                                _sp2.delete_preference(_sp2.make_key(title, 0))
                            except Exception:
                                pass
        except Exception as e:
            log(f'_open_channel_link v2: pref check error: {e}', level=xbmc.LOGERROR)

        if auto_played:
            return

        # --- Original play logic ---
        if url.lower().startswith('http') and not url.lower().endswith('.json'):
            self._save_recently_played(title, url, thumbnail)
            self._save_state(main_idx)
            track("play", channel_name=title, url=url, source="tv_network")
            xbmc.Player().stop()
            loading_overlay.show()
            xbmc.Player().play(url)
        elif url.lower().startswith('http') and url.lower().endswith('.json'):
            self._save_state(main_idx)
            self.load_items(url, is_root=False, push_nav=True)
            return
        else:
            self._save_state(main_idx)
            track("play", channel_name=title, url=url, source="tv_network")
            xbmc.Player().stop()
            loading_overlay.show()
            if 'search_json' in url and title:
                from urllib.parse import quote
                sep = '&' if '?' in url else '?'
                url_with_title = f'{url}{sep}ch_title={quote(title)}'
                xbmcgui.Window(10000).clearProperty('madtitan_resolved_url')
                self._pending_recently_played = {'title': title, 'thumbnail': thumbnail, 'fallback_link': url_with_title, 'time': time.time()}
                xbmc.executebuiltin(f'RunPlugin({url_with_title})')
            else:
                xbmcgui.Window(10000).clearProperty('madtitan_resolved_url')
                self._pending_recently_played = {'title': title, 'thumbnail': thumbnail, 'fallback_link': url, 'time': time.time()}
                xbmc.executebuiltin(f'RunPlugin({url})')

        # --- Stream preference: save after play ---
        try:
            _sp = self._get_stream_prefs()
            if _sp.is_enabled() and 'search_json' not in url:
                actual_url = _sp.extract_url_from_plugin(url)
                if actual_url and _sp.is_playable_url(actual_url):
                    _sp.save_preference(title, 0, actual_url, title)
                    log(f'_open_channel_link v2: saved pref for "{title}" url={actual_url[:80]}')
                elif _sp.is_playable_url(url):
                    _sp.save_preference(title, 0, url, title)
                    log(f'_open_channel_link v2: saved pref for "{title}" url={url[:80]}')
                else:
                    for _ in range(8):
                        xbmc.sleep(500)
                        if xbmc.Player().isPlaying():
                            break
                    if xbmc.Player().isPlaying():
                        playing_url = xbmc.Player().getPlayingFile()
                        if playing_url and _sp.is_playable_url(playing_url) and '127.0.0.1' not in playing_url:
                            _sp.save_preference(title, 0, playing_url, title)
                            log(f'_open_channel_link v2: saved playing url for "{title}" url={playing_url[:80]}')
        except Exception as e:
            log(f'_open_channel_link v2: pref save error: {e}', level=xbmc.LOGERROR)

    def _get_recent_file(self):
        import xbmcvfs
        profile = xbmcvfs.translatePath(self.addon.getAddonInfo('profile'))
        if not os.path.exists(profile):
            os.makedirs(profile)
        return os.path.join(profile, 'recently_played.json')

    def _save_recently_played(self, title, link, thumbnail=''):
        max_items = self.addon.getSettingInt('recently_played_count') if self.addon else 5
        if max_items <= 0:
            return
        recent_file = self._get_recent_file()
        recent = []
        if os.path.exists(recent_file):
            try:
                with open(recent_file, 'r', encoding='utf-8') as f:
                    recent = json.load(f)
            except Exception:
                recent = []
        recent = [r for r in recent if r.get('link') != link]
        recent.insert(0, {
            'title': strip_color_tags(title),
            'link': link,
            'thumbnail': thumbnail,
            'timestamp': time.time(),
        })
        recent = recent[:max_items]
        try:
            with open(recent_file, 'w', encoding='utf-8') as f:
                json.dump(recent, f)
            log(f'_save_recently_played: saved "{title}" ({len(recent)} items)')
        except Exception as e:
            log(f'_save_recently_played error: {e}', level=xbmc.LOGERROR)
        self._refresh_root_recently()

    def _refresh_root_recently(self):
        self._refresh_recently_pending = True

    def _do_refresh_root_recently(self):
        self._root_items = [i for i in self._root_items if i.get('route', (None,))[0] != 'recently_played']
        self._inject_recently_played_to(self._root_items)
        if not self.nav_stack:
            self.items_data = list(self._root_items)
            focused_id = self.getFocusId()
            if focused_id in (510, 520, 530, 531):
                self.populate_list(no_focus=True)
            else:
                self.populate_list()

    def _inject_recently_played_to(self, target_list):
        max_items = self.addon.getSettingInt('recently_played_count') if self.addon else 5
        if max_items <= 0:
            return
        recent = self._load_recently_played()
        if not recent:
            return
        summary_lines = []
        for r in recent:
            ts = r.get('timestamp', 0)
            link = r.get('link', '')
            source_short = ''
            if link:
                if link.startswith('plugin://'):
                    import re as _re
                    m = _re.search(r'ch_title=([^&]+)', link)
                    if m:
                        from urllib.parse import unquote
                        source_short = unquote(m.group(1))
                    else:
                        source_short = 'plugin'
                elif '://' in link:
                    source_short = link.split('://', 1)[-1][:50]
                else:
                    source_short = link[:50]
            if ts:
                dt = datetime.fromtimestamp(ts)
                time_str = dt.strftime('%m/%d %I:%M %p')
                line = f"[COLOR yellow]{time_str}[/COLOR] - {r['title']}"
                if source_short:
                    line += f"  [COLOR grey]({source_short})[/COLOR]"
                summary_lines.append(line)
            else:
                summary_lines.append(r['title'])
        summary = '\n'.join(summary_lines)
        thumbnail = recent[0].get('thumbnail', '') if recent else ''
        target_list.append({
            'title': '[COLOR orange]RECENTLY PLAYED[/COLOR]',
            'thumbnail': thumbnail,
            'fanart': '',
            'summary': summary,
            'route': ('recently_played', ''),
            'raw': {'recently_played': recent},
        })

    def _load_recently_played(self):
        recent_file = self._get_recent_file()
        if not os.path.exists(recent_file):
            return []
        try:
            with open(recent_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception:
            return []

    def _inject_recently_played(self):
        self._inject_recently_played_to(self._root_items)
        log(f'_inject_recently_played: added to root list')

    def _open_recently_played(self, raw):
        recent = raw.get('recently_played', [])
        if not recent:
            xbmcgui.Dialog().ok('Recently Played', 'No recently played items.')
            return
        items = []
        for r in recent:
            link = r.get('link', '')
            title = r.get('title', 'Unknown')
            thumbnail = r.get('thumbnail', '')
            ts = r.get('timestamp', 0)
            time_str = ''
            if ts:
                dt = datetime.fromtimestamp(ts)
                time_str = dt.strftime('%m/%d %I:%M %p')
            display_title = f'{title}  [COLOR grey]({time_str})[/COLOR]' if time_str else title
            if link:
                if link.startswith('plugin://'):
                    import re as _re
                    m = _re.search(r'ch_title=([^&]+)', link)
                    if m:
                        from urllib.parse import unquote
                        source_short = unquote(m.group(1))
                    else:
                        source_short = 'plugin'
                elif '://' in link:
                    source_short = link.split('://', 1)[-1][:60]
                else:
                    source_short = link[:60]
                display_title += f'  [COLOR grey][{source_short}][/COLOR]'
            if link.lower().startswith('http') and link.lower().endswith('.json'):
                route = ('dir', link)
            elif link.lower().startswith('plugin://'):
                route = ('plugin', link)
            elif link.lower().startswith('jetproxy://') or (link.lower().startswith('http') and '|' not in link):
                jet_link = {"address": link, "name": title}
                play_item = {"title": title, "sportjetextractors": [jet_link]}
                encoded = base64.urlsafe_b64encode(json.dumps(play_item).encode()).decode()
                plugin_url = f'plugin://{ADDON_ID}/play_video/{encoded}'
                route = ('plugin', plugin_url)
            elif link.lower().startswith('http'):
                route = ('play_http', link)
            else:
                route = ('plugin', link)
            items.append({
                'title': display_title,
                'thumbnail': thumbnail,
                'fanart': '',
                'summary': title,
                'route': route,
                'raw': r,
            })
        if not items:
            return
        self.nav_stack.append({
            'items': self.items_data,
            'title': self.current_title,
            'url': self.current_url,
            'selected_idx': self.getControl(100).getSelectedPosition(),
        })
        self.items_data = items
        self.current_title = 'Recently Played'
        self.current_url = ''
        self.populate_list()
        self.update_preview(0)
        log(f'_open_recently_played: showing {len(items)} items')

    def onAction(self, action):
        action_id = action.getId()

        if action_id in (101, 117):
            if self._focused_game_list:
                return
            lst = self.getControl(100)
            idx = lst.getSelectedPosition()
            if idx < 0 or idx >= len(self.items_data):
                return
            self._show_context_menu()
            return

        if action_id == 92:
            if self._focused_game_list:
                self._focused_game_list = False
                self._last_game_idx = -1
                self.setFocus(self.getControl(100))
                return
            if self._focused_movie_list:
                self._focused_movie_list = False
                self.setFocus(self.getControl(100))
                return
            if self._focused_channel_grid:
                self._focused_channel_grid = False
                self._last_channel_idx = -1
                self.setFocus(self.getControl(100))
                return
            if self.nav_stack:
                prev = self.nav_stack.pop()
                if not self.nav_stack:
                    self.items_data = list(self._root_items)
                    self._save_state(0)
                else:
                    self.items_data = prev['items']
                self.current_title = prev['title']
                self.current_url = prev['url']
                self.populate_list()
                prev_idx = prev.get('selected_idx', 0)
                lst = self.getControl(100)
                if prev_idx >= 0 and prev_idx < lst.size():
                    lst.selectItem(prev_idx)
                self.update_preview(prev_idx)
            else:
                self._closing = True
                self._clear_state_file()
                if self._poll_timer:
                    self._poll_timer.cancel()
                    self._poll_timer = None
                threading.Thread(target=flush_session, daemon=True).start()
                self.close()

        elif action_id == 2:
            if self._focused_game_list or self._focused_channel_grid:
                return
            focused_id = self.getFocusId()
            if focused_id == 100:
                if self._live_games and self._is_live_item():
                    self._focused_game_list = True
                    self.setFocus(self.getControl(510))
                    return
                if self._tmdb_movies and self._is_tmdb_movie_item():
                    self.setFocus(self.getControl(520))
                    return
                if self._tvnet_channels and self._is_tvnet_item():
                    self._focused_channel_grid = True
                    if self._tvnet_settings_mode:
                        self.setFocus(self.getControl(531))
                    else:
                        self.setFocus(self.getControl(530))
                    return

        elif action_id == 1:
            if self._focused_game_list:
                self._focused_game_list = False
                self._last_game_idx = -1
                self.setFocus(self.getControl(100))
                return
            if self._focused_channel_grid:
                focused_id = self.getFocusId()
                if focused_id == 531:
                    grid = self.getControl(531)
                    g_idx = grid.getSelectedPosition()
                    if g_idx <= 0:
                        self._focused_channel_grid = False
                        self._last_channel_idx = -1
                        self.setFocus(self.getControl(100))
                else:
                    ch_grid = self.getControl(530)
                    c_idx = ch_grid.getSelectedPosition()
                    if c_idx <= 0:
                        self._focused_channel_grid = False
                        self._last_channel_idx = -1
                        self.setFocus(self.getControl(100))
                return

        elif action_id in (3, 4):
            if self._focused_game_list or self._focused_channel_grid:
                return
            lst = self.getControl(100)
            idx = lst.getSelectedPosition()
            self.update_preview(idx)
