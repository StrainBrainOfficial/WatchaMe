import json
import os
import time
import xbmcaddon
import xbmc
from resources.lib.tool import log as _tool_log, debug_log

ADDON_ID = "plugin.video.madtitansports"
DEFAULT_CACHE_TTL = 300  # 5 minutes in seconds


def log(msg, level=xbmc.LOGINFO):
    _tool_log(msg, prefix='MadTitanESPN', level=level)

SPORT_MAP = {
    'NFL': 'sports/football/nfl',
    'MLB': 'sports/baseball/mlb',
    'NCAABASE': 'sports/baseball/college-baseball',
    'NBA': 'sports/basketball/nba',
    'NCAAB': 'sports/basketball/mens-college-basketball',
    'WNBA': 'sports/basketball/wnba',
    'NHL': 'sports/hockey/nhl',
    'MLS': 'sports/soccer/usa.1',
    'CFL': 'sports/football/cfl',
    'La Liga': 'sports/soccer/esp.1',
    'Bundesliga': 'sports/soccer/ger.1',
    'Serie A': 'sports/soccer/ita.1',
    'Ligue 1': 'sports/soccer/fra.1',
    'World' : 'sports/soccer/fifa.world',
    'Champions League': 'sports/soccer/uefa.champions',
}

ALL_SPORTS = list(SPORT_MAP.keys())

ESPN_BASE = "https://site.api.espn.com/apis/site/v2"


def _get_cache_path():
    addon = xbmcaddon.Addon(id=ADDON_ID)
    profile_dir = addon.getAddonInfo('profile')
    try:
        from xbmcvfs import translatePath
        profile_dir = translatePath(profile_dir)
    except ImportError:
        pass
    if not os.path.exists(profile_dir):
        os.makedirs(profile_dir, exist_ok=True)
    return os.path.join(profile_dir, 'scores_cache.json')


def _get_cache_ttl():
    try:
        addon = xbmcaddon.Addon(id=ADDON_ID)
        ttl_min = int(addon.getSetting('ls_cache_ttl') or '5')
        return ttl_min * 60
    except Exception as e:
        debug_log(f'_get_cache_ttl error: {e}')
        return DEFAULT_CACHE_TTL


def _read_cache():
    path = _get_cache_path()
    try:
        if os.path.exists(path):
            with open(path, 'r') as f:
                data = json.load(f)
            age = time.time() - data.get('timestamp', 0)
            return data.get('games', []), age
    except Exception as e:
        debug_log(f'_read_cache error: {e}')
    return [], None


def _write_cache(games):
    path = _get_cache_path()
    try:
        with open(path, 'w') as f:
            json.dump({'games': games, 'timestamp': time.time()}, f)
    except Exception as e:
        debug_log(f'_write_cache error: {e}')


def clear_cache():
    path = _get_cache_path()
    try:
        if os.path.exists(path):
            os.remove(path)
    except Exception as e:
        debug_log(f'clear_cache error: {e}')


def _parse_game(event, sport_name):
    try:
        competition = event.get('competitions', [{}])[0]
        competitors = competition.get('competitors', [])
        if len(competitors) < 2:
            return None

        t1 = competitors[0].get('team', {})
        t2 = competitors[1].get('team', {})

        team1_name = t1.get('displayName', '')
        team2_name = t2.get('displayName', '')
        if not team1_name or not team2_name:
            return None

        score1 = str(competitors[0].get('score', '0'))
        score2 = str(competitors[1].get('score', '0'))

        status_obj = competition.get('status', {})
        status_type = status_obj.get('type', {})
        full_status = status_type.get('description', 'Scheduled')

        period = competition.get('period', '')
        clock = competition.get('clock', '')

        status = full_status
        if period and full_status in ('In Progress', 'Halftime', 'Final', 'End of Period'):
            if clock:
                status = f"Q{period} {clock}"
            else:
                status = f"Q{period}"

        venue = competition.get('venue', {})
        venue_name = venue.get('fullName', '') if isinstance(venue, dict) else ''

        return {
            'team1': team1_name,
            'team2': team2_name,
            'team1_logo': t1.get('logo', ''),
            'team2_logo': t2.get('logo', ''),
            'score': f"{score1} - {score2}",
            'status': status,
            'full_status': full_status,
            'sport': sport_name,
            'venue': venue_name,
            'period': period,
            'clock': clock,
            'event_id': event.get('id', ''),
        }
    except Exception:
        return None


def fetch_scoreboard(sport_path, sport_name):
    import requests
    games = []
    try:
        url = f"{ESPN_BASE}/{sport_path}/scoreboard"
        log(f'Fetching {sport_name} from {url}')
        resp = requests.get(url, timeout=10)
        log(f'{sport_name} response status: {resp.status_code}')
        resp.raise_for_status()
        data = resp.json()
        events = data.get('events', [])
        log(f'{sport_name} returned {len(events)} events')
        for event in events:
            game = _parse_game(event, sport_name)
            if game:
                games.append(game)
        log(f'{sport_name} parsed {len(games)} games')
    except Exception as e:
        log(f'{sport_name} error: {e}', level=xbmc.LOGERROR)
    return games


def fetch_all_scores(sports_list=None, force_refresh=False):
    if sports_list is None:
        sports_list = ALL_SPORTS

    log(f'fetch_all_scores called with sports: {sports_list}, force_refresh={force_refresh}')

    if not force_refresh:
        try:
            cached, age = _read_cache()
            if cached and age is not None and age < _get_cache_ttl():
                log(f'Cache hit, age={age:.0f}s, ttl={_get_cache_ttl()}s')
                cached_sports = set(g.get('sport') for g in cached)
                requested = set(sports_list)
                if requested.issubset(cached_sports):
                    result = [g for g in cached if g.get('sport') in requested]
                    log(f'Returning {len(result)} cached games')
                    return result
                else:
                    log(f'Cache missing sports: {requested - cached_sports}')
            else:
                log(f'No cache or cache expired (age={age})')
        except Exception as e:
            log(f'Cache read error: {e}', level=xbmc.LOGWARNING)

    from concurrent.futures import ThreadPoolExecutor, as_completed

    def _fetch_sport(sport):
        path = SPORT_MAP.get(sport)
        if path:
            return fetch_scoreboard(path, sport)
        else:
            log(f'No path mapping for sport: {sport}', level=xbmc.LOGWARNING)
            return []

    all_games = []
    with ThreadPoolExecutor(max_workers=6) as executor:
        futures = {executor.submit(_fetch_sport, sport): sport for sport in sports_list}
        for future in as_completed(futures):
            try:
                all_games.extend(future.result())
            except Exception as e:
                log(f'Sport fetch error: {e}', level=xbmc.LOGERROR)

    log(f'Total games fetched: {len(all_games)}')

    if all_games:
        try:
            _write_cache(all_games)
            log('Cache written successfully')
        except Exception as e:
            log(f'Cache write error: {e}', level=xbmc.LOGWARNING)

    return all_games
