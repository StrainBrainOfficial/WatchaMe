import xbmcgui
import xbmc
import json
import threading
from resources.lib.tool import log
from resources.lib.gui_helpers import get_route_for_item, strip_color_tags


class TraktMixin:

    def _trakt_open(self, url):
        log(f'_trakt_open called with url={url}')
        progress = xbmcgui.DialogProgress()
        progress.create("Loading...", f"Fetching: {url}")
        try:
            from resources.lib.plugins.trakt import Trakt
            trakt = Trakt()
            jen_json = trakt.get_list(url)
            if not jen_json:
                progress.close()
                xbmcgui.Dialog().ok("Trakt", "No results found.")
                return
            jen_data = json.loads(jen_json)
            items = jen_data.get("items", [])
        except Exception as e:
            progress.close()
            log(f'Trakt error: {e}', level=xbmc.LOGERROR)
            import traceback
            log(traceback.format_exc(), level=xbmc.LOGERROR)
            xbmcgui.Dialog().ok("Trakt Error", f"Failed to load: {str(e)}")
            return

        progress.close()

        if not items:
            xbmcgui.Dialog().ok("Trakt", "No results found.")
            return

        display_items = []
        for item in items:
            link = item.get("link", "")
            if item.get("type") == "dir" and isinstance(link, str) and link.startswith("trakt/"):
                route = ('trakt', item["link"])
            elif item.get("type") == "dir" and isinstance(link, str) and link.startswith("tmdb/"):
                route = ('tmdb', item["link"])
            else:
                route = get_route_for_item(item)
                if route is None:
                    route = ('dir', link) if link else None
            if route is None:
                continue
            item_title = strip_color_tags(item.get("title", item.get("name", "")))
            thumbnail = item.get("thumbnail", "")
            fanart = item.get("fanart", "")
            summary = strip_color_tags(item.get("summary", ""))
            display_items.append({
                'title': item_title,
                'thumbnail': thumbnail,
                'fanart': fanart,
                'summary': summary,
                'route': route,
                'raw': item,
            })

        if not display_items:
            xbmcgui.Dialog().ok("Trakt", "No results found.")
            return

        self.nav_stack.append({
            'items': self.items_data,
            'title': self.current_title,
            'url': self.current_url,
            'selected_idx': self.getControl(100).getSelectedPosition(),
        })

        self.items_data = display_items
        title = url.replace("trakt/", "Trakt: ").replace("/", " > ")
        self.current_title = title
        self.current_url = ''
        self.populate_list()
        self.update_preview(0)

    def _load_trakt_items(self, url):
        log(f'_load_trakt_items called with url={url}')
        if self._tmdb_movies_loaded or self._tmdb_loading:
            return
        self._tmdb_loading = True
        gen = self._preview_generation
        threading.Thread(target=self._load_trakt_items_thread, args=(url, gen), daemon=True).start()

    def _load_trakt_items_thread(self, url, gen):
        try:
            from resources.lib.plugins.trakt import Trakt
            from resources.lib.plugins.trakt import Trakt_API
            trakt = Trakt()
            jen_json = trakt.get_list(url)
            if not jen_json:
                self._tmdb_loading = False
                return
            jen_data = json.loads(jen_json)
            raw_items = jen_data.get("items", [])
        except Exception as e:
            log(f'Trakt preview fetch failed: {e}', level=xbmc.LOGERROR)
            self._tmdb_loading = False
            return

        if gen != self._preview_generation:
            log('_load_trakt_items: stale generation after fetch, aborting')
            self._tmdb_loading = False
            return

        movies = []
        for item in raw_items:
            if item.get("title") == "Next Page":
                continue
            if item.get("thumbnail"):
                if not item.get('media_type'):
                    content = item.get('content', '')
                    if content in ('tv', 'tvshow'):
                        item['media_type'] = 'tv'
                    elif content == 'movie':
                        item['media_type'] = 'movie'
                    elif item.get('first_air_date') and not item.get('release_date'):
                        item['media_type'] = 'tv'
                    else:
                        item['media_type'] = 'movie'
                movies.append(item)

        if not movies:
            self._tmdb_loading = False
            return

        self._tmdb_movies = movies
        if self._tmdb_movie_idx >= len(movies):
            self._tmdb_movie_idx = 0
        self._tmdb_movies_loaded = True
        self._tmdb_loading = False

        self._populate_movie_list()
        self._start_movie_rotation()
