import xbmcgui
import xbmc
import xbmcaddon
import threading
import time

ADDON_ID = "plugin.video.madtitansports"
ADDON_PATH = xbmcaddon.Addon(id=ADDON_ID).getAddonInfo('path')

COLOR_BAR_ANIMATION = [
    "FF0066FF",  # blue
    "FF00AAFF",  # light blue
    "FF00CCFF",  # cyan
    "FF00FFAA",  # teal
    "FF00FF66",  # green
    "FF88FF00",  # lime
    "FFCCFF00",  # yellow
    "FFFFAA00",  # orange
    "FFFF3300",  # red
    "FFFF0066",  # pink
    "FFCC00FF",  # magenta
    "FF9933FF",  # purple
    "FF6666FF",  # lavender
]

BAR_ANIMATION_INTERVAL_MS = 300
AUTO_CLOSE_POLL_MS = 500
AUTO_CLOSE_TIMEOUT_S = 25
PLAYBACK_CONFIRM_S = 4

_active_overlay = None
_overlay_lock = threading.Lock()

_busy_dismiss_timer = None
_busy_dismiss_stop = threading.Event()


def _dismiss_busy():
    try:
        xbmc.executebuiltin('Dialog.Close(busydialog)')
    except Exception:
        pass


def _busy_dismiss_tick():
    if _busy_dismiss_stop.is_set():
        return
    _dismiss_busy()
    _busy_dismiss_timer_inner = threading.Timer(0.5, _busy_dismiss_tick)
    _busy_dismiss_timer_inner.daemon = True
    _busy_dismiss_timer_inner.start()


def start_busy_dismiss():
    global _busy_dismiss_timer
    _busy_dismiss_stop.clear()
    _dismiss_busy()
    _busy_dismiss_tick()


def stop_busy_dismiss():
    _busy_dismiss_stop.set()
    global _busy_dismiss_timer
    _busy_dismiss_timer = None


class LoadingOverlay(xbmcgui.WindowXMLDialog):
    def __init__(self, xml_file, addon_path):
        xbmcgui.WindowXMLDialog.__init__(self, xml_file, addon_path, "Default", "720p")
        self._bar_index = 0
        self._animation_timer = None
        self._auto_close_timer = None
        self._closing = False
        self._start_time = 0
        self._playback_detected_time = 0

    def onInit(self):
        try:
            self._start_time = time.time()
            self._start_animation()
            self._start_auto_close()
        except Exception as e:
            xbmc.log(f"[MadTitan] LoadingOverlay onInit error: {e}", level=xbmc.LOGERROR)

    def onAction(self, action):
        action_id = action.getId()
        if action_id in (xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK, 92):
            xbmc.Player().stop()
            self._close_overlay()

    def onClick(self, control_id):
        pass

    def onFocus(self, control_id):
        pass

    def _start_animation(self):
        self._bar_index = 0
        self._animation_tick()

    def _animation_tick(self):
        if self._closing:
            return
        try:
            color = COLOR_BAR_ANIMATION[self._bar_index % len(COLOR_BAR_ANIMATION)]
            self.getControl(5100).setColorDiffuse(color)
            self._bar_index += 1
        except Exception:
            pass
        self._animation_timer = threading.Timer(BAR_ANIMATION_INTERVAL_MS / 1000.0, self._animation_tick)
        self._animation_timer.daemon = True
        self._animation_timer.start()

    def _start_auto_close(self):
        self._auto_close_tick()

    def _auto_close_tick(self):
        if self._closing:
            return
        try:
            elapsed = time.time() - self._start_time
            if elapsed > AUTO_CLOSE_TIMEOUT_S:
                xbmc.log("[MadTitan] LoadingOverlay: timeout, closing overlay", level=xbmc.LOGDEBUG)
                self._close_overlay()
                return
            player = xbmc.Player()
            if player.isPlaying():
                if self._playback_detected_time == 0:
                    self._playback_detected_time = time.time()
                    xbmc.log("[MadTitan] LoadingOverlay: isPlaying detected, waiting for confirmed playback", level=xbmc.LOGDEBUG)
                since_detect = time.time() - self._playback_detected_time
                if since_detect >= PLAYBACK_CONFIRM_S:
                    try:
                        current_time = player.getTime()
                    except Exception:
                        current_time = -1
                    if current_time > 0:
                        xbmc.log(f"[MadTitan] LoadingOverlay: playback confirmed at {current_time:.1f}s, closing overlay", level=xbmc.LOGDEBUG)
                        self._close_overlay()
                        return
                    elif since_detect >= PLAYBACK_CONFIRM_S + 4:
                        xbmc.log("[MadTitan] LoadingOverlay: playback timed out after confirm window, closing", level=xbmc.LOGDEBUG)
                        self._close_overlay()
                        return
        except Exception:
            pass
        self._auto_close_timer = threading.Timer(AUTO_CLOSE_POLL_MS / 1000.0, self._auto_close_tick)
        self._auto_close_timer.daemon = True
        self._auto_close_timer.start()

    def _stop_timers(self):
        if self._animation_timer:
            self._animation_timer.cancel()
            self._animation_timer = None
        if self._auto_close_timer:
            self._auto_close_timer.cancel()
            self._auto_close_timer = None

    def _close_overlay(self):
        if self._closing:
            return
        self._closing = True
        self._stop_timers()
        try:
            self.close()
        except Exception:
            pass
        global _active_overlay
        with _overlay_lock:
            _active_overlay = None


def show():
    global _active_overlay
    with _overlay_lock:
        if _active_overlay is not None:
            return
        try:
            start_busy_dismiss()
            _active_overlay = LoadingOverlay("loading_overlay.xml", ADDON_PATH)
            _active_overlay.show()
        except Exception as e:
            xbmc.log(f"[MadTitan] LoadingOverlay show error: {e}", level=xbmc.LOGERROR)
            _active_overlay = None


def close():
    global _active_overlay
    with _overlay_lock:
        if _active_overlay is not None:
            _active_overlay._close_overlay()
    stop_busy_dismiss()
