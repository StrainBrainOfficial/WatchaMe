import xbmcgui
import xbmc
import xbmcaddon
import json
import base64
import threading
from resources.lib.tool import log
from resources.lib.gui_helpers import get_route_for_item, strip_color_tags
from resources.lib import loading_overlay

ADDON_ID = "plugin.video.madtitansports"


class TMDBMixin:

    def _is_tmdb_movie_item(self):
        lst = self.getControl(100)
        idx = lst.getSelectedPosition()
        if idx < 0 or idx >= len(self.items_data):
            return False
        item = self.items_data[idx]
        raw = item.get('raw', {})
        link = raw.get('link', '')
        title = item.get('title', '')
        is_tmdb_link = isinstance(link, str) and link.startswith('tmdb/') and (
            '/movie/' in link or link.startswith('tmdb/collection/') or link.startswith('tmdb/person/') or '/tv/' in link
        )
        is_movie_title = 'movies section' in strip_color_tags(title).lower() or 'tv shows section' in strip_color_tags(title).lower()
        is_trakt = isinstance(link, str) and link.startswith('trakt/')
        return is_tmdb_link or is_movie_title or is_trakt

    def _load_tmdb_movies(self):
        if self._tmdb_movies_loaded or self._tmdb_loading:
            return
        self._tmdb_loading = True
        log('_load_tmdb_movies called')

        lst = self.getControl(100)
        idx = lst.getSelectedPosition()
        if idx < 0 or idx >= len(self.items_data):
            self._tmdb_loading = False
            return

        item = self.items_data[idx]
        raw = item.get('raw', {})
        link = raw.get('link', '')
        title = item.get('title', '')

        title_clean = strip_color_tags(title).lower()
        if isinstance(link, str) and link.startswith('tmdb/person/'):
            list_id = link.split('/')[2].split('-')[0]
            api_url = f'person/{list_id}/combined_credits'
        elif isinstance(link, str) and link.startswith('tmdb/') and (
            '/movie/' in link or link.startswith('tmdb/collection/') or
            link.startswith('tmdb/tv/') or '/tv/' in link
        ):
            api_url = link.replace('tmdb/', '')
            parts = api_url.split('/')
            if len(parts) == 3 and parts[0] in ('genre', 'company', 'year'):
                kind, media_type, tmdb_id = parts
                api_url = f'discover/{media_type}/{kind}/{tmdb_id}'
        elif 'movies section' in title_clean:
            api_url = 'movie/popular'
        elif 'tv shows section' in title_clean:
            api_url = 'tv/popular'
        else:
            self._tmdb_loading = False
            return

        gen = self._preview_generation
        log(f'TMDB api_url resolved to {api_url}')
        threading.Thread(target=self._load_tmdb_movies_thread, args=(api_url, gen), daemon=True).start()

    def _load_tmdb_movies_thread(self, api_url, gen):
        try:
            from resources.lib.plugins.tmdb_plugin import TMDB_API
            api = TMDB_API()
            movies = api.get(api_url)
        except Exception as e:
            log(f'TMDB movies fetch failed: {e}', level=xbmc.LOGERROR)
            self._tmdb_loading = False
            return

        if not movies:
            self._tmdb_loading = False
            return

        if gen != self._preview_generation:
            log('_load_tmdb_movies: stale generation after fetch, aborting')
            self._tmdb_loading = False
            return

        is_tv = api_url.startswith('tv/') or api_url.startswith('discover/tv')
        for m in movies:
            if not m.get('media_type'):
                if is_tv:
                    m['media_type'] = 'tv'
                elif m.get('first_air_date') and not m.get('release_date'):
                    m['media_type'] = 'tv'
                else:
                    m['media_type'] = 'movie'

        self._tmdb_movies = movies
        if self._tmdb_movie_idx >= len(movies):
            self._tmdb_movie_idx = 0
        self._tmdb_movies_loaded = True
        self._tmdb_loading = False

        self._populate_movie_list()
        self._start_movie_rotation()

    def _populate_movie_list(self):
        try:
            movie_list = self.getControl(520)
            movie_list.reset()
            for m in self._tmdb_movies[:20]:
                title = m.get('title', m.get('name', ''))
                poster_path = m.get('poster_path', '')
                if poster_path and not poster_path.startswith('http'):
                    poster = f'https://image.tmdb.org/t/p/w200{poster_path}'
                elif poster_path:
                    poster = poster_path
                else:
                    poster = m.get('thumbnail', '')
                li = xbmcgui.ListItem(label=title)
                if poster:
                    li.setArt({'icon': poster, 'thumb': poster})
                movie_list.addItem(li)
            log(f'Added {movie_list.size()} movies to movie list')
        except Exception as e:
            log(f'Failed to populate movie list: {e}', level=xbmc.LOGERROR)

    def _update_featured_movie(self):
        if not self._tmdb_movies:
            return
        idx = self._tmdb_movie_idx % len(self._tmdb_movies)
        m = self._tmdb_movies[idx]
        poster_path = m.get('poster_path', '')
        if poster_path and not poster_path.startswith('http'):
            poster = f'https://image.tmdb.org/t/p/w500{poster_path}'
        elif poster_path:
            poster = poster_path
        else:
            poster = m.get('thumbnail', '')
        title = m.get('title', m.get('name', ''))
        year = m.get('release_date', m.get('year', ''))
        if isinstance(year, int):
            year = str(year)
        year = year.split('-')[0] if year else ''
        rating = m.get('vote_average', m.get('rating', 0))
        overview = m.get('overview', m.get('summary', ''))
        if len(overview) > 300:
            overview = overview[:300] + '...'

        log(f'Top movie #{idx}: {title}')
        self.setProperty('tmdb_poster', poster)
        self.setProperty('tmdb_title', title)
        self.setProperty('tmdb_year', year)
        self.setProperty('tmdb_rating', f'{rating:.1f}/10' if rating else 'N/A')
        self.setProperty('tmdb_overview', overview)
        self.setProperty('tmdb_top_label', f'{idx + 1}/{len(self._tmdb_movies)}')

    def _start_movie_rotation(self):
        self._movie_rotating = False
        xbmc.sleep(100)
        self._movie_rotating = True
        self._movie_rotation_count = 0
        threading.Thread(target=self._movie_rotation_loop, daemon=True).start()

    def _movie_rotation_loop(self):
        while self._movie_rotating and not self._closing:
            if not self._tmdb_movies:
                return
            if not self._is_tmdb_movie_item():
                self._movie_rotating = False
                return
            if self._focused_movie_list:
                for _ in range(50):
                    if not self._movie_rotating or self._closing:
                        return
                    xbmc.sleep(100)
                continue
            self._update_featured_movie()
            self._movie_rotation_count += 1
            if self._movie_rotation_count % max(len(self._tmdb_movies), 1) == 0:
                self._tmdb_movies_loaded = False
                self._movie_rotating = False
                if self._is_tmdb_movie_item():
                    self._load_tmdb_movies()
                return
            self._tmdb_movie_idx = (self._tmdb_movie_idx + 1) % len(self._tmdb_movies)
            for _ in range(50):
                if not self._movie_rotating or self._closing:
                    return
                xbmc.sleep(100)

    def _tmdb_open(self, url):
        log(f'_tmdb_open called with url={url}')
        progress = xbmcgui.DialogProgress()
        progress.create("Loading...", f"Fetching: {url}")
        try:
            from resources.lib.plugins.tmdb_plugin import TMDB_API
            api = TMDB_API()
            splitted = url.split("/")
            kind = splitted[1] if len(splitted) > 1 else ""

            api_url = url.replace("tmdb/", "")
            if kind == "person":
                list_id = splitted[2].split("-")[0] if len(splitted) > 2 else ""
                api_url = f"person/{list_id}/combined_credits"
            elif kind == "search":
                if len(splitted) == 4:
                    pass
                else:
                    query = xbmcgui.Dialog().input("Search TMDB")
                    if not query:
                        progress.close()
                        return
                    api_url = f"{url.replace('tmdb/', '')}?query={query}"
            elif len(splitted) > 3 and splitted[1] in ('genre', 'company', 'year'):
                kind2 = splitted[1]
                media_type = splitted[2]
                tmdb_id = splitted[3]
                param_map = {'genre': 'with_genres', 'company': 'with_companies', 'year': 'year'}
                api_url = f'discover/{media_type}/{kind2}/{tmdb_id}'

            progress.update(20, "Fetching from TMDB API...")
            tmdb_response = api.get(api_url)

            show_id = None
            if len(splitted) > 1 and splitted[1] == 'tv':
                if len(splitted) > 2 and str.isdigit(splitted[2]):
                    show_id = splitted[2]

            progress.update(60, "Processing results...")
            jen_list = api.handle_items(tmdb_response, show_id=show_id)
            items = jen_list.get("items", []) if isinstance(jen_list, dict) else jen_list
        except Exception as e:
            progress.close()
            log(f'TMDB error: {e}', level=xbmc.LOGERROR)
            import traceback
            log(traceback.format_exc(), level=xbmc.LOGERROR)
            xbmcgui.Dialog().ok("TMDB Error", f"Failed to load: {str(e)}")
            return

        progress.close()

        if not items:
            xbmcgui.Dialog().ok("TMDB", "No results found.")
            return

        display_items = []
        for item in items:
            if item.get("type") == "dir" and item.get("link", "").startswith("tmdb/"):
                route = ('tmdb', item["link"])
            else:
                route = get_route_for_item(item)
                if route is None:
                    route = ('tmdb_item', item)
            item_title = strip_color_tags(item.get("title", item.get("name", "")))
            thumbnail = item.get("thumbnail", "")
            fanart = item.get("fanart", "")
            summary = strip_color_tags(item.get("summary", ""))
            display_items.append({
                'title': item_title,
                'thumbnail': thumbnail,
                'fanart': fanart,
                'summary': summary,
                'route': route,
                'raw': item,
            })

        if not display_items:
            xbmcgui.Dialog().ok("TMDB", "No results found.")
            return

        self.nav_stack.append({
            'items': self.items_data,
            'title': self.current_title,
            'url': self.current_url,
            'selected_idx': self.getControl(100).getSelectedPosition(),
        })

        self.items_data = display_items
        title = url.replace("tmdb/", "TMDB: ").replace("/", " > ")
        self.current_title = title
        self.current_url = ''
        self.populate_list()
        self.update_preview(0)

    def _tmdb_item_play(self, raw_item):
        log(f'_tmdb_item_play called')
        try:
            from resources.lib.plugins.tmdb_plugin import TMDB_API
            api = TMDB_API()
            tmdb_id = raw_item.get("tmdb_id")
            content = raw_item.get("content", "movie")
            imdb_id = raw_item.get("imdb_id", "")
            year = raw_item.get("year", "")

            if not tmdb_id:
                xbmcgui.Dialog().ok("TMDB", "No TMDB ID found for this item.")
                return

            if content in ('tv', 'tvshow'):
                self._tmdb_open(f"tmdb/tv/{tmdb_id}")
                return

            if not imdb_id:
                progress = xbmcgui.DialogProgress()
                progress.create("Loading...", "Fetching movie details...")
                movie = api.get(f"movie/{tmdb_id}", full_meta=True)
                progress.close()
                if movie:
                    imdb_id = movie.get("imdb_id", "")
                    if not year:
                        year = movie.get("release_date", "").split("-")[0] if movie.get("release_date") else ""
                else:
                    log(f'Could not fetch movie details for tmdb_id={tmdb_id}, using raw data')

            if isinstance(year, int):
                year = str(year)

            play_item = {
                "title": raw_item.get("title", ""),
                "content": content,
                "tmdb_id": tmdb_id,
                "imdb_id": imdb_id,
                "year": year,
                "link": "search",
            }
            encoded = base64.urlsafe_b64encode(
                bytes(json.dumps(play_item), 'utf-8')
            ).decode('utf-8')
            self._save_state(0)
            loading_overlay.show()
            xbmc.executebuiltin(
                f'RunPlugin(plugin://{ADDON_ID}/play_video/{encoded})'
            )
        except Exception as e:
            log(f'TMDB play error: {e}', level=xbmc.LOGERROR)
            xbmcgui.Dialog().ok("TMDB Error", f"Failed to play: {str(e)}")
