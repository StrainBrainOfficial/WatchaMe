from ..plugin import Plugin
import xbmc, xbmcgui, xbmcaddon
import json
import requests
import resolveurl
import threading
import time
import re

try:
    from resources.lib.plugins.m3u_parser import m3u
except ImportError:
    m3u = None
    xbmc.log("M3U parser import failed—falling back to direct playback", level=xbmc.LOGWARNING)

addon_id = xbmcaddon.Addon().getAddonInfo('id')
default_icon = xbmcaddon.Addon(addon_id).getAddonInfo('icon')

BROWSER_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
_active_keepalive = None


def _start_keepalive(url, title):
    global _active_keepalive
    if _active_keepalive and _active_keepalive.is_alive():
        _active_keepalive.stop()
    _active_keepalive = _StreamKeepAlive(url, title)
    _active_keepalive.start()


def _extract_stream_id(url):
    m = re.search(r'[&?]stream=(\d+)', url)
    return m.group(1) if m else None


class _StreamKeepAlive(threading.Thread):
    def __init__(self, url, title):
        super().__init__(daemon=True)
        self.original_url = url
        self.current_url = url
        self.url = url
        self.title = title
        self.stream_id = _extract_stream_id(url)
        self._stop_event = threading.Event()
        self._player = xbmc.Player()
        self._check_interval = 3
        self._max_restarts = 50
        self._log_tag = "StreamKeepAlive"
        self._grace_period = 10
        self._consecutive_same = 0
        self._stall_consecutive_needed = 5
        self._has_play_token = 'play_token=' in url.lower()
        self._refresh_interval = 20
        self._last_refresh = time.time()

    def stop(self):
        self._stop_event.set()

    def _log(self, msg):
        xbmc.log(f"[{self._log_tag}] {msg}", xbmc.LOGINFO)

    def run(self):
        self._log(f"Started monitor for '{self.title}' (stream={self.stream_id})")
        restarts = 0

        while not self._stop_event.is_set() and restarts < self._max_restarts:
            self._stop_event.wait(self._check_interval)
            if self._stop_event.is_set():
                break

            if not self._player.isPlaying():
                self._log(f"Playback stopped, stopping monitor")
                break

            now = time.time()
            if self._has_play_token and (now - self._last_refresh) >= self._refresh_interval:
                self._log(f"Refreshing play_token proactively")
                try:
                    resp = requests.get(self.current_url, headers={"User-Agent": BROWSER_UA}, timeout=10, allow_redirects=False)
                    location = resp.headers.get("Location", "")
                    if location:
                        self.current_url = location
                        self.url = location
                        self._log(f"Got new token, preparing seamless switch")
                        liz = xbmcgui.ListItem(self.title)
                        liz.setProperty("IsPlayable", "true")
                        if "m3u8" in location.lower():
                            liz.setProperty("inputstream", "inputstream.adaptive")
                            liz.setProperty("inputstream.adaptive.stream_headers", f"User-Agent={BROWSER_UA}")
                        self._player.play(location, liz)
                        self._last_refresh = now
                        restarts += 1
                    else:
                        self._log(f"No redirect in response")
                except Exception as e:
                    self._log(f"Token refresh failed: {e}")

        self._log(f"Monitor ended for '{self.title}' (restarts={restarts})")

    def _restart_playback(self):
        try:
            if self._stop_event.is_set():
                return False

            url = self.current_url
            if self._has_play_token:
                try:
                    resp = requests.get(url, headers={"User-Agent": BROWSER_UA}, timeout=10, allow_redirects=False)
                    location = resp.headers.get("Location", "")
                    if location:
                        url = location
                        self.current_url = location
                        self.url = location
                        self._log(f"Refreshed play_token for restart")
                except Exception as e:
                    self._log(f"Token refresh failed: {e}, using current URL")

            self._player.stop()
            time.sleep(1)

            headers = f"User-Agent={BROWSER_UA}"
            liz = xbmcgui.ListItem(self.title)
            if "m3u8" in url.lower():
                liz.setProperty("inputstream", "inputstream.adaptive")
                liz.setProperty("inputstream.adaptive.stream_headers", headers)

            self._log(f"Restarting playback for '{self.title}'")
            self._player.play(url, liz)
            return True
        except Exception as e:
            self._log(f"Restart failed for '{self.title}': {e}")
            return False

class default_play_video(Plugin):
    name = "default video playback"
    priority = 0
    
    def play_video(self, item):
        item = json.loads(item)
        link = item.get("link", "")
        if link == "":
            return False
        title = item["title"]
        thumbnail = item.get("thumbnail", default_icon)
        summary = item.get("summary", "")
        
        # NEW: Handle M3U playlists explicitly for seamless queuing
        # Inside play_video, replace the M3U try block:
        if link.endswith(('.m3u', '.m3u8')) and m3u is not None:
            try:
                parser = m3u()
                response = parser.get_list(link)
                
                if not isinstance(response, str) or not response.strip():
                    raise ValueError("Invalid or empty M3U response")
                
                xbmc.log(f"{self.name}: Fetched M3U content ({len(response)} chars) for '{title}'", level=xbmc.LOGINFO)
                
                chunks = parser.EpgRegex(response)  # e.g., 4 chunks
                
                if not chunks:
                    raise ValueError("No valid chunks parsed from M3U")
                
                # Detect loopable structure (short list of sequential chunks)
                num_base_chunks = len(chunks)
                if num_base_chunks > 0 and num_base_chunks < 10:  # Assume <10 means "loopable cycle"
                    xbmc.log(f"{self.name}: Detected {num_base_chunks} base chunks for looping", level=xbmc.LOGINFO)
                    
                    # Generate repeated queue: e.g., 20 cycles for ~80 total (adjust REPEAT_CYCLES as needed)
                    REPEAT_CYCLES = 20  # Tune: 25 for ~100 chunks
                    total_chunks = []
                    for cycle in range(REPEAT_CYCLES):
                        for chunk in chunks:
                            # Clone with cycle info for title (optional)
                            looped_chunk = chunk.copy()
                            looped_chunk['tvg_name'] = f"{chunk.get('tvg_name', 'Chunk')} (Loop {cycle+1})"
                            total_chunks.append(looped_chunk)
                    
                    chunks = total_chunks  # Use expanded list
                    xbmc.log(f"{self.name}: Expanded to {len(chunks)} looped chunks for '{title}'", level=xbmc.LOGINFO)
                
                # Create ListItem for the overall playlist (unchanged)
                liz = xbmcgui.ListItem(title)
                video_info = liz.getVideoInfoTag()
                video_info.setTitle(title)
                video_info.setPlot(summary)
                liz.setArt({"thumb": thumbnail, "icon": thumbnail, "poster": thumbnail})
                
                # Queue all chunks into video playlist (unchanged)
                playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
                playlist.clear()
                
                for chunk in chunks:
                    stream_url = chunk.get('stream_url', '').strip()
                    if not stream_url:
                        continue
                    chunk_title = chunk.get('tvg_name', 'Unknown Chunk')
                    chunk_thumb = chunk.get('tvg_logo', thumbnail)
                    
                    chunk_liz = xbmcgui.ListItem(label=chunk_title)
                    chunk_liz.setPath(stream_url)
                    chunk_liz.setProperty('IsPlayable', 'true')
                    chunk_liz.setMimeType('video/MP2T')
                    chunk_video_info = chunk_liz.getVideoInfoTag()
                    chunk_video_info.setTitle(chunk_title)
                    chunk_liz.setArt({'thumb': chunk_thumb})
                    
                    playlist.add(stream_url, chunk_liz)
                
                # Play the queued playlist + enable infinite repeat
                xbmc.Player().play(playlist, liz)
                xbmc.executebuiltin('PlayerControl(RepeatAll)')  # NEW: Loops the full playlist endlessly
                xbmc.log(f"{self.name}: Started looped playback of {len(chunks)}-chunk playlist for '{title}'", level=xbmc.LOGINFO)
                return True
                
            except Exception as e:
                xbmc.log(f"{self.name}: M3U playback error for '{link}': {str(e)}", level=xbmc.LOGERROR)
        # Fallback to direct play...
        # Fallback...
                # Fallback to direct play if parsing fails
                link = link  # Keep original for fallback
        
        # ORIGINAL/ Fallback: Direct/single link playback (with deprecation fix)
        liz = xbmcgui.ListItem(title)
        video_info = liz.getVideoInfoTag()
        if item.get("infolabels"):
            # Handle infolabels dict (set key-value via setters)
            infolabels = item["infolabels"]
            video_info.setTitle(infolabels.get("title", title))
            video_info.setPlot(infolabels.get("plot", summary))
            # Add more setters as needed, e.g., video_info.setGenre(infolabels.get("genre", ""))
        else:
            video_info.setTitle(title)
            video_info.setPlot(summary)
        liz.setArt({"thumb": thumbnail, "icon": thumbnail, "poster": thumbnail})

        # If link looks like an internal route (e.g. "file_iptv/search/..." or
        # "tele_iptv/search/...."), run it as a plugin path instead of trying
        # to play it as media.
        if not link.startswith("plugin://"):
            internal_prefixes = ("file_iptv/", "/file_iptv/", "tele_iptv/", "/tele_iptv/")
            if link.startswith(internal_prefixes):
                plugin_path = link.lstrip("/")
                plugin_url = f"plugin://{addon_id}/{plugin_path}"
                xbmc.log(
                    f"{self.name}: Redirecting internal route to RunPlugin '{plugin_url}'",
                    level=xbmc.LOGINFO,
                )
                xbmc.executebuiltin(f'RunPlugin("{plugin_url}")')
                return True
        
        if resolveurl.HostedMediaFile(link).valid_url():
            url = resolveurl.HostedMediaFile(link).resolve()
            if "m3u8" in url.lower():
                liz.setProperty("inputstream", "inputstream.adaptive")
                liz.setProperty("inputstream.adaptive.stream_headers", f"User-Agent={BROWSER_UA}")
            xbmc.log(f"{self.name}: Resolved URL via resolveurl for '{title}'", level=xbmc.LOGINFO)
            return xbmc.Player().play(url, liz)

        if link.startswith(f"plugin://{addon_id}/") and "/play_video/" not in link and "/get_list/" not in link:
            xbmc.log(
                f"{self.name}: Redirecting own internal route to RunPlugin '{link}'",
                level=xbmc.LOGINFO,
            )
            xbmc.executebuiltin(f'RunPlugin("{link}")')
            return True

        is_hls = "m3u8" in link.lower()
        if is_hls:
            liz.setProperty("inputstream", "inputstream.adaptive")
            liz.setProperty("inputstream.adaptive.stream_headers", f"User-Agent={BROWSER_UA}")

        xbmc.log(f"{self.name}: Direct playback of '{link}' for '{title}'", level=xbmc.LOGINFO)
        xbmc.Player().play(link, liz)

        return True