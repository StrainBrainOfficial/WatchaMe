from resources.lib.plugin import Plugin, run_hook
import xbmcgui
import xbmc
from bs4 import BeautifulSoup
import urllib
import requests, re, json, time
import sys
import xbmcplugin

COUNTRY_CODES = {
    "usa": "USA", "us": "USA", "united states": "USA",
    "canada": "CAN", "can": "CAN",
    "uk": "G", "united kingdom": "G", "britain": "G", "england": "G", "great britain": "G",
    "australia": "AUS", "aus": "AUS",
    "germany": "D", "deutschland": "D",
    "france": "F",
    "japan": "J",
    "india": "IND",
    "brazil": "BR",
    "mexico": "MEX",
    "spain": "E", "espana": "E",
    "italy": "I",
    "netherlands": "H", "holland": "H",
    "ireland": "IRL",
    "new zealand": "NZL",
    "south africa": "ZA",
    "sweden": "S",
    "norway": "NOR",
    "denmark": "DK",
    "finland": "FIN",
    "poland": "PL",
    "portugal": "P",
    "russia": "RUS",
    "china": "CHN",
    "south korea": "KOR", "korea": "KOR",
    "argentina": "RA",
    "colombia": "CO",
    "chile": "RCH",
    "philippines": "PHL",
    "nigeria": "NGA",
    "kenya": "EAK",
    "jamaica": "JA",
    "trinidad": "TT", "trinidad and tobago": "TT",
    "puerto rico": "PR",
    "cuba": "CUB",
    "greece": "GR",
    "turkey": "TR",
    "egypt": "EGY",
    "pakistan": "PK",
    "bangladesh": "BD",
    "sri lanka": "CL",
    "singapore": "SGP",
    "malaysia": "MAL",
    "thailand": "THA",
    "vietnam": "VN",
    "indonesia": "RI",
}

def get_country_code(name):
    name_lower = name.lower().strip()
    if name_lower in COUNTRY_CODES:
        return COUNTRY_CODES[name_lower]
    if len(name_lower) <= 3 and name_lower.isalpha():
        return name_lower.upper()
    return name_lower.upper()[:3]

def recursive_replace(string: str, repl: str, new: str):
    while repl in string:
        string = string.replace(repl, new)
    return string

def clean_stream_url(url):
    if 'myradiostream.com' in url:
        url = url.replace('https://', 'http://').replace(':/', ':').rstrip(';/')
        if not url.endswith('/listen.mp3'):
            url += '/listen.mp3'
    return url

def parse_station(station):
    profiles=['', 'LC', 'HE', 'HE2', 'AAC Main']
    protocols=['http', 'https', 'mms', 'mmsh', 'rtsp', 'rtmp']

    res = {}
    if not station:
        return {"code": -1}
    res["link"] = station[0]
    res["bitrate"] = station[2]
    res["code"] = station[6]
    if len(station) > 7:
        res["protocol"] = protocols[station[7]]
    else:
        res["protocol"] = "http"
    if type(station[1]) == str:
        if station[1].isnumeric():
            res["codec"] = profiles[int(station[1])]
        else:
            res["codec"] = station[1]
    else:
        res["codec"] = res["protocol"]
    return res

class Fmstream(Plugin):
    name = "fmstream"
    plugin_id = "plugin.video.madtitansports"

    def process_item(self, item):
        if "fmstream_next" in item:
            item["is_dir"] = True
            item["link"] = item["fmstream_next"]
            list_item = xbmcgui.ListItem(item.get("title", ""), offscreen=True)
            item["list_item"] = list_item
            return item
        if self.name in item:
            link = item.get(self.name, "")
            thumbnail = item.get("thumbnail", "")
            fanart = item.get("fanart", "")
            icon = item.get("icon", "")
            if link.startswith("search"):
                item["is_dir"] = True
                item["link"] = f"{self.name}/{link}"
                list_item = xbmcgui.ListItem(item.get("title", item.get("name", "")), offscreen=True)
                list_item.setArt({"thumb": thumbnail, "fanart": fanart})
                item["list_item"] = list_item
                return item
            if link == "featured":
                item["is_dir"] = True
                item["link"] = f"{self.name}/featured"
                list_item = xbmcgui.ListItem(item.get("title", item.get("name", "")), offscreen=True)
                list_item.setArt({"thumb": thumbnail, "fanart": fanart})
                item["list_item"] = list_item
                return item
            if link.startswith("country"):
                item["is_dir"] = True
                item["link"] = f"{self.name}/{link}"
                list_item = xbmcgui.ListItem(item.get("title", item.get("name", "")), offscreen=True)
                list_item.setArt({"thumb": thumbnail, "fanart": fanart})
                item["list_item"] = list_item
                return item
            if link and link not in ("search", "featured"):
                code = get_country_code(link)
                item["is_dir"] = True
                item["link"] = f"{self.name}/country/{code}"
                list_item = xbmcgui.ListItem(item.get("title", item.get("name", "")), offscreen=True)
                list_item.setArt({"thumb": thumbnail, "fanart": fanart})
                item["list_item"] = list_item
                return item

    def routes(self, plugin):
        def fetch_page(query, offset=0):
            headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36'}
            params = {"s": query}
            if offset > 0:
                params["n"] = str(offset)
            for attempt in range(4):
                resp = requests.get("https://fmstream.org/index.php", params=params, headers=headers, timeout=15)
                if resp.status_code == 429:
                    time.sleep(3 * (attempt + 1))
                    continue
                resp.raise_for_status()
                break
            else:
                raise Exception("Rate limited by fmstream.org. Please wait and try again.")
            page = resp.text
            m = re.search(r'const\s+fetchIds\s*=\s*"([^"]*)"', page)
            if not m or not m.group(1).strip():
                return [], -1
            fetch_ids = m.group(1).strip().split(",")
            next_offset = -1
            next_m = re.search(r'href="\?[^"]*n=(\d+)"[^>]*>Next', page)
            if next_m:
                next_offset = int(next_m.group(1))
            return fetch_ids, next_offset

        def fetch_featured():
            headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36'}
            for attempt in range(4):
                resp = requests.get("https://fmstream.org/index.php", params={"li": "FT"}, headers=headers, timeout=15)
                if resp.status_code == 429:
                    time.sleep(3 * (attempt + 1))
                    continue
                resp.raise_for_status()
                break
            else:
                raise Exception("Rate limited by fmstream.org. Please wait and try again.")
            page = resp.text
            m = re.search(r'const\s+fetchIds\s*=\s*"([^"]*)"', page)
            if not m or not m.group(1).strip():
                return []
            return m.group(1).strip().split(",")

        def fetch_country(country_code, offset=0):
            headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36'}
            params = {"c": country_code, "o": "top"}
            if offset > 0:
                params["n"] = str(offset)
            for attempt in range(4):
                resp = requests.get("https://fmstream.org/index.php", params=params, headers=headers, timeout=15)
                if resp.status_code == 429:
                    time.sleep(3 * (attempt + 1))
                    continue
                resp.raise_for_status()
                break
            else:
                raise Exception("Rate limited by fmstream.org. Please wait and try again.")
            page = resp.text
            m = re.search(r'const\s+fetchIds\s*=\s*"([^"]*)"', page)
            if not m or not m.group(1).strip():
                return [], -1
            fetch_ids = m.group(1).strip().split(",")
            next_offset = -1
            next_m = re.search(r'href="\?[^"]*n=(\d+)"[^>]*>Next', page)
            if next_m:
                next_offset = int(next_m.group(1))
            return fetch_ids, next_offset

        def build_station_list(fetch_ids, query, next_offset):
            headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36'}
            fetch_ids_str = ",".join(fetch_ids)
            data = requests.post(
                "https://fmstream.org/stations2.php",
                data={"ids": fetch_ids_str, "app": "fmstream"},
                headers=headers,
                timeout=30
            ).json()
            if not data or (isinstance(data, dict) and data.get("error")):
                return []
            jen_list = []
            full_plugin = f"plugin://{self.plugin_id}"
            for row in data:
                try:
                    program = row[1] or "Unknown"
                    city = row[3] or ""
                    reg = row[4] or ""
                    itu = row[5] or ""
                    style = row[6] or ""
                    frq = row[7] or ""
                    homepage = row[8] or ""
                    branding = row[9] or ""
                    slogan = row[10] or ""
                    description = row[11] or ""
                    urls_raw = row[2] if len(row) > 2 else []
                    if isinstance(urls_raw, str):
                        try:
                            urls_raw = json.loads(urls_raw)
                        except Exception:
                            urls_raw = []
                    streams = []
                    for u in urls_raw:
                        try:
                            raw_url = u[0] or ""
                            codec = u[1] or "web"
                            bitrate = u[2] if len(u) > 2 and u[2] else 0
                            profile = u[7] if len(u) > 7 else None
                            active = u[8] if len(u) > 8 else 1
                            if not raw_url or codec == "web":
                                continue
                            if active == 0:
                                continue
                            full_url = raw_url if raw_url.startswith("http") else f"http://{raw_url}"
                            full_url = clean_stream_url(full_url)
                            br_kbps = int(round(bitrate / 1000)) if bitrate else 0
                            codec_label = profile if profile else codec.upper()
                            streams.append((full_url, br_kbps, codec_label))
                        except Exception:
                            continue
                    if not streams and homepage:
                        hp = homepage if homepage.startswith("http") else f"http://{homepage}"
                        streams.append((hp, 0, "WEB"))
                    if not streams:
                        continue
                    summary_parts = []
                    loc = ", ".join(filter(None, [city, reg, itu]))
                    if loc:
                        summary_parts.append(loc)
                    if style:
                        summary_parts.append(style)
                    if frq:
                        summary_parts.append(f"Freq: {frq}")
                    if description:
                        summary_parts.append(description[:200] + "..." if len(description) > 200 else description)
                    if branding:
                        summary_parts.append(branding)
                    if slogan:
                        summary_parts.append(slogan)
                    if homepage:
                        summary_parts.append(homepage)
                    summary = " | ".join(summary_parts).strip() or "No description available."
                    best = streams[0][0]
                    stream_label = f"{streams[0][1]}kbps {streams[0][2]}" if streams[0][1] else streams[0][2]
                    if len(streams) > 1:
                        stream_label += f" (+{len(streams)-1} more)"
                    if best.endswith(('.m3u8', '.mp3', '.aac', '.pls')):
                        stream_link = best
                    else:
                        stream_link = f"{full_plugin}/{self.name}/play/{urllib.parse.quote(best)}"
                    jen_data = {
                        "title": f"[{stream_label}] [COLOR=cyan]{program}[/COLOR]",
                        "link": stream_link,
                        "type": "item",
                        "summary": summary
                    }
                    jen_list.append(jen_data)
                except Exception:
                    continue
            if next_offset >= 0:
                jen_list.append({
                    "title": f"Next Page >>",
                    "fmstream_next": f"/{self.name}/next/{urllib.parse.quote(query)}/{next_offset}",
                    "type": "item",
                    "summary": "Load next 50 results from fmstream.org"
                })
            return jen_list

        @plugin.route(f"/{self.name}/search/<query>")
        def search(query):
            query = urllib.parse.unquote_plus(query)
            if query == "*":
                query = xbmcgui.Dialog().input("Enter query")
                if query == "": return
            xbmcgui.Dialog().ok("FMStream - Rate Limit Notice", "Searching fmstream.org...\n\nPlease avoid rapid or repeated searches. The site may temporarily block your IP if hit too frequently.\n\nClick OK to continue.")
            try:
                fetch_ids, next_offset = fetch_page(query, 0)
            except Exception as e:
                xbmcgui.Dialog().ok("Error", f"Failed to fetch search results: {str(e)}")
                return
            if not fetch_ids:
                xbmcgui.Dialog().ok("No Results", "No stations found for this query.")
                return
            try:
                jen_list = build_station_list(fetch_ids, query, next_offset)
            except Exception as e:
                xbmcgui.Dialog().ok("Error", f"Failed to fetch station data: {str(e)}")
                return
            if not jen_list:
                xbmcgui.Dialog().ok("No Results", "No stations found for this query. Try a different term (e.g., 'bbc' or 'pop').")
                return
            jen_list = [run_hook("process_item", item) for item in jen_list]
            jen_list = [run_hook("get_metadata", item, return_item_on_failure=True) for item in jen_list]
            run_hook("display_list", jen_list)

        @plugin.route(f"/{self.name}/featured")
        def featured():
            xbmcgui.Dialog().ok("FMStream - Rate Limit Notice", "Loading featured stations from fmstream.org...\n\nClick OK to continue.")
            try:
                fetch_ids = fetch_featured()
            except Exception as e:
                xbmcgui.Dialog().ok("Error", f"Failed to fetch featured stations: {str(e)}")
                return
            if not fetch_ids:
                xbmcgui.Dialog().ok("No Results", "No featured stations found.")
                return
            try:
                jen_list = build_station_list(fetch_ids, "featured", -1)
            except Exception as e:
                xbmcgui.Dialog().ok("Error", f"Failed to fetch station data: {str(e)}")
                return
            if not jen_list:
                xbmcgui.Dialog().ok("No Results", "No featured stations found.")
                return
            jen_list = [run_hook("process_item", item) for item in jen_list]
            jen_list = [run_hook("get_metadata", item, return_item_on_failure=True) for item in jen_list]
            run_hook("display_list", jen_list)

        @plugin.route(f"/{self.name}/country/<code>")
        def country(code):
            if code == "*":
                code = xbmcgui.Dialog().input("Enter country name")
                if not code:
                    return
                code = get_country_code(code)
            else:
                code = code.upper()
            xbmcgui.Dialog().ok("FMStream - Rate Limit Notice", f"Loading top stations from {code}...\n\nClick OK to continue.")
            try:
                fetch_ids, next_offset = fetch_country(code, 0)
            except Exception as e:
                xbmcgui.Dialog().ok("Error", f"Failed to fetch stations for {code}: {str(e)}")
                return
            if not fetch_ids:
                xbmcgui.Dialog().ok("No Results", f"No stations found for {code}.")
                return
            try:
                jen_list = build_station_list(fetch_ids, code, next_offset)
            except Exception as e:
                xbmcgui.Dialog().ok("Error", f"Failed to fetch station data: {str(e)}")
                return
            if not jen_list:
                xbmcgui.Dialog().ok("No Results", f"No stations found for {code}.")
                return
            jen_list = [run_hook("process_item", item) for item in jen_list]
            jen_list = [run_hook("get_metadata", item, return_item_on_failure=True) for item in jen_list]
            run_hook("display_list", jen_list)

        @plugin.route(f"/{self.name}/next/<query>/<offset>")
        def next_page(query, offset):
            query = urllib.parse.unquote_plus(query)
            offset = int(offset)
            try:
                fetch_ids, next_offset = fetch_page(query, offset)
            except Exception as e:
                xbmcgui.Dialog().ok("Error", f"Failed to fetch next page: {str(e)}")
                return
            if not fetch_ids:
                xbmcgui.Dialog().ok("No More Results", "No more stations found.")
                return
            try:
                jen_list = build_station_list(fetch_ids, query, next_offset)
            except Exception as e:
                xbmcgui.Dialog().ok("Error", f"Failed to fetch station data: {str(e)}")
                return
            if not jen_list:
                xbmcgui.Dialog().ok("No More Results", "No more stations found.")
                return
            jen_list = [run_hook("process_item", item) for item in jen_list]
            jen_list = [run_hook("get_metadata", item, return_item_on_failure=True) for item in jen_list]
            run_hook("display_list", jen_list)

        @plugin.route(f"/{self.name}/play/<path:encoded_url>")
        def play(encoded_url):
            stream_url = urllib.parse.unquote(encoded_url)
            try:
                stream_url = clean_stream_url(stream_url)
                if stream_url:
                    listitem = xbmcgui.ListItem(path=stream_url)
                    if '.m3u8' in stream_url:
                        mime = "application/vnd.apple.mpegurl"
                    elif '.aac' in stream_url:
                        mime = "audio/aac"
                    else:
                        mime = "audio/mpeg"
                    listitem.setMimeType(mime)
                    xbmc.Player().play(stream_url, listitem)
                else:
                    xbmcgui.Dialog().notification("Stream Not Found", "No playable stream found.")
            except Exception as e:
                xbmcgui.Dialog().ok("Play Error", f"Failed: {str(e)}")