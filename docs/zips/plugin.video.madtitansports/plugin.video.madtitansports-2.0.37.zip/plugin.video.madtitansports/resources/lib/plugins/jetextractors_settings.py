import xbmcgui
import xbmcaddon
import xbmc
from ..plugin import Plugin
try:
    from jetextractors.tools import (
        is_debug_enabled, set_debug_logging,
        is_telegramxtream_enabled, set_telegramxtream_enabled,
        is_homeiptv_enabled, set_homeiptv_enabled,
        is_myiptv_enabled, set_myiptv_enabled,
        revalidate_telegramxtream, revalidate_homeiptv,
    )
except ImportError:
    is_debug_enabled = set_debug_logging = None
    is_telegramxtream_enabled = set_telegramxtream_enabled = None
    is_homeiptv_enabled = set_homeiptv_enabled = None
    is_myiptv_enabled = set_myiptv_enabled = None
    revalidate_telegramxtream = revalidate_homeiptv = None

addon_icon = xbmcaddon.Addon().getAddonInfo('icon')


class JetExtractorsSettings(Plugin):
    name = "jetextractors_settings"
    priority = 100

    def process_item(self, item):
        if self.name in item:
            link = item.get(self.name, "")
            if link.startswith("manage"):
                item["is_dir"] = True
                item["link"] = f"{self.name}/{link}"
                list_item = xbmcgui.ListItem(item.get("title", item.get("name", "")), offscreen=True)
                item["list_item"] = list_item
                return item

    def routes(self, plugin):
        @plugin.route(f"/{self.name}/manage")
        def manage():
            if is_debug_enabled is None:
                xbmcgui.Dialog().ok("JetExtractors Settings", "JetExtractors module not available or outdated.")
                return
            settings = [
                {"key": "debug_logging", "label": "Debug Logging", "getter": is_debug_enabled, "setter": set_debug_logging, "type": "toggle"},
                {"key": "telegramxtream_enabled", "label": "TelegramXtream Extractor", "getter": is_telegramxtream_enabled, "setter": set_telegramxtream_enabled, "type": "toggle"},
                {"key": "homeiptv_enabled", "label": "HomeIPTV Extractor", "getter": is_homeiptv_enabled, "setter": set_homeiptv_enabled, "type": "toggle"},
                {"key": "myiptv_enabled", "label": "MyIPTV Extractor", "getter": is_myiptv_enabled, "setter": set_myiptv_enabled, "type": "toggle"},
                {"key": "revalidate", "label": "Revalidate TelegramXtream", "action": revalidate_telegramxtream, "type": "action"},
                {"key": "revalidate_homeiptv", "label": "Revalidate HomeIPTV", "action": revalidate_homeiptv, "type": "action"},
            ]

            while True:
                items = []
                for setting in settings:
                    if setting.get("type") == "action":
                        label = f"[COLOR cyan]{setting['label']}[/COLOR]"
                    else:
                        enabled = setting["getter"]()
                        status = "[COLOR lime]ON[/COLOR]" if enabled else "[COLOR red]OFF[/COLOR]"
                        label = f"{status}  {setting['label']}"
                    items.append(label)

                chosen = xbmcgui.Dialog().select(
                    "JetExtractors Settings (select to toggle)",
                    items,
                    preselect=-1,
                )

                if chosen == -1:
                    break

                selected = settings[chosen]
                if selected.get("type") == "action":
                    try:
                        selected["action"]()
                    except Exception as e:
                        xbmc.executebuiltin(
                            'Notification(JetExtractors,Error: %s,3000,%s)' % (str(e), addon_icon)
                        )
                    else:
                        xbmc.executebuiltin(
                            'Notification(JetExtractors,%s running...,3000,%s)' % (selected["label"], addon_icon)
                        )
                else:
                    current = selected["getter"]()
                    selected["setter"](not current)

                    new_state = "enabled" if not current else "disabled"
                    xbmc.executebuiltin(
                        'Notification(JetExtractors,%s %s,3000,%s)' % (selected["label"], new_state, addon_icon)
                    )
                    if not current and selected["key"] == "telegramxtream_enabled" and revalidate_telegramxtream:
                        try:
                            revalidate_telegramxtream()
                            xbmc.executebuiltin(
                                'Notification(JetExtractors,Revalidating TelegramXtream...,5000,%s)' % addon_icon
                            )
                        except Exception as e:
                            xbmc.executebuiltin(
                                'Notification(JetExtractors,Error: %s,3000,%s)' % (str(e), addon_icon)
                            )
                    elif not current and selected["key"] == "homeiptv_enabled" and revalidate_homeiptv:
                        try:
                            revalidate_homeiptv()
                            xbmc.executebuiltin(
                                'Notification(JetExtractors,Revalidating HomeIPTV...,5000,%s)' % addon_icon
                            )
                        except Exception as e:
                            xbmc.executebuiltin(
                                'Notification(JetExtractors,Error: %s,3000,%s)' % (str(e), addon_icon)
                            )
