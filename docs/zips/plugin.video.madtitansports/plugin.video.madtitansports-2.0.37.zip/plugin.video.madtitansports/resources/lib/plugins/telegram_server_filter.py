import xbmcgui
import xbmcaddon
import xbmc
import urllib.parse
from ..plugin import Plugin
try:
    from jetextractors.util.TelegramStore import (
        get_excluded_portals, add_excluded_portal, remove_excluded_portal,
        load_channels, remove_portal_channels,
    )
except ImportError:
    get_excluded_portals = add_excluded_portal = remove_excluded_portal = load_channels = remove_portal_channels = None

addon_icon = xbmcaddon.Addon().getAddonInfo('icon')


class TelegramServerFilter(Plugin):
    name = "telegram_server_filter"
    priority = 100

    def process_item(self, item):
        if self.name in item:
            link = item.get(self.name, "")
            if link.startswith("manage"):
                item["is_dir"] = True
                item["link"] = f"{self.name}/{link}"
                list_item = xbmcgui.ListItem(item.get("title", item.get("name", "")), offscreen=True)
                item["list_item"] = list_item
                return item

    def routes(self, plugin):
        @plugin.route(f"/{self.name}/manage")
        def manage():
            if load_channels is None:
                xbmcgui.Dialog().ok("Telegram Server Filter", "JetExtractors module not available or outdated.")
                return
            data = load_channels()
            portals = {}
            for ch in data.get("channels", []):
                p = ch.get("portal", "")
                if p and p not in portals:
                    portals[p] = ch.get("name", "")

            excluded = set(get_excluded_portals())

            if not portals:
                xbmcgui.Dialog().ok("Server Filter", "No servers found. Run a Telegram search first.")
                return

            sorted_portals = sorted(portals.keys())

            while True:
                items = []
                for addr in sorted_portals:
                    status = "[COLOR red]BLOCKED[/COLOR]" if addr in excluded else "[COLOR lime]active[/COLOR]"
                    label = f"{status}  {addr}"
                    items.append(label)

                chosen = xbmcgui.Dialog().select(
                    "Telegram Servers (select to toggle block)",
                    items,
                    preselect=-1,
                )

                if chosen == -1:
                    break

                selected_addr = sorted_portals[chosen]

                if selected_addr in excluded:
                    remove_excluded_portal(selected_addr)
                    excluded.discard(selected_addr)
                    xbmc.executebuiltin('Notification(Server Filter,Unblocked %s,3000,%s)' % (selected_addr, addon_icon))
                else:
                    add_excluded_portal(selected_addr)
                    excluded.add(selected_addr)
                    if remove_portal_channels:
                        try:
                            remove_portal_channels(selected_addr)
                        except Exception:
                            pass
                    xbmc.executebuiltin('Notification(Server Filter,Blocked %s,3000,%s)' % (selected_addr, addon_icon))
