import sys
import xbmc
import xbmcaddon
from resources.lib.tool import log
from resources.lib.changelog_window import check_and_show_changelog, show_changelog_from_tools

ADDON_ID = "plugin.video.madtitansports"
ADDON = xbmcaddon.Addon(id=ADDON_ID)


def main():
    args = sys.argv[1:]
    mode = args[0] if len(args) > 0 else "auto"
    after = args[1] if len(args) > 1 else "none"

    addon_path = ADDON.getAddonInfo("path")
    log(f"changelog.py started mode={mode} after={after}")

    if mode == "force":
        show_changelog_from_tools(addon_path)
    else:
        check_and_show_changelog(addon_path)

    if after == "gui":
        xbmc.executebuiltin(f"RunPlugin(plugin://{ADDON_ID}/gui_home)")
    elif after == "list":
        xbmc.executebuiltin(f"Container.Update(plugin://{ADDON_ID}/main_list)")

    log("changelog.py finished")


if __name__ == "__main__":
    main()
