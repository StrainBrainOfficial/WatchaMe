# Mad Titan Sports — How to Navigate

## Main Menu (Left Side)

The main menu is your home screen. Scroll up/down to browse categories. The right side shows a preview of whatever is highlighted.

- **Left-click / Select** on a category to open it
- **Back** to return to the previous menu (or close the addon if already at the root)
- **Right-click / Context menu** to jump directly to playback

---

## Sections

### Live Sports
Highlight **"LIVE SPORTS"** in the main menu to see today's games in the preview panel.

- **Right arrow** → enter the game list
- **Up/Down** → scroll through games (preview updates with scores and team logos)
- **Left-click** on a game → stream picker opens → pick a source to play
- **Left arrow** or **Back** → return to main menu
- Games update automatically. In-progress games are shown first with green status text.

### Sports Networks / Live TV
Highlight a network category (e.g. "SPORTS NETWORKS", "US ENTERTAINMENT", "LIVE TV") to see channel logos in the preview panel.

- **Right arrow** → enter the channel grid
- **Left/Right** → scroll through channels (preview shows what's currently airing + EPG schedule)
- **Left-click** on a channel → plays the stream or opens a sub-menu
- **Left arrow** or **Back** → return to main menu
- Channel categories appear at the root level and inside sub-menus

### Movies / TV Shows
Highlight a movie or TV category (e.g. "MOVIES SECTION", "TV SHOWS SECTION") to see a poster grid in the preview panel.

- **Right arrow** → enter the poster grid
- **Left/Right** → scroll through posters (preview shows movie details, rating, overview)
- **Left-click** on a poster → plays the movie/show or opens season list
- **Left arrow** or **Back** → return to main menu
- Posters rotate automatically every 5 seconds; rotation pauses while you're browsing the grid

### PVR Sport Search
Click a sport search item to open a search dialog. Type a team name (e.g. "Spain", "Lakers") and results from all available extractors appear in the main list.

- Results with a **green `>`** prefix are playable streams
- Click a result → stream picker opens
- **Back** returns to the search results, then back to the main menu
- Recent searches are cached — you can re-run them from the cache menu

### File IPTV Search
Click a File IPTV item to search for live TV channels by name.

- Type a channel name → results show matching channels with connection counts
- Click a result → stream plays directly
- **Back** returns to the search results

### Recently Played
Appears at the bottom of the main menu. Shows your last few played streams with timestamps.

- Click to open the list
- Click any item → plays that stream again
- **Back** returns to the main menu

---

## Navigation Cheatsheet

| Action | What Happens |
|--------|-------------|
| **Up/Down** | Scroll through the main menu; preview updates |
| **Right arrow** | Enter the preview sub-panel (game list, movie grid, or channel grid) |
| **Left arrow** | Exit the sub-panel back to the main menu |
| **Back** | Go back one menu level, or close the addon at the root |
| **Left-click / Select** | Open category, play item, or show source picker |
| **Right-click** | Jump directly to playback (skips the preview panel) |
| **Close button** (top-right) | Close the addon |

---

## Source Picker

When you click an item with multiple stream sources, a dialog pops up listing them. Scroll to pick one and press Select to play. If a stream doesn't work, go back and try another source.

---

## Tips

- The **preview panel updates live** as you scroll — no need to click into everything to see what it is
- **Live sports scores** refresh automatically after a full rotation cycle through all games
- **Movie posters** rotate every 5 seconds; browsing the grid pauses the rotation
- **Channel EPG** shows what's currently airing and what's coming up next
- The addon stays open during playback — press **Back** to stop and return to the menu
- Your position in the menu is saved when you play something — you'll return to the same spot after playback

---

## Settings

Open settings from the addon's context menu or from the **"TOOLS"** section in the main menu.

### Settings (General)

| Setting | What It Does |
|---------|-------------|
| **Use Cache** | Stores menu data locally so it loads faster. Turn on if the addon feels slow. |
| **Cache Update Interval** | How often (in minutes) the cache refreshes. Default is 60 minutes. Only shown when Use Cache is on. |
| **Clear Cache** | Wipes the stored cache. Try this if menus look outdated or broken. Only shown when Use Cache is on. |
| **Enable Full Meta For TMDB Lists** | Fetches detailed info (plot, rating, artwork) for movies and TV shows. ON by default. |
| **Fetch Metadata For Manually Made Lists** | Also fetches full metadata for user-created lists. OFF by default because it slows loading. Only shown when Full Meta is on. |
| **Open MicroJen Scrapers Settings** | Opens settings for the scraper engine (advanced users). |

### TMDB

| Setting | What It Does |
|---------|-------------|
| **API Key** | The TMDB API key (pre-configured, hidden). No need to change this. |
| **Access Token** | The TMDB access token (pre-configured, hidden). No need to change this. |

### Trakt

| Setting | What It Does |
|---------|-------------|
| **Authorize** | Links your Trakt account. Click this, log in on the web, and enter the code shown. |
| **Clear Trakt Authorization** | Disconnects your Trakt account. You'll need to authorize again to use Trakt features. |

### GUI Settings

| Setting | What It Does |
|---------|-------------|
| **Enable GUI Front Page** | Turns the custom GUI on/off. OFF uses Kodi's default menu instead. |
| **Server Front URL** | The JSON server address that provides the menu items. Only shown when GUI is OFF. |
| **Recently Played Items** | How many recently played items to show at the bottom of the menu. Default is 5. Set to 0 to hide it. |
| **Disable Preview Panel** | Hides the right-side preview panel and shows fanart only. Makes the addon load faster on slow devices. |

### Live Scores

| Setting | What It Does |
|---------|-------------|
| **Cache TTL** | How many minutes to cache live scores before refreshing. Default is 5. |
| **NFL** | Show NFL scores in the Live Sports panel. |
| **MLB** | Show MLB scores. |
| **NBA** | Show NBA scores. |
| **NHL** | Show NHL scores. |
| **NCAAB** | Show College Basketball scores. |
| **WNBA** | Show WNBA scores. |
| **MLS** | Show MLS (soccer) scores. |
| **CFL** | Show CFL (Canadian football) scores. |
| **College Baseball** | Show College Baseball scores. |
| **La Liga** | Show La Liga (Spanish soccer) scores. |
| **Bundesliga** | Show Bundesliga (German soccer) scores. |
| **Serie A** | Show Serie A (Italian soccer) scores. |
| **Ligue 1** | Show Ligue 1 (French soccer) scores. |
| **Champions League** | Show Champions League scores. |
| **World** | Show international/World Cup scores. |

Enable the sports you follow — only enabled sports appear in the Live Sports panel.

### Dev Mode

| Setting | What It Does |
|---------|-------------|
| **Enable Debug Logging** | Adds extra detail to the Kodi log for troubleshooting. Off unless something is broken. |
| **Enable Debugging Mode** | Enables additional debug features. Off unless instructed by a developer. |


---

## Settings Access from the GUI

Some settings are also accessible directly from the main menu:

- **TOOLS** → shows a settings panel in the preview area where you can edit File IPTV, Addon, or JetExtractor settings inline
- **SETTINGS** (in root menu) → opens the full Kodi addon settings window
