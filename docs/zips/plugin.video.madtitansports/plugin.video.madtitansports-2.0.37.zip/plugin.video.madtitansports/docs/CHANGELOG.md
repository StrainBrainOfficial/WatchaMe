# Mad Titan Sports - Changelog

## About
Mad Titan Sports is a Kodi addon for streaming live sports, movies, and TV shows. Features include live ESPN scores for 15+ sports, TMDB movie/TV browsing, IPTV channel search, PVR sport search, and a custom GUI with preview panels. The addon supports multiple content sources via JetExtractors and scrapers, with a recently played history and configurable settings.

## [2.0.37] - August 24, 2026

### Fixes
- **GUI mode now plays all stream links** — Channels that failed with "Unable to find plugin" error in GUI mode now work correctly. This affected streams hosted on sites like
 ## ok.ru ###
- where the addon needed to resolve the URL before playing

## [2.0.37] - August 23, 2026

### Improvements
- **Recently Played saves actual stream sources** — When you play a channel, the addon now saves the actual playable source URL so it can replay instantly without re-resolving
- **Live events saved to recently played** — Playing a live sports event now saves it to recently played history
- **Better replay reliability** — Saved URLs work correctly whether they're regular HTTP streams, jetproxy streams, or JetExtractors-protected sources
- **Cleaner source labels** — Recently played items now show the channel name instead of technical plugin URLs
- **Back to Video Player button** — When a video is playing in the background, a "Tap to Restore" button appears in the top-right corner. Click it to return to the fullscreen video player

## [2.0.37] - August 10, 2026

### Fixes
- **Live streams no longer freeze** — If a live stream stalls (buffering circle, frozen video), the addon now detects it and automatically restarts the stream so playback continues without you having to do anything
- **Stopping a video works normally** — Pressing stop no longer causes the stream to restart on its own
- **All live streams protected** — This fix works for channels from JSON playlists, MyIPTV Remote, File IPTV search, and all other stream sources
- **Reduced Kodi warnings** — Cleaned up deprecated stream settings that caused warning messages in the log

## [2.0.36] - August 6, 2026

### Fixes
- **Favorites no longer crash Kodi** — Favorites saved from the GUI now use `RunPlugin` instead of `PlayMedia`, which fixes the "two concurrent busydialogs" crash that happened when opening a favorite from Kodi's home screen
- **Favorites are smaller** — Large EPG schedule data is stripped from favorites before saving, making them load faster

### Known Issues
- New favorites require restarting Kodi to show up in the favorites section on the home screen. This is a Kodi limitation, not a bug in Mad Titan Sports. Restart Kodi after saving a favorite and it will appear.

## [2.0.35] - August 3, 2026

### Fixes
- **ResolveURL settings restored** - "Authorise Resolveurl" and "Open ResolveURL Settings" now appear and work correctly in the GUI

## [2.0.34] - August 3, 2026

### Fixes
- **Faster exit** - Closing the GUI window no longer pauses briefly; the window closes immediately
- **Faster stream auto-play** - When a saved stream is found, playback starts sooner (checks every half-second instead of waiting 8 full seconds)
- **Smoother navigation** - Recently played list updates in the background instead of freezing the menu after playing a video
- **ESPN/ESPN2 fix** - Remembering ESPN no longer auto-plays ESPN2 HD by accident
- **Links:// support** - Channels using the `links://` format (like ESPNEWS HD) now work with Remember Stream Selection
- **Search dialog saves preferences** - When you pick a stream from the search results, your choice is now remembered for next time

### Changes
- **Remember Stream Selection now off by default** - This setting was renamed and now defaults to off. If you had it enabled before, you'll need to turn it back on in Settings → GUI Settings → "Remember Stream Selection"

### Known Issues
- After stopping a video, there may be a 5-20 second delay before the GUI re-opens. This is caused by Kodi's inputstream addon unloading slowly — **not an issue with Mad Titan Sports itself**
- TMDB movie grid rotation doesn't follow user selection in the poster grid

## [2.0.33] - July 6, 2026

### Fixes
- **Fanart fallback** - Items without thumbnails now show the addon's default fanart instead of a blank preview
- **Thread-safe live scores** - ESPN data fetching no longer freezes the UI; game list updates happen on the main thread
- **Preview text scrolling** - Long descriptions in the preview panel now auto-scroll so you can read everything
- **Title scrolling** - Long menu item titles scroll when highlighted so you can see the full name
- **Script menu items** - Script-type items (like "Upload Kodi Log") now appear in menus and work correctly
- **Refresh Link** - The Refresh Link button now works properly in the GUI without creating extra back navigation entries
- **Cache refresh notification** - You now get a "Cache Refreshed" notification when using Refresh Link

### Changes
- **Multi-page changelog** - The "What's New" window now has 4 pages with up/down scrolling and a "Next Page" button
- **Changelog pages**: GUI Status (local), PIP Research (local), More Info (remote), Extra Info (remote)
- **Markdown support** - Changelog pages now render markdown formatting with colors and headers

### Known Issues
- TMDB movie grid rotation doesn't follow user selection in the poster grid
