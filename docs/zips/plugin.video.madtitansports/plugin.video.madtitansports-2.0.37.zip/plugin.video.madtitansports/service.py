import xbmc
from resources.lib.playback_monitor import init_monitor

# Start the persistent playback monitor from the service context.
# This avoids the problem where the monitor dies when the GUI window closes.
init_monitor()

monitor = xbmc.Monitor()
while not monitor.abortRequested():
    xbmc.sleep(1000)
