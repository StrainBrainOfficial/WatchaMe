# Homelander Bug Fixes

## Critical Fixes

### 1. "0 providers / no results" — scraper never loaded
**Root cause chain:**
- `service.py` called `clean_settings()` on every addon version update
- `clean_settings()` read `resources/settings.xml` defaults — all `<default>false</default>` for providers
- This overwrote userdata `settings.xml` with all providers set to `false`
- `enabledCheck()` read those values → returned `False` for all 13 providers
- `sources()` returned `[]` → 0 threads → instant "no results"

**Fixes applied:**
- `service.py` — removed `clean_settings()` version-update call
- `cache.py` — removed `clean_settings()` call from cache version check
- `default.py` — removed `cleanSettings` action handler
- `homelanderscrapers/resources/settings.xml` — removed "Clean Settings file" button
- `control.py` — replaced `clean_settings()` with `reset_addon_data()` (deletes full userdata dir with confirmation, prompts restart)
- `navigator.py` / `router.py` — menu item now "Reset Addon Data" → `resetAddonData` action
- `enabledCheck()` — now reads directly from `xbmcaddon.Addon().getSetting()` instead of the window-property cache, which could be stale or unbuilt

**Note:** Provider defaults in `resources/settings.xml` are still `<default>false</default>`. On a fresh install, providers will be off by default until the user enables them or uses Toggle All On.

---

### 2. Aliases crash
`aliases` was passed to scrapers as a raw string when it should be a list. Caused a crash in multiple scraper threads.

**Fix:** `literal_eval()` guard around aliases parsing in `sources.py`.

---

### 3. `getEpisodeSource` unguarded match crash
Episode regex match result was used without checking if it was `None`, causing `AttributeError` on no-match.

**Fix:** Added `if match:` guard before accessing match groups.

---

### 4. `eval()` → `literal_eval()` (5 occurrences)
Raw `eval()` on external/user data is a security risk.

**Fix:** Replaced all 5 occurrences in `sources.py` with `ast.literal_eval()`.

---

### 5. Quality casing bug
Quality strings like `4K`, `SCR`, `CAM` were compared case-sensitively against lowercase filter values, causing them to never match.

**Fix:** Added `.lower()` on quality string before comparison in `sources.py`.

---

### 6. TorBox support
TorBox was missing from the list of recognised torrent resolvers, so TorBox links were dropped silently.

**Fix:**
- Added `'TorBox'` to `torrent_resolvers` in `sources.py`
- Added `'TB'` label mapping so TorBox sources are labelled correctly in the UI

---

### 7. `log_utils.py` non-functional
The log utility was not writing to file and was silently swallowing errors, making debugging impossible.

**Fix:** Full rewrite — reads live debug setting, writes to both Kodi log and homelander log file.

---

## Parked (non-critical)

| Issue | Location | Notes |
|---|---|---|
| `headers.update(headers)` no-op | `homelanderscrapers/modules/client.py` lines 74, 256 | Updates dict with itself — cosmetic, no functional impact |
| RD 451 backoff | `sources.py` | Real-Debrid rate-limit handling not implemented |
| Orion free-user daily limit | scraper module | TODOs left in code |
| TorBox end-to-end test | resolveurl | Needs TorBox API key entered in resolveurl settings |
| Provider defaults `false` in `resources/settings.xml` | `homelanderscrapers/resources/settings.xml` | Fresh install leaves all providers disabled |
