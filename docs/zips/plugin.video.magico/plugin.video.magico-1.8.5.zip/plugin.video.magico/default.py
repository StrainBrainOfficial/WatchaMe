# -*- coding: utf-8 -*-
# Bugatsinho for Magico.info 2018

import urllib, xbmcgui, xbmcaddon, xbmcplugin, xbmc, re, sys, os
from resources.lib import pyxbmct
from resources.lib.modules import client
from resources.lib.modules import cache
from resources.lib.modules import control
from resources.lib.modules.dom_parser2 import parse_dom

reload(sys)
sys.setdefaultencoding('utf-8')

try:
    html = client.request('https://pastebin.com/raw/WwGigs17')
    NURL = client.parseDOM(html, 'domain')[0]
except BaseException:
    NURL = control.setting('domain')

BASEURL = NURL + '?p=home&pid=1'

ADDON = xbmcaddon.Addon()
ADDON_DATA = ADDON.getAddonInfo('profile')
ADDON_PATH = ADDON.getAddonInfo('path')
DESCRIPTION = ADDON.getAddonInfo('description')
FANART = ADDON.getAddonInfo('fanart')
ICON = ADDON.getAddonInfo('icon')
ID = ADDON.getAddonInfo('id')
NAME = ADDON.getAddonInfo('name')
VERSION = ADDON.getAddonInfo('version')
Lang = control.lang
Dialog = xbmcgui.Dialog()
vers = VERSION
ART = ADDON_PATH + "/resources/icons/"
__memberlist = ['Moderators', 'Super Moderators', 'Administrator', 'VIP Members', 'Uploaders',
                'S-Uploaders', 'Subs Team', 'S-VIP Members', 'Sub Moderators', 'manitsa']

try:
    path = control.setting('torrents_dir')
    if path != '':
        xbmcaddon.Addon('plugin.video.yatp').setSetting('download_dir', path)
    else:
        xbmcaddon.Addon('plugin.video.yatp').setSetting('download_dir', "")
except:
    pass

try:
    query = '{"jsonrpc": "2.0", "method": "Settings.SetSettingValue", ' \
            '"params": {"setting": "subtitles.charset", "value": "CP1253"}, "id": 1}'

    xbmc.executeJSONRPC(query)
except:
    pass

try:
    cj = control.setting('token')
except:
    pass


def magico():
    delete = control.setting('delete_tor')
    _username = xbmcaddon.Addon().getSetting('username')
    _password = xbmcaddon.Addon().getSetting('password')
    print '_USER: %s' % _username
    print '_PASS: %s' % _password

    check = login_site(_username, _password)
    xbmc.log('CKECK-RETURNS: %s' % check, xbmc.LOGNOTICE)

    if check:
        r = client.request(BASEURL, cookie=check)
        r = client.parseDOM(r, 'div', attrs={'class': 'eLinks'})[0]
        userid = client.parseDOM(r, 'a', ret='href')[0]
        userid = client.request(userid, cookie=check)
        memberid = client.parseDOM(userid, 'div', attrs={'class': 'memberCardDetails'})[0]
        try:
            memberid = re.findall(r'</span></a>.+?">(.+?)</span>', memberid, re.DOTALL)[0]
        except:
            xbmcgui.Dialog().ok('Magico GR', 'Προέκυψε ένα σφάλμα', 'με το πρόσθετο.',
                                'Παρακαλώ επικοινωνήστε με έναν διαχειριστή.')
            return

        # xbmc.log('@#@MEMBERID-CLEAN: %s' % memberid, xbmc.LOGNOTICE)
        data = client.request(NURL + 'ZGF0YS9Lb2RpLW1lbWJlcmdyb3VwL21lbWJlcmxpc3QueG1s'.decode('base64'))
        try:
            memberlist = client.parseDOM(data, 'member')
            # xbmc.log('@#@MEMBER-LIST: %s' % memberlist, xbmc.LOGNOTICE)
            if not isinstance(memberlist, list):
                memberlist = __memberlist
        except:
            memberlist = __memberlist
        # xbmc.log('@#@MEMBER-LIST: %s' % memberlist, xbmc.LOGNOTICE)
        if memberid in memberlist:
            if delete == 'true':
                clean_torrents()

            elif delete == 'false':
                pass

            else:
                line1 = Lang(32053).encode('utf-8')
                line2 = Lang(32052).encode('utf-8')
                line3 = Lang(32054).encode('utf-8')
                choice = control.yesnoDialog(line1, line2, line3, 'Magico GR', nolabel='[COLORred]NO[/COLOR]',
                                             yeslabel='[COLORgold]YES[/COLOR]')
                if choice == 1:
                    control.setSetting('delete_tor', 'true')
                else:
                    control.setSetting('delete_tor', 'false')

            line1 = Lang(32042).encode('utf-8')
            line2 = Lang(32043).encode('utf-8')
            line3 = ('[B][COLOR gold]%s[/COLOR][/B]' % _username)
            xbmcgui.Dialog().ok('Magico GR', line1, line2, line3)
            Main_addDir()

        else:
            xbmcgui.Dialog().ok('Magico GR', 'Το πρόσθετο είναι διαθέσιμο', 'μόνο για VIP μέλη',
                                'Παρακαλώ αναβαθμίστε τον λογ/σμό σας')
            return
    else:
        line1 = Lang(32040).encode('utf-8')
        line2 = Lang(32041).encode('utf-8')
        line3 = Lang(32051).encode('utf-8')
        choice = control.yesnoDialog(line1, line2, line3, 'Magico GR', nolabel='[COLORred]NO[/COLOR]',
                                     yeslabel='[COLORgold]YES[/COLOR]')
        if choice == 1:
            user = userpopup()
            passw = passpopup()
            control.setSetting('username', str(user))
            control.setSetting('password', str(passw))
            magico()
        else:
            return


def login_site(_user, _passw):
    r = client.request(BASEURL)
    sectok = re.findall(r'''stKey:\s*['"](\w\-\w+\-\w+)['"]''', r, re.DOTALL)[0]
    plink = NURL + 'ajax/login.php'
    post = {'action': 'login',
            'loginbox_remember': 'false',
            'loginbox_membername': _user,
            'loginbox_password': _passw,
            'securitytoken': sectok}
    post = urllib.urlencode(post)
    login_result = client.request(plink, post=post, referer=BASEURL, output='cookie')
    control.setSetting('token', str(login_result))
    return login_result


def Main_addDir():
    # addDir(Lang(32009).encode('utf-8'), NURL + '?p=torrents&pid=32', 5, ICON, FANART, '')
    # addDir(Lang(32008).encode('utf-8'), NURL + '?p=torrents&action=new_torrents&pid=27', 5, ICON, FANART, '')
    addDir(Lang(32002).encode('utf-8'), '', 8, ICON, FANART, '')
    addDir(Lang(32000).encode('utf-8'), '', 3, ICON, FANART, '')
    addDir(Lang(32001).encode('utf-8'), '', 4, ICON, FANART, '')
    addDir(Lang(32005).encode('utf-8'), '', 12, ICON, FANART, '')
    addDir(Lang(32006).encode('utf-8'), '', 13, ICON, FANART, '')
    addDir(Lang(32007).encode('utf-8'), NURL + '?p=torrents&type=bookmarks&pid=502', 5, ICON, FANART, '')
    addDir(Lang(32020).encode('utf-8'), '', 11, ICON, FANART, '')
    addDir(Lang(32021).encode('utf-8'), '', 9, ICON, FANART, '')
    addDir(Lang(32022).encode('utf-8'), '', 10, ICON, FANART, '')
    addDir(Lang(32019).encode('utf-8') + ': [B][COLOR lime]%s[/COLOR][/B]' % vers, '', 20, ICON, FANART, '')


def Movies():
    addDir(Lang(32002).encode('utf-8'), '', 8, ICON, FANART, '')
    addDir('Magico Ταινίες',
           NURL + '?p=torrents&pid=10&keywords=trellas&search_type=name&cid=14,16,17,84&pid=1615', 5,
           ICON, FANART, '')
    addDir('Νέες (2019, 2020, 2021)', NURL + '?p=torrents&pid=10&cid=84', 5, ICON, FANART, '')
    addDir('DVDRip-BDRip-BRRip (εώς 2018)', NURL + '?p=torrents&pid=10&cid=14', 5, ICON, FANART, '')
    addDir('Σαβούρα (CAM)', NURL + '?p=torrents&pid=10&cid=16', 5, ICON, FANART, '')
    addDir('BLU-RAY', NURL + '?p=torrents&pid=10&cid=17', 5, ICON, FANART, '')
    addDir('Eλληνικές Ταινίες', NURL + '?p=torrents&pid=10&cid=44', 5, ICON, FANART, '')
    addDir('ΑΛΦΑΒΗΤΙΚΑ ΞΕΝΕΣ ΤΑΙΝΙΕΣ (A-D)', NURL + '?p=forums&pid=11&fid=39&tid=13192', 7, ICON, FANART, '')
    addDir('ΑΛΦΑΒΗΤΙΚΑ ΞΕΝΕΣ ΤΑΙΝΙΕΣ (E-J)', NURL + '?p=forums&pid=11&fid=39&tid=13193', 7, ICON, FANART, '')
    addDir('ΑΛΦΑΒΗΤΙΚΑ ΞΕΝΕΣ ΤΑΙΝΙΕΣ (K-S)', NURL + '?p=forums&pid=11&fid=39&tid=13194', 7, ICON, FANART, '')
    addDir('ΑΛΦΑΒΗΤΙΚΑ ΞΕΝΕΣ ΤΑΙΝΙΕΣ (T)', NURL + '?p=forums&pid=11&fid=39&tid=13195', 7, ICON, FANART, '')
    addDir('ΑΛΦΑΒΗΤΙΚΑ ΞΕΝΕΣ ΤΑΙΝΙΕΣ (U-Z)', NURL + '?p=forums&pid=11&fid=39&tid=13196', 7, ICON, FANART, '')
    addDir('ΑΛΦΑΒΗΤΙΚΑ ΕΛΛΗΝΙΚΕΣ ΤΑΙΝΙΕΣ', NURL + '?p=forums&pid=11&fid=40&tid=2026', 7, ICON, FANART, '')
    addDir('ΑΛΦΑΒΗΤΙΚΑ ΠΑΙΔΙΚΕΣ ΤΑΙΝΙΕΣ', NURL + '?p=forums&pid=11&fid=41&tid=2027', 7, ICON, FANART, '')
    addDir('Ντοκιμαντέρ', NURL + '?p=torrents&pid=10&cid=76', 5, ICON, FANART, '')
    addDir('Θέατρο', NURL + '?p=torrents&pid=10&cid=82', 5, ICON, FANART, '')


def Series():
    addDir(Lang(32002).encode('utf-8'), '', 8, ICON, FANART, '')
    addDir('Magico Σειρές',
           NURL + '?p=torrents&pid=10&keywords=magico&search_type=name&cid=52,53,70,86,92&pid=1615', 5,
           ICON, FANART, '')
    addDir('Ξένες', NURL + '?p=torrents&pid=10&cid=53', 5, ICON, FANART, '')
    addDir('Ξένες (720p/1080p)', NURL + '?p=torrents&pid=10&cid=70', 5, ICON, FANART, '')
    addDir('Ελληνικές', NURL + '?p=torrents&pid=10&cid=54', 5, ICON, FANART, '')
    addDir('Ξένες Ολοκληρωμένες Seasons', NURL + '?p=torrents&pid=10&cid=86', 5, ICON, FANART, '')
    addDir('Ξένες Ολοκληρωμένες Seasons (720p/1080p)', NURL + '?p=torrents&pid=10&cid=92', 5, ICON, FANART, '')
    addDir('ΞΕΝΕΣ ΟΛΟΚΛΗΡΩΜΕΝΕΣ ΣΕΙΡΕΣ (A-M)', NURL + '?p=forums&pid=11&fid=22&tid=2107', 7, ICON, FANART, '')
    addDir('ΞΕΝΕΣ ΟΛΟΚΛΗΡΩΜΕΝΕΣ ΣΕΙΡΕΣ (N-Z)', NURL + '?p=forums&pid=11&fid=22&tid=2106', 7, ICON, FANART, '')
    addDir('Ελληνικές Ολοκληρωμένες Seasons', NURL + '?p=torrents&pid=10&cid=87', 5, ICON, FANART, '')
    addDir('ΕΛΛΗΝΙΚΕΣ ΟΛΟΚΛΗΡΩΜΕΝΕΣ ΣΕΙΡΕΣ (Α-Ω)', NURL + '?p=forums&pid=11&fid=42&tid=2108', 7, ICON,
           FANART, '')
    addDir('Ψυχαγωγικές Εκπομπές', NURL + '?p=torrents&pid=10&cid=63', 5, ICON, FANART, '')


def Paidika():
    addDir(Lang(32002).encode('utf-8'), '', 8, ICON, FANART, '')
    addDir('Μεταγλωτισμένα (Ταινίες)', NURL + '?p=torrents&pid=10&cid=38', 5, ICON, FANART, '')
    addDir('Με Υπότιτλους (Ταινίες)', NURL + '?p=torrents&pid=10&cid=39', 5, ICON, FANART, '')
    addDir('Μεταγλωτισμένα (Σειρές)', NURL + '?p=torrents&pid=10&cid=93', 7, ICON, FANART, '')
    addDir('Με Υπότιτλους (Σειρές)', NURL + '?p=torrents&pid=10&cid=94', 7, ICON, FANART, '')
    addDir('Ιαπωνικά Anime', NURL + '?p=torrents&pid=10&cid=45', 5, ICON, FANART, '')
    addDir('Μεταγλωτισμένα 3D', NURL + '?p=torrents&pid=10&cid=98', 5, ICON, FANART, '')


def Get_Genres():  # 13
    r = client.request(BASEURL, cookie=cj)
    gen = client.parseDOM(r, 'div', attrs={'class': 'genreIcon'})
    for g in gen:
        try:
            title = client.parseDOM(g, 'img', ret='alt')[0]
            icon = client.parseDOM(g, 'img', ret='src')[0]
            link = client.parseDOM(g, 'a', ret='href')[0].replace('&amp;', '&').encode('utf-8')
            icon = icon.encode('utf-8')
            link = urllib.quote(link, safe='/:?.!@#$%&*_-+=')
            title = clear_Title(title).encode('utf-8')
            if 'Book' in title or 'Βιβλ' in title: continue
            addDir('[B]%s[/B]' % title, link, 5, icon, FANART, '')
        except IndexError:
            xbmcgui.Dialog().ok('Magico GR', 'Προέκυψε ένα σφάλμα', 'με το πρόσθετο.',
                                'Παρακαλώ επικοινωνήστε με έναν διαχειριστή.')
            return
    setView('movies', 'movie-view')


def Get_listes(url):  # 7
    r = client.request(url, cookie=cj)
    r = client.parseDOM(r, 'div', attrs={'class': 'postInfo'})[0]
    r = parse_dom(r, 'a')
    for post in r:
        try:
            url = post.attrs['href']
            url = client.replaceHTMLCodes(url).encode('utf-8')
            name = post.content
            name = re.sub('<.+?>', '', name).encode('utf-8')
        except:
            name = ''
            pass
        addDir('[B][COLOR white]%s[/COLOR][/B]' % name, url, 5, ICON, FANART, '')
    setView('movies', 'movie-view')


def Get_content(url):  # 5
    if url.startswith('http'):
        r = client.request(url, cookie=cj)
    else:
        r = url
    data = client.parseDOM(r, 'div', attrs={'id': 'torrent_\d+'})
    for post in data:
        link = client.parseDOM(post, 'div', attrs={'class': 'torrentImages'})[0]
        link = client.parseDOM(link, 'a', ret='href')[0]
        title = client.parseDOM(post, 'a')[0]
        name = clear_Title(title).encode('utf-8')

        poster = client.parseDOM(post, 'a', ret='href', attrs={'rel': 'fancybox'})[0]
        uploader = client.parseDOM(post, 'div', attrs={'class': 'torrentOwner'})[0]
        uploader = re.sub('<.+?>', '', uploader).encode('utf-8')

        seed = client.parseDOM(post, 'a', attrs={'rel': 'torrent_seeders'})[0]
        leech = client.parseDOM(post, 'a', attrs={'rel': 'torrent_leechers'})[0]
        size = client.parseDOM(post, 'a', attrs={'rel': 'torrent_size'})[0]
        comp = client.parseDOM(post, 'a', attrs={'rel': 'times_completed'})[0]
        info = '{0}\nSeeders: [COLORlime]{1}[/COLOR] - Leechers: [COLORgold]{2}[/COLOR]' \
               '\nSize: [COLORorange]{3}[/COLOR] - Complete: {4} times'.format(uploader, seed, leech, size, comp)
        info = info.encode('utf-8')
        try:
            data = client.parseDOM(post, 'div', attrs={'class': 'torrentDescription'})[0]
            infos = client.parseDOM(data, 'span', attrs={'style': 'font-weight:bold;'})[1]
            infos = clear_Title(infos)
            if len(infos) < 5:
                infos = re.sub(r'<.+?>', '', data)
                infos = re.sub(r'\s{2}', ' ', infos)
                infos = clear_Title(infos)
                infos = infos.encode('utf-8')
        except:
            infos = 'N/A'

        info = '%s\n |[B][COLOR green]%s[/COLOR][/B]\n %s' % (
        info.encode('utf-8'), Lang(32014).encode('utf-8'), infos.encode('utf-8'))
        addDir('[B][COLOR white]{0}[/COLOR][/B]'.format(name), link, 100, poster, FANART, str(info))

    try:
        np = client.parseDOM(r, 'div', attrs={'class': 'pagination'})[0]
        np = parse_dom(np, 'a', req='href')
        np = [i.attrs['href'] for i in np if '&raqu' in i.content][0]
        np = np.encode('utf-8')
        page = re.findall(r'page=(\d+)$', np)[0]
        page = '[B][COLORlime]' + page + '[B][COLORwhite])[/B][/COLOR]'
        addDir('[B][COLORgold]>>>' + Lang(32011).encode('utf-8') + '[/COLOR] [COLORwhite](%s' % page, np, 5, ICON,
               FANART, '')
    except:
        pass
    setView('movies', 'movie-view')


def Search():
    keyb = xbmc.Keyboard('', Lang(32002))
    keyb.doModal()
    if keyb.isConfirmed():
        search = urllib.quote(keyb.getText())
        post = {'keywords': search.encode('utf-8'),
                'search_type': 'name',
                'cid': ''}
        post = urllib.urlencode(post)
        data = client.request(NURL + '?p=torrents&pid=10', post=post, cookie=cj)
        Get_content(data)
    else:
        return


########################################

def clear_Title(txt):
    txt = re.sub('<.+?>', '', txt)
    txt = txt.replace("&quot;", "\"").replace('()', '').replace("&#038;", "&").replace('&#8211;', ':').replace('\n',
                                                                                                               ' ')
    txt = txt.replace("&amp;", "&").replace('&#8217;', "'").replace('&#039;', ':').replace('&#;', '\'')
    txt = txt.replace("&#38;", "&").replace('&#8221;', '"').replace('&#8216;', '"').replace('&amp;#038;', '&').replace(
        '&#160;', '')
    txt = txt.replace("&nbsp;", "").replace('&#8220;', '"').replace('&#8216;', '"').replace('\t', ' ')
    return txt


def addDir(name, url, mode, iconimage, fanart, description):
    u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(
        name) + "&iconimage=" + urllib.quote_plus(iconimage) + "&description=" + urllib.quote_plus(description)
    ok = True
    liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})
    liz.setProperty('fanart_image', fanart)
    if mode == 100:
        liz.setProperty("IsPlayable", "true")
        # liz.addContextMenuItems([('Πληροφορίες', window)])
        ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=False)
    elif mode in [14, 9, 10, 11, 20, 'bug']:
        ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=False)
    else:
        ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)
    return ok


def resolve(name, url, iconimage, description):
    pyxbmct.skin.estuary = False
    tor_info, plot = description.split('|')
    if control.setting('plot-window') == 'true':
        class MyWindow(pyxbmct.AddonDialogWindow):

            def __init__(self, title=''):
                super(MyWindow, self).__init__(name)
                self.setGeometry(700, 500, 5, 2)
                self.set_controls()
                self.connect(pyxbmct.ACTION_NAV_BACK, self.close)

            def set_controls(self):
                image = pyxbmct.Image(iconimage)
                self.placeControl(image, 0, 0, 4, 1)
                self.textbox = pyxbmct.TextBox()
                self.placeControl(self.textbox, 0, 1, 4, 1)
                self.textbox.setText('%s' % plot.encode('utf-8'))
                self.textbox.autoScroll(5000, 5000, 5000)
                self.fade_label = pyxbmct.FadeLabel()
                self.placeControl(self.fade_label, 4, 1)
                self.fade_label.addLabel('[B][COLOR yellow]%s[/COLOR][/B]' % tor_info.encode('utf-8'))
                self.close_button = pyxbmct.Button('[B][COLOR white]Κλείστε για αναπαραγωγή[/COLOR][/B]''\n''(Exit)')
                self.placeControl(self.close_button, 4, 0)
                self.connect(self.close_button, self.close)

            def setAnimation(self, control):
                control.setAnimations([('WindowOpen', 'effect=fade start=0 end=100 time=500',),
                                       ('WindowClose', 'effect=fade start=100 end=0 time=500',)])

        window = MyWindow('[B][COLOR yellow]%s[/COLOR][/B]' % (name))
        window.doModal()
        del window

    r = client.request(url, cookie=cj, output='extended')
    title = re.findall('filename="(.+?)"', r[2]['Content-Disposition'])[0]
    tor_folder = control.dataPath + 'Torrents/'
    if not control.exists(tor_folder):
        control.makeFile(tor_folder)
    _torrent = os.path.join(tor_folder, '%s' % title.encode('utf-8'))
    try:
        with open(_torrent, 'wb') as f:
            f.write(r[0])
            f.close()
    except:
        control.infoDialog(Lang(32012), NAME)

    try:
        liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})
        liz.setProperty("IsPlayable", "true")
        if xbmc.getCondVisibility('system.platform.windows'):
            item = 'plugin://plugin.video.yatp/?action=play&torrent=%s&file_index=dialog' % _torrent
        else:
            item = 'plugin://plugin.video.yatp/?action=play&torrent=%s&file_index=dialog' % urllib.quote_plus(_torrent)
        liz.setPath(str(item))
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)

    except:
        control.infoDialog(Lang(32012), NAME)


def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if (params[len(params) - 1] == '/'): params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2: param[splitparams[0]] = splitparams[1]
    return param


params = get_params()
url = BASEURL
name = NAME
iconimage = ICON
mode = None
fanart = FANART
description = DESCRIPTION
query = None

try:
    url = urllib.unquote_plus(params["url"])
except:
    pass
try:
    name = urllib.unquote_plus(params["name"])
except:
    pass
try:
    iconimage = urllib.unquote_plus(params["iconimage"])
except:
    pass
try:
    mode = int(params["mode"])
except:
    pass
try:
    fanart = urllib.unquote_plus(params["fanart"])
except:
    pass
try:
    description = urllib.unquote_plus(params["description"])
except:
    pass


def setView(content, viewType):
    ''' Why recode whats allready written and works well,
    Thanks go to Eldrado for it '''
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if control.setting('auto-view') == 'true':

        print control.setting(viewType)
        if control.setting(viewType) == 'Info':
            VT = '504'
        elif control.setting(viewType) == 'Info2':
            VT = '503'
        elif control.setting(viewType) == 'Info3':
            VT = '515'
        elif control.setting(viewType) == 'Fanart':
            VT = '508'
        elif control.setting(viewType) == 'Poster Wrap':
            VT = '501'
        elif control.setting(viewType) == 'Big List':
            VT = '51'
        elif control.setting(viewType) == 'Low List':
            VT = '724'
        elif control.setting(viewType) == 'List':
            VT = '50'
        elif control.setting(viewType) == 'Default Menu View':
            VT = control.setting('default-view1')
        elif control.setting(viewType) == 'Default TV Shows View':
            VT = control.setting('default-view2')
        elif control.setting(viewType) == 'Default Episodes View':
            VT = control.setting('default-view3')
        elif control.setting(viewType) == 'Default Movies View':
            VT = control.setting('default-view4')
        elif control.setting(viewType) == 'Default Docs View':
            VT = control.setting('default-view5')
        elif control.setting(viewType) == 'Default Cartoons View':
            VT = control.setting('default-view6')
        elif control.setting(viewType) == 'Default Anime View':
            VT = control.setting('default-view7')
        else:
            VT = "0"

        print viewType
        print VT

        control.set_view_mode("Container.SetViewMode(%s)" % (int(VT)))


#################
###TOOLS###
#################

def userpopup():
    kb = xbmc.Keyboard('', 'heading', True)
    kb.setHeading('Enter Username')
    kb.setHiddenInput(False)
    kb.doModal()
    if kb.isConfirmed():
        text = kb.getText()
        return text.encode('utf-8')
    else:
        return


def passpopup():
    kb = xbmc.Keyboard('', 'heading', True)
    kb.setHeading('Enter Password')
    kb.setHiddenInput(True)
    kb.doModal()
    if kb.isConfirmed():
        text = kb.getText()
        return text.encode('utf-8')
    else:
        return


def Open_settings():  # 11
    control.openSettings()
    try:
        r = client.request(BASEURL, cookie=cj)
        r = re.findall(
            '''Συνολικά MB" />\s*([^<]+)\r\n\t\t.+?Κατεβασμένα" />\s*([^<]+)\r\n\t\t.+?Διαθέσιμα MB" />\s*([^<]+)\r\n\t\t''',
            r, re.DOTALL)[0]
        total, downloaded, available = r[0], r[1], r[2]
        control.setSetting('total', str(total))
        control.setSetting('available', str(available))
        control.setSetting('downloaded', str(downloaded))
    except:
        pass


def Force_update():
    try:
        control.force_update()
    except:
        pass


def cache_clear():
    cache.clear(withyes=False)


def clean_torrents():
    times = 0
    while times < 2:
        try:
            import shutil
            tor_dir = control.setting('torrents_dir') or control.join(xbmc.translatePath('special://temp/'), 'magico')
            _tor_file_dir = control.join(control.dataPath, 'Torrents')
            _tor_yatp_dir = control.join(control.ADDONDATA % 'plugin.video.yatp', 'torrents')
            dirs = os.listdir(tor_dir)
            torrents = os.listdir(_tor_file_dir)
            yatp = os.listdir(_tor_yatp_dir)
            for d in dirs:
                if d.startswith('.'): continue
                shutil.rmtree(control.join(tor_dir, d), ignore_errors=True)

            for f in torrents:
                if f.startswith('.'): continue
                control.deleteFile(control.join(_tor_file_dir, f))

            for y in yatp:
                if y.startswith('.'): continue
                control.deleteFile(control.join(_tor_yatp_dir, y))
            control.infoDialog(control.lang(32013).encode('utf-8'))
            if times == 2:
                break
            times += 1
        except:
            return


print str(ADDON_PATH) + ': ' + str(VERSION)
print "Mode: " + str(mode)
print "URL: " + str(url)
print "Name: " + str(name)
print "IconImage: " + str(iconimage)
#########################################################

if mode is None:
    magico()  # Main_addDir()

elif mode == 3:
    Movies()

elif mode == 4:
    Series()

elif mode == 12:
    Paidika()

elif mode == 13:
    Get_Genres()

elif mode == 5:
    Get_content(url)

elif mode == 6:
    Get_Genres()

elif mode == 7:
    Get_listes(url)

elif mode == 8:
    Search()

elif mode == 9:
    cache_clear()

elif mode == 10:
    clean_torrents()

elif mode == 11:
    Open_settings()

elif mode == 20:
    Force_update()

elif mode == 100:
    resolve(name, url, iconimage, description)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
