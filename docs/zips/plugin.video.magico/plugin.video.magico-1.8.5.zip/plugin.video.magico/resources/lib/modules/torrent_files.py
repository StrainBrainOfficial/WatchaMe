# coding: utf-8
# Module: json_requests
# Created on: 17.07.2015
# Author: Roman Miroshnychenko aka Roman V.M. (romanvm@yandex.ua)
# Licence: GPL v.3: http://www.gnu.org/copyleft/gpl.html
"""
JSON-RPC requests to the Torrent Server
"""
import xbmc

from requests import post
from simpleplugin import Addon

addon = Addon('plugin.video.yatp')
json_rpc_url = 'http://127.0.0.1:{0}/json-rpc'.format(addon.server_port)


def _request(data):
    """
    Send JSON-RPC request

    :param data: JSON request as dict
    :return:
    """
    reply = post(json_rpc_url, json=data).json()
    try:
        xbmc.log('@#@:REPLY:%s' % reply['result'], xbmc.LOGNOTICE)
        return reply['result']
    except KeyError:
        raise RuntimeError('JSON-RPC returned error:\n{0}'.format(reply['error']))


def add_torrent(torrent, paused=True):
    _request({'method': 'add_torrent', 'params': {'torrent': torrent, 'paused': paused}})


def check_torrent_added():
    return _request({'method': 'check_torrent_added'})


def get_last_added_torrent():
    return _request({'method': 'get_last_added_torrent'})

def get_files(info_hash):
    return _request({'method': 'get_files', 'params': {'info_hash': info_hash}})

