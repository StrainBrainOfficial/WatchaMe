# -*- coding: utf-8 -*-
from requests import post

json_rpc_url = 'http://127.0.0.1:{0}/json-rpc'.format(addon.server_port)


def _request(data):
    """
    Send JSON-RPC request

    :param data: JSON request as dict
    :return:
    """
    reply = post(json_rpc_url, json=data).json()
    try:
        return reply['result']
    except KeyError:
        raise RuntimeError('JSON-RPC returned error:\n{0}'.format(reply['error']))


def add_torrent(torrent, paused=True):
    _request({'method': 'add_torrent', 'params': {'torrent': torrent, 'paused': paused}})