import pyxbmct


class MyWindow(pyxbmct.AddonDialogWindow):

    def __init__(self, title=''):
        super(MyWindow, self).__init__(title)
        self.setGeometry(700, 500, 5, 2)
        self.set_controls()
        self.connect(pyxbmct.ACTION_NAV_BACK, self.close)

    def set_controls(self):
        image = pyxbmct.Image(icon)
        self.placeControl(image, 0, 0, 4, 1)
        self.textbox = pyxbmct.TextBox()
        self.placeControl(self.textbox, 0, 1, 4, 1)
        self.textbox.setText('[B][COLOR green]%s[/COLOR][/B]''\n''%s' %(w, desc))
        self.textbox.autoScroll(5000, 5000, 5000)
        self.fade_label = pyxbmct.FadeLabel()
        self.placeControl(self.fade_label, 4, 1)
        self.fade_label.addLabel('[B][COLOR yellow]%s[/COLOR][/B]' '\n' '[COLOR yellow]%s[/COLOR]' % (name3, time))
        self.close_button = pyxbmct.Button('[B][COLOR white]Κλείσε για παρόχους[/COLOR][/B]''\n''(Return σε Android)')
        self.placeControl(self.close_button, 4, 0)
        self.connect(self.close_button, self.close)

    def setAnimation(self, control):
        control.setAnimations([('WindowOpen', 'effect=fade start=0 end=100 time=500',),
                               ('WindowClose', 'effect=fade start=100 end=0 time=500',)])


window = MyWindow('[B][COLOR yellow]%s[/COLOR][/B]' % (name))
window.doModal()
del window