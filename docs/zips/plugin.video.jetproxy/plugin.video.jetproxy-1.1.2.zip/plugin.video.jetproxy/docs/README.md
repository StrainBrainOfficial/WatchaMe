# JetProxy

Local HLS proxy for Kodi. JetExtractors (and other addons) hand JetProxy `jetproxy://` stream URLs; JetProxy fetches the upstream manifest/segments with controlled HTTP headers and serves them to ffmpeg/inputstream on `127.0.0.1:49777`.

**Addon ID:** `plugin.video.jetproxy`  
**Version:** 1.1.1  
**Depends on:** `script.module.routing`, `script.module.requests`

---

## What it does

1. Resolves `plugin://plugin.video.jetproxy/play/<stream_url>[?h=<headers>]`
2. Starts (if needed) a local threaded HTTP server on port **49777**
3. Proxies the m3u8 playlist and media segments upstream
4. Passes custom headers (User-Agent, Referer, Origin) through to the origin
5. Rewrites playlist URLs so segments also go through the proxy
6. Monitors stream health and can stop a dead player instead of leaving a frozen frame

Typical upstream: Xtream-style live HLS, e.g.  
`http://host:port/live/USER/PASS/STREAMID.m3u8`

---

## Settings

**Add-ons → JetProxy → Configure**

| Setting | Options | Default | Notes |
|---|---|---|---|
| Inputstream behavior | Always On / Always Off / Always Ask | Always Ask | Whether to force `inputstream.ffmpegdirect` / adaptive / none |
| Player engine | `ffmpegdirect` \| `adaptive` \| `none` | `ffmpegdirect` | Try **`adaptive`** if video plays but audio is missing or desyncs on live IPTV |
| HLS stream mode | `realtime` \| `timeshift` | `realtime` | ffmpegdirect only. `timeshift` can cause huge ActiveAE audio sync errors on live feeds |
| Max retry attempts | 5–20 | 20 | Upstream retries on manifest403/404 (capped internally at 4 for live manifests) |
| Kill stream after N seconds | 10–120 | 25 | Stall watchdog: stop playback if no media data flows |

---

## Playlist handling

When proxying an m3u8, JetProxy:

- Rewrites absolute and relative segment URLs through `http://127.0.0.1:49777/?url=...`
- Rewrites `URI="..."` inside HLS tags (`#EXT-X-MEDIA`, `#EXT-X-MAP`, I-frame playlists) so audio renditions also go through the proxy
- **Strips** `#EXT-X-START` and `#EXT-X-PROGRAM-DATE-TIME` — these can make ffmpeg report a huge stream start time (`start: 6732`) and cause ActiveAE audio mute/desync on long-running live IPTV
- Classifies binary vs playlist payloads by Content-Type **and** body sniffing (`#EXTM3U`, MPEG-TS `0x47` sync byte) so segments with wrong Content-Type are not parsed as m3u8
- Serves playlists with `Content-Length` and `Cache-Control: no-cache`
- Uses a very short playlist cache (0.5s) to collapse duplicate probes without serving stale live edge data

---

## Stream health (stall watchdog)

Two layers, checked every 2 seconds:

1. **Per-request** — if a proxied connection receives no client data for `stall_timeout` seconds, the socket is closed.
2. **Global media health** — if the Kodi player is running but no media bytes (mp2t/octet-stream) have been proxied for `stall_timeout` seconds, JetProxy **stops the player** and shows a notification. This catches `inputstream.ffmpegdirect` timeshift getting stuck without HTTP traffic.

Additionally, when a **manifest returns 404** after short retries:

- Logs `manifest 404 — portal ended/killed the stream`
- Marks the URL dead for 60s (follow-up requests fail immediately)
- **Stops the Kodi player** so you are not left waiting on a frozen frame

---

## Headers

Callers can pass headers as a base64url JSON query parameter:

```
plugin://plugin.video.jetproxy/play/http://host/live/u/p/1.m3u8?h=eyJ... 
```

Legacy Kodi-style suffixes still work:

```
http://host/live/u/p/1.m3u8|User-Agent=...&Referer=...
```

When no custom headers are supplied, JetProxy defaults to a Chrome User-Agent and derives Referer from the portal origin (never sends a blank Referer).

Hop-by-hop headers (`Connection`, `Host`, `Transfer-Encoding`, etc.) and `Range` on manifest requests are not forwarded upstream.

---

## Troubleshooting

| Symptom | What to check |
|---|---|
| Playback fails immediately | kodi.log for `JetProxy: upstream non-HLS` (block page / wrong UA) or `manifest 404` (portal killed stream) |
| Plays ~10–30s then stops | Portal likely dropped the stream; watchdog should stop the player with a notification |
| Video but no audio | Try **Player engine → adaptive**. Check log for `stripped EXT-X-PROGRAM-DATE-TIME` and the `upstream playlist for ...` dump |
| Constant buffering | Origin bandwidth or portal connection limits; JetProxy is threaded and uses connection pooling but cannot fix a slow origin |
| Log spam | Request-level logs are DEBUG; look for INFO/WARNING/ERROR `JetProxy:` lines |

Useful log greps: `JetProxy:`, `STOPPING PLAYER`, `STALL WATCHDOG`, `manifest 404`, `player_engine=`, `upstream playlist for`.

---

## Files

| File | Role |
|---|---|
| `main.py` | Plugin routes, header decode, local proxy URL, inputstream properties |
| `server.py` | Threading HTTP proxy: headers, playlist rewrite, stall watchdog, dead-stream cache |
| `player.py` | Optional ProxyPlayer helper |
| `service.py` | Kodi service entry |
| `resources/settings.xml` | Addon settings |
| `docs/CHANGELOG.md` | Version history |

---

## Related

- JetExtractors module: `script.module.jetextractors` (builds `jetproxy://` links for MyIPTV / HomeIPTV / TelegramXtream xtream channels)
- Internal notes: `script.module.jetextractors/docs/Agents_iptv_filter.md`
