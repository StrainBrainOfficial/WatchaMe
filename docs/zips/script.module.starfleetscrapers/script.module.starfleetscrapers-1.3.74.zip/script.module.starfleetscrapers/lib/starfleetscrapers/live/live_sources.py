# -*- coding: utf-8 -*-
"""
resources/lib/live_sources.py  — Unified free live TV channel loader

Sources:
  Starfleet / Québecor  — Google DAI session tokens (handled in api.py)
  Plex FAST        — Plex's own anonymous channel API (epg.provider.plex.tv)       (12h cache)
  LG Channels      — LG's own channel / schedule API (api.lgchannels.com)           (6h cache)
  Pluto TV         — boot.pluto.tv JWT API + channel list              (1h cache)

Performance optimisations applied:
  ✓ Pre-compiled regex patterns (compiled once at import time)
  ✓ Persistent SQLite connection via cache.py (single connect per process)
  ✓ In-memory hot cache for same-session repeated reads
  ✓ Pluto: metadata cached separately from stream URL (JWT not baked into cache)
  ✓ Progress dialog suppressed on cache hits
  ✓ Lazy session creation
  ✓ Compact JSON serialisation (no whitespace)
  ✓ Differentiated timeouts: 4s cache probe, 12s network fetch, 6s stream resolve
"""

from starfleetscrapers import host as _sfhost
import re
import time
import uuid
import threading
import html as _html_mod

import xbmc
import xbmcaddon
import xbmcvfs
from starfleetscrapers.core import http as requests

ADDON    = _sfhost.addon()
ADDON_ID = ADDON.getAddonInfo('id')

# Initialise cache (done once; subsequent calls are no-ops)
import xbmc as _xbmc
_PROFILE  = _sfhost.profile()
_CACHE_DB = _PROFILE + '/cache.db'

from starfleetscrapers.core import cache as _cache
_cache.init(_CACHE_DB)

# ── Pre-compiled M3U regex ────────────────────────────────────────────────────
_RE_NAME  = re.compile(r',(.+)$')
_RE_LOGO  = re.compile(r'tvg-logo="([^"]*)"')
_RE_GROUP = re.compile(r'group-title="([^"]*)"')
_RE_ID    = re.compile(r'tvg-id="([^"]*)"')

# ── First-party channel APIs ──────────────────────────────────────────────────
_PLEX_EPG_BASE = 'https://epg.provider.plex.tv'
_PLEX_ANON = 'https://clients.plex.tv/api/v2/users/anonymous'
_LG_SCHEDULE = 'https://api.lgchannels.com/api/v1.0/schedulelist'

# ── Pluto TV ─────────────────────────────────────────────────────────────────
PLUTO_BOOT = (
    'https://boot.pluto.tv/v4/start'
    '?appName=web&appVersion=9.19.0&deviceVersion=126.0.0'
    '&deviceType=web&deviceMake=chrome&deviceModel=web'
    '&clientID={cid}&clientModelNumber=1.0.0'
    '&serverSideAds=false&marketingRegion=CA'
)
PLUTO_STITCH = (
    'https://cfd-v4-service-channel-stitcher-use1-1.prd.pluto.tv'
    '/v2/stitch/hls/channel/{ch_id}/master.m3u8'
    '?appName=web&appVersion=9.19.0&deviceVersion=126.0.0'
    '&deviceType=web&deviceMake=chrome&deviceModel=web'
    '&clientID={cid}&clientModelNumber=1.0.0'
    '&country=CA&marketingRegion=CA&serverSideAds=false&jwt={jwt}'
)

HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/126.0.0.0 Safari/537.36'
    ),
    'Accept': 'application/json, text/plain, */*',
    'Accept-Language': 'en-CA,en;q=0.9,fr-CA;q=0.8',
}

# ── HTTP session (lazy, thread-safe) ─────────────────────────────────────────
_session     = None
_session_lock = threading.Lock()

from starfleetscrapers.core import net_guard as _net_guard


def _sess():
    global _session
    if _session is None:
        with _session_lock:
            if _session is None:
                s = requests.Session()
                s.headers.update(HEADERS)
                a = requests.adapters.HTTPAdapter(
                    pool_connections=24, pool_maxsize=10,
                    max_retries=requests.adapters.Retry(total=2, connect=0, backoff_factor=0.3)
                )
                s.mount('https://', a)
                _net_guard.guard(s)
                _session = s
    return _session


# ── M3U parser (optimised) ────────────────────────────────────────────────────

# ── Samsung TV+ and Roku ────────────────────────────────────────────────────────
#
# Both services only publish their channel lineups to their own device apps (Samsung TVs, Roku boxes; the Roku Channel's web page
# is not offered in Canada at all), and their streams need a per-viewer session. The playlists that used to be listed here were
# built by someone else's job and played through someone else's redirector, so they are not used any more.

def get_samsung_channels():
    return []


def get_roku_channels():
    return []


# ── Plex FAST ─────────────────────────────────────────────────────────

def _plex_headers():
    cid = _cache.get('plex_client_id')
    if not cid:
        cid = uuid.uuid4().hex
        _cache.set('plex_client_id', cid, 3650 * 86400)
    return {'Accept': 'application/json', 'X-Plex-Product': 'Plex Web', 'X-Plex-Version': '4.145.1',
            'X-Plex-Client-Identifier': cid, 'X-Plex-Platform': 'Chrome', 'User-Agent': HEADERS['User-Agent']}


def _plex_token(force=False):
    """Plex hands out a token to any client that asks for an anonymous one (what its own web player does for logged-out viewers)."""
    tok = None if force else _cache.get('plex_anon_token')
    if tok:
        return tok
    r = _sess().post(_PLEX_ANON, headers=_plex_headers(), timeout=15)
    r.raise_for_status()
    tok = (r.json() or {}).get('authToken')
    if tok:
        _cache.set('plex_anon_token', tok, 30 * 86400)
    return tok


def _plex_get(path, params=None, timeout=25):
    for attempt in (0, 1):
        tok = _plex_token(force=bool(attempt))
        h = _plex_headers()
        h['X-Plex-Token'] = tok
        r = _sess().get(_PLEX_EPG_BASE + path, headers=h, params=params, timeout=timeout)
        if r.status_code == 401 and not attempt:
            continue
        r.raise_for_status()
        return r.json()


def get_plex_channels():
    cached = _cache.get('plex_all_v2')
    if cached is not None:
        return cached
    try:
        tok = _plex_token()
        chans = ((_plex_get('/lineups/plex/channels') or {}).get('MediaContainer') or {}).get('Channel') or []
    except Exception as e:
        xbmc.log('[Starfleet] Plex channels error: %s' % e, xbmc.LOGERROR)
        return []
    out = []
    for ch in chans:
        try:
            key = ch['Media'][0]['Part'][0]['key']
        except (KeyError, IndexError, TypeError):
            continue
        if ch.get('hidden') or not ch.get('title'):
            continue
        out.append({
            'id':         ch.get('id') or key,
            'grid_key':   ch.get('gridKey', ''),
            'title':      ch['title'],
            'group':      'Plex',
            'source':     'Plex',
            'thumbnail':  ch.get('thumb') or ch.get('coverPoster') or '',
            'plot':       ch.get('summary', ''),
            'stream_url': '%s%s?X-Plex-Token=%s' % (_PLEX_EPG_BASE, key, tok),
        })
    if out:
        _cache.set('plex_all_v2', out, 12 * 3600)
        xbmc.log('[Starfleet] Plex: %d channels' % len(out), xbmc.LOGINFO)
    return out


# ── LG Channels ───────────────────────────────────────────────────────

def _lg_schedule():
    """LG's channel list with its programme schedule, as the LG Channels web player loads it (a base64 + zlib packed JSON)."""
    cached = _cache.get('lg_schedule_v1')
    if cached is not None:
        return cached
    import base64
    import json
    import zlib
    try:
        r = _sess().get(_LG_SCHEDULE, headers={'Origin': 'https://lgchannels.com', 'Referer': 'https://lgchannels.com/',
                                                'x-device-country': 'US', 'x-device-language': 'en', 'x-device-type': '0'},
                        timeout=25)
        r.raise_for_status()
        data = json.loads(zlib.decompress(base64.b64decode(r.text)))
    except Exception as e:
        xbmc.log('[Starfleet] LG schedule error: %s' % e, xbmc.LOGERROR)
        return {}
    _cache.set('lg_schedule_v1', data, 30 * 60)
    return data


def get_lg_channels():
    cached = _cache.get('lg_us_v2')
    if cached is not None:
        return cached
    sched = _lg_schedule()
    out, seen = [], set()
    for cat in (sched.get('categories') or []):
        for ch in (cat.get('channels') or []):
            cid = ch.get('channelId')
            url = (ch.get('mediaStaticUrl') or '').split('?')[0]
            if not cid or cid in seen or not url.startswith('http'):
                continue
            seen.add(cid)
            out.append({
                'id':         cid,
                'title':      ch.get('channelName', '').strip(),
                'group':      cat.get('categoryName') or ch.get('channelGenreName') or 'LG Channels',
                'source':     'LG Channels',
                'thumbnail':  ch.get('channelLogoUrl', ''),
                'stream_url': url,
            })
    if out:
        out = _alive(out)
        _cache.set('lg_us_v2', out, 6 * 3600)
        xbmc.log('[Starfleet] LG Channels: %d channels' % len(out), xbmc.LOGINFO)
    return out


def _alive(channels, workers=None, timeout=4, overall=8):
    """Drop channels whose playlist is refused outright. Everything is kept when the check itself cannot run (offline) so a bad
    connection never empties a list."""
    from concurrent.futures import ThreadPoolExecutor, wait
    if workers is None:                       # 80 connections at once is fine on a PC and far too many for a Fire TV Stick
        try:
            from starfleetscrapers.core import device
            workers = {'low': 12, 'mid': 24, 'high': 64}.get(device.profile().get('tier'), 24)
        except Exception:
            workers = 24

    def ok(ch):
        try:
            r = _sess().get(ch['stream_url'], timeout=timeout, stream=True)
            good = r.status_code == 200
            r.close()
            return good
        except Exception:
            return None

    pool = ThreadPoolExecutor(max_workers=workers)
    try:
        futs = [(ch, pool.submit(ok, ch)) for ch in channels]
        wait([f for _c, f in futs], timeout=overall)
        results = [(ch, f.result() if f.done() else None) for ch, f in futs]
    finally:
        pool.shutdown(wait=False)
    answered = [r for _c, r in results if r is not None]
    if len(answered) < max(5, len(channels) // 4) or not any(answered):
        return channels
    return [c for c, r in results if r is not False]


# ── Programme guides from the services' own APIs ─────────────────────────────────

def _iso_utc(ts):
    return time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(ts))


def _plex_epg(hours=12):
    import datetime
    from concurrent.futures import ThreadPoolExecutor
    chans = [c for c in get_plex_channels() if c.get('grid_key')]
    now = time.time()
    days = {datetime.datetime.utcfromtimestamp(now).date().isoformat(),
            datetime.datetime.utcfromtimestamp(now + hours * 3600).date().isoformat()}

    def one(ch):
        rows = []
        for day in sorted(days):
            try:
                mc = (_plex_get('/grid', {'channelGridKey': ch['grid_key'], 'date': day}, timeout=20) or {}).get('MediaContainer') or {}
            except Exception:
                continue
            for m in mc.get('Metadata') or []:
                for md in (m.get('Media') or [])[:1]:
                    b, e = md.get('beginsAt'), md.get('endsAt')
                    if not b or not e or e < now - 1800 or b > now + hours * 3600:
                        continue
                    show = m.get('grandparentTitle')
                    title = show or m.get('title', '')
                    rows.append({'title': title, 'description': m.get('summary', ''), 'start': _iso_utc(b), 'stop': _iso_utc(e),
                                 'subtitle': (m.get('title', '') if show else '')})
        return ch['id'], rows

    out = {}
    with ThreadPoolExecutor(max_workers=16) as pool:
        for cid, rows in pool.map(one, chans):
            if rows:
                out[cid] = rows
    return out


def _lg_epg():
    out = {}
    for cat in (_lg_schedule().get('categories') or []):
        for ch in (cat.get('channels') or []):
            rows = []
            for pr in ch.get('programs') or []:
                st, en = pr.get('startDateTime') or pr.get('startTime'), pr.get('endDateTime') or pr.get('endTime')
                if st and en:
                    rows.append({'title': pr.get('programTitle', ''), 'description': pr.get('description', ''), 'start': st, 'stop': en})
            if rows and ch.get('channelId') not in out:
                out[ch['channelId']] = rows
    return out


def _pluto_epg(hours=6):
    now = time.time()
    try:
        r = _sess().get(PLUTO_CHANNELS_URL, params={'start': _iso_utc(now - 1800), 'stop': _iso_utc(now + hours * 3600)}, timeout=40)
        r.raise_for_status()
        raw = r.json()
    except Exception as e:
        xbmc.log('[Starfleet] Pluto guide error: %s' % e, xbmc.LOGWARNING)
        return {}
    out = {}
    for ch in raw:
        rows = []
        for t in ch.get('timelines') or []:
            ep = t.get('episode') or {}
            if t.get('start') and t.get('stop'):
                rows.append({'title': t.get('title') or ep.get('name', ''), 'description': ep.get('description', ''),
                             'start': t['start'], 'stop': t['stop']})
        if rows:
            out[ch.get('_id') or ch.get('id')] = rows
    return out


def get_epg_entries(source):
    """{channel id: [{'title', 'description', 'start', 'stop'} (ISO UTC)]} for 'Plex', 'LG Channels' or 'Pluto TV', taken from the
    service's own API. Cached for an hour."""
    fn = {'Plex': _plex_epg, 'LG Channels': _lg_epg, 'Pluto TV': _pluto_epg}.get(source)
    if fn is None:
        return {}
    ck = 'epg_entries_v1_%s' % source
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    data = fn()
    if data:
        _cache.set(ck, data, 3600)
    return data


# ── TimStreams 24/7 channels ─────────────────────────────────────────────────

_TIM_CH_DOMAINS = ('https://tim-streams.com', 'https://timst.top')


def get_timstreams_channels():
    """~200 24/7 sports and TV channels from TimStreams' own API (grouped by its genres). Each channel's stream is a player
    frame that Starfleet Resolver turns into a playlist when it is opened."""
    cached = _cache.get('timstreams_channels')
    if cached is not None:
        return cached
    for base in _TIM_CH_DOMAINS:
        try:
            r = _sess().get(base + '/api/channels', timeout=12, headers={'Referer': base + '/', 'Accept': 'application/json'})
            if r.status_code != 200:
                continue
            data = r.json()
        except Exception as e:
            xbmc.log('[Starfleet] TimStreams channels (%s): %s' % (base, e), xbmc.LOGWARNING)
            continue
        genres = {}
        for g in data.get('genres') or []:
            if g.get('id') is not None and g.get('name'):
                genres[g['id']] = g['name']
        channels = []
        for ch in data.get('channels') or []:
            streams = [x.get('url') for x in (ch.get('streams') or []) if x.get('url')]
            name = (ch.get('name') or '').strip()
            if not streams or not name:
                continue
            channels.append({'id': 'tim_%s' % re.sub(r'\W+', '_', name.lower()), 'title': name,
                             'group': genres.get(ch.get('genre')) or 'Channels', 'source': 'TimStreams',
                             'thumbnail': ch.get('logo') or '', 'stream_url': streams[0], 'alt_streams': streams[1:4]})
        if channels:
            _cache.set('timstreams_channels', channels, 6 * 3600)
            xbmc.log('[Starfleet] TimStreams: %d channels' % len(channels), xbmc.LOGINFO)
            return channels
    return []


_CDN_COUNTRIES = {
    'us': 'USA', 'ca': 'Canada', 'uk': 'United Kingdom', 'gb': 'United Kingdom', 'au': 'Australia', 'nz': 'New Zealand',
    'ie': 'Ireland', 'de': 'Germany', 'fr': 'France', 'es': 'Spain', 'it': 'Italy', 'pt': 'Portugal', 'nl': 'Netherlands',
    'be': 'Belgium', 'br': 'Brazil', 'ar': 'Argentina', 'mx': 'Mexico', 'tr': 'Turkey', 'pl': 'Poland', 'ro': 'Romania',
    'gr': 'Greece', 'se': 'Sweden', 'no': 'Norway', 'dk': 'Denmark', 'fi': 'Finland', 'rs': 'Serbia', 'hr': 'Croatia',
    'za': 'South Africa', 'in': 'India', 'pk': 'Pakistan', 'ae': 'Arab World', 'sa': 'Arab World', 'qa': 'Arab World',
}


def get_cdnlive_channels():
    """~400 live sports and TV channels grouped by country. Each stream is a player page that Starfleet Resolver turns into the
    signed playlist when it is opened."""
    cached = _cache.get('cdnlive_channels')
    if cached is not None:
        return cached
    for base in ('https://api.cdnlivetv.tv', 'https://api.cdnlivetv.is'):
        try:
            r = _sess().get(base + '/api/v1/channels/?user=cdnlivetv&plan=free', timeout=12, headers={'Accept': 'application/json'})
            if r.status_code != 200:
                continue
            data = r.json()
        except Exception as e:
            xbmc.log('[Starfleet] CDN Live channels (%s): %s' % (base, e), xbmc.LOGWARNING)
            continue
        channels = []
        for ch in data.get('channels') or []:
            url = ch.get('url') or ''
            name = (ch.get('name') or '').strip().lstrip(':').strip()
            if not url or not name or (ch.get('status') or 'online') != 'online':
                continue
            code = (ch.get('code') or '').lower()
            channels.append({'id': 'cdn_%s_%s' % (code, re.sub(r'\W+', '_', name.lower())), 'title': name,
                             'group': _CDN_COUNTRIES.get(code) or (code.upper() if code else 'More channels'),
                             'source': 'CDN Live', 'thumbnail': ch.get('image') or '', 'stream_url': url, 'alt_streams': []})
        if channels:
            _cache.set('cdnlive_channels', channels, 3 * 3600)
            xbmc.log('[Starfleet] CDN Live: %d channels' % len(channels), xbmc.LOGINFO)
            return channels
    return []


# ── Pluto TV ──────────────────────────────────────────────────────────────────

def _get_pluto_cid():
    cached = _cache.get('pluto_cid')
    if cached:
        return cached
    cid = str(uuid.uuid4())
    _cache.set('pluto_cid', cid, 365 * 24 * 3600)
    return cid


PLUTO_CHANNELS_URL = 'https://api.pluto.tv/v2/channels.json'


def _boot_pluto():
    """
    Fetch Pluto boot response to obtain JWT session token.
    Returns (jwt, []) — channel list is now fetched separately.
    Caches JWT independently.
    """
    cid = _get_pluto_cid()
    try:
        r = _sess().get(PLUTO_BOOT.format(cid=cid), timeout=12)
        r.raise_for_status()
        data = r.json()

        jwt = (data.get('sessionToken') or
               data.get('stitcherParams', {}).get('jwt', ''))
        if jwt:
            _cache.set('pluto_jwt', jwt, 20 * 3600)
        return jwt, []
    except Exception as e:
        xbmc.log('[Starfleet] Pluto boot error: %s' % e, xbmc.LOGERROR)
        return None, []


def _fetch_pluto_channel_list():
    """
    Fetch the Pluto TV channel list from the v2 JSON API.
    Returns list of channel dicts or [] on failure.
    The boot EPG field now only returns the current/starting channel;
    the dedicated channel list endpoint returns all ~200 channels.
    """
    try:
        r = _sess().get(PLUTO_CHANNELS_URL, timeout=12)
        r.raise_for_status()
        raw = r.json()
        meta = []
        for ch in raw:
            ch_id = ch.get('_id') or ch.get('id', '')
            name  = ch.get('name') or ch.get('title', '')
            if not ch_id or not name:
                continue
            # Logo: v2 API uses featuredImage or thumbnail dict
            logo = (
                (ch.get('featuredImage') or {}).get('path', '') or
                (ch.get('thumbnail') or {}).get('path', '') or
                ''
            )
            group = ch.get('category') or ch.get('genre', 'General')
            meta.append({
                'id':        ch_id,
                'title':     name,
                'group':     group,
                'thumbnail': logo,
                'source':    'Pluto TV',
            })
        xbmc.log('[Starfleet] Pluto: %d channels from v2 API' % len(meta), xbmc.LOGINFO)
        return meta
    except Exception as e:
        xbmc.log('[Starfleet] Pluto channel list error: %s' % e, xbmc.LOGERROR)
        return []


def get_pluto_channels():
    """
    Return Pluto channel metadata. Stream URLs built at play time using
    current JWT (not baked into cache), so stale JWT only breaks playback
    not the channel listing.
    """
    meta = _cache.get('pluto_meta')
    if meta is None:
        meta = _fetch_pluto_channel_list()
        if not meta:
            return []
        _cache.set('pluto_meta', meta, 6 * 3600)

    # Attach stream URLs using current (possibly cached) JWT
    cid = _get_pluto_cid()
    jwt = _cache.get('pluto_jwt')
    if not jwt:
        jwt, _ = _boot_pluto()

    channels = []
    for ch in meta:
        stream = (PLUTO_STITCH.format(ch_id=ch['id'], cid=cid, jwt=jwt or '') + _pluto_auth(jwt)) if jwt else ''
        channels.append(dict(ch, stream_url=stream))
    return channels


def _pluto_auth(jwt):
    """The stitcher's master playlist carries the JWT in its query, but the variant playlists and segments it
    lists do not - they answer 401 'JWT verification fails' unless the token also arrives as a bearer header
    (verified live). Kodi's pipe-header syntax sends it with every request of the stream."""
    return ('|Authorization=Bearer%%20%s' % jwt) if jwt else ''


def get_pluto_stream(channel_id):
    """Build a fresh Pluto stream URL — called at play time."""
    cid = _get_pluto_cid()
    jwt = _cache.get('pluto_jwt')
    if not jwt:
        jwt, _ = _boot_pluto()
    if not jwt:
        return None
    return PLUTO_STITCH.format(ch_id=channel_id, cid=cid, jwt=jwt) + _pluto_auth(jwt)


def refresh_pluto():
    _cache.delete(['pluto_jwt', 'pluto_meta', 'pluto_cid'])
    return get_pluto_channels()


# ── OnHockey.tv Live Channels (NHL Network + other hockey TV) ────────────────

_ONHOCKEY_BASE = 'https://onhockey.tv'

# Paths to try for the live-channels section of the site
_ONHOCKEY_LIVE_PATHS = ['/nhl-network', '/live', '/channels', '/live-tv', '/network']

# Regex: find offsite stream/embed links on an onhockey.tv live channel page
_RE_OHK_IFRAME = re.compile(
    r'<iframe[^>]+src="(https?://(?!onhockey\.tv)[^"]{10,300})"',
    re.IGNORECASE
)
_RE_OHK_STREAM = re.compile(
    r'(?:src|href|file|source)\s*[:=]\s*["\']?(https?://[^"\'>\s]{15,300}\.m3u8[^"\'>\s]*)',
    re.IGNORECASE
)
_RE_OHK_CHAN_LINK = re.compile(
    r'<a[^>]+href="(https?://onhockey\.tv/([^"#\s]{3,80}))"[^>]*>\s*([^<]{3,80}?)\s*</a>',
    re.IGNORECASE
)

_LIVE_CHAN_SKIP = {
    'home', 'schedule', 'scores', 'standings', 'news', 'about', 'contact',
    'privacy', 'faq', 'login', 'register', 'reddit', 'discord', 'nhl', 'ahl',
}


def _onhockey_scrape_stream(page_url):
    """Fetch an onhockey.tv channel page and return the first usable stream URL."""
    try:
        r = requests.get(page_url, timeout=12, headers={
            'User-Agent': HEADERS['User-Agent'],
            'Referer': _ONHOCKEY_BASE + '/',
        })
        if r.status_code >= 400:
            return None
        html = r.text
    except Exception:
        return None

    # Priority 1: direct HLS .m3u8 in JS/JSON
    m = _RE_OHK_STREAM.search(html)
    if m:
        return m.group(1).strip()

    # Priority 2: iframe src (player embed)
    m = _RE_OHK_IFRAME.search(html)
    if m:
        return m.group(1).strip()

    return None


def get_onhockey_live_channels():
    """
    Scrape onhockey.tv for live TV channel streams (NHL Network, etc.).
    Returns list of channel dicts compatible with the unified live TV system.
    """
    ck = 'onhockey_live_ch'
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    channels = []

    # Strategy 1: try dedicated live-TV section paths
    html = None
    for path in _ONHOCKEY_LIVE_PATHS:
        try:
            r = requests.get(_ONHOCKEY_BASE + path, timeout=10, headers={
                'User-Agent': HEADERS['User-Agent'],
                'Referer': 'https://www.google.com/',
            })
            if r.status_code < 400 and len(r.text) > 500:
                html = r.text
                break
        except Exception:
            pass

    if html:
        # Collect all internal channel links from the live page
        seen = set()
        for m in _RE_OHK_CHAN_LINK.finditer(html):
            href, slug, label = m.group(1).strip(), m.group(2).strip('/'), m.group(3).strip()
            if not label or slug.split('/')[0].lower() in _LIVE_CHAN_SKIP:
                continue
            if href in seen:
                continue
            seen.add(href)
            stream = _onhockey_scrape_stream(href)
            if stream:
                channels.append({
                    'id':         'onhockey_' + re.sub(r'\W+', '_', slug),
                    'title':      label,
                    'group':      'Hockey',
                    'source':     'OnHockey.tv',
                    'thumbnail':  '',
                    'stream_url': stream,
                })

    # Strategy 2: always try the NHL Network page directly if not already found
    already_have_nhl_net = any(
        c['title'].lower().replace(' ', '') in {'nhlnetwork', 'nhlnet'}
        for c in channels
    )
    if not already_have_nhl_net:
        # Try onhockey.tv's dedicated NHL Network paths first
        # (the four pages are independent, so they are fetched together, first hit in order wins)
        from concurrent.futures import ThreadPoolExecutor as _TPE
        _paths = ('/nhl-network', '/nhlnetwork', '/nhl-network-live', '/channels/nhl-network')
        with _TPE(max_workers=len(_paths)) as _pool:
            _streams = list(_pool.map(lambda p: _onhockey_scrape_stream(_ONHOCKEY_BASE + p), _paths))
        for stream in _streams:
            if stream:
                channels.append({
                    'id':         'onhockey_nhl_network',
                    'title':      'NHL Network',
                    'group':      'Hockey',
                    'source':     'OnHockey.tv',
                    'thumbnail':  'https://upload.wikimedia.org/wikipedia/en/thumb/1/1f/NHL_Network_logo.svg/200px-NHL_Network_logo.svg.png',
                    'stream_url': stream,
                })
                break
        # onhockey.tv's own pages now gate the real player behind a nested
        # same-domain iframe (welcome.html / daddylive.php?channel=663) that a
        # single-page regex scrape can't follow — confirmed live: neither the
        # dedicated NHL Network page nor the old daddylive-wrapper page expose
        # an .m3u8 or cross-domain iframe src anymore. Resolve directly via the
        # same daddylive.mov channel-id resolver used elsewhere (tvnow247 has
        # already confirmed id 663 = "NHL Network USA" on that source) instead
        # of depending on onhockey.tv's fragile wrapper page.
        if not any(c['id'] == 'onhockey_nhl_network' for c in channels):
            try:
                from starfleetscrapers.sports import sports_sources as _ss
                fallback = _ss.slap_nhl_network_url() or _ss._dlchan_stream_url('663', channel_name='NHL Network USA')
            except Exception:
                fallback = None
            if fallback:
                channels.append({
                    'id':         'onhockey_nhl_network',
                    'title':      'NHL Network',
                    'group':      'Hockey',
                    'source':     'DaddyLive',
                    'thumbnail':  'https://upload.wikimedia.org/wikipedia/en/thumb/1/1f/NHL_Network_logo.svg/200px-NHL_Network_logo.svg.png',
                    'stream_url': fallback,
                })

    xbmc.log('[Starfleet] OnHockey.tv live channels: %d' % len(channels), xbmc.LOGINFO)
    _cache.set(ck, channels, 30 * 60)
    return channels


# ── Radio-Canada / ICI Tou.tv Live Channels ──────────────────────────────────

# Official Akamaized HLS streams for Radio-Canada's free OTA channels.
# ICI Tele main feed moved to rcavlive-dai subdomain (iptv-org confirmed 2026).
# ICI RDI slug changed from xcanrdifr → xcanrdi.
# Noovo.ca shut down May 2026 (moved to Crave) — live stream removed.
_RCAV_BASE     = 'https://rcavlive.akamaized.net/hls/live'
_RCAV_DAI_BASE = 'https://rcavlive-dai.akamaized.net/hls/live'

_TOUTV_LIVE_CHANNELS = [
    {
        'id': 'ici-tele',
        'title': 'ICI Radio-Canada Télé',
        'group': 'Tou.tv / Radio-Canada',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/thumb/2/2a/ICI_Radio-Canada_T%C3%A9l%C3%A9.png/200px-ICI_Radio-Canada_T%C3%A9l%C3%A9.png',
        'stream_url': _RCAV_DAI_BASE + '/696614/cancbftprem/master.m3u8',
    },
    {
        'id': 'ici-rdi',
        'title': 'ICI RDI',
        'group': 'Tou.tv / Radio-Canada',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/thumb/5/55/Logo_ICIRDI.png/200px-Logo_ICIRDI.png',
        'stream_url': _RCAV_DAI_BASE + '/704025/xcanrdi/master.m3u8',
    },
    {
        'id': 'ici-tele-reg-mtl',
        'title': 'ICI Télé (Montréal)',
        'group': 'Tou.tv / Radio-Canada',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/thumb/2/2a/ICI_Radio-Canada_T%C3%A9l%C3%A9.png/200px-ICI_Radio-Canada_T%C3%A9l%C3%A9.png',
        'stream_url': 'https://amdici.akamaized.net/hls/live/873426/ICI-Live-Stream/master.m3u8',
    },
    {
        'id': 'ici-tele-reg-qc',
        'title': 'ICI Télé (Québec régional)',
        'group': 'Tou.tv / Radio-Canada',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/thumb/2/2a/ICI_Radio-Canada_T%C3%A9l%C3%A9.png/200px-ICI_Radio-Canada_T%C3%A9l%C3%A9.png',
        'stream_url': _RCAV_BASE + '/664045/cancbvt/master.m3u8',      # CBVT Québec City (the old 704052 feed now answers 403)
    },
]


def get_toutv_live_channels():
    """Return Radio-Canada / ICI Tou.tv live channel list (static HLS streams)."""
    results = []
    for ch in _TOUTV_LIVE_CHANNELS:
        results.append(dict(ch, source='Tou.tv'))
    return results


# ── Free Worldwide News & Channels ───────────────────────────────────────────

_NEWS_CHANNELS = [
    # ── Global News ──────────────────────────────────────────────────────────
    {
        'id': 'aljazeera-en', 'title': 'Al Jazeera English', 'group': 'News',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/en/thumb/f/f2/AJE_Logo.svg/200px-AJE_Logo.svg.png',
        'stream_url': 'https://live-hls-apps-aje-fa.getaj.net/AJE/index.m3u8',
    },
    {
        'id': 'france24-en', 'title': 'France 24 English', 'group': 'News',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/thumb/b/b8/France_24_logo.svg/200px-France_24_logo.svg.png',
        'stream_url': 'https://live.france24.com/hls/live/2037218-b/F24_EN_HI_HLS/master_5000.m3u8',
    },
    {
        'id': 'dw-news', 'title': 'DW News (English)', 'group': 'News',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/thumb/7/75/Deutsche_Welle_symbol_2012.svg/200px-Deutsche_Welle_symbol_2012.svg.png',
        'stream_url': 'https://amg01644-amg01644c1-amgplt0343.playout.now3.amagi.tv/ts-eu-w1-n2/playlist/amg01644-amg01644c1-amgplt0343/playlist.m3u8',
    },
    {
        'id': 'france24-fr', 'title': 'France 24 Français', 'group': 'News',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/thumb/b/b8/France_24_logo.svg/200px-France_24_logo.svg.png',
        'stream_url': 'https://live.france24.com/hls/live/2037179-b/F24_FR_HI_HLS/master_5000.m3u8',
    },
    {
        'id': 'france24-ar', 'title': 'France 24 Arabic', 'group': 'News',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/thumb/b/b8/France_24_logo.svg/200px-France_24_logo.svg.png',
        'stream_url': 'https://live.france24.com/hls/live/2037222-b/F24_AR_HI_HLS/master_5000.m3u8',
    },
    {
        'id': 'dw-arabic', 'title': 'DW Arabic', 'group': 'News',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/thumb/7/75/Deutsche_Welle_symbol_2012.svg/200px-Deutsche_Welle_symbol_2012.svg.png',
        'stream_url': 'https://dwamdstream103.akamaized.net/hls/live/2015526/dwstream103/master.m3u8',
    },
    {
        'id': 'dw-spanish', 'title': 'DW Español', 'group': 'News',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/thumb/7/75/Deutsche_Welle_symbol_2012.svg/200px-Deutsche_Welle_symbol_2012.svg.png',
        'stream_url': 'https://dwamdstream104.akamaized.net/hls/live/2015530/dwstream104/master.m3u8',
    },
    {
        'id': 'cgtn-en', 'title': 'CGTN (China Global TV)', 'group': 'News',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/thumb/b/b3/CGTN_logo_2016.svg/200px-CGTN_logo_2016.svg.png',
        'stream_url': 'https://amg00405-rakutentv-cgtn-rakuten-i9tar.amagi.tv/master.m3u8',
    },
    {
        'id': 'euronews-en', 'title': 'Euronews English', 'group': 'News',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/0/0e/Euronews_logo.svg',
        'stream_url': 'https://dash4.antik.sk/live/test_euronews/playlist.m3u8',
    },
    # ── Free Entertainment ────────────────────────────────────────────────────
    {
        'id': 'bbc-reel', 'title': 'BBC World Service Radio', 'group': 'Radio/Audio',
        'thumbnail': 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/41/BBC_Logo_2021.svg/200px-BBC_Logo_2021.svg.png',
        'stream_url': 'https://stream.live.vc.bbcmedia.co.uk/bbc_world_service',
    },
]


def get_news_channels():
    """Return hardcoded list of free worldwide news and entertainment channels."""
    results = []
    for ch in _NEWS_CHANNELS:
        results.append(dict(ch, source='Free News'))
    return results


def prewarm_news():
    pass  # static list, no prewarm needed


# ── Free Live Sports (watch.freelivesports.tv) ───────────────────────────────
#
# Investigated live 2026-08-19 per direct request. The site's own Angular
# bundle (unreel-fullscreen) defines a "urfsLiveChannels" service with a
# single real endpoint that returns EVERYTHING at once - no separate EPG
# call, no per-channel session/auth step:
#
#   GET https://ga-prod-api.powr.tv/v2/sites/<siteUid>/live-channels
#
# Confirmed live: 124 real, legitimate FAST channels (Red Bull TV, NASCAR,
# PFL, Sports Illustrated TV, Eurovision Sport, Big 12 Network, beIN Sports
# Xtra, etc.) - not the movie/VOD "channel" categories the site's separate
# on-demand catalogue uses (a different, unrelated endpoint that was
# investigated and correctly ruled out first). Each entry already carries:
#   - a direct, pre-resolved Amagi CDN .m3u8 URL (no session/token step -
#     confirmed live it's playable as-is; a 403 hit while testing from this
#     dev environment was a genuine CloudFront country geo-block, not a
#     URL-construction problem - the bracketed ad-tracking placeholders
#     ([US_PRIVACY], [GDPR], [DEVICE_ID], etc.) are inert if left literal,
#     only used server-side for Amagi's own ad analytics)
#   - a real embedded EPG schedule (epg.entries: title/description/start/
#     stop), unlike every other source in this file, which either has no
#     EPG at all or points at a separate third-party XMLTV feed URL.
_FLS_SITE_ID = '664f9cfe1eb297fa1d65b5bb'
_FLS_API = 'https://ga-prod-api.powr.tv/v2/sites/%s/live-channels' % _FLS_SITE_ID


def _fls_fetch_raw():
    ck = 'free_live_sports_raw_v1'
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        r = requests.get(_FLS_API, headers={
            'User-Agent': ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
                            '(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'),
            'Accept': 'application/json',
        }, timeout=20)
        r.raise_for_status()
        data = r.json()
    except Exception as e:
        xbmc.log('[Starfleet/LiveTV] Free Live Sports fetch error: %s' % e, xbmc.LOGWARNING)
        return []
    _cache.set(ck, data, 24 * 3600 if data else 10 * 60)
    return data


def get_free_live_sports_channels():
    """Real, legitimate FAST channels from watch.freelivesports.tv — see
    module comment above for the investigation. Each returned dict adds an
    'epg_entries' key (raw title/description/start/stop list) on top of the
    usual id/title/group/thumbnail/stream_url shape, consumed by
    pvr_export.py to build a real XMLTV guide from this source's own
    embedded schedule instead of a third-party feed."""
    raw = _fls_fetch_raw()
    results = []
    for ch in raw:
        if ch.get('status') != 'live' or ch.get('accessType') != 'public':
            continue
        url = ch.get('url') or ''
        if not url:
            continue
        thumbs = ch.get('thumbnails') or {}
        thumb = thumbs.get('landscape') or thumbs.get('square') or ch.get('thumbnail') or ''
        results.append({
            'id':          'fls-%s' % ch.get('_id', ''),
            'title':       ch.get('name', 'Unknown Channel'),
            'group':       'Free Live Sports',
            'thumbnail':   thumb,
            'stream_url':  url,
            'source':      'Free Live Sports',
            'epg_entries': (ch.get('epg') or {}).get('entries') or [],
        })
    return results


def prewarm_free_live_sports():
    _fls_fetch_raw()


# ── DLHD / DaddyLive (dlstreams.st) — 24/7 channel directory ─────────────────
#
# Investigated live 2026-08-20 per direct request. dlstreams.st is
# DaddyLive/DLHD's current domain (confirmed by its own site branding and
# public API docs at dlstreams.st/api.php) — the same DaddyLive family
# this addon already has extensive scraper support for elsewhere, just a
# different current mirror. Its clean JSON API (daddyapi.php) needs a
# real, individually-registered API key ("Contact support to get your API
# key") this addon doesn't have and won't fabricate/bypass — so this
# scrapes the site's own public /24-7-channels.php directory page
# instead, same no-key-needed approach already used for every other
# scraped source in this file. Confirmed live: ~900 real channels (ABC
# USA, AMC USA, Animal Planet, international sports channels, and several
# reality-TV live camera feeds — e.g. Big Brother's own 4 individual
# camera angles plus a quadview, all real and currently airing).
#
# Playback: each channel's /watch.php?id=<N> page is just a redirect
# wrapper whose own iframe points at /stream/stream-<N>.php — the exact
# same page structure already reverse-engineered for sports_sources.py's
# livetv902/903 fix (dlstreams.st turned out to be the shared backend
# both places route through): the real master m3u8 is embedded as a plain
# base64 string passed to Clappr.Player({source: window.atob('...')}),
# no JS execution needed. Reuses that fix's own resolver function instead
# of duplicating it, since it's the identical mechanism.
# UPDATE 2026-09-05 — dlstreams.st now 301-redirects everything to dlive.sx
# (confirmed live via a direct raw-socket request bypassing this machine's
# own DNS, which couldn't resolve dlstreams.st at all while dns.google
# could — and independently confirmed by direct user report of the same
# domain). `requests` follows the redirect fine on its own, so this alone
# was likely never a hard failure, but every Referer this file builds from
# the literal `_DLSTREAMS_BASE` string (the channel-list fetch, the
# stream-<id>.php iframe fetch) was still carrying the OLD pre-redirect
# domain instead of the site's actual current one — pointing this at the
# real current domain directly removes that mismatch instead of relying on
# a redirect + a stale Referer to somehow still work. Channel-list scrape
# re-verified live against the new domain directly: real 899-channel
# listing, same page structure, same regex match.
_DLSTREAMS_BASE = 'https://dlive.sx'
_RE_DLSTREAMS_CARD = re.compile(
    r'href="/watch\.php\?id=(\d+)"[^>]*>\s*<div class="card__title">([^<]+)</div>'
)
# the directory page as the site builds it now: each card names its channel (data-title / card__title) and prints "ID: <n>"
_RE_DLSTREAMS_CARD2 = re.compile(
    r'<a\s+class="card"[^>]*?href="(?P<href>[^"]+)"[^>]*?data-title="(?P<attr>[^"]*)"[^>]*>'
    r'.*?<div\s+class="card__title">\s*(?P<title>.*?)\s*</div>'
    r'.*?ID:\s*(?P<id>\d+)\s*</div>'
    r'.*?</a>', re.IGNORECASE | re.DOTALL
)


def _dl_base():
    """The site's address right now (the domain moves; the seed answers with a redirect to it)."""
    try:
        from starfleetscrapers.sports import dlhd_players as _dlp
        return _dlp.active_base(_DLSTREAMS_BASE)
    except Exception:
        return _DLSTREAMS_BASE


def _dlstreams_parse(html_text):
    """[(id, name)] from the directory page, whichever of its two layouts it has."""
    out, seen = [], set()
    for m in _RE_DLSTREAMS_CARD2.finditer(html_text):
        cid = m.group('id')
        name = _html_mod.unescape(m.group('title') or m.group('attr')).strip()
        if name.startswith(cid) and name[len(cid):len(cid) + 1].isalpha():
            name = name[len(cid):].strip()         # the number the site prints in front of the name
        if name and cid not in seen:
            seen.add(cid)
            out.append((cid, name))
    if out:
        return out
    return [(cid, _html_mod.unescape(name).strip()) for cid, name in _RE_DLSTREAMS_CARD.findall(html_text)]


def _host_up(host, port=443):
    """Does this host accept a connection? Kept 10 minutes when it does and 3 when it does not, so a dead site costs one short check
    instead of a timeout on every click (and comes back by itself)."""
    ck = 'host_up_%s' % host
    got = _cache.get(ck)
    if got is not None:
        return bool(got)
    import socket
    ok = False
    try:
        socket.create_connection((host, port), timeout=4).close()
        ok = True
    except socket.gaierror:                    # the local resolver cannot find it: ask a public one
        try:
            from starfleetscrapers.core import dns_fallback as _dnsf
            ip = _dnsf._doh_lookup(host)
            if ip:
                socket.create_connection((ip, port), timeout=4).close()
                ok = True
        except Exception:
            pass
    except Exception:
        pass
    _cache.set(ck, ok, 600 if ok else 180)
    return ok


def source_up(key):
    """False while the site behind a Live TV source cannot be reached, so the menu can leave it out (and shows it again as soon as
    the site answers). DLHD, its Big Brother section and the tvnow247 catalogue all play through the DLHD players or tvnow247's own
    resolve API: they work when either answers."""
    if key in ('dlstreams', 'bigbrother', 'tvnow', 'daddylive'):
        return _host_up(_dl_base().split('://', 1)[-1]) or _host_up('chat.cfbu247.sbs')
    return True


def _dlstreams_fallback_channels():
    """DLHD's own site is unreachable: tvnow247's catalogue uses the same channel numbers, so list those
    (kept only 10 minutes, so the real directory takes over as soon as the site answers)."""
    ck = 'dlstreams_fallback_v1'
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    if not source_up('dlstreams'):
        return []                                  # nothing could play them
    try:
        chans = [{'id': str(c['id']), 'name': c['title']} for c in get_tvnow_channels()
                 if str(c.get('id', '')).isdigit()]
    except Exception:
        chans = []
    _cache.set(ck, chans, 10 * 60)
    return chans


def _dlstreams_channels_raw():
    ck = 'dlstreams_channels_v2'
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    # Same 3-minute "host is down" marker sports_sources'
    # _livetv902_resolve_dlstreams() sets/reads (shared on-disk cache key) —
    # a dead dlive.sx used to cost every caller of this function a full 20s
    # timeout, every time, since a failed fetch here isn't cached.
    _base = _dl_base()
    _dl_host = _base.split('://', 1)[-1]
    if _cache.get('host_down_%s' % _dl_host):
        return _dlstreams_fallback_channels()
    try:
        _hdr = {'User-Agent': ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
                               '(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'), 'Referer': _base + '/'}
        # the page is requested with POST now (a plain GET answers with the shell only); GET stays as the fallback
        html_text = requests.post(_base + '/24-7-channels.php', headers=_hdr, timeout=(5, 20)).text
        if not _dlstreams_parse(html_text):
            html_text = requests.get(_base + '/24-7-channels.php', headers=_hdr, timeout=(5, 20)).text
    except requests.exceptions.ConnectionError as e:
        _cache.set('host_down_%s' % _dl_host, True, 180)
        xbmc.log('[Starfleet/LiveTV] dlstreams channels fetch error (host marked down): %s' % e, xbmc.LOGWARNING)
        return _dlstreams_fallback_channels()
    except Exception as e:
        xbmc.log('[Starfleet/LiveTV] dlstreams channels fetch error: %s' % e, xbmc.LOGWARNING)
        return _dlstreams_fallback_channels()
    channels = [{'id': cid, 'name': name} for cid, name in _dlstreams_parse(html_text)]
    _cache.set(ck, channels, 24 * 3600 if channels else 10 * 60)
    return channels


def get_dlstreams_channels():
    """Return the dlstreams.st 24/7 channel directory in the usual
    id/title/group/thumbnail/stream_url shape. stream_url is a lazy-resolve
    marker ('dlstreams:<id>') resolved at play time by
    resolve_dlstreams_channel() below — pre-resolving all ~900 channels
    up front just to build a menu listing would be far too slow."""
    if not source_up('dlstreams'):
        return []                                  # a directory nobody can play from is not worth listing
    raw = _dlstreams_channels_raw()
    return [{
        'id':         'dlstreams-%s' % ch['id'],
        'title':      ch['name'],
        'group':      'DLHD 24/7 Channels',
        'thumbnail':  '',
        'stream_url': 'dlstreams:%s' % ch['id'],
        'source':     'DLHD',
    } for ch in raw]


def resolve_dlstreams_channel(channel_id):
    """Resolve one dlstreams.st channel id to a real playable URL at play
    time — see this module's own comment above for the chain reused here
    (/stream/stream-<id>.php's embedded base64 m3u8, no JS execution)."""
    from starfleetscrapers.sports import sports_sources as _ss
    iframe_url = '%s/stream/stream-%s.php' % (_dl_base(), channel_id)
    return _ss._livetv902_resolve_dlstreams(iframe_url)


def prewarm_dlstreams():
    _dlstreams_channels_raw()


# Big Brother's own live camera feeds are real entries inside the flat
# ~900-channel DLHD directory above (confirmed live: "Big Brother 28 Live
# Feeds Cam 1-4" + "Quadview") but that directory has zero sub-grouping in
# its own UI (list_live_dlstreams renders every channel in one flat, sorted
# list) — added per direct request for a dedicated, easy-to-find Live TV
# section instead of scrolling ~900 channels to find these 5. Reuses the
# exact same channel ids/resolve path (resolve_dlstreams_channel) as the
# main DLHD directory, just pre-filtered — no new resolver needed.
_RE_BIGBROTHER = re.compile(r'big\s*brother', re.IGNORECASE)


def get_bigbrother_channels():
    return [ch for ch in get_dlstreams_channels() if _RE_BIGBROTHER.search(ch['title'])]


# ── DaddyLive's own "regular TV" channel directory (daddylive.li/api/channels) ─
#
# Country-grouped "Live Channels by Country" used to come entirely from
# daddylive_channels.json — a weekly, ~1200-channel, Playwright-assisted
# scraper run on a separate PC (scraper_daddylive_channels.py). Real gap
# found live 2026-09-05: some channels' own embed pages have moved to a
# JS-obfuscated wrapper the scraper's plain-HTTP chain can't crack anymore,
# and Kodi addons can't bundle/run Playwright at all (no room for a
# downloaded Chromium binary, no native browser automation on the FireTV/
# Android boxes this addon actually runs on) — so a scraper run hitting
# enough of these now produces an empty catalogue outright, and even a
# healthy run's baked-in playable_url only reflects a moment the scraper
# happened to run, already stale by the time anyone clicks play (same
# staleness class documented in router.py's own play_daddylive_catalog()).
#
# Per direct request: this only needs the CHANNEL LIST (name + guessed
# country) to build the browsable menu instantly, live, no scraper
# involved — router.play_daddylive_catalog() already does the actual
# fresh-resolve-at-play-time step, by fuzzy-matching this same title
# against the dlstreams.st/dlive.sx 24/7 directory this file already
# scrapes and resolves correctly (confirmed live: a channel whose own
# daddylive.li embed chain is now broken, "#Vamos Spain", still resolves
# to a real playable stream this way, since dlive.sx's OWN copy of it
# never went through daddylive.li's broken chain at all).
_DL_CHANNELS_URL = 'https://daddylive.li/api/channels'
_DL_CHANNELS_HEADERS = {
    'User-Agent': ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
                    '(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'),
    'Accept': 'application/json, text/plain, */*',
    'Referer': 'https://daddylive.li/',
}

# Same non-sport/adult block list as daddylive_common.py's own _ADULT_BLOCK
# (the scraper's twin of this function) — Adult already has its own,
# separate, dedicated scrapers in this addon; this catalogue is Live TV
# only.
_RE_DL_ADULT = re.compile(
    r'pornhub|xvideos|xhamster|beeg|motherless|naughtyamerica|sexvid|tnaflix|'
    r'realitykings|drtuber|youporn|tube8|pornhd|porntrex|bangbros|brazzers|'
    r'spankbang|eporner|18\+|xxx|adult', re.IGNORECASE)

_DL_COUNTRY_HINTS = [
    (r'\bUSA\b|\bUS\b|\bNY\b', 'US'), (r'\bUK\b|\bBritain\b', 'GB'),
    (r'\bCanada\b|\bCA\b', 'CA'), (r'\bSpain\b|\bES\b', 'ES'),
    (r'\bFrance\b|\bFR\b', 'FR'), (r'\bGermany\b|\bDE\b|\bDeutsch', 'DE'),
    (r'\bItaly\b|\bItalia\b', 'IT'), (r'\bPortugal\b', 'PT'),
    (r'\bBrazil\b|\bBrasil\b', 'BR'), (r'\bMexico\b|\bMX\b', 'MX'),
    (r'\bTurkey\b', 'TR'), (r'\bPoland\b', 'PL'), (r'\bRomania\b', 'RO'),
    (r'\bSerbia\b', 'RS'), (r'\bCroatia\b', 'HR'), (r'\bGreece\b', 'GR'),
    (r'\bNetherlands\b|\bNL\b', 'NL'), (r'\bAustralia\b|\bAU\b', 'AU'),
    (r'\bIndia\b', 'IN'), (r'\bIsrael\b', 'IL'), (r'\bUAE\b', 'AE'),
    (r'\bUkraine\b', 'UA'), (r'\bDenmark\b', 'DK'), (r'\bSweden\b', 'SE'),
    (r'\bNorway\b', 'NO'), (r'\bArgentina\b', 'AR'),
]


def _dl_guess_country(name):
    for pat, code in _DL_COUNTRY_HINTS:
        if re.search(pat, name or '', re.IGNORECASE):
            return code
    return 'Other'


def get_daddylive_channels_by_country():
    """Live daddylive.li channel directory, grouped by guessed country —
    name only, no per-channel resolve (that happens lazily at play time
    via router.play_daddylive_catalog's title-match against dlive.sx).
    Cached 24h, same convention as the DLHD 24/7 directory above."""
    ck = 'dl_channels_by_country_v1'
    if not source_up('daddylive'):
        return {}
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    try:
        from starfleetscrapers.core import dns_fallback as _dnsf
        r = _dnsf.get(_DL_CHANNELS_URL, timeout=15, headers=_DL_CHANNELS_HEADERS)
        rows = r.json()
    except Exception as e:
        xbmc.log('[Starfleet/LiveTV] daddylive channels fetch error: %s' % e, xbmc.LOGWARNING)
        rows = []
    grouped = {}
    if isinstance(rows, list):
        for row in rows:
            name = (row.get('channel_name') or '').strip()
            if not name or _RE_DL_ADULT.search(name.lower().replace(' ', '')):
                continue
            grouped.setdefault(_dl_guess_country(name), []).append({
                'title': name, 'logo': '', 'playable_url': '',
            })
    _cache.set(ck, grouped, 24 * 3600 if grouped else 600)
    return grouped


# ── USTVNow — U.S. channel EPG + live stream API ─────────────────────────────
#
# Investigated live 2026-08-20 per direct request. ustvnow.com/tvguide's own
# jQuery page calls a plain, unauthenticated POST endpoint (ustvnow.com/
# epg2) with {dt, tz, tz2, offset, limit} — offset paginates 20 channels
# at a time (limit affects something else, not channel count — confirmed
# live by paginating offset 0/20/40/... instead and seeing different
# channels each time). Confirmed live: 141 real US channels (ABC, NBC,
# CBS, Fox News, A&E, TLC, BYU TV, and many smaller niche/international
# ones), each with a real day's schedule (start/end times, title,
# description) AND a direct playable .m3u8 URL per individual show slot —
# not one static per-channel URL, since this service time-shifts each
# program's own encode rather than serving one persistent live feed.
_USTVNOW_BASE = 'https://www.ustvnow.com'
_USTVNOW_TZ_OFFSET_MIN = -240  # America/New_York, EDT — see module comment


def _ustvnow_channels_raw():
    ck = 'ustvnow_channels_v1'
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    import datetime as _dt
    today = _dt.date.today().isoformat()
    req_headers = {
        'User-Agent': ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
                        '(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'),
        'Referer': _USTVNOW_BASE + '/tvguide',
        'X-Requested-With': 'XMLHttpRequest',
    }
    channels = []
    try:
        # The guide is paged 20 channels at a time (about 420 channels -> 21 requests of ~2.5s each). Pages are
        # independent, so all of them go out at once; the ones past the end come back empty.
        from concurrent.futures import ThreadPoolExecutor

        def _page(offset):
            data = {'dt': today, 'tz': 'America/New_York', 'tz2': str(_USTVNOW_TZ_OFFSET_MIN),
                    'offset': offset, 'limit': 20}
            try:
                return requests.post(_USTVNOW_BASE + '/epg2', data=data, headers=req_headers, timeout=(5, 12)).json()
            except Exception:
                return []

        offsets = list(range(0, 320, 20))
        with ThreadPoolExecutor(max_workers=len(offsets)) as pool:
            for batch in pool.map(_page, offsets):
                if batch:
                    channels.extend(batch)
        seen_links = set()                    # the guide sometimes ignores the offset and repeats page one
        channels = [c for c in channels if not (c.get('link') in seen_links or seen_links.add(c.get('link')))]
    except Exception as e:
        xbmc.log('[Starfleet/LiveTV] ustvnow channels fetch error: %s' % e, xbmc.LOGWARNING)
        if not channels:
            return []
    _cache.set(ck, channels, 3600 if channels else 600)  # 1h — "now playing" changes throughout the day
    return channels


def get_ustvnow_channels():
    """Return the USTVNow channel list in the usual shape. stream_url is a
    lazy-resolve marker ('ustvnow:<link>') resolved at play time by
    resolve_ustvnow_channel() below, since the right URL depends on
    whatever's airing at that exact moment, not whenever the list was
    built."""
    raw = _ustvnow_channels_raw()
    out = []
    for ch in raw:
        link = ch.get('link')
        if not link:
            continue
        icon = ch.get('icon') or ''
        if icon.startswith('//'):
            icon = 'https:' + icon
        elif icon.startswith('/'):
            icon = _USTVNOW_BASE + icon
        out.append({
            'id':         'ustvnow-%s' % (ch.get('id') or link),
            'title':      (ch.get('name') or '').strip(),
            'group':      'USTVNow',
            'thumbnail':  icon,
            'stream_url': 'ustvnow:%s' % link,
            'source':     'USTVNow',
        })
    return out


def resolve_ustvnow_channel(channel_link):
    """Resolve a USTVNow channel to whatever's airing right now — its EPG
    entries are per-timeslot, each with its own direct .m3u8 (see module
    comment above for why), so this picks the show whose start/end window
    contains the current time in the same fixed America/New_York offset
    the schedule itself was requested in, rather than trusting the
    playing device's own local clock/timezone."""
    import datetime as _dt
    now_str = (_dt.datetime.utcnow() + _dt.timedelta(minutes=_USTVNOW_TZ_OFFSET_MIN)).strftime('%H:%M')
    for ch in _ustvnow_channels_raw():
        if ch.get('link') != channel_link:
            continue
        shows = ch.get('shows') or []
        for show in shows:
            if show.get('start', '') <= now_str < show.get('end', '99:99'):
                return show.get('url') or None
        return shows[0].get('url') if shows else None
    return None


def prewarm_ustvnow():
    _ustvnow_channels_raw()


# ── FilmOn — free (non-paywalled) live linear channels ───────────────────────
#
# Investigated live 2026-08-20 from a real browser DevTools capture of
# filmon.com/groups/?with-special=true and filmon.com/group/<alias>. Full
# chain (no key/auth needed for any of it):
#   1. GET /groups/?with-special=true          -> 83 category groups
#   2. GET /group/<alias>                      -> each group's full channel
#      list (id, title, alias, logo, is_free, type) in one response
#   3. POST /ajax/getChannelInfo {channel_id}   -> real signed HD/SD .m3u8
#      URLs in a `streams[]` array, but ONLY once a guest session cookie
#      (ftv_token/PHPSESSID, issued by any normal filmon.com page load) is
#      attached — a fully cookieless POST returns `streams: []`.
#   4. The resulting .m3u8 itself needs a `Referer: https://www.filmon.com/`
#      header on the CDN fetch or it 403s ("Channel id does not match") —
#      confirmed live this does NOT need to be a session-bearing request,
#      just any filmon.com referer, and does NOT need matching cookies.
# Most of FilmOn's catalogue is either subscription-gated (is_free=false,
# e.g. BBC One) or actually VOD/podcast content masquerading as a channel
# (type='vod', e.g. "Expats TV") — confirmed live only 13 channels across
# all 83 groups are genuinely free AND genuinely live linear TV. Small but
# real; added as its own group same as the other sources.
_FILMON_BASE = 'https://www.filmon.com'


def _filmon_session():
    s = requests.Session()
    s.headers.update({
        'User-Agent': ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
                        '(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'),
    })
    # FilmOn's new default site is a React SPA whose /groups/ and
    # /ajax/getChannelInfo endpoints now return the SPA's HTML shell
    # instead of JSON. Their own unsupported-browser fallback still
    # serves the old server-rendered "classic" site (and its real JSON
    # AJAX endpoints) to any session carrying this cookie — confirmed
    # live, no scraping of the SPA's JS bundle needed.
    s.cookies.set('ftv_site_mode', 'classic', domain='.filmon.com')
    try:
        s.get(_FILMON_BASE + '/tvguide/', timeout=12)
    except Exception:
        pass
    return s


def _filmon_channels_raw():
    ck = 'filmon_channels_v1'
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    channels = []
    try:
        s = _filmon_session()
        groups = s.get(_FILMON_BASE + '/groups/?with-special=true',
                        headers={'X-Requested-With': 'XMLHttpRequest'}, timeout=15).json()
        # One request per group; they used to run one after another (51s measured for
        # 13 free channels), so fetch them concurrently.
        from concurrent.futures import ThreadPoolExecutor

        def _group(g):
            alias = g.get('alias')
            if not alias:
                return g, None
            try:
                return g, s.get('%s/group/%s' % (_FILMON_BASE, alias),
                                headers={'X-Requested-With': 'XMLHttpRequest'}, timeout=(5, 12)).json()
            except Exception:
                return g, None

        with ThreadPoolExecutor(max_workers=16) as pool:
            fetched = list(pool.map(_group, groups))
        seen_ids = set()
        for g, gd in fetched:
            if not gd:
                continue
            for c in gd.get('channels', []) or []:
                if not c.get('is_free') or c.get('type') != 'standard':
                    continue
                if c.get('id') in seen_ids:
                    continue
                seen_ids.add(c.get('id'))
                channels.append({
                    'id':    c.get('id'),
                    'title': c.get('title') or '',
                    'group': g.get('title') or gd.get('title') or 'FilmOn',
                    'logo':  c.get('logo') or '',
                })
    except Exception as e:
        xbmc.log('[Starfleet/LiveTV] filmon channels fetch error: %s' % e, xbmc.LOGWARNING)
    _cache.set(ck, channels, 12 * 3600 if channels else 10 * 60)
    return channels


def get_filmon_channels():
    """Return FilmOn's free live channel list in the usual shape. stream_url
    is a lazy-resolve marker ('filmon:<id>') resolved at play time by
    resolve_filmon_channel() below, since each signed .m3u8 is single-use
    and tied to the session that requested it."""
    raw = _filmon_channels_raw()
    return [{
        'id':         'filmon-%s' % ch['id'],
        'title':      ch['title'],
        'group':      ch['group'],
        'thumbnail':  ch['logo'],
        'stream_url': 'filmon:%s' % ch['id'],
        'source':     'FilmOn',
    } for ch in raw]


def resolve_filmon_channel(channel_id):
    """Resolve one FilmOn channel id to a real playable .m3u8 at play time —
    see this module's own comment above for the session+POST chain."""
    try:
        s = _filmon_session()
        r = s.post(_FILMON_BASE + '/ajax/getChannelInfo', data={'channel_id': channel_id},
                    headers={'Referer': _FILMON_BASE + '/tvguide/', 'X-Requested-With': 'XMLHttpRequest'},
                    timeout=15)
        d = r.json()
        streams = d.get('streams') or []
        if not streams:
            return None
        # prefer the 'high'/HD quality entry, fall back to whatever's first
        chosen = next((st for st in streams if st.get('quality') == 'high'), streams[0])
        url = chosen.get('url')
        if not url:
            return None
        from urllib.parse import quote as _uq
        return '%s|Referer=%s' % (url, _uq(_FILMON_BASE + '/', safe=''))
    except Exception as e:
        xbmc.log('[Starfleet/LiveTV] filmon resolve error: %s' % e, xbmc.LOGWARNING)
        return None


def prewarm_filmon():
    _filmon_channels_raw()


# ── smotru.tv — Russian/international live TV channels ───────────────────────
#
# Investigated live 2026-08-20 per direct request. Real channel directory
# split across 8 category pages (/kategorii/<slug>.html) — confirmed live,
# 239 real channels total (kids/movies/music/news/general/documentary/
# entertainment/sports). Each channel's own page (/<slug>.html) embeds one
# or more mirror iframes pointing at cdntvmedia.com/public/<name>[-hd|-N]
# .php — a SHARED backend also serving several sibling rebrand sites
# (tvix.live, televizo.live, tvline.live, etc, per its own CSP
# frame-ancestors header). That endpoint 403s a plain fetch regardless of
# Referer/Origin — the real gate turned out to be the Sec-Fetch-Dest/Mode/
# Site headers a genuine cross-site iframe load carries (confirmed live:
# adding Sec-Fetch-Dest: iframe / Sec-Fetch-Mode: navigate / Sec-Fetch-Site:
# cross-site flips the same request from 403 to 200), which then returns
# one more nested iframe whose src is a plain playerjs.php?file=<real
# .m3u8 URL> query param — no further JS execution needed.
_SMOTRU_BASE = 'https://smotru.tv'
_SMOTRU_CATEGORIES = {
    'detskie-telekanaly':      'Kids',
    'kinokanaly':              'Movies',
    'muzykalnye-telekanaly':   'Music',
    'novostnye-telekanaly':    'News',
    'obshchestvennye-telekanaly': 'General',
    'poznavatelnye-telekanaly':   'Documentary',
    'razvlekatelnye-telekanaly':  'Entertainment',
    'sportivnye-telekanaly':      'Sports',
}
_RE_SMOTRU_CARD = re.compile(
    r'href="(/[a-z0-9-]+\.html)"[^>]*>\s*<img[^>]+src="([^"]+)"[^>]+alt="([^"]+?)\s*'
    r'смотреть онлайн"',
    re.IGNORECASE
)
_RE_SMOTRU_IFRAME = re.compile(r'<iframe[^>]+src="(https://cdntvmedia\.com/[^"]+)"')
_RE_SMOTRU_FILE_PARAM = re.compile(r'[?&]file=([^"&]+)')
_RE_SMOTRU_GENERATED_FILE = re.compile(r'generatedFile\s*=\s*"([^"]+)"')
_SMOTRU_UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
              '(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36')


def _smotru_channels_raw():
    ck = 'smotru_channels_v1'
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    channels = []
    seen_slugs = set()
    # one page per category, fetched concurrently (they were fetched one by one)
    from concurrent.futures import ThreadPoolExecutor

    def _category(item):
        cat_slug, group_label = item
        try:
            html = requests.get('%s/kategorii/%s.html' % (_SMOTRU_BASE, cat_slug),
                                headers={'User-Agent': _SMOTRU_UA}, timeout=(5, 12)).text
        except Exception as e:
            xbmc.log('[Starfleet/LiveTV] smotru category fetch error (%s): %s' % (cat_slug, e), xbmc.LOGWARNING)
            return group_label, ''
        return group_label, html

    with ThreadPoolExecutor(max_workers=8) as pool:
        pages = list(pool.map(_category, _SMOTRU_CATEGORIES.items()))
    for group_label, html in pages:
        for href, img, name in _RE_SMOTRU_CARD.findall(html):
            slug = href.strip('/').rsplit('.', 1)[0]
            if slug in seen_slugs:
                continue
            seen_slugs.add(slug)
            thumb = img if img.startswith('http') else (_SMOTRU_BASE + img)
            channels.append({
                'slug': slug,
                'title': _html_mod.unescape(name).strip(),
                'group': group_label,
                'thumb': thumb,
            })
    _cache.set(ck, channels, 24 * 3600 if channels else 10 * 60)
    return channels


def get_smotru_channels():
    """Return smotru.tv's live channel directory in the usual shape.
    stream_url is a lazy-resolve marker ('smotru:<slug>') resolved at play
    time by resolve_smotru_channel() below — each mirror needs its own
    Sec-Fetch-gated fetch chain, too slow to pre-resolve ~239 channels
    up front just to build a menu listing."""
    raw = _smotru_channels_raw()
    return [{
        'id':         'smotru-%s' % ch['slug'],
        'title':      ch['title'],
        'group':      ch['group'],
        'thumbnail':  ch['thumb'],
        'stream_url': 'smotru:%s' % ch['slug'],
        'source':     'smotru.tv',
    } for ch in raw]


def _smotru_verify_and_tag(m3u8):
    try:
        v = requests.get(m3u8, headers={'User-Agent': _SMOTRU_UA, 'Referer': 'https://cdntvmedia.com/'}, timeout=10)
        if v.status_code == 200 and v.text.lstrip().startswith('#EXTM3U'):
            from urllib.parse import quote as _uq
            return '%s|User-Agent=%s&Referer=%s' % (
                m3u8, _uq(_SMOTRU_UA, safe=''), _uq('https://cdntvmedia.com/', safe=''))
    except Exception:
        pass
    return None


def resolve_smotru_channel(slug):
    """Resolve one smotru.tv channel slug to a real playable .m3u8 at play
    time — see this module's own comment above for the Sec-Fetch-gated
    cdntvmedia.com chain reused here. Two different nested-iframe shapes
    confirmed live: some resolve straight to a '?file=<url>' query param,
    others go one hop deeper to a '?ch=<id>' player page whose own inline
    JS assigns the real (escaped) URL(s) to a plain generatedFile string —
    sometimes two alternate CDN mirrors separated by literal ' or '."""
    channel_url = '%s/%s.html' % (_SMOTRU_BASE, slug)
    try:
        page_html = requests.get(channel_url, headers={'User-Agent': _SMOTRU_UA}, timeout=15).text
    except Exception as e:
        xbmc.log('[Starfleet/LiveTV] smotru page fetch error: %s' % e, xbmc.LOGWARNING)
        return None

    sec_fetch_headers = {
        'User-Agent': _SMOTRU_UA,
        'Referer': channel_url,
        'Sec-Fetch-Dest': 'iframe',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'cross-site',
    }
    from urllib.parse import unquote as _unq

    mirrors = _RE_SMOTRU_IFRAME.findall(page_html)
    for mirror_url in mirrors:
        try:
            r = requests.get(mirror_url, headers=sec_fetch_headers, timeout=10)
            if r.status_code != 200:
                continue

            file_m = _RE_SMOTRU_FILE_PARAM.search(r.text)
            if file_m:
                m3u8 = _unq(file_m.group(1))
                if m3u8.startswith('http'):
                    tagged = _smotru_verify_and_tag(m3u8)
                    if tagged:
                        return tagged
                continue

            # Some channels embed straight from ok.ru instead of cdntvmedia's
            # own delivery — reuse this addon's own already-built OK.ru
            # resolver (sports_router._resolve_okru) rather than duplicating
            # it. Rutube-embedded channels (the other third-party platform
            # seen live here) have no existing resolver anywhere in this
            # codebase yet and are left unresolved (returns None below) —
            # not worth a speculative new platform integration on top of
            # everything else this round.
            okru_m = re.search(r'<iframe[^>]+src="(https://ok\.ru/videoembed/\d+[^"]*)"', r.text)
            if okru_m:
                try:
                    from starfleetscrapers import host as _sfhost; _resolve_okru = _sfhost.func('sports_router', '_resolve_okru')
                    tagged = _resolve_okru(okru_m.group(1))
                    if tagged:
                        return tagged
                except Exception:
                    pass
                continue

            # No direct file= param — look for the nested ?ch=<id> player
            # page one hop deeper instead.
            nested_m = re.search(r'<iframe[^>]+src="(https://cdntvmedia\.com/[^"]+)"', r.text)
            if not nested_m:
                continue
            r2 = requests.get(nested_m.group(1), headers=dict(sec_fetch_headers, Referer=mirror_url), timeout=10)
            if r2.status_code != 200:
                continue
            gen_m = _RE_SMOTRU_GENERATED_FILE.search(r2.text)
            if not gen_m:
                continue
            raw = gen_m.group(1).replace('\\/', '/')
            for candidate in raw.split(' or '):
                candidate = candidate.strip()
                if candidate.startswith('http'):
                    tagged = _smotru_verify_and_tag(candidate)
                    if tagged:
                        return tagged
        except Exception:
            continue
    return None


def prewarm_smotru():
    _smotru_channels_raw()


# ── EPG helpers ───────────────────────────────────────────────────────────────

def get_epg_urls():
    """Guides come from each service's own API now (get_epg_entries), so there is no XMLTV address to hand out."""
    return {}


# ── tvnow247.top Live Channels (500+, DaddyLive channel_id scheme) ───────────
#
# tvnow247.top is a client-rendered SPA — the channel catalogue isn't in the
# HTML, it's baked into a content-hashed JS bundle (/assets/channelData-*.js)
# at build time. The exact filename changes on redeploy, so it's discovered
# fresh from the page each time rather than hardcoded. Each channel's
# channel_id uses the SAME numbering as daddylive.mov (verified: id 663 =
# "NHL Network USA" on both), so playback resolves via
# sports_sources._dlchan_stream_url — no separate resolver needed here.

_TVNOW_BASE = 'https://tvnow247.top'
# Confirmed live 2026-08-09: the site's build renamed this chunk from
# "channelData-<hash>.js" to "channels-<hash>.js" — the reference is still
# a plain string sitting in the /tv-channels page's own static HTML (no JS
# execution needed to find it, same as before), so this was purely a
# filename-pattern change, not a move to some other discovery mechanism.
# Matching both patterns costs nothing and survives a future revert.
_RE_TVNOW_ASSET = re.compile(r'/assets/((?:channelData|channels)-[A-Za-z0-9_-]+\.js)')
_RE_TVNOW_CHANNEL = re.compile(
    r'channel_name:"([^"]*)",channel_id:"([^"]*)",slug:"([^"]*)",country:"([^"]*)".*?logoUrl:"([^"]*)"',
    re.DOTALL
)

# Adult channels are mixed into the same catalogue (e.g. "18+ (Player-N)") —
# excluded here since this addon already has a dedicated, PIN-gated Adult
# section; a general Live TV list shouldn't surface them unprompted.
_TVNOW_ADULT_BLOCK = {
    'pornhub', 'xvideos', 'xhamster', 'beeg', 'motherless', 'naughtyamerica',
    'sexvid', 'tnaflix', 'realitykings', 'drtuber', 'youporn', 'tube8',
    'pornhd', 'porntrex', 'bangbros', 'brazzers', 'spankbang', 'eporner',
}


def _tvnow_is_adult(name, slug):
    n = (name or '').lower()
    s = (slug or '').lower().replace('-', '')
    if '18+' in n or '18plus' in s:
        return True
    return any(b in n.replace(' ', '') or b in s for b in _TVNOW_ADULT_BLOCK)


_TVNOW_STREAM_API = 'https://chat.cfbu247.sbs/api/resolve-dlstream/%s'


def resolve_tvnow_stream(channel_id):
    url = _resolve_tvnow_stream_api(channel_id)
    if url:
        return url
    # tvnow247 numbers its channels exactly like DLHD (id 663 is NHL Network on both), so the same id
    # resolves straight through the DLHD player resolver before falling back to a name match
    if str(channel_id).isdigit():
        try:
            url = resolve_dlstreams_channel(str(channel_id))
            if url:
                return url
        except Exception as e:
            xbmc.log('[Starfleet/TVNow] DLHD id fallback (%s): %s' % (channel_id, e), xbmc.LOGINFO)
    return _tvnow_via_dlhd(channel_id)


def _tvnow_via_dlhd(channel_id):
    """Second chance for a tvnow247 channel whose own API has no live upstream
    right now (measured 2026-09-25: about half of a random sample): the same
    channel is very often in the DLHD 24/7 directory, so look it up there by
    name (same fuzzy match pvr_export uses to merge the two catalogues)."""
    try:
        from starfleetscrapers import host as _sfhost; _merge_normalize = _sfhost.func('pvr_export', '_merge_normalize'); _merge_score = _sfhost.func('pvr_export', '_merge_score')
        title = next((c['title'] for c in get_tvnow_channels() if c.get('id') == channel_id or c.get('slug') == channel_id), '')
        norm = _merge_normalize(title)
        if not norm:
            return None
        best, best_id = 0, None
        for ch in get_dlstreams_channels():
            sc = _merge_score(norm, _merge_normalize(ch['title']))
            if sc >= 0.8 and sc > best:
                best, best_id = sc, ch['stream_url'].split(':', 1)[1]
        return resolve_dlstreams_channel(best_id) if best_id else None
    except Exception as e:
        xbmc.log('[Starfleet/TVNow] DLHD fallback error (%s): %s' % (channel_id, e), xbmc.LOGWARNING)
        return None


def _resolve_tvnow_stream_api(channel_id):
    """Fresh-resolve one of get_tvnow_channels()'s own channel ids to a
    playable stream URL at play time — never cached, since tokens/mirrors
    expire. Same API endpoint sports_sources._tvnow_api_resolve_mirror uses
    to resolve daddylive.mov mirrors that redirect through tvnow247.top;
    this calls it directly by channel_id for the general Live TV channel
    case (a plain menu click, not a sport-event mirror lookup)."""
    if not channel_id:
        return None
    from starfleetscrapers.core import dns_fallback as _dnsf
    ua = {'User-Agent': ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
                         'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36')}
    try:
        # chat.cfbu247.sbs fails to resolve on some local/ISP DNS resolvers
        # even though it's live (confirmed via a public DNS resolver) —
        # _dnsf.get transparently retries via DNS-over-HTTPS on a local
        # resolution failure instead of just giving up.
        data = _dnsf.get(_TVNOW_STREAM_API % channel_id, timeout=8, headers=ua).json()
    except Exception as e:
        xbmc.log('[Starfleet/TVNow] resolve_tvnow_stream API error (%s): %s' % (channel_id, e),
                  xbmc.LOGWARNING)
        return None
    playlist_url = data.get('proxyPlaylistUrl') or data.get('m3u8')
    if not playlist_url:
        return None
    # The API happily returns a token even for a channel with no live
    # upstream right now — verify it actually serves before handing it to
    # the player, same check _tvnow_api_resolve_mirror already relies on.
    try:
        check = _dnsf.get(playlist_url, timeout=6, headers=ua)
        if check.status_code != 200 or not check.text.lstrip().startswith('#EXTM3U'):
            return None
    except Exception:
        return None
    return playlist_url


def get_tvnow_channels():
    """tvnow247's channel catalogue, or nothing while neither it nor DLHD can play a channel (see source_up)."""
    return _get_tvnow_channels() if source_up('tvnow') else []


def _get_tvnow_channels():
    """Scrape tvnow247.top's full channel catalogue. Cached 12h."""
    ck = 'tvnow_channels_v1'
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    channels = []
    try:
        ua = {'User-Agent': ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
                             'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36')}
        html = requests.get(_TVNOW_BASE + '/tv-channels', timeout=10, headers=ua).text
        am = _RE_TVNOW_ASSET.search(html)
        if not am:
            xbmc.log('[Starfleet/TVNow] channelData asset not found on page', xbmc.LOGWARNING)
            _cache.set(ck, [], 30 * 60)
            return []
        js_url = '%s/assets/%s' % (_TVNOW_BASE, am.group(1))
        js = requests.get(js_url, timeout=15, headers=ua).text

        seen = set()
        for m in _RE_TVNOW_CHANNEL.finditer(js):
            name, cid, slug, country, logo = m.groups()
            if not name or not cid or cid in seen:
                continue
            if _tvnow_is_adult(name, slug):
                continue
            seen.add(cid)
            channels.append({
                'id':        cid,
                'slug':      slug,
                'title':     name,
                'group':     country or 'Other',
                'source':    'TVNow247',
                'thumbnail': logo,
            })
    except Exception as e:
        xbmc.log('[Starfleet/TVNow] get_tvnow_channels error: %s' % e, xbmc.LOGWARNING)
        _cache.set(ck, [], 10 * 60)
        return []

    xbmc.log('[Starfleet/TVNow] %d channels scraped (adult filtered)' % len(channels), xbmc.LOGINFO)
    _cache.set(ck, channels, 12 * 3600)
    return channels


_RE_TVNOW_PLAYER_NUM = re.compile(r'player[\s\-]*0*(\d+)', re.IGNORECASE)

# adult-tv-channels.click — investigated live 2026-08-29 per direct request
# (alongside 2 mirror domains, fuckflix.click/xlivetv.com, sharing the exact
# same channel slugs and page template — confirmed byte-for-byte identical
# playerConfig shape, so scraping this one domain covers all three rather
# than duplicating the same content 3x). 24 real channels confirmed live
# across its 2 listing pages (Brazzers TV, Babes TV, Playboy TV, Hustler TV,
# Private TV, Penthouse TV, Dorcel TV, Vivid TV and more) — each channel
# page embeds a plain, unencrypted stream URL directly in a <script> block
# as either 'sourceUrl' or 'fallbackUrl' (template variant), no signing/
# token/expiry at all, same class of static config already confirmed and
# wired in for this site's own Vivid TV channel before this. A 4th
# candidate (guljaj.com) was also investigated and found to require a real
# account/login (own /user/reg.php + /user/ent.php pages, no free channel
# list reachable at all) — not added, unlike the other 3 which need no auth.
_ATC_BASE = 'https://adult-tv-channels.click'
_RE_ATC_CHANNEL_HREF = re.compile(r'href="https://adult-tv-channels\.click/([a-z0-9-]+)/"')
_RE_ATC_TITLE = re.compile(r'<h1[^>]*class="posttitle"[^>]*>([^<]+)</h1>')
_RE_ATC_STREAM_URL = re.compile(r'(?:sourceUrl|fallbackUrl)\s*:\s*"([^"]+)"')


def get_tvnow_adult_channels():
    """18+ channels — sourced from dlstreams.st's combined channel
    directory (see get_dlstreams_channels()'s own docstring for the
    site's background) rather than tvnow247.top. Confirmed live
    2026-08-24: tvnow247.top's /tv-channels page still loads (200), but
    its own SPA build no longer exposes a channelData asset bundle this
    regex ever matches — the site appears to have changed its own build
    tooling since this was first written, so that path silently returned
    zero channels regardless of query. dlstreams.st's own combined
    /24-7-channels.php listing (already scraped for the general SFW
    catalogue, and confirmed live as the same DaddyLive/DLHD family this
    addon already resolves elsewhere — see that module comment) carries a
    real 18+ section too: 20 real, currently-playable channels confirmed
    live (ids 501-520, titled "18+ (Player-NN)"), resolved through the
    exact same chain the SFW channels already use.

    Function name/signature kept as-is so afdb_router.py's/home.py's
    existing call sites don't need restructuring — only their own resolve
    call needed to switch from resolve_tvnow_stream() to
    resolve_dlstreams_channel() to match (done at both call sites)."""
    ck = 'tvnow_adult_channels_v3'
    cached = _cache.get(ck)
    if cached is not None:
        return cached

    channels = []
    try:
        raw = _dlstreams_channels_raw()
        for ch in raw:
            name = ch.get('name', '')
            if not name.strip().lower().startswith('18+'):
                continue
            nm = _RE_TVNOW_PLAYER_NUM.search(name)
            title = '18+ Player %02d' % int(nm.group(1)) if nm else name
            channels.append({
                'id':        ch['id'],
                'slug':      '',
                'title':     title,
                'group':     '18+',
                'source':    'DLHD',
                'thumbnail': '',
            })
        # adult_tv_sites.py: adult-tv-channels.click/.com, eroteve.com, okteve.com and
        # okporntv.com merged by channel name. Its ids ('ATV:...') carry the source pages,
        # not a stream URL - the playlists are token/IP bound and expire within the hour,
        # so resolve_adult_channel() below resolves them when played. (The 24 entries this
        # block used to add from adult-tv-channels.click were the site's placeholder
        # `sourceUrl` - one generic live.redtraffic.net category loop per channel name -
        # not the real channel; the site's API returns the real stream.)
        from starfleetscrapers.adult import tv_sites as _atv
        for ch in _atv.get_channels():
            channels.append({
                'id':        _atv.channel_id(ch),
                'slug':      '',
                'title':     ch['title'],
                'group':     '18+',
                'source':    'AdultTV',
                'thumbnail': '',
            })
    except Exception as e:
        xbmc.log('[Starfleet/TVNow] get_tvnow_adult_channels error: %s' % e, xbmc.LOGWARNING)
        _cache.set(ck, [], 10 * 60)
        return []

    channels = _adult_channels_alive(channels)
    channels.sort(key=lambda c: c['title'])
    xbmc.log('[Starfleet/TVNow] %d adult channels that play (via dlstreams.st and the adult TV sites)' % len(channels), xbmc.LOGINFO)
    _cache.set(ck, channels, 3 * 3600 if channels else 10 * 60)
    return channels


def _adult_channel_alive(ch):
    """Does the channel resolve to something that has video to play right now? The DLHD "18+ Player" slots that are not in use
    resolve to nothing, and the adult-TV proxy answers with a playlist that has no segments while its channel is off the air."""
    try:
        url = resolve_adult_channel(ch['id'])
    except Exception:
        return False
    if not url:
        return False
    if 'xlivetv' not in url:                          # a direct CDN playlist was already fetched when the channel was listed
        return True
    from urllib.parse import unquote
    base, _, tail = url.partition('|')
    headers = {'User-Agent': 'Mozilla/5.0'}
    for kv in tail.split('&'):
        if '=' in kv:
            k, v = kv.split('=', 1)
            headers[k] = unquote(v)
    for i in range(3):                                # the proxy shows its segments on some polls and not on others
        try:
            body = requests.get(base, headers=headers, timeout=8).text
            if any(l and not l.startswith('#') for l in body.splitlines()):
                return True
        except Exception:
            return False
        time.sleep(2)
    return False


def _adult_channels_alive(channels, budget=25):
    """The channels that play, checked side by side (a dead list is not shown; a check that does not finish in `budget` seconds
    counts as not playing)."""
    from concurrent.futures import ThreadPoolExecutor, wait
    ex = ThreadPoolExecutor(max_workers=10)
    futs = {ex.submit(_adult_channel_alive, c): c for c in channels}
    done, _pending = wait(list(futs), timeout=budget)
    ex.shutdown(wait=False)
    return [futs[f] for f in done if not f.exception() and f.result()]


def resolve_adult_channel(channel_id):
    """Single resolve entry point for get_tvnow_adult_channels()'s list —
    both afdb_router.py's and home.py's play handlers call this instead of
    resolve_dlstreams_channel() directly, so a channel from a different
    source (the merged adult-TV site directories in adult_tv_sites.py) can be handled here
    without either call site needing its own per-source branching."""
    if channel_id.startswith('DIRECT:'):
        return channel_id[len('DIRECT:'):]
    if channel_id.startswith('ATV:'):
        from starfleetscrapers.adult import tv_sites as _atv
        return _atv.resolve(channel_id)
    return resolve_dlstreams_channel(channel_id)


def get_combined_m3u(include_tva_channels=None):
    """
    Generate a combined M3U playlist for ALL sources.
    This can be pointed at by pvr.iptvsimple for a full EPG experience.
    include_tva_channels: list of {'title', 'asset_key', 'thumbnail'} dicts
    """
    lines = ['#EXTM3U']

    # TVA / DAI channels — use plugin:// URL so DAI token is fetched at play time
    if include_tva_channels:
        for ch in include_tva_channels:
            plugin_url = (
                'plugin://plugin.video.starfleet/'
                '?action=play_live_dai'
                '&asset_key=%s&title=%s' % (ch['asset_key'],
                                             requests.utils.quote(ch['title']))
            )
            lines.append(
                '#EXTINF:-1 tvg-id="%s" tvg-logo="%s" group-title="Starfleet",\t%s'
                % (ch['asset_key'], ch.get('thumbnail',''), ch['title'])
            )
            lines.append(plugin_url)

    # Samsung
    for ch in get_samsung_channels():
        lines.append(
            '#EXTINF:-1 tvg-id="%s" tvg-logo="%s" group-title="Samsung TV+",\t%s'
            % (ch['id'], ch['thumbnail'], ch['title'])
        )
        lines.append(ch['stream_url'])

    # Plex
    for ch in get_plex_channels():
        lines.append(
            '#EXTINF:-1 tvg-id="%s" tvg-logo="%s" group-title="Plex",\t%s'
            % (ch['id'], ch['thumbnail'], ch['title'])
        )
        lines.append(ch['stream_url'])

    # Roku / LG
    for label, getter in (('Roku', get_roku_channels), ('LG Channels', get_lg_channels)):
        for ch in getter():
            lines.append(
                '#EXTINF:-1 tvg-id="%s" tvg-logo="%s" group-title="%s",	%s'
                % (ch['id'], ch['thumbnail'], label, ch['title'])
            )
            lines.append(ch['stream_url'])

    # Pluto
    for ch in get_pluto_channels():
        lines.append(
            '#EXTINF:-1 tvg-id="%s" tvg-logo="%s" group-title="Pluto TV",\t%s'
            % (ch['id'], ch['thumbnail'], ch['title'])
        )
        lines.append(ch.get('stream_url', ''))

    return '\n'.join(lines)


# ── channel lists that never make you wait ────────────────────────────────────
#
# Each get_*_channels() already keeps its list for hours, but the first call after that (or after an update) builds it from the network
# while the screen waits: from 1 s to 8 s on a PC, several times that on a Fire TV Stick. _swr() keeps the last good list for a week
# next to it: a call returns that copy AT ONCE and, when it is older than 20 minutes, refreshes it in the background (the getter's own
# cache makes that cheap while its list is still fresh). Only the very first call ever waits. prewarm_channel_lists() builds all of
# them quietly one after the other (the add-on's scheduler calls it a few minutes after Kodi starts), so even that is rarely seen.

_SWR_AGE = 20 * 60
_swr_busy = set()


def _swr(fn):
    key = 'swr_%s' % fn.__name__

    def wrapped(*a, **k):
        if a or k:
            return fn(*a, **k)
        copy = _cache.get(key)
        if copy:
            try:
                ts, value = copy
            except Exception:
                ts, value = 0, None
            if value:
                if time.time() - ts > _SWR_AGE and key not in _swr_busy:
                    _swr_busy.add(key)

                    def _bg():
                        try:
                            v = fn()
                            if v:
                                _cache.set(key, (time.time(), v), 7 * 24 * 3600)
                        except Exception as e:
                            xbmc.log('[Starfleet/LiveTV] %s refresh: %s' % (fn.__name__, str(e)[:80]), xbmc.LOGINFO)
                        finally:
                            _swr_busy.discard(key)
                    threading.Thread(target=_bg, daemon=True).start()
                return value
        value = fn()
        if value:
            _cache.set(key, (time.time(), value), 7 * 24 * 3600)
        return value
    wrapped.__name__ = fn.__name__
    wrapped.inner = fn
    return wrapped


# ── Channel hubs (Famelack, Easy Web TV, PPV 24/7, NTV Hesgoal): see live_hubs ──

def get_famelack_channels():
    from starfleetscrapers.live import live_hubs
    return live_hubs.get_famelack_channels()


def get_easywebtv_channels():
    from starfleetscrapers.live import live_hubs
    return live_hubs.get_easywebtv_channels()


def get_ppv247_channels():
    from starfleetscrapers.live import live_hubs
    return live_hubs.get_ppv247_channels()


def get_ntvhub_channels():
    from starfleetscrapers.live import live_hubs
    return live_hubs.get_ntvhub_channels()


def get_fsltv_channels():
    from starfleetscrapers.live import live_hubs
    return live_hubs.get_fsltv_channels()


def get_tvnowst_channels():
    from starfleetscrapers.live import live_hubs
    return live_hubs.get_tvnowst_channels()


_SWR_GETTERS = ('get_plex_channels', 'get_lg_channels', 'get_pluto_channels', 'get_timstreams_channels', 'get_cdnlive_channels',
                'get_ustvnow_channels', 'get_filmon_channels', 'get_smotru_channels', 'get_onhockey_live_channels',
                'get_free_live_sports_channels',
                'get_famelack_channels', 'get_easywebtv_channels', 'get_ppv247_channels', 'get_ntvhub_channels', 'get_fsltv_channels', 'get_tvnowst_channels')
for _n in _SWR_GETTERS:
    if _n in globals():
        globals()[_n] = _swr(globals()[_n])


def prewarm_channel_lists():
    """Build every channel list now, one at a time (a few seconds of work each), so none has to be built while a screen waits.
    Safe to call often: lists that are still fresh answer from their own cache at once."""
    done = 0
    for n in _SWR_GETTERS:
        fn = globals().get(n)
        try:
            if fn is not None and fn():
                done += 1
        except Exception as e:
            xbmc.log('[Starfleet/LiveTV] warm %s: %s' % (n, str(e)[:80]), xbmc.LOGINFO)
        time.sleep(0.5)
    return done


_prewarming = [False]


def prewarm_all():
    """Called when the Live TV menu opens: warm the lists in one background thread (a second call while it runs does nothing)."""
    if _prewarming[0]:
        return

    def _run():
        try:
            prewarm_channel_lists()
        finally:
            _prewarming[0] = False
    _prewarming[0] = True
    threading.Thread(target=_run, daemon=True).start()
