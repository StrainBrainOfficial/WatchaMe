# -*- coding: utf-8 -*-
"""
resources/lib/unified_live.py

Unified Live TV channel list — all sources, deduplicated, source-picker on conflicts.

Performance:
  - All source fetches run in PARALLEL via ThreadPoolExecutor
  - Cold load: wait = slowest single source (~3-5s) not sum of all (~12s)
  - Warm load: pure cache hit, <5ms
  - Dedup and merge runs on cached data — no re-fetch on repeat opens
  - Unified list itself cached 10 min
"""

from starfleetscrapers import host as _sfhost
import re
import threading
from functools import lru_cache
from concurrent.futures import ThreadPoolExecutor, as_completed, TimeoutError

import xbmc
import xbmcaddon
import xbmcvfs
from starfleetscrapers import host as _sfhost; _select_dialog = _sfhost.func('gui.select_dialog', 'select')

ADDON    = _sfhost.addon()
_PROFILE = _sfhost.profile()

from starfleetscrapers.core import cache as _cache
_cache.init(_PROFILE + '/cache.db')

SOURCE_LABELS = {
    'Samsung TV+':  '📺  Samsung TV+',
    'Plex':         '🟠  Plex',
    'Roku':         '🟣  Roku Channel',
    'LG Channels':  '🔴  LG Channels',
    'Pluto TV':     '🪐  Pluto TV',
    'TVA+':         '📡  Québecor/Global News',
    'OnHockey.tv':  '🏒  OnHockey.tv',
    'Tou.tv':       '🍁  ICI / Noovo',
    'Sinclair':     '🇺🇸  Sinclair Local News',
}

# Per-source fetch timeout — each source gets this long independently
FETCH_TIMEOUT = 15

# ── Name normalisation ────────────────────────────────────────────────────────

_RE_QUALITY  = re.compile(r'\b(HD|SD|FHD|UHD|4K|720p|1080p|480p)\b', re.IGNORECASE)
_RE_BRACKETS = re.compile(r'\[.*?\]')
_RE_PARENS   = re.compile(r'\(.*?\)')
_RE_NONALNUM = re.compile(r'[^a-z0-9 ]')
_RE_MULTI_SP = re.compile(r' {2,}')
_STRIP_TAIL  = {'television', 'channel', 'network', 'tv', 'plus', 'ca', 'us', 'hd'}

@lru_cache(maxsize=5000)
def _normalize(name):
    n = name.lower()
    n = _RE_BRACKETS.sub(' ', n)
    n = _RE_PARENS.sub(' ', n)
    n = _RE_QUALITY.sub(' ', n)
    n = _RE_NONALNUM.sub(' ', n)
    n = _RE_MULTI_SP.sub(' ', n).strip()
    parts = n.split()
    while parts and parts[-1] in _STRIP_TAIL:
        parts.pop()
    return ' '.join(parts)


# ── Parallel source fetcher ───────────────────────────────────────────────────

def _fetch_samsung():
    from starfleetscrapers.live import live_sources as live_sources
    chs = live_sources.get_samsung_channels()
    return [dict(ch, source='Samsung TV+') for ch in chs]

def _fetch_plex():
    from starfleetscrapers.live import live_sources as live_sources
    chs = live_sources.get_plex_channels()
    return [dict(ch, source='Plex') for ch in chs]

def _fetch_roku():
    from starfleetscrapers.live import live_sources as live_sources
    chs = live_sources.get_roku_channels()
    return [dict(ch, source='Roku') for ch in chs]

def _fetch_lg():
    from starfleetscrapers.live import live_sources as live_sources
    chs = live_sources.get_lg_channels()
    return [dict(ch, source='LG Channels') for ch in chs]

def _fetch_pluto():
    from starfleetscrapers.live import live_sources as live_sources
    chs = live_sources.get_pluto_channels()
    return [dict(ch, source='Pluto TV') for ch in chs]

def _fetch_onhockey():
    from starfleetscrapers.live import live_sources as live_sources
    chs = live_sources.get_onhockey_live_channels()
    return [dict(ch, source='OnHockey.tv') for ch in chs]

def _fetch_toutv():
    from starfleetscrapers.live import live_sources as live_sources
    chs = live_sources.get_toutv_live_channels()
    return [dict(ch, source='Tou.tv') for ch in chs]

def _fetch_sinclair():
    from starfleetscrapers.live import sinclair_live as sinclair_live
    chs = sinclair_live.get_channels()
    # Already source-agnostic dicts with one 'sources' entry each — unpack
    # here into the same flat {'title','group','thumbnail','source',...}
    # shape the other fetchers return, since _merge() rebuilds the grouped
    # 'sources' list itself from this flat form.
    out = []
    for ch in chs:
        src = ch['sources'][0]
        out.append({
            'id':         src['channel_id'],
            'title':      ch['title'],
            'group':      ch['group'],
            'source':     'Sinclair',
            'thumbnail':  ch['thumbnail'],
            'stream_url': '',
            'callsign':   src['callsign'],
            'domain':     src['domain'],
        })
    return out

_FETCHERS = {
    'Samsung TV+': _fetch_samsung,
    'Plex':        _fetch_plex,
    'Roku':        _fetch_roku,
    'LG Channels': _fetch_lg,
    'Pluto TV':    _fetch_pluto,
    'OnHockey.tv': _fetch_onhockey,
    'Tou.tv':      _fetch_toutv,
    'Sinclair':    _fetch_sinclair,
}


def _fetch_all_parallel(deadline=6.0):
    """
    Ask every source at once and take what has arrived after `deadline` seconds. A slow source (OnHockey took up to 39 s for its single
    channel, LG about 20 s) used to hold the whole list back, because the thread pool waited for it on the way out; now the list is built
    from the quick sources, and a slow one keeps running behind us and fills its own cache for the next build.
    Returns a flat list of raw channel dicts with 'source' set.
    """
    from concurrent.futures import wait
    raw = []
    pool = ThreadPoolExecutor(max_workers=len(_FETCHERS))
    futures = {pool.submit(fn): source for source, fn in _FETCHERS.items()}
    done, pending = wait(list(futures), timeout=deadline)
    pool.shutdown(wait=False)
    for future in done:
        source = futures[future]
        try:
            channels = future.result()
            raw.extend(channels)
            xbmc.log('[Starfleet] %s: %d channels fetched' % (source, len(channels)), xbmc.LOGINFO)
        except Exception as e:
            xbmc.log('[Starfleet] %s: fetch error: %s' % (source, e), xbmc.LOGWARNING)
    for future in pending:
        xbmc.log('[Starfleet] %s: still loading, left out for now' % futures[future], xbmc.LOGINFO)
    return raw


# ── Merge & dedup ─────────────────────────────────────────────────────────────

def _merge(raw, tva_channels=None):
    """
    Merge raw channel list into deduplicated groups.
    Returns sorted list of group dicts.
    """
    if tva_channels:
        for ch in tva_channels:
            raw.append({
                'id':         ch.get('id', ''),
                'title':      ch['title'],
                'group':      'TVA+',
                'source':     'TVA+',
                'thumbnail':  ch.get('thumbnail', ''),
                'stream_url': '',
                'asset_key':  ch.get('asset_key', ''),
                'channel_id': ch.get('id', ''),
            })

    groups = {}

    for ch in raw:
        title = (ch.get('title') or '').strip()
        if not title:
            continue
        key = _normalize(title)
        if not key:
            continue

        entry = {
            'source':     ch['source'],
            'label':      SOURCE_LABELS.get(ch['source'], ch['source']),
            'stream_url': ch.get('stream_url', ''),
            'thumbnail':  ch.get('thumbnail', ''),
            'ch_id':      ch.get('id', ''),
            'asset_key':  ch.get('asset_key', ''),
            'channel_id': ch.get('channel_id', ch.get('id', '')),
            'callsign':   ch.get('callsign', ''),
            'domain':     ch.get('domain', ''),
        }

        if key not in groups:
            groups[key] = {
                'key':       key,
                'title':     title,
                'thumbnail': ch.get('thumbnail', ''),
                'group':     ch.get('group', ''),
                'sources':   [],
            }
        else:
            # Prefer longer title, prefer non-empty thumbnail
            if len(title) > len(groups[key]['title']):
                groups[key]['title'] = title
            if not groups[key]['thumbnail'] and ch.get('thumbnail'):
                groups[key]['thumbnail'] = ch['thumbnail']

        # One entry per source per channel
        if ch['source'] not in [s['source'] for s in groups[key]['sources']]:
            groups[key]['sources'].append(entry)

    return sorted(groups.values(), key=lambda x: x['title'].lower())


# ── Public API ────────────────────────────────────────────────────────────────

_refreshing = [False]


def _build(tva_channels=None):
    raw = _fetch_all_parallel()
    result = _merge(raw, tva_channels)
    _cache.set('unified_live_all', result, 10 * 60)
    if result:
        _cache.set('unified_live_last', result, 24 * 3600)           # the copy shown at once while a fresh one is built
    xbmc.log('[Starfleet] Unified live: %d channels merged from %d raw' % (len(result), len(raw)), xbmc.LOGINFO)
    return result


def get_all_channels(tva_channels=None):
    """
    Return merged, deduplicated channel list from all sources.
    A list built in the last ten minutes is returned as it is. Otherwise the last list is returned AT ONCE (and a new one is built
    behind it), so opening All Channels never waits on the network; only the very first build waits, and then only for the sources
    that answer within a few seconds.
    """
    cached = _cache.get('unified_live_all')
    if cached is not None:
        return cached
    last = _cache.get('unified_live_last')
    if last:
        if not _refreshing[0]:
            _refreshing[0] = True

            def _bg():
                try:
                    _build(tva_channels)
                except Exception as e:
                    xbmc.log('[Starfleet] Unified live refresh: %s' % e, xbmc.LOGWARNING)
                finally:
                    _refreshing[0] = False
            threading.Thread(target=_bg, daemon=True).start()
        return last
    return _build(tva_channels)


def invalidate():
    _cache.delete('unified_live_all')


# ── Source picker ─────────────────────────────────────────────────────────────

def pick_source_and_play(handle, channel):
    """
    Single source  → return immediately, no dialog.
    Multi source   → show select dialog → return chosen.
    Returns (source_entry, action) or (None, None) on cancel.
    """
    sources = channel['sources']

    if len(sources) == 1:
        return sources[0], _action_for(sources[0])

    options = [s['label'] for s in sources]
    idx = _select_dialog(
        'Stream "%s" from:' % channel['title'], options
    )
    if idx < 0:
        return None, None

    return sources[idx], _action_for(sources[idx])


def _action_for(source_entry):
    if source_entry['source'] == 'TVA+':
        return 'play_live_dai'
    if source_entry['source'] == 'Sinclair':
        return 'play_sinclair'
    return 'play_direct'
