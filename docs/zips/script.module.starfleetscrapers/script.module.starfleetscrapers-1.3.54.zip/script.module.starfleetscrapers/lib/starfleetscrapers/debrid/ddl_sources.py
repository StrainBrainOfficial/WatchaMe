# -*- coding: utf-8 -*-
"""Release sites ("DDL"): sites that post scene / P2P releases together with their file-host links.

Searching them gives hoster links (Rapidgator, Nitroflare, 1fichier, ...) instead of torrents, so they only play with a
debrid service that covers the host. search() returns the releases found, each with its links; get_streams() turns that
into the picker rows the debrid search adds next to the torrent and Usenet rows:

    [{'label': '[DDL] Movie.2010.1080p.BluRay.x264-GRP (Rapidgator, 2.1 GB)', 'url': hoster link, 'quality': '1080p',
      'is_ddl': True}]

The sites are searched side by side with a short deadline; a site that is down, slow or behind a browser check is skipped
(nothing here tries to get past a check)."""
import re
import time
from concurrent.futures import ThreadPoolExecutor, wait as _wait
from urllib.parse import quote_plus, urljoin, urlparse

import xbmc

from starfleetscrapers import host as _sfhost
from starfleetscrapers.core import cache as _cache

try:
    from starfleetscrapers.debrid import torrent_sources as _ts
except Exception:                                   # pragma: no cover - torrent_sources always ships with this module
    _ts = None

_HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml',
    'Accept-Language': 'en-US,en;q=0.9',
}

# file hosts worth offering, best first; the label is what the picker shows
_HOSTS = (
    ('rapidgator.net', 'Rapidgator'), ('rapidgator.asia', 'Rapidgator'), ('rg.to', 'Rapidgator'),
    ('nitroflare.com', 'Nitroflare'), ('nitro.download', 'Nitroflare'),
    ('1fichier.com', '1fichier'), ('katfile.com', 'Katfile'), ('ddownload.com', 'DDownload'), ('ddl.to', 'DDownload'),
    ('turbobit.net', 'Turbobit'), ('hitfile.net', 'Hitfile'), ('uploadgig.com', 'Uploadgig'),
    ('filefactory.com', 'FileFactory'), ('uploaded.net', 'Uploaded'), ('ul.to', 'Uploaded'), ('alfafile.net', 'Alfafile'),
    ('fikper.com', 'Fikper'), ('mexa.sh', 'Mexashare'), ('mexashare.com', 'Mexashare'), ('filejoker.net', 'Filejoker'),
)
_HOST_RANK = {h: i for i, (h, _l) in enumerate(_HOSTS)}
_HOST_LABEL = dict(_HOSTS)
_ARCHIVE = re.compile(r'\.(?:rar|zip|7z|iso|nfo|srt|sub|idx|jpe?g|png|gif|txt|exe|par2?|r\d{2})(?:\.html)?(?:[?#].*)?$', re.I)
_URL = re.compile(r'https?://[^\s<>"\'\)\]]+', re.I)
_COMMENTS = re.compile(r'<!--.*?-->', re.S)
_SIZE = re.compile(r'(\d+(?:[.,]\d+)?)\s*(GB|MB|GiB|MiB)\b', re.I)

SITE_KEYS = ('rapidmoviez', 'releasebb', 'scenerls', 'myvideolinks')


def _on(key):
    try:
        return _sfhost.addon().getSetting('src_ddl_' + key) != 'false'
    except Exception:
        return True


def _get(url, timeout=7, referer=None):
    try:
        s = _ts._sess() if _ts else None
        if s is None:
            from starfleetscrapers.core import http as requests
            s = requests
        h = dict(_HEADERS)
        if referer:
            h['Referer'] = referer
        r = s.get(url, headers=h, timeout=timeout, allow_redirects=True)
        if r.status_code != 200:
            return ''
        txt = r.text
        if len(txt) < 3000 and ('Just a moment' in txt or 'cf-chl' in txt):      # a browser check - not attempted
            return ''
        return txt
    except Exception as e:
        xbmc.log('[Starfleet/DDL] %s: %s' % (urlparse(url).netloc, e), xbmc.LOGINFO)
        return ''


def _host_of(url):
    h = urlparse(url).netloc.lower()
    return h[4:] if h.startswith('www.') else h


def hoster_links(html):
    """[(rank, label, url)] of the file-host links in a chunk of html (archives and unknown hosts dropped, duplicates merged)."""
    out, seen = [], set()
    for u in _URL.findall(_COMMENTS.sub('', html or '')):
        u = u.rstrip('.,;').replace('&amp;', '&')
        host = _host_of(u)
        key = next((h for h in _HOST_RANK if host == h or host.endswith('.' + h)), None)
        if not key or u in seen or _ARCHIVE.search(u.split('?')[0]):
            continue
        seen.add(u)
        out.append((_HOST_RANK[key], _HOST_LABEL[key], u))
    return sorted(out)


def _size_text(s):
    m = _SIZE.search(s or '')
    if not m:
        return ''
    return '%s %s' % (m.group(1).replace(',', '.'), m.group(2).upper().replace('IB', 'B'))


def _query(title, year, media_type, season, episode):
    if media_type == 'tv' and season is not None and episode is not None:
        return '%s S%02dE%02d' % (title, int(season), int(episode))
    return ('%s %s' % (title, year)).strip() if year else title


def _release(site, name, size, links):
    return {'site': site, 'title': name, 'size': size, 'links': links}


# ── RapidMoviez ───────────────────────────────────────────────────────────────

_RMZ = 'https://rapidmoviez.com'
_RE_RMZ = re.compile(r'href="(/release/[^"]+)"[^>]*><b>([^<]+)</b>', re.I)
_RE_PRE = re.compile(r'<pre[^>]*class="links"[^>]*>(.*?)</pre>', re.S | re.I)


def _rapidmoviez(query, limit=6):
    page = _get('%s/search/%s' % (_RMZ, quote_plus(query)))
    rows = _RE_RMZ.findall(page)[:limit * 2]
    out = []

    def one(row):
        path, label = row
        name = re.sub(r'^\s*(?:\[[^\]]*\]\s*)+', '', label.strip())
        size = _size_text(label)
        name = re.sub(r'\s*\([\d.,]+\s*[GM]B\)\s*$', '', name, flags=re.I)
        html = _get(_RMZ + path, referer=_RMZ + '/')
        links = hoster_links('\n'.join(_RE_PRE.findall(html)))
        return _release('RapidMoviez', name, size, links) if links else None

    seen = set()
    rows = [r for r in rows if not (r[0] in seen or seen.add(r[0]))]
    with ThreadPoolExecutor(max_workers=min(len(rows) or 1, 6)) as ex:
        for res in ex.map(one, rows):
            if res:
                out.append(res)
    return out


# ── ReleaseBB ─────────────────────────────────────────────────────────────────

_RLSBB_SEARCH = ('https://search.rlsbb.cc', 'https://search.rlsbb.to', 'https://search.rlsbb.in')
_RE_RLSBB_POST = re.compile(r'<h1[^>]*class="entry-title"[^>]*>\s*<a[^>]*href="([^"]+)"[^>]*rel="bookmark"[^>]*>(.*?)</a>', re.S | re.I)
_RE_RELNAME = re.compile(r'<strong>\s*Release Name:?\s*</strong>\s*:?\s*([^<\r\n]+)', re.I)


def _releasebb(query, limit=4):
    page = ''
    for base in _RLSBB_SEARCH:
        page = _get('%s/?s=%s' % (base, quote_plus(query)))
        if page:
            break
    posts = _RE_RLSBB_POST.findall(page)[:limit]
    out = []

    def one(post):
        url, title = post
        title = re.sub(r'<[^>]+>', '', title).strip()
        html = _get(url, referer='https://rlsbb.cc/')
        if not html:
            return []
        body = html[html.find('entry-content'):] if 'entry-content' in html else html
        parts = re.split(r'(?=<strong>\s*Release Name)', body, flags=re.I)
        found = []
        for part in parts:
            m = _RE_RELNAME.search(part[:400])
            if not m:
                continue
            name = m.group(1).strip().replace('&#8211;', '-')
            sm = re.search(r'<strong>\s*Size:?\s*</strong>\s*:?\s*([^<\r\n]+)', part[:900], re.I)
            links = hoster_links(part[:6000])
            if links:
                found.append(_release('ReleaseBB', name, _size_text(sm.group(1)) if sm else '', links))
        if not found:                               # a post without release blocks: take the whole page against its title
            links = hoster_links(body[:30000])
            if links:
                found.append(_release('ReleaseBB', title, '', links))
        return found

    with ThreadPoolExecutor(max_workers=min(len(posts) or 1, 4)) as ex:
        for res in ex.map(one, posts):
            out.extend(res)
    return out


# ── Scene-RLS ─────────────────────────────────────────────────────────────────

_SCENE = 'https://scene-rls.com'
_RE_SCENE_POST = re.compile(r'<a[^>]*href="(https?://scene-rls\.com/[^"]+/)"[^>]*title="Permalink to ([^"]+)"', re.I)


def _scenerls(query, limit=5):
    page = _get('%s/?s=%s&submit=Find' % (_SCENE, quote_plus(query)))
    seen, posts = set(), []
    for url, title in _RE_SCENE_POST.findall(page):
        if url not in seen:
            seen.add(url)
            posts.append((url, title))
    posts = posts[:limit]

    def one(post):
        url, title = post
        html = _get(url, referer=_SCENE + '/')
        links = hoster_links(html[html.find('<article'):] if '<article' in html else html)
        return _release('Scene-RLS', re.sub(r'&#\d+;', '-', title).strip(), '', links) if links else None

    out = []
    with ThreadPoolExecutor(max_workers=min(len(posts) or 1, 5)) as ex:
        for res in ex.map(one, posts):
            if res:
                out.append(res)
    return out


# ── MyVideoLinks ──────────────────────────────────────────────────────────────

_MVL = 'https://myvideolinks.org'
_RE_MVL_POST = re.compile(r'<h2[^>]*>\s*<a[^>]*href="(https?://myvideolinks\.org/[^"]+)"[^>]*>(.*?)</a>', re.S | re.I)


def _myvideolinks(query, limit=4):
    page = _get('%s/?s=%s' % (_MVL, quote_plus(query)))
    posts = _RE_MVL_POST.findall(page)[:limit]

    def one(post):
        url, title = post
        title = re.sub(r'<[^>]+>|&#\d+;|&nbsp;', ' ', title).strip()
        html = _get(url, referer=_MVL + '/')
        links = hoster_links(html[html.find('entry-content'):] if 'entry-content' in html else html)
        return _release('MyVideoLinks', title, '', links) if links else None

    out = []
    with ThreadPoolExecutor(max_workers=min(len(posts) or 1, 4)) as ex:
        for res in ex.map(one, posts):
            if res:
                out.append(res)
    return out


_SITES = (('rapidmoviez', _rapidmoviez), ('releasebb', _releasebb), ('scenerls', _scenerls), ('myvideolinks', _myvideolinks))


# ── Public ────────────────────────────────────────────────────────────────────

def search(title, year=None, media_type='movie', season=None, episode=None, timeout=6.0):
    """Releases (with their file-host links) matching the title, from every enabled release site. Cached for 15 minutes."""
    if not title:
        return []
    query = _query(title, year, media_type, season, episode)
    ck = 'ddl_v1_%s_%s_%s_%s' % (query, media_type, season, episode)
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    sites = [(k, fn) for k, fn in _SITES if _on(k)]
    ex = ThreadPoolExecutor(max_workers=max(len(sites), 1))
    futs = {ex.submit(fn, query): k for k, fn in sites}
    done, _pending = _wait(list(futs), timeout=timeout)
    ex.shutdown(wait=False)
    releases = []
    for f in done:
        try:
            got = f.result() or []
            xbmc.log('[Starfleet/DDL] %s: %d releases' % (futs[f], len(got)), xbmc.LOGINFO)
            releases.extend(got)
        except Exception as e:
            xbmc.log('[Starfleet/DDL] %s failed: %s' % (futs[f], e), xbmc.LOGWARNING)
    # keep only releases of this title / episode (the sites do loose word matching)
    if _ts and releases:
        releases = _ts.filter_by_title_and_episode(releases, title, media_type=media_type, season=season,
                                                   episode=episode, key='title', log_tag='DDL')
    if media_type != 'tv' and year:                     # movies: the year must appear in the release name
        releases = [r for r in releases if str(year) in r['title'] or not re.search(r'\b(19|20)\d{2}\b', r['title'])]
    _cache.set(ck, releases, 15 * 60 if releases else 120)
    return releases


def get_streams(title, year=None, media_type='movie', season=None, episode=None, covered=None, per_release=2, limit=60,
                timeout=6.0):
    """Picker rows for the release-site hits. `covered(url)` (optional) keeps only links a connected debrid service handles."""
    rows, seen = [], set()
    for rel in search(title, year, media_type, season, episode, timeout=timeout):
        quality = _ts._extract_quality(rel['title']) if _ts else ''
        taken, used_hosts = 0, set()
        for _rank, host_label, url in rel['links']:
            if host_label in used_hosts or url in seen:
                continue
            if covered is not None:
                try:
                    if not covered(url):
                        continue
                except Exception:
                    continue
            seen.add(url)
            used_hosts.add(host_label)
            extra = ', '.join(x for x in (host_label, rel.get('size') or '') if x)
            rows.append({'label': '[DDL] %s (%s, %s)' % (rel['title'], rel['site'], extra), 'url': url, 'quality': quality,
                         'is_ddl': True})
            taken += 1
            if taken >= per_release:
                break
        if len(rows) >= limit:
            break
    return rows
