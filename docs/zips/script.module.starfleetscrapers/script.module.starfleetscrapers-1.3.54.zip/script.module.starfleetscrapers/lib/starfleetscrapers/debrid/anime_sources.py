# -*- coding: utf-8 -*-
"""Anime torrent sources: Nyaa, AnimeTosho, SubsPlease, Tokyo Toshokan, AcgnX.

Anime is not named or numbered like Western TV: releases carry the Japanese (romaji) title and an absolute episode number
("[SubsPlease] Sousou no Frieren - 12 (1080p)"), while the show is known to the viewer's library by its English title and
season / episode. So this module

  * recognises anime and learns its other titles from AniList (a public API) - is_anime() / titles();
  * searches every source under each of those titles and the episode number;
  * keeps only releases of the requested film / episode (single episodes, "S2 - 03", batches that contain it) itself, and
    marks them {'anime': True} so the general title filter in search_all() - which only knows one title - leaves them alone.

search(title, year, media_type, season, episode) -> [result dict, ...]; [] straight away for anything that is not anime.
AniDex sits behind a browser check (DDoS-Guard) and BakaBT / AnimeBytes are private trackers, so they are not included."""
import base64
import html as _html
import re
import time
from concurrent.futures import ThreadPoolExecutor, wait as _wait
from urllib.parse import quote_plus, parse_qs, unquote

import xbmc

from starfleetscrapers import host as _sfhost
from starfleetscrapers.core import cache as _cache

try:
    from starfleetscrapers.debrid import torrent_sources as _ts
except Exception:                                  # pragma: no cover
    _ts = None

SITE_KEYS = ('nyaa', 'animetosho', 'subsplease', 'tokyotosho', 'acgnx')
_HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36',
    'Accept-Language': 'en-US,en;q=0.9',
}


def _on(key):
    try:
        return _sfhost.addon().getSetting('src_anime_' + key) != 'false'
    except Exception:
        return True


def enabled():
    try:
        return _sfhost.addon().getSetting('src_anime') != 'false'
    except Exception:
        return True


def _get(url, timeout=7):
    try:
        s = _ts._sess() if _ts else None
        if s is None:
            from starfleetscrapers.core import http as requests
            s = requests
        r = s.get(url, headers=_HEADERS, timeout=timeout, allow_redirects=True)
        if r.status_code != 200:
            return ''
        t = r.text
        if len(t) < 6000 and ('Just a moment' in t or 'DDoS-Guard' in t or 'cf-chl' in t):      # a browser check: not attempted
            return ''
        return t
    except Exception as e:
        xbmc.log('[Starfleet/Anime] %s: %s' % (url[:50], e), xbmc.LOGINFO)
        return ''


# ── Is it anime, and what else is it called ───────────────────────────────────

_ANILIST = 'https://graphql.anilist.co'
_QUERY = ('query($q:String){Page(perPage:6){media(search:$q,type:ANIME,sort:SEARCH_MATCH){id format seasonYear startDate{year} '
          'title{romaji english native} synonyms}}}')


def _norm(s):
    s = re.sub(r"[’'`]", '', (s or '').lower())
    return re.sub(r'\s+', ' ', re.sub(r'[^a-z0-9]+', ' ', s)).strip()


def _title_match(a, b):
    a, b = _norm(a), _norm(b)
    if not a or not b:
        return False
    if a == b:
        return True
    wa, wb = a.split(), b.split()
    small, big = (wa, wb) if len(wa) <= len(wb) else (wb, wa)
    return len(small) >= 2 and all(w in big for w in small) and len(small) >= 0.6 * len(big)


def titles(title, year=None, media_type='tv'):
    """[names] when `title` (+ year) is an anime - romaji first, then English, synonyms - else []. Cached for a week."""
    ck = 'anime_titles_v3_%s_%s_%s' % (_norm(title), year or '', media_type)
    cached = _cache.get(ck)
    if cached is not None:
        return cached or []
    names = []
    try:
        s = _ts._sess() if _ts else None
        if s is None:
            from starfleetscrapers.core import http as requests
            s = requests
        r = s.post(_ANILIST, json={'query': _QUERY, 'variables': {'q': title}}, headers={'Accept': 'application/json'}, timeout=8)
        media = (((r.json() or {}).get('data') or {}).get('Page') or {}).get('media') or []
    except Exception as e:
        xbmc.log('[Starfleet/Anime] AniList lookup failed: %s' % e, xbmc.LOGINFO)
        _cache.set(ck, [], 10 * 60)
        return []
    try:
        y = int(year) if year else 0
    except (TypeError, ValueError):
        y = 0
    def _cands(m):
        t = m.get('title') or {}
        return [x for x in [t.get('romaji'), t.get('english'), t.get('native')] + list(m.get('synonyms') or []) if x]

    def _year(m):
        return int(m.get('seasonYear') or (m.get('startDate') or {}).get('year') or 0)

    matched = [m for m in media if any(_title_match(title, c) for c in _cands(m))]
    if y:                                   # a different film / show of the same name has a different year
        matched = [m for m in matched if not _year(m) or abs(_year(m) - y) <= 1]
    def _score(m):                          # the entry that IS the title (not a commercial / side story that lists it as a synonym)
        t = m.get('title') or {}
        exact = any(_norm(title) == _norm(x) for x in (t.get('romaji'), t.get('english')) if x)
        fmt = m.get('format') or ''
        right_kind = fmt == 'MOVIE' if media_type == 'movie' else fmt in ('TV', 'TV_SHORT', 'ONA')
        return (2 if exact else 0) + (1 if right_kind else 0)

    matched.sort(key=_score, reverse=True)
    if matched:
        _cache.set('anime_ids_v1_%s_%s_%s' % (_norm(title), year or '', media_type), [matched[0].get('id')], 7 * 24 * 3600)
        t = matched[0].get('title') or {}
        for n in [t.get('romaji'), t.get('english')] + list(matched[0].get('synonyms') or [])[:3]:
            if n and _norm(n) not in [_norm(x) for x in names]:
                names.append(n)
    _cache.set(ck, names or [], 7 * 24 * 3600)
    return names


def is_anime(title, year=None, media_type='tv'):
    return bool(titles(title, year, media_type))


# ── Turning a release name into "is this the film / episode asked for" ─────────

_RE_SXXEXX = re.compile(r'\bs(?:eason)?[ ._-]*0*(\d{1,2})[ ._-]*e(?:p(?:isode)?)?[ ._-]*0*(\d{1,3})(?!\d)', re.I)
_RE_SEASON = re.compile(r'(?:\bs0*(\d{1,2})(?!\d|[ex])|\bseason[ ._-]*0*(\d{1,2})|\b(\d{1,2})(?:st|nd|rd|th)[ ._-]*season)', re.I)
_RE_RANGE = re.compile(r'(?<!\d)0*(\d{1,3})\s*[-~]\s*0*(\d{1,3})(?!\d)')
_BATCH = re.compile(r'batch|complete|\bseason\b|\bfull\b|bd\s*box|bdrip.*\bs\d', re.I)


def _season_of(name):
    m = _RE_SEASON.search(name)
    if not m:
        return None
    return int(next(g for g in m.groups() if g))


_FLUFF = {'tv', 'the', 'animation', 'anime', 'dub', 'dubbed', 'dual', 'audio', 'multi', 'sub', 'subs', 'eng', 'english', 'uncensored',
          'bd', 'bdrip', 'remux', 'hevc', 'web', 'dl', 'batch', 'complete', 'ova', 'raw', 'jpn', 'jp'}
_RE_BEFORE_EP = re.compile(r'\s[-' + chr(0x2013) + r']\s*0*\d{1,3}(?:v\d)?(?:\s|\[|\(|\.|$)')
_RE_GLUED_SEASON = re.compile(r'[a-z]S0*([2-9]|1\d)\b')


def _later_cour(clean_name, wanted_names):
    """True for a release of a later season of the show that carries no season number: 'Show: Arc Name - 03' or 'ShowS2 - 03'
    asked for season 1 (its episode 03 is the season's own third episode, not the first season's)."""
    if _RE_GLUED_SEASON.search(clean_name):
        return True
    m = _RE_BEFORE_EP.search(clean_name)
    if not m:
        return False
    base = _norm(re.split(r'\s[\[(]', clean_name[:m.start()])[0])
    for w in wanted_names:
        w = _norm(w)
        if w and base.startswith(w):
            known = set(' '.join(_norm(x) for x in wanted_names).split())          # the show's other name (romaji + English) is no arc name
            rest = base[len(w):].split()
            return any(x not in _FLUFF and x not in known and not x.isdigit() for x in rest)
    return False



def _accept(name, wanted_names, media_type, season, episode):
    n = _norm(name)
    # the show / film name, in any of its spellings
    n_clean = re.sub(r'^(?:(?:\[[^\]]*\]|\([^)]*\))\s*)+', '', name).strip()
    n_cmp = _norm(n_clean)
    if not any(_norm(w) and _norm(w) in n_cmp for w in wanted_names):
        return False
    if media_type != 'tv' or episode is None:
        return True
    s_want, e_want = int(season or 1), int(episode)
    m = _RE_SXXEXX.search(name)
    if m:
        return int(m.group(2)) == e_want and (int(m.group(1)) == s_want)
    s_found = _season_of(name)
    if s_found is not None and s_found != s_want:
        return False
    if s_want == 1 and _later_cour(n_clean, wanted_names):
        return False
    if s_found is None and s_want > 1:
        # "Show - 25": absolute numbering of a later season - only trust it when it is clearly beyond the first season's length
        pass
    for a, b in _RE_RANGE.findall(name):
        a, b = int(a), int(b)
        if a < b and a <= e_want <= b and (b - a >= 2 or _BATCH.search(name)):
            return True
    after = re.sub(r'\b(?:19|20)\d{2}\b', ' ', name)
    after = re.sub(r'\b\d{3,4}p\b|\b(?:x|h)\.?26[45]\b|\b\d+bit\b|\b\d+kbps\b|\b[0-9a-f]{8}\b', ' ', after, flags=re.I)
    return bool(re.search(r'(?<![\d.])0*%d(?:v\d)?(?![\d.]|\s*(?:p|bit|kbps|mb|gb))' % e_want, after))


# ── result building ───────────────────────────────────────────────────────────

def _hash_of(magnet_or_hash):
    m = re.search(r'btih:([A-Za-z0-9]{32,40})', magnet_or_hash or '') or re.match(r'^([A-Za-z0-9]{32,40})$', magnet_or_hash or '')
    if not m:
        return ''
    h = m.group(1)
    if len(h) == 32:                                    # base32 form
        try:
            return base64.b32decode(h.upper()).hex()
        except Exception:
            return ''
    return h.lower()


def _result(name, ih, seeds, size, source, magnet=''):
    if not ih or not name:
        return None
    return {'title': name, 'year': '', 'quality': _ts._extract_quality(name) if _ts else '', 'info_hash': ih,
            'magnet': magnet if magnet.startswith('magnet:') else (_ts._make_magnet(ih, name) if _ts else 'magnet:?xt=urn:btih:%s' % ih),
            'seeds': int(seeds or 0), 'size': size or '', 'source': source, 'anime': True}


def _nyaa(q):
    xml = _get('https://nyaa.si/?page=rss&q=%s&c=1_0&s=seeders&o=desc' % quote_plus(q))
    out = []
    for item in re.findall(r'<item>(.*?)</item>', xml, re.S):
        t = re.search(r'<title>(?:<!\[CDATA\[)?(.*?)(?:\]\]>)?</title>', item, re.S)
        h = re.search(r'<nyaa:infoHash>([A-Fa-f0-9]{40})</nyaa:infoHash>', item)
        s = re.search(r'<nyaa:seeders>(\d+)</nyaa:seeders>', item)
        z = re.search(r'<nyaa:size>([^<]+)</nyaa:size>', item)
        r = _result(_html.unescape(t.group(1).strip()) if t else '', h.group(1).lower() if h else '', s.group(1) if s else 0,
                    z.group(1) if z else '', 'Nyaa')
        if r:
            out.append(r)
    return out


def _animetosho(q):
    page = _get('https://animetosho.org/search?q=%s' % quote_plus(q))
    out = []
    for ent in page.split('home_list_entry')[1:]:
        t = re.search(r'<div class="link"><a href="[^"]*">(.*?)</a></div>', ent, re.S)
        m = re.search(r'href="(magnet:\?[^"]+)"', ent)
        s = re.search(r'Seeders:\s*(\d+)', ent)
        z = re.search(r'<div class="size"[^>]*>([^<]+)</div>', ent)
        if not (t and m):
            continue
        magnet = _html.unescape(m.group(1))
        r = _result(_html.unescape(re.sub(r'<[^>]+>', '', t.group(1))).strip(), _hash_of(magnet), s.group(1) if s else 0,
                    z.group(1).strip() if z else '', 'AnimeTosho', magnet)
        if r:
            out.append(r)
    return out


def _subsplease(q):
    import json
    raw = _get('https://subsplease.org/api/?f=search&tz=UTC&s=%s' % quote_plus(q))
    try:
        data = json.loads(raw) if raw else {}
    except ValueError:
        return []
    out = []
    for rel in (data.values() if isinstance(data, dict) else []):
        for d in rel.get('downloads') or []:
            mg = d.get('magnet') or ''
            qs = parse_qs(mg.split('?', 1)[-1])
            name = unquote((qs.get('dn') or [''])[0]) or '[SubsPlease] %s - %s (%sp)' % (rel.get('show'), rel.get('episode'), d.get('res'))
            xl = (qs.get('xl') or [''])[0]
            size = '%.2f GB' % (int(xl) / 1e9) if xl.isdigit() else ''
            r = _result(name, _hash_of(mg), 0, size, 'SubsPlease', mg)
            if r:
                out.append(r)
    return out


def _tokyotosho(q):
    xml = _get('https://www.tokyotosho.info/rss.php?terms=%s&type=1' % quote_plus(q), timeout=9)
    out = []
    for item in re.findall(r'<item>(.*?)</item>', xml, re.S):
        t = re.search(r'<title>(?:<!\[CDATA\[)?(.*?)(?:\]\]>)?</title>', item, re.S)
        m = re.search(r'href="(magnet:\?[^"]+)"', item)
        z = re.search(r'Size:\s*([0-9.,]+\s*[KMGT]?i?B)', item)
        if not (t and m):
            continue
        r = _result(_html.unescape(t.group(1)).strip(), _hash_of(m.group(1)), 0, z.group(1) if z else '', 'TokyoTosho',
                    _html.unescape(m.group(1)))
        if r:
            out.append(r)
    return out


def _acgnx(q):
    xml = _get('https://www.acgnx.se/rss.xml?keyword=%s' % quote_plus(q))
    out = []
    for item in re.findall(r'<item>(.*?)</item>', xml, re.S):
        t = re.search(r'<title>(?:<!\[CDATA\[)?(.*?)(?:\]\]>)?</title>', item, re.S)
        m = re.search(r'<enclosure url="(magnet:\?[^"]+)"', item)
        z = re.search(r'\|\s*([0-9.,]+\s*[KMGT]?i?B)\s*\|', item)
        if not (t and m):
            continue
        r = _result(_html.unescape(t.group(1)).strip(), _hash_of(_html.unescape(m.group(1))), 0, z.group(1) if z else '', 'AcgnX',
                    _html.unescape(m.group(1)))
        if r:
            out.append(r)
    return out


def _size_text(n):
    try:
        n = float(n)
    except (TypeError, ValueError):
        return ''
    return '%.2f GB' % (n / 1073741824.0) if n >= 1073741824 else '%.0f MB' % (n / 1048576.0)


def _nekobt(q):
    """nekoBT's own search API (the one its search page calls): JSON with magnet, seeders and size."""
    import json
    raw = _get('https://nekobt.to/api/v1/torrents/search?query=%s' % quote_plus(q), timeout=7)
    try:
        rows = ((json.loads(raw) if raw else {}).get('data') or {}).get('results') or []
    except ValueError:
        return []
    out = []
    for t in rows:
        if t.get('deleted') or t.get('hidden'):
            continue
        r = _result(t.get('title') or '', (t.get('infohash') or '').lower(), t.get('seeders'), _size_text(t.get('filesize')), 'nekoBT',
                    t.get('magnet') or '')
        if r:
            out.append(r)
    return out


def _tsukihime(q):
    """TsukiHime's public API (api.tsukihime.org/v1/search/torrents): an index of Nyaa, nekoBT and TokyoTosho releases with their hashes."""
    import json
    raw = _get('https://api.tsukihime.org/v1/search/torrents?q=%s&limit=60' % quote_plus(q), timeout=7)
    try:
        rows = (json.loads(raw) if raw else {}).get('results') or []
    except ValueError:
        return []
    out = []
    for t in rows:
        r = _result(t.get('name') or '', (t.get('btih') or '').lower(), 0, _size_text(t.get('totalsize')), 'TsukiHime')
        if r:
            out.append(r)
    return out


_RE_EP_IN_FILE = re.compile(r'\s*[-_]?\s*(?:S\d{1,2}E\d{1,3}|E\d{1,3}|\d{2,3})(?=\s*[\[(.]|\s*$)', re.I)


def _seadex(al_ids):
    """SeaDex (releases.moe) hand-picks the best release of a finished show - mostly BD batches on Nyaa. One entry per AniList id."""
    import json
    out = []
    for al in al_ids:
        raw = _get('https://releases.moe/api/collections/entries/records?filter=%s&expand=trs&perPage=1' % quote_plus('(alID=%s)' % al), timeout=7)
        try:
            items = (json.loads(raw) if raw else {}).get('items') or []
        except ValueError:
            continue
        for it in items:
            for tr in (it.get('expand') or {}).get('trs') or []:
                ih = (tr.get('infoHash') or '').lower()
                if not re.match(r'^[0-9a-f]{40}$', ih):                     # private-tracker entries carry no public hash
                    continue
                files = tr.get('files') or []
                if not files:
                    continue
                main = max(files, key=lambda f: int(f.get('length') or 0))        # the episodes, not the creditless / extras files
                base = re.sub(r'\.[A-Za-z0-9]{2,4}$', '', main.get('name', '').rsplit('/', 1)[-1])
                base = _RE_EP_IN_FILE.sub('', base, count=1).strip()
                n = len(files)
                size = sum(int(f.get('length') or 0) for f in files)
                tags = ' '.join(x for x in ('Dual Audio' if tr.get('dualAudio') else '', 'Best' if tr.get('isBest') else 'Alt') if x)
                grp = '' if base.startswith('[') else '[%s] ' % (tr.get('releaseGroup') or 'SeaDex')
                name = '%s%s [SeaDex %s]%s' % (grp, base, tags, (' Batch 01-%02d' % n) if n > 1 else '')
                r = _result(name, ih, 40 if tr.get('isBest') else 15, _size_text(size), 'SeaDex')
                if r:
                    out.append(r)
    return out


_SITES = (('nyaa', _nyaa), ('animetosho', _animetosho), ('subsplease', _subsplease), ('tokyotosho', _tokyotosho), ('acgnx', _acgnx),
          ('nekobt', _nekobt), ('tsukihime', _tsukihime))


def _queries(names, media_type, season, episode):
    qs = []
    for n in names[:2]:
        n = re.sub(r'[^\w\s\-\']', ' ', n).strip()
        if media_type == 'tv' and episode is not None:
            qs.append('%s %02d' % (n, int(episode)))
            if season and int(season) > 1:
                qs.append('%s S%d %02d' % (n, int(season), int(episode)))
        else:
            qs.append(n)
    return list(dict.fromkeys(qs))


def search(title, year=None, media_type='movie', season=None, episode=None, timeout=4.5):
    names = titles(title, year, media_type)
    if not names:
        return []
    qs = _queries(names, media_type, season, episode)
    jobs = [(k, fn, q) for k, fn in _SITES if _on(k) for q in qs]
    ids = _cache.get('anime_ids_v1_%s_%s_%s' % (_norm(title), year or '', media_type)) or []
    if ids and _on('seadex') and (media_type == 'movie' or not season or int(season) <= 1):
        jobs.append(('seadex', lambda _q, _ids=ids: _seadex(_ids), 'seadex'))
    if not jobs:
        return []
    ex = ThreadPoolExecutor(max_workers=min(len(jobs), 12))
    futs = {ex.submit(fn, q): (k, q) for k, fn, q in jobs}
    done, _pending = _wait(list(futs), timeout=timeout)
    ex.shutdown(wait=False)
    results, seen, per = [], set(), {}
    for f in done:
        try:
            got = f.result() or []
        except Exception as e:
            xbmc.log('[Starfleet/Anime] %s failed: %s' % (futs[f][0], e), xbmc.LOGWARNING)
            continue
        for r in got:
            if r['info_hash'] in seen or not _accept(r['title'], names, media_type, season, episode):
                continue
            seen.add(r['info_hash'])
            results.append(r)
            per[futs[f][0]] = per.get(futs[f][0], 0) + 1
    xbmc.log('[Starfleet/Anime] %s: %d releases %s' % (title, len(results), per), xbmc.LOGINFO)
    results.sort(key=lambda r: r['seeds'], reverse=True)
    return results
