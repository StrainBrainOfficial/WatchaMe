# -*- coding: utf-8 -*-
"""VR releases (180 / 360 degree video for a headset, side-by-side or over-under, fisheye).

The "VR content" switch (setting vr_enabled, off by default) decides whether searches look for VR releases and list them: with it off
every VR release is left out of the source lists, with it on a second search for the title plus "VR" runs, the Adult menu gets a VR
section (browse()), and each VR release is labelled with its format so the player knows how it is to be shown."""
import re
import time

from starfleetscrapers import host as _sfhost

# VR studios whose releases carry no "VR" word in the file name's layout words (the studio name itself says it)
_STUDIOS = (r'vrbangers|vrallure|vrhush|vrconk|vrpornvideos|vrcosplayx|vrspy|vrsexlab|wankzvr|badoinkvr|virtualrealporn|virtualrealtrans|'
            r'virtualrealgay|virtualrealamateur|virtualtaboo|fuckpassvr|czechvr\w*|naughtyamericavr|stripzvr|realjamvr|tmwvrnet|'
            r'sexlikereal|povr|18vr|lethalhardcorevr|holivr|darkroomvr|tonightsgirlfriendvr|realityloversvr|vrcosplay\w*|evilangelvr|'
            r'milfvr|swallowbay|hologirlsvr|vrintimacy|sinsvr|jimmydrawsvr|analvr|bravovr|vrlatina|vrpfilms')
_VR_RX = re.compile(r'(?<![a-z0-9])(' + '|'.join((
    r'vr[-_. ]?(?:180|360|200)', r'(?:180|200|360)[-_. ]?(?:lr|sbs|tb|ou)', r'(?:lr|sbs|tb|ou)[-_. ]?(?:180|200|360)', r'mkx[-_. ]?200',
    r'fish[-_. ]?eye\d*', r'virtual[-_. ]?reality', r'vr', r'3d[hv]', _STUDIOS)) +
    r')(?![a-z0-9])', re.I)
_PROJ = re.compile(r'(?<![a-z0-9])(?:vr[-_. ]?)?(180|200|360)(?![0-9])', re.I)
_FISH = re.compile(r'fish[-_. ]?eye|mkx[-_. ]?200', re.I)
_SBS = re.compile(r'(?<![a-z0-9])(?:lr|sbs|3dh|side[-_. ]?by[-_. ]?side)(?![a-z0-9])', re.I)
_OU = re.compile(r'(?<![a-z0-9])(?:tb|ou|3dv|top[-_. ]?(?:and[-_. ]?)?bottom|over[-_. ]?under)(?![a-z0-9])', re.I)

# searches of the Adult VR section (and what a VR search adds): the words releases use, then the VR studios
BROWSE_QUERIES = ('vr180', 'vr360', 'virtual reality', 'vrbangers', 'wankzvr', 'badoinkvr', 'virtualrealporn', 'fuckpassvr', 'czechvr',
                  'naughtyamericavr', 'stripzvr', 'vrhush', 'vrallure', 'vrconk', 'realjamvr', 'sexlikereal')


def enabled():
    try:
        return (_sfhost.addon().getSetting('vr_enabled') or '').strip().lower() == 'true'
    except Exception:
        return False


def is_vr(name):
    return bool(_VR_RX.search(name or ''))


def mode(name):
    """'' (not VR), else (projection, stereo): projection '180' / '200' / '360' / 'fisheye' / '' (not named), stereo 'sbs' / 'ou' / ''."""
    n = name or ''
    if not is_vr(n):
        return ''
    if _FISH.search(n):
        proj = 'fisheye'
    else:
        m = _PROJ.search(n)
        proj = m.group(1) if m else ''
    stereo = 'sbs' if _SBS.search(n) else ('ou' if _OU.search(n) else '')
    return proj, stereo


def label(name):
    """The tag shown in the source list: 'VR180 SBS', 'VR360 OU', 'VR fisheye SBS', 'VR' ... or ''."""
    md = mode(name)
    if not md:
        return ''
    proj, stereo = md
    head = 'VR fisheye' if proj == 'fisheye' else ('VR' + proj if proj else 'VR')
    return (head + (' ' + stereo.upper() if stereo else '')).strip()


def torrent_name(torrent):
    n = torrent.get('title') or torrent.get('name') or ''
    if n:
        return n
    try:
        import urllib.parse as _ul
        return _ul.parse_qs(_ul.urlparse(torrent.get('magnet', '')).query).get('dn', [''])[0]
    except Exception:
        return ''


def browse(limit=120):
    """The VR releases the torrent sources list now (XXXClub first), newest and best seeded first: what the Adult VR section shows. Kept for 15 minutes."""
    from concurrent.futures import ThreadPoolExecutor, as_completed
    from starfleetscrapers.debrid import torrent_sources as ts
    try:
        from starfleetscrapers.core import cache as _cache
    except Exception:
        _cache = None
    key = 'vr_browse_v1'
    if _cache is not None:
        try:
            hit = _cache.get(key)
            if hit:
                return hit[:limit]
        except Exception:
            pass
    jobs = []
    pool = ThreadPoolExecutor(max_workers=8)
    try:
        for q in BROWSE_QUERIES:
            jobs.append(pool.submit(ts.search_xxxclub, q, None, 20, 'adult'))
        for q in ('vr180', 'virtual reality'):
            jobs.append(pool.submit(ts.search_tpb, q, None, 500, 15, 'adult'))
            jobs.append(pool.submit(ts.search_knaben, q, None, 'adult', 30))
        out, seen = [], set()
        deadline = time.time() + 25
        try:
            for f in as_completed(jobs, timeout=25):
                try:
                    for r in f.result() or []:
                        ih = (r.get('info_hash') or '').lower()
                        if not ih or ih in seen or not is_vr(torrent_name(r)):
                            continue
                        seen.add(ih)
                        out.append(r)
                except Exception:
                    pass
                if time.time() > deadline:
                    break
        except Exception:
            pass
    finally:
        pool.shutdown(wait=False)
    first = {'XXXClub': 0, 'Rintor': 1, 'XXXTor': 2}
    out.sort(key=lambda r: (first.get(r.get('source'), 3), -(r.get('seeds') or 0)))
    if _cache is not None and out:
        try:
            _cache.set(key, out, 900)
        except Exception:
            pass
    return out[:limit]
