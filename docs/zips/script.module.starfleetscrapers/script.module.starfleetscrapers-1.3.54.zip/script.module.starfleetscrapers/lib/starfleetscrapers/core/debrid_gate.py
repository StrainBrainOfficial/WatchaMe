# -*- coding: utf-8 -*-
"""Which source families may run.

Free sources (hosters, embed players, direct playlists, Internet Archive...) always run. Debrid sources (torrents, NZB, release-site
hoster rows, the viewer's own debrid cloud libraries) only run while a debrid service is switched on. Torrents are also allowed
while the host's "use Elementum when no debrid service is set up" option is on, because Elementum plays a magnet without debrid.
"""
import time

_CACHE = {'t': 0.0, 'debrid': None}
_TTL = 3.0


def _resolvers():
    from starfleetscrapers import host as _sfhost
    return _sfhost.module('resolvers')


def debrid_on():
    """True when any debrid service is switched on and set up (the host's answer; a failed check counts as on, so nothing is
    silently dropped)."""
    now = time.time()
    if _CACHE['debrid'] is not None and now - _CACHE['t'] < _TTL:
        return _CACHE['debrid']
    try:
        v = bool(_resolvers().any_debrid_enabled())
    except Exception:
        v = True
    _CACHE['t'], _CACHE['debrid'] = now, v
    return v


def elementum_on():
    try:
        fn = getattr(_resolvers(), 'elementum_enabled', None)
        return bool(fn()) if callable(fn) else False
    except Exception:
        return False


def torrents_allowed():
    """Torrent / magnet search: with a debrid service, or when Elementum is the no-debrid player."""
    return debrid_on() or elementum_on()
