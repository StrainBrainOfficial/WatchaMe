# -*- coding: utf-8 -*-
"""
core/http.py - the one place the scrapers get an HTTP connection from.

    get / post / head / put / delete / request(...)   drop-in for requests.get / requests.post / ...
    session()                                          the shared session behind them
    new_session()                                      a session of its own with the same fast set-up (for code that wants cookies)

What it does that a bare requests.get() does not:

  * ONE TLS context for every connection. requests/urllib3 build a fresh context for each new connection and re-read the whole CA
    bundle into it (about 0.3 s of CPU on a PC, several times that on a Fire TV Stick). A search that opens dozens of connections paid
    that dozens of times. Certificates and host names are still checked.
  * Connections are kept and reused (keep-alive) by the thread that opened them, so a source asked twice (a title page, then its
    stream list) does not do a second TCP + TLS set-up.
  * Cookies live only for the length of one call (redirects inside a call still carry them, as with a bare requests.get()) and are
    dropped afterwards, so one site's cookies never reach another.
  * A host that cannot be reached at all (connect timeout, refused, no DNS) is skipped for three minutes after it failed three times in
    a row, so a dead site costs one short wait instead of a full timeout on every click. A host that answers slowly is never counted.

It is safe for add-ons that load this module: nothing global is patched. The module also stands in for `requests` where the scrapers
import it (`from starfleetscrapers.core import http as requests`): get / post / head / put / delete / request / Session are replaced,
everything else (exceptions, utils, adapters, codes...) is requests' own.
"""
import os
import ssl
import threading
import time
from urllib.parse import urlparse

import requests
from requests.adapters import HTTPAdapter

_PLAIN = os.environ.get('STARFLEET_PLAIN_HTTP') == '1'     # switch the layer off (for comparing, or if it ever misbehaves)
_lock = threading.Lock()
_local = threading.local()
_ctx = None

_FAILS = 3                 # connection failures in a row before a host is skipped
_FAIL_WINDOW = 90          # ... within this many seconds
_DOWN_SECS = 180
_state = {}                # host -> [consecutive failures, first failure time, down until]


def _context():
    global _ctx
    if _ctx is None:
        with _lock:
            if _ctx is None:
                ctx = ssl.create_default_context()
                try:
                    ctx.load_verify_locations(cafile=requests.certs.where())
                except Exception:
                    pass
                _ctx = ctx
    return _ctx


class _FastAdapter(HTTPAdapter):
    def init_poolmanager(self, *a, **k):
        k['ssl_context'] = _context()
        super(_FastAdapter, self).init_poolmanager(*a, **k)

    def cert_verify(self, conn, url, verify, cert):
        conn.cert_reqs = 'CERT_REQUIRED' if url.lower().startswith('https') else 'CERT_NONE'
        conn.ca_certs = None                                 # the shared context already holds them: nothing is read again
        conn.ca_cert_dir = None


def _build():
    s = requests.Session()
    try:
        s.mount('https://', _FastAdapter(pool_connections=64, pool_maxsize=64, max_retries=0))
    except Exception:
        s.mount('https://', HTTPAdapter(pool_connections=64, pool_maxsize=64, max_retries=0))
    s.mount('http://', HTTPAdapter(pool_connections=64, pool_maxsize=64, max_retries=0))
    return s


def new_session():
    """A session of its own (it keeps cookies) with the shared TLS set-up."""
    return _build()


Session = new_session


def _plain_session():
    """For the rare call that turns certificate checking off (verify=False) or sends a client certificate: urllib3's own set-up."""
    s = getattr(_local, 'p', None)
    if s is None:
        s = _local.p = requests.Session()
    return s


def session():
    """This thread's session (one per thread: a requests session is not meant to be shared by threads that redirect at once)."""
    s = getattr(_local, 's', None)
    if s is None:
        s = _local.s = _build()
    return s


def _host(url):
    try:
        return urlparse(url).netloc.lower()
    except Exception:
        return ''


def host_down(url):
    """True while a host is being skipped (see above)."""
    st = _state.get(_host(url))
    return bool(st and st[2] > time.time())


def _note(host, ok):
    if not host:
        return
    if ok:
        _state.pop(host, None)
        return
    now = time.time()
    st = _state.get(host)
    if not st or now - st[1] > _FAIL_WINDOW:
        st = [0, now, 0]
    st[0] += 1
    if st[0] >= _FAILS:
        st[2] = now + _DOWN_SECS
        st[0], st[1] = 0, now
    _state[host] = st
    if len(_state) > 400:
        for k in [k for k, v in _state.items() if v[2] < now and now - v[1] > _FAIL_WINDOW]:
            _state.pop(k, None)


def request(method, url, **kw):
    if _PLAIN:
        return requests.request(method, url, **kw)
    host = _host(url)
    if host_down(url):
        raise requests.exceptions.ConnectionError('%s was unreachable a moment ago (skipped for a few minutes)' % host)
    s = _plain_session() if (kw.get('verify') is False or kw.get('cert')) else session()
    try:
        r = s.request(method, url, **kw)
    except (requests.exceptions.ConnectTimeout, requests.exceptions.ConnectionError) as e:
        # only a host that cannot be connected to counts: a TLS error or an interrupted transfer says nothing about it being down
        text = str(e)
        if not isinstance(e, requests.exceptions.SSLError) and 'Read timed out' not in text and 'RemoteDisconnected' not in text                 and 'Connection aborted' not in text:
            _note(host, False)
        raise
    finally:
        s.cookies.clear()                                    # cookies last for one call, as with a bare requests.get()
    _note(host, True)
    return r


def get(url, params=None, **kw):
    kw.setdefault('allow_redirects', True)
    return request('GET', url, params=params, **kw)


def post(url, data=None, json=None, **kw):
    return request('POST', url, data=data, json=json, **kw)


def head(url, **kw):
    kw.setdefault('allow_redirects', False)
    return request('HEAD', url, **kw)


def put(url, **kw):
    return request('PUT', url, **kw)


def delete(url, **kw):
    return request('DELETE', url, **kw)


def __getattr__(name):
    """Anything not replaced above (exceptions, utils, adapters, codes, Response...) is requests' own."""
    return getattr(requests, name)
