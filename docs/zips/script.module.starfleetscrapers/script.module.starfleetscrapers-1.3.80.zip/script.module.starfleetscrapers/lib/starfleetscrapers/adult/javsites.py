# -*- coding: utf-8 -*-
"""More JAV streaming sites with the same three-function shape as javhd / javseen / javleak / mythav:

    browse_<site>_latest(page)        -> [{'id', 'slug', 'title', 'thumb', 'source'}...]
    get_<site>_detail(vid, slug)      -> {'fanart', 'description'}
    resolve_<site>_stream(vid, slug)  -> a playable address, or ''

Sites: jav.guru (javguru), javgiga.com (javgiga), 7mmtv.sx (jav7mm), ikisoda.com (ikisoda), javbangers.com (javbangers),
bestjavporn.com (bestjav) and 91porn.com (porn91). Every list is the site's own newest-first listing. Playback hands the embed hosts a
title offers to javcommon.first_playable() and, when none plays, to javcode (the same product code on the other JAV sites); the sites
that serve a plain video file themselves (ikisoda, javbangers, 91porn) play it directly.

Not included: missav.ws (Cloudflare browser check), javmost.ws and bestjavporn.com (their players are AES-encrypted by scripts
that change; the same titles are reachable through the sites above by product code)."""
import base64
import html as _html
import re
from urllib.parse import quote_plus, urljoin

import xbmc

from starfleetscrapers import host as _sfhost
from starfleetscrapers.core import cache as _cache

try:
    from starfleetscrapers.debrid import torrent_sources as _ts
except Exception:                                   # pragma: no cover
    _ts = None

PAGE_TTL = 15 * 60
_HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36',
    'Accept-Language': 'en-US,en;q=0.9',
}
_AD_HOSTS = ('mayzaent', 'whitetrafsa', 'realsrv', 'labadena', 'doubleclick', 'googletag', 'facebook', 'twitter', 'histats',
             'pemsrv', 'magsrv', 'exoclick', 'juicyads', 'cloudflare', 'gstatic', 'google', 'jquery', 'schema.org', 'w3.org',
             'gravatar', 'wp.com', 'sexjavhd.site', 'livexcams', '19sex.live')


def _get(url, referer='', timeout=12, session=None):
    try:
        s = session or (_ts._sess() if _ts else None)
        if s is None:
            from starfleetscrapers.core import http as requests
            s = requests
        h = dict(_HEADERS)
        if referer:
            h['Referer'] = referer
        r = s.get(url, headers=h, timeout=timeout, allow_redirects=True)
        if r.status_code != 200:
            return '', r.url
        return r.text, r.url
    except Exception as e:
        xbmc.log('[Starfleet/JAV] %s: %s' % (url[:60], e), xbmc.LOGINFO)
        return '', url


def _clean(t):
    t = re.sub(r'&quots\b', "'s", t or '')                        # 7mmtv writes an apostrophe-s as "&quots"
    t = re.sub(r'&quot(?!;)', '"', t)
    return re.sub(r'\s+', ' ', _html.unescape(re.sub(r'<[^>]+>', '', t))).strip()


def _is_ad(u):
    u = u.lower()
    return any(h in u for h in _AD_HOSTS)


def _first_page_items(parse_fn, urls, key):
    ck = '%s_%s' % (key, '|'.join(urls))
    cached = _cache.get(ck)
    if cached is not None:
        return cached or []
    items = []
    for u in urls:
        html, _final = _get(u)
        if html:
            items += parse_fn(html)
    _cache.set(ck, items or False, PAGE_TTL)
    return items


# ── jav.guru ──────────────────────────────────────────────────────────────────

_GURU = 'https://jav.guru'
_RE_GURU = re.compile(r'<div class="imgg">\s*<a href="(https://jav\.guru/(\d+)/([^"/]+)/)">.*?<img\s+src="([^"]+)"\s+alt="([^"]*)"', re.S)


def _guru_parse(html):
    out, seen = [], set()
    for url, vid, slug, thumb, alt in _RE_GURU.findall(html):
        if vid in seen:
            continue
        seen.add(vid)
        out.append({'id': vid, 'slug': slug, 'title': _clean(alt) or slug, 'thumb': thumb, 'poster': thumb, 'fanart': thumb})
    return out


def _guru_candidates(vid, slug):
    url = '%s/%s/%s/' % (_GURU, vid, slug)
    html, _f = _get(url)
    if not html:
        return []
    out = []
    # every server button carries a base64 gateway address; the gateway page hides the real host behind three reversed hex parts
    for b in dict.fromkeys(re.findall(r'"iframe_url":"([A-Za-z0-9+/=]+)"', html)):
        try:
            gate = base64.b64decode(b + '=' * (-len(b) % 4)).decode('utf-8', 'ignore')
        except Exception:
            continue
        if not gate.startswith('http'):
            continue
        page, _final = _get(gate, referer=url)
        attrs = re.findall(r'data-[a-z0-9]{5}="([0-9a-f]+)"', page)
        base = re.search(r"base:\s*'([^']+)'", page)
        rtype = re.search(r"rtype:\s*'([^']+)'", page)
        if len(attrs) < 3 or not base or not rtype:
            continue
        real = '%s?%sr=%s' % (base.group(1), rtype.group(1), ''.join(attrs[:3])[::-1])
        _body, final = _get(real, referer=gate, timeout=10)           # redirects to the host's own embed page
        if final and final.startswith('http') and 'jav.guru' not in final:
            out.append(final)
    return out


# ── javgiga.com ───────────────────────────────────────────────────────────────

_GIGA = 'https://javgiga.com'
_RE_GIGA_ART = re.compile(r'<article\b(.*?)</article>', re.S)


def _giga_parse(html):
    out = []
    for body in _RE_GIGA_ART.findall(html):
        a = re.search(r'<a href="(https://javgiga\.com/([^"/]+)/)"[^>]*title="([^"]*)"', body)
        pid = re.search(r'data-post-id="(\d+)"', body)
        img = re.search(r'data-main-thumb="([^"]+)"', body) or re.search(r'<img[^>]+src="(https?://[^"]+)"', body)
        if not a:
            continue
        thumb = img.group(1) if img else ''
        out.append({'id': pid.group(1) if pid else '', 'slug': a.group(2), 'title': _clean(a.group(3)) or a.group(2), 'thumb': thumb,
                    'poster': thumb, 'fanart': thumb})
    return out


def _giga_candidates(vid, slug):
    url = '%s/%s/' % (_GIGA, slug)
    html, _f = _get(url)
    out = []
    for u in re.findall(r'<iframe[^>]+(?:src|data-src|data-lazy-src)="([^"]+)"', html or ''):
        if u.startswith('//'):
            u = 'https:' + u
        if u.startswith('http') and not _is_ad(u):
            out.append(u)
    return list(dict.fromkeys(out))


# ── 7mmtv.sx ──────────────────────────────────────────────────────────────────

_7MM = 'https://7mmtv.sx'
_RE_7MM = re.compile(r"<a\s+target=\"_top\"\s+href=\"(https://7mmtv\.sx/en/((?:un)?censored|amateurjav|amateur)_content/(\d+)/([^\"/]+)\.html)\"><img[^>]*data-src='([^']+)'[^>]*alt='([^']*)'")


def _7mm_parse(html):
    out, seen = [], set()
    for url, kind, vid, code, thumb, alt in _RE_7MM.findall(html):
        if (kind, vid) in seen:
            continue
        seen.add((kind, vid))
        out.append({'id': '%s:%s' % (kind, vid), 'slug': code, 'title': _clean(alt) or code, 'thumb': thumb, 'poster': thumb, 'fanart': thumb})
    return out


def _7mm_url(vid, slug):
    kind, _, num = (vid or '').partition(':')
    return '%s/en/%s_content/%s/%s.html' % (_7MM, kind or 'censored', num or vid, slug)


def _7mm_candidates(vid, slug):
    url = _7mm_url(vid, slug)
    html, _f = _get(url)
    out = []
    for u in re.findall(r'(https?://[^"\'\s<>]+/(?:v|e|embed|d)/[A-Za-z0-9_\-]{6,}[^"\'\s<>]*)', html or ''):
        if not _is_ad(u):
            out.append(u)
    for u in re.findall(r'<iframe[^>]+(?:src|data-src)="(https?://[^"]+)"', html or ''):
        if not _is_ad(u):
            out.append(u)
    return list(dict.fromkeys(out))


# ── ikisoda.com and javbangers.com (KVS sites: the video page names the mp4 files) ───────────────────────────────

_IKI = 'https://ikisoda.com'
_BANG = 'https://www.javbangers.com'
_UA = _HEADERS['User-Agent']


def _kvs_files(html, base):
    """[(height, url)] best first: the file addresses in a KVS player's flashvars (video_url / video_alt_url...), with the
    'function/0/' protection undone."""
    from starfleetscrapers.adult import tubes
    lic = re.search(r"license_code\s*:\s*['\"]([^'\"]+)", html or '')
    out = []
    for key, val in re.findall(r"(video_(?:alt_)?url\d?)\s*:\s*['\"]([^'\"]+)['\"]", html or ''):
        real = tubes._kvs_real_url(val, lic.group(1)) if lic else val
        if real and real.startswith('//'):
            real = 'https:' + real
        if real and not real.startswith('http') and real.startswith(base.split('//')[1].split('/')[0]):
            real = 'https://' + real
        if not real or not real.startswith('http') or 'get_file' not in real:
            continue
        h = re.search(r'_(\d{3,4})p\.mp4', real)
        txt = re.search(r"%s_text\s*:\s*['\"](\d{3,4})p" % key, html or '')
        out.append((int(h.group(1)) if h else (int(txt.group(1)) if txt else 480), real))
    return sorted(dict.fromkeys(out), key=lambda x: -x[0])


def _pipe(url, referer):
    from urllib.parse import quote
    return '%s|Referer=%s&User-Agent=%s' % (url, quote(referer, safe=''), quote(_UA, safe=''))


def _direct_kvs(base, page_url, referer):
    html, _f = _get(page_url, referer=referer)
    for _h, u in _kvs_files(html, base):
        got = _check_file(u, referer)
        if got:
            return got
    return ''


def _check_file(url, referer, lenient=False):
    """The address with Kodi's header suffix when the server really answers it with video (a signed file address can be refused).
    lenient: a server that cannot be reached by this check at all (the connection is closed, the certificate chain is incomplete)
    is still given to the player, which has its own network stack; an answer that is an error is never given."""
    from starfleetscrapers.core import http as requests
    try:
        r = requests.get(url, headers={'User-Agent': _UA, 'Referer': referer, 'Range': 'bytes=0-1023'}, timeout=12, stream=True)
        ok = r.status_code in (200, 206) and (r.headers.get('content-type', '').startswith(('video', 'application/octet')))
        final = r.url
        r.close()
        return _pipe(final, referer) if ok else ''
    except Exception:
        return _pipe(url, referer) if lenient else ''


_RE_IKI = re.compile(r'<a class="is-item-link is-item-link-video"\s+href="(https://ikisoda\.com/videos/([^"/]+)/)"(.{0,30000}?)</a>', re.S)


def _iki_parse(html):
    out, seen = [], set()
    for url, slug, body in _RE_IKI.findall(html):
        if slug in seen:
            continue
        seen.add(slug)
        img = re.search(r'data-(?:src|original|lazy|thumb)="(https?://[^"]+)"', body)
        alt = re.search(r'alt="([^"]*)"', body)
        ttl = re.search(r'class="[^"]*is-title[^"]*"[^>]*>\s*([^<]+)', body)
        thumb = img.group(1) if img else ''
        out.append({'id': slug, 'slug': slug, 'title': _clean(ttl.group(1) if ttl else (alt.group(1) if alt else '')) or slug.replace('-', ' ').title(),
                    'thumb': thumb, 'poster': thumb, 'fanart': thumb})
    return out


def _iki_direct(vid, slug):
    return _direct_kvs(_IKI, '%s/videos/%s/' % (_IKI, slug), _IKI + '/')


_RE_BANG = re.compile(r'<a href="(https://www\.javbangers\.com/video/(\d+)/([^"/]+))"\s+title="([^"]*)"\s+class="thumb">(.{0,6000}?)</a>', re.S)


def _bang_parse(html):
    out, seen = [], set()
    for url, vid, slug, title, body in _RE_BANG.findall(html):
        if vid in seen:
            continue
        seen.add(vid)
        img = re.search(r'data-original="([^"]+)"', body)
        thumb = img.group(1) if img else ''
        out.append({'id': vid, 'slug': slug, 'title': _clean(title) or slug, 'thumb': thumb, 'poster': thumb, 'fanart': thumb})
    return out


def _bang_direct(vid, slug):
    return _direct_kvs(_BANG, '%s/video/%s/%s' % (_BANG, vid, slug), _BANG + '/')


# ── 91porn.com (the video page holds a plain <source>) ───────────────────────────────────────────────────────────

_91 = 'https://www.91porn.com'
_RE_91 = re.compile(r'<a href="(https?://[^"]*view_video\.php\?viewkey=([0-9a-f]+))[^"]*">(.{0,1800}?)</a>', re.S)


def _91_parse(html):
    out, seen = [], set()
    for url, key, body in _RE_91.findall(html):
        if key in seen:
            continue
        seen.add(key)
        img = re.search(r'<img[^>]+src="(https?://[^"]+)"', body)
        ttl = re.search(r'class="video-title[^"]*">([^<]+)<', body)
        dur = re.search(r'class="duration">([^<]+)<', body)
        thumb = img.group(1) if img else ''
        title = _html.unescape(_clean(ttl.group(1))) if ttl else key       # the site writes its apostrophes as &amp;#39;
        out.append({'id': key, 'slug': key, 'title': title + ((' [%s]' % dur.group(1)) if dur else ''), 'thumb': thumb, 'poster': thumb, 'fanart': thumb})
    return out


def _91_direct(vid, slug):
    html, _f = _get('%s/view_video.php?viewkey=%s' % (_91, vid), referer=_91 + '/')
    for u in re.findall(r'<source[^>]+src="(https?://[^"]+)"', html or ''):
        got = _check_file(u, _91 + '/', lenient=True)
        if got:
            return got
    return ''


# ── bestjavporn.com (its players are encrypted by scripts that change: playback goes through the product code) ───

_BEST = 'https://www.bestjavporn.com'
_RE_BEST = re.compile(r'<article\b[^>]*>\s*<a href="(https://www\.bestjavporn\.com/video/([^"/]+)/)" title="([^"]*)"(.{0,2500}?)</article>', re.S)


def _best_parse(html):
    out, seen = [], set()
    for url, slug, title, body in _RE_BEST.findall(html):
        if slug in seen:
            continue
        seen.add(slug)
        img = re.search(r'data-lazy-src="(https?://[^"]+)"', body) or re.search(r'data-wpsrc="(https?://[^"]+)"', body)
        thumb = img.group(1) if img else ''
        out.append({'id': slug, 'slug': slug, 'title': _clean(title) or slug, 'thumb': thumb, 'poster': thumb, 'fanart': thumb})
    return out


# ── site table and the shared functions ───────────────────────────────────────

SITES = {
    'javguru': {'label': 'jav.guru', 'parse': _guru_parse, 'candidates': _guru_candidates,
                'pages': lambda p: ['%s/' % _GURU if p <= 1 else '%s/page/%d/' % (_GURU, p)],
                'search': lambda q: '%s/?s=%s' % (_GURU, quote_plus(q)), 'detail': lambda v, s: '%s/%s/%s/' % (_GURU, v, s)},
    'javgiga': {'label': 'javgiga.com', 'parse': _giga_parse, 'candidates': _giga_candidates,
                'pages': lambda p: ['%s/' % _GIGA if p <= 1 else '%s/page/%d/' % (_GIGA, p)],
                'search': lambda q: '%s/?s=%s' % (_GIGA, quote_plus(q)), 'detail': lambda v, s: '%s/%s/' % (_GIGA, s)},
    'jav7mm': {'label': '7mmtv.sx', 'parse': _7mm_parse, 'candidates': _7mm_candidates,
               'pages': lambda p: ['%s/en/censored_list/all/%d.html' % (_7MM, max(p, 1)), '%s/en/uncensored_list/all/%d.html' % (_7MM, max(p, 1))],
               'search': lambda q: '%s/en/searchform_search/all/index.html?search_keyword=%s' % (_7MM, quote_plus(q)),
               'detail': _7mm_url},
    'ikisoda': {'label': 'ikisoda.com', 'parse': _iki_parse, 'candidates': lambda v, s: [], 'direct': _iki_direct,
                'pages': lambda p: ['%s/videos/?sort_by=post_date%s' % (_IKI, '' if p <= 1 else '&from=%d' % p)],
                'search': lambda q: '%s/search/%s/' % (_IKI, quote_plus(q.replace('-', ' '))), 'detail': lambda v, s: '%s/videos/%s/' % (_IKI, s)},
    'javbangers': {'label': 'javbangers.com', 'parse': _bang_parse, 'candidates': lambda v, s: [], 'direct': _bang_direct,
                   'pages': lambda p: ['%s/latest-updates/%s' % (_BANG, '' if p <= 1 else '%d/' % p)],
                   'search': lambda q: '%s/search/%s/' % (_BANG, quote_plus(q)), 'detail': lambda v, s: '%s/video/%s/%s' % (_BANG, v, s)},
    'bestjav': {'label': 'bestjavporn.com', 'parse': _best_parse, 'candidates': lambda v, s: [],
                # the site moves its listings under a version prefix (/v44/...) and sends /v1/... there; page 2 and up exist only there
                'pages': lambda p: ['%s/v1/category/%s/%s' % (_BEST, c, '' if p <= 1 else 'page/%d/' % p) for c in ('censored', 'decensored')],
                'search': lambda q: '%s/?s=%s' % (_BEST, quote_plus(q)), 'detail': lambda v, s: '%s/video/%s/' % (_BEST, s)},
    'porn91': {'label': '91porn.com', 'parse': _91_parse, 'candidates': lambda v, s: [], 'direct': _91_direct,
               'pages': lambda p: ['%s/v.php?category=mr&page=%d' % (_91, max(p, 1))],
               'search': lambda q: '%s/search_result.php?search_id=%s' % (_91, quote_plus(q)), 'detail': lambda v, s: '%s/view_video.php?viewkey=%s' % (_91, v)},
}


def browse(site, page=1):
    cfg = SITES[site]
    items = _first_page_items(cfg['parse'], cfg['pages'](page), 'javsite_%s_p%d' % (site, page))
    for it in items:
        it['source'] = site
    return items


def detail(site, vid, slug):
    html, _f = _get(SITES[site]['detail'](vid, slug))
    if not html:
        return {}
    out = {}
    m = re.search(r'<meta[^>]+property="og:image"[^>]+content="([^"]+)"', html, re.I)
    if m:
        out['fanart'] = m.group(1)
    m = re.search(r'<meta[^>]+(?:property="og:description"|name="description")[^>]+content="([^"]+)"', html, re.I)
    if m:
        out['description'] = _clean(m.group(1))
    return out


def search_by_code(site, code):
    """(vid, slug) of the title with this product code on `site`, or None."""
    from starfleetscrapers.adult import javcode
    cfg = SITES[site]
    html, _f = _get(cfg['search'](code))
    for it in cfg['parse'](html or ''):
        if javcode.code_of(it['slug']) == code or javcode.code_of(it['title']) == code:
            return it['id'], it['slug']
    return None


def resolve(site, vid, slug):
    from starfleetscrapers.adult import javcommon, javcode
    direct = SITES[site].get('direct')
    if direct:
        try:
            got = direct(vid, slug)
        except Exception as e:
            xbmc.log('[Starfleet/JAV] %s direct: %s' % (site, e), xbmc.LOGINFO)
            got = ''
        if got:
            return got
    cands = SITES[site]['candidates'](vid, slug)
    got = javcommon.first_playable(cands, 'JAV-' + site) if cands else ''
    return got or javcode.resolve_by_code(slug, skip=site)


def _make(site):
    def b(page=1):
        return browse(site, page)

    def d(vid, slug):
        return detail(site, vid, slug)

    def r(vid, slug):
        return resolve(site, vid, slug)
    b.__name__, d.__name__, r.__name__ = 'browse_%s_latest' % site, 'get_%s_detail' % site, 'resolve_%s_stream' % site
    return b, d, r


for _site in SITES:
    _b, _d, _r = _make(_site)
    globals()['browse_%s_latest' % _site] = _b
    globals()['get_%s_detail' % _site] = _d
    globals()['resolve_%s_stream' % _site] = _r
