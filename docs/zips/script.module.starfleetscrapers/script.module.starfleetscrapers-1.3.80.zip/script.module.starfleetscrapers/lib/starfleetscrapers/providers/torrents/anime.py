# -*- coding: utf-8 -*-
"""Starfleet's anime sources (Nyaa, AnimeTosho, SubsPlease, TokyoTosho, AcgnX) for hosts that load a common-layout scraper module.

The title is first looked up on AniList; for anything that is not anime this returns at once. For anime, the sites are searched under
every known name of the show (romaji, English, synonyms) and only the releases of the asked episode / season / film are kept."""
from starfleetscrapers.compat.layout import to_layout


class source(object):
    priority = 1
    pack_capable = False
    hasMovies = True
    hasEpisodes = True
    language = ['en']

    def __init__(self):
        self.provider = 'anime'

    def sources(self, data, hostDict=None):
        if not data:
            return []
        tv = 'tvshowtitle' in data
        title = data.get('tvshowtitle') if tv else data.get('title')
        if not title:
            return []
        try:
            from starfleetscrapers.debrid import anime_sources
            if not anime_sources.enabled():
                return []
            season = episode = None
            if tv:
                season, episode = int(data.get('season') or 1), int(data.get('episode') or 1)
            items = anime_sources.search(title, data.get('year'), 'tv' if tv else 'movie', season, episode)
        except Exception:
            return []
        out, seen = [], set()
        for it in items or []:
            d = to_layout(it, 'anime')
            if d and d['hash'] not in seen:
                seen.add(d['hash'])
                out.append(d)
        return out

    def sources_packs(self, data, hostDict=None, search_series=False, total_seasons=None, bypass_filter=False):
        return []
