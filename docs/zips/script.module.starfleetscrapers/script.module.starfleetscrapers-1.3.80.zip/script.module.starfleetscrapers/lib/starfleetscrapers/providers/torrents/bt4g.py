# -*- coding: utf-8 -*-
"""Starfleet's bt4g source, for hosts that load a common-layout scraper module."""
from starfleetscrapers.compat.layout import make_source

source = make_source('bt4g')
