# -*- coding: utf-8 -*-
"""Which torrent sources are dead right now.

A source that keeps coming back empty while the others find plenty, or keeps missing the deadline, only slows every search
down. After SOURCE_STREAK such searches in a row it is left out for 24 hours (48 after a second time in a week); it then gets
one more chance. The three best sources (search_all's first tier) and the optional extras are never switched off here.

    record(outcomes, popular)   outcomes: {source name: 'hit' | 'empty' | 'late'}; popular: the title was one many sources know
    disabled()                  {name: seconds left}
    reset()                     back to everything on (the diagnostics button)
"""
import json
import os
import threading
import time

from starfleetscrapers import host as _host

STREAK = 6
HOURS = (24, 48)
KEEP = frozenset(('Comet', 'StremThru', 'DMM', 'Bitmagnet', 'TorrentDL', 'Anime', 'External'))
_lock = threading.Lock()
_mem = {'data': None, 'at': 0.0}


def _path():
    return os.path.join(_host.profile(), 'source_health.json')


def _load():
    now = time.time()
    if _mem['data'] is not None and now - _mem['at'] < 5:
        return _mem['data']
    try:
        with open(_path(), 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        if not isinstance(data, dict):
            data = {}
    except (OSError, ValueError):
        data = {}
    _mem['data'], _mem['at'] = data, now
    return data


def _save(data):
    _mem['data'], _mem['at'] = data, time.time()
    try:
        os.makedirs(os.path.dirname(_path()), exist_ok=True)
        with open(_path(), 'w', encoding='utf-8') as fh:
            json.dump(data, fh)
    except OSError:
        pass


def disabled():
    """{source name: seconds left} for the sources currently left out."""
    now = time.time()
    return {n: int(e['until'] - now) for n, e in _load().items() if e.get('until', 0) > now and n not in KEEP}


def record(outcomes, popular):
    """Count one search. A source with a result resets its streak; 'empty' counts only when the title is popular (an
    obscure film is empty everywhere), 'late' (still running when the search stopped waiting) always counts."""
    if not outcomes:
        return
    now = time.time()
    with _lock:
        data = dict(_load())
        changed = False
        for name, out in outcomes.items():
            if name in KEEP:
                continue
            e = dict(data.get(name) or {'streak': 0, 'until': 0, 'times': []})
            if e.get('until', 0) > now:
                continue                                      # already out: nothing to count
            if out == 'hit':
                if e.get('streak'):
                    e['streak'] = 0
                    changed = True
            elif out == 'late' or (out == 'empty' and popular):
                e['streak'] = int(e.get('streak', 0)) + 1
                changed = True
                if e['streak'] >= STREAK:
                    times = [t for t in e.get('times', []) if now - t < 7 * 86400]
                    hours = HOURS[1] if times else HOURS[0]
                    e['until'] = now + hours * 3600
                    e['times'] = times + [now]
                    e['streak'] = STREAK - 2                  # after the break, two more misses switch it off again
            else:
                continue
            data[name] = e
        if changed:
            _save(data)


def reset():
    _save({})
