# -*- coding: utf-8 -*-
"""3D releases (side-by-side, over-under, anaglyph, MVC).

The "3D content" switch (setting three_d_enabled, off by default) decides whether torrent searches look for 3D releases and
list them: with it off every 3D release is dropped from the source lists, with it on a second search for the title plus "3D"
runs and each 3D release is labelled with its format so the player can offer the right viewing mode."""
import re

from starfleetscrapers import host as _sfhost

# the format words releases use; "3D" alone (a 3D release with no layout named) counts as 3D too
_FULL_SBS = r'f(?:ull)?[-. ]?sbs'
_HALF_SBS = r'h(?:alf)?[-. ]?sbs'
_FULL_OU = r'f(?:ull)?[-. ]?(?:ou|tab)'
_HALF_OU = r'h(?:alf)?[-. ]?(?:ou|tab)'
_RX = re.compile(r'(?<![a-z0-9])(' + '|'.join((
    _FULL_SBS, _HALF_SBS, r'sbs', r'side[-. ]by[-. ]side', _FULL_OU, _HALF_OU, r'over[-. ]under', r'top[-. ]and[-. ]bottom',
    r'anaglyph[a-z]*', r'3d[-. ]?mvc', r'mvc', r'3d')) + r')(?![a-z0-9])', re.I)


def enabled():
    try:
        return (_sfhost.addon().getSetting('three_d_enabled') or '').strip().lower() == 'true'
    except Exception:
        return False


def mode(name):
    """'' (not 3D), or the layout: 'sbs' (side by side), 'ou' (over under), 'anaglyph', 'mvc', '3d' (3D, layout not named)."""
    found = set()
    for m in _RX.finditer(name or ''):
        w = re.sub(r'[-. ]', '', m.group(1).lower())
        if w.startswith('anaglyph'):
            found.add('anaglyph')
        elif 'mvc' in w:
            found.add('mvc')
        elif 'sbs' in w or 'sidebyside' in w:
            found.add('sbs')
        elif w.endswith('ou') or w.endswith('tab') or 'overunder' in w or 'topandbottom' in w:
            found.add('ou')
        else:
            found.add('3d')
    for k in ('sbs', 'ou', 'anaglyph', 'mvc', '3d'):          # the most specific word names the layout
        if k in found:
            return k
    return ''


def label(name):
    """The tag shown in the source list: '3D SBS', '3D HSBS', '3D OU', '3D' ... or ''."""
    md = mode(name)
    if not md:
        return ''
    low = (name or '').lower()
    half = bool(re.search(r'(?<![a-z0-9])h(?:alf)?[-. ]?(?:sbs|ou|tab)', low))
    full = bool(re.search(r'(?<![a-z0-9])f(?:ull)?[-. ]?(?:sbs|ou|tab)', low))
    pre = 'H' if half else ('F' if full else '')
    return {'sbs': '3D %sSBS' % pre, 'ou': '3D %sOU' % pre, 'anaglyph': '3D Anaglyph', 'mvc': '3D MVC'}.get(md, '3D')


def torrent_name(torrent):
    """The release name of a torrent dict: its title / name, or the dn= of its magnet."""
    n = torrent.get('title') or torrent.get('name') or ''
    if n:
        return n
    try:
        import urllib.parse as _ul
        return _ul.parse_qs(_ul.urlparse(torrent.get('magnet', '')).query).get('dn', [''])[0]
    except Exception:
        return ''
