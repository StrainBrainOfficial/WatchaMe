# -*- coding: utf-8 -*-
"""Reads the scrambled video addresses xHamster puts in its player settings (window.initials.xplayerSettings.sources).

An address is either a hex string, or a normal URL whose first path part is such a string. Decoded: byte 0 is the
algorithm number (1-7), bytes 1-4 the little-endian seed of a 32-bit pseudo-random generator, the rest is XOR-ed with that
generator's byte stream; the result is the address as (percent-encoded) text. The seven generators are small integer
mixers (multiply-add, xorshift, splitmix-style), written out below with explicit 32-bit wrap-around."""
import re

_M = 0xFFFFFFFF


def _imul(a, b):
    return (a * b) & _M


def _generator(algo, seed):
    st = [seed & _M]

    def lcg():
        st[0] = (_imul(st[0], 1664525) + 0x3c6ef35f) & _M
        return st[0] & 255

    def xorshift():
        x = st[0]
        x ^= (x << 13) & _M
        x ^= x >> 17
        x ^= (x << 5) & _M
        st[0] = x
        return x & 255

    def splitmix():
        st[0] = (st[0] + 0x9e3779b9) & _M
        e = st[0]
        e ^= e >> 16
        e = _imul(e, 0x85ebca77)
        e ^= e >> 13
        e = _imul(e, 0xc2b2ae3d)
        e ^= e >> 16
        return e & 255

    def mulberry():
        st[0] = (st[0] + 0x6d2b79f5) & _M
        e = ((st[0] << 7) & _M) | (st[0] >> 25)
        e = (e + 0x9e3779b9) & _M
        e ^= e >> 11
        return _imul(e, 0x27d4eb2d) & 255

    def shift_add():
        x = st[0]
        x ^= (x << 7) & _M
        x ^= x >> 9
        x ^= (x << 8) & _M
        st[0] = (x + 0xa5a5a5a5) & _M
        return st[0] & 255

    def pcg():
        st[0] = (_imul(st[0], 0x2c9277b5) + 0xac564b05) & _M
        x = st[0]
        return ((x ^ (x >> 18)) >> ((x >> 27) & 31)) & 255

    def murmur():
        st[0] = (st[0] + 0x9e3779b9) & _M
        e = st[0] ^ ((st[0] << 5) & _M)
        e = _imul(e, 0x7feb352d)
        e ^= e >> 15
        return _imul(e, 0x846ca68b) & 255

    return {1: lcg, 2: xorshift, 3: splitmix, 4: mulberry, 5: shift_add, 6: pcg, 7: murmur}[algo]


def _from_hex(s):
    if len(s) < 12 or len(s) % 2 or not re.fullmatch(r'[0-9a-fA-F]+', s):
        return None
    b = bytes.fromhex(s)
    if len(b) < 5 or b[0] not in (1, 2, 3, 4, 5, 6, 7):
        return None
    nxt = _generator(b[0], b[1] | b[2] << 8 | b[3] << 16 | b[4] << 24)
    raw = bytes((b[k] ^ nxt()) & 255 for k in range(5, len(b)))
    try:
        txt = raw.decode('utf-8')
    except UnicodeDecodeError:
        txt = raw.decode('latin-1')
    return txt if txt and re.fullmatch(r'[\x20-\x7E]+', txt) else None


def decode_address(e):
    """The readable address for a page value (unchanged when it is not scrambled)."""
    if not isinstance(e, str) or not e:
        return e
    plain = _from_hex(e)
    if plain is not None:
        return plain
    i = e.find('://')
    s = e.find('/', i + 3) if i != -1 else e.find('/')
    if s == -1 or s + 1 >= len(e):
        return None
    n = s + 1
    cuts = [x for x in (e.find('/', n), e.find(',', n)) if x != -1]
    if not cuts or min(cuts) <= n:
        return None
    end = min(cuts)
    part = _from_hex(e[n:end])
    return e[:n] + part + e[end:] if part is not None else e


def decode_sources(node):
    """Decode every 'url' / 'fallback' value inside a sources structure."""
    if isinstance(node, dict):
        return {k: (decode_address(v) if k in ('url', 'fallback') and isinstance(v, str) else decode_sources(v))
                for k, v in node.items()}
    if isinstance(node, list):
        return [decode_sources(v) for v in node]
    return node
