# -*- coding: utf-8 -*-
"""Where the scrapers keep their files. The module has its own profile folder
(special://profile/addon_data/script.module.starfleetscrapers/) and its own cache database, so it never shares a
database file with a host add-on."""
import os

import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon('script.module.starfleetscrapers')
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
try:
    os.makedirs(PROFILE, exist_ok=True)
except OSError:
    pass
