# -*- coding: utf-8 -*-
"""Speed guard for the scraper HTTP sessions.

Most of the time a search spends is not work but waiting: dead or unreachable
sites answering only after their full 10-15 s timeout, once per call, in every
search, while the results of all the healthy sources are held until the slowest
one gives up. `guard(session)` wraps a requests session so that

* the connect phase gets a short cap (a host that cannot even be connected to
  in 5 s is not going to serve a page in 10), while the read timeout callers
  asked for is left alone;
* a host that failed to connect (timeout, DNS, TLS, redirect loop) is marked
  down for a few minutes - shared across Kodi's per-action processes through
  the on-disk cache - so every other call to it, in this search and the next
  ones, fails at once instead of waiting again;
* Cloudflare "origin down" answers (521-523) are treated the same way.

A plain read timeout or a connection reset is only remembered briefly, since
those are as often load as death. HTTP 403/404/429/5xx are never held against a
host.
"""

import time
from urllib.parse import urlparse

from starfleetscrapers.core import http as requests
import xbmc

_CONNECT_CAP = 8.0

# seconds a host stays "down" after each kind of failure
_HARD = 90       # connect timeout, DNS failure, TLS failure, redirect loop (short: a busy device times out a healthy site too)
_ORIGIN = 120    # Cloudflare 521/522/523
_SOFT = 45       # read timeout, connection reset

_mem = {}        # host -> (until_epoch, reason)   (this process)
_KEY = 'ng_down_%s'


def _cache():
    try:
        from starfleetscrapers.core import cache as c
        return c
    except Exception:
        return None


def is_down(host):
    now = time.time()
    hit = _mem.get(host)
    if hit:
        if hit[0] > now:
            return True
        _mem.pop(host, None)
    c = _cache()
    if c is not None:
        try:
            until = c.get(_KEY % host)
        except Exception:
            until = None
        if until and until > now:
            _mem[host] = (until, 'cache')
            return True
    return False


def mark_down(host, seconds, reason=''):
    until = time.time() + seconds
    _mem[host] = (until, reason)
    c = _cache()
    if c is not None:
        try:
            c.set(_KEY % host, until, seconds)
        except Exception:
            pass
    xbmc.log('[Starfleet/NetGuard] %s marked down for %ds (%s)' % (host, seconds, reason), xbmc.LOGINFO)


def clear(host=None):
    """Forget marks (tests / settings)."""
    if host:
        _mem.pop(host, None)
    else:
        _mem.clear()


def _classify(exc):
    ex = requests.exceptions
    if isinstance(exc, (ex.ConnectTimeout, ex.SSLError, ex.TooManyRedirects)):
        return _HARD, type(exc).__name__
    if isinstance(exc, ex.ReadTimeout):
        return _SOFT, 'read timeout'
    if isinstance(exc, ex.ConnectionError):
        text = str(exc)
        if any(k in text for k in ('NameResolutionError', 'getaddrinfo', 'Name or service', 'Failed to resolve',
                                   'Connection refused', 'WinError 10061', 'No route to host', 'Network is unreachable')):
            return _HARD, 'unreachable'
        return _SOFT, 'connection error'
    return None, ''


def guard(session):
    """Patch `session.request` in place (idempotent) and return the session."""
    if session is None or getattr(session, '_ng_guarded', False):
        return session
    orig = session.request

    def request(method, url, *args, **kwargs):
        try:
            host = urlparse(url).netloc.lower()
        except Exception:
            host = ''
        if host and is_down(host):
            raise requests.exceptions.ConnectionError('%s is marked down (net_guard)' % host)
        t = kwargs.get('timeout')
        if isinstance(t, (int, float)) and t:
            kwargs['timeout'] = (min(float(t), _CONNECT_CAP), float(t))
        elif t is None and 'timeout' not in kwargs:
            kwargs['timeout'] = (_CONNECT_CAP, 15.0)
        try:
            resp = orig(method, url, *args, **kwargs)
        except requests.exceptions.RequestException as e:
            secs, why = _classify(e)
            if secs and host:
                mark_down(host, secs, why)
            raise
        if host and resp.status_code in (521, 522, 523):
            mark_down(host, _ORIGIN, 'HTTP %d' % resp.status_code)
        return resp

    session.request = request
    session._ng_guarded = True
    return session
