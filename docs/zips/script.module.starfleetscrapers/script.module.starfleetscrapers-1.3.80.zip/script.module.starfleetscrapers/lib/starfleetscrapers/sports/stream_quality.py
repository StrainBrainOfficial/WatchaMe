# -*- coding: utf-8 -*-
"""Quality labels (4K / 1080p / 720p / 480p / SD) for sports streams, so the stream list can show - and sort by - what each one is.

Almost no sports site states a stream's quality, so it is read from the stream itself, in a short parallel pass:
  * a playlist that lists its variants (#EXT-X-STREAM-INF) states the resolution: the best one is shown ("1080p");
  * a single-quality playlist is estimated from one segment's size and duration (a one-byte range request, nothing is
    downloaded) and marked with "~" ("~720p"), since a bitrate only suggests the resolution.
Streams that are not a playlist address (pages that are resolved when played) and the local relay are left alone, and one that
cannot be read in the time allowed simply shows no quality. Never raises.
"""
import re
import time
from concurrent.futures import ThreadPoolExecutor, wait
from urllib.parse import unquote, urljoin

from starfleetscrapers.core import http as requests
import xbmc

_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'
_TTL = 300
_cache = {}


def _split(url):
    base, _, h = url.partition('|')
    headers = {}
    for kv in h.split('&'):
        if '=' in kv:
            k, v = kv.split('=', 1)
            headers[unquote(k)] = unquote(v)
    return base, headers


def name_for_height(h):
    h = int(h)
    if h >= 2000:
        return '4K'
    if h >= 1400:
        return '1440p'
    if h >= 1000:
        return '1080p'
    if h >= 700:
        return '720p'
    if h >= 460:
        return '480p'
    return 'SD'


def name_for_bitrate(bps):
    """The resolution a live-sport bitrate usually means (an estimate)."""
    if bps >= 7.0e6:
        return '1080p'
    if bps >= 3.2e6:
        return '720p'
    if bps >= 1.3e6:
        return '480p'
    return 'SD'


def _segment_bitrate(playlist_url, text, headers, timeout):
    """bits per second of the first segment (size from a range request, duration from #EXTINF), or 0."""
    lines = text.splitlines()
    dur, uri = 0.0, ''
    for i, ln in enumerate(lines):
        m = re.match(r'#EXTINF:([\d.]+)', ln)
        if m:
            dur = float(m.group(1))
            for nxt in lines[i + 1:]:
                if nxt and not nxt.startswith('#'):
                    uri = nxt.strip()
                    break
            break
    if not uri or dur <= 0:
        return 0
    seg = urljoin(playlist_url, uri)
    rs = requests.get(seg, headers=dict(headers, Range='bytes=0-0'), timeout=timeout, stream=True)
    try:
        total = 0
        cr = rs.headers.get('Content-Range', '')
        if '/' in cr and cr.rsplit('/', 1)[1].isdigit():
            total = int(cr.rsplit('/', 1)[1])
        elif rs.status_code == 200 and (rs.headers.get('Content-Length') or '').isdigit():
            total = int(rs.headers['Content-Length'])
    finally:
        rs.close()
    return total * 8.0 / dur if total else 0


def probe(url, timeout=6):
    """'1080p' / '~720p' / '' for one playlist address (with the usual |Header=value tail)."""
    base, headers = _split(url)
    if not base.startswith('http') or '127.0.0.1' in base or 'm3u8' not in base.lower():
        return ''
    headers.setdefault('User-Agent', _UA)
    r = requests.get(base, headers=headers, timeout=timeout)
    if r.status_code != 200 or '#EXTM3U' not in r.text[:400]:
        return ''
    text = r.text
    if '#EXT-X-STREAM-INF' in text:
        heights, bands = [], []
        for ln in text.splitlines():
            if ln.startswith('#EXT-X-STREAM-INF'):
                m = re.search(r'RESOLUTION=\d+x(\d+)', ln)
                if m:
                    heights.append(int(m.group(1)))
                b = re.search(r'BANDWIDTH=(\d+)', ln)
                if b:
                    bands.append(int(b.group(1)))
        if heights:
            return name_for_height(max(heights))
        return ('~' + name_for_bitrate(max(bands))) if bands else ''
    bps = _segment_bitrate(r.url, text, headers, timeout)
    return ('~' + name_for_bitrate(bps)) if bps else ''


def _cached_probe(url, timeout):
    base = url.split('|', 1)[0]
    hit = _cache.get(base)
    if hit and time.time() - hit[0] < _TTL:
        return hit[1]
    try:
        q = probe(url, timeout)
    except Exception as e:
        xbmc.log('[Starfleet/Quality] %s: %s' % (base[:60], str(e)[:60]), xbmc.LOGDEBUG)
        q = ''
    _cache[base] = (time.time(), q)
    return q


def annotate(streams, budget=3.0, timeout=6.0, late=10.0):
    """Fill in 'quality' on the streams that have none (in place, and returned). Everything is probed side by side; the call waits
    at most `budget` seconds, so quick hosts are labelled at once, and the slower ones (some playlist servers take 5 s and more
    to answer) keep going for up to `late` more seconds and fill their label into the same stream when it arrives."""
    try:
        todo = [s for s in streams if not s.get('quality') and 'm3u8' in (s.get('url') or '').split('|', 1)[0].lower()]
        if not todo:
            return streams
        pool = ThreadPoolExecutor(max_workers=8)
        futs = [(s, pool.submit(_cached_probe, s['url'], timeout)) for s in todo]
        pool.shutdown(wait=False)

        def _apply(pairs):
            for s, f in pairs:
                if f.done() and not f.exception() and f.result() and not s.get('quality'):
                    s['quality'] = f.result()
        wait([f for _s, f in futs], timeout=budget)
        _apply(futs)
        slow = [(s, f) for s, f in futs if not f.done()]
        if slow:
            def _finish():
                wait([f for _s, f in slow], timeout=late)
                _apply(slow)
            import threading
            threading.Thread(target=_finish, daemon=True).start()
    except Exception as e:
        xbmc.log('[Starfleet/Quality] annotate: %s' % e, xbmc.LOGWARNING)
    return streams
