# -*- coding: utf-8 -*-
"""Live playlists that a site publishes over a websocket instead of as an .m3u8 file (topstreamer.site).

The game page names the websocket hosts and a channel. Connecting and sending
    {"jsonrpc":"2.0","method":"start","id":0,"params":{"connid":<uuid>,"channel":<channel>,
     "is_publisher":false,"is_cdn":false,"version":1}}
makes the service answer with a "paint" message holding {"renditions": {<name>: <media playlist text>}}: the
current playlist of every quality. The segments in it are ordinary signed https links, so once the playlist
text is in hand any player can fetch them. Ad-break segments (everything outside the CDN's /ephemeral/ path)
are removed here instead of being played.

The local relay (local_proxy) calls media_playlist() on every refresh of the playlist the player asks for, so
the stream keeps moving; freshness() lets a resolver tell a live channel from one whose last snapshot is old.
"""
import base64
import json
import os
import re
import socket
import ssl
import struct
import time
import uuid

_UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
       '(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36')


class _WS(object):
    """Just enough of RFC 6455 to read text messages from one server."""

    def __init__(self, host, path='/websocket', origin=None, timeout=8):
        sock = socket.create_connection((host, 443), timeout=timeout)
        self.sock = ssl.create_default_context().wrap_socket(sock, server_hostname=host)
        self.sock.settimeout(timeout)
        key = base64.b64encode(os.urandom(16)).decode()
        req = ('GET %s HTTP/1.1\r\nHost: %s\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n'
               'Sec-WebSocket-Key: %s\r\nSec-WebSocket-Version: 13\r\nUser-Agent: %s\r\n' % (path, host, key, _UA))
        if origin:
            req += 'Origin: %s\r\n' % origin
        self.sock.sendall((req + '\r\n').encode())
        buf = b''
        while b'\r\n\r\n' not in buf:
            chunk = self.sock.recv(4096)
            if not chunk:
                raise IOError('closed during handshake')
            buf += chunk
        head, _, self.buf = buf.partition(b'\r\n\r\n')
        if b' 101 ' not in head.split(b'\r\n')[0]:
            raise IOError('websocket handshake refused')

    def send(self, text):
        data = text.encode()
        n = len(data)
        hdr = bytearray([0x81])
        if n < 126:
            hdr.append(0x80 | n)
        elif n < 65536:
            hdr += bytes([0x80 | 126]) + struct.pack('>H', n)
        else:
            hdr += bytes([0x80 | 127]) + struct.pack('>Q', n)
        mask = os.urandom(4)
        self.sock.sendall(bytes(hdr) + mask + bytes(b ^ mask[i % 4] for i, b in enumerate(data)))

    def _read(self, n):
        while len(self.buf) < n:
            chunk = self.sock.recv(65536)
            if not chunk:
                raise IOError('closed')
            self.buf += chunk
        out, self.buf = self.buf[:n], self.buf[n:]
        return out

    def recv(self):
        msg = b''
        while True:
            b1, b2 = self._read(2)
            op, ln = b1 & 0x0F, b2 & 0x7F
            if ln == 126:
                ln = struct.unpack('>H', self._read(2))[0]
            elif ln == 127:
                ln = struct.unpack('>Q', self._read(8))[0]
            payload = self._read(ln)
            if op == 9:
                self.sock.sendall(bytes([0x8A, 0x80]) + b'\0\0\0\0')
                continue
            if op == 8:
                raise IOError('closed by server')
            msg += payload
            if b1 & 0x80:
                return msg.decode('utf-8', 'replace')

    def close(self):
        try:
            self.sock.close()
        except Exception:
            pass


def fetch_renditions(hosts, channel, origin, path='/websocket', wait=8):
    """{rendition name: playlist text} from the first host that answers, or {}."""
    for host in hosts:
        ws = None
        try:
            ws = _WS(host, path, origin, timeout=wait)
            ws.send(json.dumps({'jsonrpc': '2.0', 'method': 'start', 'id': 0,
                                'params': {'connid': str(uuid.uuid4()), 'channel': channel, 'is_publisher': False,
                                           'is_cdn': False, 'version': 1}}))
            end = time.time() + wait
            while time.time() < end:
                msg = json.loads(ws.recv())
                if msg.get('type') == 'paint' and (msg.get('result') or {}).get('renditions'):
                    return msg['result']['renditions']
        except Exception:
            pass
        finally:
            if ws:
                ws.close()
    return {}


def clean_playlist(text):
    """Drop ad-break segments (anything not under /ephemeral/); keep the tags that belong to real segments."""
    out, pending = [], []
    for line in text.splitlines():
        s = line.strip()
        if not s:
            continue
        if s.startswith('#EXTINF') or s.startswith('#EXT-X-PROGRAM-DATE-TIME') or s.startswith('#EXT-X-DISCONTINUITY') \
                and not s.startswith('#EXT-X-DISCONTINUITY-SEQUENCE'):
            pending.append(line)
        elif s.startswith('#'):
            out.append(line)
        else:
            if '/ephemeral/' in s:
                out.extend(pending)
                out.append(line)
            pending = []
    return '\n'.join(out) + '\n'


def freshness(text, now=None):
    """Seconds until the newest signed segment link expires (negative when the playlist is an old snapshot)."""
    now = now or time.time()
    exp = [int(x) for x in re.findall(r'[?&]Expires=(\d+)', text)]
    return (max(exp) - now) if exp else 0


def media_playlist(hosts, channel, origin, rendition, path='/websocket'):
    """Current cleaned media playlist for one rendition, or None when the channel is not live."""
    rends = fetch_renditions(hosts, channel, origin, path)
    text = rends.get(rendition) or rends.get(rendition.split('.')[0])
    if not text or freshness(text) <= 0:
        return None
    cleaned = clean_playlist(text)
    return cleaned if '#EXTINF' in cleaned else None
