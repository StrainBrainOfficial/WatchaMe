# -*- coding: utf-8 -*-
"""Live scores and game status for the sports lists.

The event lists are cached for several minutes, so a score baked into a title goes stale. This module keeps the title plain and
attaches the current score, clock and state ('pre' / 'in' / 'post') to each event when a list is shown, from the leagues' own
public scoreboards (one request per sport, kept 20 seconds). An event is matched to a game by both teams' names and, when both
sides know it, by start time."""
import re
import threading
import time
import unicodedata

from starfleetscrapers.core import http as requests
import xbmc

from starfleetscrapers.sports.timeparse import strptime as _strp

_API = 'https://site.api.espn.com/apis/site/v2/sports/{sport}/{league}/scoreboard'
_BOARDS = {
    'nfl':    [('football', 'nfl')],
    'nba':    [('basketball', 'nba')],
    'mlb':    [('baseball', 'mlb')],
    'nhl':    [('hockey', 'nhl')],
    'cfb':    [('football', 'college-football')],
    'ncaab':  [('basketball', 'mens-college-basketball')],
    'cfl':    [('football', 'cfl')],
    'wnba':   [('basketball', 'wnba')],
    'ncaaw':  [('basketball', 'womens-college-basketball')],
    'ncaah':  [('hockey', 'mens-college-hockey')],
    'soccer': [('soccer', 'all')],
}
_TTL = 20
_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'
_cache = {}
_lock = threading.Lock()
_STOP = {'fc', 'cf', 'sc', 'ac', 'afc', 'club', 'de', 'the', 'of', 'and', 'st', 'cd', 'sd', 'ud', 'fk', 'sk', 'vs', 'v'}


def _tokens(text):
    t = unicodedata.normalize('NFKD', text or '')
    t = ''.join(c for c in t if not unicodedata.combining(c)).lower()
    return [w for w in re.findall(r'[a-z0-9]+', t) if w not in _STOP and not w.isdigit()]


def _ts(iso):
    try:
        import calendar
        return calendar.timegm(_strp(iso.replace('Z', '')[:16], '%Y-%m-%dT%H:%M').timetuple())
    except Exception:
        return 0


_PWHL_FEED = 'https://lscluster.hockeytech.com/feed/index.php?feed=modulekit&key=446521baf8c38984&fmt=json&client_code=pwhl&lang=en'
_pwhl = {'t': 0, 'games': []}
_pwhl_lock = threading.Lock()


def _iso_offset_ts(iso):
    """'2026-11-22T21:50:00-05:00' -> UTC timestamp."""
    import calendar
    m = re.match(r'(\d{4})-(\d\d)-(\d\d)T(\d\d):(\d\d):(\d\d)([+-])(\d\d):(\d\d)', iso or '')
    if not m:
        return 0
    y, mo, d, h, mi, s = (int(x) for x in m.groups()[:6])
    off = (int(m.group(8)) * 3600 + int(m.group(9)) * 60) * (1 if m.group(7) == '+' else -1)
    return calendar.timegm((y, mo, d, h, mi, s)) - off


def pwhl_games(days_ahead=21):
    """Every PWHL game from yesterday to `days_ahead` days on: [{'id','home','away','hs','as','state','detail','start'}] (the feed is
    read at most every 60 seconds). The PWHL is not on ESPN, so its own stats feed is the scoreboard."""
    now = time.time()
    with _pwhl_lock:
        if now - _pwhl['t'] > 60:
            games = []
            try:
                head = {'User-Agent': _UA}
                seasons = requests.get(_PWHL_FEED + '&view=seasons', headers=head, timeout=8).json()['SiteKit']['Seasons']
                since = time.strftime('%Y-%m-%d', time.gmtime(now - 86400))
                until = time.strftime('%Y-%m-%d', time.gmtime(now + 45 * 86400))
                for sn in seasons:
                    if (sn.get('end_date') or '') < since or (sn.get('start_date') or '9') > until:
                        continue
                    sched = requests.get(_PWHL_FEED + '&view=schedule&season_id=%s' % sn['season_id'], headers=head,
                                         timeout=10).json()['SiteKit']['Schedule']
                    for g in sched:
                        start = _iso_offset_ts(g.get('GameDateISO8601', ''))
                        if not start:
                            continue
                        final = g.get('final') == '1'
                        state = 'post' if final else ('in' if g.get('started') == '1' else 'pre')
                        detail = ''
                        if state == 'in':
                            per = g.get('period', '')
                            detail = ('%s%s Period' % (per, {'1': 'st', '2': 'nd', '3': 'rd'}.get(per, 'th'))) if per.isdigit() else ''
                            if g.get('overtime') == '1':
                                detail = 'OT'
                        games.append({'id': g.get('game_id', ''), 'home': g.get('home_team_name', ''), 'away': g.get('visiting_team_name', ''),
                                      'hs': g.get('home_goal_count', '0'), 'as': g.get('visiting_goal_count', '0'),
                                      'state': state, 'detail': detail, 'start': start})
            except Exception as e:
                xbmc.log('[Starfleet/Scores] pwhl feed: %s' % str(e)[:80], xbmc.LOGWARNING)
                games = _pwhl['games']
            _pwhl['t'], _pwhl['games'] = now, games
        return [g for g in _pwhl['games'] if now - 86400 <= g['start'] <= now + days_ahead * 86400]


def _games(slug):
    """[{'home','away','hs','as','state','detail','start'}] for the sport, from the scoreboard (cached 20 s)."""
    if slug == 'pwhl':
        return pwhl_games(days_ahead=2)
    boards = _BOARDS.get(slug)
    if not boards:
        return []
    now = time.time()
    with _lock:
        hit = _cache.get(slug)
        if hit and now - hit[0] < _TTL:
            return hit[1]
    out = []
    for sport, league in boards:
        try:
            r = requests.get(_API.format(sport=sport, league=league), headers={'User-Agent': _UA}, timeout=7)
            r.raise_for_status()
            data = r.json()
        except Exception as e:
            xbmc.log('[Starfleet/Scores] %s scoreboard: %s' % (slug, str(e)[:80]), xbmc.LOGWARNING)
            continue
        for ev in data.get('events', []):
            try:
                comp = (ev.get('competitions') or [{}])[0]
                cs = comp.get('competitors') or []
                home = next(c for c in cs if c.get('homeAway') == 'home')
                away = next(c for c in cs if c.get('homeAway') == 'away')
                st = ev.get('status', {}).get('type', {})
                state = st.get('state', 'pre')
                detail = st.get('shortDetail', '') or ''
                if state == 'pre':
                    detail = ''
                out.append({
                    'home': home['team']['displayName'], 'away': away['team']['displayName'],
                    'hs': str(home.get('score', '0')), 'as': str(away.get('score', '0')),
                    'state': state, 'detail': detail, 'start': _ts(ev.get('date', '')),
                })
            except Exception:
                continue
    with _lock:
        _cache[slug] = (now, out)
    return out


def _distinct(a, b):
    """Name tokens that belong to one team only ('lakers' / 'clippers' out of two 'Los Angeles' teams)."""
    sa, sb = set(a), set(b)
    da, db = sa - sb, sb - sa
    return (da or sa), (db or sb)


def _find(games, ev):
    title = ev.get('match_title') or ev.get('title') or ''
    toks = set(_tokens(title))
    if not toks:
        return None
    start = ev.get('start_ts') or 0
    for g in games:
        ha, aa = _distinct(_tokens(g['home']), _tokens(g['away']))
        if not (ha & toks and aa & toks):
            continue
        if start and g['start'] and abs(start - g['start']) > 36 * 3600:
            continue
        return g
    return None


def _line(ev, g):
    """'Away 8 - 9 Home' in the order the event title gives the teams."""
    title = ev.get('match_title') or ev.get('title') or ''
    if ' : ' in title:                           # 'England - Premier League : Team A vs Team B'
        title = title.split(' : ')[-1]
    parts = re.split(r'\s+(?:vs\.?|@|at|v)\s+', title, maxsplit=1)
    if len(parts) < 2:
        parts = re.split(r'\s+-\s+', title, maxsplit=1)
    first = set(_tokens(parts[0]))
    ha, aa = _distinct(_tokens(g['home']), _tokens(g['away']))
    if first & ha and not first & aa:
        return '%s %s - %s %s' % (g['home'], g['hs'], g['as'], g['away'])
    return '%s %s - %s %s' % (g['away'], g['as'], g['hs'], g['home'])


def attach(slug, events):
    """Copies of `events` with 'score_line', 'score_detail', 'game_state' added where a scoreboard game matches (and 'is_live'
    corrected from the scoreboard). Events without a match are returned as they were."""
    games = _games(slug)
    if not games:
        return events
    out = []
    for ev in events:
        g = _find(games, ev)
        if not g:
            out.append(ev)
            continue
        e = dict(ev)
        e['game_state'] = g['state']
        e['score_detail'] = g['detail']
        if g['state'] in ('in', 'post'):
            e['score_line'] = _line(ev, g)
        if g['state'] == 'in':
            e['is_live'] = True
        elif g['state'] == 'post':
            e['is_live'] = False
        if e.get('match_title'):                 # lists cached earlier may carry a score inside the title
            e['title'] = e['match_title']
        out.append(e)
    return out


# ── for the add-on's My Teams (home row and alerts) ─────────────────────────────────────────────────────────────────

def games(slug):
    """Current scoreboard games for a sport: [{'home', 'away', 'hs', 'as', 'state', 'detail', 'start'}] (cached 20 s)."""
    return _games(slug)


def team_matches(team, name):
    """True when a followed team's name (any common spelling: 'Boston Celtics', 'Celtics', 'LA Clippers') is the scoreboard's
    team `name`."""
    a, b = _tokens(team), _tokens(name)
    if not a or not b:
        return False
    if set(a) <= set(b) or set(b) <= set(a):
        return True
    if a[-1] != b[-1]:
        return False

    def initials(tokens):                    # 'los angeles' -> 'la', 'new york' -> 'ny'
        return ''.join(t[0] for t in tokens)
    # same nickname: the same team when one side is only the nickname, the city starts the same, or one is the other's initials
    # ('LA Clippers' / 'Los Angeles Clippers'); not 'Real Madrid' / 'Atletico Madrid'
    short, long_ = sorted((a[0], b[0]), key=len)
    return (len(a) == 1 or len(b) == 1 or a[0] == b[0] or a[0] == initials(b[:-1]) or b[0] == initials(a[:-1])
            or (len(short) >= 3 and long_.startswith(short)))               # 'Man City' / 'Manchester City'


def team_games(slug, teams):
    """[(team name, game)] for every scoreboard game in which one of `teams` plays."""
    out = []
    for g in _games(slug):
        for t in teams:
            if team_matches(t, g['home']) or team_matches(t, g['away']):
                out.append((t, g))
                break
    return out


_PERIOD = re.compile(r'(\d+)(?:st|nd|rd|th)', re.I)


def margin(g):
    try:
        return abs(int(float(g['hs'])) - int(float(g['as'])))
    except (TypeError, ValueError):
        return 99


def is_overtime(g):
    return g.get('state') == 'in' and bool(re.search(r'\b\d*OT\b|overtime|extra time|shootout', g.get('detail') or '', re.I))


def is_close_late(slug, g):
    """A game still in play, late, and within a score or two: the moment worth interrupting for."""
    if g.get('state') != 'in':
        return False
    d, m = g.get('detail') or '', margin(g)
    per = _PERIOD.search(d)
    n = int(per.group(1)) if per else 0
    if slug in ('nba', 'ncaab', 'wnba', 'ncaaw'):
        return (n >= 4 or is_overtime(g)) and m <= 5
    if slug in ('nfl', 'cfb', 'cfl'):
        return (n >= 4 or is_overtime(g)) and m <= 8
    if slug in ('nhl', 'pwhl', 'ncaah'):
        return (n >= 3 or is_overtime(g)) and m <= 1
    if slug == 'mlb':
        return n >= 8 and m <= 2
    if slug == 'soccer':
        mm = re.match(r"\s*(\d+)", d)
        return bool(mm) and int(mm.group(1)) >= 75 and m <= 1
    return False
