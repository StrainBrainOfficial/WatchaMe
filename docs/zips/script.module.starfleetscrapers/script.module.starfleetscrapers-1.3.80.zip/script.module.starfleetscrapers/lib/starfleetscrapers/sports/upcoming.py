# -*- coding: utf-8 -*-
"""Upcoming events of the sports that have no teams to follow (UFC, boxing, BKFC, PFL, Formula 1, tennis): what is coming, and
when it starts, so the add-on can list it and remind the viewer.

Every event is {'id', 'sport', 'title', 'sub', 'start_ts', 'approx', 'venue', 'logo', 'stream_slug'}:
  start_ts     UTC timestamp of the start (the main card / the race / the first match)
  approx       True when the source gives only a day (start_ts is then noon that day, local to the venue's region is not known)
  stream_slug  the sport list the stream search runs under when the event starts (BKFC and PFL are searched as UFC / MMA)
Sources: ESPN's schedule (UFC, PFL, Bellator, Formula 1 sessions, ATP and WTA tournaments), bkfc.com/events (BKFC) and
BoxingScene's schedule (boxing). Each list is kept for two hours; a source that is down returns what it returned last time."""
import calendar
import datetime
import re
import time

import xbmc

from starfleetscrapers.core import cache as _cache
from starfleetscrapers.core import http as requests

SPORTS = (
    ('ufc', 'UFC'),
    ('boxing', 'Boxing'),
    ('bkfc', 'BKFC'),
    ('pfl', 'PFL / Bellator'),
    ('f1', 'Formula 1'),
    ('tennis', 'Tennis'),
)
# the sport list a stream search runs under for each of them
STREAM_SLUG = {'ufc': 'ufc', 'boxing': 'boxing', 'bkfc': 'ufc', 'pfl': 'ufc', 'f1': 'f1', 'tennis': 'tennis'}

_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'
_TTL = 2 * 3600
_KEEP = 14 * 86400                          # the last good list is kept this long for a source that is down
_ESPN = 'https://site.api.espn.com/apis/site/v2/sports/{path}/scoreboard?dates={rng}&limit=100'
_MONTHS = {m: i for i, m in enumerate(('jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'), 1)}


def _log(msg):
    xbmc.log('[Starfleet/Upcoming] %s' % msg, xbmc.LOGINFO)


def _get(url, timeout=15, **kw):
    r = requests.get(url, headers={'User-Agent': _UA}, timeout=timeout, **kw)
    r.raise_for_status()
    return r


def _iso_ts(iso):
    """'2026-10-31T21:00Z' / '2026-11-22T21:50:00-05:00' -> UTC timestamp (0 when it does not parse)."""
    m = re.match(r'(\d{4})-(\d\d)-(\d\d)[T ](\d\d):(\d\d)(?::(\d\d))?\s*(Z|[+-]\d\d:?\d\d)?', iso or '')
    if not m:
        return 0
    y, mo, d, h, mi, s, tz = m.groups()
    ts = calendar.timegm((int(y), int(mo), int(d), int(h), int(mi), int(s or 0)))
    if tz and tz != 'Z':
        sign = -1 if tz[0] == '-' else 1
        digits = tz[1:].replace(':', '')
        ts -= sign * (int(digits[:2]) * 3600 + int(digits[2:]) * 60)
    return ts


def _us_eastern_offset(y, mo, d):
    """UTC offset in seconds of US Eastern on that date (DST from the second Sunday of March to the first Sunday of November)."""
    first = datetime.date(y, 3, 1)
    start = first + datetime.timedelta(days=(6 - first.weekday()) % 7 + 7)
    first = datetime.date(y, 11, 1)
    end = first + datetime.timedelta(days=(6 - first.weekday()) % 7)
    return -4 * 3600 if start <= datetime.date(y, mo, d) < end else -5 * 3600


def _eastern_ts(y, mo, d, h, mi):
    return calendar.timegm((y, mo, d, h, mi, 0)) - _us_eastern_offset(y, mo, d)


def _approx_ts(y, mo, d, hour=12):
    """A day with no known start time: that hour US Eastern (the add-on's reminder then fires around then)."""
    return _eastern_ts(y, mo, d, hour, 0)


def _key(sport, ts, title):
    return '%s|%s|%s' % (sport, time.strftime('%Y%m%d', time.gmtime(ts)), re.sub(r'\W+', '', title.lower())[:40])


def _event(sport, title, ts, sub='', approx=False, venue='', logo='', end_ts=0):
    return {'end_ts': int(end_ts or 0), 'id': _key(sport, ts, title), 'sport': sport, 'title': title.strip(), 'sub': (sub or '').strip(), 'start_ts': int(ts),
            'approx': bool(approx), 'venue': (venue or '').strip(), 'logo': logo or '', 'stream_slug': STREAM_SLUG.get(sport, sport)}


# ── ESPN ────────────────────────────────────────────────────────────────────────────────────────────────────────────

def _espn(path, days=120):
    today = datetime.date.today()
    rng = '%s-%s' % (today.strftime('%Y%m%d'), (today + datetime.timedelta(days=days)).strftime('%Y%m%d'))
    return _get(_ESPN.format(path=path, rng=rng)).json()


def _espn_mma(path, sport, league_label):
    out = []
    for ev in _espn(path).get('events', []):
        state = (ev.get('status') or {}).get('type', {}).get('state', 'pre')
        ts = _iso_ts(ev.get('date', ''))
        if state == 'post' or not ts:
            continue
        comp = (ev.get('competitions') or [{}])[0]
        venue = (comp.get('venue') or {})
        place = ', '.join(x for x in (venue.get('fullName'), (venue.get('address') or {}).get('city')) if x)
        out.append(_event(sport, ev.get('name') or ev.get('shortName') or league_label, ts, league_label, venue=place))
    return out


def _ufc():
    return _espn_mma('mma/ufc', 'ufc', 'UFC')


def _pfl():
    out = []
    for path, label in (('mma/pfl', 'PFL'), ('mma/bellator', 'Bellator')):
        try:
            out += _espn_mma(path, 'pfl', label)
        except Exception as e:
            _log('%s: %s' % (path, str(e)[:80]))
    return sorted(out, key=lambda e: e['start_ts'])


_F1_SESSIONS = {'Race': 'Race', 'Qual': 'Qualifying', 'SS': 'Sprint', 'SQ': 'Sprint Qualifying', 'Sprint': 'Sprint'}


def _f1():
    out = []
    now = time.time()
    for ev in _espn('racing/f1', days=200).get('events', []):
        name = ev.get('name') or 'Formula 1'
        for comp in ev.get('competitions', []):
            kind = _F1_SESSIONS.get((comp.get('type') or {}).get('abbreviation'))
            ts = _iso_ts(comp.get('date', ''))
            if not kind or not ts or ts < now - 3 * 3600:
                continue
            venue = ((ev.get('circuit') or {}).get('fullName')) or (comp.get('venue') or {}).get('fullName', '')
            out.append(_event('f1', '%s - %s' % (name, kind), ts, 'Formula 1', venue=venue))
    return sorted(out, key=lambda e: e['start_ts'])


def _tennis():
    out = []
    now = time.time()
    seen = set()
    for tour, label in (('atp', 'ATP'), ('wta', 'WTA')):
        try:
            events = _espn('tennis/' + tour, days=60).get('events', [])
        except Exception as e:
            _log('tennis %s: %s' % (tour, str(e)[:80]))
            continue
        for ev in events:
            end = _iso_ts(ev.get('endDate', '')) or _iso_ts(ev.get('date', ''))
            if end and end < now:
                continue
            name = ev.get('name') or ev.get('shortName') or 'Tennis'
            first = 0                                   # the first match with a real start time, else the tournament's day
            for grp in ev.get('groupings', []):
                for c in grp.get('competitions', []):
                    ts = _iso_ts(c.get('startDate') or c.get('date') or '')
                    if ts and c.get('timeValid') and (not first or ts < first) and ts > now - 3 * 3600:
                        first = ts
            start = first or _iso_ts(ev.get('date', ''))
            if not start:
                continue
            k = (label, name, start // 86400)
            if k in seen:
                continue
            seen.add(k)
            if not first:                                # only a date: it starts around the middle of that day
                day = time.gmtime(start)
                start = _approx_ts(day.tm_year, day.tm_mon, day.tm_mday, 12)
            sub = '%s tournament, until %s' % (label, time.strftime('%b %d', time.gmtime(end))) if end else '%s tournament' % label
            venue = ''
            for grp in ev.get('groupings', []):
                for c in grp.get('competitions', []):
                    venue = venue or (c.get('venue') or {}).get('fullName', '')
            out.append(_event('tennis', '%s (%s)' % (name, label), start, sub, approx=not first, venue=venue, end_ts=end))
    return sorted(out, key=lambda e: e['start_ts'])


# ── BKFC ────────────────────────────────────────────────────────────────────────────────────────────────────────────

_RE_DT = re.compile(r'^(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\.?\s+(\d{1,2}),?\s+(\d{4})\s+(\d{1,2}):(\d\d)\s*([AP]M)$', re.I)
_RE_BKFC_NAME = re.compile(r'^(BKFC\b.+|KNUCKLEMANIA\b.+|.*\bBKFC\b.*)$', re.I)


def _lines(html):
    import html as _html
    t = re.sub(r'<script.*?</script>|<style.*?</style>', '', html, flags=re.S | re.I)
    t = _html.unescape(re.sub(r'<[^>]+>', '\n', t))
    return [l.strip() for l in t.split('\n') if l.strip()]


def _bkfc():
    """bkfc.com/events lists each card as ... 'Month D, YYYY h:mm AM' / 'BKFC 96 GLASGOW COOKE vs WEIR' / ... / 'VENUE - CITY'; the
    times are US Eastern. The page repeats every card (list, then details): the two are joined by the card's date and name."""
    lines = _lines(_get('https://www.bkfc.com/events').text)
    now = time.time()
    found = {}
    for i, l in enumerate(lines):
        m = _RE_DT.match(l)
        if not m:
            continue
        mon, d, y, h, mi, ap = m.groups()
        h = int(h) % 12 + (12 if ap.upper() == 'PM' else 0)
        ts = _eastern_ts(int(y), _MONTHS[mon[:3].lower()], int(d), h, int(mi))
        if ts < now - 3 * 3600:
            continue
        near = lines[max(0, i - 4):i] + lines[i + 1:i + 5]
        name = next((x for x in lines[i + 1:i + 3] if _RE_BKFC_NAME.match(x) and not _RE_DT.match(x)), '') or             next((x for x in reversed(near) if _RE_BKFC_NAME.match(x) and not _RE_DT.match(x)), '')
        place = next((x for x in lines[i + 1:i + 3] if re.search(r'\s[-–]\s', x) and x.upper() == x and not _RE_DT.match(x)), '')
        if not name:
            continue
        rec = found.setdefault((ts, re.sub(r'\W+', '', name.lower())), {'name': name, 'place': ''})
        rec['place'] = rec['place'] or place
    out = []
    for (ts, _k), rec in found.items():
        title = re.sub(r'\s+', ' ', rec['name']).strip()
        title = ' '.join(w if w.upper() == 'BKFC' or w.isdigit() or w.lower() == 'vs' else w.capitalize() if w.isupper() and len(w) > 3
                         else w for w in title.split(' '))
        out.append(_event('bkfc', title, ts, 'Bare Knuckle Fighting Championship', venue=re.sub(r'([,-]\s*)([A-Z][a-z])$', lambda m: m.group(1) + m.group(2).upper(), rec['place'].title())))
    return sorted(out, key=lambda e: e['start_ts'])


# ── boxing ──────────────────────────────────────────────────────────────────────────────────────────────────────────

_RE_BOX_CARD = re.compile(r'<h3 class="card-title">([^<]+)</h3>\s*<div[^>]*>([^<]+)</div>(.*?)(?=<h3 class="card-title">|$)', re.S)
_RE_BOX_DT = re.compile(r'(?:[A-Za-z]{3},\s+)?([A-Za-z]{3})[a-z]*\.?\s+(\d{1,2}),?\s+(\d{4})\s*-\s*(\d{1,2}):(\d\d)\s*([AP]M)\s*([A-Z]{2,4})?', re.I)
_TZ = {'EST': -5, 'EDT': -4, 'ET': None, 'CST': -6, 'CDT': -5, 'MST': -7, 'MDT': -6, 'PST': -8, 'PDT': -7, 'GMT': 0, 'UTC': 0,
       'BST': 1, 'CET': 1, 'CEST': 2}


def _boxing():
    """BoxingScene's schedule: 'Alvarez vs. Mbilli' / 'Sat, Oct 31, 2026 - 8:00 PM EST' / venue / broadcaster. A time without a zone is
    not trusted (the site shows 12:00 AM for 'time to be announced'): such an event is listed by its day."""
    html = _get('https://www.boxingscene.com/schedule', timeout=20).text
    import html as _html
    out, seen = [], set()
    now = time.time()
    for m in _RE_BOX_CARD.finditer(html):
        title = _html.unescape(m.group(1)).strip()
        dm = _RE_BOX_DT.search(_html.unescape(m.group(2)))
        if not dm or not title:
            continue
        mon, d, y, h, mi, ap, tz = dm.groups()
        y, d, mo = int(y), int(d), _MONTHS[mon[:3].lower()]
        h24 = int(h) % 12 + (12 if ap.upper() == 'PM' else 0)
        tz = (tz or '').upper()
        if tz in _TZ and _TZ[tz] is not None:
            ts = calendar.timegm((y, mo, d, h24, int(mi), 0)) - _TZ[tz] * 3600
            approx = False
        elif tz == 'ET':
            ts, approx = _eastern_ts(y, mo, d, h24, int(mi)), False
        else:
            ts, approx = _approx_ts(y, mo, d, 20), True          # a boxing card is an evening show
        if ts < now - 4 * 3600:
            continue
        card = m.group(3).split('</a>')[0]                  # this card only: its link closes after its last line
        body = _html.unescape(re.sub(r'<svg.*?</svg>', '', card, flags=re.S))
        spans = [re.sub(r'\s+', ' ', s).strip() for s in re.findall(r'<span[^>]*>([^<]+)</span>', body)]
        venue = ', '.join(spans[:2]) if spans else ''
        tv = ''
        tvm = re.search(r'lucide-tv[^>]*>.*?</svg>\s*(?:<[^>]+>)*\s*([^<]{2,60})', card, re.S)
        if tvm:
            tv = re.sub(r'\s+', ' ', tvm.group(1)).strip()
        k = (title.lower(), ts // 86400)
        if k in seen:
            continue
        seen.add(k)
        out.append(_event('boxing', title.replace('-', ' vs. ') if ' vs' not in title.lower() and ' - ' not in title and '-' in title
                          else title, ts, tv, approx=approx, venue=venue))
    return sorted(out, key=lambda e: e['start_ts'])


_GETTERS = {'ufc': _ufc, 'boxing': _boxing, 'bkfc': _bkfc, 'pfl': _pfl, 'f1': _f1, 'tennis': _tennis}


def events(sport, refresh=False):
    """The sport's upcoming events by start time ([] when there are none or the source is down and nothing was kept)."""
    getter = _GETTERS.get(sport)
    if not getter:
        return []
    ck, lk = 'upcoming_%s' % sport, 'upcoming_last_%s' % sport
    if not refresh:
        hit = _cache.get(ck)
        if hit is not None:
            return hit
    try:
        out = getter()
    except Exception as e:
        _log('%s: %s' % (sport, str(e)[:100]))
        out = None
    if out:
        _cache.set(ck, out, _TTL)
        _cache.set(lk, out, _KEEP)
        return out
    last = _cache.get(lk) or []
    now = time.time()
    last = [e for e in last if e['start_ts'] > now - 3 * 3600]
    _cache.set(ck, last, 20 * 60 if out is None else _TTL)          # a failed source is tried again in 20 minutes
    return last


def label(sport):
    return dict(SPORTS).get(sport, sport)
