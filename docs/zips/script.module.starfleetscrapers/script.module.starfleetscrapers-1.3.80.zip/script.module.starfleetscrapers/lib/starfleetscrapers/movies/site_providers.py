# -*- coding: utf-8 -*-
"""
movies/site_providers.py

Streaming sites that are only a front end for a small set of players. Each entry here reads the site's own backend (the same
request its web page makes) and returns direct HLS playlists, so no browser or script engine is needed:

  VixSrc     vixsrc.to (also the player behind StreamingUnity): /api/movie/<tmdb> or /api/tv/<tmdb>/<s>/<e> gives the embed page,
             whose `window.masterPlaylist` carries the signed master playlist (AES-128 HLS, 1080p, several audio languages).
  MovieNerds api.movenerds.space/api/stream, the backend of movienerds.site and cineruv.website (it carries VidRock, VidZee,
             VidSrc and CineJoy streams). Its own proxy refuses other sites, so the underlying CDN address and the headers it names
             are played directly.

Every link is checked (the playlist answers and starts with #EXTM3U) before it is handed back, and every call is bounded in time.
All are keyed on the TMDB id. Nothing here returns a page address: Kodi cannot play a page.
"""
import base64
import json
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.parse import parse_qs, quote, unquote, urlparse

import xbmc

try:
    from starfleetscrapers.core import http as _req
except ImportError:
    _req = None

_UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
       'Chrome/126.0.0.0 Safari/537.36')


def _log(msg):
    xbmc.log('[Starfleet/Sites] %s' % msg, xbmc.LOGINFO)


def _pipe(url, headers):
    """url|Referer=..&Origin=..&User-Agent=.. (Kodi's convention for stream headers)."""
    h = dict(headers or {})
    h.setdefault('User-Agent', _UA)
    return '%s|%s' % (url, '&'.join('%s=%s' % (k, quote(str(v), safe='')) for k, v in h.items()))


def _alive(url, headers, timeout=6):
    """The playlist answers 200 and really is one. Only the playlist is fetched (signed segments tolerate few requests)."""
    try:
        h = dict(headers or {})
        h.setdefault('User-Agent', _UA)
        r = _req.get(url, headers=h, timeout=timeout, stream=True)
        try:
            head = next(r.iter_content(512), b'')
        finally:
            r.close()
        return r.status_code < 400 and head[:7] == b'#EXTM3U'
    except Exception:
        return False


def _quality(text):
    m = re.search(r'(2160|4k|1440|1080|720|480|360)', (text or '').lower())
    if not m:
        return ''
    return '4K' if m.group(1) in ('2160', '4k') else m.group(1) + 'p'


# ── VixSrc ───────────────────────────────────────────────────────────────────

def vixsrc(tmdb_id, media_type, season=None, episode=None, **_):
    path = ('movie/%s' % tmdb_id) if media_type == 'movie' else ('tv/%s/%s/%s' % (tmdb_id, season or 1, episode or 1))
    h = {'User-Agent': _UA, 'Referer': 'https://vixsrc.to/'}
    src = _req.get('https://vixsrc.to/api/' + path, headers=h, timeout=8).json().get('src')
    if not src:
        return []
    page = _req.get('https://vixsrc.to' + src, headers=h, timeout=8).text
    tok = re.search(r"'token':\s*'([^']+)'", page)
    exp = re.search(r"'expires':\s*'([^']+)'", page)
    base = re.search(r"url:\s*'(https://[^']+/playlist/\d+)'", page)
    if not (tok and exp and base):
        return []
    fhd = 'canPlayFHD = true' in page
    url = '%s?token=%s&expires=%s%s&lang=en' % (base.group(1), tok.group(1), exp.group(1), '&h=1' if fhd else '')
    if not _alive(url, h):
        return []
    return [{'label': 'VixSrc [%s, multi-audio]' % ('1080p' if fhd else '720p'), 'url': _pipe(url, {'Referer': 'https://vixsrc.to/'})}]


# ── MovieNerds (movienerds.site, cineruv.website) ────────────────────────────

def _movenerds_item(s):
    u = s.get('url') or ''
    q = parse_qs(urlparse(u).query)
    raw = (q.get('url') or [''])[0]
    if not raw.startswith('http'):
        return None
    try:
        hd = json.loads((q.get('headers') or ['{}'])[0])
    except ValueError:
        hd = s.get('headers') or {}
    return raw, {k: v for k, v in (hd or {}).items() if k.lower() in ('referer', 'origin', 'user-agent')}


def movenerds(tmdb_id, media_type, season=None, episode=None, **_):
    qs = 'tmdbId=%s&type=%s' % (tmdb_id, 'movie' if media_type == 'movie' else 'tv')
    if media_type != 'movie':
        qs += '&season=%s&episode=%s' % (season or 1, episode or 1)
    d = _req.get('https://api.movenerds.space/api/stream?' + qs, headers={'User-Agent': _UA}, timeout=25).json()
    cands = []
    for s in d.get('primarySources') or []:
        if (s.get('language') or 'en').lower() not in ('en', 'english'):
            continue
        it = _movenerds_item(s)
        if it:
            cands.append((s, it))
    out = []
    with ThreadPoolExecutor(max_workers=max(1, min(len(cands), 8))) as pool:
        ok = list(pool.map(lambda c: _alive(c[1][0], c[1][1]), cands))
    for (s, (raw, hd)), good in zip(cands, ok):
        if good:
            name = re.sub(r'\s*\(.*', '', (s.get('name') or '').replace('�', '-')).strip() or s.get('providerName') or 'stream'
            out.append({'label': 'MovieNerds - %s %s' % (name, _quality(s.get('quality') or s.get('name'))), 'url': _pipe(raw, hd)})
    return out


# ── Videasy (the player behind many "watch free" front ends: Vidy, CineHD, Frame and more) and CineJoy ─────────────────────
# Both hand out an encrypted answer that a public helper turns back into plain JSON (enc-dec.app: only the encrypted text and
# the TMDB id go there, nothing about the viewer). The result is a direct HLS playlist, checked like the others before it is listed.

_ENCDEC = 'https://enc-dec.app/api'
_META = {}


def _tmdb_meta(tmdb_id, media_type):
    """(title, year, imdb id) of a TMDB title; kept for the session."""
    key = (tmdb_id, media_type)
    if key in _META:
        return _META[key]
    out = ('', '', '')
    try:
        from starfleetscrapers.movies.embed_sources import _RIVESTREAM_TMDB_KEY as _k
        d = _req.get('https://api.themoviedb.org/3/%s/%s' % ('movie' if media_type == 'movie' else 'tv', tmdb_id),
                     params={'api_key': _k, 'append_to_response': 'external_ids'}, timeout=8).json()
        title = d.get('title') or d.get('name') or ''
        date = d.get('release_date') or d.get('first_air_date') or ''
        imdb = d.get('imdb_id') or (d.get('external_ids') or {}).get('imdb_id') or ''
        out = (title, date[:4], imdb)
    except Exception as e:
        _log('tmdb meta %s: %s' % (tmdb_id, str(e)[:80]))
    _META[key] = out
    return out


_VIDEASY_HDR = {'Accept': '*/*', 'Origin': 'https://vidy.st', 'Referer': 'https://vidy.st/', 'User-Agent': _UA}
_VIDEASY_SERVERS = ('miami', 'boise', 'vegas', 'seattle')


def _videasy_server(server, tmdb_id, media_type, season, episode, title, year, imdb):
    seed = _req.get('https://api.wecollege.net/seed?mediaId=%s' % tmdb_id, headers=_VIDEASY_HDR, timeout=8).json().get('seed')
    if not seed:
        return []
    q = quote(quote(title, safe=''), safe='')
    url = ('https://api.wecollege.net/%s/sources?title=%s&mediaType=%s&year=%s&tmdbId=%s&imdbId=%s&enc=2&seed=%s'
           % (server, q, 'movie' if media_type == 'movie' else 'tv', year, tmdb_id, imdb, seed))
    if media_type != 'movie':
        url += '&episodeId=%s&seasonId=%s' % (episode or 1, season or 1)
    enc = _req.get(url, headers=_VIDEASY_HDR, timeout=12).text
    if not enc or len(enc) < 40 or enc.lstrip().startswith('{'):
        return []
    res = _req.post(_ENCDEC + '/dec-videasy', json={'text': enc, 'id': str(tmdb_id), 'seed': seed}, timeout=15).json()
    srcs = ((res or {}).get('result') or {}).get('sources') or []
    ranked = []
    for s in srcs:
        u = s.get('url') or ''
        h = re.search(r'(\d{3,4})', s.get('quality') or '')
        if u.startswith('http') and h:
            ranked.append((int(h.group(1)), u))
    ranked.sort(reverse=True)
    chosen = [r for r in ranked if r[0] >= 720][:2] or ranked[:1]
    hdr = {'Referer': 'https://vidy.st/', 'Origin': 'https://vidy.st'}
    if not chosen or not _alive(chosen[0][1], hdr):
        return []
    return [{'label': 'Videasy %s [%s]' % (server.title(), '4K' if h >= 2000 else '%dp' % h), 'url': _pipe(u, hdr)} for h, u in chosen]


def videasy(tmdb_id, media_type, season=None, episode=None, **_):
    title, year, imdb = _tmdb_meta(tmdb_id, media_type)
    if not title:
        return []
    out = []
    with ThreadPoolExecutor(max_workers=len(_VIDEASY_SERVERS)) as pool:
        futs = [pool.submit(_videasy_server, sv, tmdb_id, media_type, season, episode, title, year, imdb) for sv in _VIDEASY_SERVERS]
        for f in futs:
            try:
                out.extend(f.result(timeout=20) or [])
            except Exception as e:
                _log('videasy: %s' % str(e)[:100])
    return out


def _b64u_enc(b):
    import base64
    return base64.urlsafe_b64encode(b).rstrip(b'=').decode()


def _b64u_dec(s):
    import base64
    return base64.urlsafe_b64decode(s + '=' * (-len(s) % 4))


_CINEJOY_HDR = {'Accept': '*/*', 'Origin': 'https://cinejoy.pk', 'Referer': 'https://cinejoy.pk/', 'User-Agent': _UA}


def _cinejoy_server(name, tmdb_id, media_type, season, episode, title, year, imdb):
    url = 'https://api.wing.st/?title=%s&type=%s&year=%s&imdb=%s&tmdb=%s&server=%s' % (
        quote(title), 'movie' if media_type == 'movie' else 'series', year, imdb, tmdb_id, quote(name))
    if media_type != 'movie':
        url += '&season=%s&episode=%s' % (season or 1, episode or 1)
    enc = _req.get(_ENCDEC + '/enc-cinejoy', params={'url': url}, timeout=10).json().get('result') or {}
    if not enc.get('data'):
        return []
    raw = _req.post('https://api.wing.st/g', data=_b64u_dec(enc['data']), headers=_CINEJOY_HDR, timeout=15).content
    res = _req.post(_ENCDEC + '/dec-cinejoy', json={'text': _b64u_enc(raw), 'state': enc.get('state')}, timeout=15).json()
    data = ((res or {}).get('result') or {}).get('data') or {}
    hdr = {'Referer': 'https://cinejoy.pk/', 'Origin': 'https://cinejoy.pk'}
    out = []
    for st in data.get('stream') or []:
        pl = st.get('playlist') or ''
        if st.get('type') == 'hls' and pl.startswith('http') and _alive(pl, hdr):
            out.append({'label': 'CineJoy %s [HLS]' % name.title(), 'url': _pipe(pl, hdr)})
    return out


def cinejoy(tmdb_id, media_type, season=None, episode=None, **_):
    title, year, imdb = _tmdb_meta(tmdb_id, media_type)
    if not title:
        return []
    servers = _req.get('https://api.wing.st/servers', headers=_CINEJOY_HDR, timeout=8).json().get('servers') or []
    names = [x['name'] for x in servers if x.get('status') == 'ok' and x.get('name')][:3]
    out = []
    with ThreadPoolExecutor(max_workers=max(1, len(names))) as pool:
        futs = [pool.submit(_cinejoy_server, n, tmdb_id, media_type, season, episode, title, year, imdb) for n in names]
        for f in futs:
            try:
                out.extend(f.result(timeout=22) or [])
            except Exception as e:
                _log('cinejoy: %s' % str(e)[:100])
    return out


# ── Playlist probe: alive + best resolution ─────────────────────────────────────────────────────────────────────────────────

def _best_res(url, headers, timeout=7):
    """(alive, best width) of an HLS master. Only the playlist is fetched."""
    try:
        h = dict(headers or {})
        h.setdefault('User-Agent', _UA)
        r = _req.get(url, headers=h, timeout=timeout)
        t = r.text[:20000] if r.status_code < 400 else ''
        if not t.startswith('#EXTM3U'):
            return False, 0
        ws = [int(x) for x in re.findall(r'RESOLUTION=(\d+)x\d+', t)]
        return True, (max(ws) if ws else 0)
    except Exception:
        return False, 0


def _res_label(w):
    """Label from the widest variant (widescreen films are letterboxed, so the height alone under-reports)."""
    if w >= 3400:
        return '4K'
    if w >= 2400:
        return '1440p'
    if w >= 1800:
        return '1080p'
    if w >= 1200:
        return '720p'
    return '%dp' % int(w * 9 / 16) if w else 'HLS'


# ── VidFast / Vidcore (same player family: a page token, three small calls, one playlist per server) ───────────────────────

def _vidx_server(site, label, srv, stream_base, hdr, hdr_ref):
    enc = _req.post('%s/%s' % (stream_base, srv['data']), headers=hdr, timeout=12).text
    res = _req.post(_ENCDEC + '/dec-' + site, json={'text': enc}, timeout=15).json()
    r = (res or {}).get('result') or {}
    u = r.get('url') if isinstance(r, dict) else ''
    if not (u and u.startswith('http')):
        return []
    ph = {} if r.get('noReferrer') else dict(hdr_ref)
    ok, hh = _best_res(u, ph)
    if not ok:
        return []
    return [{'label': '%s %s [%s]' % (label, srv.get('name') or 'server', _res_label(hh)), 'url': _pipe(u, ph)}]


def _vidx(site, label, host, tmdb_id, media_type, season, episode, max_servers):
    path = ('movie/%s' % tmdb_id) if media_type == 'movie' else ('tv/%s/%s/%s' % (tmdb_id, season or 1, episode or 1))
    page = _req.get('https://%s/%s/' % (host, path), headers={'User-Agent': _UA}, timeout=12).text
    m = re.search(r'\\"(?:en|token)\\":\\"(.*?)\\"', page)
    if not m:
        return []
    hdr = {'User-Agent': _UA, 'Referer': 'https://%s/' % host, 'X-Requested-With': 'XMLHttpRequest'}
    p1 = (_req.get(_ENCDEC + '/enc-' + site, params={'text': m.group(1), 'stage': 1}, timeout=12).json() or {}).get('result') or {}
    if not p1.get('stage1'):
        return []
    hdr['X-CSRF-Token'] = p1['token']
    text = _req.post(p1['stage1'], headers=hdr, timeout=12).text
    p2 = (_req.get(_ENCDEC + '/enc-' + site, params={'text': text, 'stage': 2}, timeout=12).json() or {}).get('result') or {}
    if not p2.get('servers'):
        return []
    hdr['X-CSRF-Token'] = p2['token']
    servers_enc = _req.post(p2['servers'], headers=hdr, timeout=12).text
    servers = ((_req.post(_ENCDEC + '/dec-' + site, json={'text': servers_enc}, timeout=15).json() or {}).get('result')) or []
    ref = {'Referer': 'https://%s/' % host, 'Origin': 'https://%s' % host}
    out = []
    with ThreadPoolExecutor(max_workers=max_servers) as pool:
        futs = [pool.submit(_vidx_server, site, label, srv, p2['stream'], hdr, ref)
                for srv in servers[:max_servers] if srv.get('data')]
        for f in futs:
            try:
                out.extend(f.result(timeout=22) or [])
            except Exception as e:
                _log('%s: %s' % (site, str(e)[:100]))
    return out


def vidfast(tmdb_id, media_type, season=None, episode=None, **_):
    return _vidx('vidfast', 'VidFast', 'vidfast.vc', tmdb_id, media_type, season, episode, 3)


def vidcore(tmdb_id, media_type, season=None, episode=None, **_):
    return _vidx('vidcore', 'VidCore', 'vidcore.io', tmdb_id, media_type, season, episode, 5)


# ── Nexa (nexa.mov): a status call lists the servers, one encrypted call per server returns the playlist ───────────────────

_NEXA = 'https://providers.nexa.mov'
_NEXA_HDR = {'Referer': 'https://nexa.mov/', 'User-Agent': _UA}
_NEXA_NAMES = {'nova': 'Nova', 'onyx': 'Onyx', 'orion': 'Orion', 'sylver': 'Sylver', 'flux': 'Flux'}


def _nexa_server(code, tmdb_id, media_type, season, episode):
    url = '%s/?platform=tmdb&id=%s&server=%s' % (_NEXA, tmdb_id, code)
    if media_type == 'tv':
        url += '&season=%s&episode=%s' % (season or 1, episode or 1)
    enc = (_req.get(_ENCDEC + '/enc-nexa', params={'url': url}, timeout=12).json() or {}).get('result')
    if not enc:
        return []
    h = dict(_NEXA_HDR)
    h['Content-Type'] = 'application/octet-stream'
    r = _req.post(_NEXA + '/v1/playlist', data=base64.b64decode(enc), headers=h, timeout=20)
    if r.status_code != 200 or not r.content:
        return []
    d = (_req.post(_ENCDEC + '/dec-nexa', json={'text': r.content.hex(), 'server': code}, timeout=15).json() or {}).get('result') or {}
    u = d.get('url') if isinstance(d, dict) else ''
    if not (u and u.startswith('http')):
        return []
    ph = {'Referer': 'https://nexa.mov/'}
    ok, hh = _best_res(u, ph)
    if not ok:
        return []
    return [{'label': 'Nexa %s [%s]' % (_NEXA_NAMES.get(code, code.title()), _res_label(hh)), 'url': _pipe(u, ph)}]


def nexa(tmdb_id, media_type, season=None, episode=None, **_):
    try:
        st = _req.get(_NEXA + '/v1/status', headers=_NEXA_HDR, timeout=8).json().get('sources') or []
    except Exception:
        st = []
    # the last four servers are anime-only (they need AniList ids)
    codes = [s['codename'] for s in st if s.get('working') and s.get('codename') in _NEXA_NAMES] or ['nova', 'sylver']
    out = []
    with ThreadPoolExecutor(max_workers=len(codes)) as pool:
        futs = [pool.submit(_nexa_server, c, tmdb_id, media_type, season, episode) for c in codes]
        for f in futs:
            try:
                out.extend(f.result(timeout=24) or [])
            except Exception as e:
                _log('nexa: %s' % str(e)[:100])
    return out


# ── VAPlayer (vaplayer.ru and the front ends that embed it): one JSON call, a few mirror playlists ────────────────────────────

def vaplayer(tmdb_id, media_type, season=None, episode=None, **_):
    q = {'tmdb': tmdb_id, 'type': media_type}
    if media_type == 'tv':
        q.update({'season': season or 1, 'episode': episode or 1})
    d = _req.get('https://streamdata.vaplayer.ru/api.php', params=q,
                 headers={'User-Agent': _UA, 'Referer': 'https://vaplayer.ru/'}, timeout=14).json()
    data = (d or {}).get('data') or {}
    out = []
    for i, u in enumerate((data.get('stream_urls') or [])[:3]):
        ph = {}          # no Referer: its segments answer 403 (Cloudflare) when one is sent, and the playlist does not need it
        ok, hh = _best_res(u, ph)
        if ok:
            out.append({'label': 'VAPlayer %d [%s]' % (i + 1, _res_label(hh)), 'url': _pipe(u, ph)})
            if len(out) >= 2:
                break
    return out


# ── VidUp (vidup.to): the same page-token flow as VidFast ──────────────────────────────────────────────────────────────────────

def vidup(tmdb_id, media_type, season=None, episode=None, **_):
    return _vidx('vidup', 'VidUp', 'vidup.to', tmdb_id, media_type, season, episode, 4)


# ── MeowTV (meowtv.ru): a one-use ticket per call, an encrypted answer that the public helper turns back into a playlist ────────

_MEOW = 'https://api.meowtv.ru'
_MEOW_HDR = {'Origin': 'https://meowtv.ru', 'Referer': 'https://meowtv.ru/', 'User-Agent': _UA}
# (server id, label); the Hindi-language servers are left out
_MEOW_SERVERS = (('english', 'English'), ('dcloud', 'Dcloud'), ('tik', 'TCloud'))


def _meow_server(sid, label, tmdb_id, media_type, season, episode):
    h = dict(_MEOW_HDR)
    h['X-Stream-Ticket'] = _req.post(_MEOW + '/streams/ticket', headers=_MEOW_HDR, timeout=8).json().get('ticket') or ''
    path = ('movie/%s' % tmdb_id) if media_type == 'movie' else ('tv/%s/%s/%s' % (tmdb_id, season or 1, episode or 1))
    r = _req.get('%s/streams/%s?s=%s' % (_MEOW, path, sid), headers=h, timeout=22)
    if r.status_code != 200:
        return []
    res = ((_req.post(_ENCDEC + '/dec-meowtv', json={'data': r.json()}, timeout=15).json() or {}).get('result')) or {}
    if not isinstance(res, dict):
        return []
    u = res.get('url') or ''
    if not u.startswith('http') or (res.get('language') or '').lower() in ('hindi', 'tamil', 'telugu'):
        return []
    ph = {'Referer': 'https://meowtv.ru/', 'Origin': 'https://meowtv.ru'}       # the CDNs refuse a request without it
    ph.update({k: v for k, v in (res.get('headers') or {}).items() if k.lower() in ('referer', 'origin', 'user-agent')})
    ok, w = _best_res(u, ph)
    if not ok:
        return []
    m = re.search(r'/(2160|1080|720|480|360)/index', u)
    q = _res_label(w) if w else ('%sp' % m.group(1) if m else 'HLS')
    return [{'label': 'MeowTV %s [%s]' % (label, q), 'url': _pipe(u, ph)}]


def meowtv(tmdb_id, media_type, season=None, episode=None, **_):
    out = []
    with ThreadPoolExecutor(max_workers=len(_MEOW_SERVERS)) as pool:
        futs = [pool.submit(_meow_server, sid, lab, tmdb_id, media_type, season, episode) for sid, lab in _MEOW_SERVERS]
        for f in futs:
            try:
                out.extend(f.result(timeout=28) or [])
            except Exception as e:
                _log('meowtv: %s' % str(e)[:100])
    return out


# ── VidBolt (vidbolt.pro; also behind SweetFox): one open JSON call per server returns the playlists ──────────────────────────

_VIDBOLT_SERVERS = (('orion', 'Orion'), ('vega', 'Vega'), ('quantum', 'Quantum'))


def _vidbolt_server(sid, label, tmdb_id, media_type, season, episode):
    q = {'type': 'movie' if media_type == 'movie' else 'tv', 'id': tmdb_id, 'only': sid, 'hevc': '0'}
    if media_type != 'movie':
        q.update({'season': season or 1, 'episode': episode or 1})
    d = _req.get('https://vidbolt.pro/api/resolve', params=q, headers={'User-Agent': _UA}, timeout=30).json()
    out = []
    for s in ((d or {}).get('stream') or {}).get('sources') or []:
        u = s.get('url') or ''
        lang = (s.get('language') or '').lower()
        if s.get('kind') != 'hls' or not u.startswith('http') or (lang and not lang.startswith('en')):
            continue
        if not _alive(u, {}):
            continue
        ws = [int(x) for x in re.findall(r'RESOLUTION=(\d+)x\d+', s.get('master') or '')]
        qual = _res_label(max(ws)) if ws else (s.get('quality') or 'HLS')
        out.append({'label': 'VidBolt %s [%s]' % (label, qual), 'url': u})
        if len(out) >= 2:
            break
    return out


def vidbolt(tmdb_id, media_type, season=None, episode=None, **_):
    out = []
    with ThreadPoolExecutor(max_workers=len(_VIDBOLT_SERVERS)) as pool:
        futs = [pool.submit(_vidbolt_server, sid, lab, tmdb_id, media_type, season, episode) for sid, lab in _VIDBOLT_SERVERS]
        for f in futs:
            try:
                out.extend(f.result(timeout=32) or [])
            except Exception as e:
                _log('vidbolt: %s' % str(e)[:100])
    return out


# ── Bingr (bingr.one): the watch page already carries the signed playlist (MovieBox's CDN, DASH turned into HLS by a bridge) ──────

def bingr(tmdb_id, media_type, season=None, episode=None, **_):
    import html as _html
    path = ('movie/%s' % tmdb_id) if media_type == 'movie' else ('tv/%s/%s/%s' % (tmdb_id, season or 1, episode or 1))
    page = _req.get('https://bingr.one/watch/' + path, headers={'User-Agent': _UA}, timeout=14).text
    m = re.search(r'<link[^>]+href="(https://[^"]*url=[^"]*\.m3u8[^"]*)"', page)
    if not m:
        return []
    u = _html.unescape(m.group(1))
    ok, w = _best_res(u, {})
    if not ok:
        return []
    return [{'label': 'Bingr [%s]' % _res_label(w), 'url': u}]


# ── Vidmoly through 0123movie.space (the player page behind BBFlix's "Vidmoly" server): the page itself holds the playlist ───────

def vidmoly(tmdb_id, media_type, season=None, episode=None, **_):
    if media_type == 'movie':
        imdb = _tmdb_meta(tmdb_id, 'movie')[2]
        if not imdb:
            return []
        path = 'vmf/%s/%s/' % (imdb, tmdb_id)
    else:
        path = 'vms/%s/%s/%s/' % (tmdb_id, season or 1, episode or 1)
    page = _req.get('https://0123movie.space/' + path, headers={'User-Agent': _UA, 'Referer': 'https://bbflix.one/'}, timeout=14)
    m = re.search(r"https?://[^\"\s<>']+\.m3u8[^\"\s<>']*", page.text) if page.status_code == 200 else None
    if not m:
        return []
    u = m.group(0).replace('&amp;', '&')
    ok, w = _best_res(u, {})            # the edge servers differ: some answer 403 to a plain request, those are left out
    if not ok:
        return []
    return [{'label': 'Vidmoly [%s]' % _res_label(w), 'url': u}]


PROVIDERS = (('vixsrc', vixsrc), ('movenerds', movenerds), ('videasy', videasy), ('cinejoy', cinejoy), ('vidfast', vidfast), ('vidcore', vidcore), ('nexa', nexa), ('vaplayer', vaplayer),
             ('vidup', vidup), ('meowtv', meowtv), ('vidbolt', vidbolt), ('bingr', bingr), ('vidmoly', vidmoly))


def search_sites(tmdb_id, media_type='movie', season=None, episode=None, budget=14):
    """Every provider in parallel; whatever answers inside `budget` seconds. [{'label', 'url'}]."""
    if not _req or not tmdb_id or media_type not in ('movie', 'tv'):
        return []
    from starfleetscrapers.core import source_toggles as _st
    active = [(n, fn) for n, fn in PROVIDERS if _st.on('free', n)]
    if not active:
        return []
    out = []
    pool = ThreadPoolExecutor(max_workers=len(active))
    try:
        futs = {pool.submit(fn, tmdb_id, media_type, season, episode): name for name, fn in active}
        try:
            for f in as_completed(futs, timeout=budget):
                try:
                    out.extend(f.result() or [])
                except Exception as e:
                    _log('%s: %s' % (futs[f], str(e)[:100]))
        except Exception:
            pass
    finally:
        pool.shutdown(wait=False)
    seen, uniq = set(), []
    for it in out:
        key = it['url'].split('|', 1)[0].split('?', 1)[0]
        if key not in seen:
            seen.add(key)
            uniq.append(it)
    _log('%d link(s) for tmdb %s' % (len(uniq), tmdb_id))
    return uniq
