# -*- coding: utf-8 -*-
"""Use other installed scraper modules from inside Starfleet.

Any installed script.module.* add-on whose package follows the common common-layout convention - a function
sources(specified_folders=None, ret_all=False) returning [(provider name, source class), ...], each class answering
source().sources(data, hostDict) with dicts like {'hash', 'url' (magnet), 'name', 'quality', 'seeders', 'size', ...} -
is picked up (and similar scraper packs). Each module's own provider switches decide which of its
providers run. Their results are turned into Starfleet's result dicts and merged with Starfleet's own by the caller.

    modules()                                  -> [(add-on id, package)] found on this device
    search(title, year, media_type, imdb_id, season, episode, timeout=14)  -> [result dict, ...]
Nothing here raises: a module that fails to load or a provider that hangs is skipped."""
import importlib
import os
import sys
import threading
import time

_OWN = 'script.module.starfleetscrapers'
_cache = {'mods': None, 'loaded': {}}


def _addons_dirs():
    dirs = []
    try:
        import xbmcvfs
        dirs.append(xbmcvfs.translatePath('special://home/addons'))
    except Exception:
        pass
    env = os.environ.get('STARFLEET_EXTERNAL_ADDONS')
    if env:
        dirs += env.split(os.pathsep)
    return [d for d in dirs if d and os.path.isdir(d)]


def modules(force=False):
    """[(add-on id, package name)] of installed scraper modules in the common-layout layout (cached for the session)."""
    if _cache['mods'] is not None and not force:
        return _cache['mods']
    found = []
    for base in _addons_dirs():
        try:
            names = sorted(os.listdir(base))
        except OSError:
            continue
        for addon_id in names:
            if not addon_id.startswith('script.module.') or addon_id == _OWN:
                continue
            package = addon_id.split('.')[-1]
            init = os.path.join(base, addon_id, 'lib', package, '__init__.py')
            try:
                with open(init, 'r', encoding='utf-8', errors='replace') as fh:
                    head = fh.read(6000)
            except OSError:
                continue
            if 'def sources(' in head and any(m[1] == package for m in found) is False:
                found.append((addon_id, package, os.path.join(base, addon_id, 'lib')))
    _cache['mods'] = [(a, p) for a, p, _l in found]
    _cache['paths'] = {p: lib for _a, p, lib in found}
    return _cache['mods']


def _load(package):
    """The provider list of one module ([(name, class)]), loaded once."""
    if package in _cache['loaded']:
        return _cache['loaded'][package]
    lib = _cache.get('paths', {}).get(package)
    out = []
    try:
        if lib and lib not in sys.path:
            sys.path.append(lib)
        mod = importlib.import_module(package)
        out = list(mod.sources(specified_folders=['torrents']) or [])
    except Exception:
        out = []
    _cache['loaded'][package] = out
    return out


def _wanted_modules():
    try:
        from starfleetscrapers import host
        listed = (host.addon().getSetting('external_scraper_modules') or '').replace(' ', '')
    except Exception:
        listed = ''
    chosen = [x for x in listed.split(',') if x]
    mods = modules()
    return [(a, p) for a, p in mods if not chosen or a in chosen]


def _to_result(d, module_package):
    ih = (d.get('hash') or '').lower()
    magnet = d.get('url') or ''
    if not ih and 'btih:' in magnet:
        import re
        m = re.search(r'btih:([0-9a-fA-F]{40})', magnet)
        ih = m.group(1).lower() if m else ''
    if not ih:
        return None
    size = d.get('size') or 0
    try:
        size_txt = '%.2f GB' % float(size) if float(size) else ''
    except (TypeError, ValueError):
        size_txt = str(size)
    try:
        seeds = int(d.get('seeders') or 0)
    except (TypeError, ValueError):
        seeds = 0
    return {'title': d.get('name') or '', 'year': '', 'quality': d.get('quality') or '', 'info_hash': ih,
            'magnet': magnet if magnet.startswith('magnet:') else 'magnet:?xt=urn:btih:%s' % ih, 'seeds': seeds, 'size': size_txt,
            'source': 'Ext/%s' % (d.get('provider') or module_package)}


def search(title, year=None, media_type='movie', imdb_id=None, season=None, episode=None, timeout=14):
    """Run every enabled provider of every compatible module at once; whatever answers inside `timeout` seconds is returned."""
    mods = _wanted_modules()
    if not mods or not title:
        return []
    tv = media_type == 'tv' and season is not None and episode is not None
    if tv:
        data = {'tvshowtitle': title, 'title': '', 'year': str(year or ''), 'imdb': imdb_id or '', 'season': str(season),
                'episode': str(episode), 'aliases': [], 'premiered': '', 'tvdb': ''}
    else:
        data = {'title': title, 'year': str(year or ''), 'imdb': imdb_id or '', 'aliases': [], 'premiered': ''}
    results, lock = [], threading.Lock()
    threads = []

    def work(package, name, cls):
        try:
            items = cls().sources(dict(data), []) or []
        except Exception:
            return
        conv = [r for r in (_to_result(i, package) for i in items if isinstance(i, dict)) if r]
        with lock:
            results.extend(conv)

    for _addon_id, package in mods:
        for name, cls in _load(package):
            t = threading.Thread(target=work, args=(package, name, cls), daemon=True)
            t.start()
            threads.append(t)
    deadline = time.time() + timeout
    for t in threads:
        t.join(max(0.0, deadline - time.time()))
    with lock:
        return list(results)
