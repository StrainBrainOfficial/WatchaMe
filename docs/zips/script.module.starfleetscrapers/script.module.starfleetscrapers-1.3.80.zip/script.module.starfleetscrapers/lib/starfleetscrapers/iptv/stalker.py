# -*- coding: utf-8 -*-
"""
iptv/stalker.py - Stalker / Ministra middleware portals (the MAG set-top-box protocol).

The viewer gives the portal address (http://host/c/ or http://host/stalker_portal/c/) and the MAC address of their subscription. The portal's
server/load.php is then used the way a MAG box does:  handshake -> token,  get_profile,  itv (genres, channels),  vod and series (categories,
ordered lists by page),  create_link (turns a channel / film `cmd` into the real stream address),  get_epg_info (the guide).

Written from the protocol as MAG clients use it; portals differ in small ways, so each step is tolerant of missing fields.
"""
import hashlib
import json
import re
import time
from urllib.parse import quote, urlencode

from starfleetscrapers.core import http as _http

_UA = ('Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG250 stbapp ver: 4 rev: 1812 Mobile Safari/533.3')
_TIMEOUT = (8, 40)
_PAGE_CAP = 400            # safety stop when paging a list


def normalize_mac(mac):
    m = re.sub(r'[^0-9A-Fa-f]', '', mac or '')
    if len(m) != 12:
        raise ValueError('a MAC address has 12 hex digits (00:1A:79:xx:xx:xx)')
    return ':'.join(m[i:i + 2] for i in range(0, 12, 2)).upper()


def _root(url):
    u = (url or '').strip()
    if '://' not in u:
        u = 'http://' + u
    m = re.match(r'^(https?://[^/?#]+)(/[^?#]*)?', u)
    return m.group(1), (m.group(2) or '/')


def candidates(url):
    """Likely server/load.php addresses for a typed portal address, most likely first."""
    host, path = _root(url)
    if path.rstrip('/').endswith(('load.php', 'portal.php')):
        return [host + path.rstrip('/')]
    path = re.sub(r'/c/?$', '', path.rstrip('/'))
    out = []
    if path:
        out += [host + path + '/server/load.php', host + path + '/portal.php']
    out += [host + '/stalker_portal/server/load.php', host + '/server/load.php', host + '/portal.php', host + '/c/server/load.php']
    seen, res = set(), []
    for c in out:
        if c not in seen:
            seen.add(c)
            res.append(c)
    return res


class Stalker(object):
    def __init__(self, provider):
        self.p = provider
        self.mac = normalize_mac(provider.get('mac'))
        self.host, _ = _root(provider['url'])
        self.endpoint = None
        self.token = ''
        self._ready = False
        self._channels = None

    # ── plumbing ──
    def _headers(self):
        h = {'User-Agent': self.p.get('user_agent') or _UA, 'X-User-Agent': 'Model: MAG250; Link: WiFi', 'Accept': '*/*',
             'Referer': self.host + '/c/', 'Cookie': 'mac=%s; stb_lang=en; timezone=Europe%%2FLondon' % quote(self.mac, safe='')}
        if self.token:
            h['Authorization'] = 'Bearer ' + self.token
        return h

    def _get(self, params, endpoint=None):
        q = dict(params)
        q['JsHttpRequest'] = '1-xml'
        r = _http.get((endpoint or self.endpoint) + '?' + urlencode(q), headers=self._headers(), timeout=_TIMEOUT)
        r.raise_for_status()
        text = r.text.strip()
        try:
            data = json.loads(text)
        except ValueError:
            m = re.search(r'\{.*\}', text, re.S)
            data = json.loads(m.group(0)) if m else {}
        return data.get('js') if isinstance(data, dict) else data

    def connect(self):
        if self._ready:
            return True
        last = None
        for ep in ([self.endpoint] if self.endpoint else candidates(self.p['url'])):
            try:
                js = self._get({'type': 'stb', 'action': 'handshake', 'token': '', 'prehash': '0'}, endpoint=ep)
            except Exception as e:
                last = e
                continue
            tok = (js or {}).get('token') if isinstance(js, dict) else ''
            if tok:
                self.endpoint, self.token = ep, tok
                break
        else:
            raise RuntimeError('portal did not answer a handshake (%s)' % (type(last).__name__ if last else 'no token'))
        sn = hashlib.md5(self.mac.encode()).hexdigest()[:13].upper()
        try:
            self._get({'type': 'stb', 'action': 'get_profile', 'hd': '1', 'ver': 'ImageDescription: 0.2.18-r14-pub-250; ImageDate: Fri Jan 15 15:20:44 EET 2016',
                       'num_banks': '2', 'sn': sn, 'stb_type': 'MAG250', 'client_type': 'STB', 'image_version': '218', 'video_out': 'hdmi',
                       'device_id': hashlib.sha256(self.mac.encode()).hexdigest().upper(), 'device_id2': '', 'signature': '',
                       'auth_second_step': '1', 'hw_version': '1.7-BD-00', 'not_valid_token': '0', 'timestamp': str(int(time.time())),
                       'api_signature': '262', 'prehash': '', 'mac': self.mac})
        except Exception:
            pass                                          # some portals accept a handshake token without a profile step
        self._ready = True
        return True

    def test(self):
        try:
            self.connect()
            js = self._get({'type': 'account_info', 'action': 'get_main_info'}) or {}
            exp = js.get('end_date') or js.get('expire_billing_date') or ''
            return {'ok': True, 'message': 'Portal answered (%s)' % (exp or 'account active'), 'info': {'expires_text': exp}}
        except Exception as e:
            return {'ok': False, 'message': 'Portal problem: %s' % e, 'info': {}}

    # ── lists ──
    def categories(self, kind):
        self.connect()
        if kind == 'live':
            rows = self._get({'type': 'itv', 'action': 'get_genres'}) or []
        else:
            rows = self._get({'type': 'vod' if kind == 'movie' else 'series', 'action': 'get_categories'}) or []
        out = []
        for c in rows if isinstance(rows, list) else []:
            if not isinstance(c, dict) or str(c.get('id')) in ('*', ''):
                continue
            out.append({'id': str(c.get('id')), 'name': (c.get('title') or c.get('name') or '').strip() or 'Uncategorised'})
        return out

    def _live_all(self):
        if self._channels is None:
            js = self._get({'type': 'itv', 'action': 'get_all_channels'}) or {}
            rows = js.get('data') if isinstance(js, dict) else js
            self._channels = rows if isinstance(rows, list) else []
        return self._channels

    def items(self, kind, category_id=None):
        self.connect()
        if kind == 'live':
            rows = self._live_all()
            if not rows:                                        # portals that only serve a list per genre
                rows = []
                for g in ([{'id': category_id}] if category_id else self.categories('live')):
                    rows += self._paged({'type': 'itv', 'action': 'get_ordered_list', 'genre': g['id']})
            out = []
            for r in rows:
                if category_id is not None and str(r.get('tv_genre_id')) != str(category_id) and r.get('tv_genre_id') is not None:
                    continue
                out.append({'id': str(r.get('id')), 'kind': 'live', 'title': (r.get('name') or '').strip(), 'poster': r.get('logo') or '',
                            'category_id': str(r.get('tv_genre_id')), 'epg_id': 'ch%s' % r.get('id'), 'num': r.get('number'),
                            'ref': {'t': 'live', 'cmd': r.get('cmd') or '', 'id': str(r.get('id'))}})
            return out
        t = 'vod' if kind == 'movie' else 'series'
        cats = [{'id': category_id}] if category_id else self.categories(kind)
        out = []
        for c in cats:
            for r in self._paged({'type': t, 'action': 'get_ordered_list', 'category': c['id']}):
                item = {'id': str(r.get('id')), 'kind': kind, 'title': (r.get('name') or '').strip(), 'poster': r.get('screenshot_uri') or r.get('cover') or '',
                        'plot': r.get('description') or '', 'year': str(r.get('year') or '')[:4], 'rating': r.get('rating_imdb') or r.get('rating_kinopoisk') or '',
                        'category_id': str(c['id']), 'ref': {'t': kind, 'cmd': r.get('cmd') or '', 'id': str(r.get('id'))}}
                if kind == 'series':
                    item['ref']['episodes'] = r.get('series') or []
                out.append(item)
        return out

    def _paged(self, params):
        rows, page = [], 1
        while page <= _PAGE_CAP:
            js = self._get(dict(params, p=str(page))) or {}
            data = js.get('data') if isinstance(js, dict) else None
            if not data:
                break
            rows += data
            total, per = int(js.get('total_items') or 0), int(js.get('max_page_items') or len(data) or 1)
            if total and len(rows) >= total or len(data) < per:
                break
            page += 1
        return rows

    def seasons(self, series_id):
        """Series on a portal list their episode numbers on the show itself; they play with create_link(series=<number>)."""
        found = None
        for it in self.items('series'):
            if it['id'] == str(series_id):
                found = it
                break
        if not found:
            return {'info': {}, 'seasons': {}}
        eps = found['ref'].get('episodes') or []
        return {'info': {'title': found['title'], 'plot': found.get('plot', ''), 'poster': found.get('poster', '')},
                'seasons': {1: [{'id': '%s:%s' % (series_id, n), 'kind': 'episode', 'season': 1, 'episode': int(n), 'title': 'Episode %s' % n,
                                 'ref': {'t': 'episode', 'cmd': found['ref']['cmd'], 'series': str(n), 'id': '%s:%s' % (series_id, n)}}
                                for n in eps]}}

    # ── playing ──
    def resolve(self, item):
        self.connect()
        ref = item['ref']
        t = 'itv' if ref.get('t') == 'live' else ('vod' if ref.get('t') == 'movie' else 'vod')
        js = self._get({'type': t, 'action': 'create_link', 'cmd': ref.get('cmd', ''), 'series': ref.get('series', ''),
                        'forced_storage': '', 'disable_ad': '0', 'download': '0'}) or {}
        cmd = (js.get('cmd') if isinstance(js, dict) else '') or ref.get('cmd', '')
        url = re.sub(r'^(ffmpeg|ffrt\d*|auto)\s+', '', cmd.strip())
        return {'url': url, 'headers': {'User-Agent': self.p.get('user_agent') or _UA}}

    # ── guide ──
    def epg_rows(self):
        """Programme rows (channel, start, stop, title, desc) for the next hours, from the portal's own guide call."""
        self.connect()
        js = self._get({'type': 'itv', 'action': 'get_epg_info', 'period': '6'}) or {}
        data = js.get('data') if isinstance(js, dict) else {}
        for ch, rows in (data or {}).items() if isinstance(data, dict) else []:
            for e in rows or []:
                try:
                    yield ('ch%s' % ch, int(e.get('start_timestamp')), int(e.get('stop_timestamp')), e.get('name') or '', e.get('descr') or '')
                except (TypeError, ValueError):
                    continue

    def epg_url(self):
        return self.p.get('epg_url') or ''
