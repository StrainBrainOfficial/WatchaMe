# -*- coding: utf-8 -*-
"""
iptv/catalog.py - the one front door to the IPTV engine. The Kodi plugin and the Android app both call only this.

Kinds:  'live' | 'movie' | 'series'.   Every list row is a plain dict:
    {'id', 'kind', 'title', 'poster', 'plot', 'year', 'rating', 'category_id', 'epg_id', 'num', 'provider_id', 'provider_name', 'ref'}
`ref` is opaque: hand the whole row back to resolve().

    providers()                          the viewer's providers
    save_provider(dict) / delete_provider(id) / test(provider)
    has_content(kind)                    True when a provider is set up (so a menu can show its IPTV entry)
    categories(provider_id, kind)        visible categories after the viewer's hide / rename / order choices
    manager_rows(provider_id, kind)      every category, for the manage-categories screen (+ set_hidden, set_name, move, reset)
    items(provider_id, kind, category_id)
    seasons(provider_id, series_id)      {'info', 'seasons': {n: [episode rows]}}
    search(query, kind)
    resolve(provider_id, row)            {'url', 'headers'}  (kodi_url() turns that into url|Header=value)
    refresh_epg(provider_id=None, force=False) / now_next(provider_id, row) / guide(provider_id, rows, start, end)
"""
import threading
import time
from urllib.parse import quote

from starfleetscrapers.iptv import cache, categories as _cats, epg, m3u, store
from starfleetscrapers.iptv.stalker import Stalker
from starfleetscrapers.iptv.xtream import Xtream

KINDS = ('live', 'movie', 'series')
KIND_LABELS = {'live': 'Live TV', 'movie': 'Movies', 'series': 'TV Shows'}
EPG_TTL = 6 * 3600
_adapters = {}
_lock = threading.Lock()

# re-exported for callers
providers = store.providers
get_provider = store.get
save_provider = store.save_provider
delete_provider = store.delete_provider
set_hidden = _cats.set_hidden
set_all_hidden = _cats.set_all_hidden
set_name = _cats.set_name
reset_categories = _cats.reset
adult_hidden = _cats.adult_hidden
set_adult_hidden = _cats.set_adult_hidden


def _enabled():
    return [p for p in store.providers() if p.get('enabled', True)]


class _M3U(object):
    """Adapter over a parsed playlist (kept in the cache for a few hours)."""

    def __init__(self, p):
        self.p = p

    def _parsed(self, refresh=False):
        key = 'm3u_parsed'
        data = None if refresh else cache.get(self.p['id'], key)
        if data is None:
            data = cache.put(self.p['id'], key, m3u.parse(m3u.fetch(self.p['url'], self.p.get('user_agent'))))
        return data

    def test(self):
        try:
            d = self._parsed(refresh=True)
            n = {k: sum(1 for e in d['entries'] if e['kind'] == k) for k in KINDS}
            return {'ok': bool(d['entries']), 'message': '%d live, %d movies, %d series entries' % (n['live'], n['movie'], n['series']),
                    'info': n}
        except Exception as e:
            return {'ok': False, 'message': 'Could not read the playlist (%s)' % type(e).__name__, 'info': {}}

    def categories(self, kind):
        return m3u.categories(self._parsed(), kind)

    def items(self, kind, category_id=None):
        return m3u.items(self._parsed(), kind, category_id)

    def seasons(self, series_id):
        return m3u.seasons(self._parsed(), series_id)

    def resolve(self, row):
        return m3u.resolve(self._parsed(), row)

    def epg_url(self):
        return self.p.get('epg_url') or self._parsed().get('epg_url') or ''


def adapter(provider):
    t = provider['type']
    key = (provider['id'], provider.get('url'), provider.get('username'), provider.get('password'), provider.get('mac'))
    with _lock:
        a = _adapters.get(provider['id'])
        if a is None or a[0] != key:
            a = (key, Xtream(provider) if t == 'xtream' else Stalker(provider) if t == 'stalker' else _M3U(provider))
            _adapters[provider['id']] = a
    return a[1]


def test(provider):
    """Check a provider (also one not saved yet): {'ok', 'message', 'info'}."""
    p = dict(provider)
    p.setdefault('id', 'test')
    try:
        if p['type'] == 'xtream':
            return Xtream(p).test()
        if p['type'] == 'stalker':
            return Stalker(p).test()
        return _M3U(p).test()
    except Exception as e:
        return {'ok': False, 'message': str(e), 'info': {}}


def has_content(kind=None):
    return bool(_enabled())


def _raw_categories(p, kind, refresh=False):
    key = 'cats_%s' % kind
    data = None if refresh else cache.get(p['id'], key)
    if data is None:
        data = cache.put(p['id'], key, adapter(p).categories(kind))
    return data


def categories(provider_id, kind, include_hidden=False, refresh=False):
    p = store.get(provider_id)
    if not p:
        return []
    return _cats.apply(provider_id, kind, _raw_categories(p, kind, refresh), include_hidden)


def manager_rows(provider_id, kind, refresh=False):
    p = store.get(provider_id)
    return _cats.manager_rows(provider_id, kind, _raw_categories(p, kind, refresh)) if p else []


def move_category(provider_id, kind, category_id, delta):
    p = store.get(provider_id)
    if p:
        _cats.move(provider_id, kind, category_id, delta, _raw_categories(p, kind))


def hide_all(provider_id, kind, hidden):
    p = store.get(provider_id)
    if p:
        _cats.set_all_hidden(provider_id, kind, _raw_categories(p, kind), hidden)


def _tag(p, rows):
    for r in rows:
        r['provider_id'] = p['id']
        r['provider_name'] = p.get('name') or ''
    return rows


def items(provider_id, kind, category_id=None, refresh=False):
    p = store.get(provider_id)
    if not p:
        return []
    key = 'items_%s_%s' % (kind, category_id)
    data = None if refresh else cache.get(provider_id, key)
    if data is None:
        data = cache.put(provider_id, key, adapter(p).items(kind, category_id))
    return _tag(p, [dict(r) for r in data])


def all_rows(provider_id, kind, refresh=False):
    """Every row of a kind in one list (cached, no per-row copy): what the IPTV scraper indexes. Visible-category filtering is the caller's job."""
    p = store.get(provider_id)
    if not p:
        return []
    key = 'items_%s_%s' % (kind, None)
    data = None if refresh else cache.get(provider_id, key)
    if data is None:
        data = cache.put(provider_id, key, adapter(p).items(kind, None))
    return data


def seasons(provider_id, series_id):
    p = store.get(provider_id)
    if not p:
        return {'info': {}, 'seasons': {}}
    key = 'seasons_%s' % series_id
    data = cache.get(provider_id, key, ttl=3600)
    if data is None:
        data = adapter(p).seasons(series_id)
        data = {'info': data.get('info') or {}, 'seasons': {str(k): v for k, v in (data.get('seasons') or {}).items()}}
        cache.put(provider_id, key, data)
    return {'info': data['info'], 'seasons': {int(k): _tag(p, [dict(e) for e in v]) for k, v in data['seasons'].items()}}


def search(query, kind, limit=200):
    """Rows whose title contains every word of `query`, over every enabled provider's visible categories."""
    words = [w for w in (query or '').lower().split() if w]
    out = []
    for p in _enabled():
        try:
            for c in categories(p['id'], kind):
                for r in items(p['id'], kind, c['id']):
                    t = r['title'].lower()
                    if all(w in t for w in words):
                        out.append(r)
                        if len(out) >= limit:
                            return out
        except Exception:
            continue
    return out


def resolve(provider_id, row):
    p = store.get(provider_id)
    if not p:
        raise KeyError('unknown provider')
    return adapter(p).resolve(row)


def kodi_url(resolved):
    """{'url', 'headers'} -> Kodi's 'url|Header=value&...' form."""
    h = resolved.get('headers') or {}
    if not h:
        return resolved['url']
    return '%s|%s' % (resolved['url'], '&'.join('%s=%s' % (k, quote(str(v), safe='')) for k, v in h.items()))


# ── guide ────────────────────────────────────────────────────────────────────────────────────────────────────────────

def refresh_epg(provider_id=None, force=False):
    """Import the guide of one provider (or all). Skipped while the last import is younger than six hours unless forced.
    -> {provider_id: programmes imported | 'fresh' | 'none' | 'error: ...'}"""
    result = {}
    for p in ([store.get(provider_id)] if provider_id else _enabled()):
        if not p:
            continue
        pid = p['id']
        try:
            if not force and time.time() - epg.loaded_at(pid) < EPG_TTL:
                result[pid] = 'fresh'
                continue
            a = adapter(p)
            if hasattr(a, 'epg_rows') and not a.epg_url():
                result[pid] = epg.import_rows(pid, a.epg_rows())
                continue
            url = a.epg_url()
            if not url:
                result[pid] = 'none'
                continue
            nch, npr = epg.import_url(pid, url, p.get('user_agent'))
            result[pid] = npr
        except Exception as e:
            result[pid] = 'error: %s' % e
    return result


def now_next(provider_id, row):
    return epg.now_next(provider_id, row.get('epg_id') or '', row.get('epg_name') or row.get('title') or '')


def guide(provider_id, rows, start, end):
    return epg.guide(provider_id, [(r.get('epg_id') or '', r.get('epg_name') or r.get('title') or '') for r in rows], start, end)
