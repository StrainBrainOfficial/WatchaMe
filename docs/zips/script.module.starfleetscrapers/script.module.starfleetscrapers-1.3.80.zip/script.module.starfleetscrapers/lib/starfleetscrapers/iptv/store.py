# -*- coding: utf-8 -*-
"""
iptv/store.py - where the IPTV engine keeps its files: the viewer's providers (with their logins) and the category choices.

Everything lives in one folder: `configure(path)` sets it (the Android app does that), otherwise the module's own profile folder is used, and
as a last resort ~/.starfleet_iptv. Files are written atomically so an interrupted write never leaves a broken file behind. This package does
not need Kodi: it only uses xbmc* when they are there to find the profile folder.
"""
import json
import os
import threading
import time
import uuid

TYPES = ('xtream', 'stalker', 'm3u')
TYPE_LABELS = {'xtream': 'Xtream Codes', 'stalker': 'Stalker / Ministra portal', 'm3u': 'M3U playlist'}

_lock = threading.RLock()
_base = [None]


def configure(path):
    """Use `path` as the IPTV data folder."""
    _base[0] = path
    os.makedirs(path, exist_ok=True)


def base_dir():
    if _base[0]:
        return _base[0]
    path = os.environ.get('STARFLEET_IPTV_DIR')
    if not path:
        try:
            from starfleetscrapers import host as _host
            path = os.path.join(_host.profile(), 'iptv')
        except Exception:
            path = os.path.join(os.path.expanduser('~'), '.starfleet_iptv')
    os.makedirs(path, exist_ok=True)
    _base[0] = path
    return path


def path(name):
    return os.path.join(base_dir(), name)


def load(name, default=None):
    with _lock:
        try:
            with open(path(name), 'r', encoding='utf-8') as f:
                return json.load(f)
        except (OSError, ValueError):
            return default


def save(name, data):
    with _lock:
        p = path(name)
        tmp = p + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False)
        os.replace(tmp, p)


# ── providers ────────────────────────────────────────────────────────────────────────────────────────────────────────

def providers():
    """[provider dict] in the order they were added."""
    return list(load('providers.json', []) or [])


def get(provider_id):
    for p in providers():
        if p.get('id') == provider_id:
            return p
    return None


MAX_PROVIDERS = 100          # the most IPTV accounts that can be linked


def save_provider(p):
    """Add (no id yet) or update (known id) a provider and return it. Fields: name, type (xtream|stalker|m3u), url, username, password,
    mac (stalker), epg_url (optional), user_agent (optional), enabled."""
    if p.get('type') not in TYPES:
        raise ValueError('unknown provider type: %r' % p.get('type'))
    p = dict(p)
    p['url'] = (p.get('url') or '').strip()
    if not p['url']:
        raise ValueError('the address is empty')
    p.setdefault('enabled', True)
    p.setdefault('name', p['url'].split('//')[-1].split('/')[0])
    with _lock:
        rows = providers()
        if len(rows) >= MAX_PROVIDERS and not any(o.get('id') == p.get('id') for o in rows):
            raise ValueError('at most %d IPTV accounts can be linked - remove one first' % MAX_PROVIDERS)
        if not p.get('id'):
            p['id'] = uuid.uuid4().hex[:8]
            p['added'] = int(time.time())
            rows.append(p)
        else:
            for i, old in enumerate(rows):
                if old.get('id') == p['id']:
                    p['added'] = old.get('added', int(time.time()))
                    rows[i] = p
                    break
            else:
                rows.append(p)
        save('providers.json', rows)
    return p


def delete_provider(provider_id):
    """Remove a provider, its category choices, its cached lists and its guide data."""
    with _lock:
        save('providers.json', [p for p in providers() if p.get('id') != provider_id])
        prefs = load('categories.json', {}) or {}
        if prefs.pop(provider_id, None) is not None:
            save('categories.json', prefs)
    try:
        from starfleetscrapers.iptv import cache as _cache
        _cache.drop_provider(provider_id)
    except Exception:
        pass
    try:
        from starfleetscrapers.iptv import epg as _epg
        _epg.drop_provider(provider_id)
    except Exception:
        pass
