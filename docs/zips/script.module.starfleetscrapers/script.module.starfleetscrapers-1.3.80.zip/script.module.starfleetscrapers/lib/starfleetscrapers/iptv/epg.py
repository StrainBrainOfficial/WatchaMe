# -*- coding: utf-8 -*-
"""
iptv/epg.py - the TV guide: XMLTV (a web address, a .gz file, or a file) and the portals' own guide calls are imported into one small SQLite
database (epg.db) holding programmes from a few hours back to three days ahead, so the guide is a quick query instead of a download.

    import_url(provider_id, url)        XMLTV from an address (gzip is detected)
    import_xmltv(provider_id, fileobj)  XMLTV from an open binary file
    import_rows(provider_id, rows)      (channel, start, stop, title, desc) rows from a portal
    now_next(provider_id, epg_id, name) what is on now and next
    guide(provider_id, channel_ids, start, end)
"""
import gzip
import os
import re
import shutil
import sqlite3
import tempfile
import threading
import time
from datetime import datetime, timedelta, timezone
from xml.etree import ElementTree as ET

from starfleetscrapers.core import http as _http
from starfleetscrapers.iptv import store

_BACK = 3 * 3600
_AHEAD = 72 * 3600
_lock = threading.Lock()
_SCHEMA = '''
CREATE TABLE IF NOT EXISTS programme (provider TEXT, channel TEXT, start INTEGER, stop INTEGER, title TEXT, descr TEXT);
CREATE INDEX IF NOT EXISTS programme_ix ON programme (provider, channel, start);
CREATE TABLE IF NOT EXISTS channel (provider TEXT, id TEXT, name TEXT, norm TEXT, icon TEXT);
CREATE INDEX IF NOT EXISTS channel_ix ON channel (provider, norm);
CREATE TABLE IF NOT EXISTS meta (provider TEXT PRIMARY KEY, loaded INTEGER, source TEXT, programmes INTEGER);
'''


def _conn():
    c = sqlite3.connect(store.path('epg.db'), timeout=60)
    c.executescript(_SCHEMA)
    return c


def norm_name(s):
    """A channel name reduced for matching: lower case, letters and digits only, quality words dropped."""
    s = re.sub(r'\b(hd|fhd|uhd|sd|4k|hevc|h265)\b', ' ', (s or '').lower())
    return re.sub(r'[^a-z0-9]+', '', s)


def parse_time(s):
    """XMLTV time ('20261030180000 +0100', also without zone or seconds) -> unix seconds."""
    s = (s or '').strip()
    m = re.match(r'^(\d{8})(\d{4})?(\d{2})?\s*([+-]\d{4})?', s)
    if not m:
        return 0
    d, hm, sec, tz = m.groups()
    try:
        dt = datetime.strptime(d + (hm or '0000') + (sec or '00'), '%Y%m%d%H%M%S')
    except ValueError:
        return 0
    off = timedelta(0)
    if tz:
        off = timedelta(hours=int(tz[1:3]), minutes=int(tz[3:5])) * (1 if tz[0] == '+' else -1)
    return int((dt.replace(tzinfo=timezone.utc) - off).timestamp())


def _flush(c, provider_id, buf):
    c.executemany('INSERT INTO programme VALUES (?,?,?,?,?,?)', [(provider_id,) + r for r in buf])
    del buf[:]


def import_xmltv(provider_id, fileobj, source=''):
    """Replace this provider's guide with the XMLTV in `fileobj`. -> (channels, programmes) kept."""
    now = int(time.time())
    lo, hi = now - _BACK, now + _AHEAD
    head = fileobj.read(2)
    fileobj.seek(0)
    if head == b'\x1f\x8b':
        fileobj = gzip.open(fileobj, 'rb')
    with _lock:
        c = _conn()
        try:
            c.execute('DELETE FROM programme WHERE provider=?', (provider_id,))
            c.execute('DELETE FROM channel WHERE provider=?', (provider_id,))
            nch = npr = 0
            buf = []
            for _ev, el in ET.iterparse(fileobj, events=('end',)):
                tag = el.tag
                if tag == 'channel':
                    cid = el.get('id') or ''
                    names = [(n.text or '').strip() for n in el.findall('display-name') if (n.text or '').strip()]
                    icon = (el.find('icon').get('src') if el.find('icon') is not None else '') or ''
                    for n in names[:3] or ['']:
                        c.execute('INSERT INTO channel VALUES (?,?,?,?,?)', (provider_id, cid, n, norm_name(n), icon))
                    nch += 1
                    el.clear()
                elif tag == 'programme':
                    start, stop = parse_time(el.get('start')), parse_time(el.get('stop'))
                    if stop and stop >= lo and start <= hi:
                        t = el.find('title')
                        d = el.find('desc')
                        buf.append((el.get('channel') or '', start, stop or start + 1800, (t.text or '').strip() if t is not None else '',
                                    (d.text or '').strip() if d is not None else ''))
                        npr += 1
                        if len(buf) >= 5000:
                            _flush(c, provider_id, buf)
                    el.clear()
            _flush(c, provider_id, buf)
            c.execute('INSERT OR REPLACE INTO meta VALUES (?,?,?,?)', (provider_id, now, source, npr))
            c.commit()
            return nch, npr
        except Exception:
            c.rollback()
            raise
        finally:
            c.close()


def import_url(provider_id, url, user_agent=None):
    """Download an XMLTV address to a temp file (they can be tens of MB) and import it."""
    tmp = tempfile.NamedTemporaryFile(prefix='iptv_epg_', suffix='.xml', delete=False)
    try:
        with _http.get(url, stream=True, timeout=(10, 120), headers={'User-Agent': user_agent or 'Mozilla/5.0'}) as r:
            r.raise_for_status()
            shutil.copyfileobj(r.raw, tmp)
        tmp.close()
        with open(tmp.name, 'rb') as f:                      # a gzip file (or a gzip transfer of plain XML) is recognised by its first bytes
            return import_xmltv(provider_id, f, source=url)
    finally:
        try:
            os.remove(tmp.name)
        except OSError:
            pass


def import_rows(provider_id, rows, source='portal'):
    now = int(time.time())
    n = 0
    with _lock:
        c = _conn()
        try:
            c.execute('DELETE FROM programme WHERE provider=?', (provider_id,))
            buf = []
            for r in rows:
                buf.append(r)
                n += 1
                if len(buf) >= 5000:
                    _flush(c, provider_id, buf)
            _flush(c, provider_id, buf)
            c.execute('INSERT OR REPLACE INTO meta VALUES (?,?,?,?)', (provider_id, now, source, n))
            c.commit()
        finally:
            c.close()
    return n


def loaded_at(provider_id):
    c = _conn()
    try:
        row = c.execute('SELECT loaded FROM meta WHERE provider=?', (provider_id,)).fetchone()
        return row[0] if row else 0
    finally:
        c.close()


def _channel_id(c, provider_id, epg_id, name):
    if epg_id:
        row = c.execute('SELECT 1 FROM programme WHERE provider=? AND channel=? LIMIT 1', (provider_id, epg_id)).fetchone()
        if row:
            return epg_id
    n = norm_name(name)
    if n:
        row = c.execute('SELECT id FROM channel WHERE provider=? AND norm=? LIMIT 1', (provider_id, n)).fetchone()
        if row:
            return row[0]
    return None


def now_next(provider_id, epg_id='', name='', at=None):
    """{'now': {start, stop, title, desc} | None, 'next': ... | None}"""
    at = int(at or time.time())
    c = _conn()
    try:
        ch = _channel_id(c, provider_id, epg_id, name)
        if not ch:
            return {'now': None, 'next': None}
        rows = c.execute('SELECT start, stop, title, descr FROM programme WHERE provider=? AND channel=? AND stop>? ORDER BY start LIMIT 2',
                         (provider_id, ch, at)).fetchall()
        mk = lambda r: {'start': r[0], 'stop': r[1], 'title': r[2], 'desc': r[3]}
        now = mk(rows[0]) if rows and rows[0][0] <= at else None
        nxt = mk(rows[1] if now and len(rows) > 1 else rows[0]) if rows and (now is None or len(rows) > 1) else None
        return {'now': now, 'next': nxt if (nxt and (not now or nxt['start'] >= now['stop'] - 1)) else None}
    finally:
        c.close()


def guide(provider_id, channels, start, end):
    """channels: [(epg_id, name)] -> {epg_id: [programme dicts overlapping start..end]}"""
    c = _conn()
    try:
        out = {}
        for epg_id, name in channels:
            ch = _channel_id(c, provider_id, epg_id, name)
            if not ch:
                out[epg_id or name] = []
                continue
            rows = c.execute('SELECT start, stop, title, descr FROM programme WHERE provider=? AND channel=? AND stop>? AND start<? ORDER BY start',
                             (provider_id, ch, start, end)).fetchall()
            out[epg_id or name] = [{'start': r[0], 'stop': r[1], 'title': r[2], 'desc': r[3]} for r in rows]
        return out
    finally:
        c.close()


def drop_provider(provider_id):
    with _lock:
        c = _conn()
        try:
            for t in ('programme', 'channel', 'meta'):
                c.execute('DELETE FROM %s WHERE provider=?' % t, (provider_id,))
            c.commit()
        finally:
            c.close()
