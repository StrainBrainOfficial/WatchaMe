# -*- coding: utf-8 -*-
"""
iptv/xtream.py - Xtream Codes providers (player_api.php).

    live     get_live_categories / get_live_streams        -> {base}/live/{user}/{pass}/{stream_id}.{m3u8|ts}
    movie    get_vod_categories  / get_vod_streams         -> {base}/movie/{user}/{pass}/{stream_id}.{container_extension}
    series   get_series_categories / get_series / get_series_info -> {base}/series/{user}/{pass}/{episode_id}.{container_extension}
    guide    {base}/xmltv.php?username=..&password=..   (the whole guide as XMLTV)  and  get_short_epg for one channel

Every item is the plain dict described in catalog.py.
"""
import re

from starfleetscrapers.core import http as _http

_UA = 'Mozilla/5.0 (Linux; Android 11) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36'
_TIMEOUT = (8, 40)


def base_of(url):
    """http://host:port from whatever the viewer typed (a get.php or player_api.php address, a trailing slash, no scheme...)."""
    url = (url or '').strip()
    if '://' not in url:
        url = 'http://' + url
    m = re.match(r'^(https?://[^/?#]+)', url)
    return m.group(1) if m else url.rstrip('/')


def credentials_from_url(url):
    """(base, username, password) when the address itself carries them (get.php?username=..&password=..), else (base, '', '')."""
    from urllib.parse import parse_qs, urlparse
    q = parse_qs(urlparse(url if '://' in url else 'http://' + url).query)
    return base_of(url), (q.get('username') or [''])[0], (q.get('password') or [''])[0]


class Xtream(object):
    kind_names = {'live': 'live', 'movie': 'vod', 'series': 'series'}

    def __init__(self, provider):
        self.p = provider
        self.base = base_of(provider['url'])
        self.user = provider.get('username', '')
        self.password = provider.get('password', '')
        if not self.user:
            _b, self.user, self.password = credentials_from_url(provider['url'])
        self._info = None

    # ── plumbing ──
    def _api(self, action=None, **params):
        q = {'username': self.user, 'password': self.password}
        if action:
            q['action'] = action
        q.update({k: v for k, v in params.items() if v not in (None, '')})
        r = _http.get(self.base + '/player_api.php', params=q, timeout=_TIMEOUT,
                      headers={'User-Agent': self.p.get('user_agent') or _UA})
        r.raise_for_status()
        return r.json()

    def info(self):
        if self._info is None:
            self._info = self._api() or {}
        return self._info

    def test(self):
        """{'ok', 'message', 'info': {expires, connections, ...}}"""
        try:
            d = self.info()
        except Exception as e:
            return {'ok': False, 'message': 'Could not reach the server (%s)' % type(e).__name__, 'info': {}}
        u = d.get('user_info') or {}
        if str(u.get('auth')) != '1':
            return {'ok': False, 'message': 'The server refused the username or password', 'info': {}}
        status = u.get('status') or ''
        exp = u.get('exp_date')
        return {'ok': status.lower() in ('active', ''), 'message': 'Account %s' % (status or 'ok'),
                'info': {'expires': int(exp) if str(exp).isdigit() else None, 'connections': u.get('max_connections'),
                         'active': u.get('active_cons'), 'trial': u.get('is_trial') == '1'}}

    # ── lists ──
    def categories(self, kind):
        rows = self._api('get_%s_categories' % self.kind_names[kind]) or []
        return [{'id': str(c.get('category_id')), 'name': (c.get('category_name') or '').strip() or 'Uncategorised'}
                for c in rows if isinstance(c, dict)]

    def items(self, kind, category_id=None):
        if kind == 'live':
            rows = self._api('get_live_streams', category_id=category_id) or []
        elif kind == 'movie':
            rows = self._api('get_vod_streams', category_id=category_id) or []
        else:
            rows = self._api('get_series', category_id=category_id) or []
        out = []
        for r in rows if isinstance(rows, list) else []:
            if not isinstance(r, dict):
                continue
            if kind == 'live':
                sid = r.get('stream_id')
                out.append({'id': str(sid), 'kind': 'live', 'title': (r.get('name') or '').strip(), 'poster': r.get('stream_icon') or '',
                            'category_id': str(r.get('category_id')), 'epg_id': r.get('epg_channel_id') or '', 'num': r.get('num'),
                            'archive': bool(r.get('tv_archive')), 'ref': {'t': 'live', 'id': str(sid)}})
            elif kind == 'movie':
                sid = r.get('stream_id')
                out.append({'id': str(sid), 'kind': 'movie', 'title': (r.get('name') or '').strip(), 'poster': r.get('stream_icon') or '',
                            'rating': r.get('rating_5based') or r.get('rating') or '', 'year': _year(r),
                            'category_id': str(r.get('category_id')), 'added': r.get('added'),
                            'ref': {'t': 'movie', 'id': str(sid), 'ext': r.get('container_extension') or 'mp4'}})
            else:
                sid = r.get('series_id')
                out.append({'id': str(sid), 'kind': 'series', 'title': (r.get('name') or '').strip(), 'poster': r.get('cover') or '',
                            'plot': r.get('plot') or '', 'year': str(r.get('releaseDate') or r.get('release_date') or '')[:4],
                            'rating': r.get('rating_5based') or r.get('rating') or '', 'category_id': str(r.get('category_id')),
                            'ref': {'t': 'series', 'id': str(sid)}})
        return out

    def seasons(self, series_id):
        """{'info': {...}, 'seasons': {season number: [episode items]}}"""
        d = self._api('get_series_info', series_id=series_id) or {}
        info = d.get('info') or {}
        seasons = {}
        eps = d.get('episodes') or {}
        if isinstance(eps, list):                        # some servers send a flat list
            grouped = {}
            for e in eps:
                grouped.setdefault(str(e.get('season') or 1), []).append(e)
            eps = grouped
        for sn, rows in eps.items():
            try:
                snum = int(sn)
            except (TypeError, ValueError):
                continue
            for e in rows or []:
                ei = e.get('info') or {}
                seasons.setdefault(snum, []).append({
                    'id': str(e.get('id')), 'kind': 'episode', 'season': snum, 'episode': _int(e.get('episode_num')),
                    'title': (e.get('title') or 'Episode %s' % e.get('episode_num')).strip(), 'poster': ei.get('movie_image') or '',
                    'plot': ei.get('plot') or '', 'duration': ei.get('duration') or '',
                    'ref': {'t': 'episode', 'id': str(e.get('id')), 'ext': e.get('container_extension') or 'mp4'}})
        for rows in seasons.values():
            rows.sort(key=lambda x: x['episode'] or 0)
        return {'info': {'title': info.get('name') or '', 'plot': info.get('plot') or '', 'poster': info.get('cover') or '',
                         'backdrop': (info.get('backdrop_path') or [''])[0] if isinstance(info.get('backdrop_path'), list) else '',
                         'rating': info.get('rating') or '', 'genre': info.get('genre') or '', 'year': str(info.get('releaseDate') or '')[:4]},
                'seasons': dict(sorted(seasons.items()))}

    def movie_info(self, vod_id):
        d = self._api('get_vod_info', vod_id=vod_id) or {}
        i = d.get('info') or {}
        return {'plot': i.get('plot') or i.get('description') or '', 'poster': i.get('movie_image') or '', 'duration': i.get('duration') or '',
                'rating': i.get('rating') or '', 'genre': i.get('genre') or '', 'year': str(i.get('releasedate') or '')[:4],
                'tmdb_id': i.get('tmdb_id') or ''}

    # ── playing ──
    def resolve(self, item):
        ref = item.get('ref') or {}
        t, sid = ref.get('t'), ref.get('id')
        prefix = '%s/%s/%s/%s' % (self.base, {'live': 'live', 'movie': 'movie', 'episode': 'series'}[t], self.user, self.password)
        if t == 'live':
            ext = 'm3u8' if (self.p.get('live_format') or 'm3u8') == 'm3u8' else 'ts'
            return {'url': '%s/%s.%s' % (prefix, sid, ext), 'headers': {'User-Agent': self.p.get('user_agent') or _UA}}
        return {'url': '%s/%s.%s' % (prefix, sid, ref.get('ext') or 'mp4'), 'headers': {'User-Agent': self.p.get('user_agent') or _UA}}

    # ── guide ──
    def epg_url(self):
        return self.p.get('epg_url') or '%s/xmltv.php?username=%s&password=%s' % (self.base, self.user, self.password)

    def short_epg(self, stream_id, limit=4):
        d = self._api('get_short_epg', stream_id=stream_id, limit=limit) or {}
        out = []
        for e in d.get('epg_listings') or []:
            try:
                out.append({'start': int(e.get('start_timestamp')), 'stop': int(e.get('stop_timestamp')),
                            'title': _b64(e.get('title')), 'desc': _b64(e.get('description'))})
            except (TypeError, ValueError):
                continue
        return out


def _b64(s):
    import base64
    try:
        return base64.b64decode(s).decode('utf-8', 'replace')
    except Exception:
        return s or ''


def _int(v):
    try:
        return int(v)
    except (TypeError, ValueError):
        return 0


def _year(r):
    for k in ('year', 'releasedate', 'release_date'):
        v = str(r.get(k) or '')
        m = re.search(r'(19|20)\d\d', v)
        if m:
            return m.group(0)
    m = re.search(r'\((19|20)\d\d\)', r.get('name') or '')
    return m.group(0).strip('()') if m else ''
