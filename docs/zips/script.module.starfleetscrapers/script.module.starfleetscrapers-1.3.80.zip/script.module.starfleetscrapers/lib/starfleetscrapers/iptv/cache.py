# -*- coding: utf-8 -*-
"""iptv/cache.py - big provider lists (tens of thousands of VOD rows) are kept on disk as gzip JSON for a few hours, and in memory while
the process runs, so opening a category twice costs nothing."""
import gzip
import hashlib
import json
import os
import threading
import time

from starfleetscrapers.iptv import store

DEFAULT_TTL = 6 * 3600
_mem = {}
_lock = threading.Lock()


def _file(provider_id, key):
    d = store.path('cache')
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, '%s_%s.json.gz' % (provider_id, hashlib.md5(key.encode('utf-8')).hexdigest()[:16]))


def get(provider_id, key, ttl=DEFAULT_TTL):
    with _lock:
        hit = _mem.get((provider_id, key))
        if hit and time.time() - hit[0] < ttl:
            return hit[1]
    p = _file(provider_id, key)
    try:
        if time.time() - os.path.getmtime(p) < ttl:
            with gzip.open(p, 'rt', encoding='utf-8') as f:
                data = json.load(f)
            with _lock:
                _mem[(provider_id, key)] = (time.time(), data)
            return data
    except (OSError, ValueError):
        pass
    return None


def put(provider_id, key, data):
    with _lock:
        _mem[(provider_id, key)] = (time.time(), data)
    try:
        p = _file(provider_id, key)
        with gzip.open(p + '.tmp', 'wt', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False)
        os.replace(p + '.tmp', p)
    except OSError:
        pass
    return data


def drop_provider(provider_id):
    with _lock:
        for k in [k for k in _mem if k[0] == provider_id]:
            del _mem[k]
    d = store.path('cache')
    try:
        for n in os.listdir(d):
            if n.startswith(provider_id + '_'):
                os.remove(os.path.join(d, n))
    except OSError:
        pass


def clear():
    with _lock:
        _mem.clear()
    d = store.path('cache')
    try:
        for n in os.listdir(d):
            os.remove(os.path.join(d, n))
    except OSError:
        pass
