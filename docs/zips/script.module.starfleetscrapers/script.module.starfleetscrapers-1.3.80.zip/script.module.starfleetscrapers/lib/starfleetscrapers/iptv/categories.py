# -*- coding: utf-8 -*-
"""
iptv/categories.py - "manage categories": per provider and per kind (live, movie, series) the viewer can hide a category, rename it and put
the categories in their own order. The choices are kept apart from the provider's lists, so a refreshed provider keeps them, and a category
that appears later simply shows up at the end.

Adult-looking categories (xxx, adult, 18+...) are hidden by default; one switch (set_adult_hidden) shows them.

    apply(provider_id, kind, cats)              visible categories, renamed and ordered
    manager_rows(provider_id, kind, cats)       every category with hidden / renamed flags (what the manager screen lists)
    set_hidden / set_name / move / reset
"""
import re

from starfleetscrapers.iptv import store

_FILE = 'categories.json'
_ADULT = re.compile(r'\b(xxx|adult|adults|18\+|porn|porno|sex|erotic|erotica|hentai|playboy|brazzers|hustler|nsfw|onlyfans|camgirls?)\b', re.I)


def is_adult(name):
    return bool(_ADULT.search(name or ''))


def _prefs():
    return store.load(_FILE, {}) or {}


def adult_hidden():
    return _prefs().get('_adult_hidden', True)


def set_adult_hidden(hidden):
    p = _prefs()
    p['_adult_hidden'] = bool(hidden)
    store.save(_FILE, p)


def _kind_prefs(p, provider_id, kind, create=False):
    if create:
        return p.setdefault(provider_id, {}).setdefault(kind, {'cats': {}, 'order': []})
    return (p.get(provider_id) or {}).get(kind) or {'cats': {}, 'order': []}


def _hidden(kp, cat, adult_off):
    c = kp['cats'].get(cat['id'])
    if c is not None and 'hidden' in c:
        return bool(c['hidden'])
    return adult_off and is_adult(cat['name'])          # no choice made yet: adult-looking ones start hidden


def _ordered(kp, cats):
    pos = {cid: i for i, cid in enumerate(kp.get('order') or [])}
    base = {c['id']: i for i, c in enumerate(cats)}
    return sorted(cats, key=lambda c: (pos.get(c['id'], len(pos) + base[c['id']]),))


def manager_rows(provider_id, kind, cats):
    """[{'id', 'name' (shown), 'original', 'hidden', 'renamed'}] in the viewer's order, hidden ones included."""
    p = _prefs()
    kp = _kind_prefs(p, provider_id, kind)
    off = p.get('_adult_hidden', True)
    rows = []
    for c in _ordered(kp, cats):
        ov = kp['cats'].get(c['id']) or {}
        rows.append({'id': c['id'], 'name': ov.get('name') or c['name'], 'original': c['name'], 'hidden': _hidden(kp, c, off),
                     'renamed': bool(ov.get('name'))})
    return rows


def apply(provider_id, kind, cats, include_hidden=False):
    rows = manager_rows(provider_id, kind, cats)
    return [{'id': r['id'], 'name': r['name']} for r in rows if include_hidden or not r['hidden']]


def set_hidden(provider_id, kind, category_id, hidden):
    p = _prefs()
    kp = _kind_prefs(p, provider_id, kind, create=True)
    kp['cats'].setdefault(str(category_id), {})['hidden'] = bool(hidden)
    store.save(_FILE, p)


def set_all_hidden(provider_id, kind, cats, hidden):
    p = _prefs()
    kp = _kind_prefs(p, provider_id, kind, create=True)
    for c in cats:
        kp['cats'].setdefault(c['id'], {})['hidden'] = bool(hidden)
    store.save(_FILE, p)


def set_name(provider_id, kind, category_id, name):
    """Rename; an empty name goes back to the provider's own."""
    p = _prefs()
    kp = _kind_prefs(p, provider_id, kind, create=True)
    ov = kp['cats'].setdefault(str(category_id), {})
    if (name or '').strip():
        ov['name'] = name.strip()
    else:
        ov.pop('name', None)
    store.save(_FILE, p)


def move(provider_id, kind, category_id, delta, cats):
    """Shift one category up (negative delta) or down in the viewer's order; `cats` is the provider's current list."""
    p = _prefs()
    kp = _kind_prefs(p, provider_id, kind, create=True)
    ids = [c['id'] for c in _ordered(kp, cats)]
    category_id = str(category_id)
    if category_id not in ids:
        return
    i = ids.index(category_id)
    j = max(0, min(len(ids) - 1, i + int(delta)))
    ids.insert(j, ids.pop(i))
    kp['order'] = ids
    store.save(_FILE, p)


def reset(provider_id, kind=None):
    p = _prefs()
    if provider_id in p:
        if kind:
            p[provider_id].pop(kind, None)
        else:
            p.pop(provider_id)
        store.save(_FILE, p)
