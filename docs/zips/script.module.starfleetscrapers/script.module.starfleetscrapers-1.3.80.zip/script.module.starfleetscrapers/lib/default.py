# -*- coding: utf-8 -*-
"""Entry point of the Starfleet Scrapers add-on when it is opened from the add-on list: its settings (which torrent
sources are on, hoster / sports / live TV options). Everything else in this add-on is a module other add-ons import."""
import sys
from urllib.parse import parse_qsl

import xbmcaddon

ADDON_ID = 'script.module.starfleetscrapers'


def _params():
    try:
        return dict(parse_qsl(sys.argv[2].replace('?', '')))
    except Exception:
        return {}


def main():
    action = _params().get('action')
    addon = xbmcaddon.Addon(ADDON_ID)
    if action in (None, '', 'settings', 'StarfleetScrapersSettings'):
        addon.openSettings()


if __name__ == '__main__':
    main()
