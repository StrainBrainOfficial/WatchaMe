# -*- coding: utf-8 -*-
"""
resources/lib/torrent_sources.py

Search multiple torrent sites for a title and return magnet links.
Results are used with debrid services (Real-Debrid, AllDebrid, Premiumize, TorBox)
to get instant cached streams — uncached torrents are skipped.

Sources:
  YTS          — JSON API, movies only, high quality
  1337x        — HTML scraping, mirror rotation + CF bypass
  The Pirate Bay — JSON API, movies + TV + adult
  EZTV         — JSON API, TV shows
  Bitsearch    — DHT index scrape
  TorrentGalaxy — HTML scraping + CF bypass
  YourBitTorrent — HTML scraping
  Bitlord      — HTML scraping
  Knaben       — aggregated JSON API (movies/TV/adult)
  Torrentio    — Stremio IMDB-based API
  Torrentdownload — HTML scraping
  XXXClub        — HTML scraping, adult only
"""

from starfleetscrapers import host as _sfhost
import hashlib
import re
import time
import xbmc
import xbmcaddon
import xbmcvfs

try:
    from starfleetscrapers.core import http as _req
except ImportError:
    _req = None

try:
    from starfleetscrapers.core.title_utils import clean_adult_title as _clean_adult_title
except Exception:
    def _clean_adult_title(t):
        return t

try:
    from starfleetscrapers.core import cache as _cache
    _PROFILE = _sfhost.profile()
    _cache.init(_PROFILE + '/cache.db')
    _HAS_CACHE = True
except Exception:
    _HAS_CACHE = False

# ── Quality helpers ───────────────────────────────────────────────────────────

# High-quality markers
_QUALITY_HQ = re.compile(
    r'\b(?:720p?|1080p?|1080i|2160p?|4320p?|4k|8k|uhd|3d|bd(?:rip|remux)|bluray|blu[-\s]?ray)\b',
    re.IGNORECASE
)
# Any recognisable video quality marker (accepts HDTV/WEB/x265 without resolution)
_QUALITY_ANY = re.compile(
    r'\b(?:720|1080|2160|4320|4k|8k|uhd|3d|bluray|blu.ray|bdrip|bdremux|'
    r'web[-.]?dl|webdl|webrip|web.rip|hdtv|hdrip|dvdrip|dvd|'
    r'x264|x265|hevc|h\.?264|h\.?265|xvid|avc|hevcrip|remux|'
    r'hdcam|scr|screener|dvdscr)\b',
    re.IGNORECASE
)
# Definitively low-quality markers — anything below the 540p floor, plus
# camrip/screener junk regardless of any resolution tag it might also carry.
# telesync/hdts are the same cam-sourced junk tier as camrip/hdcam (footage
# captured off a cinema screen, sometimes with a separate audio feed synced
# in) but were missing from this list — confirmed live this let releases
# like "The Odyssey 2026 2160pHD TELESYNC..." and "...2160PHD HQ HDTS..."
# through _meets_quality and get mislabeled '4K'/'1080p' by _extract_quality
# below, purely because a genuine cam rip can never actually contain real
# 2160p/1080p detail no matter what resolution tag the release name claims.
# That's not just a mislabel: it's the exact scam-torrent pattern behind
# the malware-disguised-magnet issue found earlier in this same title's
# results (a popular real TELESYNC release's name cloned with a bogus 4K
# tag swapped in), and it was crowding real WEB/BluRay 4K releases out of
# the top-seeded quick-check candidates entirely.
_QUALITY_LQ = re.compile(
    r'\b(?:480p?|360p?|240p?|camrip|hdcam|telesync|hdts|scr|screener|dvdscr|dvdrip)\b',
    re.IGNORECASE
)

_QUALITY_LQ_HARD = re.compile(r'\b(?:camrip|hdcam|telesync|hdts|scr|screener|dvdscr)\b', re.IGNORECASE)
_sd_rips_cache = [0.0, True]


def _include_sd_rips():
    """Setting 'include_sd_rips' (default on): DVD rips and 480p releases are real releases, just low quality, so they stay in the
    list (they sort last); off drops them like CAM / telesync copies, which are always dropped."""
    now = __import__('time').time()
    if now - _sd_rips_cache[0] > 20:
        try:
            v = (_sfhost.addon().getSetting('include_sd_rips') or 'true').strip().lower()
        except Exception:
            v = 'true'
        _sd_rips_cache[0], _sd_rips_cache[1] = now, v != 'false'
    return _sd_rips_cache[1]


# Text-month embedded dates (e.g. "June 13, 2015", "13 Sept", "April 13") —
# used by search_all()'s title filter to keep a release date's day number
# from spuriously satisfying a numeric query word like a scene/sequel number.
_MONTH_NAMES = (r'jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|'
                r'jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:t(?:ember)?)?|'
                r'oct(?:ober)?|nov(?:ember)?|dec(?:ember)?')
_RE_MONTH_DAY_YEAR = re.compile(
    r'\b(?:' + _MONTH_NAMES + r')\.?\s+\d{1,2}(?:st|nd|rd|th)?,?\s*(?:\d{2,4})?\b',
    re.IGNORECASE
)
_RE_DAY_MONTH = re.compile(
    r'\b\d{1,2}(?:st|nd|rd|th)?\s+(?:' + _MONTH_NAMES + r')\.?,?\s*(?:\d{2,4})?\b',
    re.IGNORECASE
)
# Numeric date already space-separated in the source title (e.g. "06 13
# 2015") rather than dot/slash-separated — requires a 19xx/20xx year to
# stay narrow enough not to eat unrelated three-number sequences.
_RE_NUM_DATE_SPACED = re.compile(r'\b\d{1,2}\s+\d{1,2}\s+(?:19|20)\d{2}\b')
# Patterns that identify non-video content (games, software, ebooks, music)
_NON_VIDEO = re.compile(
    r'(?:'
    r'\[(?:Nintendo\s*Switch|NSZ|XCI|NSW|PS[345]|XBOX|PC\s*Game|NDS|3DS|GBA)\]'
    r'|Nintendo\s*Switch'
    r'|(?<!\d)v\d+\.\d+[\.\d]*(?:[- ]|$)'  # software version like v2025.11.22
    r'|\bBuild\s+\d{5,}\b'                  # game build numbers like "Build 13275298"
    r'|\bUpdate\s+v\d'                       # "Update v1" game update pattern
    r'|\bNSZ\b|\bXCI\b|\bNSP\b' # Switch formats
    r'|\[P\]'                    # Knaben game/app marker
    r'|\bAndroid\b|\biOS\b|\bAPK\b'
    r'|-(?:TENOKE|RELOADED|CODEX|SKIDROW|PLAZA|FLT|HOODLUM|GOG|DARKSIDERS|CPY)\b'  # game crack groups
    r')',
    re.IGNORECASE
)
# Adult content markers — excluded from movie/tv results
_IS_ADULT = re.compile(r'\b(?:XXX|adult|porn|sex)\b', re.IGNORECASE)

# EZTV only ever indexed TV shows, never movies (confirmed by user) — EZTV
# itself has also been dead/CF-blocked for years (see search_all()'s own
# "Dead permanently" notes), so nothing genuine is being freshly released
# under that branding either way. A torrent for a MOVIE title carrying an
# "EZTV" tag is therefore not just stale, it's definitionally fake — and
# confirmed live this is exactly the scam-clone pattern behind both the
# disguised-.exe malware and the fake-4K TELESYNC releases found for the
# same title: several "The Odyssey ... EZTV" entries claiming 2160p/4K,
# none of which could be genuine EZTV content since EZTV never covered
# movies at all. Movie-only — real EZTV TV-show releases from when the
# site was alive are still legitimately re-seeded/cached elsewhere.
_RE_FAKE_EZTV = re.compile(r'\beztv\b', re.IGNORECASE)


def _meets_quality(text, media_type='movie'):
    """
    Return True if this torrent is acceptable quality.
    Rejects explicit LQ markers (480p, cam, screener) and non-video content
    (games, software) for movie/tv searches.
    """
    if media_type == 'adult':
        return True
    s = text or ''
    if (_QUALITY_LQ_HARD if _include_sd_rips() else _QUALITY_LQ).search(s):
        return False
    if media_type in ('movie', 'tv'):
        if _NON_VIDEO.search(s):
            return False
        if _IS_ADULT.search(s):
            return False
    if media_type == 'movie' and _RE_FAKE_EZTV.search(s):
        return False
    return True


def _extract_quality(text):
    # Substring matching (not strict \b-bounded regex) for the resolution
    # tiers, matching gearsscrapers' source_utils.get_qual() breadth -- real
    # scene-release names routinely butt the resolution token right up
    # against other alnum content with no word boundary at all (e.g.
    # "2160p10bit", "2160p60fps", "4kUHD"), which a trailing \b silently
    # rejected even though the release genuinely was that quality. Also
    # catches the "216o"/"108o"/"72o" letter-for-zero obfuscation some sites
    # use, and "ultrahd"/"ultra.hd" as additional 4K signals gears checks
    # for that the old regex never did.
    text = (text or '').lower()
    if '4320' in text or '7680x' in text or re.search(r'(?<![a-z0-9])8k(?![a-z0-9])', text):
        return '8K'
    if any(s in text for s in ('2160', '216o', '4k', 'ultrahd', 'ultra.hd', 'ultra hd', 'uhd')):
        return '4K'
    if any(s in text for s in ('1080', '1o8o', '108o', '1o80', 'fhd')):
        return '1080p'
    if '720' in text or '72o' in text:
        return '720p'
    if '3d' in text:
        return '3D'
    if 'bluray' in text or 'blu-ray' in text or 'blu ray' in text:
        return 'Blu-ray'
    if 'webdl' in text or 'web-dl' in text or 'web.dl' in text or 'web dl' in text:
        return 'WEB-DL'
    if 'webrip' in text:
        return 'WEBRip'
    if 'hdtv' in text:
        return 'HDTV'
    return ''


# ── HTTP session & Cloudflare bypass ─────────────────────────────────────────

_BROWSER_HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/126.0.0.0 Safari/537.36'
    ),
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9',
    # No 'br' (Brotli) — decoding it depends on an optional brotli/brotlicffi
    # package this environment doesn't have installed, so a Brotli-encoded
    # response (which Cloudflare-fronted sites serve whenever Accept-Encoding
    # allows it) came back as raw compressed garbage instead of real HTML.
    # Confirmed live against limetorrents.fun: a real 200 response, silently
    # unusable, looking exactly like the site being dead. gzip/deflate are
    # handled natively with no extra dependency.
    'Accept-Encoding': 'gzip, deflate',
    'DNT': '1',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
}

# Full Chrome headers for CF-protected sites (includes sec-ch-ua and sec-fetch-* fields)
_CF_HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/126.0.0.0 Safari/537.36'
    ),
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'Accept-Language': 'en-US,en;q=0.9',
    # No 'br' (Brotli) — decoding it depends on an optional brotli/brotlicffi
    # package this environment doesn't have installed, so a Brotli-encoded
    # response (which Cloudflare-fronted sites serve whenever Accept-Encoding
    # allows it) came back as raw compressed garbage instead of real HTML.
    # Confirmed live against limetorrents.fun: a real 200 response, silently
    # unusable, looking exactly like the site being dead. gzip/deflate are
    # handled natively with no extra dependency.
    'Accept-Encoding': 'gzip, deflate',
    'Cache-Control': 'max-age=0',
    'sec-ch-ua': '"Not/A)Brand";v="8", "Chromium";v="126", "Google Chrome";v="126"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'Sec-Fetch-Dest': 'document',
    'Sec-Fetch-Mode': 'navigate',
    'Sec-Fetch-Site': 'none',
    'Sec-Fetch-User': '?1',
    'Upgrade-Insecure-Requests': '1',
    'Connection': 'keep-alive',
}

from starfleetscrapers.core import net_guard as _net_guard

_session = None
_cf_session = None  # cloudscraper session (created lazily)


def _sess():
    global _session
    if _session is None and _req:
        _session = _req.Session()
        _session.headers.update(_BROWSER_HEADERS)
        # No retries — scrapers each have explicit timeouts; retrying a timed-out
        # connection wastes 3× the time (e.g. EZTV hitting 24s instead of 8s).
        # pool_connections/pool_maxsize were sized for a much smaller source
        # list -- confirmed live that with search_all() now running 20-27
        # sources truly concurrently (each hitting a different host) sharing
        # this one session, a pool this small caused real connection-pool
        # contention: the whole batch took 24.9s even though the single
        # slowest individual source only took 12.2s in isolation. Sized well
        # above the realistic peak concurrent-host count so no request ever
        # has to wait on pool space that a DIFFERENT host's requests are
        # sitting on.
        a = _req.adapters.HTTPAdapter(
            pool_connections=40, pool_maxsize=40,
            max_retries=_req.adapters.Retry(total=0, redirect=False)
        )
        _session.mount('https://', a)
        _session.mount('http://', a)
        _net_guard.guard(_session)
    return _session


def _get_cf_session():
    """Return a Cloudflare-bypass session (cloudscraper) if available, else None."""
    global _cf_session
    if _cf_session is not None:
        return _cf_session
    try:
        import cloudscraper as _cs
        _cf_session = _cs.create_scraper(
            browser={'browser': 'chrome', 'platform': 'windows', 'mobile': False}
        )
        _net_guard.guard(_cf_session)
        xbmc.log('[Starfleet/Torrents] cloudscraper loaded', xbmc.LOGINFO)
        return _cf_session
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] cloudscraper init failed: %s' % e, xbmc.LOGWARNING)
    return None


def _get(url, timeout=10, cf=False):
    """HTTP GET. If cf=True, try cloudscraper first to bypass Cloudflare."""
    if cf:
        cs = _get_cf_session()
        if cs:
            try:
                r = cs.get(url, timeout=timeout)
                r.raise_for_status()
                return r.text
            except Exception as e:
                xbmc.log('[Starfleet/Torrents] CF session failed (%s): %s' % (url[:60], e),
                         xbmc.LOGWARNING)
    s = _sess()
    if s:
        r = s.get(url, timeout=timeout)
        r.raise_for_status()
        return r.text
    # Fallback: urllib (always available in Kodi's Python)
    try:
        import urllib.request as _ur
        req = _ur.Request(url, headers=_BROWSER_HEADERS)
        with _ur.urlopen(req, timeout=timeout) as resp:
            return resp.read().decode('utf-8', errors='replace')
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] urllib fallback failed (%s): %s' % (url[:60], e),
                 xbmc.LOGWARNING)
        return ''


def _get_json(url, timeout=10):
    s = _sess()
    if not s:
        return None
    r = s.get(url, timeout=timeout)
    r.raise_for_status()
    return r.json()


# Expanded tracker list (2026-08-27, per explicit request) — appended to
# every magnet this addon builds from a bare info_hash (a site that gives
# us a hash/id but no ready-made magnet of its own). More trackers means
# more independent chances to find an active announce for this exact
# torrent's swarm, which matters most for thin/older releases where DHT
# alone is slow to bootstrap, and gives a debrid service more paths to
# confirm "instantly available" or finish caching quickly. A magnet a site
# already hands back fully-formed (with its own embedded trackers) is left
# as-is — this list only fills in for the ones this addon builds itself.
_GOOD_TRACKERS = [
    'udp://tracker.opentrackr.org:1337/announce',
    'udp://open.tracker.cl:1337/announce',
    'udp://tracker.openbittorrent.com:6969/announce',
    'udp://open.stealth.si:80/announce',
    'udp://tracker-udp.gbitt.info:80/announce',
    'http://ipv4announce.sktorrent.eu:6969/announce',
    'udp://tracker.torrent.eu.org:451/announce',
    'udp://evan.im:6969/announce',
    'udp://bittorrent-tracker.e-n-c-r-y-p-t.net:1337/announce',
    'http://tracker.waaa.moe:6969/announce',
    'https://tracker.leechshield.link:443/announce',
    'udp://tracker.corpscorp.online:80/announce',
    'https://tracker.7471.top:443/announce',
    'https://tracker.lenition.de:443/announce',
    'udp://tracker.nyaa.net:6969/announce',
    'udp://tracker.cn.nyaa.net:6969/announce',
    'udp://tracker.qu.ax:6969/announce',
    'udp://tracker.0x7c0.com:6969/announce',
    'udp://martin-gebhardt.eu:25/announce',
    'udp://torrent.tracker.durukanbal.com:6969/announce',
    'udp://tr4ck3r.duckdns.org:6969/announce',
    'http://wegkxfcivgx.ydns.eu:80/announce',
    'udp://ns575949.ip-51-222-82.net:6969/announce',
    'https://004430.xyz:443/announce',
    'http://bt1.archive.org:6969/announce',
    'udp://open.ftorrent.com:443/announce',
    'udp://torrentclub.online:1984/announce',
    'https://tracker.foreverpirates.co:443/announce',
    'udp://tracker.dler.com:6969/announce',
    'https://t.213891.xyz:443/announce',
    'https://tracker.nekomi.cn:443/announce',
    'udp://tracker.aruku.ovh:8081/announce',
    'udp://tracker.teambelgium.net:6969/announce',
    'udp://tracker.nexusstream.eu:6969/announce',
    'http://tracker.dhitechnical.com:6969/announce',
    'https://tracker.pmman.tech:443/announce',
    'https://tracker.zhuqiy.com:443/announce',
    'http://tracker.mywaifu.best:6969/announce',
    'udp://tracker.k.vu:6969/announce',
    'udp://mail.segso.net:6969/announce',
    'udp://tracker.peerfect.org:6969/announce',
    'udp://tracker.opentrackr.com:6969/announce',
    'udp://tracker.ilibr.org:6969/announce',
    'https://tracker.gcrenwp.top:443/announce',
    'udp://tracker.breizh.pm:6969/announce',
    'udp://tracker.gmi.gd:6969/announce',
    'udp://tracker.farted.net:6969/announce',
    'http://tracker.renfei.net:8080/announce',
    'http://bt2.archive.org:6969/announce',
    'udp://tracker.cynma.tv:6969/announce',
    'udp://obey.torrentonline.cc:42069/announce',
    'udp://whybother.torrentonline.cc:42069/announce',
]


def _json_from_mirrors(bases, path, timeout=12):
    """First non-empty JSON answer for `path` from a list of equivalent public instances (the same addon hosted by
    several people): one instance being down or rate-limited no longer loses the whole source."""
    for base in bases:
        try:
            data = _get_json(base + path, timeout=timeout)
        except Exception as e:
            xbmc.log('[Starfleet/Torrents] %s unavailable (%s) - trying the next instance' % (base, e), xbmc.LOGINFO)
            continue
        if data:
            return data
    return None


def _trackers():
    """Today's public tracker list (community 'best' list, cached for a day) followed by the curated list above."""
    try:
        from starfleetscrapers.core import tracker_list as _tl
        merged = list(_tl.get())
    except Exception:
        merged = []
    for t in _GOOD_TRACKERS:
        if t not in merged:
            merged.append(t)
    return merged[:48]


def _make_magnet(info_hash, name=''):
    dn = ('&dn=' + _req.utils.quote(name)) if name and _req else ''
    tr = ''.join('&tr=' + t for t in _trackers())
    return 'magnet:?xt=urn:btih:%s%s%s' % (info_hash.lower(), dn, tr)


def _bencode_skip(data, i):
    """Return the index just past the bencoded value starting at offset i
    (int/list/dict/string, generic — doesn't care which)."""
    c = data[i:i + 1]
    if c == b'i':
        return data.index(b'e', i) + 1
    if c in (b'l', b'd'):
        j = i + 1
        while data[j:j + 1] != b'e':
            j = _bencode_skip(data, j)
        return j + 1
    colon = data.index(b':', i)
    length = int(data[i:colon])
    return colon + 1 + length


def _torrent_info_hash(torrent_bytes):
    """SHA1 info_hash of a raw .torrent file's bencoded 'info' dict --
    bencode is byte-exact/canonical, so hashing the original raw slice
    (found by walking the structure, not re-encoding a parsed dict) is
    equivalent to the standard BitTorrent info_hash computation."""
    idx = torrent_bytes.find(b'4:info')
    if idx == -1:
        return None
    start = idx + len(b'4:info')
    try:
        end = _bencode_skip(torrent_bytes, start)
    except Exception:
        return None
    import hashlib
    return hashlib.sha1(torrent_bytes[start:end]).hexdigest()


def _torrent_own_tracker(torrent_bytes):
    """The .torrent file's own top-level 'announce' URL (a bencoded
    length-prefixed string right after the 'announce' key) — for a private
    tracker this embeds the account's passkey, so building a magnet with
    THIS tracker instead of _make_magnet()'s public ones is what actually
    lets a debrid service (or any client) join that tracker's own swarm,
    at the cost of that traffic then counting toward the account's ratio
    same as any other client would. Per direct request 2026-09-07 for
    BitPorn/Podzemlje specifically — every other source in this file stays
    on the public-tracker _make_magnet() path, this is deliberately scoped
    to just the two private-tracker personal sources that need it."""
    idx = torrent_bytes.find(b'8:announce')
    if idx == -1:
        return None
    start = idx + len(b'8:announce')
    colon = torrent_bytes.find(b':', start)
    if colon == -1:
        return None
    try:
        length = int(torrent_bytes[start:colon])
        url = torrent_bytes[colon + 1:colon + 1 + length].decode('utf-8', 'ignore')
        return url if url.startswith('http') or url.startswith('udp://') else None
    except Exception:
        return None


def _make_private_magnet(info_hash, name, tracker_url):
    """Same shape as _make_magnet() but with exactly one tracker — the
    private tracker's own passkey-embedded announce URL — instead of the
    public tracker list, so peer discovery actually goes through that
    tracker's real swarm. Falls back to _make_magnet()'s public trackers
    if the .torrent file's own announce URL couldn't be extracted."""
    if not tracker_url:
        return _make_magnet(info_hash, name)
    dn = ('&dn=' + _req.utils.quote(name)) if name and _req else ''
    tr = '&tr=' + (_req.utils.quote(tracker_url, safe='') if _req else tracker_url)
    return 'magnet:?xt=urn:btih:%s%s%s' % (info_hash.lower(), dn, tr)


# ── YTS ──────────────────────────────────────────────────────────────────────

_YTS_DOMAINS = [
    'https://yts.lt',
    'https://yts.mx',
    'https://yts.proxyninja.org',
    'https://yts.lu',
    'https://www13.yts.lu',
    'https://movies-api.accel.li',
]


def search_yts(title, year=None, limit=5, media_type='movie'):
    # YTS is a mainstream-only movie site — no adult content at all, so
    # 'adult' is deliberately excluded here too (defense-in-depth alongside
    # search_all()'s own gate, in case something else ever calls this
    # directly with media_type='adult').
    if media_type != 'movie':
        return []
    try:
        # Don't append year — YTS API is strict with full-string matching,
        # title-only gets more results (year can be checked post-fetch if needed)
        params = {'query_term': title, 'limit': limit, 'sort_by': 'seeds'}
        qs = '&'.join('%s=%s' % (k, v) for k, v in params.items())
        data = None
        for domain in _YTS_DOMAINS:
            try:
                data = _get_json(domain + '/api/v2/list_movies.json?' + qs)
            except Exception:                    # dead / blocked domain: next mirror, not "no results"
                data = None
            if data and data.get('status') == 'ok':
                break
            data = None
        if not data:
            return []
        movies = data.get('data', {}).get('movies') or []
        results = []
        for movie in movies:
            for tor in movie.get('torrents', []):
                ih = tor.get('hash', '')
                if not ih:
                    continue
                quality = tor.get('quality', '')
                if not _meets_quality(quality, media_type):
                    continue
                results.append({
                    'title':     movie.get('title_english') or movie.get('title', ''),
                    'year':      movie.get('year', ''),
                    'quality':   _extract_quality(quality) or quality,
                    'info_hash': ih,
                    'magnet':    _make_magnet(ih, movie.get('title', '')),
                    'seeds':     tor.get('seeds', 0),
                    'size':      tor.get('size', ''),
                    'source':    'YTS',
                })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] YTS error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Zooqle (movies-only meta-index — its own detail pages link out to the
# actual torrent host, e.g. yts.mx, with the info hash right there in the
# download URL; no distinct "adult" section exists on the site at all, so
# it's wired in unconditionally like TPB/Knaben/etc rather than gated to
# a media_type, same as those) ────────────────────────────────────────────────

# Confirmed live 2026-09-12: zooqle.pro and zooqle.movie both return a
# real-looking 200 homepage but neither actually serves search results
# (0 matches for a real query on either, different template from the
# other three) — same "loads fine but isn't actually the working site"
# trap as TorrentGalaxy's dead decoy mirror elsewhere in this file, so
# they're deliberately left out of rotation below rather than included
# and silently wasting a request every time.
_ZOOQLE_MIRRORS = ['zooqle.app', 'zooqle.io', 'zooqlemovies.com']
_zooqle_working = {}


def _get_zooqle_base():
    cached = _zooqle_working.get('url')
    ts = _zooqle_working.get('ts', 0)
    if cached and (time.time() - ts) < 3600:
        return cached
    for mirror in _ZOOQLE_MIRRORS:
        try:
            url = 'https://%s' % mirror
            html = _get(url + '/?keyword=inception', timeout=6)
            if html and '/movies/inception' in html.lower():
                _zooqle_working['url'] = url
                _zooqle_working['ts'] = time.time()
                return url
        except Exception:
            continue
    return 'https://' + _ZOOQLE_MIRRORS[0]


def _zooqle_patterns(base):
    domain = re.escape(base.split('://', 1)[-1])
    result_re = re.compile(
        r'href="(https://%s/movies/[a-z0-9-]+)"[^>]*title="([^"]{2,120})"' % domain,
        re.IGNORECASE
    )
    return result_re


_RE_ZOOQLE_DL = re.compile(
    r'href="(https://[^"]+/torrent/download/([A-F0-9]{40}))"[\s\S]*?>([^<]{2,120})<',
    re.IGNORECASE
)


def search_zooqle(title, year=None, limit=10, media_type='movie'):
    """Zooqle — search page lists candidate movie pages; each movie page's
    own torrent table links out to the real host (yts.mx confirmed live,
    possibly others) with the 40-char info hash sitting directly in the
    download URL — no magnet or extra detail fetch needed for that part,
    just the one candidate-page fetch per matching movie."""
    if media_type not in ('movie', 'adult'):
        return []
    try:
        from urllib.parse import quote as _q
        query = re.sub(r'\s+', ' ', title).strip()
        if not query:
            return []
        base = _get_zooqle_base()
        # Confirmed live this endpoint either responds quickly or not at all
        # -- a query that's going to fail did so at essentially the full 12s
        # with zero results, making it the single longest pole in the whole
        # movie-search batch for no payoff. Trimmed to fail fast instead.
        search_html = _get('%s/?keyword=%s' % (base, _q(query)), timeout=6)
        if not search_html:
            return []

        def _nc(s):
            return re.sub(r'\s+', ' ', re.sub(r'[^a-z0-9 ]', ' ', s.lower())).strip()

        norm_query = _nc(query)
        seen_urls = set()
        candidates = []
        result_re = _zooqle_patterns(base)
        for page_url, name in result_re.findall(search_html):
            if page_url in seen_urls:
                continue
            seen_urls.add(page_url)
            core = _nc(name)
            if not core:
                continue
            if norm_query in core or core in norm_query:
                candidates.append(page_url)
            if len(candidates) >= 4:
                break

        if not candidates:
            return []

        results = []
        from concurrent.futures import ThreadPoolExecutor

        def _fetch_page(page_url):
            html = _get(page_url, timeout=10)
            out = []
            if not html:
                return out
            for dl_url, info_hash, label in _RE_ZOOQLE_DL.findall(html):
                out.append({
                    'title':     label.strip(),
                    'info_hash': info_hash.lower(),
                    'magnet':    _make_magnet(info_hash, label.strip()),
                    'seeds':     0,
                    'size':      '',
                    'source':    'Zooqle',
                })
            return out

        with ThreadPoolExecutor(max_workers=len(candidates)) as pool:
            for page_results in pool.map(_fetch_page, candidates):
                results.extend(page_results)
                if len(results) >= limit:
                    break
        return results[:limit]
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Zooqle error: %s' % e, xbmc.LOGWARNING)
        return []


# ── KONTRAST (small curated x265 release group — movies + full TV season
# packs, no per-episode releases). Its own HTML search page AND even its
# RSS feed's `?search=` query param are behind a genuine Cloudflare JS
# challenge (confirmed live both ways), but the bare unfiltered feed
# (/feed/rss) is NOT protected and hands back a rolling ~30-item window of
# fully-resolved items -- title, category, infoHash and a ready-to-use
# magnet URI, no per-item detail fetch or bencode parsing needed at all.
# Since server-side filtering is blocked, this fetches the whole feed once
# and matches locally -- low hit rate per search (only catches whatever
# KONTRAST happens to have released in roughly the last ~12 days), but
# zero extra cost when it does hit. ──────────────────────────────────────────

KONTRAST_BASE = 'https://kontrast.top'

_RE_KONTRAST_ITEM = re.compile(
    r'<item><title>\[[^\]]*\]\s*([^<(]+?)(?:\s*\([^)]*\))?</title>'
    r'<category>([^<]+)</category>.*?'
    r'<torrent:infoHash>([a-fA-F0-9]{40})</torrent:infoHash>'
    r'<torrent:magnetURI><!\[CDATA\[(magnet:[^\]]+)\]\]></torrent:magnetURI>',
    re.IGNORECASE
)


def search_kontrast(title, year=None, limit=10, media_type='movie'):
    """KONTRAST — fetches the site's own unfiltered RSS feed (its `?search=`
    param is Cloudflare-walled just like the HTML search page) and matches
    the requested title locally against whatever's currently in the
    feed's rolling window.

    The feed itself was never cached — every single search re-fetched the
    same ~30-item, ~75KB feed from scratch, even for a second title looked
    up moments after the first. Confirmed live the feed only actually
    shifts a few times a day at most (it's the group's own release
    cadence, not a live-updating page), so a short cache here costs
    nothing in real freshness while turning every search after the first
    one in a session into a pure local-match pass instead of a repeat
    network round-trip."""
    if media_type not in ('movie', 'tv'):
        return []
    try:
        xml = _cache.get('kontrast_feed') if _HAS_CACHE else None
        if xml is None:
            xml = _get(KONTRAST_BASE + '/feed/rss', timeout=8)
            if _HAS_CACHE and xml:
                _cache.set('kontrast_feed', xml, 900)
        if not xml:
            return []

        def _nc(s):
            return re.sub(r'\s+', '', re.sub(r'[^a-z0-9]', ' ', s.lower())).strip()

        norm_title = _nc(title)
        if not norm_title:
            return []

        results = []
        for raw_name, category, info_hash, magnet in _RE_KONTRAST_ITEM.findall(xml):
            if len(results) >= limit:
                break
            cat_media = 'tv' if category.strip().lower() == 'tv' else 'movie'
            if cat_media != media_type:
                continue
            name = raw_name.strip()
            if norm_title not in _nc(name):
                continue
            # Season packs don't carry the show's premiere year in the
            # filename, so only enforce a year match for movies.
            if year and media_type == 'movie' and str(year) not in name:
                continue
            if not _meets_quality(name, media_type):
                continue
            results.append({
                'title':     name,
                'year':      year or '',
                'quality':   _extract_quality(name),
                'info_hash': info_hash.lower(),
                'magnet':    magnet.replace('&amp;', '&'),
                'seeds':     0,
                'size':      '',
                'source':    'KONTRAST',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] KONTRAST error: %s' % e, xbmc.LOGWARNING)
        return []


# ── The Pirate Bay ────────────────────────────────────────────────────────────

TPB_BASE = 'https://apibay.org'


def search_tpb(title, year=None, category=200, limit=10, media_type='movie'):
    try:
        # apibay.org's own search is confirmed live to choke on apostrophes:
        # "Lads' Army" returns a placeholder "No results returned" row while
        # the apostrophe-stripped "Lads Army" finds the real listing (same
        # torrent, imdb tt0417301 confirmed in the response). Straight and
        # curly apostrophes are stripped before querying; filter_by_title_
        # and_episode() already tolerates the resulting punctuation gap when
        # matching results back against the real (apostrophe'd) title.
        query = re.sub(r"['’]", '', title)
        if year and media_type != 'adult':
            query = '%s %s' % (query, year)
        # apibay's word separator is unreliable: confirmed live the same
        # multi-word query answers with a placeholder "No results returned"
        # row when spaces are sent as %20 ("Inception 2010") but not as +,
        # and the reverse for others ("Breaking Bad"). Try both spellings,
        # then drop the year, before giving up.
        def _tpb_fetch(q):
            d = _get_json(TPB_BASE + '/q.php?q=%s&cat=%d' % (q, category), timeout=8)
            if isinstance(d, list) and d and d[0].get('info_hash', '0' * 40) != '0' * 40:
                return d
            return None
        data = None
        if _req:
            variants = [_req.utils.quote(query), _req.utils.quote(query).replace('%20', '+')]
            if year and media_type != 'adult':
                bare = re.sub(r"['’]", '', title)
                variants += [_req.utils.quote(bare), _req.utils.quote(bare).replace('%20', '+')]
            for q in dict.fromkeys(variants):
                data = _tpb_fetch(q)
                if data:
                    break
        if not data:
            return []
        results = []
        for item in data[:limit]:
            ih = item.get('info_hash', '')
            if not ih or ih == '0000000000000000000000000000000000000000':
                continue
            name = item.get('name', '')
            if not _meets_quality(name, media_type):
                continue
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    _make_magnet(ih, name),
                'seeds':     int(item.get('seeders', 0)),
                'size':      item.get('size', ''),
                'source':    'TPB',
            })
        results.sort(key=lambda x: x['seeds'], reverse=True)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] TPB error: %s' % e, xbmc.LOGWARNING)
        return []


# ── 1337x (mirror rotation + Cloudflare bypass) ───────────────────────────────
# The old 1337x.* domains (.se/.tw/.pro/.to/.st/.ws/.gd) are all dead or
# reduced to parked "alternative domain" stub pages now — 1337x.tw's own
# stub explicitly points to 1377x.to (extra 7) and 1337xx.to (double x) as
# the real current mirrors, confirmed live. The site itself was also
# restructured: old code's /sort-category-search/.../seeders/desc/1/ search
# path and coll-1/coll-2 class-based row parsing both 404/no-match now —
# real search is GET /srch?search=query, results are plain <td class="...
# seeds">/<td class="... size ..."> table cells, and the health-check path
# is just / (old /home/ 404s on these mirrors' template).

# Re-verified live 2026-08-16 against this exact health-check (real
# search form present, not just a 200 status): only 1377x.to and 1337xx.to
# still pass. 1337x.se/.tw are both now parked stub pages (200 but no
# search form — 1337xto.to, a domain a user asked about adding, is the
# same story: it's a landing page whose own links all point to 1337xx.to,
# not an independent index, so nothing to add there). 1337x.to/.st now
# 403, .ws redirects through an ad-decoy domain, .pro times out, .gd
# doesn't resolve at all — all five removed rather than left in as dead
# weight the health-check loop pays a real timeout to rule out every time
# the 1-hour mirror cache is cold.
_LEET_MIRRORS = [
    '1377x.to', '1337xx.to', 'www.1377x.is',
    # Proxy front-end, not a separate index — last resort only, if every
    # real mirror above is down.
    '1337x-to.hashhackers.com',
]
_leet_working = {}  # {'url': ..., 'ts': ...}

_RE_LEET_MAGNET = re.compile(r'href="(magnet:[^"]+)"', re.IGNORECASE)


def _get_leet_base():
    """Return a working 1337x mirror, cached for 1 hour."""
    cached = _leet_working.get('url')
    ts = _leet_working.get('ts', 0)
    if cached and (time.time() - ts) < 3600:
        return cached

    for mirror in _LEET_MIRRORS:
        try:
            # The hashhackers proxy is already a full subdomain host — prepending
            # 'www.' the way bare "1337x.se"-style domains need would break it.
            no_www_prefix = mirror.startswith('www.') or 'hashhackers' in mirror
            url = 'https://%s' % mirror if no_www_prefix else 'https://www.%s' % mirror
            html = _get(url + '/', timeout=7, cf=True)
            # Several "mirrors" (1337x.tw confirmed live) are just parked
            # stub pages pointing at OTHER domains, still mentioning
            # "1337x" and even "alternative domain" themselves — the real,
            # functional mirrors ALSO casually mention alternate domains on
            # their own homepage, so that phrase isn't a reliable way to
            # tell them apart. The real search form (action="/srch") only
            # exists on an actually-working mirror, confirmed live against
            # both a stub (absent) and the real site (present).
            if html and 'action="/srch"' in html.lower():
                _leet_working['url'] = url
                _leet_working['ts'] = time.time()
                xbmc.log('[Starfleet/Torrents] 1337x using mirror: %s' % url, xbmc.LOGINFO)
                return url
        except Exception:
            continue

    fallback = 'https://www.1377x.to'
    xbmc.log('[Starfleet/Torrents] 1337x all mirrors failed, using: %s' % fallback, xbmc.LOGWARNING)
    return fallback


def _leet_get_magnet(path, base):
    try:
        html = _get(base + path, timeout=8, cf=True)
        m = _RE_LEET_MAGNET.search(html)
        if m:
            return m.group(1).split('&tr=')[0]
    except Exception:
        pass
    return ''


_RE_LEET_ROW = re.compile(
    r'href="(/torrent/\d+/[^"]+/)">([^<]+)</a></td>\s*'
    r'<td[^>]*seeds">(\d+)</td>\s*'
    r'<td[^>]*leeches">\d+</td>\s*'
    r'<td[^>]*coll-date">[^<]*</td>\s*'
    r'<td[^>]*size[^>]*>([^<]+)</td>',
    re.IGNORECASE
)


def search_1337x(title, year=None, limit=5, media_type='movie'):
    try:
        base = _get_leet_base()
        if media_type == 'adult':
            # 1337x has a real, server-enforced XXX category — confirmed
            # live 2026-09-05: /sort-category-search/<query>/XXX/... only
            # ever returns genuinely XXX-tagged releases (verified against
            # the same query on the generic /srch endpoint, which pulls in
            # whatever mainstream content happens to share a word with the
            # query — exactly the leak this addon's adult search was fixed
            # to stop). Scoping to this real category is what makes it safe
            # to include 1337x in adult search at all. LimeTorrents was
            # checked the same day for an equivalent — its own
            # "/search/adult/..." category slug turned out to be a no-op
            # (byte-identical results to "/search/all/...", i.e. not a real
            # filter) — so it stays OUT of adult search; nothing server-side
            # actually restricts what it returns for an adult-style query.
            q = _req.utils.quote(title) if _req else title.replace(' ', '%20')
            url = '%s/sort-category-search/%s/XXX/seeders/desc/1/' % (base, q)
        else:
            query = title.replace(' ', '+')
            if year:
                query += '+' + str(year)
            url = '%s/srch?search=%s' % (base, query)
        html = _get(url, timeout=10, cf=True)
        if not html:
            return []

        candidates = []
        for m in _RE_LEET_ROW.finditer(html):
            path, name, seeds, size = m.group(1), m.group(2).strip(), m.group(3), m.group(4).strip()
            if not _meets_quality(name, media_type):
                continue
            candidates.append((path, name, int(seeds), size))

        if not candidates:
            return []

        # 1337x's own /srch is a loose/fuzzy match (any shared word, not the
        # actual title) — confirmed live 2026-09-05 this let completely
        # unrelated, highly-seeded torrents (e.g. searching "Dune Part Two"
        # returned "It Chapter Two", "Shogun S01E09/10", the FIRST "Dune"
        # instead of Part Two, as the top hits by seeds) silently crowd the
        # real match out entirely: the old code stopped scanning the page
        # the moment it had `limit` quality-passing rows, with no
        # title-relevance check of its own, so a real match sitting further
        # down the page than the limit'th irrelevant-but-popular row never
        # even made it into the candidate list before search_all()'s own
        # title filter got a chance to run on it. Every row is now scanned
        # and checked for real title relevance (the exact same phrase-match
        # search_all() applies centrally) BEFORE truncating to `limit`, so
        # only genuine matches compete for those slots by seed count —
        # this is also why "1337x/LimeTorrents never show real 4K results"
        # kept happening: a real 2160p release usually has far fewer seeds
        # than a wrong-but-popular 1080p one, so it needed to survive on
        # relevance, not seed count, to even be considered.
        candidate_dicts = [{'title': name, '_i': i}
                           for i, (path, name, seeds, size) in enumerate(candidates)]
        candidate_dicts = filter_by_title_and_episode(candidate_dicts, title, media_type=media_type)
        keep_idx = {d['_i'] for d in candidate_dicts}
        candidates = [c for i, c in enumerate(candidates) if i in keep_idx]
        candidates.sort(key=lambda c: c[2], reverse=True)  # seeds desc
        candidates = candidates[:limit]
        if not candidates:
            return []

        from concurrent.futures import ThreadPoolExecutor, as_completed as _ac2
        results = []
        with ThreadPoolExecutor(max_workers=min(len(candidates), 15)) as pool:
            fmap = {pool.submit(_leet_get_magnet, path, base): (name, seeds, size)
                    for path, name, seeds, size in candidates}
            for fut in _ac2(fmap, timeout=12):
                name, seeds, size = fmap[fut]
                try:
                    magnet = fut.result()
                except Exception:
                    magnet = ''
                if not magnet:
                    continue
                ih_m = re.search(r'urn:btih:([a-fA-F0-9]{40})', magnet)
                results.append({
                    'title':     name,
                    'year':      '',
                    'quality':   _extract_quality(name),
                    'info_hash': ih_m.group(1).lower() if ih_m else '',
                    'magnet':    magnet,
                    'seeds':     seeds,
                    'size':      size,
                    'source':    '1337x',
                })
        return sorted(results, key=lambda x: x['seeds'], reverse=True)
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] 1337x error: %s' % e, xbmc.LOGWARNING)
        return []


# ── EZTV (TV shows) ───────────────────────────────────────────────────────────

EZTV_BASE = 'https://eztvx.to'


def _eztv_pages(imdb_num, base):
    """Every torrent EZTV lists for the show: page 1, then the remaining pages side by side. The API hands out the newest
    100 first, so an older episode of a long-running show is only on a later page."""
    import json as _json
    raw = _get('%s/api/get-torrents?limit=100&page=1&imdb_id=%s' % (base, imdb_num), timeout=8)
    if not raw:
        return None                      # the site did not answer (an empty list means: answered, nothing for this show)
    data = _json.loads(raw)
    torrents = list(data.get('torrents') or [])
    try:
        total = int(data.get('torrents_count') or 0)
    except (TypeError, ValueError):
        total = 0
    pages = min((total + 99) // 100, 8)
    if pages > 1:
        from concurrent.futures import ThreadPoolExecutor as _TPE

        def one(pg):
            try:
                r = _get('%s/api/get-torrents?limit=100&page=%d&imdb_id=%s' % (base, pg, imdb_num), timeout=8)
                return (_json.loads(r).get('torrents') or []) if r else []
            except Exception:
                return []
        with _TPE(max_workers=pages - 1) as ex:
            for part in ex.map(one, range(2, pages + 1)):
                torrents.extend(part)
    return torrents


def _search_eztv_api(imdb_id, limit=5, season=None, episode=None):
    """
    EZTV official API by imdb_id — no Cloudflare in front of this endpoint
    (unlike /search/{slug}, which is CF-403'd), so this is the reliable path
    whenever an imdb_id is known. For an episode search every page of the show's
    list is read and only that season/episode is kept; without one the newest
    page is returned and search_all()'s shared title filter narrows it down.
    """
    try:
        imdb_num = re.sub(r'^tt', '', str(imdb_id or ''))
        if not imdb_num.isdigit():
            return []
        want = season is not None and episode is not None
        torrents = None
        for base in dict.fromkeys([EZTV_BASE, 'https://eztv.re', 'https://eztv.wf']):
            try:
                got = _eztv_pages(imdb_num, base)
            except Exception:
                got = None
            if got is not None:
                torrents = got if want else got[:100]
                break
        if torrents is None:
            return None
        if want:
            torrents = [t for t in torrents if str(t.get('season')) == str(int(season)) and str(t.get('episode')) == str(int(episode))]
        results = []
        for t in torrents:
            name = t.get('title') or t.get('filename') or ''
            if not name or not _meets_quality(name, 'tv'):
                continue
            ih = (t.get('hash') or '').lower()
            if not ih:
                continue
            magnet = t.get('magnet_url') or _make_magnet(ih, name)
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    magnet,
                'seeds':     int(t.get('seeds', 0) or 0),
                'size':      t.get('size_bytes', ''),
                'source':    'EZTV',
            })
        results.sort(key=lambda x: x['seeds'], reverse=True)
        return results[:limit]
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] EZTV API error: %s' % e, xbmc.LOGWARNING)
        return []


def search_eztv(title, year=None, limit=5, imdb_id=None, season=None, episode=None):
    """
    EZTV: official API by imdb_id first (reliable, no Cloudflare). Falls back
    to the /search/{slug} HTML scrape (CF-protected, needs cloudscraper) only
    when no imdb_id is available — the API doesn't accept free-text keywords.
    """
    if imdb_id:
        results = _search_eztv_api(imdb_id, limit, season, episode)
        if results is not None:              # EZTV answered: its list is complete, the Cloudflare-gated page search adds nothing
            return results
    try:
        slug = re.sub(r'[^a-z0-9]+', '-', title.lower()).strip('-')
        url = '%s/search/%s' % (EZTV_BASE, slug)
        cs = _get_cf_session()
        html = (cs.get(url, timeout=10).text if cs else
                _get(url, timeout=10, cf=True))
        if not html:
            return []
        # Rows: <tr class="forum_header_border">
        magnets = re.findall(r'(magnet:\?xt=urn:btih:[a-fA-F0-9]{40}[^"\'<\s]*)', html)
        names   = re.findall(r'class="epinfo"[^>]*>([^<]+)</a>', html)
        seeds_all = re.findall(r'class="[^"]*seeds[^"]*"[^>]*>(\d+)<', html, re.IGNORECASE)
        results = []
        for i, mag in enumerate(magnets):
            ih_m = re.search(r'btih:([a-fA-F0-9]{40})', mag, re.IGNORECASE)
            if not ih_m:
                continue
            ih   = ih_m.group(1).lower()
            name = names[i] if i < len(names) else ''
            if not name:
                dn = re.search(r'[&?]dn=([^&"\'<\s]+)', mag)
                name = _req.utils.unquote(dn.group(1)).replace('+', ' ') if dn and _req else ih
            seeds = int(seeds_all[i]) if i < len(seeds_all) else 0
            if not _meets_quality(name, 'tv'):
                continue
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    mag,
                'seeds':     seeds,
                'size':      '',
                'source':    'EZTV',
            })
            if len(results) >= limit:
                break
        results.sort(key=lambda x: x['seeds'], reverse=True)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] EZTV error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Bitsearch ─────────────────────────────────────────────────────────────────

BITSEARCH_BASE = 'https://bitsearch.eu'  # .to confirmed dead/empty live; .eu is the current real site
_RE_BS_SIZE = re.compile(r'(\d+(?:\.\d+)?)\s*(GB|MB|GiB|MiB)', re.IGNORECASE)


def search_bitsearch(title, year=None, limit=5, media_type='movie'):
    """
    Bitsearch scraper. Anchors on magnet: links rather than CSS card classes
    so it survives HTML/CSS redesigns on bitsearch.to.
    """
    try:
        import html as _html
        query = title
        # No year in query — title-only gets more results
        if _req:
            query = _req.utils.quote(query)
        url = '%s/search?q=%s&sort=seeders' % (BITSEARCH_BASE, query)
        cs = _get_cf_session()
        html_raw = (cs.get(url, timeout=10).text if cs else _get(url, timeout=10))
        if not html_raw:
            return []
        text = _html.unescape(html_raw)

        # Split on magnet: links — one per result card, CSS-class-independent
        parts = re.split(r'(magnet:\?[^"\'<\s]+)', text)
        # parts = [pre, magnet1, after1, magnet2, after2, ...]
        results = []
        i = 1
        while i < len(parts) - 1 and len(results) < limit:
            raw_magnet = parts[i].replace('&amp;', '&')
            before = parts[i - 1][-800:]
            after  = parts[i + 1][:400]
            context = before + after
            i += 2

            ih_m = re.search(r'btih:([a-fA-F0-9]{40})', raw_magnet, re.IGNORECASE)
            if not ih_m:
                continue
            info_hash = ih_m.group(1).lower()

            # Name: prefer &dn= from magnet (already URL-decoded title)
            name = ''
            dn_m = re.search(r'[&?]dn=([^&"\'<\s]+)', raw_magnet)
            if dn_m and _req:
                name = _req.utils.unquote(dn_m.group(1)).replace('+', ' ').strip()
            if not name:
                # Fall back: nearest heading/link text before the magnet
                t_m = re.search(
                    r'<(?:h\d|a)\b[^>]*>\s*(?:<[^>]+>)?\s*([^<]{5,80}?)\s*(?:</[^>]+>)?\s*</(?:h\d|a)>',
                    before, re.IGNORECASE | re.DOTALL
                )
                if t_m:
                    name = re.sub(r'<[^>]+>', '', t_m.group(1)).strip()
                    name = re.sub(r'\s+', ' ', name)
            if not name or not _meets_quality(name, media_type):
                continue

            seeds = 0
            s_m = re.search(r'(\d+)\s*[<\s]*(?:seeder|seed)\b', context, re.IGNORECASE)
            if s_m:
                seeds = int(s_m.group(1))

            size = ''
            z_m = _RE_BS_SIZE.search(context)
            if z_m:
                size = z_m.group(0)

            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': info_hash,
                'magnet':    raw_magnet,
                'seeds':     seeds,
                'size':      size,
                'source':    'Bitsearch',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Bitsearch error: %s' % e, xbmc.LOGWARNING)
        return []


# ── TorrentGalaxy (CF bypass) ────────────────────────────────────────────────

_TGX_MIRRORS = [
    'torrentgalaxy-official.is', 'torrentgalaxy.one', 'torrentgalaxy.info',
    'torrentgalaxy.hair', 'torrentgalaxy.mx', 'torrentgalaxy.to', 'tgx.rs',
]
_tgx_working = {}

_RE_TGX_MAGNET = re.compile(r'a\s+href="(magnet:[^"]+)"', re.IGNORECASE)
_RE_TGX_SIZE   = re.compile(r'(\d+(?:[,.]\d+)?)\s*(GiB|MiB|GB|MB)', re.IGNORECASE)
_TGX_SKIP_LANG = re.compile(r'\b(FRENCH|TRUEFRENCH|ITALIAN|Ita|SPANISH|DUBBED|LAT|Dublado)\b',
                             re.IGNORECASE)


def _get_tgx_base():
    cached = _tgx_working.get('url')
    ts = _tgx_working.get('ts', 0)
    if cached and (time.time() - ts) < 3600:
        return cached
    for mirror in _TGX_MIRRORS:
        try:
            url = 'https://%s' % mirror
            # Confirmed live 2026-09-11: torrentgalaxy-official.is (first in
            # the list) passes a loose 'torrent' in html.lower() check every
            # time — its own page title/description literally say "torrent"
            # repeatedly — while actually being a dead decoy landing page
            # with zero real listings (0 magnet: links, same ~39KB response
            # for both / and /torrents.php regardless of query). The
            # rotation locked onto it as "working" and never fell through to
            # torrentgalaxy.one, which has always had real results (188
            # magnets for a real test query) the whole time. Requiring an
            # actual magnet: link is a real functional check, not just a
            # word this mirror's marketing copy happens to contain.
            html = _get(url + '/torrents.php', timeout=7, cf=True)
            if html and 'magnet:' in html:
                _tgx_working['url'] = url
                _tgx_working['ts'] = time.time()
                xbmc.log('[Starfleet/Torrents] TGX using mirror: %s' % url, xbmc.LOGINFO)
                return url
        except Exception:
            continue
    return 'https://' + _TGX_MIRRORS[0]


_RE_TGX_ROW = re.compile(
    r'href="(/post-detail/[a-f0-9]+/[^"]+)"><span\s+src="torrent"><b>([^<]+)</b>'
)
_RE_TGX_SIZE_DETAIL = re.compile(r'Total Size:</b></div>\s*<div class="tpcell">([^<]+)</div>')


def search_torrentgalaxy(title, year=None, limit=5, media_type='movie'):
    """TorrentGalaxy — confirmed live 2026-09-11 the site moved its search
    off the old /torrents.php?search= listing (which now silently ignores
    the query and just shows the generic recent-uploads feed) to
    /get-posts/keywords:<query>, and no longer inlines a magnet: link on
    the listing page at all — only a per-result /post-detail/ page link,
    which itself has the real magnet plus total size in static HTML (no
    per-item hash decode needed, unlike NNMClub/FreeJAVTorrent elsewhere in
    this file). Seed/leech counts on the detail page are fetched by the
    site's OWN page via a separate client-side AJAX call after load (not
    present in the static HTML at all) — not worth a second per-item
    request just for that, so this defaults seeds to 0 same as several
    other sources here already do when a site doesn't expose it cheaply."""
    try:
        base = _get_tgx_base()
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        if _req:
            query = _req.utils.quote(query)
        url = '%s/get-posts/keywords:%s' % (base, query)
        html_raw = _get(url, timeout=10, cf=True)
        if not html_raw:
            return []

        import html as _html_mod
        candidates = []
        for href, raw_name in _RE_TGX_ROW.findall(html_raw):
            if len(candidates) >= limit * 2:
                break
            name = _html_mod.unescape(raw_name).strip()
            if not name or not _meets_quality(name, media_type) or _TGX_SKIP_LANG.search(name):
                continue
            detail_url = href if href.startswith('http') else base + href
            candidates.append((detail_url, name))
        if not candidates:
            return []

        def _fetch(item):
            detail_url, name = item
            try:
                detail = _get(detail_url, timeout=10, cf=True)
                if not detail:
                    return None
                mag_m = re.search(r'href="(magnet:[^"]+)"', detail)
                if not mag_m:
                    return None
                magnet = _html_mod.unescape(mag_m.group(1))
                ih_m = re.search(r'btih:([a-fA-F0-9]{40})', magnet, re.IGNORECASE)
                if not ih_m:
                    return None
                size_m = _RE_TGX_SIZE_DETAIL.search(detail)
                size = size_m.group(1).replace('\xa0', ' ').strip() if size_m else ''
                return {
                    'title':     name,
                    'year':      '',
                    'quality':   _extract_quality(name),
                    'info_hash': ih_m.group(1).lower(),
                    'magnet':    magnet,
                    'seeds':     0,
                    'size':      size,
                    'source':    'TGX',
                }
            except Exception:
                return None

        results = []
        from concurrent.futures import ThreadPoolExecutor
        with ThreadPoolExecutor(max_workers=min(10, len(candidates))) as pool:
            for res in pool.map(_fetch, candidates):
                if res:
                    results.append(res)
                if len(results) >= limit:
                    break
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] TorrentGalaxy error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Knaben meta-search (movies / TV / adult) ──────────────────────────────────

KNABEN_API = 'https://api.knaben.org/v1'
# Knaben category filters are unreliable (returns empty when set) — skip them
# and rely on the title/word filter in search_all to remove wrong-media results.

_KNABEN_HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
    'Accept':       'application/json',
    'Content-Type': 'application/json',
}


def search_knaben(title, year=None, media_type='movie', limit=10):
    try:
        import json as _json
        query = title
        if year and media_type not in ('adult',):
            query = '%s %s' % (title, year)

        body = {'query': query, 'order_by': 'seeders', 'take': max(limit * 3, 30)}
        # No category filter — Knaben category IDs are broken (return empty)
        # Use a fresh Session per call: the shared _sess() pool causes empty responses
        # for this large JSON endpoint (211KB response body).
        if not _req:
            return []
        with _req.Session() as _ks:
            # Confirmed live this endpoint either responds well under a
            # couple seconds or doesn't respond at all -- a query that's
            # going to time out did so at essentially the full 12s with zero
            # results, making it consistently the single longest pole in the
            # whole batch for no payoff. Trimmed so a dead query fails fast
            # instead of eating a third of the batch's total time for nothing.
            r = _ks.post(KNABEN_API, json=body, headers=_KNABEN_HEADERS, timeout=6)
        if r.status_code >= 400:
            return []
        if not r.text or not r.text.strip():
            xbmc.log('[Starfleet/Torrents] Knaben: empty response', xbmc.LOGWARNING)
            return []
        data = r.json()
        # API returns 'hits' (old) or 'result' (new) depending on version
        hits = data.get('hits') or data.get('result') or data.get('results') or []
        results = []
        for entry in hits:
            if len(results) >= limit:
                break
            name = entry.get('title', '')
            if not name or not _meets_quality(name, media_type):
                continue
            # Knaben marks games/software with [DL] prefix — skip for movie/tv searches
            if media_type in ('movie', 'tv') and name.startswith('[DL]'):
                continue
            ih = (entry.get('hash') or '').lower()
            if not ih or len(ih) != 40:
                continue
            magnet = entry.get('magnetUrl') or _make_magnet(ih, name)
            seeds  = int(entry.get('seeders') or 0)
            b = entry.get('bytes') or 0
            size = ''
            if b >= 1_073_741_824:
                size = '%.1f GB' % (b / 1_073_741_824)
            elif b >= 1_048_576:
                size = '%.0f MB' % (b / 1_048_576)
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    magnet,
                'seeds':     seeds,
                'size':      size,
                'source':    'Knaben',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Knaben error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Torrentio (IMDB-based Stremio API) ───────────────────────────────────────

TORRENTIO_BASE = 'https://torrentio.strem.fun'
_RE_TIO_INFO = re.compile(r'👤.*')


# ── YourBitTorrent ────────────────────────────────────────────────────────────
# Confirmed live 2026-08-15: this function existed but was never actually
# wired into search_all()'s tasks dict below (a real orphaned-function bug,
# same class as an earlier one found this session) - AND the site itself
# has since moved from yourbittorrent2.com to yourbittorrent.com with a
# redesigned page (different result-link markup, hash/size now in a
# labeled key/value grid instead of <kbd>/card-title tags). Both issues
# fixed together: regexes rewritten against the current live markup,
# function now actually called below.

YBT_BASE = 'https://yourbittorrent.com'
_RE_YBT_LINK = re.compile(r'href="(/torrent/[^"]+)"', re.IGNORECASE)
_RE_YBT_HASH = re.compile(r'<div class="k">Infohash</div><div class="v"[^>]*>([a-fA-F0-9]{40})', re.IGNORECASE)
_RE_YBT_NAME = re.compile(r'<title>([^<]+)</title>', re.IGNORECASE)
_RE_YBT_SIZE = re.compile(r'<div class="k">Size</div><div class="v"[^>]*>([^<]+)', re.IGNORECASE)
_RE_YBT_LANG = re.compile(r'\b(french|italian|spanish|truefrench|dublado|dubbed)\b', re.IGNORECASE)


def search_yourbittorrent(title, year=None, limit=5, media_type='movie'):
    try:
        from concurrent.futures import ThreadPoolExecutor
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        from urllib.parse import quote_plus as _qp
        query_enc = _qp(query).replace('+', '-')
        html_raw = _get('%s?q=%s' % (YBT_BASE, query_enc), timeout=8)
        if not html_raw:
            return []
        links = _RE_YBT_LINK.findall(html_raw)[:limit]

        def _fetch(link):
            try:
                detail = _get(YBT_BASE + link, timeout=8)
                ih_m = _RE_YBT_HASH.search(detail)
                nm_m = _RE_YBT_NAME.search(detail)
                if not ih_m or not nm_m:
                    return None
                ih = ih_m.group(1).lower()
                name = nm_m.group(1).strip()
                if name.endswith(' Torrent Download'):
                    name = name[:-len(' Torrent Download')]
                if not _meets_quality(name, media_type):
                    return None
                if _RE_YBT_LANG.search(name):
                    return None
                sz_m = _RE_YBT_SIZE.search(detail)
                size = sz_m.group(1).strip() if sz_m else ''
                return {
                    'title': name, 'year': '', 'quality': _extract_quality(name),
                    'info_hash': ih, 'magnet': _make_magnet(ih, name),
                    'seeds': 0, 'size': size, 'source': 'YourBT',
                }
            except Exception:
                return None

        if not links:
            return []
        results = []
        with ThreadPoolExecutor(max_workers=max(min(len(links), limit), 1)) as pool:
            for r in pool.map(_fetch, links, timeout=10):
                if r and len(results) < limit:
                    results.append(r)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] YourBitTorrent error: %s' % e, xbmc.LOGWARNING)
        return []


# ── FileMood (DHT file-search index) ─────────────────────────────────────────
# filemood.com is a general DHT/file index (not movie-specific — its own
# homepage claims "1,948,539,407 files ... 64,940,387 entries"), same family
# as Bitsearch/TPB. Cloudflare-fronted (real cf-ray headers, a "Cloudflare
# challenge-platform" analytics beacon on every page), but confirmed live
# 2026-08-16 that the actual search results ARE present in a plain
# unauthenticated GET's HTML with no CF bypass needed at all — the beacon is
# just passive bot-management telemetry, not a blocking JS challenge. (A
# real dead end WAS found immediately next to this one: the #result-main-left
# div this page also renders is permanently empty for every client, browser
# or scraper alike — a leftover/decoy container, not a bot-cloaking tell.
# The real results live in #result-main-center, confirmed by diffing actual
# browser DOM output against this scraper's own plain curl/cloudscraper
# fetches, which were otherwise byte-identical.)
# Each top-level result's own download-page URL already ends in
# "-<40-char-info-hash>.html" — the info hash is sitting directly in the
# HTML with no separate detail-page fetch or bencode parsing needed, same
# shortcut Zooqle uses. The two numbers FileMood shows per result
# (e.g. "683/283") aren't standard tracker seed/leech — how-to page confirms
# this is a DHT crawler with no live tracker connection — but the first
# number tracks the same "how many peers has our crawler seen recently"
# popularity signal seeds normally represent, so it's used as the sort/
# display 'seeds' value the same way.
FILEMOOD_BASE = 'https://filemood.com'

_RE_FILEMOOD_ROW = re.compile(
    r'<td class="dn-title">\s*<p class="filedir">\s*'
    r'<a href="(/[^"]+?-([a-fA-F0-9]{40})\.html)"[^>]*>(.*?)</a>\s*</p>\s*</td>\s*'
    r'<td class="dn-status">\s*<p class="text"[^>]*><b>(\d+)/(\d+)</b></p>\s*</td>\s*'
    r'<td class="dn-size">\s*<p class="text"[^>]*><b>([^<]+)</b>',
    re.IGNORECASE | re.DOTALL
)


def search_filemood(title, year=None, limit=5, media_type='movie'):
    try:
        from urllib.parse import quote as _q
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        query = re.sub(r'\s+', ' ', query).strip()
        if not query:
            return []
        html = _get('%s/result?q=%s' % (FILEMOOD_BASE, _q(query)), timeout=10)
        if not html:
            return []

        results = []
        for href, info_hash, raw_title, n1, n2, size in _RE_FILEMOOD_ROW.findall(html):
            if len(results) >= limit:
                break
            name = re.sub(r'<[^>]+>', '', raw_title)
            name = re.sub(r'\s+', ' ', name).strip()
            if not name or not _meets_quality(name, media_type):
                continue
            ih = info_hash.lower()
            results.append({
                'title':     name,
                'year':      year or '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    _make_magnet(ih, name),
                'seeds':     int(n1),
                'size':      size.strip(),
                'source':    'FileMood',
            })
        results.sort(key=lambda x: x['seeds'], reverse=True)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] FileMood error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Torrentdownload.info (Tordl) ──────────────────────────────────────────────

TORDL_BASE = 'https://www.torrentdownload.info'
_RE_TORDL_LINK = re.compile(r'href="/([a-fA-F0-9]{40})/([^"]+)"', re.IGNORECASE)
_RE_TORDL_SIZE = re.compile(r'(\d+(?:\.\d+)?)\s*(GB|MB|GiB|MiB)', re.IGNORECASE)


def search_tordl(title, year=None, limit=5, media_type='movie'):
    try:
        from urllib.parse import quote_plus as _qp
        query = title.lower()
        if year and media_type != 'adult':
            query = '%s %s' % (query, year)
        url = '%s/search?q=%s' % (TORDL_BASE, _qp(query))
        html = _get(url, timeout=10)
        if not html:
            return []
        results = []
        for m in _RE_TORDL_LINK.finditer(html):
            if len(results) >= limit:
                break
            ih = m.group(1).lower()
            name = m.group(2).replace('+', ' ').replace('-', ' ')
            name = re.sub(r'[_%]', ' ', name).strip()
            if not name or not _meets_quality(name, media_type):
                continue
            # Size is approximate from listing
            magnet = _make_magnet(ih, name)
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    magnet,
                'seeds':     0,
                'size':      '',
                'source':    'Tordl',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Tordl error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Bitlord ───────────────────────────────────────────────────────────────────

BITLORD_BASE = 'http://www.bitlordsearch.com'
_RE_BL_MAG  = re.compile(
    r'class="btn btn-default magnet-button[^"]*"[^>]+href="([^"]+)"', re.IGNORECASE
)
_RE_BL_SIZE = re.compile(r'<td class="size">(\d+)</td>', re.IGNORECASE)
_RE_BL_LANG = re.compile(r'\b(french|italian|spanish|truefrench|dublado|dubbed)\b', re.IGNORECASE)


def search_bitlord(title, year=None, limit=5, media_type='movie'):
    try:
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        if _req:
            query = _req.utils.quote(query)
        html_raw = _get('%s/search?q=%s' % (BITLORD_BASE, query), timeout=10)
        if not html_raw:
            return []
        magnets = _RE_BL_MAG.findall(html_raw)
        sizes   = _RE_BL_SIZE.findall(html_raw)
        results = []
        for i, mag in enumerate(magnets):
            if len(results) >= limit:
                break
            mag = mag.replace('&amp;', '&').split('&tr=')[0]
            if 'magnet' not in mag:
                continue
            dn_m = re.search(r'&dn=([^&]+)', mag)
            name = _req.utils.unquote(dn_m.group(1)).replace('+', ' ') if dn_m and _req else ''
            if not name or not _meets_quality(name, media_type):
                continue
            if _RE_BL_LANG.search(name):
                continue
            ih_m = re.search(r'btih:([a-fA-F0-9]{40})', mag, re.IGNORECASE)
            info_hash = ih_m.group(1).lower() if ih_m else ''
            size = ''
            if i < len(sizes):
                try:
                    b = int(sizes[i])
                    if b >= 1_073_741_824:
                        size = '%.1f GB' % (b / 1_073_741_824)
                    elif b >= 1_048_576:
                        size = '%.0f MB' % (b / 1_048_576)
                except Exception:
                    pass
            results.append({
                'title': name, 'year': '', 'quality': _extract_quality(name),
                'info_hash': info_hash, 'magnet': mag,
                'seeds': 0, 'size': size, 'source': 'Bitlord',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Bitlord error: %s' % e, xbmc.LOGWARNING)
        return []


# ── MagnetDL ──────────────────────────────────────────────────────────────────

MAGNETDL_BASE = 'https://www.magnetdl.hair'
_RE_MDL_ROW  = re.compile(
    r'href="(/([a-fA-F0-9]{40})/([^"]+))"', re.IGNORECASE
)


def search_magnetdl(title, year=None, limit=5, media_type='movie'):
    """MagnetDL — magnets are embedded in search-result URLs, no per-page fetch."""
    try:
        from urllib.parse import quote as _q2
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        slug = re.sub(r'[^\w\s-]', '', query.lower()).strip()
        slug = re.sub(r'[\s_]+', '-', slug)
        first = slug[0] if slug else 'm'
        url = '%s/%s/%s/' % (MAGNETDL_BASE, first, slug)
        html_raw = _get(url, timeout=10)
        if not html_raw:
            return []
        results = []
        seen_hashes = set()
        for m in _RE_MDL_ROW.finditer(html_raw):
            if len(results) >= limit:
                break
            ih = m.group(2).lower()
            if ih in seen_hashes:
                continue
            raw_name = m.group(3)
            name = re.sub(r'[_+]+', ' ', raw_name).strip()
            if not name or not _meets_quality(name, media_type):
                continue
            seen_hashes.add(ih)
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    _make_magnet(ih, name),
                'seeds':     0,
                'size':      '',
                'source':    'MagnetDL',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] MagnetDL error: %s' % e, xbmc.LOGWARNING)
        return []


# ── TorrentDownloads (RSS) ────────────────────────────────────────────────────

TDOWNLOADS_BASE = 'https://www.torrentdownloads.pro'
_RE_TD_ITEM = re.compile(
    r'<info_hash>([a-fA-F0-9]{40})</info_hash>.*?'
    r'<title>(.+?)</title>.*?'
    r'<size>(\d+)</size>.*?'
    r'<seeders>(\d+)</seeders>',
    re.IGNORECASE | re.DOTALL
)


def search_torrentdownloads(title, year=None, limit=5, media_type='movie'):
    """TorrentDownloads — RSS feed returns info_hash directly, very fast."""
    try:
        from urllib.parse import quote as _q3
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        cat = '8' if media_type == 'tv' else '4'  # 4=Movies, 8=TV
        if media_type == 'adult':
            cat = '6'
        url = '%s/rss.xml?new=1&type=search&cid=%s&search=%s' % (
            TDOWNLOADS_BASE, cat, _q3(query))
        html_raw = _get(url, timeout=10)
        if not html_raw:
            return []
        results = []
        for m in _RE_TD_ITEM.finditer(html_raw):
            if len(results) >= limit:
                break
            ih, name, size_b, seeders = (
                m.group(1).lower(), m.group(2).strip(),
                int(m.group(3)), int(m.group(4))
            )
            if not name or not _meets_quality(name, media_type):
                continue
            size = ''
            if size_b >= 1_073_741_824:
                size = '%.1f GB' % (size_b / 1_073_741_824)
            elif size_b >= 1_048_576:
                size = '%d MB' % (size_b // 1_048_576)
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    _make_magnet(ih, name),
                'seeds':     seeders,
                'size':      size,
                'source':    'TorrentDL',
            })
        results.sort(key=lambda x: x['seeds'], reverse=True)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] TorrentDownloads error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Glodls ───────────────────────────────────────────────────────────────────

_GLODLS_BASE = 'https://glodls.to'
_GLODLS_TV   = 'search_results.php?search={q}&cat=41&incldead=0&inclexternal=0&lang=1&sort=seeders&order=desc'
_GLODLS_MOV  = 'search_results.php?search={q}&cat=1&incldead=0&inclexternal=0&lang=1&sort=size&order=desc'
_RE_GL_NAME  = re.compile(r'<a[^>]+title="([^"]+)"', re.IGNORECASE)
_RE_GL_MAG   = re.compile(r'href="(magnet:\?[^"]+)"', re.IGNORECASE)
_RE_GL_SIZE  = re.compile(r'(\d+(?:[,.]\d+)?)\s*(GiB|MiB|GB|MB)', re.IGNORECASE)


def search_glodls(title, year=None, limit=5, media_type='movie'):
    try:
        if not _req:
            return []
        query = title
        if year and media_type not in ('adult',):
            query = '%s %s' % (title, year)
        q = _req.utils.quote(query)
        tmpl = _GLODLS_TV if media_type == 'tv' else _GLODLS_MOV
        url = '%s/%s' % (_GLODLS_BASE, tmpl.format(q=q))
        html = _get(url, timeout=10)
        if not html:
            return []
        results = []
        # Parse t-row table rows
        for row in html.split('class="t-row"')[1:]:
            if len(results) >= limit:
                break
            try:
                mag_m = _RE_GL_MAG.search(row)
                if not mag_m:
                    continue
                magnet = mag_m.group(1).replace('&amp;', '&')
                ih_m = re.search(r'btih:([a-fA-F0-9]{40})', magnet, re.IGNORECASE)
                if not ih_m:
                    continue
                info_hash = ih_m.group(1).lower()
                # Title from <a title="...">
                name_m = _RE_GL_NAME.search(row)
                name = name_m.group(1) if name_m else ''
                if not name or not _meets_quality(name, media_type):
                    continue
                # Size
                sz_m = _RE_GL_SIZE.search(row)
                size = sz_m.group(0) if sz_m else ''
                results.append({
                    'title':     name,
                    'year':      '',
                    'quality':   _extract_quality(name),
                    'info_hash': info_hash,
                    'magnet':    magnet.split('&tr')[0],
                    'seeds':     0,
                    'size':      size,
                    'source':    'Glodls',
                })
            except Exception:
                continue
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Glodls error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Rutor (rutor.info / rutor.is) ─────────────────────────────────────────────
# Russian tracker (mixed Cyrillic/English titles) — confirmed live 2026-08-11:
# 39 real results for a real query, magnets embedded directly in the search
# results table, no per-item fetch needed, fully anonymous (no login).
# rutor.info and rutor.is confirmed live 2026-08-27 to be byte-identical
# mirrors of the same site (same backend) — tries both so this source
# survives either domain going down on its own.

_RUTOR_MIRRORS = ['https://rutor.info', 'https://rutor.is']
_rutor_working = {}
_RE_RUTOR_ROW = re.compile(
    r'href="magnet:\?xt=urn:btih:([a-fA-F0-9]{40})[^"]*".*?'
    r'<a href="/torrent/\d+/[^"]*">([^<]+)</a>.*?'
    r'<td align="right">([\d.,]+)&nbsp;(GB|MB|KB)</td>.*?'
    r'S"\s*/>&nbsp;(\d+)',
    re.IGNORECASE | re.DOTALL
)


def _get_rutor_base():
    cached = _rutor_working.get('url')
    ts     = _rutor_working.get('ts', 0)
    if cached and (time.time() - ts) < 3600:
        return cached
    for mirror in _RUTOR_MIRRORS:
        try:
            html = _get(mirror + '/', timeout=7)
            if html and 'rutor' in html.lower():
                _rutor_working['url'] = mirror
                _rutor_working['ts']  = time.time()
                return mirror
        except Exception:
            continue
    return _RUTOR_MIRRORS[0]


def search_rutor(title, year=None, limit=5, media_type='movie'):
    try:
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        q = _req.utils.quote(query) if _req else query
        url = '%s/search/0/0/000/0/%s' % (_get_rutor_base(), q)
        html = _get(url, timeout=10)
        if not html:
            return []
        results = []
        for ih, name, size_val, size_unit, seeds in _RE_RUTOR_ROW.findall(html):
            if len(results) >= limit:
                break
            name = name.strip()
            if not name or not _meets_quality(name, media_type):
                continue
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih.lower(),
                'magnet':    _make_magnet(ih.lower(), name),
                'seeds':     int(seeds),
                'size':      '%s %s' % (size_val, size_unit),
                'source':    'Rutor',
            })
        results.sort(key=lambda x: x['seeds'], reverse=True)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Rutor error: %s' % e, xbmc.LOGWARNING)
        return []


# ── NNMClub (nnmclub.to) ──────────────────────────────────────────────────────
# Russian forum-tracker. Search results only link to a download.php redirect
# (no magnet/hash inline), which forwards anonymously (uid=-1, no login
# required — confirmed live 2026-08-11) to a real .torrent file on
# bulk.nnmclub.to. Needs a tiny bencode decode per result to compute the
# actual info_hash (SHA1 of the bencoded 'info' dict) since the site itself
# never exposes it directly — one extra fetch per candidate beyond the
# search page itself, same cost class as this file's other detail-page-fetch
# sources (isohunt2/yourbittorrent above).
NNMCLUB_BASE = 'https://nnmclub.to/forum'
_RE_NNM_ROW = re.compile(
    r'<a[^>]+href="(viewtopic\.php\?t=\d+)"[^>]*>(?:<b>)?([^<]+)(?:</b>)?</a>.*?'
    r'<a href="(download\.php\?id=\d+)"',
    re.IGNORECASE | re.DOTALL
)


def _bdecode(data, i=0):
    """Minimal bencode decoder — only needs to parse a .torrent file well
    enough to isolate the 'info' dict for hashing, not a general-purpose
    implementation."""
    c = data[i:i + 1]
    if c == b'i':
        end = data.index(b'e', i)
        return int(data[i + 1:end]), end + 1
    if c == b'l':
        i += 1
        items = []
        while data[i:i + 1] != b'e':
            v, i = _bdecode(data, i)
            items.append(v)
        return items, i + 1
    if c == b'd':
        i += 1
        d = {}
        while data[i:i + 1] != b'e':
            k, i = _bdecode(data, i)
            v, i = _bdecode(data, i)
            d[k] = v
        return d, i + 1
    colon = data.index(b':', i)
    length = int(data[i:colon])
    start = colon + 1
    return data[start:start + length], start + length


def _bencode(obj):
    if isinstance(obj, int):
        return b'i' + str(obj).encode() + b'e'
    if isinstance(obj, bytes):
        return str(len(obj)).encode() + b':' + obj
    if isinstance(obj, list):
        return b'l' + b''.join(_bencode(x) for x in obj) + b'e'
    if isinstance(obj, dict):
        out = b'd'
        for k in sorted(obj.keys()):
            out += _bencode(k) + _bencode(obj[k])
        return out + b'e'
    raise TypeError(type(obj))


def _nnm_hash_from_torrent(dl_path):
    """Follows the anonymous download.php redirect and computes the real
    info_hash from the returned .torrent bytes. Deliberately bypasses _get()
    here — that helper always text-decodes the response (r.text), which
    corrupts arbitrary binary bencode data (a .torrent file has no reliable
    text encoding, so a decode+re-encode round trip isn't guaranteed to
    reproduce the original bytes). Fetches raw .content directly instead."""
    try:
        s = _sess()
        if not s:
            return None
        r = s.get('%s/%s' % (NNMCLUB_BASE, dl_path), timeout=10)
        r.raise_for_status()
        data = r.content
        if not data:
            return None
        parsed, _pos = _bdecode(data, 0)
        info = parsed.get(b'info')
        if not info:
            return None
        return hashlib.sha1(_bencode(info)).hexdigest()
    except Exception:
        return None


def search_nnmclub(title, year=None, limit=5, media_type='movie'):
    try:
        from concurrent.futures import ThreadPoolExecutor
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        url = '%s/tracker.php?nm=%s' % (NNMCLUB_BASE, _req.utils.quote(query) if _req else query)
        html = _get(url, timeout=10)
        if not html:
            return []
        rows = _RE_NNM_ROW.findall(html)[:limit * 2]  # slack for quality-filtered drops
        candidates = []
        for _topic, name, dl_path in rows:
            name = name.strip()
            if not name or not _meets_quality(name, media_type):
                continue
            candidates.append((name, dl_path))
            if len(candidates) >= limit:
                break
        if not candidates:
            return []

        def _resolve(item):
            name, dl_path = item
            ih = _nnm_hash_from_torrent(dl_path)
            if not ih:
                return None
            return {
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    _make_magnet(ih, name),
                'seeds':     0,
                'size':      '',
                'source':    'NNMClub',
            }

        results = []
        with ThreadPoolExecutor(max_workers=max(len(candidates), 1)) as pool:
            for r in pool.map(_resolve, candidates, timeout=15):
                if r:
                    results.append(r)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] NNMClub error: %s' % e, xbmc.LOGWARNING)
        return []


# ── DaMagNet (damag.net — DHT-crawl index; two-step like NNMClub above) ──────
#
# Confirmed live 2026-09-03: real, large (67M+ resource) DHT crawl, plain
# server-rendered POST form (no JS rendering needed — same shape as
# NNMClub's own search). The results listing itself only carries a short
# per-item detail-page path (e.g. "/53MOpSe") plus a file count and a raw
# byte size — no magnet/info_hash inline — so each candidate needs a second
# GET to its own detail page (which does inline a bare
# `magnet:?xt=urn:btih:...`, no display name or trackers of its own)
# before it's usable. Resolved via the same bounded thread pool as
# NNMClub's own two-step lookup, for the same reason: N sequential
# per-item GETs here would multiply this source's real latency by N for
# no benefit over a bounded number of them in flight at once. The hidden
# "token" field on the search form was confirmed live to work fine left
# blank (not a per-session CSRF value that gets validated).
DAMAG_BASE = 'https://damag.net'
_RE_DAMAG_ROW = re.compile(
    r'<a href="(/[A-Za-z0-9]+)"\s+target="_blank"\s+id="res\d+">([^<]+)</a>'
    r'.*?<span id="size\d+"[^>]*>(\d+)</span>',
    re.DOTALL
)
_RE_DAMAG_MAGNET = re.compile(r'magnet:\?xt=urn:btih:([A-Fa-f0-9]{40})')


def search_damag(title, year=None, limit=8, media_type='movie'):
    try:
        from concurrent.futures import ThreadPoolExecutor
        s = _sess()
        if not s:
            return []
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        # Origin/Referer are required here — confirmed live 2026-09-03 that
        # a request without them gets silently 302'd to /nsfw (403) instead
        # of running the actual search, regardless of query content (even a
        # plain "ubuntu" hits it) or any cookie/token. Passed per-request
        # rather than via s.headers.update(), since `s` is the module-wide
        # shared session every other concurrently-running source in
        # search_all() also uses — mutating its defaults here would leak
        # damag.net's Origin/Referer into every other source's requests too.
        _dmg_headers = {'Origin': DAMAG_BASE, 'Referer': DAMAG_BASE + '/'}
        home = s.get(DAMAG_BASE + '/', timeout=10, headers=_dmg_headers).text
        tok_m = re.search(r'name="token"\s+value="([^"]*)"', home)
        token = tok_m.group(1) if tok_m else ''
        r = s.post(DAMAG_BASE + '/', data={'token': token, 'q': query, 'wanted': '50'},
                   timeout=15, headers=_dmg_headers)
        r.raise_for_status()
        rows = _RE_DAMAG_ROW.findall(r.text)[:limit * 3]  # slack for quality-filtered drops
        candidates = []
        for path, name, size_b in rows:
            name = name.strip()
            if not name or not _meets_quality(name, media_type):
                continue
            candidates.append((path, name, int(size_b)))
            if len(candidates) >= limit:
                break
        if not candidates:
            return []

        def _resolve(item):
            path, name, size_b = item
            try:
                dr = s.get(DAMAG_BASE + path, timeout=10, headers=_dmg_headers)
                m = _RE_DAMAG_MAGNET.search(dr.text)
            except Exception:
                return None
            if not m:
                return None
            ih = m.group(1).lower()
            size = ''
            if size_b >= 1_073_741_824:
                size = '%.1f GB' % (size_b / 1_073_741_824)
            elif size_b >= 1_048_576:
                size = '%.0f MB' % (size_b / 1_048_576)
            return {
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    _make_magnet(ih, name),
                'seeds':     0,
                'size':      size,
                'source':    'DaMagNet',
            }

        results = []
        with ThreadPoolExecutor(max_workers=max(len(candidates), 1)) as pool:
            for res in pool.map(_resolve, candidates, timeout=15):
                if res:
                    results.append(res)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] DaMagNet error: %s' % e, xbmc.LOGWARNING)
        return []


# ── PublicDomainTorrents.info (real public-domain classic films) ────────────
# Old-school static site (confirmed live 2026-08-28), no login/paywall, no
# CF/JS wall anywhere. No search endpoint exists at all — only category
# browsing (nshowcat.html?category=X) — so the full 'ALL' category listing
# (981 real titles confirmed live, e.g. real IMDB-linked classics like
# "Africa Screams" tt0041098) is fetched once and cached 24h, then matched
# locally by title substring, same "no native search" workaround already
# used elsewhere in this file (myporn_sources.search_myporn_club's
# single-word-tag limitation gets a similar local-filter treatment).
# Detail pages (nshowmovie.html?movieid=<id>) never expose a magnet: URI —
# only real .torrent file downloads at several quality tiers (DivX AVI,
# iPod/PSP MP4, PDA-sized AVI) with the size in MB right in the link text.
# Downloading the largest one and deriving its info_hash from the raw
# bencoded 'info' dict (confirmed live against "Africa Screams" ->
# 07c88d686782bf1345b4c21a9bb2305630c1af98) reuses this file's own
# _bdecode/_bencode helpers — the exact same technique _nnm_hash_from_torrent
# above already uses for NNMClub's identically torrent-file-only downloads.
PDT_BASE = 'https://www.publicdomaintorrents.info'
PDT_DL_BASE = 'http://www.publicdomaintorrents.com'

_RE_PDT_ITEM = re.compile(r'href=nshowmovie\.html\?movieid=(\d+)>([^<]+)</a>')
_RE_PDT_DL = re.compile(
    r"href=\s*(http://www\.publicdomaintorrents\.com/bt/btdownload\.php\?"
    r"type=torrent&file=[^>]+\.torrent)>([^<]+)</a>", re.IGNORECASE)
_RE_PDT_SIZE_MB = re.compile(r'([\d.]+)\s*MB', re.IGNORECASE)


def _pdt_all_listing():
    ck = 'pdt_all_listing'
    if _HAS_CACHE:
        cached = _cache.get(ck)
        if cached is not None:
            return cached or []
    try:
        html = _get(PDT_BASE + '/nshowcat.html?category=ALL', timeout=15)
        items = [{'id': mid, 'title': _html_unescape(name.strip())}
                  for mid, name in _RE_PDT_ITEM.findall(html or '')]
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] PublicDomainTorrents listing error: %s' % e, xbmc.LOGWARNING)
        items = []
    if _HAS_CACHE and items:
        _cache.set(ck, items, 24 * 3600)
    return items


def _html_unescape(s):
    try:
        import html as _html_mod
        return _html_mod.unescape(s)
    except Exception:
        return s


def _pdt_hash_from_torrent(url):
    try:
        s = _sess()
        if not s:
            return None
        r = s.get(url, timeout=15)
        r.raise_for_status()
        data = r.content
        if not data:
            return None
        parsed, _pos = _bdecode(data, 0)
        info = parsed.get(b'info')
        if not info:
            return None
        return hashlib.sha1(_bencode(info)).hexdigest()
    except Exception:
        return None


def search_publicdomaintorrents(title, year=None, limit=5, media_type='movie'):
    if media_type != 'movie':
        return []
    try:
        from concurrent.futures import ThreadPoolExecutor
        listing = _pdt_all_listing()
        if not listing:
            return []
        q_words = [w for w in re.findall(r'[a-z0-9]+', title.lower()) if len(w) > 1]
        if not q_words:
            return []
        candidates = []
        for item in listing:
            t_words = set(re.findall(r'[a-z0-9]+', item['title'].lower()))
            if all(w in t_words for w in q_words):
                candidates.append(item)
            if len(candidates) >= limit:
                break
        if not candidates:
            return []

        def _resolve(item):
            try:
                html = _get(PDT_BASE + '/nshowmovie.html?movieid=%s' % item['id'], timeout=12)
                dls = _RE_PDT_DL.findall(html or '')
                if not dls:
                    return None
                # Pick the largest file by its own stated MB size — the
                # highest-quality option (usually the DivX AVI) also always
                # happens to be listed first, but sizes are compared
                # explicitly rather than assumed to stay in that order.
                def _mb(pair):
                    m = _RE_PDT_SIZE_MB.search(pair[1])
                    return float(m.group(1)) if m else 0.0
                best_url, best_label = max(dls, key=_mb)
                ih = _pdt_hash_from_torrent(best_url)
                if not ih:
                    return None
                size = re.sub(r'\s+', ' ', re.sub(r'^Click for\s+', '', best_label)).strip()
                return {
                    'title':     item['title'],
                    'year':      '',
                    'quality':   'SD',
                    'info_hash': ih,
                    'magnet':    _make_magnet(ih, item['title']),
                    'seeds':     0,
                    'size':      size,
                    'source':    'PublicDomainTorrents',
                }
            except Exception:
                return None

        results = []
        with ThreadPoolExecutor(max_workers=max(len(candidates), 1)) as pool:
            futs = [pool.submit(_resolve, c) for c in candidates]
            for fut in futs:
                try:
                    r = fut.result(timeout=15)
                except Exception:
                    r = None
                if r:
                    results.append(r)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] PublicDomainTorrents error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Snowfl.com — magnet metasearch aggregator (limetorrents/1337x/etc.) ─────
#
# Reputed hard-to-scrape in the Kodi/scraper community (its own homepage's
# click handler builds the real search URL as
# `"/" + <secret> + "/" + query + "/" + <sessionToken> + "/" + page + "/" +
# sort + "/" + top + "/" + nsfw`, with <secret> looking like a rotating/
# hashed value) — but confirmed live 2026-08-15 that <secret> is NOT
# actually computed by any hashing/obfuscation logic at request time: it's
# a literal `var <randomName>="<secret>";` string constant baked directly
# into the plain-text served `b.min.js?v=...` bundle (the query-string
# version, and the JS's own random variable NAME, presumably rotate on
# their own schedule, but the secret ITSELF is always sitting there in
# clear text at request time, extractable by a plain regex against the
# freshly-fetched bundle — no JS interpreter/engine ever needs to run).
# <sessionToken> in the URL is client-generated via `Math.random()`-style
# 8-char string and confirmed live the server accepts literally any
# 8-char alnum value there (tested with a hardcoded "abcd1234", worked
# fine) — it's not validated against any prior request/cookie, just part
# of the URL shape. The response itself is real, clean JSON — a list of
# {magnet, age, name, size, seeder, leecher, type, site, url, nsfw} — with
# a ready-to-use magnet: URI (real btih hash + tracker list) per item,
# already aggregated from multiple trackers (limetorrents, 1337x, etc. per
# the `site` field), and an explicit `nsfw` flag this integration uses for
# the adult-mode request instead of guessing from the title.
SNOWFL_BASE = 'https://snowfl.com'
_RE_SNOWFL_JS = re.compile(r'<script[^>]+src="([^"]+\.min\.js\?v=[^"]+)"')
_RE_SNOWFL_SECRET_IDENT = re.compile(r'"/"\s*\+\s*(\w+)\s*\+\s*\(\s*"/"')

_snowfl_secret_cache = {'value': None, 'ts': 0}


def _snowfl_get_secret():
    """Fetch snowfl.com's homepage + its bundled JS and pull out today's
    secret path segment fresh each time (cached 30 min in-process — long
    enough to avoid re-fetching/re-parsing a ~150KB JS bundle on every
    single search, short enough to notice if the site rotates it)."""
    now = time.time()
    if _snowfl_secret_cache['value'] and (now - _snowfl_secret_cache['ts']) < 1800:
        return _snowfl_secret_cache['value']
    try:
        home = _get(SNOWFL_BASE + '/', timeout=10)
        if not home:
            return None
        m = _RE_SNOWFL_JS.search(home)
        if not m:
            return None
        js = _get('%s/%s' % (SNOWFL_BASE, m.group(1)), timeout=10)
        if not js:
            return None
        m2 = _RE_SNOWFL_SECRET_IDENT.search(js)
        if not m2:
            return None
        ident = m2.group(1)
        m3 = re.search(re.escape(ident) + r'\s*=\s*"([A-Za-z0-9]{20,60})"', js)
        if not m3:
            return None
        secret = m3.group(1)
        _snowfl_secret_cache['value'] = secret
        _snowfl_secret_cache['ts'] = now
        return secret
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Snowfl secret extraction error: %s' % e, xbmc.LOGWARNING)
        return None


def search_snowfl(title, year=None, limit=10, media_type='movie'):
    """Search snowfl.com's aggregator API. Returns standard result dicts;
    magnets come straight from the API already complete (real btih hash +
    tracker list), no per-item follow-up fetch needed."""
    try:
        secret = _snowfl_get_secret()
        if not secret:
            return []
        import random, string
        from urllib.parse import quote as _q
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        token = ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(8))
        nsfw = '1' if media_type == 'adult' else '0'
        url = '%s/%s/%s/%s/0/NONE/NONE/%s' % (SNOWFL_BASE, secret, _q(query), token, nsfw)
        raw = _get(url, timeout=12)
        if not raw:
            return []
        import json
        try:
            items = json.loads(raw)
        except ValueError:
            return []
        if not isinstance(items, list):
            return []
        results = []
        for item in items:
            if len(results) >= limit:
                break
            name = (item.get('name') or '').strip()
            magnet = item.get('magnet') or ''
            if not name or not magnet or 'btih:' not in magnet.lower():
                continue
            if media_type != 'adult' and item.get('nsfw'):
                continue
            if not _meets_quality(name, media_type):
                continue
            m_ih = re.search(r'btih:([a-fA-F0-9]{40})', magnet)
            if not m_ih:
                continue
            ih = m_ih.group(1).lower()
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    magnet,
                'seeds':     int(item.get('seeder') or 0),
                'size':      item.get('size') or '',
                'source':    'Snowfl (%s)' % item.get('site', '') if item.get('site') else 'Snowfl',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Snowfl error: %s' % e, xbmc.LOGWARNING)
        return []


# ── EXT Torrents (ext.to) ─────────────────────────────────────────────────────
# Flipped back 2026-09-12: ext.to (dead/DNS-unresolving back on 2026-08-04,
# which is why this ever moved to extto.com as "the current live mirror" in
# the first place) has since come back online — and extto.com, this file's
# replacement pick, has since gone the other way, now sitting behind a
# genuine sustained Cloudflare 403 of its own (confirmed independently on
# three separate days, disabled elsewhere in this file). ext.to's own
# Cloudflare setup is a Turnstile "Verify you are human" checkbox (real
# interaction needed — confirmed live it does NOT silently self-check),
# but the cf_clearance cookie that checkbox produces is valid for a full
# YEAR (confirmed empirically via a real solve: Playwright's own cookie
# object reported `expires` ~8760h out, not the handful of hours SportSurge's
# equivalent cookie needs) — nothing like SportSurge's frequent-refresh
# problem, so this only needs the scraper-PC's own scraper_extto_cookie.py
# to run rarely (see run_extto_cookie.py's own comment for the schedule)
# rather than every couple hours. Magnet links still aren't in the
# search-result HTML (that part of the 2026-08 EXT-Torrents rewrite is
# unrelated to which domain serves it) — every torrent's magnet still has
# to be fetched per-item via the same small HMAC-signed AJAX call, same
# anti-scraping idea as vidhide_bypass.py's target but even simpler: the
# "secret" (window.pageToken) is embedded directly in that torrent's own
# detail-page HTML, and the HMAC is just a plain client-side SHA256
# (resources/lib/vidhide_bypass.py's docstring has more on this pattern of
# cosmetic-vs-real anti-scraping — this is cosmetic).

EXTTO_BASE = 'https://ext.to'
_EXTTO_AUTO_COOKIE_URL = 'https://hazmat77.github.io/repository.starfleet/data/extto_cookie.json'


def _extto_auto_cookie():
    """The scraper-PC-refreshed cf_clearance+UA pair (scraper_extto_cookie.py
    — real headed Chrome, refreshed rarely since the cookie itself is good
    for about a year, see this section's own header comment). Cached 30 min
    so ordinary browsing doesn't refetch this on every single search.
    Returns ('', '') on any failure so callers fall back to a cookie-less
    request cleanly (which will just 403, same as before this existed)."""
    ck = 'extto_auto_cookie_v1'
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    result = ('', '')
    try:
        r = _req.get(_EXTTO_AUTO_COOKIE_URL, timeout=8)
        r.raise_for_status()
        data = r.json()
        cf = (data.get('cf_clearance') or '').strip()
        ua = (data.get('user_agent') or '').strip()
        if cf:
            result = (cf, ua)
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] extto auto-cookie fetch error: %s' % e, xbmc.LOGWARNING)
    _cache.set(ck, result, 30 * 60)
    return result


def _extto_get(url, timeout=10):
    """GET an ext.to path using the auto-refreshed cf_clearance cookie —
    returns None if no cookie is available yet, or the cookie's expired
    (still gets the Turnstile challenge page back), matching this file's
    existing convention of treating that exactly like any other source
    finding nothing rather than raising."""
    cookie, ua = _extto_auto_cookie()
    if not cookie:
        return None
    try:
        s = _sess()
        r = s.get(url, cookies={'cf_clearance': cookie},
                   headers=dict(_BROWSER_HEADERS, **{'User-Agent': ua or _BROWSER_HEADERS['User-Agent']}),
                   timeout=timeout)
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] extto fetch error: %s' % e, xbmc.LOGWARNING)
        return None
    if r.status_code != 200 or 'Just a moment' in r.text[:2000] or 'challenges.cloudflare.com' in r.text[:2000]:
        xbmc.log('[Starfleet/Torrents] extto cf_clearance cookie missing/expired', xbmc.LOGWARNING)
        return None
    return r.text


_EXTTO_CAT = {'movie': 1, 'tv': 2, 'adult': 10}
_RE_EXTTO_ROW_TITLE = re.compile(
    r'<a href="(/[a-z0-9\-]+-(\d+)/)"\s+class="torrent-title-link"[^>]*data-tooltip="([^"]+)"',
    re.IGNORECASE
)
_RE_EXTTO_SEEDS = re.compile(r'file_upload</i>\s*<span[^>]*>(\d+)</span>')
_RE_EXTTO_SIZE  = re.compile(r'storage</i>\s*<span>([^<]+)</span>')
_RE_EXTTO_TOKEN = re.compile(r'pageToken\s*=\s*["\']([^"\']+)["\']')
_RE_EXTTO_CSRF  = re.compile(r'csrfToken\s*=\s*["\']([^"\']+)["\']')


def _extto_get_magnet(detail_path, torrent_id):
    """Reproduces main.min.js's handleTorrentDownload(): fetch the torrent's
    own detail page for its per-page pageToken/csrfToken, compute the same
    plain SHA256 HMAC the site's own JS does, then hit its AJAX endpoint
    directly — confirmed live to return a real, complete magnet link."""
    import time as _time
    import hashlib as _hashlib
    try:
        detail_html = _extto_get(EXTTO_BASE + detail_path, timeout=8)
        if not detail_html:
            return ''
        tok_m = _RE_EXTTO_TOKEN.search(detail_html)
        csrf_m = _RE_EXTTO_CSRF.search(detail_html)
        if not tok_m or not csrf_m:
            return ''
        timestamp = int(_time.time())
        hmac_token = _hashlib.sha256(
            ('%s|%d|%s' % (torrent_id, timestamp, tok_m.group(1))).encode('utf-8')
        ).hexdigest()
        cookie, ua = _extto_auto_cookie()
        if not cookie:
            return ''
        s = _sess()
        if not s:
            return ''
        r = s.post(
            EXTTO_BASE + '/ajax/getTorrentMagnet.php',
            data={
                'torrent_id': torrent_id, 'download_type': 'magnet',
                'timestamp': timestamp, 'hmac': hmac_token, 'sessid': csrf_m.group(1),
            },
            cookies={'cf_clearance': cookie},
            headers=dict(_BROWSER_HEADERS, **{
                'User-Agent': ua or _BROWSER_HEADERS['User-Agent'],
                'X-Requested-With': 'XMLHttpRequest', 'Referer': EXTTO_BASE + detail_path,
            }),
            timeout=8,
        )
        import json as _json
        data = _json.loads(r.text)
        if data.get('success'):
            return data.get('url') or (
                _make_magnet(data['hash']) if data.get('hash') else ''
            )
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] extto magnet fetch error: %s' % e, xbmc.LOGWARNING)
    return ''


def search_extto(title, year=None, limit=5, media_type='movie'):
    """ext.to ("EXT Torrents") — /browse/?q=...&cat=N (1=Movies, 2=TV,
    10=Adult, needs &with_adult=1 too). Needs the auto-refreshed
    cf_clearance cookie (see this section's own header comment) — returns
    [] immediately if one isn't published yet, same as any other source
    finding nothing. Each candidate needs its own _extto_get_magnet() call
    (see that function's docstring) so this stays bounded to `limit`
    candidates, resolved in parallel."""
    try:
        if not _req:
            return []
        q = _req.utils.quote(title)
        cat = _EXTTO_CAT.get(media_type, 1)
        url = '%s/browse/?q=%s&cat=%d&sort=seeds&order=desc' % (EXTTO_BASE, q, cat)
        if media_type == 'adult':
            url += '&with_adult=1'
        html_raw = _extto_get(url, timeout=10)
        if not html_raw:
            return []
        import html as _html

        candidates = []
        for m in _RE_EXTTO_ROW_TITLE.finditer(html_raw):
            if len(candidates) >= limit:
                break
            path, torrent_id, tooltip = m.group(1), m.group(2), m.group(3)
            # data-tooltip is double-HTML-encoded (its own <span> highlight
            # tags come through as literal "&lt;span&gt;" text) — unescape
            # first so the tag-strip regex actually has real "<...>" to match.
            name = re.sub(r'<[^>]+>', '', _html.unescape(tooltip)).strip()
            if not name or not _meets_quality(name, media_type):
                continue
            start = m.end()
            block = html_raw[start:start + 4500]
            seeds_m = _RE_EXTTO_SEEDS.search(block)
            size_m = _RE_EXTTO_SIZE.search(block)
            candidates.append({
                'path': path, 'id': torrent_id, 'name': name,
                'seeds': int(seeds_m.group(1)) if seeds_m else 0,
                'size': size_m.group(1).strip() if size_m else '',
            })

        if not candidates:
            return []

        from concurrent.futures import ThreadPoolExecutor
        results = []
        with ThreadPoolExecutor(max_workers=min(len(candidates), 15)) as pool:
            fmap = {pool.submit(_extto_get_magnet, c['path'], c['id']): c for c in candidates}
            for fut, c in fmap.items():
                try:
                    magnet = fut.result(timeout=10)
                except Exception:
                    magnet = ''
                if not magnet:
                    continue
                ih_m = re.search(r'btih:([a-fA-F0-9]{40})', magnet, re.IGNORECASE)
                results.append({
                    'title': c['name'], 'year': '', 'quality': _extract_quality(c['name']),
                    'info_hash': ih_m.group(1).lower() if ih_m else '', 'magnet': magnet,
                    'seeds': c['seeds'], 'size': c['size'], 'source': 'EXTto',
                })
        return sorted(results, key=lambda x: x['seeds'], reverse=True)
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] extto error: %s' % e, xbmc.LOGWARNING)
        return []


# ── TheRarBG ──────────────────────────────────────────────────────────────────
# The original RARBG shut down permanently in May 2023 — this is an
# actively-run unofficial revival using the same branding (confirmed live
# 2026-08-04: real, current 2026 uploads across Movies/TV/XXX, not a stale
# database dump), not the original site. Fully open, no Cloudflare wall,
# and — unlike extto.com — its detail pages carry the magnet link directly
# inline with no token/HMAC dance needed at all.

THERARBG_BASE = 'https://therarbg.com'
_THERARBG_CAT = {'movie': 'Movies', 'tv': 'TV', 'adult': 'XXX'}
_RE_THERARBG_ROW = re.compile(
    r'href="(/post-detail/[a-z0-9]+/[^"]+)"\s+style="font-weight: 700"\s*>([^<]+)</a>',
    re.IGNORECASE
)
_RE_THERARBG_SIZE = re.compile(r'sizeCell"[^>]*>([^<]+)</td>')
_RE_THERARBG_SEEDS = re.compile(r'color:\s*green">(\d+)</td>')
_RE_THERARBG_MAGNET = re.compile(r'href="(magnet:\?xt=urn:btih:([0-9a-fA-F]{40})[^"]*)"')


def _therarbg_get_magnet(detail_path):
    try:
        html = _get(THERARBG_BASE + detail_path, timeout=8)
        if not html:
            return '', ''
        m = _RE_THERARBG_MAGNET.search(html)
        if not m:
            return '', ''
        return m.group(1).replace('&amp;', '&'), m.group(2).lower()
    except Exception:
        return '', ''


def search_therarbg(title, year=None, limit=5, media_type='movie'):
    """therarbg.com — query syntax is one colon-joined path segment,
    /get-posts/keywords:X:category:Y/ — confirmed live that a
    slash-separated keywords:X/category:Y/ silently falls back to the
    homepage's default listing instead of filtering, so this MUST stay one
    segment. A literal colon in the title (e.g. "Spider-Man: Into the
    Spider-Verse") is safe percent-encoded via quote_plus — confirmed live
    it still filters correctly rather than breaking the site's own
    colon-delimited parsing. Search results already carry size/seeds; only
    the magnet needs a separate per-item detail-page fetch."""
    try:
        if not _req:
            return []
        from urllib.parse import quote_plus as _qp2
        cat = _THERARBG_CAT.get(media_type, 'Movies')
        q = _qp2(re.sub(r'\s+', ' ', title).strip())
        url = '%s/get-posts/keywords:%s:category:%s/' % (THERARBG_BASE, q, cat)
        html_raw = _get(url, timeout=10)
        if not html_raw:
            return []

        matches = list(_RE_THERARBG_ROW.finditer(html_raw))
        candidates = []
        for i, m in enumerate(matches):
            if len(candidates) >= limit:
                break
            name = m.group(2).strip()
            if not name or not _meets_quality(name, media_type):
                continue
            start = m.end()
            end = matches[i + 1].start() if i + 1 < len(matches) else start + 1200
            block = html_raw[start:end]
            size_m = _RE_THERARBG_SIZE.search(block)
            seeds_m = _RE_THERARBG_SEEDS.search(block)
            candidates.append({
                'path': m.group(1), 'name': name,
                'size': size_m.group(1).replace('\xa0', ' ').strip() if size_m else '',
                'seeds': int(seeds_m.group(1)) if seeds_m else 0,
            })

        if not candidates:
            return []

        from concurrent.futures import ThreadPoolExecutor
        results = []
        with ThreadPoolExecutor(max_workers=min(len(candidates), 15)) as pool:
            fmap = {pool.submit(_therarbg_get_magnet, c['path']): c for c in candidates}
            for fut, c in fmap.items():
                try:
                    magnet, info_hash = fut.result(timeout=10)
                except Exception:
                    magnet, info_hash = '', ''
                if not magnet:
                    continue
                results.append({
                    'title': c['name'], 'year': '', 'quality': _extract_quality(c['name']),
                    'info_hash': info_hash, 'magnet': magnet,
                    'seeds': c['seeds'], 'size': c['size'], 'source': 'TheRarBG',
                })
        return sorted(results, key=lambda x: x['seeds'], reverse=True)
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] therarbg error: %s' % e, xbmc.LOGWARNING)
        return []


# ── RARBG Dump (rarbgdump.com — static archive of RARBG's own database,
# 2.8M+ entries; RARBG itself has been dead since 2023) ──────────────────────
#
# Confirmed live 2026-09-03: real JSON API (POST /api/search {"query":...}),
# no Cloudflare interstitial actually in front of it despite the
# challenge-platform scripts the page itself loads — those only ever fired
# their own background telemetry beacons (cdn-cgi/rum) in testing, never
# blocked the API call itself. Every hit already carries a real 40-char
# btih hash plus its own seeders/leechers straight in the response — no
# per-item resolve step needed, unlike DaMagNet elsewhere in this file.
# Since RARBG is dead, this is a frozen 2023 snapshot, not a live crawl:
# seeder counts are whatever they were at RARBG's own last update, not
# current — but the swarms themselves (DHT-level) can still be alive years
# later for anything popular enough, same as any other old-but-real hash.
# Each hit's own 'cat' field (e.g. "movies_x265_4k_hdr", "music_mp3",
# "games_pc_iso", "xxx") is real per-source metadata the archive carries
# for every entry, not a guess from the title — used here to drop the
# non-video categories a plain title-text quality filter can't see (unlike
# most other sources in this file, this one gets to filter on ground truth
# instead of pattern-matching the release name for the same signal).
_RARBGDUMP_API = 'https://rarbgdump.com/api/search'


def search_rarbgdump(title, year=None, limit=10, media_type='movie'):
    try:
        if not _req:
            return []
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        r = _sess().post(_RARBGDUMP_API, json={'query': query}, timeout=12)
        r.raise_for_status()
        items = (r.json() or {}).get('results') or []
        results = []
        for item in items:
            if len(results) >= limit:
                break
            cat = (item.get('cat') or '').lower()
            if media_type == 'adult':
                if not cat.startswith('xxx'):
                    continue
            elif not (cat.startswith('movies') or cat.startswith('tv')):
                continue
            name = (item.get('title') or '').strip()
            ih = (item.get('hash') or '').lower()
            if not name or not ih or not _meets_quality(name, media_type):
                continue
            try:
                size_b = int(item.get('size') or 0)
            except (TypeError, ValueError):
                size_b = 0
            size = ''
            if size_b >= 1_073_741_824:
                size = '%.1f GB' % (size_b / 1_073_741_824)
            elif size_b >= 1_048_576:
                size = '%.0f MB' % (size_b / 1_048_576)
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    _make_magnet(ih, name),
                'seeds':     int(item.get('seeders') or 0),
                'size':      size,
                'source':    'RARBGDump',
            })
        return sorted(results, key=lambda x: x['seeds'], reverse=True)
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] RARBGDump error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Demonoid (demonoid.nl — 2026 revival of the classic tracker) ─────────────
#
# Confirmed live 2026-09-04: a real, clean JSON GET API (no Cloudflare wall,
# no login/account needed to search), quite different from the original
# Demonoid (a private, invite-gated tracker) — this revival is fully open.
# Small/curated catalog (528 total hits for the bare word "the" against its
# whole library, vs. tens of thousands on the big aggregators), but with
# genuinely current, real content (e.g. this week's episodes of "The Pitt"
# and "Tehran" showed up in testing) and a real `seeders`/`leechers` count
# per item. Its own `category` filter (`&category=Movies` / `&category=TV
# Shows`) is honored server-side (confirmed live: narrows result counts
# correctly), so it's used here to scope the query instead of relying on
# _meets_quality alone. Not every hit carries a magnet — plenty only have a
# `file_path` to a .torrent file with no magnet/info_hash inline at all — so
# those are skipped outright rather than adding a third per-item
# resolve-a-.torrent-file step (like NNMClub/DaMagNet elsewhere in this
# file) for what would be a small niche site's already-small result set.
DEMONOID_API = 'https://demonoid.nl/api/torrents.php'
_RE_DEMONOID_HASH = re.compile(r'btih:([a-fA-F0-9]{40})', re.IGNORECASE)


def search_demonoid(title, year=None, limit=10, media_type='movie'):
    try:
        if not _req:
            return []
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        category = {'movie': 'Movies', 'tv': 'TV Shows'}.get(media_type, 'all')
        params = {
            'action': 'list', 'page': 1, 'limit': max(limit * 3, 20),
            'search': query, 'category': category,
        }
        r = _sess().get(DEMONOID_API, params=params, timeout=10)
        r.raise_for_status()
        items = (r.json() or {}).get('torrents') or []
        results = []
        for item in items:
            if len(results) >= limit:
                break
            if not item.get('is_active', True):
                continue
            magnet = item.get('magnet_link') or ''
            if not magnet:
                continue
            ih_m = _RE_DEMONOID_HASH.search(magnet)
            if not ih_m:
                continue
            name = (item.get('name') or '').strip()
            if not name or not _meets_quality(name, media_type):
                continue
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih_m.group(1).lower(),
                'magnet':    magnet,
                'seeds':     int(item.get('seeders') or 0),
                'size':      item.get('file_size') or '',
                'source':    'Demonoid',
            })
        return sorted(results, key=lambda x: x['seeds'], reverse=True)
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Demonoid error: %s' % e, xbmc.LOGWARNING)
        return []


# ── TorrentFunk (its HTML search.php is genuinely Cloudflare JS-challenge
# protected, confirmed live -- but the site documents/exposes a free,
# keyless JSON API at /api/search.json with real server-side query search,
# no CF in front of it at all. Ready-to-use magnet + infohash straight in
# the response, no local matching or file-download workaround needed,
# unlike KONTRAST.) ───────────────────────────────────────────────────────────

TORRENTFUNK_API = 'https://www.torrentfunk.com/api/search.json'
_TORRENTFUNK_CAT = {'movie': 1, 'tv': 3, 'adult': 7}


def search_torrentfunk(title, year=None, limit=5, media_type='movie'):
    try:
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        import urllib.parse as _up
        params = {
            'q': query[:100],
            'limit': min(max(limit * 2, 5), 100),
            'sort': 'seeds',
            'order': 'desc',
        }
        cat = _TORRENTFUNK_CAT.get(media_type)
        if cat:
            params['category'] = cat
        url = '%s?%s' % (TORRENTFUNK_API, _up.urlencode(params))
        data = _get_json(url, timeout=8)
        if not data or data.get('status') != 'ok':
            return []
        results = []
        for item in data.get('results', []):
            if len(results) >= limit:
                break
            name = item.get('name', '')
            ih = (item.get('infohash') or '').lower()
            if not name or not ih or not _meets_quality(name, media_type):
                continue
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    item.get('magnet') or _make_magnet(ih, name),
                'seeds':     item.get('seeds', 0),
                'size':      item.get('size', ''),
                'source':    'TorrentFunk',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] TorrentFunk error: %s' % e, xbmc.LOGWARNING)
        return []


# ── TorrentsCSV (clean JSON API, no Cloudflare, no auth -- real infohash and
# seeders straight in the response, same category as TorrentFunk's own
# official API: no scraping or per-item detail fetch needed at all) ──────────

TORRENTSCSV_BASE = 'https://torrents-csv.com/service/search'


def search_torrentscsv(title, year=None, limit=10, media_type='movie'):
    try:
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        import urllib.parse as _up
        url = '%s?%s' % (TORRENTSCSV_BASE, _up.urlencode(
            {'size': min(max(limit * 3, 20), 100), 'q': query}))
        data = _get_json(url, timeout=8)
        if not data:
            return []
        results = []
        for item in data.get('torrents', []):
            if len(results) >= limit:
                break
            name = item.get('name', '')
            ih = (item.get('infohash') or '').lower()
            if not name or not ih or not _meets_quality(name, media_type):
                continue
            b = item.get('size_bytes') or 0
            size = ''
            if b >= 1_073_741_824:
                size = '%.1f GB' % (b / 1_073_741_824)
            elif b >= 1_048_576:
                size = '%.0f MB' % (b / 1_048_576)
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    _make_magnet(ih, name),
                'seeds':     item.get('seeders', 0) or 0,
                'size':      size,
                'source':    'TorrentsCSV',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] TorrentsCSV error: %s' % e, xbmc.LOGWARNING)
        return []


# ── TorrentKitty (DHT crawler index: every result is a real info-hash, but there are no seed counts and the
# sizes it prints are not reliable, so results sort after sources that know their seeders) ─────────────────────

TORRENTKITTY_BASE = 'https://www.torrentkitty.tv'


def search_torrentkitty(title, year=None, limit=10, media_type='movie'):
    try:
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        s = _sess()
        if not s:
            return []
        import urllib.parse as _up
        r = s.get('%s/search/%s/' % (TORRENTKITTY_BASE, _up.quote(query)), timeout=10)
        if r.status_code != 200:
            return []
        results, seen = [], set()
        for row in re.findall(r'<tr><td class="name">(.*?)</td>.*?href="magnet:\?xt=urn:btih:([0-9A-Fa-f]{40})', r.text, re.S):
            name = re.sub(r'<[^>]+>', '', row[0]).strip()
            ih = row[1].lower()
            if not name or ih in seen or not _meets_quality(name, media_type):
                continue
            seen.add(ih)
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    _make_magnet(ih, name),
                'seeds':     0,
                'size':      '',
                'source':    'TorrentKitty',
            })
            if len(results) >= limit:
                break
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] TorrentKitty error: %s' % e, xbmc.LOGWARNING)
        return []


# ── BitTorrented ──────────────────────────────────────────────────────────────

BITTORRENTED_BASE = 'https://bittorrented.com'
_RE_BT_SIZE = re.compile(r'(\d+(?:\.\d+)?)\s*(GB|MB|GiB|MiB)', re.IGNORECASE)


def search_bittorrented(title, year=None, limit=5, media_type='movie'):
    """BitTorrented — HTML scraper, may be CF-protected."""
    try:
        if not _req:
            return []
        q = _req.utils.quote(title)
        url = '%s/search/?q=%s&category=0' % (BITTORRENTED_BASE, q)
        html_raw = _get(url, timeout=10, cf=True)
        if not html_raw:
            return []
        import html as _html
        text = _html.unescape(html_raw)
        parts = re.split(r'(magnet:\?[^"\'<\s]+)', text)
        results = []
        i = 1
        while i < len(parts) - 1 and len(results) < limit:
            raw_magnet = parts[i].replace('&amp;', '&')
            before = parts[i - 1][-800:]
            i += 2
            ih_m = re.search(r'btih:([a-fA-F0-9]{40})', raw_magnet, re.IGNORECASE)
            if not ih_m:
                continue
            info_hash = ih_m.group(1).lower()
            dn_m = re.search(r'[&?]dn=([^&"\'<\s]+)', raw_magnet)
            name = _req.utils.unquote(dn_m.group(1)).replace('+', ' ').strip() if dn_m else ''
            if not name:
                t_m = re.search(r'<a[^>]+class="[^"]*name[^"]*"[^>]*>([^<]{5,80})<', before, re.IGNORECASE)
                if t_m:
                    name = t_m.group(1).strip()
            if not name or not _meets_quality(name, media_type):
                continue
            sz_m = _RE_BT_SIZE.search(before[-400:])
            size = sz_m.group(0) if sz_m else ''
            seeds_m = re.search(r'(\d+)\s*seeder', before[-400:], re.IGNORECASE)
            seeds = int(seeds_m.group(1)) if seeds_m else 0
            results.append({
                'title': name, 'year': '', 'quality': _extract_quality(name),
                'info_hash': info_hash, 'magnet': raw_magnet,
                'seeds': seeds, 'size': size, 'source': 'BitTorrented',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] BitTorrented error: %s' % e, xbmc.LOGWARNING)
        return []


XXXCLUB_BASE = 'https://xxxclub.to'


_SPLIT_SCENE_RE = re.compile(r'\bsplit[\s._-]*scenes?\b', re.IGNORECASE)
_XXXCLUB_HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9',
    'Accept-Encoding': 'gzip, deflate',
}


_XXXCLUB_BROWSE_TTL = 21600  # 6 hours


def browse_xxxclub(cursor='', limit=51):
    """
    Browse latest adult torrents from xxxclub.to via direct HTML scrape.
    cursor: '' or '1' → first page; a long digit string → actual xxxclub cursor
            for subsequent pages (extracted from the site's Next link).
    Returns (results_list, next_site_cursor) where next_site_cursor is the raw
    cursor string from the site's Next link (empty string if no next page).
    """
    import urllib.request as _ureq
    import gzip as _gz

    cat = 3  # Movies/DVD/WEB category

    # Decide whether cursor is a real site cursor (long number) or page 1
    is_page1 = (not cursor) or (cursor.isdigit() and int(cursor) <= 1)
    site_cursor = '' if is_page1 else cursor  # the actual xxxclub cursor for page 2+

    # 'xxxclub_p1v2' key is new (old key was 'xxxclub_browse_1' with wrong cursor baked in)
    ck = 'xxxclub_p1v2' if is_page1 else ('xxxclub_browse_c_%s' % site_cursor[:20])
    if _HAS_CACHE:
        cached = _cache.get(ck)
        if cached is not None:
            results, next_site_cursor = cached
            xbmc.log('[Starfleet/XXXClub] cache hit cursor=%s (%d items)' % (site_cursor or '1', len(results)), xbmc.LOGINFO)
            return results, next_site_cursor

    def _fetch_html(url):
        req = _ureq.Request(url)
        for k, v in _XXXCLUB_HEADERS.items():
            req.add_header(k, v)
        with _ureq.urlopen(req, timeout=12) as resp:
            raw = resp.read()
            if resp.headers.get('Content-Encoding') == 'gzip':
                raw = _gz.decompress(raw)
        return raw.decode('utf-8', errors='replace')

    try:
        if site_cursor:
            url = '%s/torrents/browse/%d/%s' % (XXXCLUB_BASE, cat, site_cursor)
        else:
            url = '%s/torrents/browse/%d/' % (XXXCLUB_BASE, cat)

        html = _fetch_html(url)
        rows = re.findall(
            r'id="#i([a-fA-F0-9]{40})"[^>]*onpointerleave="hideImage\(\)">(.*?)</a>'
            r'.*?src=.(https://imgxclub\.com/[^\'\"]+).'
            r'.*?class="siz[^"]*">([^<]*)</span>'
            r'.*?class="see[^"]*">([^<]*)</span>',
            html, re.DOTALL
        )
        xbmc.log('[Starfleet/XXXClub] direct cursor=%s rows=%d' % (site_cursor or '1', len(rows)), xbmc.LOGWARNING)
        if len(rows) < 3:
            raise ValueError('too few rows')

        results = []
        for ih, title, thumb, size, seeds in rows:
            title = title.strip()
            if not title or _SPLIT_SCENE_RE.search(title):
                continue
            results.append({
                'title': title,
                'info_hash': ih.lower(),
                'magnet': _make_magnet(ih, title),
                'thumb': thumb.strip(),
                'size': size.strip(),
                'seeds': seeds.strip(),
            })
            if len(results) >= limit:
                break

        # Extract the Next page cursor from the real (visible) Next Page link.
        # The site has multiple hidden decoy links (style="position:absolute; left:-99999px")
        # and one real link marked with data-no-instant — match only that one.
        next_m = re.search(r'href=["\']?/torrents/browse/%d/(\d{8,})["\']?[^>]*data-no-instant' % cat, html, re.IGNORECASE)
        next_site_cursor = next_m.group(1) if next_m else ''

        if _HAS_CACHE:
            _cache.set(ck, (results, next_site_cursor), _XXXCLUB_BROWSE_TTL)
        return results, next_site_cursor
    except Exception as e:
        xbmc.log('[Starfleet/XXXClub] direct scrape failed (%s), falling back to Knaben' % e, xbmc.LOGWARNING)
    try:
        offset = (page - 1) * limit
        body = {'query': 'xxx', 'order_by': 'date', 'take': limit, 'skip': offset}
        if not _req:
            return [], ''
        r = _sess().post(KNABEN_API, json=body, headers=_KNABEN_HEADERS, timeout=12)
        if r.status_code >= 400 or not r.text.strip():
            return [], ''
        data = r.json()
        hits = data.get('hits') or data.get('result') or data.get('results') or []
        xbmc.log('[Starfleet/XXXClub] Knaben fallback returned %d hits' % len(hits), xbmc.LOGWARNING)
        results = []
        for entry in hits:
            name = entry.get('title', '').strip()
            if not name or _SPLIT_SCENE_RE.search(name):
                continue
            ih = (entry.get('hash') or '').lower()
            if not ih:
                continue
            magnet = entry.get('magnetUrl') or _make_magnet(ih, name)
            b = entry.get('bytes') or 0
            size = '%.1f GB' % (b / 1_073_741_824) if b >= 1_073_741_824 else '%.0f MB' % (b / 1_048_576) if b >= 1_048_576 else ''
            results.append({'title': name, 'info_hash': ih, 'magnet': magnet, 'thumb': '', 'size': size})
            if len(results) >= limit:
                break
        next_cursor = str(page + 1) if len(hits) >= limit else ''
        if _HAS_CACHE:
            _cache.set(ck, (results, next_cursor), _XXXCLUB_BROWSE_TTL)
        return results, next_cursor
    except Exception as e2:
        xbmc.log('[Starfleet/XXXClub] Knaben fallback error: %s' % e2, xbmc.LOGWARNING)
        return [], ''


# XXXClub answers a handful of requests at a time: an Adult search also asks it, one film after another, whether each film has a source
# (a few dozen requests at once), which starved the real search of the title and left XXXClub out of the results. At most three
# of those checks run at a time (the real search is not held up by them), and the same question asked again within ten minutes is
# answered from memory.
import threading as _threading
_XC_SLOTS = _threading.Semaphore(3)
_XC_MEMO = {}


def search_xxxclub(title, year=None, limit=10, media_type='movie'):
    key = ((title or '').strip().lower(), int(limit or 0), media_type)
    hit = _XC_MEMO.get(key)
    if hit and time.time() - hit[0] < 600:
        return list(hit[1])
    if (limit or 0) > 3:                             # a real search is never kept waiting behind the one-hit "has this film a source" checks
        out = _search_xxxclub_now(title, year, limit, media_type)
    else:
        with _XC_SLOTS:
            hit = _XC_MEMO.get(key)                  # asked while this one waited for a slot
            if hit and time.time() - hit[0] < 600:
                return list(hit[1])
            out = _search_xxxclub_now(title, year, limit, media_type)
    if out:                                          # an empty answer may be a refused request: asked again next time
        if len(_XC_MEMO) > 400:
            _XC_MEMO.clear()
        _XC_MEMO[key] = (time.time(), list(out))
    return out


def _search_xxxclub_now(title, year=None, limit=10, media_type='movie'):
    """Adult torrent search via direct xxxclub.to HTML scrape."""
    if media_type != 'adult':
        return []
    # Clean here (not just at the ADE-ingestion layer) so a raw search-box
    # query — which never goes through ADE's own title cleaning — gets the
    # same studio/resolution/junk stripping as a canonical ADE title before
    # it's used to build the search query or to match results against.
    title = _clean_adult_title(title) or title
    import urllib.request as _ureq
    import urllib.parse as _uparse
    import gzip as _gz

    query = title

    def _fetch_html(u):
        req = _ureq.Request(u)
        for k, v in _XXXCLUB_HEADERS.items():
            req.add_header(k, v)
        with _ureq.urlopen(req, timeout=14) as resp:
            raw = resp.read()
            if resp.headers.get('Content-Encoding') == 'gzip':
                raw = _gz.decompress(raw)
        return raw.decode('utf-8', errors='replace')

    _LEET_MAP = str.maketrans({'4': 'a', '3': 'e', '1': 'i', '0': 'o', '5': 's', '@': 'a', '!': 'i'})

    def _parse_rows(html, q):
        r = re.findall(
            r'id="#i([a-fA-F0-9]{40})"[^>]*>(.*?)</a>'
            r'.*?class="siz[^"]*">([^<]*)</span>'
            r'.*?class="see[^"]*">([^<]*)</span>',
            html, re.DOTALL
        )
        xbmc.log('[Starfleet/XXXClub] search "%s" html=%d rows=%d' % (q, len(html), len(r)), xbmc.LOGINFO)
        if not r:
            xbmc.log('[Starfleet/XXXClub] search html snippet: %s' % html[:600].replace('\n', ' '), xbmc.LOGWARNING)
        return r

    def _smart_deleet(q):
        # Only translate leet chars inside words that also contain real letters.
        # Standalone digits (e.g. "#4" sequel numbers) are left as-is.
        def _tok(t):
            if re.search(r'[a-zA-Z]', t) and re.search(r'[4310@!5]', t):
                return t.translate(_LEET_MAP)
            return t
        return re.sub(r'[A-Za-z0-9@!]+', lambda m: _tok(m.group()), q)

    def _build_variants(q):
        import html as _hl
        q = _hl.unescape(q)
        deleet = _smart_deleet(q)
        stripped = re.sub(r'[#@!]', ' ', q).strip()
        stripped_deleet = _smart_deleet(stripped)
        seen = set()
        variants = []
        # Try clean variants first (no #/@/!) — special chars cause xxxclub to ignore
        # the episode number entirely, returning the full catalogue instead
        for v in [stripped, stripped_deleet, q, deleet]:
            v = re.sub(r'\s+', ' ', v).strip()
            if v and v not in seen:
                seen.add(v)
                variants.append(v)
        return variants

    try:
        rows = []
        for variant in _build_variants(query):
            v_url = '%s/torrents/search/all/%s' % (XXXCLUB_BASE, _uparse.quote(variant))
            try:
                html = _fetch_html(v_url)
                rows = _parse_rows(html, variant)
            except Exception:
                continue
            if rows:
                break
        import html as _html_mod

        # Normalise query for matching: lowercase, strip non-alphanum, collapse spaces
        def _nc(s):
            return re.sub(r'\s+', ' ', re.sub(r'[^a-z0-9 ]', ' ', s.lower())).strip()

        # Strip resolution/year/studio/codec suffixes from torrent name to get core title
        _SUFFIX_RE = re.compile(
            r'\s*[\(\[]?(19|20)\d{2}[\)\]]?.*$'
            r'|\s+(WEB-?DL|BluRay|BDRip|DVDRip|HDTV|x264|x265|HEVC|AAC|MP4|AVC'
            r'|480p|540p|720p|1080p|2160p|4K|UHD|HDRip|WEBRip|SPLIT)\b.*$',
            re.IGNORECASE)

        norm_query = _nc(query)
        qwords = norm_query.split()

        results = []
        for ih, name, size, seeds in rows:
            name = _html_mod.unescape(name).strip()
            if not name or _SPLIT_SCENE_RE.search(name):
                continue
            # Strip suffixes to get the core torrent title, then normalise
            name = name.replace('<mark>', '').replace('</mark>', '')
            core = _nc(_SUFFIX_RE.sub('', name))
            # Accept if core title exactly equals query, or core starts with query
            # (allows e.g. "Threesomes 7 (Marc DORCEL)" after stripping → "threesomes 7")
            # Reject if extra words appear BEFORE the query words (e.g. "Anal Threesomes 7")
            def _qw_in(w, s):
                """Word match allowing episode-number variants: '97' matches 'E97', '097'."""
                if w in s.split():
                    return True
                if w.isdigit():
                    # (?<!\d)0*97(?!\d) matches "97", "097", "E097" but not "970", "197"
                    return bool(re.search(r'(?<!\d)0*' + re.escape(w) + r'(?!\d)', s))
                return False

            if core == norm_query or core.startswith(norm_query) or norm_query in core:
                pass  # good match — also catches "marc dorcel threesomes 7 xxx" style torrent names
            else:
                # Try: all query words present and core starts with first query word
                if qwords and core.startswith(qwords[0]) and all(_qw_in(w, core) for w in qwords):
                    pass  # "Threesomes 7 Special Edition" / "FacialCasting E097" type match
                else:
                    continue  # skip — too loose
            results.append({
                'title':     re.sub(r'(?i)^(brazzers|blacked|tushy|vixen|deeper|mofos|bangbros|realitykings|digitalplayground|evilangel|julesjordan)(?=[A-Z][a-z])', r'\g<1> ', name),
                'info_hash': ih.lower(),
                'magnet':    _make_magnet(ih, name),
                'seeds':     int(seeds.strip()) if seeds.strip().isdigit() else 0,
                'size':      size.strip(),
                'source':    'XXXClub',
            })
            if len(results) >= limit:
                break
        xbmc.log('[Starfleet/XXXClub] search "%s" matched %d/%d after title filter' % (
            query, len(results), len(rows)), xbmc.LOGINFO)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/XXXClub] search error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Rintor (adult torrent tracker — plain WordPress, no Cloudflare) ───────────

RINTOR_BASE = 'https://www.rintor.net'

_RE_RINTOR_RESULT = re.compile(
    r'<a[^>]+href="(https://(?:www\.)?rintor\.net/[^"]+\.html)"[^>]*>([^<]{5,120})</a>',
    re.IGNORECASE
)
_RE_RINTOR_MAGNET = re.compile(r'magnet:\?[^"\'<> ]+', re.IGNORECASE)
_RE_RINTOR_XL = re.compile(r'[?&]xl=(\d+)')


def _rintor_human_size(magnet):
    m = _RE_RINTOR_XL.search(magnet)
    if not m:
        return ''
    n = float(m.group(1))
    for unit in ('B', 'KB', 'MB', 'GB'):
        if n < 1024:
            return '%.2f %s' % (n, unit)
        n /= 1024.0
    return '%.2f TB' % n


def _post_rintor_search(query, timeout=12):
    """rintor.net runs DataLife Engine, not WordPress — confirmed live via
    browser that its real search is a POST to / with do=search&
    subaction=search&story=query (a plain GET ?s=query, what this used to
    send, just silently serves the homepage back instead of erroring, so
    the bug was invisible from the addon side: every search "succeeded"
    with an empty result). Posted straight to the canonical non-www host —
    www.rintor.net 301s to rintor.net, and requests' default redirect
    handling downgrades a POST to a bodyless GET on a 301, which would
    reproduce the exact same silent-homepage bug one hop later.

    Explicitly asks for gzip/deflate only (no 'br') — Cloudflare serves
    this response Brotli-encoded whenever the request's Accept-Encoding
    allows it, and decoding that depends on an optional `brotli`/
    `brotlicffi` package that isn't guaranteed to be present in Kodi's
    bundled Python; confirmed live this environment doesn't have it
    either, which silently produced raw compressed garbage where real
    HTML was expected. gzip/deflate are handled natively by
    requests/urllib3 with no extra dependency, and the site accepts it
    fine."""
    data = {'do': 'search', 'subaction': 'search', 'story': query}
    headers = {'Accept-Encoding': 'gzip, deflate'}
    s = _sess()
    if s:
        try:
            r = s.post('https://rintor.net/', data=data, timeout=timeout, headers=headers)
            r.raise_for_status()
            return r.text
        except Exception as e:
            xbmc.log('[Starfleet/Rintor] POST search failed: %s' % e, xbmc.LOGWARNING)
    try:
        import urllib.request as _ur
        import urllib.parse as _up
        req_headers = dict(_BROWSER_HEADERS)
        req_headers.update(headers)
        req = _ur.Request('https://rintor.net/',
                           data=_up.urlencode(data).encode('utf-8'),
                           headers=req_headers)
        with _ur.urlopen(req, timeout=timeout) as resp:
            raw = resp.read()
            if resp.headers.get('Content-Encoding') == 'gzip':
                import gzip as _gz
                raw = _gz.decompress(raw)
            return raw.decode('utf-8', errors='replace')
    except Exception as e:
        xbmc.log('[Starfleet/Rintor] urllib POST fallback failed: %s' % e, xbmc.LOGWARNING)
        return ''


def search_rintor(title, year=None, limit=8, media_type='adult'):
    """Adult torrent search via rintor.net's real search endpoint (see
    _post_rintor_search). Real magnet links sit directly in each result's
    detail page HTML — no Cloudflare, no obfuscation."""
    if media_type != 'adult':
        return []
    try:
        # Same reasoning as search_xxxclub — clean here so a raw search-box
        # query gets the same junk-stripping as a canonical ADE title.
        title = _clean_adult_title(title) or title
        query = re.sub(r'\s+', ' ', title).strip()
        if not query:
            return []
        html = _post_rintor_search(query, timeout=12)
        if not html:
            return []

        seen_urls = set()
        candidates = []
        for m in _RE_RINTOR_RESULT.finditer(html):
            page_url, name = m.group(1), m.group(2).strip()
            if page_url in seen_urls:
                continue
            seen_urls.add(page_url)
            name = name.split('|')[0].strip()
            import html as _html_mod
            name = _html_mod.unescape(name)
            if not name:
                continue
            candidates.append((page_url, name))
            if len(candidates) >= limit * 2:
                break

        if not candidates:
            return []

        def _nc(s):
            return re.sub(r'\s+', ' ', re.sub(r'[^a-z0-9 ]', ' ', s.lower())).strip()

        norm_query = _nc(query)

        def _fetch_magnet(item):
            page_url, name = item
            try:
                dhtml = _get(page_url, timeout=10, cf=True)
                m = _RE_RINTOR_MAGNET.search(dhtml or '')
                if not m:
                    return None
                magnet = m.group(0)
                ih_m = re.search(r'btih:([a-fA-F0-9]{40})', magnet)
                if not ih_m:
                    return None
                return {
                    'title':     name,
                    'magnet':    magnet,
                    'info_hash': ih_m.group(1).lower(),
                    'seeds':     0,
                    'size':      _rintor_human_size(magnet),
                    'source':    'Rintor',
                }
            except Exception:
                return None

        results = []
        from concurrent.futures import ThreadPoolExecutor
        with ThreadPoolExecutor(max_workers=min(8, len(candidates))) as pool:
            for r in pool.map(_fetch_magnet, candidates):
                if not r:
                    continue
                core = _nc(r['title'])
                if norm_query in core or core in norm_query:
                    results.append(r)
                if len(results) >= limit:
                    break
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Rintor] search error: %s' % e, xbmc.LOGWARNING)
        return []


# ── XXXTor (adult torrent tracker — Russian site but content/titles are the
# usual English scene releases, magnets sit directly in the search results
# HTML, no Cloudflare, no per-item detail fetch needed) ──────────────────────

XXXTOR_BASE = 'https://xxxtor.com'

_RE_XXXTOR_MAGNET = re.compile(r'magnet:\?[^"\'<> ]+', re.IGNORECASE)


def search_xxxtor(title, year=None, limit=15, media_type='adult'):
    if media_type != 'adult':
        return []
    try:
        title = _clean_adult_title(title) or title
        query = re.sub(r'\s+', ' ', title).strip()
        if not query:
            return []
        from urllib.parse import quote as _q
        url = '%s/b.php?search=%s&cat=0&page=1' % (XXXTOR_BASE, _q(query))
        html = _get(url, timeout=10)
        if not html:
            return []

        def _nc(s):
            return re.sub(r'\s+', ' ', re.sub(r'[^a-z0-9 ]', ' ', s.lower())).strip()

        norm_query = _nc(query)
        results = []
        for m in _RE_XXXTOR_MAGNET.finditer(html):
            if len(results) >= limit:
                break
            magnet = m.group(0).replace('&amp;', '&')
            ih_m = re.search(r'btih:([a-fA-F0-9]{40})', magnet, re.IGNORECASE)
            dn_m = re.search(r'[&?]dn=([^&"\'<\s]+)', magnet)
            if not ih_m or not dn_m:
                continue
            info_hash = ih_m.group(1).lower()
            import urllib.parse as _up
            name = _up.unquote(dn_m.group(1)).replace('+', ' ').strip()
            if name.lower().endswith('.torrent'):
                name = name[:-len('.torrent')]
            if not name or not _meets_quality(name, media_type):
                continue
            core = _nc(name)
            if norm_query not in core:
                continue
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': info_hash,
                'magnet':    magnet,
                'seeds':     0,
                'size':      '',
                'source':    'XXXTor',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] XXXTor error: %s' % e, xbmc.LOGWARNING)
        return []


# ── FreeJAVTorrent (JAV torrent tracker -- despite the name, its detail pages
# expose neither a magnet nor an info_hash directly. Each one links to
# dl.php?t=<id>, an interstitial ad page whose real "Download Torrent"
# button points at an actual .torrent file on a separate CDN host; this
# downloads that file and bencode-parses it for the info_hash, same
# technique as _torrent_info_hash's other callers.) ──────────────────────────

FREEJAVTORRENT_BASE = 'https://www.freejavtorrent.com'

_RE_FJT_ROW = re.compile(
    r'<div class="image-wrapper"><img src="([^"]*)" alt="([^"]+)">.*?'
    r'<a href="(https://www\.freejavtorrent\.com/[a-z0-9\-]+-(\d+)\.html)" class="overlay"',
    re.IGNORECASE | re.DOTALL
)
_RE_FJT_TORRENT_LINK = re.compile(r"href='(https://j\.freejavtorrent\.com/bt/[^']+\.torrent)'")
_RE_FJT_SIZE = re.compile(r'^\[([\d.]+\s*[A-Za-z]{2,3})\]')


def _fjt_get_bytes(url, timeout=15):
    s = _sess()
    try:
        if s:
            r = s.get(url, timeout=timeout)
            r.raise_for_status()
            return r.content
    except Exception:
        pass
    try:
        import urllib.request as _ur
        req = _ur.Request(url, headers=_BROWSER_HEADERS)
        with _ur.urlopen(req, timeout=timeout) as resp:
            return resp.read()
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] FreeJAVTorrent bytes fetch failed: %s' % e, xbmc.LOGWARNING)
        return b''


def search_freejavtorrent(title, year=None, limit=10, media_type='adult'):
    if media_type != 'adult':
        return []
    try:
        title = _clean_adult_title(title) or title
        query = re.sub(r'\s+', ' ', title).strip()
        if not query:
            return []
        from urllib.parse import quote as _q
        url = '%s/s.php?search=%s' % (FREEJAVTORRENT_BASE, _q(query))
        html = _get(url, timeout=10)
        if not html:
            return []

        def _nc(s):
            return re.sub(r'\s+', ' ', re.sub(r'[^a-z0-9 ]', ' ', s.lower())).strip()

        import html as _html_mod
        norm_query = _nc(query)
        candidates = []
        seen = set()
        for thumb, raw_title, _detail_url, vid in _RE_FJT_ROW.findall(html):
            if vid in seen:
                continue
            seen.add(vid)
            name = _html_mod.unescape(raw_title).strip()
            size_m = _RE_FJT_SIZE.match(name)
            size = size_m.group(1) if size_m else ''
            core_name = _RE_FJT_SIZE.sub('', name).strip()
            if not core_name or norm_query not in _nc(core_name):
                continue
            if not _meets_quality(core_name, media_type):
                continue
            candidates.append((vid, core_name, size))
            if len(candidates) >= limit * 2:
                break
        if not candidates:
            return []

        def _fetch(item):
            vid, name, size = item
            try:
                interstitial = _get('%s/dl.php?t=%s' % (FREEJAVTORRENT_BASE, vid), timeout=10)
                if not interstitial:
                    return None
                m = _RE_FJT_TORRENT_LINK.search(interstitial)
                if not m:
                    return None
                torrent_bytes = _fjt_get_bytes(m.group(1), timeout=15)
                if not torrent_bytes:
                    return None
                info_hash = _torrent_info_hash(torrent_bytes)
                if not info_hash:
                    return None
                return {
                    'title':     name,
                    'year':      '',
                    'quality':   _extract_quality(name),
                    'info_hash': info_hash,
                    'magnet':    _make_magnet(info_hash, name),
                    'seeds':     0,
                    'size':      size,
                    'source':    'FreeJAVTorrent',
                }
            except Exception:
                return None

        results = []
        from concurrent.futures import ThreadPoolExecutor
        with ThreadPoolExecutor(max_workers=min(10, len(candidates))) as pool:
            for r in pool.map(_fetch, candidates):
                if r:
                    results.append(r)
                if len(results) >= limit:
                    break
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] FreeJAVTorrent error: %s' % e, xbmc.LOGWARNING)
        return []


# ── IJAVTorrent (JAV torrent tracker -- real magnets AND real cover art sit
# directly in the search results HTML, no per-item detail fetch needed at
# all. projectjav.com mirrors the exact same backend/content (confirmed
# live: identical info_hashes in the same order), so it's just a fallback
# domain here, not a separate source.) ───────────────────────────────────────

_IJAVTORRENT_MIRRORS = ['https://ijavtorrent.com', 'https://projectjav.com']

_RE_IJAVTORRENT_ROW = re.compile(
    r'data-src="(https://images\.ijavtorrent\.com/data/covers/\d+\.jpg)"[^>]*alt="([^"]+)".*?'
    r'href="(magnet:\?xt=urn:btih:[a-fA-F0-9]{40}[^"]*)"',
    re.IGNORECASE | re.DOTALL
)


def search_ijavtorrent(title, year=None, limit=10, media_type='adult'):
    if media_type != 'adult':
        return []
    try:
        title = _clean_adult_title(title) or title
        query = re.sub(r'\s+', ' ', title).strip()
        if not query:
            return []
        from urllib.parse import quote as _q
        html = ''
        for base in _IJAVTORRENT_MIRRORS:
            html = _get('%s/?s=%s' % (base, _q(query)), timeout=10)
            if html:
                break
        if not html:
            return []

        def _nc(s):
            return re.sub(r'\s+', ' ', re.sub(r'[^a-z0-9 ]', ' ', s.lower())).strip()

        import html as _html_mod
        norm_query = _nc(query)
        results = []
        for _cover, raw_title, raw_magnet in _RE_IJAVTORRENT_ROW.findall(html):
            if len(results) >= limit:
                break
            name = _html_mod.unescape(raw_title).strip()
            if not name or norm_query not in _nc(name):
                continue
            if not _meets_quality(name, media_type):
                continue
            magnet = _html_mod.unescape(raw_magnet).replace('&amp;', '&')
            ih_m = re.search(r'btih:([a-fA-F0-9]{40})', magnet, re.IGNORECASE)
            if not ih_m:
                continue
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih_m.group(1).lower(),
                'magnet':    magnet,
                'seeds':     0,
                'size':      '',
                'source':    'IJAVTorrent',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] IJAVTorrent error: %s' % e, xbmc.LOGWARNING)
        return []


# ── BitPorn (bitporn.eu — private UNIT3D tracker, personal account) ──────────
# Per-user API token (Settings > Personal Sources), never hardcoded — same
# credential-in-Settings convention personal_sources.py already uses for
# MixDrop/Streamtape. Confirmed live 2026-09-07: this UNIT3D instance has
# magnet_link disabled in its own API response (empty string on every result),
# but download_link (a pre-signed .torrent file URL, no further auth needed)
# still works, so the real info_hash is computed the same way
# search_freejavtorrent/_nnm_hash_from_torrent already do elsewhere in this
# file — one extra per-result .torrent fetch, hashed via the shared
# _torrent_info_hash() helper, not re-implemented here.
BITPORN_BASE = 'https://bitporn.eu'


def _bitporn_credentials():
    try:
        addon = _sfhost.addon()
        if addon.getSetting('bitporn_enabled') != 'true':
            return ''
        return (addon.getSetting('bitporn_api_token') or '').strip()
    except Exception:
        return ''


def _bitporn_human_size(n):
    try:
        n = float(n)
    except (TypeError, ValueError):
        return ''
    for unit in ('B', 'KB', 'MB', 'GB'):
        if n < 1024:
            return '%.2f %s' % (n, unit)
        n /= 1024.0
    return '%.2f TB' % n


def search_bitporn(title, year=None, limit=10, media_type='adult'):
    if media_type != 'adult':
        return []
    token = _bitporn_credentials()
    if not token:
        return []
    try:
        title = _clean_adult_title(title) or title
        query = re.sub(r'\s+', ' ', title).strip()
        if not query:
            return []
        r = _req.get(
            BITPORN_BASE + '/api/torrents/filter',
            params={'api_token': token, 'name': query, 'perPage': max(limit * 2, 10)},
            headers=_BROWSER_HEADERS, timeout=12,
        )
        r.raise_for_status()
        data = r.json().get('data') or []
        if not data:
            return []

        candidates = []
        for item in data:
            attrs = item.get('attributes') or {}
            name = attrs.get('name') or ''
            dl = attrs.get('download_link') or ''
            if not name or not dl or not _meets_quality(name, media_type):
                continue
            candidates.append({
                'name': name,
                'dl':   dl,
                'seeds': int(attrs.get('seeders') or 0),
                'size':  _bitporn_human_size(attrs.get('size')),
            })
            if len(candidates) >= limit * 2:
                break
        if not candidates:
            return []

        def _fetch(c):
            try:
                rr = _req.get(c['dl'], headers=_BROWSER_HEADERS, timeout=15)
                rr.raise_for_status()
                info_hash = _torrent_info_hash(rr.content)
                if not info_hash:
                    return None
                tracker = _torrent_own_tracker(rr.content)
                return {
                    'title':     c['name'],
                    'year':      '',
                    'quality':   _extract_quality(c['name']),
                    'info_hash': info_hash,
                    'magnet':    _make_private_magnet(info_hash, c['name'], tracker),
                    'seeds':     c['seeds'],
                    'size':      c['size'],
                    'source':    'BitPorn',
                }
            except Exception:
                return None

        results = []
        from concurrent.futures import ThreadPoolExecutor
        with ThreadPoolExecutor(max_workers=min(10, len(candidates))) as pool:
            for res in pool.map(_fetch, candidates):
                if res:
                    results.append(res)
                if len(results) >= limit:
                    break
        return sorted(results, key=lambda x: x['seeds'], reverse=True)
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] BitPorn error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Podzemlje (podzemlje.net — private UNIT3D tracker, personal account) ─────
# Same UNIT3D API shape as BitPorn above (confirmed live 2026-09-07: identical
# /api/torrents/filter contract, magnet_link also empty on this instance,
# download_link works the same way) — general movies/TV, not adult.
PODZEMLJE_BASE = 'https://podzemlje.net'


def _podzemlje_credentials():
    try:
        addon = _sfhost.addon()
        if addon.getSetting('podzemlje_enabled') != 'true':
            return ''
        return (addon.getSetting('podzemlje_api_token') or '').strip()
    except Exception:
        return ''


def search_podzemlje(title, year=None, limit=10, media_type='movie'):
    if media_type not in ('movie', 'tv'):
        return []
    token = _podzemlje_credentials()
    if not token:
        return []
    try:
        query = title
        if year:
            query = '%s %s' % (title, year)
        r = _req.get(
            PODZEMLJE_BASE + '/api/torrents/filter',
            params={'api_token': token, 'name': query, 'perPage': max(limit * 2, 10)},
            headers=_BROWSER_HEADERS, timeout=12,
        )
        r.raise_for_status()
        data = r.json().get('data') or []
        if not data:
            return []

        candidates = []
        for item in data:
            attrs = item.get('attributes') or {}
            name = attrs.get('name') or ''
            dl = attrs.get('download_link') or ''
            if not name or not dl or not _meets_quality(name, media_type):
                continue
            candidates.append({
                'name': name,
                'dl':   dl,
                'seeds': int(attrs.get('seeders') or 0),
                'size':  _bitporn_human_size(attrs.get('size')),
            })
            if len(candidates) >= limit * 2:
                break
        if not candidates:
            return []

        def _fetch(c):
            try:
                rr = _req.get(c['dl'], headers=_BROWSER_HEADERS, timeout=15)
                rr.raise_for_status()
                info_hash = _torrent_info_hash(rr.content)
                if not info_hash:
                    return None
                tracker = _torrent_own_tracker(rr.content)
                return {
                    'title':     c['name'],
                    'year':      '',
                    'quality':   _extract_quality(c['name']),
                    'info_hash': info_hash,
                    'magnet':    _make_private_magnet(info_hash, c['name'], tracker),
                    'seeds':     c['seeds'],
                    'size':      c['size'],
                    'source':    'Podzemlje',
                }
            except Exception:
                return None

        results = []
        from concurrent.futures import ThreadPoolExecutor
        with ThreadPoolExecutor(max_workers=min(10, len(candidates))) as pool:
            for res in pool.map(_fetch, candidates):
                if res:
                    results.append(res)
                if len(results) >= limit:
                    break
        return sorted(results, key=lambda x: x['seeds'], reverse=True)
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Podzemlje error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Nyaa.si (anime / Japanese media, also has live-action movies) ─────────────

_NYAA_RSS = 'https://nyaa.si/?page=rss&q={q}&c=0_0&f=0'
_RE_NYAA_HASH  = re.compile(r'<nyaa:infoHash>([a-fA-F0-9]{40})</nyaa:infoHash>', re.IGNORECASE)
_RE_NYAA_SEED  = re.compile(r'<nyaa:seeders>(\d+)</nyaa:seeders>', re.IGNORECASE)
_RE_NYAA_SIZE  = re.compile(r'<nyaa:size>([^<]+)</nyaa:size>', re.IGNORECASE)
_RE_NYAA_TITLE = re.compile(r'<title><!\[CDATA\[([^\]]+)\]\]></title>', re.IGNORECASE)
_RE_NYAA_ITEM  = re.compile(r'<item>(.*?)</item>', re.IGNORECASE | re.DOTALL)


def search_nyaa(title, year=None, limit=8, media_type='movie'):
    """Nyaa.si RSS search — best for anime; also indexes live-action J-movies.
    Confirmed live via kodi.log across many real searches (movies, TV,
    anime and non-anime alike): nyaa.si is consistently unreachable from
    this network right now — every single attempt fails at the TCP
    connect stage (ConnectTimeoutError), never even reaching an HTTP
    response, and it's always the last source search_all() waits on,
    adding its full timeout to every single search. A real, live
    connection attempt succeeds or fails well under a second; a 10s
    timeout on something that never once connects is pure dead time
    tacked onto every search this addon does. Cut way down rather than
    removed outright, in case the block is transient and it recovers."""
    try:
        from urllib.parse import quote as _q
        query = title
        if year and media_type not in ('adult',):
            query = '%s %s' % (title, year)
        url = _NYAA_RSS.format(q=_q(query))
        rss = _get(url, timeout=3)
        if not rss:
            return []
        results = []
        for item_m in _RE_NYAA_ITEM.finditer(rss):
            if len(results) >= limit:
                break
            item = item_m.group(1)
            ih_m = _RE_NYAA_HASH.search(item)
            if not ih_m:
                continue
            ih = ih_m.group(1).lower()
            title_m = _RE_NYAA_TITLE.search(item)
            name = title_m.group(1).strip() if title_m else ''
            if not name or not _meets_quality(name, media_type):
                continue
            seeds_m = _RE_NYAA_SEED.search(item)
            seeds = int(seeds_m.group(1)) if seeds_m else 0
            size_m = _RE_NYAA_SIZE.search(item)
            size = size_m.group(1).strip() if size_m else ''
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    _make_magnet(ih, name),
                'seeds':     seeds,
                'size':      size,
                'source':    'Nyaa',
            })
        return sorted(results, key=lambda x: x['seeds'], reverse=True)
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Nyaa error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Sukebei.Nyaa.si (adult/hentai counterpart to Nyaa, same RSS engine) ──────
# Confirmed live: identical RSS shape to nyaa.si itself (same <nyaa:*> tags,
# same c=0_0&f=0 query params), just a separate adult-only index at a
# different subdomain -- so this reuses the exact same _RE_NYAA_* regexes
# nyaa.si's own scraper already has, no new parsing logic needed.

_SUKEBEI_RSS = 'https://sukebei.nyaa.si/?page=rss&q={q}&c=0_0&f=0'
# Unlike nyaa.si's own <title><![CDATA[...]]></title>, sukebei's feed emits a
# plain, HTML-entity-escaped <title> with no CDATA wrapper -- confirmed live
# (real title came back as "...Okarun&#39;s Thing..." with no CDATA at all),
# so this needs its own regex + html.unescape() rather than reusing
# _RE_NYAA_TITLE, which silently matched nothing against this feed's shape.
_RE_SUKEBEI_TITLE = re.compile(r'<title>([^<]+)</title>', re.IGNORECASE)


def search_sukebei_nyaa(title, year=None, limit=10, media_type='adult'):
    if media_type != 'adult':
        return []
    try:
        from urllib.parse import quote as _q
        import html as _html
        rss = _get(_SUKEBEI_RSS.format(q=_q(title)), timeout=6)
        if not rss:
            return []
        results = []
        for item_m in _RE_NYAA_ITEM.finditer(rss):
            if len(results) >= limit:
                break
            item = item_m.group(1)
            ih_m = _RE_NYAA_HASH.search(item)
            if not ih_m:
                continue
            ih = ih_m.group(1).lower()
            title_m = _RE_SUKEBEI_TITLE.search(item)
            name = _html.unescape(title_m.group(1)).strip() if title_m else ''
            if not name:
                continue
            seeds_m = _RE_NYAA_SEED.search(item)
            seeds = int(seeds_m.group(1)) if seeds_m else 0
            size_m = _RE_NYAA_SIZE.search(item)
            size = size_m.group(1).strip() if size_m else ''
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    _make_magnet(ih, name),
                'seeds':     seeds,
                'size':      size,
                'source':    'Sukebei',
            })
        return sorted(results, key=lambda x: x['seeds'], reverse=True)
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Sukebei error: %s' % e, xbmc.LOGWARNING)
        return []


# ── BitDig (btdig.com) — DHT-crawler search engine ───────────────────────────
# Indexes files actually seen live on the DHT swarm, rather than scraping a
# tracker site's own upload database -- different mechanism than every other
# source in this file, so it surfaces torrents pure tracker-scrapers miss.
# No live seeder count is exposed (a DHT crawler doesn't track ongoing swarm
# health, only "last seen" + the file listing), so seeds is always 0 here;
# debrid resolution doesn't need a seed count and search_all()'s final sort
# just places these after sources that do report a real one. Confirmed live:
# relevance can be loose (BM25-style full-text match against files INSIDE a
# torrent, not just its own name), so this leans on search_all()'s own
# title-match filter to drop anything that doesn't actually match.

_RE_BTDIG_NAME   = re.compile(r'class="torrent_name"[^>]*><a[^>]*>([^<]+)</a>', re.IGNORECASE)
_RE_BTDIG_SIZE   = re.compile(r'class="torrent_size"[^>]*>([^<]+)<', re.IGNORECASE)
_RE_BTDIG_MAGNET = re.compile(r'href="(magnet:\?[^"]+)"', re.IGNORECASE)


def search_btdig(title, year=None, limit=8, media_type='movie'):
    try:
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        import urllib.parse as _up
        url = 'https://btdig.com/search?q=%s' % _up.quote(query)
        html_raw = _get(url, timeout=10)
        if not html_raw:
            return []
        import html as _html
        results = []
        for block in html_raw.split('class="one_result"')[1:]:
            if len(results) >= limit:
                break
            name_m = _RE_BTDIG_NAME.search(block)
            size_m = _RE_BTDIG_SIZE.search(block)
            magnet_m = _RE_BTDIG_MAGNET.search(block)
            if not (name_m and magnet_m):
                continue
            ih_m = re.search(r'btih:([a-fA-F0-9]{40})', magnet_m.group(1), re.IGNORECASE)
            if not ih_m:
                continue
            ih = ih_m.group(1).lower()
            name = _html.unescape(name_m.group(1)).strip()
            if not name or not _meets_quality(name, media_type):
                continue
            size = size_m.group(1).replace('\xa0', ' ').strip() if size_m else ''
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    _make_magnet(ih, name),
                'seeds':     0,
                'size':      size,
                'source':    'BitDig',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] BitDig error: %s' % e, xbmc.LOGWARNING)
        return []


# ── AnimeTosho (animetosho.org) — anime-specific, clean JSON API ─────────────
# feed.animetosho.org/json is a documented, keyless JSON search endpoint --
# no scraping needed. Returns its own 'magnet_uri' with a base32 BTIH
# (incompatible with every other source's hex-based info_hash/dedup), but
# also gives a separate plain hex 'info_hash' field directly, so that's used
# instead and a normal magnet is built via _make_magnet() like everywhere
# else in this file.

_ANIMETOSHO_API = 'https://feed.animetosho.org/json?q={q}'


def search_animetosho(title, year=None, limit=8, media_type='movie'):
    if media_type == 'adult':
        return []
    try:
        from urllib.parse import quote as _q
        query = title
        if year:
            query = '%s %s' % (title, year)
        data = _get_json(_ANIMETOSHO_API.format(q=_q(query)), timeout=8)
        if not data:
            return []
        results = []
        for item in data:
            if len(results) >= limit:
                break
            ih = (item.get('info_hash') or '').lower()
            name = item.get('torrent_name') or item.get('title') or ''
            if not ih or not name or not _meets_quality(name, media_type):
                continue
            b = item.get('total_size') or 0
            size = ''
            if b >= 1_073_741_824:
                size = '%.1f GB' % (b / 1_073_741_824)
            elif b >= 1_048_576:
                size = '%.0f MB' % (b / 1_048_576)
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    _make_magnet(ih, name),
                'seeds':     item.get('seeders', 0) or 0,
                'size':      size,
                'source':    'AnimeTosho',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] AnimeTosho error: %s' % e, xbmc.LOGWARNING)
        return []


# ── LimeTorrents (limetorrents.fun + mirrors) ─────────────────────────────────
# .info/.cc/limetor.com confirmed DNS-dead live (getaddrinfo failure, not
# just blocked) — .fun confirmed live and working (once the Accept-Encoding
# fix above stopped Brotli garbage from masquerading as a dead site). Kept
# the old domains in the list rather than deleting them outright in case
# any of them comes back; .fun just goes first so the common case doesn't
# pay for 3 guaranteed-dead DNS lookups every cache cycle.

_LIME_MIRRORS = [
    'https://limetorrents.fun',
    'https://www.limetorrents.info',
    'https://limetorrents.cc',
    'https://limetor.com',
]
_lime_working = {}

_RE_LIME_ROW  = re.compile(
    r'<div[^>]+class="[^"]*tt-name[^"]*"[^>]*>.*?'
    r'<a[^>]+href="([^"]+/torrent/[^"]+)"[^>]*></a>.*?'
    r'<a[^>]+>([^<]+)</a>.*?'
    r'<td[^>]+class="[^"]*tdseed[^"]*"[^>]*>([,\d]+)<',
    re.IGNORECASE | re.DOTALL
)
_RE_LIME_HASH = re.compile(r'/torrent/([a-fA-F0-9]{40})/*', re.IGNORECASE)
_RE_LIME_SIZE = re.compile(r'(\d+(?:\.\d+)?)\s*(KB|GB|MB|GiB|MiB)', re.IGNORECASE)


def _get_lime_base():
    cached = _lime_working.get('url')
    ts     = _lime_working.get('ts', 0)
    if cached and (time.time() - ts) < 3600:
        return cached
    for mirror in _LIME_MIRRORS:
        try:
            html = _get(mirror + '/', timeout=7)
            if html and 'torrent' in html.lower():
                _lime_working['url'] = mirror
                _lime_working['ts']  = time.time()
                return mirror
        except Exception:
            continue
    # Nothing passed the health check this cycle — fall back to whichever
    # mirror is CURRENTLY confirmed live (.fun), not just the list's first
    # entry, which used to be .info (confirmed DNS-dead) and would have
    # guaranteed the actual search request failed too.
    return 'https://limetorrents.fun'


def search_limetorrents(title, year=None, limit=5, media_type='movie'):
    """LimeTorrents — HTML scrape with mirror rotation."""
    try:
        base  = _get_lime_base()
        query = re.sub(r'\s+', '-', title.lower())
        if year and media_type != 'adult':
            query = '%s-%s' % (query, year)
        url  = '%s/search/all/%s/seeds/1/' % (base, query)
        html = _get(url, timeout=10)
        if not html:
            return []
        results = []
        for row_m in _RE_LIME_ROW.finditer(html):
            if len(results) >= limit:
                break
            path, name, seeds = row_m.group(1), row_m.group(2).strip(), row_m.group(3)
            seeds = seeds.replace(',', '')
            if not _meets_quality(name, media_type):
                continue
            # Hash embedded in torrent detail path
            ih_m = _RE_LIME_HASH.search(path)
            if ih_m:
                ih = ih_m.group(1).lower()
            else:
                # Fetch detail page for hash
                try:
                    detail = _get(base + path, timeout=7)
                    ih_m2  = re.search(r'magnet:.*?btih:([a-fA-F0-9]{40})', detail, re.IGNORECASE)
                    ih     = ih_m2.group(1).lower() if ih_m2 else ''
                except Exception:
                    ih = ''
            if not ih:
                continue
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    _make_magnet(ih, name),
                'seeds':     int(seeds),
                'size':      '',
                'source':    'LimeTorrents',
            })
        return sorted(results, key=lambda x: x['seeds'], reverse=True)
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] LimeTorrents error: %s' % e, xbmc.LOGWARNING)
        return []


# ── TorLock (torlock.com) ─────────────────────────────────────────────────────

_TORLOCK_MIRRORS = ['https://www.torlock.com', 'https://www.torlock2.com']
_torlock_working = {}

_RE_TORLOCK_ROW = re.compile(
    # Confirmed live 2026-09-07: TorLock now wraps the year and release-
    # group portions of each title in colored <span> tags (e.g.
    # 'Inception<span style=color:#777> 2010</span> 1080p...<span
    # style=color:#fc9c6d>-GalaxyRG265[TGx]</span>'), so the old bare
    # '[^<]+</a>' capture stopped at the very first '<span' and never
    # matched '</a>' right after it, silently dropping every single row —
    # this returned 0 results for every query regardless of real
    # availability. Also: the <td> immediately after the link used to be
    # seeds, but a date/size <td> pair was inserted before it — seeds now
    # lives in class="tul ..." specifically (leechers in class=tdl right
    # after), not "whichever numeric <td> comes next".
    r'<a class="tl-name" href="/torrent/(\d+)/([^"]+\.html)">(.*?)</a>'
    r'.*?class="tul[^"]*">(\d+)</td>',
    re.IGNORECASE | re.DOTALL
)
_RE_TORLOCK_HASH = re.compile(r'<td[^>]*>([a-fA-F0-9]{40})</td>', re.IGNORECASE)
_RE_TORLOCK_MAG  = re.compile(r'href="(magnet:\?[^"]+)"', re.IGNORECASE)


def _get_torlock_base():
    cached = _torlock_working.get('url')
    ts     = _torlock_working.get('ts', 0)
    if cached and (time.time() - ts) < 3600:
        return cached
    for mirror in _TORLOCK_MIRRORS:
        try:
            html = _get(mirror + '/', timeout=7)
            if html and 'torrent' in html.lower():
                _torlock_working['url'] = mirror
                _torlock_working['ts']  = time.time()
                return mirror
        except Exception:
            continue
    return _TORLOCK_MIRRORS[0]


def search_torlock(title, year=None, limit=5, media_type='movie'):
    """TorLock — HTML scrape."""
    try:
        base  = _get_torlock_base()
        query = re.sub(r'\s+', '-', title.lower())
        if year and media_type != 'adult':
            query = '%s-%s' % (query, year)
        cat_path = 'all'
        if media_type == 'movie':
            cat_path = 'movie'
        elif media_type == 'tv':
            cat_path = 'television'
        url  = '%s/%s/torrents/%s.html?sort=seeds' % (base, cat_path, query)
        html = _get(url, timeout=10)
        if not html:
            return []
        results = []
        for row_m in _RE_TORLOCK_ROW.finditer(html):
            if len(results) >= limit:
                break
            tid, _, raw_name, seeds = (
                row_m.group(1), row_m.group(2),
                row_m.group(3), row_m.group(4)
            )
            # Title text now arrives with inner <span> tags around parts of
            # it (see _RE_TORLOCK_ROW's own comment) — strip them rather
            # than assume plain text.
            name = re.sub(r'<[^>]+>', '', raw_name).strip()
            if not _meets_quality(name, media_type):
                continue
            # Magnet from detail page
            try:
                detail = _get('%s/torrent/%s/x.html' % (base, tid), timeout=8)
                mag_m  = _RE_TORLOCK_MAG.search(detail)
                if not mag_m:
                    ih_m = _RE_TORLOCK_HASH.search(detail)
                    if ih_m:
                        ih     = ih_m.group(1).lower()
                        magnet = _make_magnet(ih, name)
                    else:
                        continue
                else:
                    magnet = mag_m.group(1).replace('&amp;', '&').split('&tr=')[0]
                    ih_m   = re.search(r'btih:([a-fA-F0-9]{40})', magnet, re.IGNORECASE)
                    ih     = ih_m.group(1).lower() if ih_m else ''
            except Exception:
                continue
            if not ih:
                continue
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    magnet,
                'seeds':     int(seeds),
                'size':      '',
                'source':    'TorLock',
            })
        return sorted(results, key=lambda x: x['seeds'], reverse=True)
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] TorLock error: %s' % e, xbmc.LOGWARNING)
        return []


# ── msearch.vercel.app (meta-search — real backend is Algolia, not a REST API
# of its own) ──────────────────────────────────────────────────────────────
#
# Confirmed live 2026-09-04: the msearch.vercel.app frontend has no API
# route of its own at all — this file's previous implementation guessed 3
# plausible-looking Vercel/Next.js REST paths (`/api/search`, `/api/torrents`,
# `/api/search?category=`), none of which ever existed, which is why this
# source has been silently returning 0 results this whole time despite never
# throwing an error. Reading the site's own tiny JS bundle
# (app.e3e6859d.js) shows the real mechanism: it's an Algolia InstantSearch
# widget, `algoliasearch("7OOB1B3OF6", "4c16fab3a20a692c2e63f48830b554e4")`
# against index "stream" — a public, search-only API key (the same kind
# every Algolia-powered site ships client-side on purpose; this is not a
# secret being exposed). Also confirmed live the SAME day: that Algolia
# application id's own DNS entry (7oob1b3of6-dsn.algolia.net) does not
# resolve at all right now — a different, well-known Algolia app
# (bh4d9od16a-dsn.algolia.net, a public DocSearch demo) resolves fine from
# the same network, so this isn't a local DNS/connectivity problem, it's
# specifically this one Algolia application/cluster being gone (deleted,
# suspended, or migrated) even though the static msearch.vercel.app
# frontend is still up and still references it. So this source is
# currently non-functional either way — but calling the REAL endpoint
# (rather than 3 URLs that never existed to begin with) means this comes
# back to life on its own the moment MSearch's Algolia backend does,
# without needing another round of guessing.
_MSEARCH_ALGOLIA_HOST = 'https://7OOB1B3OF6-dsn.algolia.net/1/indexes/stream/query'
_MSEARCH_HEADERS = {
    'X-Algolia-API-Key':         '4c16fab3a20a692c2e63f48830b554e4',
    'X-Algolia-Application-Id':  '7OOB1B3OF6',
    'Content-Type':              'application/json',
}


def search_msearch_torrents(title, year=None, limit=10, media_type='movie'):
    """
    msearch.vercel.app — meta-search aggregator, real backend is Algolia
    (see the comment above this function for how that was found).
    """
    try:
        if not _req:
            return []
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        body = {'params': 'query=%s&hitsPerPage=%d' % (query, max(limit * 2, 10))}
        r = _sess().post(_MSEARCH_ALGOLIA_HOST, json=body, headers=_MSEARCH_HEADERS, timeout=12)
        r.raise_for_status()
        data = r.json()
        items = data.get('hits') or []
        results = []
        for item in items:
            if len(results) >= limit:
                break
            name = (item.get('title') or item.get('name') or '').strip()
            if not name or not _meets_quality(name, media_type):
                continue
            ih = (item.get('infohash') or item.get('info_hash') or
                  item.get('hash') or '').lower()
            magnet = item.get('download') or item.get('magnet') or ''
            if not ih and magnet:
                ih_m = re.search(r'btih:([a-fA-F0-9]{40})', magnet, re.IGNORECASE)
                if ih_m:
                    ih = ih_m.group(1).lower()
            if not ih:
                continue
            if not magnet:
                magnet = _make_magnet(ih, name)
            seeds = int(item.get('seeders') or item.get('seeds') or 0)
            b     = item.get('size') or item.get('bytes') or 0
            size  = ''
            if isinstance(b, int):
                if b >= 1_073_741_824:
                    size = '%.1f GB' % (b / 1_073_741_824)
                elif b >= 1_048_576:
                    size = '%.0f MB' % (b / 1_048_576)
            elif isinstance(b, str):
                size = b
            results.append({
                'title': name, 'year': '', 'quality': _extract_quality(name),
                'info_hash': ih, 'magnet': magnet,
                'seeds': seeds, 'size': size, 'source': 'MSearch',
            })
        return sorted(results, key=lambda x: x['seeds'], reverse=True)
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] MSearch error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Cleanbay (cleanbay.netlify.app — torrent metasearch: piratebay/yts/eztv/
# linuxtracker/libgen/nyaa) ────────────────────────────────────────────────────
#
# The cleanbay.netlify.app frontend is a static React app with no API of
# its own — every search goes straight from the browser to its actual
# backend, testbay.onrender.com (a separate Render-hosted service, found
# by reading the site's own shipped JS bundle for the literal API URL).
# That backend itself live-queries piratebay/yts/eztv/linuxtracker/libgen/
# nyaa per-request (per its own /docs page: "Cleanbay works by searching
# the torrent indexes on-demand... does not store any torrents or
# associated data") and already returns ready-to-use magnet URIs, so no
# per-item resolve step is needed here (unlike DaMagNet elsewhere in this
# file). Confirmed live 2026-09-03: an unfiltered query for a popular
# title ("inception") returned 0 results — piratebay/yts/linuxtracker/eztv
# all appear dead upstream of this backend right now — but the same
# backend still returned 75 real hits with real magnets/seeders for "one
# piece" (served from nyaa, per each hit's own "uploader" field). Left
# unfiltered (no include_sites) anyway rather than hardcoding site:nyaa,
# since that's the one config that keeps surfacing whatever subset of the
# 6 backing sites is alive at request time without needing its own
# separate maintenance as those sites individually rot further. Render's
# free tier sleeps this backend after inactivity — a cold start alone
# took ~10s in testing — so this is given a longer-than-usual timeout; a
# search_all() run that catches it asleep just times out like any other
# slow source rather than erroring.
_CLEANBAY_API = 'https://testbay.onrender.com/api/v1/search'


def search_cleanbay(title, year=None, limit=10, media_type='movie'):
    try:
        if not _req:
            return []
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        payload = {
            'search_term': query,
            'include_categories': [], 'exclude_categories': [],
            'include_sites': [], 'exclude_sites': [],
        }
        r = _sess().post(_CLEANBAY_API, json=payload, timeout=20)
        r.raise_for_status()
        items = (r.json() or {}).get('data') or []
        results = []
        for item in items:
            if len(results) >= limit:
                break
            name = (item.get('name') or '').strip()
            if not name or not _meets_quality(name, media_type):
                continue
            magnet = item.get('magnet') or ''
            ih_m = re.search(r'btih:([a-fA-F0-9]{40})', magnet, re.IGNORECASE)
            if not ih_m:
                continue
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih_m.group(1).lower(),
                'magnet':    magnet,
                'seeds':     int(item.get('seeders') or 0),
                'size':      item.get('size') or '',
                'source':    'Cleanbay',
            })
        return sorted(results, key=lambda x: x['seeds'], reverse=True)
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Cleanbay error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Torrentio (IMDB-based, requires imdb_id) ──────────────────────────────────

TORRENTIO_BASE = 'https://torrentio.strem.fun'

def search_torrentio(imdb_id, season=None, episode=None, limit=250, media_type='movie'):
    """Query Torrentio API by IMDB ID. Returns magnet list sorted by seeds.
    Torrentio itself is a single, cheap JSON call (not per-item HTML scraping
    like the other sources here), so there's no real cost to keeping a much
    larger slice of what it returns. Confirmed live: a 4K release is a much
    bigger file than a 1080p/720p one of the same title, so it almost always
    has fewer seeders — sorting purely by seeds and truncating to a small
    limit (previously 10-20) systematically threw away the 4K options before
    they ever reached the final quality-based sort in metadata_router.py,
    which is exactly why 4K never showed up here despite Torrentio actually
    having it."""
    if not imdb_id:
        return []
    try:
        import urllib.request as _ureq, json as _json
        if season is not None and episode is not None:
            path = '/stream/series/%s:%d:%d.json' % (imdb_id, int(season), int(episode))
        else:
            path = '/stream/movie/%s.json' % imdb_id
        url = TORRENTIO_BASE + path
        req = _ureq.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with _ureq.urlopen(req, timeout=12) as resp:
            data = _json.loads(resp.read().decode('utf-8'))
        results = []
        for stream in data.get('streams', []):
            ih = stream.get('infoHash', '')
            if not ih:
                continue
            raw_title = stream.get('title', '') or ''
            name = raw_title.split('\n')[0].strip()
            # Torrentio itself doesn't filter by quality — without this, CAM/
            # screener/480p-and-below releases (which real seed counts don't
            # otherwise discourage here) landed in the picker right alongside
            # good encodes, the same gap every other scraper in this file
            # already closes via _meets_quality.
            if not _meets_quality(name, media_type):
                continue
            # Parse seeds from title lines (emoji 👤 + number)
            seeds = 0
            for line in raw_title.split('\n')[1:]:
                m = re.search(r'(\d+)', line)
                if m:
                    seeds = int(m.group(1))
                    break
            magnet = _make_magnet(ih, name)
            results.append({
                'title':     name,
                'quality':   _extract_quality(name),
                'info_hash': ih.lower(),
                'magnet':    magnet,
                'seeds':     seeds,
                'size':      0,
                'source':    'Torrentio',
            })
        results.sort(key=lambda x: x['seeds'], reverse=True)
        return results[:limit]
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Torrentio error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Comet (public Stremio-style meta-search, same protocol as Torrentio) ─────

COMET_BASE = 'https://comet.feels.legal'
COMET_MIRRORS = [COMET_BASE, 'https://comet.stremio.ru', 'https://cometfortheweebs.midnightignite.me']
_RE_COMET_SIZE = re.compile(r'💾\s*([\d.,]+\s*(?:GB|GiB|MB|MiB))', re.IGNORECASE)


def search_comet(imdb_id, season=None, episode=None, limit=1000, media_type='movie'):
    """Comet (comet.feels.legal) — a public Stremio meta-search addon
    aggregating many indexers behind the same 'streams' JSON protocol
    Torrentio uses. Confirmed live: 1000+ real streams for a single
    popular movie. imdb_id required, same as Torrentio — this API shape
    has no free-text search."""
    if not imdb_id:
        return []
    try:
        if season is not None and episode is not None:
            path = '/stream/series/%s:%d:%d.json' % (imdb_id, int(season), int(episode))
        else:
            path = '/stream/movie/%s.json' % imdb_id
        data = _json_from_mirrors(COMET_MIRRORS, path, timeout=12)
        if not data:
            return []
        results = []
        for stream in data.get('streams', []):
            ih = (stream.get('infoHash') or '').lower()
            if not ih:
                continue
            desc = stream.get('description') or stream.get('name') or ''
            name = re.sub(r'^[^\w(\[]+', '', desc.split('\n')[0]).strip()
            if not name or not _meets_quality(name, media_type):
                continue
            size_m = _RE_COMET_SIZE.search(desc)
            size = size_m.group(1).strip() if size_m else ''
            results.append({
                'title': name, 'year': '', 'quality': _extract_quality(name),
                'info_hash': ih, 'magnet': _make_magnet(ih, name),
                'seeds': 0, 'size': size, 'source': 'Comet',
            })
        return results[:limit]
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Comet error: %s' % e, xbmc.LOGWARNING)
        return []


# ── StremThru (torz.13377001.xyz-style public torrent index proxy) ──────────

TORZ_BASE = 'https://stremthru.13377001.xyz'
TORZ_MIRRORS = [TORZ_BASE, 'https://stremthru.stremio.ru', 'https://stremthrufortheweebs.midnightignite.me']


def search_torz(imdb_id, season=None, episode=None, limit=1000, media_type='movie'):
    """StremThru (stremthru.13377001.xyz) — a public torrent-index proxy,
    keyed by imdb_id like Torrentio/Comet but with a much cleaner JSON
    shape (no emoji-encoded description parsing needed at all)."""
    if not imdb_id:
        return []
    try:
        if season is not None and episode is not None:
            sid = '%s:%d:%d' % (imdb_id, int(season), int(episode))
        else:
            sid = imdb_id
        data = _json_from_mirrors(TORZ_MIRRORS, '/v0/torrents?sid=%s' % sid, timeout=15)
        if not data:
            return []
        items = (data.get('data') or {}).get('items') or []
        results = []
        for item in items:
            if len(results) >= limit:
                break
            ih = (item.get('hash') or '').lower()
            name = item.get('name') or ''
            if not ih or not name or not _meets_quality(name, media_type):
                continue
            b = item.get('size') or 0
            size = ''
            if b >= 1_073_741_824:
                size = '%.1f GB' % (b / 1_073_741_824)
            elif b >= 1_048_576:
                size = '%.0f MB' % (b / 1_048_576)
            results.append({
                'title': name, 'year': '', 'quality': _extract_quality(name),
                'info_hash': ih, 'magnet': _make_magnet(ih, name),
                'seeds': int(item.get('seeders') or 0), 'size': size, 'source': 'StremThru',
            })
        return sorted(results, key=lambda x: x['seeds'], reverse=True)
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] StremThru error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Peerflix (public Stremio-style addon, same protocol as Torrentio) ───────
# peerflix.mov — a Stremio addon (manifest at /manifest.json) with real
# Spanish+English coverage, confirmed live 2026-09-12. Cleaner JSON shape
# than Torrentio/Comet: seed count and byte size come back as their own
# numeric fields (stream['seed']/stream['sizebytes']), no emoji-text
# parsing needed at all, same as StremThru's shape above.

PEERFLIX_BASE = 'https://peerflix.mov'


def search_peerflix(imdb_id, season=None, episode=None, limit=250, media_type='movie'):
    """Query Peerflix's Stremio-protocol stream endpoint by IMDB ID."""
    if not imdb_id:
        return []
    try:
        if season is not None and episode is not None:
            path = '/stream/series/%s:%d:%d.json' % (imdb_id, int(season), int(episode))
        else:
            path = '/stream/movie/%s.json' % imdb_id
        data = _get_json(PEERFLIX_BASE + path, timeout=12)
        if not data:
            return []
        results = []
        for stream in data.get('streams', []):
            ih = (stream.get('infoHash') or '').lower()
            if not ih:
                continue
            desc = stream.get('description') or stream.get('name') or ''
            name = desc.split('\n')[0].strip()
            if not name or not _meets_quality(name, media_type):
                continue
            b = stream.get('sizebytes') or 0
            size = ''
            if b >= 1_073_741_824:
                size = '%.1f GB' % (b / 1_073_741_824)
            elif b >= 1_048_576:
                size = '%.0f MB' % (b / 1_048_576)
            results.append({
                'title': name, 'year': '', 'quality': _extract_quality(name),
                'info_hash': ih, 'magnet': _make_magnet(ih, name),
                'seeds': int(stream.get('seed') or 0), 'size': size, 'source': 'Peerflix',
            })
        return sorted(results, key=lambda x: x['seeds'], reverse=True)[:limit]
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Peerflix error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Torrent9 (French-language torrents) ──────────────────────────────────────
# Confirmed live 2026-09-13: torrent9.town (the domain a comparable open-
# source Stremio scraper hardcodes as default) is now a thin WordPress
# landing shell with no real search of its own — it points readers at
# "Voir le site complet" -> ww1.fit/torrent9/, which itself is just a
# wrapper page whose real content is an <iframe src="https://www.torrent9.bid">.
# torrent9.bid is the actual live site with real listings/search. Same
# real magnet-per-detail-page shape as TorrentGalaxy/RedeTorrent elsewhere
# in this file.

TORRENT9_BASE = 'https://www1.torrent9.store'

_RE_T9_ROW = re.compile(
    r'<a href="(/detail/\d+)" title="([^"]+)"[^<]*</a></td>\s*'
    r'<td[^>]*>([^<]+)</td>\s*'
    r'<td[^>]*><span class="seed_ok">(\d+)',
    re.IGNORECASE
)


def search_torrent9(title, year=None, limit=10, media_type='movie'):
    """torrent9.bid — French-language torrent index. Search page lists
    candidates with size/seeds inline; each has a real magnet link only on
    its own detail page (same shape as TorrentGalaxy/RedeTorrent above)."""
    if media_type not in ('movie', 'tv'):
        return []
    try:
        from urllib.parse import quote as _q
        import html as _html_mod
        query = re.sub(r'\s+', ' ', title).strip()
        if year and media_type != 'adult':
            query = '%s %s' % (query, year)
        if not query:
            return []

        html = _get('%s/recherche/%s' % (TORRENT9_BASE, _q(query)), timeout=10)
        # Confirmed live: a query with no matches for the exact title+year
        # returns zero table rows rather than an error — retry once
        # without the trailing year (e.g. "The Matrix 1999" -> "The Matrix"),
        # same fallback the comparable open-source scraper this was ported
        # from uses for the identical reason.
        if not html or 'table-striped' not in html:
            year_stripped = re.sub(r'\s+\d{4}$', '', query).strip()
            if year_stripped and year_stripped != query:
                html = _get('%s/recherche/%s' % (TORRENT9_BASE, _q(year_stripped)), timeout=10)
        if not html:
            return []

        candidates = []
        seen_paths = set()
        for path, name, size_text, seeds_text in _RE_T9_ROW.findall(html):
            if len(candidates) >= limit * 2:
                break
            if path in seen_paths:
                continue
            seen_paths.add(path)
            name = _html_mod.unescape(name).strip()
            if not name or not _meets_quality(name, media_type):
                continue
            candidates.append((TORRENT9_BASE + path, name, size_text.strip(), int(seeds_text)))
        if not candidates:
            return []

        def _fetch(item):
            detail_url, name, size_text, seeds = item
            try:
                detail = _get(detail_url, timeout=10)
                if not detail:
                    return None
                mag_m = re.search(r'href="(magnet:[^"]+)"', detail)
                if not mag_m:
                    return None
                magnet = mag_m.group(1)
                ih_m = re.search(r'btih:([a-fA-F0-9]{40})', magnet, re.IGNORECASE)
                if not ih_m:
                    return None
                return {
                    'title':     name,
                    'year':      '',
                    'quality':   _extract_quality(name),
                    'info_hash': ih_m.group(1).lower(),
                    'magnet':    magnet,
                    'seeds':     seeds,
                    'size':      size_text,
                    'source':    'Torrent9',
                }
            except Exception:
                return None

        results = []
        from concurrent.futures import ThreadPoolExecutor
        with ThreadPoolExecutor(max_workers=min(10, len(candidates))) as pool:
            for res in pool.map(_fetch, candidates):
                if res:
                    results.append(res)
                if len(results) >= limit:
                    break
        return sorted(results, key=lambda x: x['seeds'], reverse=True)[:limit]
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Torrent9 error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Bt4g (bt4gprx.com — real-time BitTorrent search engine) ─────────────────
# Per direct follow-up on a comparable open-source Android torrent client's
# own provider list. bt4gprx.com is fronted by a fully-automatic Cloudflare
# Managed Challenge (confirmed live via a real headed Chrome: cf_clearance
# just appears on its own within ~6s of the page loading, no checkbox click
# needed, unlike ext.to's Turnstile checkbox) -- the same "mint the cookie
# on a real PC, auto-refresh it onto GitHub Pages, replay it from the addon
# via plain requests" mechanism already built for ext.to above (see that
# section's own header comment for the fuller "what was tested" history).
# Confirmed live the resulting cf_clearance is good for a full YEAR and,
# unlike ext.to's clearance (scoped separately per path), this one worked
# immediately on both /search and /magnet/<id> detail pages with no second
# challenge. See scraper_bt4g_cookie.py (real headed Chrome, refreshed
# rarely) for the minting side of this.
BT4G_BASE = 'https://bt4gprx.com'
_BT4G_AUTO_COOKIE_URL = 'https://hazmat77.github.io/repository.starfleet/data/bt4g_cookie.json'
_RE_BT4G_TITLE_HREF = re.compile(r'<a title="([^"]*)" href="(/magnet/[^"]+)"')
_RE_BT4G_SIZE = re.compile(r'Total Size:\s*<b class="cpill[^"]*">([^<]+)</b>')
_RE_BT4G_SEEDS = re.compile(r'class="notion-seeders" id="seeders">(\d+)')
_RE_BT4G_HASH = re.compile(r'downloadtorrentfile\.com/hash/([A-Fa-f0-9]{40})', re.IGNORECASE)


def _bt4g_auto_cookie():
    """The scraper-PC-refreshed cf_clearance+UA pair (scraper_bt4g_cookie.py).
    Cached 30 min so ordinary browsing doesn't refetch this on every single
    search. Returns ('', '') on any failure so callers fall back to a
    cookie-less request cleanly (which will just 403/challenge-page, same
    as before this existed) -- matches _extto_auto_cookie()'s convention."""
    ck = 'bt4g_auto_cookie_v1'
    cached = _cache.get(ck)
    if cached is not None:
        return cached
    result = ('', '')
    try:
        r = _req.get(_BT4G_AUTO_COOKIE_URL, timeout=8)
        r.raise_for_status()
        data = r.json()
        cf = (data.get('cf_clearance') or '').strip()
        ua = (data.get('user_agent') or '').strip()
        if cf:
            result = (cf, ua)
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] bt4g auto-cookie fetch error: %s' % e, xbmc.LOGWARNING)
    _cache.set(ck, result, 30 * 60)
    return result


def _bt4g_get(url, timeout=10):
    """GET a bt4gprx.com path using the auto-refreshed cf_clearance cookie
    -- returns None if no cookie is available yet, or the cookie's expired
    (still gets the Managed Challenge page back)."""
    cookie, ua = _bt4g_auto_cookie()
    if not cookie:
        return None
    try:
        s = _sess()
        r = s.get(url, cookies={'cf_clearance': cookie},
                   headers=dict(_BROWSER_HEADERS, **{'User-Agent': ua or _BROWSER_HEADERS['User-Agent']}),
                   timeout=timeout)
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] bt4g request error: %s' % e, xbmc.LOGWARNING)
        return None
    if r.status_code != 200 or 'Just a moment' in r.text[:2000] or 'challenges.cloudflare.com' in r.text[:2000]:
        xbmc.log('[Starfleet/Torrents] bt4g cf_clearance cookie missing/expired', xbmc.LOGWARNING)
        return None
    return r.text


def search_bt4g(title, year=None, limit=30, media_type='movie'):
    """bt4gprx.com search -- see this section's header comment for the
    cf_clearance mechanism. No adult category on this site (its own
    category set is Apps/Books/Movies/Music/Other, confirmed via the
    open-source Android app this was ported from), so movie/tv only, same
    restriction as Torrent9 above."""
    if media_type not in ('movie', 'tv'):
        return []
    try:
        from urllib.parse import quote as _q
        import html as _html_mod
        query = re.sub(r'\s+', ' ', title).strip()
        if year:
            query = '%s %s' % (query, year)
        if not query:
            return []

        html = _bt4g_get('%s/search?q=%s&category=all&orderby=seeders&p=1' %
                          (BT4G_BASE, _q(query)), timeout=10)
        if not html:
            return []

        # Confirmed live: each result is a flat sibling block (title/files/
        # meta divs) with no nested notion-list-item divs inside it, so a
        # plain string split on the wrapper's own class is reliable without
        # needing a real HTML parser (matches this file's existing
        # regex-only convention throughout).
        chunks = html.split('<div class="notion-list-item">')[1:]
        candidates = []
        for chunk in chunks:
            m = _RE_BT4G_TITLE_HREF.search(chunk)
            if not m:
                continue
            name = _html_mod.unescape(m.group(1)).strip()
            path = m.group(2)
            if not name or not _meets_quality(name, media_type):
                continue
            size_m = _RE_BT4G_SIZE.search(chunk)
            seeds_m = _RE_BT4G_SEEDS.search(chunk)
            candidates.append((
                BT4G_BASE + path, name,
                size_m.group(1).strip() if size_m else '',
                int(seeds_m.group(1)) if seeds_m else 0,
            ))
        if not candidates:
            return []

        def _fetch(item):
            detail_url, name, size_text, seeds = item
            try:
                detail = _bt4g_get(detail_url, timeout=10)
                if not detail:
                    return None
                ih_m = _RE_BT4G_HASH.search(detail)
                if not ih_m:
                    return None
                ih = ih_m.group(1).lower()
                return {
                    'title': name, 'year': '', 'quality': _extract_quality(name),
                    'info_hash': ih, 'magnet': _make_magnet(ih, name),
                    'seeds': seeds, 'size': size_text, 'source': 'Bt4g',
                }
            except Exception:
                return None

        # Every candidate from this single (bounded) search page is
        # fetched and only truncated after the final seed-sort -- same 4K-
        # preservation fix just applied to the bot sources that used to sit above: a
        # 4K release is a bigger file than a 1080p one of the same title
        # so it reliably has fewer seeders, and cutting off mid-loop before
        # sorting would silently throw it away.
        results = []
        from concurrent.futures import ThreadPoolExecutor
        with ThreadPoolExecutor(max_workers=min(10, len(candidates))) as pool:
            for res in pool.map(_fetch, candidates):
                if res:
                    results.append(res)
        return sorted(results, key=lambda x: x['seeds'], reverse=True)[:limit]
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Bt4g error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Bitmagnet (public torznab-protocol meta-search, same imdb_id-keyed shape
# as Torrentio/Comet but returns torznab XML instead of the streams-JSON
# protocol) ───────────────────────────────────────────────────────────────────

BITMAGNET_BASE = 'https://bitmagnetfortheweebs.midnightignite.me'


def search_bitmagnet(imdb_id, season=None, episode=None, limit=250, media_type='movie'):
    """Bitmagnet — a public torznab-protocol meta-search addon, keyed by
    imdb_id like Torrentio/Comet/StremThru but speaking the older Newznab/
    torznab XML API shape (item/torznab:attr) instead of a streams JSON
    array."""
    if not imdb_id:
        return []
    try:
        import xml.etree.ElementTree as ET
        if season is not None and episode is not None:
            path = '/torznab/api?t=tvsearch&imdbid=%s&season=%s&ep=%s' % (imdb_id, season, episode)
        else:
            path = '/torznab/api?t=movie&imdbid=%s' % imdb_id
        xml_text = _get(BITMAGNET_BASE + path, timeout=12)
        if not xml_text:
            return []
        root = ET.fromstring(xml_text)
        results = []
        for item in root.iter('item'):
            if len(results) >= limit:
                break
            attr_dict = {}
            title_el = item.find('title')
            if title_el is not None and title_el.text:
                attr_dict['title'] = title_el.text
            for attr in item.findall('{http://torznab.com/schemas/2015/feed}attr'):
                key, val = attr.get('name'), attr.get('value')
                if key:
                    attr_dict[key] = val
            name = attr_dict.get('title') or ''
            ih = (attr_dict.get('infohash') or '').lower()
            if not ih or not name or not _meets_quality(name, media_type):
                continue
            size = ''
            try:
                b = float(attr_dict.get('size') or 0)
                if b >= 1_073_741_824:
                    size = '%.1f GB' % (b / 1_073_741_824)
                elif b >= 1_048_576:
                    size = '%.0f MB' % (b / 1_048_576)
            except Exception:
                pass
            results.append({
                'title': name, 'year': '', 'quality': _extract_quality(name),
                'info_hash': ih, 'magnet': _make_magnet(ih, name),
                'seeds': int(attr_dict.get('seeders') or 0), 'size': size, 'source': 'Bitmagnet',
            })
        return sorted(results, key=lambda x: x['seeds'], reverse=True)
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Bitmagnet error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Zilean (DMM hash-cache proxy, imdb_id-keyed) ─────────────────────────────
# All 5 of Zilean/MediaFusion/Meteor/AIOStreams/TorrentsDB below are public
# meta-search aggregators, not trackers of their own — they re-serve results
# already scraped from the same well-known public sites this file already
# scrapes directly (YTS, EZTV, 1337x, Knaben, LimeTorrents, TPB, RARBG-clones,
# Nyaa, etc. — torrentsdb.py's own upstream docstring lists exactly this set).
# Kept anyway as redundant fallback paths: if one direct scraper gets briefly
# blocked, an aggregator indexing the same site may still surface it.

ZILEAN_BASE = 'https://zileanfortheweebs.midnightignite.me'
ZILEAN_MIRRORS = [ZILEAN_BASE, 'https://zilean.stremio.ru']


def search_zilean(imdb_id, season=None, episode=None, limit=500, media_type='movie'):
    """Zilean — DMM community hash-cache, keyed by imdb_id. Returns a bare
    JSON array (not wrapped in a 'streams' key like the others), with the
    hash/size/raw title already flat on each entry — no description parsing
    needed at all."""
    if not imdb_id:
        return []
    try:
        if season is not None and episode is not None:
            path = '/dmm/filtered?ImdbId=%s&Season=%s&Episode=%s' % (imdb_id, season, episode)
        else:
            path = '/dmm/filtered?ImdbId=%s' % imdb_id
        data = _json_from_mirrors(ZILEAN_MIRRORS, path, timeout=10)
        if not data:
            return []
        results = []
        for f in data:
            if len(results) >= limit:
                break
            ih = (f.get('info_hash') or '').lower()
            name = f.get('raw_title') or ''
            if not ih or not name or not _meets_quality(name, media_type):
                continue
            size = ''
            try:
                b = float(f.get('size') or 0)
                if b >= 1_073_741_824:
                    size = '%.1f GB' % (b / 1_073_741_824)
                elif b >= 1_048_576:
                    size = '%.0f MB' % (b / 1_048_576)
            except Exception:
                pass
            results.append({
                'title': name, 'year': '', 'quality': _extract_quality(name),
                'info_hash': ih, 'magnet': _make_magnet(ih, name),
                'seeds': 0, 'size': size, 'source': 'Zilean',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Zilean error: %s' % e, xbmc.LOGWARNING)
        return []


# ── MediaFusion (imdb_id-keyed, streams-JSON protocol) ───────────────────────

MEDIAFUSION_BASE = 'https://mediafusionfortheweebs.midnightignite.me'
_MEDIAFUSION_TOKEN = (
    'D-h5mpsX35oygOGFiHutl66dLAPiXzjQTODPXKQuKBaQOLjwNBbVkSPi7TJPr0gdykpCFREq8JOh'
    'DHZcvoS_UNZsWpsbjscCAwzgqc9VvP0S3Wt9lz5blcPT8lU6fcHdAHYctp_yde6nWKtSQ1O9Tjeh'
    'GNwajH9TjGZwn6rOybPFmoMpccXfTkB3Xwe9xRhT9O-bKzoYnGnlG8fCDxlNGdzrnlythePc3C7O'
    'phF8b5GyhuSnvBhxD7dTfkI77Dbay8_k_wqS-me9euZQ-oyOJBNTOIsO8HiWQhLGCC8m9rYsqJT6'
    'QF1Xhn-2bNzlukfbSYh_X1kOFdi6Y-YkBeEYokDlQHzzU45qmrj2b1Nz-GALcJHjNDJEMF3h9Eyx'
    '7UcmGWT1qvTpv_tcXjAX37ceqrWH-e_EqwVkvQDjNnmpjOhBWhuUW2R-0KbvxKUn1s5d2jZjLBxC'
    'bMotHIC-G2SrVCLgC_KV0OUainevUHKOKTe0CQmWz1HKV1ju52CFZFZYAWkOAX5cw55qzNnWl_nQ'
    'RnLyngrW_P6aYqghbYyyrAvQ6hCrIbSnVj4GsMFIelcMETvGW4jIXdwZGZA1L8gCzmyCbI9vAqPv'
    'dZxRWb7roc2EnB7gaSYdFtTP9gGoFKKkQ-9aircUEiPXjkP4QWO7lVI4GZri7KKCKjBM7-hWf4nm'
    'ttY7lJS_4Te_H80BeR_qpqeYQ6V0gpVwihARA6cIsZFbWmQXtoYNO16jt1ZqeVztwR6L1IQQnAsH'
    'ANyR5kF7ovGCOnhWlDDxO3nk8fhm3s0k7XewrMisZHy1zNsivTjvJW6KoVwghLn8-QCTf9PEPoPj'
    's6tW5KjciaRvbMg5-mbhpAhYOmPisB4ZyW63vWY6TeU1OBJV0T_fkHtgbvgiTEX5RFoRVDLnhaof'
    '-xHVw2oCc2AdXmBDVROmFjY8x9KEyZ91QfNjHnrTFmGetelcHE'
)
_RE_MF_INFO = re.compile(r'💾.*')
_RE_MF_SEEDS = re.compile(r'👤\s*(\d+)')


def search_mediafusion(imdb_id, season=None, episode=None, limit=250, media_type='movie'):
    if not imdb_id:
        return []
    try:
        if season is not None and episode is not None:
            path = '/%s/stream/series/%s:%s:%s.json' % (_MEDIAFUSION_TOKEN, imdb_id, season, episode)
        else:
            path = '/%s/stream/movie/%s.json' % (_MEDIAFUSION_TOKEN, imdb_id)
        data = _get_json(MEDIAFUSION_BASE + path, timeout=12)
        if not data:
            return []
        results = []
        for stream in data.get('streams', []):
            if len(results) >= limit:
                break
            ih = (stream.get('infoHash') or '').lower()
            if not ih:
                continue
            desc = stream.get('description') or ''
            lines = desc.replace('┈➤', '\n').split('\n')
            name = lines[0].strip() if lines else ''
            if not name or not _meets_quality(name, media_type):
                continue
            info_line = next((l for l in lines if _RE_MF_INFO.search(l)), '')
            seeds_m = _RE_MF_SEEDS.search(info_line)
            seeds = int(seeds_m.group(1)) if seeds_m else 0
            size_m = re.search(r'((?:\d+,\d+\.\d+|\d+\.\d+|\d+,\d+|\d+)\s*(?:GB|GiB|Gb|MB|MiB|Mb))', info_line)
            size = size_m.group(1) if size_m else ''
            results.append({
                'title': name, 'year': '', 'quality': _extract_quality(name),
                'info_hash': ih, 'magnet': _make_magnet(ih, name),
                'seeds': seeds, 'size': size, 'source': 'MediaFusion',
            })
        return sorted(results, key=lambda x: x['seeds'], reverse=True)
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] MediaFusion error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Meteor (imdb_id-keyed, streams-JSON protocol) ────────────────────────────

METEOR_BASE = 'https://meteorfortheweebs.midnightignite.me'
_RE_METEOR_SEEDS = re.compile(r'👥\s*(\d+)')


def search_meteor(imdb_id, season=None, episode=None, limit=250, media_type='movie'):
    if not imdb_id:
        return []
    try:
        if season is not None and episode is not None:
            path = '/stream/series/%s:%s:%s.json' % (imdb_id, season, episode)
        else:
            path = '/stream/movie/%s.json' % imdb_id
        data = _get_json(METEOR_BASE + path, timeout=12)
        if not data:
            return []
        results = []
        for stream in data.get('streams', []):
            if len(results) >= limit:
                break
            ih = (stream.get('infoHash') or '').lower()
            if not ih:
                continue
            desc = stream.get('description') or ''
            lines = desc.split('\n')
            # Confirmed live 2026-09-07: every single result's first line
            # starts with a literal '📄 ' file-icon prefix (e.g. '📄
            # Inception.2010...mkv') that MediaFusion's own description
            # format doesn't carry — left unstripped, it polluted both the
            # displayed title and the magnet's dn= filename.
            name = lines[0].strip().lstrip('📄').strip() if lines else ''
            if not name or not _meets_quality(name, media_type):
                continue
            info_line = next((l for l in lines if _RE_MF_INFO.search(l)), '')
            seeds_m = _RE_METEOR_SEEDS.search(info_line)
            seeds = int(seeds_m.group(1)) if seeds_m else 0
            size_m = re.search(r'((?:\d+,\d+\.\d+|\d+\.\d+|\d+,\d+|\d+)\s*(?:GB|GiB|Gb|MB|MiB|Mb))', info_line)
            size = size_m.group(1) if size_m else ''
            results.append({
                'title': name, 'year': '', 'quality': _extract_quality(name),
                'info_hash': ih, 'magnet': _make_magnet(ih, name),
                'seeds': seeds, 'size': size, 'source': 'Meteor',
            })
        return sorted(results, key=lambda x: x['seeds'], reverse=True)
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Meteor error: %s' % e, xbmc.LOGWARNING)
        return []


# ── TorrentsDB (imdb_id-keyed, aggregates YTS/EZTV/1337x/Knaben/LimeTorrent/
# RARBG/ThePirateBay/KickassTorrents/Nyaa/YggTorrent/Rutracker and more) ──────

TORRENTSDB_BASE = 'https://torrentsdb.com'
_RE_TSDB_SEEDS = re.compile(r'👤\s*(\d+)')


def search_torrentsdb(imdb_id, season=None, episode=None, limit=250, media_type='movie'):
    if not imdb_id:
        return []
    try:
        if season is not None and episode is not None:
            path = '/stream/series/%s:%s:%s.json' % (imdb_id, season, episode)
        else:
            path = '/stream/movie/%s.json' % imdb_id
        data = _get_json(TORRENTSDB_BASE + path, timeout=12)
        if not data:
            return []
        results = []
        for stream in data.get('streams', []):
            if len(results) >= limit:
                break
            ih = (stream.get('infoHash') or '').lower()
            if not ih:
                continue
            title_field = stream.get('title') or ''
            lines = title_field.split('\n')
            name = lines[0].strip() if lines else ''
            if not name or not _meets_quality(name, media_type):
                continue
            info_line = next((l for l in lines if _RE_MF_INFO.match(l)), '')
            seeds_m = _RE_TSDB_SEEDS.search(info_line)
            seeds = int(seeds_m.group(1)) if seeds_m else 0
            size_m = re.search(r'((?:\d+,\d+\.\d+|\d+\.\d+|\d+,\d+|\d+)\s*(?:GB|GiB|Gb|MB|MiB|Mb))', info_line)
            size = size_m.group(1) if size_m else ''
            results.append({
                'title': name, 'year': '', 'quality': _extract_quality(name),
                'info_hash': ih, 'magnet': _make_magnet(ih, name),
                'seeds': seeds, 'size': size, 'source': 'TorrentsDB',
            })
        return sorted(results, key=lambda x: x['seeds'], reverse=True)
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] TorrentsDB error: %s' % e, xbmc.LOGWARNING)
        return []


# ── AIOStreams (imdb_id-keyed; needs a special config header — same public
# community demo config already used by gearsscrapers' own port, not
# anything fabricated here) ──────────────────────────────────────────────────

# Community-hosted instances of the same open-source project -- any one of
# these can go dark or get rate-limited at any time (confirmed live: one
# candidate mirror, aiostreamsfortheweak.cloud, was already unreachable when
# checked), so this tries each in turn instead of hardcoding a single host.
AIOSTREAMS_MIRRORS = [
    'https://aiostreamsfortheweebs.midnightignite.me',
    'https://aiostreamsfortheweebsstable.midnightignite.me',
    'https://aiostreams.stremio.ru',
    'https://aiostreams.viren070.me',
    'https://aiostreams.12312023.xyz',
    'https://aiostreams.fortheweak.cloud',
]
# Config adds seadex + neko-bt presets (2026-08-11) on top of the existing
# bitmagnet-only demo config — both are anime-focused sources with no direct
# Starfleet equivalent (unlike comet/zilean/mediafusion/meteor/torrentsdb/
# knaben/stremthru/tgx/animetosho, which duplicate scrapers already run
# directly elsewhere in this file, so weren't added here). AIOStreams itself
# decides server-side whether a searched title is anime and only queries
# these two when it is — no media_type='anime' path needed on our end, this
# fires transparently through the existing movie/tv search flow.
_AIOSTREAMS_HEADERS = {'x-aiostreams-user-data': (
    'eyJzZXJ2aWNlcyI6IFt7ImlkIjogImFsbGRlYnJpZCIsICJlbmFibGVkIjogdHJ1ZSwgImNyZWRlbnRpYWxzIjogeyJhcGlLZXkiOiAic3RhdGljRGVtb0FwaWtleVByZW0ifX1dLCAicHJlc2V0cyI6IFt7InR5cGUiOiAiYml0bWFnbmV0IiwgImluc3RhbmNlSWQiOiAiM2IzIiwgImVuYWJsZWQiOiB0cnVlLCAib3B0aW9ucyI6IHsibmFtZSI6ICJCaXRtYWduZXQiLCAidGltZW91dCI6IDEwMDAwLCAibWVkaWFUeXBlcyI6IFtdfX0sIHsidHlwZSI6ICJzZWFkZXgiLCAiaW5zdGFuY2VJZCI6ICI0N2IiLCAiZW5hYmxlZCI6IHRydWUsICJvcHRpb25zIjogeyJuYW1lIjogIlNlYURleCIsICJ0aW1lb3V0IjogNzAwMCwgIm1lZGlhVHlwZXMiOiBbImFuaW1lIl19fSwgeyJ0eXBlIjogIm5la28tYnQiLCAiaW5zdGFuY2VJZCI6ICI1NmUiLCAiZW5hYmxlZCI6IHRydWUsICJvcHRpb25zIjogeyJuYW1lIjogIm5la29CVCIsICJ0aW1lb3V0IjogNzAwMCwgIm1lZGlhVHlwZXMiOiBbXSwgInNlYXJjaE1vZGUiOiAiYm90aCIsICJ1c2VNdWx0aXBsZUluc3RhbmNlcyI6IGZhbHNlLCAibGVhdmVBdXRvVGl0bGVUYWdzSW5GaWxlbmFtZSI6IGZhbHNlfX1dLCAiZm9ybWF0dGVyIjogeyJpZCI6ICJ0b3JyZW50aW8iLCAiZGVmaW5pdGlvbiI6IHsibmFtZSI6ICIiLCAiZGVzY3JpcHRpb24iOiAiIn19LCAic29ydENyaXRlcmlhIjogeyJnbG9iYWwiOiBbXX19'
)}


def search_aiostreams(imdb_id, season=None, episode=None, limit=1000, media_type='movie'):
    if not imdb_id:
        return []
    try:
        if season is not None and episode is not None:
            path = '/api/v1/search?type=series&id=%s:%s:%s' % (imdb_id, season, episode)
        else:
            path = '/api/v1/search?type=movie&id=%s' % imdb_id
        s = _sess()
        if not s:
            return []
        data = None
        for base in AIOSTREAMS_MIRRORS:
            try:
                r = s.get(base + path, headers=_AIOSTREAMS_HEADERS, timeout=12)
                r.raise_for_status()
                candidate = r.json()
                if (candidate.get('data') or {}).get('results'):
                    data = candidate
                    break
                if data is None:
                    data = candidate  # keep the first reachable-but-empty response as a fallback
            except Exception:
                continue
        if not data:
            return []
        files = (data.get('data') or {}).get('results') or []
        results = []
        for f in files:
            if len(results) >= limit:
                break
            ih = (f.get('infoHash') or '').lower()
            name = f.get('folderName') or f.get('filename') or ''
            if not ih or not name or not _meets_quality(name, media_type):
                continue
            size = ''
            try:
                b = float(f.get('size') or 0)
                if b >= 1_073_741_824:
                    size = '%.1f GB' % (b / 1_073_741_824)
                elif b >= 1_048_576:
                    size = '%.0f MB' % (b / 1_048_576)
            except Exception:
                pass
            results.append({
                'title': name, 'year': '', 'quality': _extract_quality(name),
                'info_hash': ih, 'magnet': _make_magnet(ih, name),
                'seeds': int(f.get('seeders') or 0), 'size': size, 'source': 'AIOStreams',
            })
        return sorted(results, key=lambda x: x['seeds'], reverse=True)
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] AIOStreams error: %s' % e, xbmc.LOGWARNING)
        return []


# ── DebridMediaManager (movies only — its TV endpoint is season-level only,
# no per-episode granularity, so it doesn't fit this addon's per-episode
# search model the way it fits a season-pack-capable one) ───────────────────

DMM_BASE = 'https://debridmediamanager.com'


def _dmm_challenge():
    """DMM now hands out the pair itself: GET /api/challenge -> {"token", "hash"}; they go back as
    dmmProblemKey / solution (valid for a couple of minutes)."""
    ck = 'dmm_challenge_v1'
    cached = _cache.get(ck) if _HAS_CACHE else None
    if cached:
        return cached[0], cached[1]
    d = _get_json(DMM_BASE + '/api/challenge', timeout=8)
    tok, hsh = (d or {}).get('token'), (d or {}).get('hash')
    if not tok or not hsh:
        raise ValueError('malformed DMM challenge')
    if _HAS_CACHE:
        _cache.set(ck, [tok, hsh], 90)
    return tok, hsh


def _dmm_secret():
    """Reproduces DMM's own client-side proof-of-work challenge — a plain
    computed hash pair, not a real secret (the algorithm and salt are both
    shipped in DMM's own public JS), so this is fully reproducible without
    ever touching a browser."""
    import ctypes, math, random, time as _time

    def calc(t, n, const):
        temp = t ^ n
        t = ctypes.c_long(temp * const).value
        t4 = ctypes.c_long(t << 5).value
        t5 = ctypes.c_long((t & 0xFFFFFFFF) >> 27).value
        return t4 | t5

    def slice_(e, t):
        a = math.floor(len(e) / 2)
        s, n = e[0:a], e[a:]
        i, o = t[0:a], t[a:]
        l = ''.join(s[k] + i[k] for k in range(a))
        return l + (o[::-1] + n[::-1])

    def gen_hash(e):
        t = ctypes.c_long(3735928559 ^ len(e)).value
        a = 1103547991 ^ len(e)
        for ch in e:
            n = ord(ch)
            t = calc(t, n, 2654435761)
            a = calc(a, n, 1597334677)
        t = ctypes.c_long(t + ctypes.c_long(a * 1566083941).value | 0).value
        a = ctypes.c_long(a + ctypes.c_long(t * 2024237689).value | 0).value
        return (ctypes.c_long(t ^ a).value & 0xFFFFFFFF) >> 0

    myhex = '%064x' % random.randrange(10 ** 80)
    e = myhex[:8]
    a = '%s-%d' % (e, int(_time.time()))
    s = hex(gen_hash(a)).replace('0x', '')
    n = hex(gen_hash('debridmediamanager.com%%fe7#td00rA3vHz%VmI-' + e)).replace('0x', '')
    return a, slice_(s, n)


def search_dmm(imdb_id, limit=250, media_type='movie'):
    """DebridMediaManager (debridmediamanager.com) — a public debrid-library
    search service, movie catalog only for this addon's purposes."""
    if not imdb_id or media_type not in ('movie', 'adult'):
        return []
    try:
        try:
            problem_key, solution = _dmm_challenge()
        except Exception:
            problem_key, solution = _dmm_secret()      # the older client-side scheme
        url = '%s/api/torrents/movie?imdbId=%s&dmmProblemKey=%s&solution=%s&onlyTrusted=false&maxSize=0&page=0' % (
            DMM_BASE, imdb_id, problem_key, solution)
        data = _get_json(url, timeout=10)
        if not data:
            return []
        files = data.get('results') or []
        results = []
        for f in files:
            if len(results) >= limit:
                break
            ih = (f.get('hash') or '').lower()
            name = f.get('title') or ''
            if not ih or not name or not _meets_quality(name, media_type):
                continue
            size = ''
            try:
                b = float(f.get('fileSize') or 0) * 1_048_576
                if b >= 1_073_741_824:
                    size = '%.1f GB' % (b / 1_073_741_824)
                elif b:
                    size = '%.0f MB' % (b / 1_048_576)
            except Exception:
                pass
            results.append({
                'title': name, 'year': '', 'quality': _extract_quality(name),
                'info_hash': ih, 'magnet': _make_magnet(ih, name),
                'seeds': 0, 'size': size, 'source': 'DMM',
            })
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] DMM error: %s' % e, xbmc.LOGWARNING)
        return []


# ── TorrentProject2 ───────────────────────────────────────────────────────────

TORRENTPROJECT2_BASE = 'https://torrentproject2.org'
_RE_TP2_LINKS  = re.compile(r'<a\s*href\s*=\s*["\'](.+?torrent\.html)["\']', re.IGNORECASE)
_RE_TP2_HASH   = re.compile(r'<a\s*title\s*=\s*["\']hash:(.+?)\s*torrent', re.IGNORECASE)
_RE_TP2_TITLE  = re.compile(r'<title>(.+?)</title>', re.IGNORECASE)
_RE_TP2_SEEDS  = re.compile(r'["\']tseeders["\']>\s*([0-9,]+)\s*<', re.IGNORECASE)
_RE_TP2_SIZE   = re.compile(r'<div id\s*=\s*["\']torrent-size["\']>(.+?)<', re.IGNORECASE)


def _tp2_get_detail(link, media_type):
    try:
        url = TORRENTPROJECT2_BASE + link
        html = _get(url, timeout=8)
        if not html:
            return None
        hash_m = _RE_TP2_HASH.search(html)
        title_m = _RE_TP2_TITLE.search(html)
        if not hash_m or not title_m:
            return None
        import urllib.parse as _up
        name = _up.unquote_plus(title_m.group(1)).strip()
        if not name or not _meets_quality(name, media_type):
            return None
        seeds_m = _RE_TP2_SEEDS.search(html)
        seeds = int(seeds_m.group(1).replace(',', '')) if seeds_m else 0
        size_m = _RE_TP2_SIZE.search(html)
        size = size_m.group(1).strip() if size_m else ''
        return {
            'title': name, 'year': '', 'quality': _extract_quality(name),
            'info_hash': hash_m.group(1).lower(), 'magnet': _make_magnet(hash_m.group(1).lower(), name),
            'seeds': seeds, 'size': size, 'source': 'TorrentProject2',
        }
    except Exception:
        return None


def search_torrentproject2(title, year=None, limit=5, media_type='movie'):
    """torrentproject2.org — query syntax is one colon-joined path segment
    (same site family/quirk as TheRarBG's), confirmed live no Cloudflare
    wall. Per-candidate detail-page fetch is required for the magnet."""
    try:
        if not _req:
            return []
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        url = '%s/?t=%s&orderby=seeders' % (TORRENTPROJECT2_BASE, _req.utils.quote(query))
        html = _get(url, timeout=10)
        if not html:
            return []
        links = list(dict.fromkeys(_RE_TP2_LINKS.findall(html)))[:limit]
        if not links:
            return []
        from concurrent.futures import ThreadPoolExecutor
        results = []
        with ThreadPoolExecutor(max_workers=min(len(links), 5)) as pool:
            for r in pool.map(lambda l: _tp2_get_detail(l, media_type), links):
                if r:
                    results.append(r)
        return sorted(results, key=lambda x: x['seeds'], reverse=True)
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] TorrentProject2 error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Torrentz2 ─────────────────────────────────────────────────────────────────

TORRENTZ2_BASE = 'https://torrentz2.nz'
_RE_TZ2_ROW    = re.compile(r'href="(/torrent/[a-f0-9]+)"[^>]*>([^<]+)</a>', re.IGNORECASE)
_RE_TZ2_SIZE   = re.compile(r'<span class="s">([^<]+)</span>')
_RE_TZ2_SEEDS  = re.compile(r'<span class="u">(\d+)</span>')
_RE_TZ2_MAGNET = re.compile(r'href="(magnet:[^"]+)"', re.IGNORECASE)
_TORRENTZ2_SERVER_ERR = ('something went wrong', 'Connection timed out', '521: Web server is down', '503 Service Unavailable')


def _tz2_get_magnet(link):
    try:
        html = _get(TORRENTZ2_BASE + link, timeout=8)
        if not html:
            return ''
        m = _RE_TZ2_MAGNET.search(html)
        if not m:
            return ''
        import html as _html_mod
        return _html_mod.unescape(m.group(1))
    except Exception:
        return ''


def search_torrentz2(title, year=None, limit=5, media_type='movie'):
    """torrentz2.nz — search results link out to a /torrent/<id> detail
    page for the (HTML-entity-encoded) magnet, confirmed live 2026-08-04
    that it no longer embeds magnets inline in the listing."""
    try:
        if not _req:
            return []
        query = title
        if year and media_type != 'adult':
            query = '%s %s' % (title, year)
        url = '%s/search?q=%s' % (TORRENTZ2_BASE, _req.utils.quote(query))
        html = _get(url, timeout=10)
        if not html or any(v in html for v in _TORRENTZ2_SERVER_ERR):
            return []

        candidates = []
        for m in _RE_TZ2_ROW.finditer(html):
            if len(candidates) >= limit:
                break
            path, name = m.group(1), m.group(2).strip()
            if not name or not _meets_quality(name, media_type):
                continue
            start = m.end()
            block = html[start:start + 600]
            size_m = _RE_TZ2_SIZE.search(block)
            seeds_m = _RE_TZ2_SEEDS.search(block)
            candidates.append({
                'path': path, 'name': name,
                'size': size_m.group(1).replace('\xa0', ' ').strip() if size_m else '',
                'seeds': int(seeds_m.group(1)) if seeds_m else 0,
            })
        if not candidates:
            return []

        from concurrent.futures import ThreadPoolExecutor
        results = []
        with ThreadPoolExecutor(max_workers=min(len(candidates), 15)) as pool:
            fmap = {pool.submit(_tz2_get_magnet, c['path']): c for c in candidates}
            for fut, c in fmap.items():
                try:
                    magnet = fut.result(timeout=10)
                except Exception:
                    magnet = ''
                if not magnet:
                    continue
                ih_m = re.search(r'btih:([a-fA-F0-9]{40})', magnet, re.IGNORECASE)
                results.append({
                    'title': c['name'], 'year': '', 'quality': _extract_quality(c['name']),
                    'info_hash': ih_m.group(1).lower() if ih_m else '', 'magnet': magnet,
                    'seeds': c['seeds'], 'size': c['size'], 'source': 'Torrentz2',
                })
        return sorted(results, key=lambda x: x['seeds'], reverse=True)
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Torrentz2 error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Kickass2 (KAT mirror network) ────────────────────────────────────────────

_KICKASS2_MIRRORS = [
    'kick4ss.com', 'thekat.info', 'kickasst.net', 'kickasshydra.dev',
    'kickasshydra.net', 'kathydra.com', 'kickasstorrents.id', 'thekat.cc',
    'kkat.net', 'kickasstorrents.bz', 'kkickass.com',
]
_kickass2_working = {}
_RE_KA2_ROW = re.compile(
    r'<tr class="[^"]*" id="torrent_latest_torrents">(.*?)</tr>', re.DOTALL
)


def _get_kickass2_base():
    cached = _kickass2_working.get('url')
    ts = _kickass2_working.get('ts', 0)
    if cached and (time.time() - ts) < 3600:
        return cached
    for mirror in _KICKASS2_MIRRORS:
        try:
            url = 'https://%s' % mirror
            html = _get(url + '/', timeout=7)
            title_m = re.search(r'<title>(.+?)</title>', html or '', re.IGNORECASE)
            if title_m and 'kickass' in title_m.group(1).lower():
                _kickass2_working['url'] = url
                _kickass2_working['ts'] = time.time()
                return url
        except Exception:
            continue
    return 'https://' + _KICKASS2_MIRRORS[0]


def search_kickass2(title, year=None, limit=5, media_type='movie'):
    """Kickass2 (KAT mirror network) — magnets are inline in the listing
    row (URL-encoded behind a click-redirect wrapper, so need unquote_plus
    to reveal the literal 'magnet:' string), no detail-page fetch needed.
    No category:movies/category:tv filter — confirmed live it silently
    zeroes out results for common multi-word titles ("Breaking Bad" +
    any category filter = 0 results, same title alone = plenty), the same
    class of site-side query-relevance quirk already documented for 1337x
    elsewhere in this file. Plain keyword search plus this addon's own
    downstream quality/title filtering covers it instead."""
    try:
        if not _req:
            return []
        base = _get_kickass2_base()
        query = title
        if year and media_type == 'movie':
            query = '%s %s' % (title, year)
        url = '%s/usearch/%s/?field=size&sorder=desc' % (base, _req.utils.quote(query))
        html = _get(url, timeout=10)
        if not html:
            return []
        results = []
        for row_m in _RE_KA2_ROW.finditer(html):
            if len(results) >= limit:
                break
            row = row_m.group(1)
            columns = re.findall(r'<td.*?>(.+?)</td>', row, re.DOTALL)
            if not columns:
                continue
            decoded = _req.utils.unquote(columns[0]).replace('&amp;', '&')
            mag_m = re.search(r'(magnet:.+?)&tr=', decoded, re.IGNORECASE)
            if not mag_m:
                continue
            magnet = mag_m.group(1).replace(' ', '.')
            ih_m = re.search(r'btih:([a-fA-F0-9]{40})', magnet, re.IGNORECASE)
            if not ih_m:
                continue
            dn_m = re.search(r'&dn=([^&]+)', magnet)
            name = _req.utils.unquote(dn_m.group(1)).replace('+', ' ').strip() if dn_m else ''
            if not name or not _meets_quality(name, media_type):
                continue
            seeds = 0
            try:
                seeds = int(re.sub(r'<[^>]+>', '', columns[3]).strip().replace(',', ''))
            except Exception:
                pass
            size = ''
            try:
                size = re.sub(r'<[^>]+>', '', columns[1]).strip()
            except Exception:
                pass
            results.append({
                'title': name, 'year': '', 'quality': _extract_quality(name),
                'info_hash': ih_m.group(1).lower(), 'magnet': magnet.split('&tr=')[0],
                'seeds': seeds, 'size': size, 'source': 'Kickass2',
            })
        return sorted(results, key=lambda x: x['seeds'], reverse=True)
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Kickass2 error: %s' % e, xbmc.LOGWARNING)
        return []


# ── ApacheTorrent / RedeTorrent (Brazilian-Portuguese dubbed catalog) ─────────
# Two differently-branded sites confirmed live to share the exact same
# underlying content pool and per-title detail-page template (identical
# image-CDN paths and even identical info_hash values for the same title —
# e.g. "A Origem 4K" nets the SAME btih on both apachetorrent.com and
# redetorrent.com). Both have a real, genuinely-filtering server-rendered
# search (confirmed live against a nonsense query returning an empty result
# set on redetorrent.com, and a title-specific result set on apachetorrent.com
# distinct from its "no query" homepage) — unlike the four other Spanish-
# language sites investigated the same session (divxtotal.wtf, tomadivx.net,
# esmeraldatorrent.com, naranjatorrent.com) which all turned out to be
# mirrors of one shared DonTorrent-based backend whose search silently
# ignores the query entirely and always returns the same generic "recent
# uploads" listing regardless of what's searched (confirmed live on all four
# via both their top-nav ?sec=buscador param and their sidebar
# /peliculas/buscar POST form) — a dead end, not implemented here.
# elitetorrent.com's search DOES genuinely filter too, but every one of its
# download links (.torrent AND magnet) routes through an acortame-esto.com
# link-shortener wrapping multiply-base64-obfuscated payloads — the exact
# ad-gated-redirect dead end this file's other scrapers avoid — so it's
# skipped as well.
#
# Neither site exposes seed/leech counts anywhere (these are direct-download
# dubbed-movie catalogs, not tracker-style indexes), so seeds is always 0.
# Each listing item needs its own detail-page fetch to get the actual
# magnet (never present in the listing itself), resolved in parallel like
# search_extto/search_therarbg already do.

APACHETORRENT_BASE = 'https://apachetorrents.com'
# redetorrent.com now permanently redirects here — a full site rebuild
# confirmed live 2026-09-11 (old 'capa_lista' listing template and
# ?s=<query> search param both gone). Search moved to a CSRF-token-gated
# ?busca=<query>&token=<token> param (a missing/bogus token silently falls
# back to the generic unfiltered recent-uploads feed instead of erroring,
# so this is a real, easy-to-miss silent-failure trap, not a hard block) —
# the token is single-use-looking (changes on every homepage fetch, no
# session/cookie binding needed) so it's simplest to just fetch a fresh one
# right before each search rather than cache it.
REDETORRENT_BASE = 'https://redestorrents.com'

_RE_APT_ITEM = re.compile(
    r"<h2 class='h6 text-center'><a href='([^']+)'[^>]*>([^<]+?)\s*<br/>\s*\(([^)]*)\)</a></h2>",
    re.IGNORECASE
)
_RE_RT_ITEM = re.compile(
    r'<a href="([^"]+)"\s+class="text-decoration-none cover-link"[^>]*>\s*'
    r'<article class="custom-card"\s+data-title="([^"]*)"\s+data-tipo="([^"]*)"'
    r'\s+data-genero="[^"]*"\s+data-desc="([^"]*)"',
    re.IGNORECASE
)
_RE_RT_TOKEN = re.compile(r'name="token"\s+value="([^"]+)"', re.IGNORECASE)
_RE_BR_MAGNET = re.compile(r'(magnet:\?xt=urn:btih:[a-fA-F0-9]{40}[^"\'<>\s]*)', re.IGNORECASE)
_RE_BR_SIZE   = re.compile(r"<strong>Tamanho</strong>:\s*([^<]+)<", re.IGNORECASE)
# redestorrents.com's new detail-page template ("Tamanho do Arquivo" instead
# of apachetorrent.com's unchanged "Tamanho") — tried as a fallback only, so
# apachetorrent.com's own (still-working) size extraction is untouched.
_RE_BR_SIZE2  = re.compile(r'<small>Tamanho do Arquivo</small>\s*<strong>([^<]+)</strong>', re.IGNORECASE)


def _br_dubbed_detail(url, listing_title, cand_year, media_type, source_name):
    """Shared detail-page fetch for the apachetorrent.com/redetorrent.com
    template — real inline magnet link, no ad-gate/shortener in front of it."""
    try:
        detail = _get(url, timeout=8)
        if not detail:
            return None
        mag_m = _RE_BR_MAGNET.search(detail)
        if not mag_m:
            return None
        magnet = mag_m.group(1).replace('&amp;', '&')
        ih_m = re.search(r'btih:([a-fA-F0-9]{40})', magnet, re.IGNORECASE)
        if not ih_m:
            return None
        dn_m = re.search(r'[?&]dn=([^&]+)', magnet)
        if dn_m:
            import urllib.parse as _up
            name = _up.unquote_plus(dn_m.group(1))
        else:
            name = ''
        name = name or listing_title
        if not _meets_quality(name, media_type):
            return None
        size_m = _RE_BR_SIZE.search(detail) or _RE_BR_SIZE2.search(detail)
        ih = ih_m.group(1).lower()
        return {
            'title':     name,
            'year':      cand_year or '',
            'quality':   _extract_quality(name),
            'info_hash': ih,
            'magnet':    _make_magnet(ih, name),
            'seeds':     0,
            'size':      size_m.group(1).strip() if size_m else '',
            'source':    source_name,
        }
    except Exception:
        return None


def search_apachetorrent(title, year=None, limit=5, media_type='movie'):
    """apachetorrent.com — WordPress-style ?s=<query> search, confirmed live
    to return genuinely title-filtered results (Brazilian-Portuguese titles,
    e.g. "Inception" search surfaces "A Origem")."""
    if media_type not in ('movie', 'tv'):
        return []
    try:
        if not _req:
            return []
        html = _get('%s/?s=%s' % (APACHETORRENT_BASE, _req.utils.quote(title)), timeout=10)
        if not html:
            return []
        candidates = []
        seen_urls = set()
        for m in _RE_APT_ITEM.finditer(html):
            if len(candidates) >= limit:
                break
            url, name, paren = m.group(1), m.group(2).strip(), m.group(3) or ''
            # Confirmed live the same item can appear twice on this site's
            # own results page (a featured/highlighted section duplicating
            # a row also listed below) — dedupe by detail-page URL, the one
            # value guaranteed unique per real item.
            if url in seen_urls:
                continue
            seen_urls.add(url)
            yr_m = re.search(r'(19|20)\d{2}', paren)
            cand_year = yr_m.group(0) if yr_m else ''
            if year and cand_year and str(year) != cand_year:
                continue
            candidates.append((url, name, cand_year))
        if not candidates:
            return []
        from concurrent.futures import ThreadPoolExecutor
        results = []
        seen_hashes = set()
        with ThreadPoolExecutor(max_workers=min(len(candidates), 10)) as pool:
            futs = [pool.submit(_br_dubbed_detail, u, n, y, media_type, 'ApacheTorrent')
                    for u, n, y in candidates]
            for fut in futs:
                try:
                    r = fut.result(timeout=10)
                except Exception:
                    r = None
                # Confirmed live: two different detail-page URLs on this
                # site can embed the identical magnet (info_hash) - the
                # earlier URL-based dedup above catches duplicate listing
                # rows, this catches duplicate CONTENT under different URLs.
                ih = r.get('info_hash', '') if r else ''
                if r and (not ih or ih not in seen_hashes):
                    if ih:
                        seen_hashes.add(ih)
                    results.append(r)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] ApacheTorrent error: %s' % e, xbmc.LOGWARNING)
        return []


def search_redetorrent(title, year=None, limit=5, media_type='movie'):
    """redestorrents.com (formerly redetorrent.com, which now redirects
    here after a full site rebuild — see this file's REDETORRENT_BASE
    comment) — same dubbed-catalog content pool as ApacheTorrent above (see
    this section's header comment) but with a richer listing that also
    carries a category badge (Filmes/Séries), used here to skip fetching
    detail pages for the wrong media_type outright. Search is
    index.php?busca=<query>&token=<token> (a fresh token fetched from the
    homepage right before searching) — confirmed live to genuinely filter;
    a missing/stale token silently returns the generic unfiltered feed
    instead of erroring, so the token fetch is not optional. The token is
    also bound to the PHPSESSID cookie the homepage response sets — a
    stateless second GET (no shared cookie jar) gets silently redirected
    back to the homepage even with a freshly-fetched, otherwise-valid
    token, confirmed live — so the homepage fetch and the search must
    share one requests.Session."""
    if media_type not in ('movie', 'tv'):
        return []
    try:
        if not _req:
            return []
        sess = _req.Session()
        sess.headers.update(_BROWSER_HEADERS)
        home_resp = sess.get('%s/' % REDETORRENT_BASE, timeout=10)
        tok_m = _RE_RT_TOKEN.search(home_resp.text or '')
        if not tok_m:
            return []
        url = '%s/index.php?busca=%s&token=%s&hp_bot_check=' % (
            REDETORRENT_BASE, _req.utils.quote(title), tok_m.group(1))
        html = sess.get(url, timeout=10).text
        if not html:
            return []
        candidates = []
        seen_urls = set()
        for m in _RE_RT_ITEM.finditer(html):
            if len(candidates) >= limit:
                break
            url, name, category, desc = m.groups()
            # Same duplicate-listing quirk as ApacheTorrent (shared template) —
            # dedupe by detail-page URL.
            if url in seen_urls:
                continue
            seen_urls.add(url)
            is_tv = 'rie' in (category or '').strip().lower()  # "Séries"/"Series"
            if is_tv != (media_type == 'tv'):
                continue
            yr_m = re.search(r'\((19|20)\d{2}\)', desc or '')
            cand_year = yr_m.group(0).strip('()') if yr_m else ''
            if year and cand_year and str(year) != cand_year:
                continue
            name = (name or '').strip()
            candidates.append((url, name, cand_year))
        if not candidates:
            return []
        from concurrent.futures import ThreadPoolExecutor
        results = []
        seen_hashes = set()
        with ThreadPoolExecutor(max_workers=min(len(candidates), 10)) as pool:
            futs = [pool.submit(_br_dubbed_detail, u, n, y, media_type, 'RedeTorrent')
                    for u, n, y in candidates]
            for fut in futs:
                try:
                    r = fut.result(timeout=10)
                except Exception:
                    r = None
                # Same duplicate-content-under-different-URLs quirk as
                # ApacheTorrent (shared template) - dedupe by info_hash.
                ih = r.get('info_hash', '') if r else ''
                if r and (not ih or ih not in seen_hashes):
                    if ih:
                        seen_hashes.add(ih)
                    results.append(r)
        return results
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] RedeTorrent error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Torseek (torseek.org) ──────────────────────────────────────────────────
# Next.js 15 App-Router site, fully client-rendered (its own RSC payload for
# /search confirmed live to carry no server-fetched torrent data at all).
# There's no REST search endpoint — the compiled page JS instead calls
# createServerReference("<40-hex id>", ..., "search"), which is Next.js'
# React Server Actions machinery: at runtime that becomes a POST to the
# CURRENT page URL carrying a `Next-Action: <id>` header, with the call's
# arguments JSON-encoded as the raw body (`[query, page]`). Confirmed live
# this is reproducible with a plain POST + those two headers, no browser/JS
# execution needed at all — and the backend is itself a Jackett meta-search
# aggregator (each hit's `jackettindexer` field names the real underlying
# indexer, e.g. TheRarBG/The Pirate Bay), returning genuine magnets with
# real btih hashes, human release names and live seeder counts.
# CAVEAT: that action id is Next.js build output tied to this one specific
# deployment — it WILL silently change whenever Torseek redeploys, at which
# point this scraper degrades to routine POST failures (caught below,
# returns [] like any other dead source) until the id is refreshed by hand.
TORSEEK_BASE = 'https://www.torseek.org'
TORSEEK_SEARCH_ACTION = '60024254f6afa5cc0a7878404013b88cf799b21f57'
_RE_TORSEEK_HASH = re.compile(r'btih:([a-fA-F0-9]{40})', re.IGNORECASE)


def search_torseek(title, year=None, limit=5, media_type='movie'):
    try:
        if not _req:
            return []
        s = _sess()
        if not s:
            return []
        query = title
        if year and media_type == 'movie':
            query = '%s %s' % (title, year)
        url = '%s/search?q=%s' % (TORSEEK_BASE, _req.utils.quote(query))
        import json as _json
        body = _json.dumps([query, 1])
        headers = {
            'Accept':       'text/x-component',
            'Next-Action':  TORSEEK_SEARCH_ACTION,
            'Content-Type': 'text/plain;charset=UTF-8',
            'Origin':       TORSEEK_BASE,
            'Referer':      url,
        }
        r = s.post(url, data=body.encode('utf-8'), headers=headers, timeout=12)
        r.raise_for_status()
        data = None
        for line in r.text.split('\n'):
            if line.startswith('1:') and not line.startswith('1:E'):
                try:
                    data = _json.loads(line[2:])
                except Exception:
                    data = None
                break
        if not data or not isinstance(data, dict):
            return []
        results = []
        for item in data.get('results', []):
            if len(results) >= limit:
                break
            magnet = item.get('magnetLink') or item.get('guid') or ''
            ih_m = _RE_TORSEEK_HASH.search(magnet)
            if not ih_m:
                continue
            name = item.get('title', '')
            if not name or not _meets_quality(name, media_type):
                continue
            try:
                seeds = int(item.get('seeders') or 0)
            except Exception:
                seeds = 0
            size = ''
            try:
                b = int(item.get('size') or 0)
                if b >= 1_073_741_824:
                    size = '%.1f GB' % (b / 1_073_741_824)
                elif b >= 1_048_576:
                    size = '%.0f MB' % (b / 1_048_576)
            except Exception:
                pass
            ih = ih_m.group(1).lower()
            results.append({
                'title':     name,
                'year':      '',
                'quality':   _extract_quality(name),
                'info_hash': ih,
                'magnet':    _make_magnet(ih, name),
                'seeds':     seeds,
                'size':      size,
                'source':    'Torseek',
            })
        return sorted(results, key=lambda x: x['seeds'], reverse=True)
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] Torseek error: %s' % e, xbmc.LOGWARNING)
        return []


# ── Unified search ────────────────────────────────────────────────────────────

_SITE_TLDS = frozenset(('com', 'net', 'org', 'cc', 'to', 'me', 'tv', 'io', 'xyz', 'vip', 'club', 'info', 'haus', 'site', 'top', 'ru', 'cn'))


def _title_prefix_ok(words, skip_words):
    """What may sit in front of the title in a release name: filler words, a year, a title in another script (Chinese,
    Russian, ...), or a site / group tag ("47BT", "www.site.com"). Other English words in front mean another title
    ("Hans Zimmer - Inception")."""
    for i, w in enumerate(words):
        if w in skip_words or len(w) <= 2:
            continue
        if not w.isascii():
            continue
        if re.fullmatch(r'(?:19|20)\d{2}', w) or re.fullmatch(r'\d{1,3}[a-z]{1,4}', w):
            continue
        if w in ('www', 'http', 'https') or w in _SITE_TLDS:
            continue
        if i and words[i - 1] == 'www':
            continue
        if i + 1 < len(words) and words[i + 1] in _SITE_TLDS:
            continue
        return False
    return True


# ── fake releases ─────────────────────────────────────────────────────────────
# Before an episode exists, sites list "releases" for it that are not video at all: names ending in .exe / .7z / .iso (some are even
# reported as cached by debrid services), and season packs of the WRONG season ("Show S01 complete" offered for S02E04).
_NONVIDEO_NAME = re.compile(r'\.(?:exe|msi|bat|cmd|scr|lnk|jar|vbs|ps1|apk|dmg|7z|zip|rar|iso|pdf|txt|nfo|torrent|html?)\s*$', re.I)
_RE_SEASON_RANGE = re.compile(r'(?<![A-Za-z0-9])(?:S|Seasons?[ ._]*)(\d{1,2})[ ._]*(?:-|\u2013|to)[ ._]*(?:S|Seasons?[ ._]*)?(\d{1,2})(?![A-Za-z0-9])', re.I)
_RE_SEASON_ONE = re.compile(r'(?<![A-Za-z0-9])(?:S|Seasons?[ ._]*)(\d{1,2})(?![A-Za-z0-9])(?!E\d)', re.I)


def _seasons_named(name):
    """The seasons a release name says it holds ({1} for 'Show S01 ...', {1,2,3} for 'S01-S03'); an empty set when it names none."""
    seen = set()
    for a, b in _RE_SEASON_RANGE.findall(name):
        a, b = int(a), int(b)
        if 0 < a <= b <= 60:
            seen.update(range(a, b + 1))
    for m in _RE_SEASON_ONE.findall(name):
        seen.add(int(m))
    return seen


def drop_fake_releases(results, media_type='movie', season=None, key='title'):
    """Remove releases that cannot be the thing asked for: names ending in a non-video extension and (for a TV request) releases that
    name only OTHER seasons. Releases that name no season at all (complete-series packs...) stay."""
    out = []
    for r in results:
        name = (r.get(key) or r.get('title') or r.get('name') or '') if isinstance(r, dict) else str(r)
        if _NONVIDEO_NAME.search(name):
            continue
        if media_type == 'tv' and season:
            named = _seasons_named(name)
            if named and int(season) not in named and not re.search(r'complete[ ._]*series|all[ ._]*seasons', name, re.I):
                continue
        out.append(r)
    if len(out) != len(results):
        xbmc.log('[Starfleet/Torrents] dropped %d fake / wrong-season release(s) of %d' % (len(results) - len(out), len(results)),
                 xbmc.LOGINFO)
    return out


def filter_by_title_and_episode(results, title, media_type='movie', season=None, episode=None, key='title', log_tag='Torrents'):
    """The shared title / episode precision filter (see _filter_by_title_and_episode), then the fake-release check."""
    kept = _filter_by_title_and_episode(results, title, media_type, season=season, episode=episode, key=key, log_tag=log_tag)
    try:
        return drop_fake_releases(kept, media_type, season, key)
    except Exception:
        return kept


def _filter_by_title_and_episode(results, title, media_type='movie', season=None,
                                 episode=None, key='title', log_tag='Torrents'):
    """Shared title/episode precision filter, extracted out of search_all()
    so non-torrent sources (NZB/Usenet) can apply the exact same strictness
    instead of shipping unfiltered. Confirmed live this was a real, visible
    bug for NZB: searching "Found S01E03" returned "Virgin River S01E03",
    "Happy Tree Friends S01E03", "Eyes of Wakanda S01E03" etc mixed in
    alongside real "Found" results, because Binsearch's own search is a
    loose multi-word match (any post containing similar terms/markers, not
    an exact title match) and nzb_sources.py never filtered its output the
    way every torrent source here already does via this same code.

    See search_all()'s original inline version of this same logic (still
    the copy of record for *why* each individual regex/skip-word/episode
    exists) — this is a straight extraction, not a rewrite, so both callers
    behave identically to how torrents always have.
    """
    # Filter out false matches where the show/movie name doesn't appear as
    # whole words in the result's own title. Prevents e.g. "Farmhouse Rules
    # S04E10" matching search "FROM S04E10" because "from" appears as a
    # substring inside "farmhouse".
    if title:
        _skip_words = {'a', 'an', 'the', 'of', 'in', 'on', 'at', 'to', 'for', 'or', 'and'}
        # Trim leading/trailing filler words only — an interior one (e.g.
        # "Day OF the Dead") stays, so it can still act as flexible filler
        # between two real words below rather than being silently dropped.
        _raw_words = [w.lower() for w in re.split(r'\W+', title) if w]
        while _raw_words and _raw_words[0] in _skip_words:
            _raw_words.pop(0)
        while _raw_words and _raw_words[-1] in _skip_words:
            _raw_words.pop()
        # A trailing sequel/episode number ("Anal Players 9", "Moana 2") is
        # exactly the part that disambiguates one title from another, but
        # `len(w) >= 2` was silently dropping every single-digit number from
        # _search_words entirely. Numeric tokens are now kept regardless of
        # length.
        _search_words = [w for w in _raw_words if len(w) >= 2 or w.isdigit()]
        if _search_words:
            # Bag-of-words matching (each query word present ANYWHERE, any
            # order) let through real false positives. Fix: require the
            # query's words to appear as one contiguous phrase, in the same
            # order, with only optional filler (whitespace/punctuation, a
            # skip-word, or a bare release year) between them.
            _skip_alt = '|'.join(sorted(_skip_words))
            _region_alt = 'us|uk|au|ca|nz|ie'
            # \w{1,2} tolerates a bare short leftover word between two real
            # search words too, not just before the first one (the prefix
            # check a few lines below already does this via len(w) <= 2).
            # Real bug fixed 2026-09-05, found via the same investigation
            # as the prefix fix: a title like "Ocean's Eleven" splits into
            # 'ocean'/'s'/'eleven', 's' gets dropped from _search_words
            # (too short), leaving the phrase regex needing "ocean" then
            # "eleven" adjacent — but the real candidate text still has a
            # genuine, un-droppable "s" sitting between them ("ocean s
            # eleven" once apostrophes normalize to spaces), which nothing
            # in the old separator pattern could ever skip over since "s"
            # is neither a skip-word, a region code, nor a year.
            _sep = r'[\W_]+(?:(?:(?:' + _skip_alt + r')|(?:' + _region_alt + r')|(?:19|20)\d{2}|\w{1,2})[\W_]+)*'
            _parts = []
            for w in _search_words:
                if w.isdigit():
                    _parts.append('0*' + re.escape(w))
                else:
                    _parts.append(re.escape(w))
            # Trailing \b is dropped for adult searches only. Real bug
            # confirmed live 2026-09-08: adult studios routinely glue a
            # sub-brand suffix directly onto the studio name with no
            # separator at all (e.g. real NZB hits titled
            # "BrazzersExxtra.26.06.30...") — a query for "Brazzers" has
            # no word-char/non-word-char transition right after it in
            # "brazzersexxtra" (s->E is word-char to word-char), so the
            # strict trailing \b that's correct for movie/TV titles
            # rejected 100% of real, genuinely-matching results (21 raw
            # hits across binsearch/nzbindex/nzbking, 0 survived). The
            # leading \b is untouched — "wife" still can't match inside
            # "housewife" — this only stops requiring a hard stop at the
            # END of the query phrase for adult media_type.
            _trailing = r'\b' if media_type != 'adult' else ''
            _PHRASE_RE = re.compile(r'\b' + _sep.join(_parts) + _trailing, re.IGNORECASE)

            def _title_matches(name_in):
                name = name_in.lower()
                # Strip embedded dates before punctuation gets flattened to
                # spaces below — otherwise a date's day/month component
                # becomes a free-floating number that can spuriously
                # satisfy a numeric query word.
                name = re.sub(r'\b\d{1,2}[.\-/]\d{1,2}[.\-/]\d{2,4}\b', ' ', name)
                name = re.sub(r'\b\d{2,4}[.\-/]\d{1,2}[.\-/]\d{1,2}\b', ' ', name)
                name = re.sub(_RE_MONTH_DAY_YEAR, ' ', name)
                name = re.sub(_RE_DAY_MONTH, ' ', name)
                name = re.sub(_RE_NUM_DATE_SPACED, ' ', name)
                # Strip leading release-group/language/quality bracket tags
                # before the position check below.
                name = re.sub(r'^(?:[\[(][^\])]*[\])][\s._\-]*)+', '', name)
                # Also strip wrapping quote characters (straight AND curly/
                # smart) to spaces, same as every other punctuation char
                # here — NZB titles are new to this filter (torrent titles
                # never carried them) and Binsearch wraps its own raw title
                # text in quotes. Confirmed live this was a real 100%-
                # rejection bug: a leading quote glued directly onto the
                # first word (e.g. '"the odyssey...') makes that word its
                # own un-skippable token ('"the' != 'the'), so the
                # prefix-word check below rejected EVERY single NZB
                # candidate regardless of content the moment this filter
                # started running against them.
                # Real bug fixed 2026-09-05, found alongside the prefix-
                # tolerance one above: this list stripped curly quotes but
                # never the plain straight apostrophe (') — the character
                # real torrent filenames actually use (curly quotes are
                # essentially never seen in plain ASCII release names).
                # "la's" therefore never split into "la"/"s" here even
                # though the query side already treats apostrophe as a
                # separator (re.split(r'\W+', title) a few lines up), so a
                # title like "LA's Finest" left "la's" glued into one
                # 4-char prefix token that failed the <=2-char tolerance
                # above for a reason that had nothing to do with it really
                # being unrelated text.
                norm = re.sub(r"[._\-\[\]()+'\"“”‘’]", ' ', name)
                norm = re.sub(r'\s+', ' ', norm).strip()
                m = _PHRASE_RE.search(norm)
                if not m:
                    return False
                # The query's phrase must start the (cleaned) title, not
                # sit after another real word — allow anything before the
                # match IF it's made up entirely of the same skip-words
                # already trimmed from our own query, OR short (<=2 char)
                # tokens. Real bug fixed 2026-09-05: an abbreviation like
                # "L.A.'s Finest" splits into 'l'/'a'/'s'/'finest' by the
                # same \W+ split used to build _search_words above, but
                # _search_words itself then drops every one of those
                # single-character tokens (the len(w) >= 2 filter a few
                # lines up) — so the actual phrase regex only ever looks
                # for "finest" alone. A real candidate's own normalized
                # title has those exact letters sitting right before the
                # match ("l a s finest s01e01..."), and none of 'l'/'a'/'s'
                # were themselves skip-words, so this check rejected every
                # single real candidate for this title — confirmed live,
                # 143 raw hits across 9 sources, 0 survived. <=2 chars
                # (not just 1) because a release can just as easily write
                # the same abbreviation as one merged 2-letter token
                # ("LA's Finest" -> 'la'/'s'/'finest') instead of splitting
                # on the period the query happened to use ("L.A.'s Finest"
                # -> 'l'/'a'/'s'/'finest') — confirmed live both spellings
                # exist for this exact show. Real words this could
                # wrongly tolerate as filler (to/of/is/on/at/an/by/or/us/
                # no/go/so/if/as/up/we) are already a subset of ordinary
                # filler in a title anyway, so this doesn't meaningfully
                # loosen what "false match" means in practice.
                prefix_words = norm[:m.start()].split()
                return _title_prefix_ok(prefix_words, _skip_words)
            before = len(results)
            results = [r for r in results if _title_matches(r.get(key, ''))]
            filtered = before - len(results)
            if filtered:
                xbmc.log('[Starfleet/%s] Title filter removed %d false matches' % (log_tag, filtered), xbmc.LOGINFO)

    # For a specific TV episode, the title-word filter above only confirms
    # the show name matches — it says nothing about WHICH episode. A
    # release with NO single-episode marker (season pack, "S01-S05",
    # "COMPLETE", etc.) is assumed to legitimately contain the target
    # episode and kept; one WITH a marker must match.
    if media_type == 'tv' and season is not None and episode is not None:
        _target_s, _target_e = int(season), int(episode)
        _RE_EP_MARKER = re.compile(r's0*(\d{1,2})[\s._-]*e0*(\d{1,3})(?!\d)', re.IGNORECASE)

        def _episode_ok(name_in):
            markers = _RE_EP_MARKER.findall(name_in)
            if not markers:
                return True
            return any(int(s) == _target_s and int(e) == _target_e for s, e in markers)

        before_ep = len(results)
        results = [r for r in results if _episode_ok(r.get(key, ''))]
        filtered_ep = before_ep - len(results)
        if filtered_ep:
            xbmc.log('[Starfleet/%s] Episode filter removed %d wrong-episode matches' % (log_tag, filtered_ep), xbmc.LOGINFO)

    return results


# Every individually-toggleable torrent source's settings.xml key suffix
# (Settings > Torrent Sources — each is its own "src_<key>" bool setting).
# Used only to build a stable cache-key signature reflecting exactly which
# sources are currently enabled, so a settings change never serves a
# stale cached result built under a different on/off mix — see
# search_all()'s own cache-key construction below.
_ALL_SOURCE_KEYS = (
    'external',
    'torrentio', 'comet', 'stremthru', 'peerflix', 'torrent9', 'bitmagnet', 'zilean', 'mediafusion',
    'meteor', 'torrentsdb', 'aiostreams', 'dmm', 'knaben', 'tpb', 'yts',
    'eztv', '1337x',
    'bitsearch', 'torrentdl', 'limetorrents', 'magnetdl', 'bittorrented',
    'msearch', 'tgx', 'zooqle', 'nyaa', 'extto', 'therarbg',
    'torrentproject2', 'torrentz2', 'kickass2', 'kontrast', 'torrentfunk',
    'torlock', 'torrentscsv', 'torrentkitty', 'btdig', 'animetosho', 'tordl', 'rutor',
    'nnmclub', 'snowfl', 'yourbittorrent', 'apachetorrent', 'redetorrent',
    'torseek', 'filemood', 'publicdomaintorrents',
    'cleanbay', 'damag', 'rarbgdump', 'demonoid', 'bt4g',
)


# ── Resolution limits (Settings > Torrent Sources): a viewer with a 1080p or 720p TV has no use for 4K releases ──────────

_RES_RANK = {'8K': 4, '4K': 3, '1080p': 2, '720p': 1, 'SD': 0}


def allow_8k():
    """True when the device can play 8K (the app detects its decoders and sets device_8k). Without it 8K releases are left out:
    a 4K player cannot decode them."""
    try:
        return _sfhost.addon().getSetting('device_8k') == 'true'
    except Exception:
        return False


def quality_limits():
    """(lowest, highest) resolution rank to keep: 0 SD, 1 720p, 2 1080p, 3 4K, 4 8K (only on a device that plays it). Defaults keep everything."""
    top = 4 if allow_8k() else 3
    try:
        addon = _sfhost.addon()
        lo = {'0': 0, '1': 1, '2': 2, '3': 3}.get(addon.getSetting('scrape_quality_min') or '0', 0)
        hi = {'0': top, '1': 2, '2': 1, '3': 0}.get(addon.getSetting('scrape_quality_max') or '0', top)
    except Exception:
        return 0, top
    return min(lo, hi), hi


def _result_rank(r):
    """Resolution rank of a result, or None when the release does not say."""
    q = (r.get('quality') or '').strip()
    if q in _RES_RANK:
        return _RES_RANK[q]
    t = _extract_quality((r.get('title') or '') + ' ' + q)
    if t in _RES_RANK:
        return _RES_RANK[t]
    low = ((r.get('title') or '') + ' ' + q).lower()
    if any(x in low for x in ('480', '576', 'dvdrip', 'dvd', 'xvid')):
        return 0
    return None


def apply_quality_limits(results):
    """Drop results outside the viewer's resolution range. A release that does not state its resolution stays unless the
    viewer asked for 1080p or better (then it cannot be vouched for)."""
    lo, hi = quality_limits()
    if lo == 0 and hi == 4:
        return results
    out = []
    for r in results:
        rank = _result_rank(r)
        if rank is None:
            if lo <= 1:
                out.append(r)
        elif lo <= rank <= hi:
            out.append(r)
    return out


_ANIME_FLAGGED = {}          # (title, year) -> True once AniList says the title is anime: search_all then waits for the anime sites


def _anime_search(title, year, media_type, season, episode):
    """Release lists of the anime sites for a title that is anime (see anime_sources); [] for everything else."""
    try:
        from starfleetscrapers.debrid import anime_sources
        if not anime_sources.enabled():
            return []
        if anime_sources.titles(title, year, media_type):
            _ANIME_FLAGGED[(title, year)] = True
        return anime_sources.search(title, year, media_type, season, episode)
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] anime sources: %s' % e, xbmc.LOGWARNING)
        return []


def _external_search(title, year, media_type, imdb_id, season, episode):
    """Results from other installed scraper modules that follow the common layout (see compat/external.py)."""
    try:
        from starfleetscrapers.compat import external
        return external.search(title, year, media_type, imdb_id, season, episode, timeout=8)
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] external scraper modules: %s' % e, xbmc.LOGWARNING)
        return []


# The five movie / TV torrent sources whose results are best SEEDED, measured on their own over six titles (3 films, 3 episodes):
# together they hold 83% of all the 1080p / 4K results with at least 10 seeders that the thirty working sources find, each
# answers in about a second. Sources that report no seed counts at all (Comet, Zilean, TorrentsDB, DMM...) find many torrents but
# nobody can tell which ones are alive, so they are off by default. Everything else is off until the viewer turns it on in
# Settings > Torrent Sources. Adult, sports, live TV, radio and the hoster / Usenet sources are not part of this list.
_TOP_SOURCES = ('stremthru', 'meteor', 'limetorrents', 'torrentdl', 'kickass2')
_PROFILE_VERSION = 2

# Automatic source choice (setting 'torrent_mode': 0 = automatic, the default; 1 = the viewer's own toggles below it). Measured on
# six titles (2 films, 2 episodes, an anime episode and film): Comet alone finds 83-96 % of every relevant release, and the best
# three sources 92-98 %. Those three go first and are usually done in 1-2 s; the rest (TIER2) start only if the three found
# little (fewer than ~150 raw hits), so an obscure title still gets the whole sweep. The names are search_all's task names.
_TIER1 = {'movie': ('Comet', 'StremThru', 'DMM'), 'tv': ('Comet', 'Bitmagnet', 'TorrentDL')}
_TIER1_ALWAYS = ('Anime', 'External')          # end at once for a title that is not anime / when no other module is installed
_TIER2_KEYS = ('stremthru', 'meteor', 'zilean', 'mediafusion', 'torrentio', 'torrentsdb', 'peerflix', 'aiostreams', 'knaben',
               'tpb', 'yts', 'eztv', 'bitmagnet', 'dmm', 'torrentdl', 'bitsearch', 'rutor', 'kickass2', 'limetorrents',
               'torrentfunk', 'comet', '1337x')
_AUTO_KEYS = frozenset(_TIER2_KEYS)


def _mode_is_auto():
    try:
        return (_sfhost.addon().getSetting('torrent_mode') or '0').strip() != '1'
    except Exception:
        return True
_PROFILE_SKIP = ('external',)      # not a toggle of this kind (module choice)
_profile_lock = __import__('threading').Lock()


def apply_default_sources():
    """Once per _PROFILE_VERSION: switch the movie / TV torrent sources to the top five above, everything else off. Writes the
    host's own source toggles, so the viewer sees (and can change) exactly what is on; a marker file keeps it from running again
    and from undoing the viewer's later choices."""
    import json as _json
    import os as _os
    if _mode_is_auto():                  # the automatic choice does not touch the viewer's toggles
        return False
    with _profile_lock:
        try:
            marker = _os.path.join(_sfhost.profile(), 'src_profile.json')
            try:
                with open(marker, 'r', encoding='utf-8') as fh:
                    if int((_json.load(fh) or {}).get('version', 0)) >= _PROFILE_VERSION:
                        return False
            except (OSError, ValueError):
                pass
            addon = _sfhost.addon()
            for key in _ALL_SOURCE_KEYS:
                if key in _PROFILE_SKIP:
                    continue
                addon.setSetting('src_' + key, 'true' if key in _TOP_SOURCES else 'false')
            try:
                _os.makedirs(_os.path.dirname(marker), exist_ok=True)
                with open(marker, 'w', encoding='utf-8') as fh:
                    _json.dump({'version': _PROFILE_VERSION, 'on': list(_TOP_SOURCES)}, fh)
            except OSError:
                pass
            try:
                import xbmcgui
                xbmcgui.Dialog().notification('Starfleet', 'Movie / TV torrent sources set to the 5 best-seeded - change them in '
                                              'Settings > Torrent Sources', xbmcgui.NOTIFICATION_INFO, 6000)
            except Exception:
                pass
            xbmc.log('[Starfleet/Torrents] default source profile v%d applied: %s' % (_PROFILE_VERSION, ', '.join(_TOP_SOURCES)), xbmc.LOGINFO)
            return True
        except Exception as e:
            xbmc.log('[Starfleet/Torrents] default source profile error: %s' % e, xbmc.LOGWARNING)
            return False


_prewarmed = [False]


def prewarm():
    """Open the connections (DNS, TLS) to the fast aggregator hosts ahead of the first search - on a cold start those
    handshakes were most of the first search's time. Safe to call any number of times; runs in the background."""
    if _prewarmed[0]:
        return
    _prewarmed[0] = True
    hosts = [TORRENTIO_BASE, COMET_BASE, TORZ_BASE, ZILEAN_BASE, MEDIAFUSION_BASE, METEOR_BASE, BITMAGNET_BASE,
             PEERFLIX_BASE, TPB_BASE, KNABEN_API.rsplit('/v1', 1)[0], EZTV_BASE, DMM_BASE] + list(AIOSTREAMS_MIRRORS[:1])

    def _hit(url):
        try:
            s = _sess()
            if s:
                s.head(url, timeout=4, allow_redirects=False)
        except Exception:
            pass
    import threading
    for u in hosts:
        threading.Thread(target=_hit, args=(u,), daemon=True).start()


# the sources that answer a whole list from one cheap request (search_all starts these first)
_FAST_TASKS = frozenset(('Torrentio', 'Comet', 'StremThru', 'Zilean', 'Meteor', 'Bitmagnet', 'MediaFusion', 'TorrentsDB',
                         'Peerflix', 'AIOStreams', 'DMM', 'Knaben', 'TPB', 'EZTV', 'YTS', 'Anime', 'External'))


def search_all(title, year=None, media_type='movie', max_per_source=5, imdb_id=None,
               season=None, episode=None, light=False):
    """With the "3D content" switch on, a movie search also asks for the title plus "3D" and merges what that finds;
    with it off this is the plain search (3D releases are dropped later, where the source list is made)."""
    base = _search_all_plain(title, year, media_type, max_per_source, imdb_id, season, episode, light)
    if not title or light:
        return base

    def _merge(have, extra, wanted):
        seen = {r.get('info_hash', '').lower() for r in have if r.get('info_hash')}
        merged = list(have)
        for r in extra or []:
            ih = (r.get('info_hash') or '').lower()
            if (ih and ih in seen) or not wanted(r):
                continue
            seen.add(ih)
            merged.append(r)
        merged.sort(key=lambda x: x.get('seeds', 0), reverse=True)
        return merged

    try:
        from starfleetscrapers.debrid import three_d as _3d
        if media_type == 'movie' and _3d.enabled() and not _3d.mode(title):
            base = _merge(base, _search_all_plain('%s 3D' % title, year, media_type, max_per_source, imdb_id, season, episode, light),
                          lambda r: _3d.mode(_3d.torrent_name(r)))
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] 3D search: %s' % e, xbmc.LOGWARNING)
    try:
        from starfleetscrapers.debrid import vr as _vr
        if _vr.enabled() and not _vr.is_vr(title):          # films, shows and adult titles that also come as VR releases
            base = _merge(base, _search_all_plain('%s VR' % title, year, media_type, max_per_source, None, season, episode, light),
                          lambda r: _vr.is_vr(_vr.torrent_name(r)))
    except Exception as e:
        xbmc.log('[Starfleet/Torrents] VR search: %s' % e, xbmc.LOGWARNING)
    return base


# Sources that carry nothing but adult releases (or search an adult category of their own), and the words that mark an adult release
# in the other indexes
_ADULT_ONLY_SOURCES = {'XXXClub', 'Rintor', 'XXXTor', 'FreeJAVTorrent', 'IJAVTorrent', 'Sukebei', 'TPB', 'BitPorn', 'FreeJAVTorrent', 'FreeJAV'}
_ADULT_MARK = re.compile(
    r'(?<![a-z0-9])(?:xxx|porn\w*|adult|18\+|nsfw|jav|erotic\w*|sex\w*|milf|hardcore|anal|blowjob|fuck\w*|hentai|uncensored|'
    r'brazzers|bangbros|naughty[ .]?america|reality[ .]?kings|mofos|vixen|tushy|blacked|deeper|nubiles|teamskeet|evil[ .]?angel|'
    r'jules[ .]?jordan|digital[ .]?playground|sex[ .]?art|met[ .]?art|x[ .]?art|hegre|vivid|penthouse|playboy|hustler|cumshot|'
    r'creampie|threesome|orgy|bdsm|fetish|lesbian|gangbang|bukkake|stepmom|stepsis\w*|stepdad|onlyfans|pornhub)(?![a-z0-9])', re.I)


def _search_all_plain(title, year=None, media_type='movie', max_per_source=5, imdb_id=None,
                      season=None, episode=None, light=False):
    """
    Search all torrent sources in parallel. Returns combined list sorted by seeds.
    media_type: 'movie', 'tv', or 'adult'
    imdb_id: optional tt... ID for Torrentio
    season/episode: for TV episodes
    light: a search made ahead of time for something not on screen (the next episode): in the automatic mode only the best
           three sources are asked and the others are never started, however little they find; with the viewer's own source
           switches (My own choice) the switched-on sources are asked as always
    """
    from concurrent.futures import ThreadPoolExecutor, as_completed
    from concurrent.futures import wait as _cf_wait, FIRST_COMPLETED as _CF_FIRST

    from starfleetscrapers.core import debrid_gate as _gate
    if not _gate.torrents_allowed():     # torrents are a debrid source: with no debrid service on (and Elementum off) nothing is asked
        xbmc.log('[Starfleet/Torrents] no debrid service on: torrent sources not searched', xbmc.LOGINFO)
        return []

    if media_type in ('movie', 'tv'):
        apply_default_sources()          # first search only: the top-five movie / TV profile (adult and the rest are untouched)

    # Adult titles get run through the same junk-stripper the ADE-ingestion
    # layer uses, so a raw search-box query is just as clean as a canonical
    # ADE title by the time it's used to build every source's query AND the
    # title-match filter below — search_xxxclub/search_rintor also clean
    # defensively, but generic scrapers (TPB, Knaben, etc.) take `title` as-is.
    if media_type == 'adult' and title:
        title = _clean_adult_title(title) or title

    # Confirmed live this was a real, large, avoidable cost: this function
    # was never cached at all (only the adult XXXClub browse path used
    # _cache anywhere in this whole file) - every single search, even an
    # immediate repeat of the exact same title/episode (retrying after
    # Cancel, autoplay-next-episode re-checking, re-opening the source
    # picker), re-hit all ~30+ live sites from scratch every time. 15
    # minutes is short enough that seed counts/cache availability haven't
    # drifted much, but long enough to make every one of those repeat
    # cases instant instead of paying the full multi-source sweep again.
    # Per-source on/off toggles (Settings > Torrent Sources) — one bool per
    # scraper, defaults matching the "fast core set" this file settled on
    # after a real comparison against gears (core aggregators + Knaben/
    # TPB/YTS/EZTV/1337x default on; the ~20 slower single-site scrapers
    # default off). Lets a user keep the fast default, turn everything
    # back on, or hand-pick their own preferred mix - not just one blanket
    # "extra sources" switch as before.
    _auto = media_type in ('movie', 'tv') and _mode_is_auto()
    try:
        _src_addon = _sfhost.addon()
        _scraper_mode = (_src_addon.getSetting('scraper_mode') or '1').strip()
        def _src_on(key):
            if key == 'external':
                return _scraper_mode in ('1', '2')
            if _auto:
                return key in _AUTO_KEYS
            return _src_addon.getSetting('src_' + key) == 'true'
    except Exception:
        _scraper_mode = '1'
        def _src_on(key):
            return True
    _enabled_sig = tuple(sorted(k for k in _ALL_SOURCE_KEYS if _src_on(k)))
    try:
        _mods_sig = _sfhost.addon().getSetting('external_scraper_modules') or ''
    except Exception:
        _mods_sig = ''
    try:
        from starfleetscrapers.debrid import foreign_audio as _fa
        _fa_mode = _fa.mode()
    except Exception:
        _fa_mode = '1'
    _ck = ('torrentall_%s_%s_%s_%s_%s_%s_%s_%s_%s_%s_%s_%s_%s_%s' %
           (title, year, media_type, imdb_id, season, episode, max_per_source, _enabled_sig, quality_limits(),
            _scraper_mode, _mods_sig, _fa_mode, _auto, _include_sd_rips()))
    try:
        from starfleetscrapers.core import device as _dv0
        _ck += '_' + _dv0.profile()['tier']
    except Exception:
        pass
    if light and _auto:
        _ck += '_light'                   # a best-three-only list is not the full list: never handed to a normal search
    if _HAS_CACHE:
        _cached = _cache.get(_ck)
        if _cached is not None:
            return _cached

    # TPB/apibay categories: 500=adult (confirmed live 2026-09-05 as a real
    # working parent category — a query against it alone returns full,
    # correctly-tagged pages of results). 201 ("Movies") and 208 ("HD - TV
    # shows") were NOT the same kind of parent category despite this file's
    # own prior comment claiming "201=Movies/HD" — confirmed live the same
    # day querying cat=201 for a real, currently-popular movie ("Dune Part
    # Two") returned exactly 1 result, while the SAME query with no
    # category filter returned 97, nearly all of them sitting under
    # completely different category ids (207 "HD - Movies", 211 "UHD/4K -
    # Movies", 210) that a cat=201 query never matched at all. This is why
    # TPB kept surfacing nothing but old CAM/TS junk in real use even when
    # enabled: those happened to be the rare uploads actually tagged 201,
    # while every legitimate HD/4K release was invisible to this query the
    # entire time. TV's cat=208 wasn't nearly as broken (still 100 results)
    # but was confirmed to miss a real, separate 27-item UHD-TV bucket
    # (category 212) the same way. Querying with no category filter at all
    # for movie/tv and letting the existing local _meets_quality()/
    # filter_by_title_and_episode() filters do the real work (same as every
    # other source in this file that doesn't get a reliable server-side
    # category) sidesteps trusting TPB's own category taxonomy at all.
    tpb_cat = 500 if media_type == 'adult' else 0

    # Previously removed for being CF-blocked; re-enabled with cfscraper fallback.
    # TGX: magnets may be JS-rendered on some mirrors — cfscraper handles most.
    # EXTto: the old ext.to domain this pointed at is fully dead now (DNS
    # doesn't even resolve, confirmed 2026-08-04) — moved to extto.com, the
    # site's current live mirror, no Cloudflare wall at all. Its magnets
    # need a per-item HMAC-signed AJAX call now (search_extto's own
    # docstring has the details) instead of the old inline-HTML scrape.
    # TorrentFunk: re-enabled 2026-08-06 -- its HTML search.php is still
    # genuinely CF-JS-challenged, but the site now documents/exposes a free
    # keyless JSON API (search_torrentfunk() hits /api/search.json directly)
    # with real server-side query search, no CF in front of it at all.
    #
    # Dead permanently: isohunt2 (404), EZTV (CF 403), Glodls (glodls.to
    #   redirects to glodls.club, which returns a Cloudflare 522 -- origin
    #   server itself is down/unreachable, not a JS-challenge to bypass),
    #   Bitlord (site rebuilt as a compiled Flutter web app -- no scrapeable
    #   HTML/API surface at all anymore), YourBT (search results now link out
    #   through single-use, per-query-rotating t0r.space subdomains whose
    #   detail pages 404 almost immediately -- not a stale-selector bug,
    #   the site's own link chain doesn't survive a second request)
    # 1337x: re-enabled — the old domain list was genuinely dead/reduced to
    # parked stub pages, but 1377x.to and 1337xx.to are real, live mirrors
    # (confirmed) once search_1337x() was rewritten for the site's new
    # /srch search endpoint and result-row format.
    #
    # Dict insertion order here IS submission order below (pool.submit()
    # iterates tasks.items() in order), and with max_workers capped at 12
    # against typically 13-16 total sources, whichever ones are inserted
    # LAST are the ones that queue and wait for a worker slot instead of
    # starting immediately. Torrentio/Knaben/TPB/YTS/EZTV/1337x are the
    # highest-value sources (see this file's own quality/reliability
    # notes), so they're built FIRST now — previously Torrentio/YTS/EZTV
    # were appended after all 13 lower-priority sources below, meaning the
    # single best source in the whole list was consistently one of the
    # ones most likely to be left queuing instead of running right away.
    tasks = {}

    # Torrentio: API-based, needs IMDB ID, works great for TV and movies.
    # Not scaled off max_per_source (that's sized for per-item HTML-scraping
    # sources) — Torrentio is one cheap JSON call, so it just uses its own
    # generous default limit (see search_torrentio's own docstring for why
    # a small limit here specifically hid 4K results).
    if imdb_id and media_type in ('movie', 'tv'):
        if media_type == 'tv' and season is not None and episode is not None:
            if _src_on('torrentio'):   tasks['Torrentio'] = lambda: search_torrentio(imdb_id, season, episode, media_type=media_type)
            if _src_on('comet'):       tasks['Comet']     = lambda: search_comet(imdb_id, season, episode, media_type=media_type)
            if _src_on('stremthru'):   tasks['StremThru'] = lambda: search_torz(imdb_id, season, episode, media_type=media_type)
            if _src_on('peerflix'):    tasks['Peerflix']  = lambda: search_peerflix(imdb_id, season, episode, media_type=media_type)
            if _src_on('bitmagnet'):   tasks['Bitmagnet'] = lambda: search_bitmagnet(imdb_id, season, episode, media_type=media_type)
            if _src_on('zilean'):      tasks['Zilean']      = lambda: search_zilean(imdb_id, season, episode, media_type=media_type)
            if _src_on('mediafusion'): tasks['MediaFusion'] = lambda: search_mediafusion(imdb_id, season, episode, media_type=media_type)
            if _src_on('meteor'):      tasks['Meteor']      = lambda: search_meteor(imdb_id, season, episode, media_type=media_type)
            if _src_on('torrentsdb'):  tasks['TorrentsDB']  = lambda: search_torrentsdb(imdb_id, season, episode, media_type=media_type)
            if _src_on('aiostreams'):  tasks['AIOStreams']  = lambda: search_aiostreams(imdb_id, season, episode, media_type=media_type)
        elif media_type == 'movie':
            if _src_on('torrentio'):   tasks['Torrentio'] = lambda: search_torrentio(imdb_id, media_type=media_type)
            if _src_on('comet'):       tasks['Comet']     = lambda: search_comet(imdb_id, media_type=media_type)
            if _src_on('stremthru'):   tasks['StremThru'] = lambda: search_torz(imdb_id, media_type=media_type)
            if _src_on('peerflix'):    tasks['Peerflix']  = lambda: search_peerflix(imdb_id, media_type=media_type)
            if _src_on('dmm'):         tasks['DMM']       = lambda: search_dmm(imdb_id, media_type=media_type)
            if _src_on('bitmagnet'):   tasks['Bitmagnet'] = lambda: search_bitmagnet(imdb_id, media_type=media_type)
            if _src_on('zilean'):      tasks['Zilean']      = lambda: search_zilean(imdb_id, media_type=media_type)
            if _src_on('mediafusion'): tasks['MediaFusion'] = lambda: search_mediafusion(imdb_id, media_type=media_type)
            if _src_on('meteor'):      tasks['Meteor']      = lambda: search_meteor(imdb_id, media_type=media_type)
            if _src_on('torrentsdb'):  tasks['TorrentsDB']  = lambda: search_torrentsdb(imdb_id, media_type=media_type)
            if _src_on('aiostreams'):  tasks['AIOStreams']  = lambda: search_aiostreams(imdb_id, media_type=media_type)

    if _src_on('knaben'):      tasks['Knaben']   = lambda: search_knaben(title, year, media_type, max_per_source * 2)
    if _src_on('tpb'):         tasks['TPB']      = lambda: search_tpb(title, year, tpb_cat, max_per_source, media_type)
    if _src_on('torrent9'):    tasks['Torrent9'] = lambda: search_torrent9(title, year, max_per_source, media_type)
    if _src_on('bt4g'):        tasks['Bt4g']     = lambda: search_bt4g(title, year, max(max_per_source * 2, 15), media_type)

    if media_type == 'movie' and _src_on('yts'):
        # YTS is a mainstream-only movie site with zero adult content —
        # confirmed live 2026-09-03 this was previously also gated on
        # media_type=='adult' (a real contributor to the "regular IMDB
        # movies showing up in Adult search results" bug fixed just below
        # in this same function), which could only ever have returned real
        # mainstream movies into an adult search, never anything genuinely
        # adult.
        tasks['YTS'] = lambda: search_yts(title, year, max_per_source, media_type)
    if media_type == 'tv' and _src_on('eztv'):
        # EZTV: API-first when imdb_id is known (no Cloudflare on that
        # endpoint); falls back to the CF-protected HTML search otherwise.
        tasks['EZTV'] = lambda: search_eztv(title, year, max_per_source, imdb_id, season, episode)

    if _src_on('1337x'): tasks['1337x'] = lambda: search_1337x(title, year, max_per_source, media_type)

    # Lower-priority generic sources — mostly slower/flakier single-site
    # HTML/CF-walled scrapers, unlike the aggregator APIs and Knaben/TPB/
    # YTS/EZTV/1337x above. Confirmed via a real comparison against gears
    # (which queries ~5 fast aggregator sources by default, not ~30+) that
    # this block is the main reason a Starfleet search runs noticeably
    # longer than gears' equivalent search for comparable results - each
    # one is its own individual Settings > Torrent Sources toggle, off by
    # default, rather than one blanket "extra sources" switch - a search
    # stays fast by default but the user can turn any/all of these back on
    # (or use the "Enable All Sources" button for the full ~34-source set).
    if _src_on('yourbittorrent'):  tasks['YourBT']          = lambda: search_yourbittorrent(title, year, max_per_source, media_type)
    if _src_on('bitsearch'):       tasks['Bitsearch']       = lambda: search_bitsearch(title, None, max_per_source, media_type)
    if _src_on('torrentdl'):       tasks['TorrentDL']       = lambda: search_torrentdownloads(title, year, max_per_source, media_type)
    if _src_on('limetorrents'):    tasks['LimeTorrents']    = lambda: search_limetorrents(title, year, max_per_source, media_type)
    # Podzemlje — private tracker, per-user API token (Settings > Personal
    # Sources); search_podzemlje() itself returns [] instantly when no token
    # is configured or media_type isn't movie/tv, so always safe to include.
    tasks['Podzemlje'] = lambda: search_podzemlje(title, year, max_per_source, media_type)
    # magnetdl.hair: confirmed live 2026-09-07 the domain is now a parked
    # "This domain may be for sale" page — real, not a bot-challenge
    # (confirmed via cloudscraper too, which gets the identical parking
    # page). Site is genuinely gone. Function body left in place in case
    # the domain ever changes hands to a real operator again.
    # if _src_on('magnetdl'):        tasks['MagnetDL']        = lambda: search_magnetdl(title, None, max_per_source, media_type)
    # bittorrented.com: confirmed live 2026-09-07 the site's own homepage
    # now returns 402 Payment Required (not just the search endpoint) —
    # paywalled/monetized shut-down, not a scraper bug. Every enabled
    # search was paying this source's full timeout for a guaranteed
    # failure. Function body left in place in case it ever reopens.
    # if _src_on('bittorrented'):    tasks['BitTorrented']    = lambda: search_bittorrented(title, None, max_per_source, media_type)
    # msearch: confirmed live 2026-09-07 its backend
    # (7oob1b3of6-dsn.algolia.net, an Algolia hosted-search index) no
    # longer resolves at all (DNS NXDOMAIN) — the whole index is gone, not
    # a query-format issue. Function body left in place in case a new
    # index host ever gets confirmed.
    # if _src_on('msearch'):         tasks['MSearch']         = lambda: search_msearch_torrents(title, year, max_per_source * 2, media_type)
    if _src_on('tgx'):             tasks['TGX']             = lambda: search_torrentgalaxy(title, year, max_per_source, media_type)
    if _src_on('zooqle'):          tasks['Zooqle']          = lambda: search_zooqle(title, year, max_per_source, media_type)
    if _src_on('nyaa'):            tasks['Nyaa']            = lambda: search_nyaa(title, year, max_per_source, media_type)
    # ext.to: re-enabled 2026-09-12 — was extto.com's sustained 403, but the
    # site itself flipped back to ext.to (see EXTTO_BASE's own header
    # comment) with a real, working, ~1-year cf_clearance cookie mechanism
    # now in place (scraper_extto_cookie.py). search_extto() itself already
    # no-ops cleanly if that cookie isn't published yet.
    if _src_on('extto'):           tasks['EXTto']           = lambda: search_extto(title, year, max_per_source, media_type)
    if _src_on('therarbg'):        tasks['TheRarBG']        = lambda: search_therarbg(title, year, max_per_source, media_type)
    if _src_on('torrentproject2'): tasks['TorrentProject2'] = lambda: search_torrentproject2(title, year, max_per_source, media_type)
    if _src_on('torrentz2'):       tasks['Torrentz2']       = lambda: search_torrentz2(title, year, max_per_source, media_type)
    if _src_on('kickass2'):        tasks['Kickass2']        = lambda: search_kickass2(title, year, max_per_source, media_type)
    if _src_on('kontrast'):        tasks['KONTRAST']        = lambda: search_kontrast(title, year, max_per_source, media_type)
    if _src_on('torrentfunk'):     tasks['TorrentFunk']     = lambda: search_torrentfunk(title, year, max_per_source, media_type)
    if _src_on('torlock'):         tasks['Torlock']         = lambda: search_torlock(title, year, max_per_source, media_type)
    if _src_on('torrentscsv'):     tasks['TorrentsCSV']     = lambda: search_torrentscsv(title, year, max_per_source, media_type)
    if _src_on('torrentkitty'):    tasks['TorrentKitty']    = lambda: search_torrentkitty(title, year, max_per_source, media_type)
    if _src_on('btdig'):           tasks['BitDig']          = lambda: search_btdig(title, year, max_per_source, media_type)
    if _src_on('animetosho'):      tasks['AnimeTosho']      = lambda: search_animetosho(title, year, max_per_source, media_type)
    # Tordl (torrentdownload.info): already fully written and correct, just
    # never wired in — confirmed live 2026-08-11 with real results (50
    # matches, real 40-char hashes, on "The Matrix 1999") using its existing
    # regex unchanged. Off by default like the rest of this block.
    if _src_on('tordl'):           tasks['Tordl']           = lambda: search_tordl(title, year, max_per_source, media_type)
    # Rutor/NNMClub: confirmed live 2026-08-11 (39 real magnets on Rutor,
    # real anonymous .torrent downloads on NNMClub). Both Russian trackers
    # with mixed Cyrillic/English titles — off by default like the rest of
    # this block, since seeders/mirror uptime for either haven't been
    # observed over any real length of time yet.
    if _src_on('rutor'):           tasks['Rutor']           = lambda: search_rutor(title, year, max_per_source, media_type)
    if _src_on('nnmclub'):         tasks['NNMClub']         = lambda: search_nnmclub(title, year, max_per_source, media_type)
    if media_type == 'movie' and _src_on('publicdomaintorrents'):
        tasks['PublicDomainTorrents'] = lambda: search_publicdomaintorrents(title, year, max_per_source, media_type)
    # Cleanbay/DaMagNet/RARBGDump: confirmed live 2026-09-03 — Cleanbay
    # (real magnets via its testbay.onrender.com backend, though several of
    # the 6 sites it metasearches appear dead upstream right now), DaMagNet
    # (real two-step DHT-index lookup, 67M+ resources), RARBGDump (real
    # JSON API over RARBG's frozen pre-2023 database). See each function's
    # own docstring for the full detail. Off by default like the rest of
    # this block, no track record yet.
    if _src_on('cleanbay'):        tasks['Cleanbay']        = lambda: search_cleanbay(title, year, max_per_source, media_type)
    if _src_on('damag'):           tasks['DaMagNet']        = lambda: search_damag(title, year, max_per_source, media_type)
    if _src_on('rarbgdump'):       tasks['RARBGDump']       = lambda: search_rarbgdump(title, year, max_per_source * 2, media_type)
    # Demonoid: confirmed live 2026-09-04 — real, small/curated catalog with
    # a clean JSON API (see search_demonoid's own docstring). Off by default
    # like the rest of this block, no track record yet.
    if _src_on('demonoid'):        tasks['Demonoid']        = lambda: search_demonoid(title, year, max_per_source, media_type)
    # Snowfl: confirmed live 2026-08-15 — real aggregator API (limetorrents/
    # 1337x/etc.), real magnets with real btih hashes; see search_snowfl's
    # own docstring for why this works despite the site's scraper-hostile
    # reputation. Carries adult content too (real `nsfw` flag per result,
    # used both to include it when media_type=='adult' and to filter it
    # back OUT for movie/tv searches) — kept in this generic block AND
    # given its own explicit adult-block entry below since its own filter
    # only works right when it already knows which mode it's in.
    if _src_on('snowfl'):          tasks['Snowfl']          = lambda: search_snowfl(title, year, max_per_source, media_type)
    # ApacheTorrent/RedeTorrent: confirmed live 2026-08-16 — genuinely
    # filtering server-rendered search, real inline magnets (no ad-gate),
    # Brazilian-Portuguese dubbed movie/TV catalog. Torseek: confirmed live
    # same day — Jackett-backed meta-search reachable via its Next.js
    # Server Action (see search_torseek's own docstring for the mechanism
    # and its build-specific fragility caveat). All three off by default
    # like the rest of this block, no track record yet.
    if _src_on('apachetorrent'):   tasks['ApacheTorrent']   = lambda: search_apachetorrent(title, year, max_per_source, media_type)
    # RedeTorrent: the 2026-09-07 outage (site timing out completely) has
    # since cleared — confirmed live 2026-09-12 the site responds normally
    # again (200, real ~80KB search-results page). Re-enabled.
    if _src_on('redetorrent'):     tasks['RedeTorrent']     = lambda: search_redetorrent(title, year, max_per_source, media_type)
    # Torseek: confirmed live 2026-09-07 www.torseek.org no longer resolves
    # at all (DNS NXDOMAIN) — exactly the fragility this block's own
    # comment above flagged as a real possibility when this was added.
    # Function body left in place in case a working mirror ever surfaces.
    # if _src_on('torseek'):         tasks['Torseek']         = lambda: search_torseek(title, year, max_per_source, media_type)
    # FileMood: confirmed live 2026-08-16 — general DHT file index, no CF
    # bypass needed (see search_filemood's own comment for why that isn't a
    # contradiction despite the site being Cloudflare-fronted), info hash
    # embedded directly in each result's own URL. Off by default like the
    # rest of this block, no track record yet.
    if _src_on('filemood'):        tasks['FileMood']        = lambda: search_filemood(title, year, max_per_source, media_type)

    # anime: Nyaa, AnimeTosho, SubsPlease, Tokyo Toshokan, AcgnX - only for titles AniList knows as anime (the task ends at once
    # for everything else); not part of the per-source toggles above (Settings has src_anime / src_anime_<site> to switch them off)
    if media_type in ('movie', 'tv'):
        tasks['Anime'] = lambda: _anime_search(title, year, media_type, season, episode)

    # other installed scraper modules (scraper packs of the common layout): one task that runs all of their providers at once
    if media_type in ('movie', 'tv') and _src_on('external'):
        tasks['External'] = lambda: _external_search(title, year, media_type, imdb_id, season, episode)
        # "Other installed scraper modules only": drop Starfleet's own sources, unless no such module is installed
        if _scraper_mode == '2':
            try:
                from starfleetscrapers.compat import external as _ext_mods
                if _ext_mods._wanted_modules():
                    tasks = {k: v for k, v in tasks.items() if k == 'External'}
            except Exception:
                pass

    if media_type == 'adult':
        # Adult gets a completely different scraper mix than movie/tv, not
        # just the previous "movie/tv" mix minus a handful of weak ones.
        # Confirmed live 2026-09-03 this was a real, visible bug: every
        # generic movie/TV source built into `tasks` above (MSearch, TGX,
        # EXTto, TheRarBG, TorrentProject2, Torrentz2, Kickass2,
        # TorrentFunk, Torlock, TorrentsCSV, BitDig, Tordl, Rutor, NNMClub,
        # YourBT, Bitsearch, TorrentDL, LimeTorrents, MagnetDL,
        # BitTorrented, ApacheTorrent, RedeTorrent, Torseek, FileMood,
        # Cleanbay, DaMagNet, RARBGDump, 1337x, and even YTS — a
        # mainstream-only site with zero adult content at all, yet
        # previously explicitly re-added for media_type=='adult' just
        # below here) has no concept of "adult" and applies no adult-aware
        # filtering of its own. _meets_quality() (the one filter these
        # sources DO all run their results through) deliberately returns
        # True unconditionally for media_type=='adult', on the theory that
        # real adult releases don't reliably carry the same
        # resolution/non-video tags movie/tv releases do — but that same
        # blanket pass-through is exactly what let a real IMDB movie or TV
        # show whose title happened to match the search words sail straight
        # into "Adult" search results completely unfiltered, from any of
        # those ~25+ sources. The previous fix here only popped 5 of them
        # (YTS wasn't even one of the 5 — it was being added FOR adult) and
        # left the other ~20 running against the raw adult query. Clearing
        # the whole dict and rebuilding it below from only sources that
        # either are dedicated, adult-only trackers to begin with
        # (XXXClub/Rintor/XXXTor/FreeJAVTorrent/IJAVTorrent/Sukebei — no
        # mainstream catalog to leak from at all) or expose a real,
        # checkable adult signal of their own (TPB's own cat=500 XXX
        # category, Snowfl's own `nsfw` flag) is the actual fix: nothing
        # without at least one of those two guarantees runs for an adult
        # search at all now. Knaben is the one exception kept here despite
        # neither guarantee — its own category filter is broken server-side
        # (see search_knaben's own comment: "category filters are
        # unreliable — returns empty when set") so it's relying on the
        # same title/word match as everything just removed above. Left in
        # because that was already the deliberate, pre-existing choice for
        # this adult mix (not something this fix changed), but it's worth
        # knowing this one source can still theoretically surface a
        # same-titled mainstream result if a search term is generic enough
        # to collide with a real movie/show title.
        tasks = {}
        # Years are unreliable in adult release names (scene numbers get
        # mistaken for them) — query without one for these three, same as
        # search_xxxclub/search_rintor already do defensively on their own.
        tasks['TPB']     = lambda: search_tpb(title, None, tpb_cat, max(max_per_source * 2, 15), media_type)
        tasks['Knaben']  = lambda: search_knaben(title, None, media_type, max(max_per_source * 3, 30))
        tasks['XXXClub'] = lambda: search_xxxclub(title, year, max(max_per_source * 3, 20), media_type)
        tasks['Rintor']  = lambda: search_rintor(title, year, max_per_source, media_type)
        tasks['XXXTor']  = lambda: search_xxxtor(title, year, max(max_per_source * 3, 15), media_type)
        tasks['FreeJAVTorrent'] = lambda: search_freejavtorrent(title, year, max_per_source, media_type)
        tasks['IJAVTorrent'] = lambda: search_ijavtorrent(title, year, max_per_source, media_type)
        tasks['Sukebei'] = lambda: search_sukebei_nyaa(title, None, max(max_per_source * 2, 10), media_type)
        # BitPorn — private tracker, per-user API token (Settings > Personal
        # Sources); search_bitporn() itself returns [] instantly when no
        # token is configured, so this is always safe to include unconditionally.
        tasks['BitPorn'] = lambda: search_bitporn(title, year, max_per_source, media_type)
        # Snowfl carries real adult content (confirmed live via its own
        # `nsfw` flag) — forced on here same as TPB/Knaben above, regardless
        # of the general Settings toggle, matching this block's existing
        # convention of always running its own known-good adult sources.
        tasks['Snowfl'] = lambda: search_snowfl(title, None, max(max_per_source * 2, 15), media_type)
        # 1337x/EXTto/TheRarBG: added 2026-09-05, per direct request to get
        # the "main" sources into adult search without reintroducing the
        # mainstream-leak this block was fixed to stop. All three are safe
        # for the same reason TPB is: a real, server-side adult category the
        # site itself enforces, not just a title-text match against an
        # unscoped general search — 1337x's own XXX category (see
        # search_1337x's own docstring for how that was confirmed), and
        # EXTto/TheRarBG's cat=10/'XXX' were already fully implemented in
        # both functions and handling media_type='adult' correctly, just
        # never wired in here. Confirmed live real, correctly-scoped adult
        # results for all three the same day.
        tasks['1337x']    = lambda: search_1337x(title, None, max_per_source, media_type)
        # ext.to: re-enabled 2026-09-12 — see EXTTO_BASE's own header
        # comment and the general movie/TV toggle above for the full story
        # (domain flip back from extto.com + a working cf_clearance
        # mechanism now in place).
        tasks['EXTto']    = lambda: search_extto(title, None, max_per_source, media_type)
        tasks['TheRarBG'] = lambda: search_therarbg(title, None, max_per_source, media_type)

    if media_type in ('movie', 'tv'):
        try:                              # sources that keep coming back empty / late are left out for a day (source_health)
            from starfleetscrapers.debrid import source_health as _sh
            _off = _sh.disabled()
            _dropped = [n for n in tasks if n in _off]
            for _n in _dropped:
                tasks.pop(_n, None)
            if _dropped:
                xbmc.log('[Starfleet/Torrents] left out for now (dead lately): %s' % ', '.join(_dropped), xbmc.LOGINFO)
        except Exception as _e:
            xbmc.log('[Starfleet/Torrents] source health: %s' % _e, xbmc.LOGWARNING)
    _outcomes = {}
    all_results = []
    # NOT a `with` block on purpose — same footgun already fixed in
    # metadata_router.py/free_sources.py's own pools (see their comments):
    # ThreadPoolExecutor.__exit__ always calls shutdown(wait=True), which
    # blocks until EVERY submitted task finishes, even ones the code below
    # has already given up on via as_completed's own timeout. Confirmed
    # live this was silently costing two things at once here: (1) the
    # function's real wall-clock time could run well past the 15s the
    # timeout implies, waiting on a slow 1337x mirror probe or an ext.to CF
    # retry that nothing downstream even wants; (2) a fast, reliable source
    # (TPB/EZTV confirmed individually sub-2s live) that simply lost the
    # race to be YIELDED before the 15s mark in one particular run — pure
    # network jitter, not a real slowdown of its own — got silently
    # dropped with no chance to ever show up, since the whole batch's
    # timeout is shared across every task regardless of how fast any one
    # of them individually is. Was raised to 25s for headroom against that
    # jitter; lowered again to 18s once the always-run task list itself
    # was trimmed down to a fast core set (see the torrent_extra_sources
    # setting above) - confirmed live that with only ~14 tasks instead of
    # ~34, the couple of sources having a genuinely bad moment (a real
    # connection timeout, not just slow) were what the full 25s was really
    # buying, at the cost of the picker taking noticeably longer on every
    # single search even when nothing was wrong - 18s matches gears' own
    # 20s external-search ceiling instead of exceeding it. The pool itself
    # is shut down without waiting so a straggler can't block the caller
    # after we've already stopped collecting its result anyway.
    # Every task here is I/O-bound (waiting on a network response, not CPU),
    # so there's no real cost to running them all truly concurrently instead
    # of artificially staggering them in batches. Capping this well below the
    # actual task count (previously 12 against 20-27 real sources once the
    # IMDB meta-search block grew) meant roughly half of every search sat
    # queued waiting for an earlier task to finish before it even started —
    # not a real slowdown of any individual source, just self-inflicted
    # serialization. One worker per task removes that queueing entirely.
    try:
        from starfleetscrapers.core import device as _device
        _dev = _device.profile()
    except Exception:
        _dev = {'pool': 48, 'per_source': 3000, 'raw_cap': 0, 'speculative': False, 'tier': 'high'}
    # one thread per task on a device with the cores and memory for it; a bounded number on a weak one (a Fire TV Stick runs
    # four slow cores in under 2 GB: forty threads at once make each of them slower, and the tail is cut off anyway)
    pool = ThreadPoolExecutor(max_workers=max(2, min(len(tasks), _dev['pool'])))
    try:
        # Staged start (movie / TV): the aggregators that answer from one cheap call go first. The thirty-odd single-site
        # scrapers start only if those have not produced a picker's worth of hits within ~1.2 s - launching all of them
        # at once made every thread fight over the interpreter, so even the aggregators needed 4-5 s instead of ~1 s.
        held = {}
        _tier1_names = set()
        if _auto and not _ANIME_FLAGGED.get((title, year)):
            _tier1_names = set(_TIER1.get(media_type, ())) | set(_TIER1_ALWAYS)
            if _dev.get('speculative'):         # a device with cores to spare starts the other aggregators in the same breath
                _tier1_names |= _FAST_TASKS
            held = {n: fn for n, fn in tasks.items() if n not in _tier1_names}
            if light:
                held = {}                       # prepared ahead of time: the best three only, nothing else is ever started
        elif media_type in ('movie', 'tv') and any(n in _FAST_TASKS for n in tasks) and not _ANIME_FLAGGED.get((title, year)):
            held = {n: fn for n, fn in tasks.items() if n not in _FAST_TASKS}
        futures = {pool.submit(fn): name for name, fn in tasks.items() if name not in held}
        # Collection with a "good enough" cut-off. The hard ceiling is still 18s, but the
        # long tail is not worth waiting for: measured with all 49 sources on, the eleven
        # IMDb-keyed aggregators (Torrentio, Comet, Zilean, ...) return 100-200 hits in
        # 1-2s while single-site scrapers each add a handful more after 5-10s. Once at
        # least 60 hits from 4+ sources are in and 5s have passed, the remaining sources
        # get a short grace period (2s or 40% of the time already spent) and are then left
        # behind, so the picker opens in 6-8s instead of 10-14s.
        try:
            t_start = time.time()
            pending = set(futures)
            sources_with_hits = 0
            quorum_at = None

            def _release_held():
                for _n, _fn in held.items():
                    _f = pool.submit(_fn)
                    futures[_f] = _n
                    pending.add(_f)
                held.clear()
            # Tuned against the other scraper modules (about 7s wall each): the IMDb-keyed aggregators have
            # 100-200 hits in 1-2s, so a picker with plenty of hits does not wait for the single-site tail.
            _grace = 1.0
            _spec_at = None
            while pending or held:
                elapsed = time.time() - t_start
                if held and _auto:
                    # automatic mode: the best three decide. Enough hits -> the rest never start; little (or an anime title,
                    # whose sites are the point) -> everything else starts now.
                    _t1_left = [f for f in pending if futures.get(f) in _tier1_names and futures.get(f) not in _TIER1_ALWAYS]
                    if _ANIME_FLAGGED.get((title, year)) or (not _t1_left and (len(all_results) < 150 or sources_with_hits < 2)) \
                            or elapsed >= 2.5:
                        _release_held()
                    elif not _t1_left:
                        xbmc.log('[Starfleet/Torrents] the best three found %d hits, %d other sources not started' % (len(all_results), len(held)),
                                 xbmc.LOGINFO)
                        held.clear()
                elif held and quorum_at is not None:
                    xbmc.log('[Starfleet/Torrents] enough hits from the aggregators, %d single-site scrapers not started' % len(held),
                             xbmc.LOGINFO)
                    held.clear()
                elif held and (elapsed >= 1.2 or not pending):
                    _release_held()
                limit = 7.0
                if _auto and _dev.get('speculative') and _tier1_names and quorum_at is None:
                    # the extra aggregators started beside the best three: they get a moment after the best three answered,
                    # then the list goes ahead without them (they are not marked as late: they were never promised)
                    _best_left = [f for f in pending if futures.get(f) in set(_TIER1.get(media_type, ()))]
                    if not _best_left and len(all_results) >= 60:
                        if _spec_at is None:
                            _spec_at = elapsed
                        elif elapsed >= _spec_at + 0.3:
                            quorum_at, _grace = elapsed, 0.3
                limit = 7.0
                if quorum_at is not None:
                    limit = min(limit, quorum_at + _grace)
                if _ANIME_FLAGGED.get((title, year)) and any(futures[_f] == 'Anime' for _f in pending):
                    limit = max(limit, 6.5)                      # an anime title: the anime sites are the point, give them time
                if elapsed >= limit:
                    break
                # wake up at least every 0.2s while no quorum yet, so the cut-off is judged on time, not only when a source ends
                done, pending = _cf_wait(pending, timeout=min(limit - elapsed, 0.2) if quorum_at is None else limit - elapsed,
                                         return_when=_CF_FIRST)
                for future in done:
                    name = futures[future]
                    try:
                        results = future.result()
                        xbmc.log('[Starfleet/Torrents] %s: %d results in %.1fs' % (name, len(results), time.time() - t_start), xbmc.LOGINFO)
                        all_results.extend(results[:_dev['per_source']])
                        _outcomes[name] = 'hit' if results else 'empty'
                        if results:
                            sources_with_hits += 1
                    except Exception as e:
                        xbmc.log('[Starfleet/Torrents] %s failed: %s' % (name, e), xbmc.LOGWARNING)
                spent = time.time() - t_start
                if quorum_at is None:
                    n_raw = len(all_results)
                    if n_raw >= 400 and sources_with_hits >= 5 and spent >= 0.7:
                        quorum_at, _grace = spent, 0.3
                    elif n_raw >= 150 and sources_with_hits >= 4 and spent >= 1.0:
                        quorum_at, _grace = spent, 0.7
                    elif n_raw >= 40 and sources_with_hits >= 3 and spent >= 2.0:
                        quorum_at, _grace = spent, 1.0
                    elif n_raw >= 1 and spent >= 3.0:
                        quorum_at, _grace = spent, 1.0
            if media_type in ('movie', 'tv'):
                try:
                    if quorum_at is None:               # waited the full time: whoever is still running is late, not just cut off
                        for _f in pending:
                            if futures.get(_f):
                                _outcomes[futures[_f]] = 'late'
                    _sh.record(_outcomes, len(all_results) >= 80)
                except Exception:
                    pass
            if pending:
                xbmc.log('[Starfleet/Torrents] search_all left %d slow source(s) behind after %.1fs: %s' % (
                    len(pending), time.time() - t_start, ', '.join(sorted(futures[f] for f in pending))[:200]),
                    xbmc.LOGINFO)
        except Exception as e:
            xbmc.log('[Starfleet/Torrents] search_all collection error: %s' % e, xbmc.LOGWARNING)
    finally:
        pool.shutdown(wait=False)

    if _dev.get('raw_cap') and len(all_results) > _dev['raw_cap']:
        all_results = all_results[:_dev['raw_cap']]      # the title filter below is CPU work that extra cores do not speed up

    if media_type == 'adult':
        # The general indexes (Knaben, EXTto, TheRarBG, Snowfl...) search every category, so a title that is also a mainstream film
        # ("Equilibrium") brings that film in: from them only releases that name something adult are kept. The adult-only trackers
        # and TPB (searched in its own adult category) are taken as they come.
        all_results = [r for r in all_results if (r.get('source') or '') in _ADULT_ONLY_SOURCES or _ADULT_MARK.search(r.get('title') or r.get('name') or '')]
        try:                      # with the VR switch off no VR release is listed (the Adult VR section and the VR searches are off too)
            from starfleetscrapers.debrid import vr as _vr_off
            if not _vr_off.enabled() and not _vr_off.is_vr(title):
                all_results = [r for r in all_results if not _vr_off.is_vr(_vr_off.torrent_name(r))]
        except Exception:
            pass

    # Filter out false matches where the show/movie name doesn't appear as
    # whole words in the torrent title, and (for TV) wrong-episode matches.
    # See filter_by_title_and_episode()'s own docstring for the full
    # rationale — this used to be inline here; extracted so NZB/Usenet
    # search (nzb_sources.py, via debrid_torrent.py) can apply the exact
    # same strictness instead of shipping unfiltered.
    _anime_hits = [r for r in all_results if r.get('anime')]            # already matched to the film / episode by anime_sources
    all_results = filter_by_title_and_episode([r for r in all_results if not r.get('anime')], title, media_type=media_type,
                                               season=season, episode=episode) + _anime_hits
    if media_type in ('movie', 'tv'):
        all_results = apply_quality_limits(all_results)
        try:
            from starfleetscrapers.debrid import foreign_audio
            _anime_keep = [r for r in all_results if r.get('anime')]
            all_results = foreign_audio.filter_results([r for r in all_results if not r.get('anime')], title) + _anime_keep
        except Exception as e:
            xbmc.log('[Starfleet/Torrents] foreign-audio filter: %s' % e, xbmc.LOGWARNING)

    # Deduplicate by info_hash — keep whichever source's copy of a given
    # hash reports the highest seed count, not just whichever happened to
    # finish first. Confirmed live 2026-09-04 (investigating a direct
    # report that 1337x/TPB/Zooqle/LimeTorrents rarely show up even when
    # enabled) this was real: on a real "Inception" search with 9 sources
    # enabled, Torrentio alone returned 60 of 125 total raw hits (it's a
    # cheap single JSON call already aggregating many upstream indexers,
    # not slower than the others by accident), and used to win the old
    # first-seen-wins dedup for every hash it also happened to carry —
    # TorrentFunk/EXTto/Snowfl lost 100% of their own raw hits that run,
    # discarded as "duplicates" purely because Torrentio's copy of the same
    # hash happened to land in all_results first, even in cases where a
    # slower source's copy carried a more accurate/higher current seed
    # count for that exact swarm. This doesn't mean those sources are
    # broken or add nothing — every hash they find really was found, it
    # just wasn't necessarily the best-quality copy of itself kept. Keeping
    # the best-seed copy per hash instead fixes that without weakening
    # dedup accuracy at all (still exactly one entry per real torrent).
    best_by_hash = {}
    for r in all_results:
        ih = r.get('info_hash', '').lower()
        if not ih:
            continue
        prev = best_by_hash.get(ih)
        if prev is None or r.get('seeds', 0) > prev.get('seeds', 0):
            best_by_hash[ih] = r
    unique = list(best_by_hash.values())

    unique.sort(key=lambda x: x.get('seeds', 0), reverse=True)
    if media_type == 'adult':
        _lead = {'XXXClub': 0, 'Rintor': 1, 'XXXTor': 2}          # the adult trackers lead the list (stable: seeds order inside each)
        unique.sort(key=lambda x: _lead.get(x.get('source'), 3))
    if _HAS_CACHE:
        _cache.set(_ck, unique, 900)
    return unique
