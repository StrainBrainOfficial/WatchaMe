# -*- coding: utf-8 -*-
"""Extra live-sports providers, resolved on-device with plain HTTP (no browser).

Sites: sportzone (cdnsport.ru + nizar.nexa.st), topsurge (topsurge.st + kora.st),
flyembed (ovogoal.cyou + flyembed.click), sportsonline (sportsonline.vc).

A generic embed-page decoder (_econfig scheme, PP_CLAPPR_CONFIG block, XOR
payloads, plain m3u8 sources, iframe hops) plus a small resolver per provider.
Site listing URLs default to the values below and can be overridden without an
addon release via an optional data/live_sites.json on the Starfleet Pages repo
(same pattern as the other scraper-published JSON feeds), so a site moving
domain is a one-line data change.

Public API:
    events_for_slug(sport_slug)              -> list of event dicts
    streams_by_title(sport_slug, title)      -> list of resolved stream dicts
    event_path(sport_slug, title) / parse_event_path(path)
"""
import re
import json
import base64
import math
import time
import hashlib
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.parse import urlparse, urljoin, quote, unquote

from starfleetscrapers.core import http as requests
from starfleetscrapers.core.cache import coalesced as _coalesced
import xbmc

UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
      '(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36')
_TIMEOUT = 7
PATH_PREFIX = 'livesite:'

_OVERRIDE_URL = 'https://hazmat77.github.io/repository.starfleet/data/live_sites.json'
# provider key -> default listing URL
_LISTINGS = {
    'sz': 'https://cdnsport.ru/data.json',
    'ts': 'https://topsurge.st/api_proxy.php',
    'fe': 'https://ovogoal.cyou/api/v2/flyembed.json',
    'so': 'https://sportsonline.vc/prog.txt',
    'sr': 'https://streamfree.top/api/v1/streams',
    'pt': 'https://pitsport.st/api/v1/live-now',
    'll': 'https://livelive24.com/test/ntv/ntv.json',
}
_SOURCE_LABEL = {'sz': 'Sportzone', 'ts': 'TopSurge', 'fe': 'FlyEmbed', 'so': 'SportsOnline', 'pk': 'Streamed', 'sr': 'StreamFree', 'pt': 'PitSport', 'll': 'LiveLive'}


def _cache():
    from starfleetscrapers.sports import sports_sources as _ss
    return _ss._cache


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log('[Starfleet/LiveSites] %s' % msg, level)


# ── listing URLs ──────────────────────────────────────────────────────────────

@_coalesced
def _listing_url(key):
    c = _cache()
    ck = 'livesite_urls_v1'
    urls = c.get(ck)
    if urls is None:
        urls = {}
        try:
            r = requests.get(_OVERRIDE_URL, headers={'User-Agent': UA}, timeout=6)
            if r.status_code == 200:
                data = r.json()
                urls = {k: v for k, v in data.items()
                        if k in _LISTINGS and isinstance(v, str) and v.startswith('https://')}
        except Exception:
            urls = {}
        c.set(ck, urls or {'_': ''}, 6 * 3600)
    return urls.get(key) or _LISTINGS[key]


# ── team-aware title matching ─────────────────────────────────────────────────
# Existing word-overlap matching ("Ohio State vs Kent State" scores 3 against
# "Penn State vs Kent State") is far too loose to attach streams by — a wrong
# stream on the wrong game is worse than none — so this requires BOTH teams to
# line up on a distinctive word.

_STOP = {'state', 'united', 'city', 'the', 'fc', 'cf', 'sc', 'club', 'athletic',
         'real', 'team', 'women', 'womens', 'men', 'university', 'college'}
_RE_SCORE = re.compile(r'^(.*?)\s+\d+\s*-\s*\d+\s+(.*)$')
_SPLIT = re.compile(r'\s+(?:vs\.?|v|x|@|at|-|–)\s+', re.IGNORECASE)


def _norm(s):
    import unicodedata
    s = unicodedata.normalize('NFKD', s or '')
    s = ''.join(ch for ch in s if not unicodedata.combining(ch)).lower()
    s = re.sub(r'\s+', ' ', s)
    return re.sub(r'[^a-z0-9 ]', '', s).strip()


def _teams(title):
    t = (title or '').strip()
    m = _RE_SCORE.match(t)
    if m:
        return [m.group(1), m.group(2)]
    parts = _SPLIT.split(t, maxsplit=1)
    return parts if len(parts) == 2 else [t]


def _sig_words(s):
    return {w for w in _norm(s).split() if len(w) >= 3 and w not in _STOP}


def _team_match(a, b):
    wa, wb = _sig_words(a), _sig_words(b)
    if not wa or not wb:
        return False
    common = wa & wb
    # short single-word names ("Roma", "Inter") match on that word alone;
    # longer names need a distinctive shared word
    return bool(common)


def titles_match(a, b):
    ta, tb = _teams(a), _teams(b)
    if len(ta) == 2 and len(tb) == 2:
        return ((_team_match(ta[0], tb[0]) and _team_match(ta[1], tb[1]))
                or (_team_match(ta[0], tb[1]) and _team_match(ta[1], tb[0])))
    # single-name events (a UFC card, a race): need 2+ distinctive words in common
    return len(_sig_words(a) & _sig_words(b)) >= 2


# ── sport slug mapping ────────────────────────────────────────────────────────

_SOCCER_HINT = re.compile(
    r'premier|liga|serie a|bundesliga|ligue|eredivisie|mls|champions|europa|conference|'
    r'copa|world cup|efl|championship|super league|primeira|superliga|division|'
    r'j\.?league|a-league|allsvenskan|eliteserien|friendl|uefa|fifa', re.I)


def slug_for(sport, league, title=''):
    s = (sport or '').lower().strip()
    lg = (league or '').lower().strip()
    if s in ('american football', 'football (american)'):
        if 'ncaa' in lg or 'college' in lg:
            return 'cfb'
        return 'nfl'
    if s == 'canadian football' or lg == 'cfl':
        return 'cfl'
    if s == 'baseball':
        return 'mlb' if 'mlb' in lg else 'other_international'
    if s == 'basketball':
        if 'ncaa' in lg or 'college' in lg:
            return 'ncaab'
        return 'nba' if lg in ('nba', '') else 'other_international'
    if s in ('hockey', 'ice hockey'):
        return 'nhl' if lg == 'nhl' else 'hockey'
    if s == 'mma' or 'ufc' in lg:
        return 'ufc'
    if s == 'boxing':
        return 'boxing'
    if s in ('wrestling',) or 'wwe' in lg or 'aew' in lg:
        return 'wwe'
    if s == 'rugby':
        return 'rugby'
    if s == 'tennis':
        return 'tennis'
    if s == 'cricket':
        return 'cricket'
    if s == 'motorsport':
        if 'motogp' in lg or 'motogp' in (title or '').lower():
            return 'motogp'
        if 'f1' in lg or 'formula' in lg:
            return 'f1'
        return 'other_international'
    if s in ('football', 'soccer'):
        return 'soccer'
    return 'other_international'


def _slug_from_league_text(league, title=''):
    """Providers with no explicit sport field (flyembed, sportsonline)."""
    lg = (league or '').lower()
    if 'ncaa' in lg or 'college football' in lg:
        return 'cfb' if 'basket' not in lg else 'ncaab'
    if lg.strip() == 'nfl' or 'nfl ' in lg + ' ':
        return 'nfl'
    if 'mlb' in lg:
        return 'mlb'
    if 'nba' in lg or 'wnba' in lg:
        return 'nba'
    if 'nhl' in lg:
        return 'nhl'
    if 'cfl' in lg:
        return 'cfl'
    if 'ufc' in lg or 'mma' in lg:
        return 'ufc'
    if 'boxing' in lg:
        return 'boxing'
    if 'wwe' in lg or 'wrestling' in lg or 'aew' in lg:
        return 'wwe'
    if 'motogp' in lg:
        return 'motogp'
    if 'formula' in lg or lg.strip() == 'f1':
        return 'f1'
    if 'rugby' in lg:
        return 'rugby'
    if 'tennis' in lg or 'atp' in lg or 'wta' in lg:
        return 'tennis'
    if 'cricket' in lg:
        return 'cricket'
    if 'hockey' in lg:
        return 'hockey'
    if _SOCCER_HINT.search(lg) or not lg.strip():
        # sportsonline's prog.txt only prefixes a league for non-football
        # events; a bare "Team x Team" line is football
        return 'soccer'
    return 'other_international'


# The hockey hub groups games by league name, and onhockey.tv (which the hub
# already uses) says "Liiga", "SHL", "Tipsport Extraliga" — while sportzone /
# topsurge say "Finland Liiga", "Sweden SHL", "Czech Republic Extraliga".
# Normalized here so the same league doesn't show up twice in the hub.
_HOCKEY_LEAGUE_ALIAS = {
    'finland liiga': 'Liiga', 'finland mestis': 'Mestis', 'finland u20 sm-sarja': 'U20 SM-Sarja',
    'sweden shl': 'SHL', 'sweden hockeyallsvenskan': 'HockeyAllsvenskan',
    'hockeyallsvenskan': 'HockeyAllsvenskan', 'czech republic extraliga': 'Tipsport Extraliga',
    'czechia extraliga': 'Tipsport Extraliga', 'slovakia extraliga': 'Tipsport Liga',
    'switzerland national league': 'National League', 'switzerland swiss league': 'Swiss League',
    'germany del': 'DEL', 'austria icehl': 'ICEHL', 'russia khl': 'KHL', 'russia vhl': 'VHL',
    'norway eliteserien': 'EHL', 'norway ehl': 'EHL', 'usa nhl': 'NHL', 'usa ahl': 'AHL',
}


def _hockey_league(league):
    return _HOCKEY_LEAGUE_ALIAS.get((league or '').strip().lower(), (league or '').strip())


# ── provider fetchers → normalized matches ────────────────────────────────────
# match: {'prov','title','league','sport_slug','start_ts','is_live','links':[{'label','url'}]}

def _get(url, **kw):
    h = {'User-Agent': UA}
    h.update(kw.pop('headers', {}))
    return requests.get(url, headers=h, timeout=kw.pop('timeout', _TIMEOUT), **kw)


def _london_to_utc(y, mo, d, hh, mm):
    """flyembed / sportsonline publish UK local time (verified against
    sportzone's UTC timestamps for the same games: exactly +1h in September).
    zoneinfo/tzdata isn't reliably present on every Kodi platform, so BST is
    computed directly (last Sunday of March -> last Sunday of October, 01:00 UTC)."""
    import calendar
    import datetime as _dt

    def _last_sunday(year, month):
        last = _dt.date(year, month, calendar.monthrange(year, month)[1])
        return last - _dt.timedelta(days=(last.weekday() + 1) % 7)
    naive_utc = calendar.timegm((y, mo, d, hh, mm, 0))
    start = calendar.timegm((y, 3, _last_sunday(y, 3).day, 1, 0, 0))
    end = calendar.timegm((y, 10, _last_sunday(y, 10).day, 1, 0, 0))
    # treat the local time as BST first; if that lands outside BST, it was GMT
    bst_guess = naive_utc - 3600
    return bst_guess if start <= bst_guess < end else naive_utc


_MONTHS = {m: i for i, m in enumerate(
    ['january', 'february', 'march', 'april', 'may', 'june', 'july', 'august',
     'september', 'october', 'november', 'december'], 1)}


def _parse_clock(s):
    """'4:30 PM' / '22:30 PM' / '01:00' -> (hour24, minute) or None."""
    m = re.match(r'\s*(\d{1,2}):(\d{2})\s*(AM|PM)?', s or '', re.I)
    if not m:
        return None
    hh, mm, ap = int(m.group(1)), int(m.group(2)), (m.group(3) or '').upper()
    if ap == 'PM' and hh < 12:
        hh += 12
    elif ap == 'AM' and hh == 12:
        hh = 0
    return hh, mm


def _live_window(start_ts, duration_min=180):
    now = time.time()
    return bool(start_ts) and (start_ts - 600) <= now <= (start_ts + duration_min * 60)


def _fetch_matches_shape(prov):
    """cdnsport.ru/data.json (sportzone) and topsurge api_proxy.php share one
    shape: {'matches': [{team1, team2, sport, league, channels:[{name, language,
    links:[...]}], ...}]}."""
    data = _get(_listing_url(prov), timeout=15).json()
    out = []
    for m in data.get('matches', []):
        t1, t2 = (m.get('team1') or '').strip(), (m.get('team2') or '').strip()
        title = ('%s vs %s' % (t1, t2)) if t1 and t2 else (m.get('event') or m.get('name') or t1)
        if not title:
            continue
        links = []
        for ch in m.get('channels', []):
            name = ch.get('name') or 'Channel'
            lang = ch.get('language') or ''
            for i, l in enumerate(ch.get('links') or [], 1):
                if not l:
                    continue
                label = name + (' (%s)' % lang if lang else '') + (' Link %d' % i if len(ch['links']) > 1 else '')
                links.append({'label': label, 'url': l})
        if not links:
            continue
        ts = m.get('timestamp') or m.get('startTimestamp') or 0
        ts = int(ts // 1000) if ts and ts > 10 ** 11 else int(ts or 0)
        dur = m.get('duration_min') or m.get('duration') or 180
        is_live = (str(m.get('status', '')).lower() == 'live') or _live_window(ts, int(dur) if str(dur).isdigit() else 180)
        league = m.get('league') or ''
        out.append({'prov': prov, 'title': title.strip(), 'league': league,
                    'sport_slug': slug_for(m.get('sport'), league, title),
                    'start_ts': ts, 'is_live': is_live, 'links': links})
    return out


def _fetch_flyembed():
    data = _get(_listing_url('fe'), timeout=15).json()
    out = []
    for e in data:
        url = e.get('iframeURL')
        t1, t2 = (e.get('Team 1 ') or e.get('Team1') or '').strip(), (e.get('Team2') or '').strip()
        if not url or not (t1 or t2):
            continue
        title = ('%s vs %s' % (t1, t2)) if t1 and t2 else (t1 or t2)
        league = re.sub(r'\s+', ' ', (e.get('League') or '')).strip()
        ts = 0
        try:
            clock = _parse_clock(e.get('Time'))
            dm = re.match(r'\s*(\d{1,2})\s+([A-Za-z]+)\s*,?\s*(\d{4})', e.get('Date') or '')
            if clock and dm and dm.group(2).lower() in _MONTHS:
                ts = _london_to_utc(int(dm.group(3)), _MONTHS[dm.group(2).lower()], int(dm.group(1)), *clock)
        except Exception:
            ts = 0
        out.append({'prov': 'fe', 'title': title, 'league': league,
                    'sport_slug': _slug_from_league_text(league, title),
                    'start_ts': ts, 'is_live': _live_window(ts),
                    'links': [{'label': 'FlyEmbed', 'url': url}]})
    return out


_STREAMED = 'https://streamed.pk'
_STREAMED_SPORT = {'basketball': 'Basketball', 'football': 'Football', 'american-football': 'American Football',
                   'hockey': 'Hockey', 'baseball': 'Baseball', 'motor-sports': 'Motorsport', 'tennis': 'Tennis',
                   'rugby': 'Rugby', 'cricket': 'Cricket', 'golf': 'Golf', 'fight': 'Fight'}


def _fetch_streamed():
    """streamed.pk: /api/matches/all -> [{title, category, date (ms), teams{home,away}, sources:[{source,id}]}]."""
    base = _listing_url('pk') if 'pk' in _LISTINGS else _STREAMED
    games = _get(base.rstrip('/') + '/api/matches/all', headers={'Referer': base + '/'}, timeout=15).json()
    out = []
    for g in games or []:
        srcs = g.get('sources') or []
        if not srcs:
            continue
        teams = g.get('teams') or {}
        home, away = (teams.get('home') or {}).get('name'), (teams.get('away') or {}).get('name')
        title = ('%s vs %s' % (away, home)) if home and away else (g.get('title') or '').strip()
        if not title:
            continue
        cat = g.get('category') or ''
        sport = _STREAMED_SPORT.get(cat, cat)
        if cat == 'fight':
            sport = 'mma' if re.search(r'ufc|mma|bellator|pfl|one championship', title, re.I) else 'boxing'
        ts = int((g.get('date') or 0) // 1000)
        links = []
        for sr in srcs[:4]:
            links.append({'label': sr.get('source', 'stream').title(),
                          'url': '%s/api/stream/%s/%s' % (base.rstrip('/'), sr.get('source'), sr.get('id'))})
        out.append({'prov': 'pk', 'title': title, 'league': '', 'sport_slug': slug_for(sport, '', title),
                    'start_ts': ts, 'is_live': _live_window(ts) if ts else True, 'links': links})
    return out


_SR_SPORT = {'football': 'american football', 'racing': 'motorsport'}      # streamfree.top's own category words


def _fetch_streamfree():
    """streamfree.top/api/v1/streams: {'streams': [{name, category, league, match_timestamp, sources: [<embed url>...]}]}. The embed
    addresses (strmfree.st/embed/...) are opened by the shared resolver (StrmFree)."""
    data = _get(_listing_url('sr'), timeout=15).json()
    out = []
    for g in (data or {}).get('streams', []):
        embeds = [u for u in (g.get('live_sources') or g.get('sources') or []) if isinstance(u, str) and u.startswith('http')]
        title = (g.get('name') or '').strip()
        if not title or not embeds:
            continue
        league = (g.get('league') or '').strip()
        cat = (g.get('category') or '').lower()
        sport = _SR_SPORT.get(cat, cat)
        ts = int(g.get('match_timestamp') or 0)
        live = bool(g.get('live_sources'))
        links = []
        for i, u in enumerate(embeds[:3]):
            q = re.search(r'(540p|720p|1080p|2160p)', u)
            links.append({'label': 'Server %d%s' % (i + 1, (' ' + q.group(1)) if q else ''), 'url': u})
        out.append({'prov': 'sr', 'title': title, 'league': league, 'sport_slug': slug_for(sport, league, title),
                    'start_ts': ts, 'is_live': live or (_live_window(ts) if ts else False), 'links': links})
    return out


_PT_COMP = {   # pitsport.st competition slug -> (sport word for slug_for, league)
    'nba': ('basketball', 'NBA'), 'wnba': ('basketball', 'WNBA'), 'mlb': ('baseball', 'MLB'), 'nhl': ('hockey', 'NHL'),
    'nfl': ('american football', 'NFL'), 'cfl': ('canadian football', 'CFL'),
    'formula-1': ('motorsport', 'Formula 1'), 'formula-2': ('motorsport', 'Formula 2'), 'formula-3': ('motorsport', 'Formula 3'),
    'motogp': ('motorsport', 'MotoGP'), 'moto2': ('motorsport', 'MotoGP'), 'moto3': ('motorsport', 'MotoGP'),
}


def _fetch_pitsport():
    """pitsport.st/api/v1/live-now: {'data': {'live': [...], 'upcoming': [...]}}, each {programId, titleText, sessionStart,
    competitionSlug, hasVideo, liveState}. A game's link is its program page: the shared resolver (PitSport) asks for the player."""
    data = (_get(_listing_url('pt'), timeout=15, headers={'Referer': 'https://pitsport.st/'}).json() or {}).get('data') or {}
    out, seen = [], set()
    for state in ('live', 'upcoming'):
        for g in data.get(state) or []:
            pid, title = g.get('programId'), (g.get('titleText') or '').strip()
            if not pid or not title or pid in seen or not g.get('hasVideo', True):
                continue
            seen.add(pid)
            title = re.sub(r'\s+at\s+', ' vs ', title)
            comp = g.get('competitionSlug') or ''
            sport, league = _PT_COMP.get(comp, ('', (g.get('footer') or comp or '').strip()))
            if not sport:
                sport = 'soccer' if re.search(r'\bvs\b', title) and comp not in ('nascar',) else ''
            ts = int(g.get('sessionStart') or 0)
            out.append({'prov': 'pt', 'title': title, 'league': league, 'sport_slug': slug_for(sport, league, title),
                        'start_ts': ts, 'is_live': state == 'live' or g.get('liveState') == 'live',
                        'links': [{'label': 'PitSport', 'url': 'https://pitsport.st/programs/%s' % pid}]})
    return out


_LL_SPORT = {'football': 'soccer', 'ice hockey': 'hockey'}      # livelive24's own category words


def _fetch_livelive():
    """livelive24.com/test/ntv/ntv.json: [{title, category, tournament, date (ms), live, sources: [{url: .../live24.html?url=<slug>,
    channelName}]}]. A stream is the embedsports.me page of its slug (the shared player page; opened by _resolve_embedsports_me)."""
    data = _get(_listing_url('ll'), timeout=12, headers={'Referer': 'https://livelive24.com/'}).json()
    out = []
    for g in data if isinstance(data, list) else []:
        title = (g.get('title') or '').strip()
        links = []
        for i, so in enumerate((g.get('sources') or [])[:4]):
            m = re.search(r'[?&]url=([\w.-]+)', so.get('url') or '')
            if m:
                links.append({'label': (so.get('channelName') or 'Stream %d' % (i + 1)).strip(),
                              'url': 'https://embedsports.me/a/%s' % m.group(1)})
        if not title or not links:
            continue
        cat = (g.get('category') or '').lower().strip()
        league = (g.get('tournament') or '').strip()
        ts = int((g.get('date') or 0) / 1000)
        live = bool(g.get('live')) or g.get('status') == 'live'
        out.append({'prov': 'll', 'title': title, 'league': league, 'sport_slug': slug_for(_LL_SPORT.get(cat, cat), league, title),
                    'start_ts': ts, 'is_live': live or (_live_window(ts) if ts else False), 'links': links})
    return out


_RE_SO_LINE = re.compile(r'^(\d{1,2}:\d{2})\s+(.+?)\s*\|\s*(https?://\S+)')


def _fetch_sportsonline():
    r = _get(_listing_url('so'), timeout=15)
    r.encoding = 'utf-8'
    out = []
    import calendar
    now = time.gmtime()
    for line in r.text.splitlines():
        m = _RE_SO_LINE.match(line.strip())
        if not m:
            continue
        hhmm, raw, url = m.group(1), m.group(2).strip(), m.group(3)
        league, title = '', raw
        if ':' in raw:
            league, title = [x.strip() for x in raw.split(':', 1)]
        title = re.sub(r'\s+x\s+', ' vs ', title)
        try:
            hh, mm = [int(x) for x in hhmm.split(':')]
            ts = _london_to_utc(now.tm_year, now.tm_mon, now.tm_mday, hh, mm)
        except Exception:
            ts = 0
        chan = re.search(r'/([A-Za-z0-9_-]+)\.php', url)
        out.append({'prov': 'so', 'title': title, 'league': league,
                    'sport_slug': _slug_from_league_text(league, title),
                    'start_ts': ts, 'is_live': _live_window(ts),
                    'links': [{'label': 'SportsOnline %s' % (chan.group(1).upper() if chan else ''), 'url': url}]})
    return out


@_coalesced
def _all_matches():
    c = _cache()
    ck = 'livesite_matches_v1'
    cached = c.get(ck)
    if cached is not None:
        return cached
    jobs = {'sz': lambda: _fetch_matches_shape('sz'), 'ts': lambda: _fetch_matches_shape('ts'),
            'fe': _fetch_flyembed, 'so': _fetch_sportsonline, 'sr': _fetch_streamfree, 'pt': _fetch_pitsport, 'll': _fetch_livelive}      # (streamed.pk closed down: its page now says so)
    matches = []
    ex = ThreadPoolExecutor(max_workers=6)
    futs = {k: ex.submit(fn) for k, fn in jobs.items()}
    ex.shutdown(wait=False)
    # One shared 7s window (each provider used to be waited on for up to 18s in turn - the
    # slowest one alone set the time of every sports listing). A provider that misses the
    # window, or errors, falls back to its own last good listing (kept 30 min), so a slow
    # provider costs a little freshness instead of the whole wait.
    deadline = time.time() + 7
    for k, f in futs.items():
        got = None
        try:
            got = f.result(timeout=max(0.05, deadline - time.time()))
            if got:
                c.set('livesite_last_%s' % k, got, 30 * 60)
        except Exception as e:
            _log('%s listing error: %s' % (k, e or type(e).__name__), xbmc.LOGWARNING)
        if not got:
            got = c.get('livesite_last_%s' % k) or []
        matches += got
    c.set(ck, matches, 3 * 60 if matches else 60)
    _log('%d matches across %s' % (len(matches), sorted({m['prov'] for m in matches})))
    return matches


# ── public: events ────────────────────────────────────────────────────────────

def event_path(sport_slug, title):
    return PATH_PREFIX + quote('%s|%s' % (sport_slug, title), safe='')


def parse_event_path(path):
    """-> (sport_slug, title) or (None, None)."""
    if not path or not path.startswith(PATH_PREFIX):
        return None, None
    try:
        slug, title = unquote(path[len(PATH_PREFIX):]).split('|', 1)
        return slug, title
    except Exception:
        return None, None


def events_for_slug(sport_slug):
    """Events for one sport slug, one per distinct game (providers that list
    the same game are collapsed into one event; stream links are re-gathered
    from every provider by title at play time)."""
    try:
        matches = _all_matches()
    except Exception as e:
        _log('events error: %s' % e, xbmc.LOGWARNING)
        return []
    wanted = {sport_slug}
    if sport_slug == 'hockey':
        wanted.add('nhl')
    events, kept = [], []
    for m in matches:
        if m['sport_slug'] not in wanted:
            continue
        dup = None
        for i, k in enumerate(kept):
            if titles_match(m['title'], k['title']):
                dup = i
                break
        if dup is not None:
            events[dup]['is_live'] = events[dup]['is_live'] or m['is_live']
            continue
        kept.append(m)
        eid = 'livesite_' + hashlib.md5(('%s|%s|%s' % (m['sport_slug'], m['title'], m['start_ts'] // 86400)).encode('utf-8')).hexdigest()[:12]
        league = m['league'] or sport_slug.upper()
        if m['sport_slug'] in ('hockey', 'nhl'):
            league = _hockey_league(league)
        events.append({
            'id': eid, 'slug': eid, 'path': event_path(sport_slug, m['title']),
            'title': m['title'], 'league': league,
            'logo': '', 'is_live': m['is_live'], 'start_ts': m['start_ts'],
            'datetime': '', 'date_label': '',
        })
    return events


# ── stream extraction (generic embed-page decoder) ────────────────────────────

def _econfig(html):
    m = re.search(r"window\._econfig\s*=\s*'([^']+)'", html)
    if not m:
        return None
    try:
        s = base64.b64decode(m.group(1)).decode('utf-8')
        size = math.ceil(len(s) / 4)
        chunks = [s[i * size:(i + 1) * size] for i in range(4)]
        perm = [2, 0, 3, 1]
        out = [''] * 4
        for i, p in enumerate(perm):
            c = chunks[i]
            out[p] = base64.b64decode(c[:3] + c[4:]).decode('utf-8')
        cfg = json.loads(base64.b64decode(''.join(out)).decode('utf-8'))
        u = cfg.get('stream_url') or cfg.get('url_nop2p') or cfg.get('stream_url_nop2p')
        return re.sub(r'(?<!:)/{2,}', '/', u) if u else None
    except Exception:
        return None


def _pp_config(html):
    i = html.find('PP_CLAPPR_CONFIG')
    if i < 0:
        return None
    j = html.find('{', i)
    if j < 0:
        return None
    try:
        cfg, _ = json.JSONDecoder().raw_decode(html[j:])
        return cfg.get('srcBase') or cfg.get('src')
    except Exception:
        return None


_RE_XOR = re.compile(
    r'var\s+\w+\s*=\s*\[([\d,\s]+)\]\s*,\s*\w+\s*=\s*(\d+)\s*,\s*\w+\s*=\s*(\d+)\s*,'
    r'\s*\w+\s*=\s*""\s*,\s*\w+\s*;\s*for\s*\([^)]*\)\s*\{[^}]*?fromCharCode\('
    r'\(\(\s*\w+\[\w+\]\s*\^\s*\w+\s*\)\s*-\s*\w+\s*\+\s*(\d+)\s*\)\s*(?:&\s*(\d+)|%\s*(\d+))', re.S)


def _xor_payload(html):
    m = _RE_XOR.search(html)
    if not m:
        return None
    try:
        arr = [int(n) for n in m.group(1).split(',') if n.strip()]
        k1, k2, add = int(m.group(2)), int(m.group(3)), int(m.group(4))
        mask = int(m.group(5)) if m.group(5) else None
        mod = int(m.group(6)) if m.group(6) else None
        chars = []
        for n in arr:
            v = (n ^ k1) - k2 + add
            v = (v & mask) if mask is not None else (v % mod)
            chars.append(chr(v))
        dec = ''.join(chars)
    except Exception:
        return None
    mu = re.search(r'SIGNED_URL\s*=\s*"([^"]+)"', dec) or re.search(r'\burl\s*=\s*"([^"]+)"', dec)
    if not mu:
        return None
    try:
        u = json.loads('"' + mu.group(1) + '"')
    except Exception:
        u = mu.group(1).replace('\\/', '/')
    return re.sub(r'(?<!:)/{2,}', '/', u)


def _plain_m3u8(html):
    m = (re.search(r'src\s*=\s*"([^"]*\.m3u8[^"]*)"', html)
         or re.search(r'var\s+streamUrl\s*=\s*"([^"]+\.m3u8[^"]*)"', html)
         or re.search(r'"(?:file|source|src|url)"\s*:\s*"(https?:[^"]+\.m3u8[^"]*)"', html))
    if not m:
        return None
    return m.group(1).replace('\\/', '/')


def _extract_stream(html):
    return _econfig(html) or _pp_config(html) or _xor_payload(html) or _plain_m3u8(html)


_AD_HOSTS = ('histats', 'doubleclick', 'googletag', 'adsterra', 'popads', 'acscdn')


def _iframe_srcs(html, base):
    out = []
    for m in re.finditer(r'<iframe[^>]+src=["\']([^"\']+)', html, re.I):
        u = urljoin(base, m.group(1).strip())
        if u.startswith('//'):
            u = 'https:' + u
        if u.startswith('http') and not any(a in u for a in _AD_HOSTS):
            out.append(u)
    return out


def _origin(u):
    p = urlparse(u)
    return '%s://%s' % (p.scheme, p.netloc)


def _pipe(url, referer, origin=None):
    origin = origin or referer.rstrip('/')
    return '%s|User-Agent=%s&Referer=%s&Origin=%s' % (
        url, quote(UA, safe=''), quote(referer, safe=''), quote(origin, safe=''))


def _resolve_iframe_chain(link, hops=3):
    """Follow iframes from an event page until an embed page yields a stream.
    Returns a playable pipe-header URL, or None."""
    page_url, referer = link, link
    for _ in range(hops):
        r = _get(page_url, headers={'Referer': referer})
        html = r.text or ''
        found = _extract_stream(html)
        if found:
            org = _origin(r.url)
            return _pipe(found, org + '/', org)
        srcs = _iframe_srcs(html, r.url)
        if not srcs:
            return None
        page_url, referer = srcs[0], r.url
    return None


# Referer note (confirmed live against real playlists AND segments): the
# sportzone CDN returns 200 for the playlist with any Referer but 403 for the
# segments unless the Referer is the EMBED page's own origin (lineagest.click
# etc.) — the tursatrueper.xyz Referer the original handlers hardcode gets
# every segment 403'd on that CDN. The topsurge CDN accepts anything, so the
# embed origin is used for both.

def _resolve_nizar(link):
    """nizar.nexa.st/ch?id=N -> /api/player.php -> embed page -> _econfig."""
    m = re.search(r'id=(\d+)', link)
    if not m:
        return None
    org = _origin(link)
    pd = _get('%s/api/player.php?id=%s' % (org, m.group(1)),
              headers={'Referer': org + '/', 'Origin': org}).json()
    embed = pd.get('url')
    if not embed:
        return None
    html = _get(embed, headers={'Referer': org + '/'}).text or ''
    found = _extract_stream(html)
    if not found:
        return None
    eo = _origin(embed)
    return _pipe(found, eo + '/', eo)


def _resolve_kora(link):
    """*.kora.st/channel.php?id=N -> /api/player.php -> player page -> PP_CLAPPR_CONFIG."""
    page = _get(link, headers={'Referer': link}).text or ''
    m = re.search(r'window\.loadPlayerChannel\((\d+)\)', page)
    if not m:
        found = _extract_stream(page)
        return _pipe(found, _origin(link) + '/') if found else None
    org = _origin(link)
    pd = _get('%s/api/player.php?id=%s' % (org, m.group(1)), headers={'Referer': link}).json()
    embed = pd.get('url')
    if not embed:
        return None
    html = _get(embed, headers={'Referer': org + '/'}, timeout=15).text or ''
    found = _extract_stream(html)
    if not found:
        return None
    eo = _origin(embed)
    return _pipe(found, eo + '/', eo)


_XYZ_SECRET = b'MySuperSecretKey123!'
_XYZ_SERVERS = ('xyzstreams.space', 'eu-4605069466.duckdns.org', 'hls.fancy-shark151.workers.dev')


def _resolve_xyzstreams(link):
    """xyzstreams.st/embedserver2?<id> -> https://<server>/<id>/mono.ts.m3u8?server=2&token=<t>.
    The player page fetches /api/token (AES-256-CBC, key = SHA256 of a constant baked into the page)
    and sends the decrypted token as x-token; the same token also works as a ?token= query parameter,
    which is what lets a plain player (no custom headers) open it."""
    sid = urlparse(link).query.split('&')[0]
    if not sid:
        return None
    try:
        import pyaes
    except Exception:
        return None
    key = hashlib.sha256(_XYZ_SECRET).digest()
    org = _origin(link)
    for host in _XYZ_SERVERS:
        try:
            d = _get('https://%s/api/token' % host, headers={'Referer': org + '/'}, timeout=6).json()
            dec = pyaes.Decrypter(pyaes.AESModeOfOperationCBC(key, bytes.fromhex(d['iv'])))
            raw = dec.feed(bytes.fromhex(d['token'])) + dec.feed()
            tok = ''.join(c for c in raw.decode('utf-8', 'ignore') if 32 <= ord(c) < 127).strip()
            if not tok:
                continue
            url = 'https://%s/%s/mono.ts.m3u8?server=2&token=%s' % (host, sid, quote(tok, safe=''))
            r = _get(url, headers={'Referer': org + '/', 'Origin': org}, timeout=7)
            if r.status_code == 200 and '#EXTM3U' in (r.text or '')[:200]:
                return _pipe(url, org + '/', org)
        except Exception as e:
            _log('xyzstreams %s: %s' % (host, e or type(e).__name__))
    return None


# embed.st and the embedsports.* family hand out their playlist through one small API: POST /fetch with a
# protobuf body {1: source, 2: id, 3: stream number} answers {1: <cipher>}; the cipher is base64 (alphabet shifted
# by a rotation over the 94 printable characters) holding a 12-byte nonce + ChaCha20-Poly1305 ciphertext, and the key is
# the value of the response header named in access-control-expose-headers. Only the keystream is needed to read it.
_EMBEDSPORTS_HOSTS = ('embedsports.top', 'pooembed', 'embedindia', 'taifood-blog')
_INDIANS_SECRET = {'embedindia': '679808d3e4c8a4068767e6f22dfe191318909a62e6601b8149c8e2fa29a5375e'}
_INDIANS_DEFAULT = '18866ebec06934ba03ad3387e9fc9ebfbf2ea2d0e9305c86797b66c62ee4f8a5'


def _rotl32(x, n):
    return ((x << n) & 0xFFFFFFFF) | (x >> (32 - n))


def _chacha20(key, nonce, data, counter=1):
    """RFC 8439 ChaCha20 stream (pure Python: no crypto library is needed on the Firestick)."""
    import struct
    k = struct.unpack('<8L', key)
    n = struct.unpack('<3L', nonce)
    out = bytearray()

    def qr(w, a, b, c, d):
        w[a] = (w[a] + w[b]) & 0xFFFFFFFF; w[d] = _rotl32(w[d] ^ w[a], 16)
        w[c] = (w[c] + w[d]) & 0xFFFFFFFF; w[b] = _rotl32(w[b] ^ w[c], 12)
        w[a] = (w[a] + w[b]) & 0xFFFFFFFF; w[d] = _rotl32(w[d] ^ w[a], 8)
        w[c] = (w[c] + w[d]) & 0xFFFFFFFF; w[b] = _rotl32(w[b] ^ w[c], 7)

    for off in range(0, len(data), 64):
        st = [0x61707865, 0x3320646e, 0x79622d32, 0x6b206574] + list(k) + [counter + off // 64] + list(n)
        w = st[:]
        for _ in range(10):
            qr(w, 0, 4, 8, 12); qr(w, 1, 5, 9, 13); qr(w, 2, 6, 10, 14); qr(w, 3, 7, 11, 15)
            qr(w, 0, 5, 10, 15); qr(w, 1, 6, 11, 12); qr(w, 2, 7, 8, 13); qr(w, 3, 4, 9, 14)
        block = struct.pack('<16L', *[(w[i] + st[i]) & 0xFFFFFFFF for i in range(16)])
        out += bytes(a ^ b for a, b in zip(data[off:off + 64], block))
    return bytes(out)


def _pb_varint(n):
    out = bytearray()
    while True:
        b = n & 0x7F
        n >>= 7
        out.append(b | 0x80 if n else b)
        if not n:
            return bytes(out)


def _pb_field(num, val):
    return bytes([(num << 3) | 2]) + _pb_varint(len(val)) + val


def _goat_decode(resp):
    """Playlist URL from a /fetch response, or None."""
    ac = resp.headers.get('access-control-expose-headers')
    key = resp.headers.get(ac) if ac else None
    c = resp.content
    if not key or not c:
        return None
    i, cipher = 0, None
    while i < len(c):
        tag = c[i]; i += 1
        length, shift = 0, 0
        while True:
            b = c[i]; i += 1
            length |= (b & 0x7F) << shift
            if not (b & 0x80):
                break
            shift += 7
        val = c[i:i + length]; i += length
        if tag >> 3 == 1:
            cipher = val
            break
    if cipher is None:
        return None
    dec = bytes(((b - 0x21 + 71) % 94) + 0x21 for b in cipher)
    raw = base64.b64decode(dec + b'=' * (-len(dec) % 4))
    if len(raw) < 29:
        return None
    return _chacha20(key.encode('utf-8'), raw[:12], raw[12:-16]).decode('utf-8', 'ignore').strip()


def _resolve_goat(link):
    """embed.st/embed/<source>/<id>/<n> and embedsports.top/... -> playable playlist URL (pipe headers)."""
    link = link.split('#')[0]
    p = urlparse(link)
    host = p.netloc.lower()
    origin = '%s://%s' % (p.scheme or 'https', p.netloc)
    seg = link.rstrip('/').split('/')
    hdr = {'User-Agent': UA, 'Referer': link, 'Origin': origin, 'Content-Type': 'application/octet-stream'}
    if 'embed.st' in host:
        body = _pb_field(1, seg[-3].encode()) + _pb_field(2, seg[-2].encode()) + _pb_field(3, seg[-1].encode())
    elif any(h in host for h in _EMBEDSPORTS_HOSTS):
        if any(h in host for h in ('pooembed', 'embedindia', 'taifood-blog')):
            body = _pb_field(1, '/'.join(seg[4:]).encode())
        else:
            body = _pb_field(1, seg[-3].encode()) + _pb_field(2, seg[-2].encode()) + _pb_field(3, seg[-1].encode())
        hdr['indians'] = next((v for k, v in _INDIANS_SECRET.items() if k in host), _INDIANS_DEFAULT)
    else:
        return None
    r = requests.post(origin + '/fetch', data=body, headers=hdr, timeout=_TIMEOUT)
    url = _goat_decode(r)
    if not url or not url.startswith('http'):
        return None
    return _pipe(url, origin + '/', origin)


def _embedsports_jw(s, p, d, link):
    """The embedsports.me player variant that keeps its settings in window.SecKeyPlayerConfig: a session request (answered with
    the device id the playlist is bound to) opens the playlist, whose segments and key are served for the player page's address."""
    m = re.search(r'SecKeyPlayerConfig\["[^"]+"\]=(\{.*?\});</script>', p, re.S)
    if not m:
        return None
    c = json.loads(m.group(1))

    def b64(x):
        return base64.b64decode(x).decode('utf-8', 'replace')

    origin = 'https://%s' % d['pldm']
    q = '&'.join('%s=%s' % (k, quote(str(v), safe='')) for k, v in (
        ('scode', c['sCode']), ('stream', c['strUnqId']), ('expires', c['expireTs']), ('u_id', c['device_id']),
        ('session_id', c['session_id']), ('host_id', c.get('edgeHostId') or '')))
    r = s.get('%s?%s' % (b64(c['secTokenUrl']), q), headers={'Accept': 'application/json', 'X-CSRF-Auth': b64(c['csrf_token']),
                                                              'Referer': origin + '/', 'Origin': origin}, timeout=_TIMEOUT)
    j = r.json() if r.status_code == 200 else {}
    if not j.get('success', True):
        return None
    dev = j.get('device_id') or c['device_id']
    piped = _pipe(c['urlSource'].split('?')[0] + '?u_id=' + quote(dev, safe=''), origin + '/', origin)
    try:
        from starfleetscrapers.sports import local_proxy as _lp
        return _lp.wrap_hls_always(piped)
    except Exception:
        return piped


def _resolve_embedsports_me(link, referer='https://playoffsstream.com/'):
    """embedsports.me/<sport>/<channel> -> HLS master playlist. The page names a player host and carries one-time
    tokens; the player iframe it builds then carries a session request whose answer completes the playlist address."""
    from urllib.parse import urlencode
    s = requests.Session()
    s.headers['User-Agent'] = UA
    page = s.get(link, headers={'Referer': referer}, timeout=_TIMEOUT).text
    d = dict(re.findall(r'data-(pldm|pid|play|player|gc)="([^"]*)"', page))
    m = re.search(r'const siteConfig = (\{.*?\});', page, re.S)
    if not d or not m:
        return None
    cfg = json.loads(m.group(1))
    q = urlencode({'pid': d['pid'], 'v': d['play'], 'player': d['player'], 'csrf': cfg['csrf'], 'csrf_ip': cfg['csrf_ip'],
                   'expires': cfg['sec_expires'], 'sec_hash': cfg['sec_hash']})
    pl = 'https://%s/sd0embed/%s?%s' % (d['pldm'], d['gc'], q)
    p = s.get(pl, headers={'Referer': link}, timeout=_TIMEOUT).text
    if 'SecKeyPlayerConfig' in p:
        return _embedsports_jw(s, p, d, link)

    def b64(x):
        return base64.b64decode(x).decode('utf-8', 'replace')

    base = b64(re.search(r',d=e\("([^"]+)"\)', p).group(1))
    codes = re.search(r'R=e\(String\.fromCharCode\(\.\.\.\[([\d,]+)\]\)\)', p).group(1)
    manifest = b64(''.join(chr(int(x)) for x in codes.split(',')))
    csrf = b64(re.search(r'"X-CSRF-Auth":e\("([^"]+)"\)', p).group(1))
    stream = re.search(r',E="([^"]+)"', p).group(1)
    ts = re.search(r',s=parseInt\((\d+),10\)', p).group(1)
    dev = re.search(r',_="([^"]+)"', p).group(1)
    scode = re.search(r'scode:"([^"]+)"', p).group(1)
    sess = re.search(r'session_id:"([^"]+)"', p).group(1)
    host = re.search(r'encodeURIComponent\("([^"]+)"\)', p[p.find('function u('):]).group(1)
    u = '%s?scode=%s&stream=%s&expires=%s&u_id=%s&session_id=%s&host_id=%s' % (
        base, quote(scode, safe=''), quote(stream, safe=''), ts, quote(dev, safe=''), quote(sess, safe=''), quote(host, safe=''))
    origin = 'https://%s' % d['pldm']
    r = s.get(u, headers={'Accept': 'application/json', 'X-CSRF-Auth': csrf, 'Referer': origin + '/', 'Origin': origin},
              timeout=_TIMEOUT)
    j = r.json()
    if not j.get('device_id'):
        return None
    piped = _pipe(manifest.split('?')[0] + '?u_id=' + quote(j['device_id'], safe=''), origin + '/', origin)
    # the playlist address ends in .ts, so the player would open it as raw video: serve it as HLS through the relay
    try:
        from starfleetscrapers.sports import local_proxy as _lp
        return _lp.wrap_hls_always(piped)
    except Exception:
        return piped


def _resolve_streamed_api(link):
    """https://streamed.pk/api/stream/<source>/<id> -> first embed that resolves (HD first)."""
    r = _get(link, headers={'Referer': 'https://streamed.pk/'}, timeout=8)
    streams = r.json() if r.status_code == 200 else []
    streams = sorted(streams or [], key=lambda s: (not s.get('hd'), -(s.get('viewers') or 0)))
    for st in streams[:3]:
        emb = st.get('embedUrl')
        if not emb:
            continue
        try:
            out = _resolve_goat(emb)
        except Exception as e:
            _log('streamed embed %s: %s' % (emb[-40:], e or type(e).__name__))
            continue
        if out:
            return out
    return None


def _still_alive(piped_url):
    """False only when the playlist itself answers 4xx/5xx (a dead/offline or
    geo-blocked channel — e.g. sportzone's Finnish MTV feed 404s all day).
    Network errors/timeouts keep the link rather than over-pruning. These
    playlists are time-signed, not one-shot: confirmed re-fetchable 4x in a row
    with 200 each time, so this check doesn't consume the link."""
    base, _, hdr = piped_url.partition('|')
    headers = {}
    for kv in hdr.split('&'):
        if '=' in kv:
            k, v = kv.split('=', 1)
            headers[k] = unquote(v)
    try:
        r = requests.get(base, headers=headers, timeout=6, stream=True)
        code = r.status_code
        r.close()
        return code < 400
    except Exception:
        return True


def resolve_link(url):
    host = urlparse(url).netloc.lower()
    try:
        if 'nexa.st' in host:
            out = _resolve_nizar(url)
        elif 'kora.st' in host:
            out = _resolve_kora(url)
        elif 'xyzstreams.' in host:
            out = _resolve_xyzstreams(url)
        elif 'embedsports.me' in host:
            out = _resolve_embedsports_me(url)
        elif host == 'embed.st' or host.endswith('.embed.st') or any(h in host for h in _EMBEDSPORTS_HOSTS):
            out = _resolve_goat(url)
        elif 'streamed.pk' in host and '/api/stream/' in url:
            out = _resolve_streamed_api(url)
        else:
            out = _resolve_iframe_chain(url)
        if not out:
            # second opinion: the shared Starfleet resolver add-on (more host families, same headers convention)
            try:
                import starfleetresolve as _sfr
                out = _sfr.resolve(url, use_resolveurl=False, generic=False)
            except Exception:
                out = None
        if out and not _still_alive(out):
            _log('dropping dead link (%s)' % host)
            return None
        return out
    except Exception as e:
        _log('resolve error (%s): %s' % (host, e or type(e).__name__), xbmc.LOGWARNING)
        return None


# ── public: streams ───────────────────────────────────────────────────────────

_MAX_LINKS = 16


def _segment_ok(piped_url, timeout=8):
    """True when a media segment of this playlist can really be fetched. A playlist that answers 200 can still list
    segments the CDN refuses (a feed that is not on air yet, an expired token); only the start of a segment is read."""
    base, _, tail = piped_url.partition('|')
    if base.startswith('http://127.0.0.1') or base.startswith('http://localhost'):
        return True
    headers = {'User-Agent': UA}
    for kv in tail.split('&'):
        if '=' in kv:
            k, v = kv.split('=', 1)
            headers[k] = unquote(v)
    try:
        r = requests.get(base, headers=headers, timeout=timeout)
        txt = r.text or ''
        if r.status_code != 200 or '#EXTM3U' not in txt[:60]:
            return False
        if 'EXT-X-STREAM-INF' in txt:
            nxt = [l for l in txt.splitlines() if l and not l.startswith('#')]
            if not nxt:
                return False
            r = requests.get(urljoin(r.url, nxt[0]), headers=headers, timeout=timeout)
            txt = r.text or ''
        segs = [l for l in txt.splitlines() if l and not l.startswith('#')]
        if not segs:
            return False
        seg = segs[-2] if len(segs) > 2 else segs[-1]      # the newest one may not be on the CDN yet
        h2 = dict(headers, Range='bytes=0-2047')
        s = requests.get(urljoin(r.url, seg), headers=h2, timeout=timeout, stream=True)
        try:
            return s.status_code in (200, 206) and len(next(s.iter_content(1024), b'')) > 0
        finally:
            s.close()
    except (requests.Timeout, requests.ConnectionError):
        return True          # a slow answer does not say the feed is off the air: keep the link (as _still_alive does)
    except Exception:
        return False


def _resolve_page_link(url, depth=0):
    """A schedule-page provider's game page -> playable stream (see sports_pages_live)."""
    from starfleetscrapers.sports import sports_pages_live as _sp
    res = _sp.resolve_page(url)
    if not res:
        return None
    kind, val = res
    if kind == 'stream':
        out = val if _still_alive(val) else None
    else:
        out = resolve_link(val) if depth == 0 else None
    if out and not _segment_ok(out):
        _log('dropping link whose segments are not available (%s)' % urlparse(url).netloc)
        return None
    return out


def streams_by_title(sport_slug, title, include_pages=True):
    """Every provider link for the game whose title matches `title`, resolved
    in parallel under one deadline. Returns stream dicts."""
    if not title:
        return []
    # the game-page sites and the listing sites are independent: look them up side by side
    from starfleetscrapers.sports import sports_pages_live as _sp
    _pex = ThreadPoolExecutor(max_workers=1)
    _pfut = _pex.submit(_sp.links_for, sport_slug, title, titles_match) if include_pages else None
    _pex.shutdown(wait=False)
    try:
        matches = _all_matches()
    except Exception:
        matches = []
    picked, seen = [], set()
    page_links = []
    try:
        if _pfut is not None:
            page_links = _pfut.result(timeout=12)
        for code, l in page_links:
            _SOURCE_LABEL.setdefault(code, _sp.LABEL.get(code, code))
    except Exception as e:
        _log('page providers: %s' % (e or type(e).__name__), xbmc.LOGINFO)
    for m in matches:
        if not titles_match(title, m['title']):
            continue
        # a match from a clearly different sport slug is a false positive
        if sport_slug in ('nfl', 'cfb', 'cfl', 'mlb', 'nba', 'ncaab', 'nhl', 'soccer') \
                and m['sport_slug'] not in (sport_slug, 'other_international', 'hockey') \
                and not (sport_slug == 'nhl' and m['sport_slug'] == 'hockey') \
                and not (sport_slug in ('nfl', 'cfb') and m['sport_slug'] in ('nfl', 'cfb')):
            continue
        for l in m['links']:
            if l['url'] in seen:
                continue
            seen.add(l['url'])
            picked.append((m['prov'], l))
    for code, l in page_links:
        if l['url'] not in seen:
            seen.add(l['url'])
            picked.append((code, dict(l, page=True)))
    if not picked:
        return []
    # spread across providers first so one provider's many channels don't crowd out the rest
    by_prov = {}
    for prov, l in picked:
        by_prov.setdefault(prov, []).append(l)
    ordered = []
    # sites that usually give a working stream go first, so they are inside the cap and not left behind
    _prio = ['pv', 'pk', 'sr', 'pt', 'll', 'au', 'g2', 'vk', 'rs', 'tp', 'eh', 'ms', 'bt', 'st', 'tt', 'ih', 'ps', 'p7', 'se', 'bf', 'ss', 'sh', 'sc', 'sf', 'vg', 'tm',
             'sz', 'ts', 'fe', 'so']
    for prov in sorted(by_prov, key=lambda p: _prio.index(p) if p in _prio else len(_prio)):
        by_prov[prov] = by_prov.pop(prov)
    while len(ordered) < _MAX_LINKS and any(by_prov.values()):
        for prov in list(by_prov):
            if by_prov[prov] and len(ordered) < _MAX_LINKS:
                ordered.append((prov, by_prov[prov].pop(0)))
    out = []
    ex = ThreadPoolExecutor(max_workers=len(ordered))
    futs = {ex.submit(_resolve_page_link if l.get('page') else resolve_link, l['url']): (prov, l) for prov, l in ordered}
    ex.shutdown(wait=False)
    # Return as soon as there are enough working links: once 3 are resolved and 2.5s have
    # passed the rest get 2s more, then are left behind (measured: a UFC card took 11.5s
    # because two of ten embeds were slow, with eight links already usable after 3s).
    from concurrent.futures import wait as _wait, FIRST_COMPLETED as _FIRST
    t0 = time.time()
    pending = set(futs)
    quorum_at = None
    while pending:
        elapsed = time.time() - t0
        limit = 12.0
        if quorum_at is not None:
            limit = min(limit, quorum_at + 4.0)
        if elapsed >= limit:
            break
        done, pending = _wait(pending, timeout=limit - elapsed, return_when=_FIRST)
        for f in done:
            prov, l = futs[f]
            try:
                u = f.result()
            except Exception:
                u = None
            if u and u.split('|')[0] in {o['url'].split('|')[0] for o in out}:
                u = None     # two sites embedding the same player: list it once
            if u:
                out.append({'label': '%s - %s' % (_SOURCE_LABEL[prov], l['label']), 'url': u,
                            'quality': '', 'language': '', 'source': 'LiveSites-' + _SOURCE_LABEL[prov]})
        if quorum_at is None and len(out) >= 5 and time.time() - t0 >= 3.0:
            quorum_at = time.time() - t0
    if pending:
        _log('resolve stopped for "%s" (%d/%d links done)' % (title, len(out), len(ordered)))
    return out
