# -*- coding: utf-8 -*-
"""Live program-guide matching for the "Live TV - <country>" channels (DLHD / tvnow247 catalogues).

Those channels carry no guide data of their own. epgshare01.online publishes free XMLTV packs per
country (plus a few sports/regional ones), refreshed daily. At export time this module

  1. downloads the packs for the countries that are present (each cached for 12 hours),
  2. streams each pack once to read its channel names, and matches every exported channel to a pack
     channel by normalised name (same-country only),
  3. streams the pack again keeping only the programmes of matched channels in a window around "now",

and returns {entry key: epg channel id} plus a small XMLTV document. Nothing here depends on a
scraper-PC job, so the guide stays current by itself.
"""
import gzip
import os
import re
import time
import unicodedata

import xbmc

BASE = 'https://epgshare01.online/epgshare01/'
_PACK_CACHE_SECS = 12 * 3600
_WINDOW_BEFORE = 3 * 3600        # keep programmes that ended no earlier than 3 h ago ...
_WINDOW_AFTER = 60 * 3600        # ... and start within the next 60 h

# country code (as the catalogues use it) -> extra / alternative pack names
_COUNTRY_PACKS = {
    'US': ['US2', 'US_LOCALS1', 'US_SPORTS1', 'DIRECTVSPORTS1', 'PLEX1', 'DISTROTV1', 'RAKUTEN1', 'TBNPLUS1', 'RALLY_TV1',
           'WHALETVPLUS1', 'MUSICBOX1', 'DELUXEMUSIC1', 'PEACOCK1'],
    'GB': ['UK1'], 'UK': ['UK1'],
    'CA': ['CA2'],
}
# packs worth adding when a channel title mentions the brand
_BRAND_PACKS = {'bein': 'BEIN1', 'jazeera': 'ALJAZEERA1', 'sport klub': 'SPORTKLUB1', 'sportklub': 'SPORTKLUB1'}

_COUNTRY_WORDS = {'usa', 'us', 'uk', 'gb', 'canada', 'ca', 'france', 'fr', 'germany', 'de', 'spain', 'es', 'italy', 'it',
                  'portugal', 'pt', 'poland', 'pl', 'brazil', 'br', 'brasil', 'mexico', 'mx', 'israel', 'il', 'greece', 'gr',
                  'romania', 'ro', 'serbia', 'rs', 'denmark', 'dk', 'netherlands', 'nl', 'australia', 'au', 'india', 'in',
                  'east', 'west', 'hd', 'sd', 'fhd', 'uhd', '4k', 'live', 'channel', 'tv', 'television', 'network', 'plus'}

_RE_NON = re.compile(r'[^a-z0-9 ]')
_RE_CALL = re.compile(r'[wk][a-z]{2,3}')


_NUM_WORDS = {'one': '1', 'two': '2', 'three': '3', 'four': '4', 'five': '5', 'six': '6', 'seven': '7', 'eight': '8',
              'nine': '9', 'ten': '10', 'uno': '1', 'dos': '2', 'tres': '3'}
_MINOR = {'international', 'east', 'west', 'pacific', 'feed', 'national', 'alternate', 'premium', 'extra', 'plus', 'hd',
          'sd', 'channel', 'network', 'tv'}
# national networks whose pack entry is "<name> National Feed"
_NETWORK_ALIAS = {'abc': 'abc national feed', 'nbc': 'nbc national feed', 'cbs': 'cbs national feed',
                  'fox': 'fox national feed', 'pbs': 'pbs national feed', 'cw': 'cw national feed'}


# listing tags that are not part of a channel's name: "[Geo-blocked]", "[Not 24/7]", "(United States)", "(Canada)"
_RE_TAGS = re.compile(r'\[[^\]]*\]|\((?:united states|usa|us|u\.s\.|united kingdom|uk|canada|ca|hd|sd)\)')
_RE_COUNTRY_PHRASE = re.compile(r'(?:united states|united kingdom)')


def _norm(name):
    n = _RE_COUNTRY_PHRASE.sub(' ', _RE_TAGS.sub(' ', (name or '').lower()))
    n = unicodedata.normalize('NFD', n)
    n = ''.join(c for c in n if unicodedata.category(c) != 'Mn')
    n = n.replace('+', ' plus ').replace('&', ' and ')
    n = _RE_NON.sub(' ', n)
    words = [_NUM_WORDS.get(w, w) for w in n.split() if w not in _COUNTRY_WORDS]
    return ' '.join(words)


def _score(a, b):
    aw, bw = set(a.split()), set(b.split())
    if not aw or not bw:
        return 0.0
    if a == b or a.replace(' ', '') == b.replace(' ', ''):
        return 1.0
    inter = aw & bw
    base = len(inter) / max(len(aw), len(bw))
    # one name is the other plus at most one extra word ("Arena Sport 1" / "Arena Sport 1 Premium")
    if inter and (aw <= bw or bw <= aw):
        extra = (bw - aw) if aw <= bw else (aw - bw)
        if len(extra) <= 1 and (len(inter) >= 2 or extra <= _MINOR):
            base = max(base, 0.85)
    return base


def _cache_dir():
    import xbmcvfs
    d = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.starfleet/epgcache/')
    if not xbmcvfs.exists(d):
        xbmcvfs.mkdirs(d)
    return d


def _available_packs():
    """Names of the packs on the server (cached 24 h in a small file)."""
    path = os.path.join(_cache_dir(), '_packs.txt')
    try:
        if os.path.exists(path) and time.time() - os.path.getmtime(path) < 24 * 3600:
            with open(path, 'r', encoding='utf-8') as f:
                names = [l.strip() for l in f if l.strip()]
            if names:
                return names
    except Exception:
        pass
    from starfleetscrapers.core import http as requests
    try:
        t = requests.get(BASE, timeout=20).text
        names = re.findall(r'epg_ripper_([A-Za-z0-9_.-]+?)\.xml\.gz', t)
    except Exception as e:
        xbmc.log('[Starfleet/EPG] pack list error: %s' % e, xbmc.LOGWARNING)
        names = []
    if names:
        try:
            with open(path, 'w', encoding='utf-8') as f:
                f.write('\n'.join(dict.fromkeys(names)))
        except Exception:
            pass
    return names


def _max_pack_mb():
    """The biggest guide pack (compressed) worth fetching and scanning on this device. The packs run from 1 to 55 MB: the biggest
    (US local stations) is half a gigabyte of XML once unpacked, which a Fire TV Stick can neither hold nor scan in reasonable time."""
    try:
        from starfleetscrapers.core import device
        return {'low': 10, 'mid': 25, 'high': 80}.get(device.profile().get('tier'), 25)
    except Exception:
        return 25


def _pack_file(name):
    """Local .xml.gz of a pack, downloaded if missing or older than 12 h ('' on failure)."""
    path = os.path.join(_cache_dir(), 'epg_%s.xml.gz' % name)
    try:
        if os.path.exists(path) and time.time() - os.path.getmtime(path) < _PACK_CACHE_SECS:
            return path
    except Exception:
        pass
    from starfleetscrapers.core import http as requests
    try:
        r = requests.get('%sepg_ripper_%s.xml.gz' % (BASE, name), timeout=(8, 90), stream=True)
        if r.status_code != 200:
            return path if os.path.exists(path) else ''
        try:
            size_mb = int(r.headers.get('Content-Length') or 0) / 1048576.0
        except ValueError:
            size_mb = 0
        if size_mb > _max_pack_mb():
            r.close()
            xbmc.log('[Starfleet/EPG] pack %s is %.0f MB: too big for this device, skipped' % (name, size_mb), xbmc.LOGINFO)
            return ''
        tmp = path + '.part'
        with open(tmp, 'wb') as f:
            for chunk in r.iter_content(1 << 16):
                f.write(chunk)
        os.replace(tmp, path)
        return path
    except Exception as e:
        xbmc.log('[Starfleet/EPG] pack %s download failed: %s' % (name, e), xbmc.LOGWARNING)
        return path if os.path.exists(path) else ''


def _pack_channels(path):
    """{channel id: [display names]} read by streaming the pack."""
    import xml.etree.ElementTree as ET
    out = {}
    try:
        with gzip.open(path, 'rb') as f:
            for ev, el in ET.iterparse(f, events=('end',)):
                if el.tag == 'channel':
                    names = [(d.text or '').strip() for d in el.findall('display-name')]
                    out[el.get('id')] = [n for n in names if n]
                    el.clear()
                elif el.tag == 'programme':
                    break               # channels come first in these files
    except Exception as e:
        xbmc.log('[Starfleet/EPG] channel scan failed (%s): %s' % (os.path.basename(path), e), xbmc.LOGWARNING)
    return out


def _xmltv_ts(s):
    """'20261010143000 +0000' -> epoch seconds (UTC)."""
    try:
        import calendar
        base = s.strip().split(' ')[0]
        t = time.strptime(base[:14], '%Y%m%d%H%M%S')
        secs = calendar.timegm(t)
        if ' ' in s.strip():
            off = s.strip().split(' ')[1]
            sign = -1 if off.startswith('-') else 1
            secs -= sign * (int(off[1:3]) * 3600 + int(off[3:5]) * 60)
        return secs
    except Exception:
        return 0


def _pack_programmes(path, wanted):
    """Programme elements (serialised) for the wanted channel ids, inside the time window."""
    import xml.etree.ElementTree as ET
    now = time.time()
    lo, hi = now - _WINDOW_BEFORE, now + _WINDOW_AFTER
    out = []
    try:
        with gzip.open(path, 'rb') as f:
            for ev, el in ET.iterparse(f, events=('end',)):
                if el.tag == 'programme':
                    if el.get('channel') in wanted:
                        stop, start = _xmltv_ts(el.get('stop', '')), _xmltv_ts(el.get('start', ''))
                        if stop >= lo and start <= hi:
                            out.append(ET.tostring(el, encoding='unicode'))
                    el.clear()
                elif el.tag == 'channel':
                    el.clear()
    except Exception as e:
        xbmc.log('[Starfleet/EPG] programme scan failed (%s): %s' % (os.path.basename(path), e), xbmc.LOGWARNING)
    return out


def _packs_for(country, titles, available):
    cc = (country or '').upper()
    names = list(_COUNTRY_PACKS.get(cc, []))
    for suffix in ('1', '2', '3'):
        names.append(cc + suffix)
    low = ' '.join(titles).lower()
    for brand, pack in _BRAND_PACKS.items():
        if brand in low:
            names.append(pack)
    return [n for n in dict.fromkeys(names) if n in available]


def build(channels):
    """channels: [(key, title, country)] -> ({key: epg_channel_id}, xmltv_bytes, stats).

    Same-country matching only: a channel is matched against the packs of its own country (and brand
    packs for beIN / Al Jazeera / Sport Klub titles)."""
    from concurrent.futures import ThreadPoolExecutor
    from xml.sax.saxutils import escape
    if not channels:
        return {}, b'', {}
    # the same channels were matched a moment ago (the guide is rebuilt only when something changed, or after six hours)
    import hashlib
    import json
    sig = hashlib.md5(json.dumps(sorted((str(k), t, c or '') for k, t, c in channels)).encode('utf-8')).hexdigest()[:16]
    base = os.path.join(_cache_dir(), 'build_%s' % sig)
    try:
        if time.time() - os.path.getmtime(base + '.json') < 6 * 3600:
            with open(base + '.json', 'r', encoding='utf-8') as f:
                ids = json.load(f)
            with open(base + '.xml', 'rb') as f:
                xml = f.read()
            return ids, xml, {'channels': len(channels), 'matched': len(ids), 'cached': True}
    except Exception:
        pass
    available = set(_available_packs())
    if not available:
        return {}, b'', {}

    by_country = {}
    for key, title, cc in channels:
        by_country.setdefault((cc or '').upper(), []).append((key, title))

    wanted_packs = {}
    for cc, items in by_country.items():
        for p in _packs_for(cc, [t for _k, t in items], available):
            wanted_packs.setdefault(p, set()).add(cc)
    if not wanted_packs:
        return {}, b'', {}

    pool = ThreadPoolExecutor(max_workers=4)
    try:
        files = dict(zip(wanted_packs, pool.map(_pack_file, list(wanted_packs))))
        chans = {p: (_pack_channels(f) if f else {}) for p, f in files.items()}
    finally:
        pool.shutdown(wait=False)

    matched = {}                    # key -> (pack, epg id, display name)
    for cc, items in by_country.items():
        packs = [p for p, ccs in wanted_packs.items() if cc in ccs]
        index = []                   # (normalised name, pack, id, display)
        for p in packs:
            for cid, names in chans.get(p, {}).items():
                for n in names[:3]:
                    nn = _norm(n)
                    if nn:
                        index.append((nn, p, cid, n))
        by_norm = {}
        by_call = {}                  # US station call sign (WJAC, KABC...) -> entry
        for nn, p, cid, n in index:
            by_norm.setdefault(nn, (p, cid, n))
            first = nn.split(' ', 1)[0]
            if _RE_CALL.fullmatch(first):
                by_call.setdefault(first, (p, cid, n))
        for key, title in items:
            q = _norm(title)
            if not q:
                continue
            hit = by_norm.get(q) or by_norm.get(_NETWORK_ALIAS.get(q, '#'))
            if not hit and cc == 'US':
                for tok in q.split():
                    if _RE_CALL.fullmatch(tok) and tok in by_call:
                        hit = by_call[tok]
                        break
            if not hit:
                best, best_s = None, 0.0
                for nn, p, cid, n in index:
                    s = _score(q, nn)
                    if s > best_s:
                        best, best_s = (p, cid, n), s
                if best and best_s >= 0.8:
                    hit = best
            if hit:
                matched[key] = hit

    wanted_by_pack = {}
    for key, (p, cid, _n) in matched.items():
        wanted_by_pack.setdefault(p, set()).add(cid)

    pool = ThreadPoolExecutor(max_workers=4)
    try:
        progs = dict(zip(wanted_by_pack, pool.map(lambda p: _pack_programmes(files[p], wanted_by_pack[p]), list(wanted_by_pack))))
    finally:
        pool.shutdown(wait=False)

    seen_ids, parts = set(), ['<?xml version="1.0" encoding="UTF-8"?>\n<tv generator-info-name="starfleet-live-epg">\n']
    n_prog = 0
    for key, (p, cid, name) in matched.items():
        if cid in seen_ids:
            continue
        seen_ids.add(cid)
        parts.append('<channel id="%s"><display-name>%s</display-name></channel>\n' % (escape(cid, {'"': '&quot;'}), escape(name)))
    for p, lst in progs.items():
        for x in lst:
            parts.append(x + '\n')
            n_prog += 1
    parts.append('</tv>\n')
    xml = ''.join(parts).encode('utf-8')
    ids = {key: cid for key, (p, cid, _n) in matched.items()}
    stats = {'channels': len(channels), 'matched': len(matched), 'programmes': n_prog, 'packs': sorted(wanted_packs)}
    xbmc.log('[Starfleet/EPG] live guide: %(matched)d of %(channels)d channels matched, %(programmes)d programmes, packs %(packs)s' % stats,
             xbmc.LOGINFO)
    try:
        for old in os.listdir(_cache_dir()):                    # only the latest result is kept
            if old.startswith('build_'):
                os.remove(os.path.join(_cache_dir(), old))
        with open(base + '.xml', 'wb') as f:
            f.write(xml)
        with open(base + '.json', 'w', encoding='utf-8') as f:
            json.dump(ids, f)
    except Exception:
        pass
    return ids, xml, stats
