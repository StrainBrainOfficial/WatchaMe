# -*- coding: utf-8 -*-
"""NOJHL (Northern Ontario Junior Hockey League) schedule and scores.

The league's website is a HockeyTech site; its pages call the HockeyTech feed (lscluster.hockeytech.com) with the public key the page itself
carries, and that is the feed read here: the games of the last two days and the next two weeks, with the score of a game in progress. The
games become events of the Hockey list, so My Teams finds them by team name like any other league."""
import calendar
import datetime
import re
import time

import requests
import xbmc

from starfleetscrapers.core import cache as _cache

_FEED = 'https://lscluster.hockeytech.com/feed/index.php'
_KEY = 'c1375ff55168bd71'          # the public key nojhl.com's own pages use
_UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36')
_LOGO = 'https://assets.leaguestat.com/nojhl/logos/50x50/'
LOGOS = {
    'Kirkland Lake Gold Miners': '17_44.png', 'Timmins Rock': '10.png', 'Soo Thunderbirds': '5_44.png', 'Hearst Lumberjacks': '19_44.jpg',
    'Powassan Voodoos': '22.png', 'Soo Eagles': '31.png', 'Espanola Paper Kings': '32_44.png', 'Blind River Beavers': '6.png',
    'Iroquois Falls Storm': '8_44.png', 'Elliot Lake Vikings': '23_44.png', 'French River Rapids': '30.png',
}


def _logo(name):
    f = LOGOS.get(name)
    return (_LOGO + f) if f else ''


def _start_ts(g):
    """Seconds since 1970 of the puck drop: the feed gives it as an ISO time with the Eastern offset."""
    iso = g.get('GameDateISO8601') or ''
    m = re.match(r'(\d{4})-(\d\d)-(\d\d)T(\d\d):(\d\d):(\d\d)([+-])(\d\d):(\d\d)$', iso)
    if not m:
        return 0
    y, mo, d, h, mi, s = (int(x) for x in m.groups()[:6])
    off = (int(m.group(8)) * 3600 + int(m.group(9)) * 60) * (1 if m.group(7) == '+' else -1)
    return calendar.timegm((y, mo, d, h, mi, s)) - off


def _games():
    ck = 'nojhl_scorebar'
    got = _cache.get(ck)
    if got is not None:
        return got
    r = requests.get(_FEED, params={
        'feed': 'modulekit', 'view': 'scorebar', 'key': _KEY, 'client_code': 'nojhl', 'numberofdaysahead': '14', 'numberofdaysback': '2',
        'limit': '1000', 'fmt': 'json', 'site_id': '2', 'lang': 'en', 'league_id': '1'},
        headers={'User-Agent': _UA, 'Referer': 'https://nojhl.com/'}, timeout=(5, 12))
    r.raise_for_status()
    games = (r.json().get('SiteKit') or {}).get('Scorebar') or []
    _cache.set(ck, games, 3 * 60)
    return games


def events():
    """The NOJHL games as events of the Hockey list."""
    try:
        games = _games()
    except Exception as e:
        xbmc.log('[Starfleet/Sports] NOJHL schedule error: %s' % e, xbmc.LOGWARNING)
        return []
    out = []
    now = time.time()
    for g in games:
        home, away = g.get('HomeLongName') or '', g.get('VisitorLongName') or ''
        if not home or not away:
            continue
        ts = _start_ts(g)
        status = str(g.get('GameStatus') or '')
        text = (g.get('GameStatusString') or '').strip()
        final = status == '4' or text.lower().startswith('final')
        # 1 = not started (the text is the start time), 2 / 3 = in progress; a game that should have started and has no result is on
        live = (not final) and (status in ('2', '3') or (ts and ts <= now and now - ts < 3.5 * 3600 and (g.get('Period') or '0') not in ('0', '')
                                                         and text.lower() not in ('', 'postponed', 'cancelled')))
        hg, vg = g.get('HomeGoals') or '0', g.get('VisitorGoals') or '0'
        score = '%s %s - %s %s' % (away, vg, hg, home) if (final or live) else ''
        gid = str(g.get('ID') or '')
        try:
            label = datetime.datetime.utcfromtimestamp(ts - 5 * 3600).strftime('%b %d').replace(' 0', ' ')
        except Exception:
            label = ''
        out.append({
            'id': 'nojhl_%s' % gid, 'slug': 'nojhl_%s' % gid, 'path': 'nojhl:%s' % gid,
            'title': '%s vs %s' % (away, home), 'match_title': '%s vs %s' % (away, home),
            'home_team': home, 'away_team': away, 'home_badge': _logo(home), 'away_badge': _logo(away), 'logo': _logo(home),
            'league': 'NOJHL', 'date_label': label, 'start_ts': ts, 'is_live': bool(live),
            'game_state': 'post' if final else ('in' if live else 'pre'), 'score_line': score,
            'score_detail': (g.get('PeriodNameLong') or '') + ((' ' + g.get('GameClock')) if g.get('GameClock') else '') if live else '',
        })
    return out
