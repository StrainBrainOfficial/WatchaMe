# -*- coding: utf-8 -*-
"""DLHD / DaddyLive channel resolver for the site's current "six player" layout.

watch.php?id=<N> lists up to six player buttons (/stream/, /cast/, /watch/, /plus/,
/casting/, /player/ + stream-<N>.php). Each one is a different wrapper around the same
channel, so each needs its own small decoder:

  stream / watch / hub   iframe -> page with  const SRC = "<m3u8>" (some edges also want a short-lived playlist token)
  cast             iframe -> page with  window._econfig='<4-chunk shuffled base64 json>'
  plus             iframe -> page with  var a=[bytes], k1, k2   (xor/sub obfuscated JS blob; the blob may name a token
                   address instead of the playlist: loadStreamUrl("<token url>"), whose reply is the playlist, xor-coded)
  casting          iframe -> iframe -> const streamUrls = ["<m3u8>", ...]
  player           open-ended hop chain (data-encoded base64, eval(atob()), f.src=..., iframes)

resolve_channel() returns the first playable result as
    {'url': 'https://...m3u8|Referer=..&Origin=..&User-Agent=..', 'player': 'cast', 'embed': url}
(a playlist that needs a playlist token comes back as a relay address that keeps the token fresh)
or None.  Network only, no JS execution.
"""
import base64
import html as _html
import json
import math
import queue
import re
import threading
import time
from urllib.parse import urljoin, urlparse, parse_qsl, quote_plus

from starfleetscrapers.core import http as requests
import xbmc

UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
      '(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36')
DEFAULT_BASE = 'https://thedaddy.li'
# the site's known addresses, newest first; any of them that is still up redirects to wherever it lives now
SEEDS = ('https://thedaddy.li', 'https://dlhd.pk', 'https://dlhd.st', 'https://thedaddy.pk', 'https://dlstreams.st', 'https://dlive.sx')
_TIMEOUT = (4, 9)
# the site throttles bursts (a handful of parallel resolves is enough to make it drop
# connections), so cap how many channel resolves hit it at once.
_GATE = threading.BoundedSemaphore(3)


_ACTIVE = {}


def active_base(seed=DEFAULT_BASE):
    """The site's current address: the seed answers with a redirect to wherever the site lives now (the domain changes every
    few weeks); when the seed is gone the other known addresses are asked. Kept 10 minutes; the seed itself when none can be
    reached."""
    seed = seed.rstrip('/')
    hit = _ACTIVE.get(seed)
    if hit and time.time() < hit[1]:
        return hit[0]
    base = seed
    ttl = 180                              # nothing reachable: do not wait for it again on every call
    for cand in [seed] + [c for c in SEEDS if c != seed]:
        try:
            r = requests.get(cand + '/', headers={'User-Agent': UA}, timeout=(4, 8), allow_redirects=True)
            if r.status_code == 200 and r.url:
                base = _origin(r.url)
                ttl = 600
                break
        except Exception as e:
            _log('active domain %s: %s' % (cand, str(e)[:100]))
    _ACTIVE[seed] = (base, time.time() + ttl)
    return base


def _log(msg):
    xbmc.log('[Starfleet/DLHD] %s' % msg, xbmc.LOGINFO)


def _origin(url):
    u = urlparse(url)
    return '%s://%s' % (u.scheme or 'https', u.netloc)


def _fetch(url, referer=None):
    headers = {'User-Agent': UA}
    if referer:
        headers['Referer'] = referer
    for attempt in (0, 1):
        try:
            return requests.get(url, headers=headers, timeout=_TIMEOUT).text
        except (requests.exceptions.ConnectTimeout, requests.exceptions.ConnectionError):
            # dlive.sx drops the odd connect under load; one quick retry is enough
            if attempt:
                raise


def _iframe_src(page, page_url):
    m = re.search(r'<iframe[^>]+src="([^"]+)"', page, re.I)
    if not m:
        return None
    return urljoin(page_url, _html.unescape(m.group(1)).strip())


# ── decoders ─────────────────────────────────────────────────────────────────

def decode_econfig(encoded):
    """base64 -> text split into 4 chunks -> each chunk loses its 4th char and is
    base64-decoded -> chunks re-ordered [2,0,3,1] and joined -> base64 json."""
    s = base64.b64decode(encoded).decode('utf-8')
    size = math.ceil(len(s) / 4)
    chunks = [s[i * size:(i + 1) * size] for i in range(4)]
    order = [2, 0, 3, 1]
    out = [''] * 4
    for i in range(4):
        c = chunks[i]
        c = c[:3] + c[4:]
        out[order[i]] = base64.b64decode(c).decode('utf-8')
    return json.loads(base64.b64decode(''.join(out)).decode('utf-8'))


def decode_payload(page, page_url=None):
    """`var d=[n,n,...], k1=<int>, k2=<int>` -> chr(((n ^ k1) - k2) mod 256) text that holds either the signed playlist URL or a
    loadStreamUrl("<token url>") call (the token address answers with the playlist URL, xor-coded)."""
    m = re.search(r'(?:var|let|const)\s+\w+\s*=\s*\[([\d,\s]+)\]\s*,\s*\w+\s*=\s*(\d+)\s*,\s*\w+\s*=\s*(\d+)', page)
    if not m:
        sm = re.search(r'streamUrl\s*:\s*"(https?:[^"]+\.m3u8[^"]*)"', page)       # plain config object (wideiptv player)
        return sm.group(1).replace('\/', '/') if sm else None
    k1, k2 = int(m.group(2)), int(m.group(3))
    text = ''.join(chr(((int(n) ^ k1) - k2 + 256) % 256) for n in m.group(1).split(',') if n.strip())
    lm = re.search(r'loadStreamUrl\(\s*"([^"]+)"', text)
    if lm and page_url:
        return _token_stream_url(lm.group(1).replace('\\/', '/'), page_url)
    m = re.search(r'SIGNED_URL\s*=\s*"([^"]+)"', text) or re.search(r'\burl\s*=\s*"([^"]+)"', text)
    return m.group(1).replace('\\/', '/') if m else None


def _token_stream_url(token_url, page_url):
    """The token address replies with bytes: the first is a seed, the rest are the playlist URL xor-ed with the token's own last
    path segment and a counter."""
    org = _origin(page_url)
    tk = token_url.rstrip('/').rsplit('/', 1)[-1]
    try:
        r = requests.get(token_url, headers={'User-Agent': UA, 'Referer': org + '/', 'Origin': org}, timeout=_TIMEOUT)
    except Exception as e:
        _log('token reply: %s' % str(e)[:100])
        return None
    raw = r.content
    if r.status_code != 200 or len(raw) < 2 or not tk:
        _log('token reply %s for %s' % (r.status_code, token_url[:80]))
        return None
    seed = raw[0]
    url = ''.join(chr(raw[i] ^ ord(tk[(i - 1) % len(tk)]) ^ ((seed + i - 1) & 255)) for i in range(1, len(raw))).strip()
    return url if url.startswith('http') else None


def _b64_url(encoded):
    try:
        text = base64.b64decode(encoded + '=' * (-len(encoded) % 4)).decode('utf-8', 'ignore')
    except Exception:
        return None
    m = re.search(r"atob\('([^']+)'\)", text)
    if m:
        return _b64_url(m.group(1))
    m = re.search(r'(?:https?:)?//[^\s"\'<>]+', text)
    return m.group(0) if m else None


def _next_hop(page, page_url):
    m = re.search(r'data-encoded="([^"]+)"', page)
    if m and _b64_url(m.group(1)):
        return urljoin(page_url, _b64_url(m.group(1)))
    m = re.search(r'"([A-Za-z0-9+/=]{40,})"\s*;\s*eval\(atob', page)
    if m and _b64_url(m.group(1)):
        return urljoin(page_url, _b64_url(m.group(1)))
    m = re.search(r"iframe\.src\s*=\s*'([^']+)'\s*\+\s*encodeURIComponent", page)
    if m:
        chan = re.sub(r'[/\\.?&=]', '', dict(parse_qsl(urlparse(page_url).query)).get('id', '').strip())
        if chan:
            return urljoin(page_url, m.group(1) + quote_plus(chan))
    m = (re.search(r'f\.src\s*=\s*"([^"]+)"', page) or
         re.search(r'<ifr(?:\'\+\')?ame[^>]+src="((?:https?:)?//[^"]+)"', page, re.I))
    if m:
        return urljoin(page_url, _html.unescape(m.group(1)).strip())
    return None


# ── per-player resolvers: (player_url, referer) -> (stream_url, embed_url) | None ──

def _r_src(player_url, referer):          # stream, watch, hub
    embed = _iframe_src(_fetch(player_url, referer), player_url)
    if not embed:
        return None
    page = _fetch(embed, player_url)
    m = re.search(r'const\s+SRC\s*=\s*"([^"]+)"', page)
    if not m:
        return None
    src = m.group(1).replace('\\/', '/')
    edge = re.search(r'const\s+EDGE\s*=\s*"([^"]+)"', page)
    chan = re.search(r'const\s+CHANNEL\s*=\s*"([^"]+)"', page)
    if edge and chan and 'playlist-token' in page:
        return src, embed, '%s/api/playlist-token?slug=%s' % (edge.group(1).rstrip('/'), quote_plus(chan.group(1)))
    return src, embed


def _r_cast(player_url, referer):
    embed = _iframe_src(_fetch(player_url, referer), player_url)
    if not embed:
        return None
    page = _fetch(embed, player_url)
    url = None
    m = re.search(r"window\._econfig\s*=\s*'([^']+)'", page)
    if m:
        try:
            cfg = decode_econfig(m.group(1))
            url = cfg.get('stream_url_nop2p') or cfg.get('stream_url')
        except Exception as e:
            _log('cast config: %s' % str(e)[:100])
    url = url or decode_payload(page, embed)
    return (url, embed) if url else None


def _r_plus(player_url, referer):
    embed = _iframe_src(_fetch(player_url, referer), player_url)
    if not embed:
        return None
    url = decode_payload(_fetch(embed, player_url), embed)
    return (url, embed) if url else None


def _r_casting(player_url, referer):
    outer = _iframe_src(_fetch(player_url, referer), player_url)
    if not outer:
        return None
    embed = _iframe_src(_fetch(outer, player_url), outer)
    if not embed:
        return None
    m = re.search(r'const\s+streamUrls\s*=\s*(\[[^\]]*\])', _fetch(embed, outer))
    if not m:
        return None
    for entry in json.loads(m.group(1)):
        if isinstance(entry, dict):
            entry = next((entry[k] for k in ('url', 'src', 'file', 'stream_url') if isinstance(entry.get(k), str) and entry[k]), None)
        if isinstance(entry, str) and entry:
            return entry, embed
    return None


def _r_chain(player_url, referer):        # player
    url = player_url
    for _ in range(10):
        page = _fetch(url, referer)
        stream = decode_payload(page, url)
        if stream:
            return stream, url
        nxt = _next_hop(page, url)
        if not nxt:
            return None
        referer = None if 'referrerpolicy="no-referrer"' in page else _origin(url) + '/'
        url = nxt
    return None


PLAYERS = {'stream': _r_src, 'watch': _r_src, 'hub': _r_src, 'cast': _r_cast, 'plus': _r_plus,
           'casting': _r_casting, 'player': _r_chain}
# Probe-able players first (their playlist URLs can be fetched any number of times), then
# cast, whose playlist URL is single-use (?s=..&e=..): a probe would burn it before Kodi
# opens it, so it is handed back unverified and only used when nothing else is live.
_ORDER = ('stream', 'plus', 'casting', 'player', 'watch', 'hub', 'cast')
_SINGLE_USE = ('cast',)


def _headers_suffix(embed_url):
    org = _origin(embed_url)
    return '|Referer=%s/&Origin=%s&User-Agent=%s' % (org, org, quote_plus(UA))


def _playable(stream_url, embed_url, token_url=None):
    """Cheap check that the playlist answers 200 with #EXTM3U (these URLs are signed and
    some players hand out dead ones). `token_url`: the edge only serves the playlist with a token from there."""
    try:
        org = _origin(embed_url)
        headers = {'User-Agent': UA, 'Referer': org + '/', 'Origin': org}
        if token_url:
            from starfleetscrapers.sports import local_proxy as _lp
            stream_url = _lp.tokenized(stream_url, _lp.playlist_token(token_url, headers))
        r = requests.get(stream_url, headers=headers, timeout=(4, 8))
        return r.status_code == 200 and '#EXTM3U' in r.text[:400]
    except Exception:
        return False


def _final_url(stream_url, embed, token_url, single_use):
    """The address handed to the player ('url|Header=..'). A playlist that needs a token is served through the relay, which
    keeps the token fresh; a single-use one is marked so the relay never opens it first."""
    piped = stream_url + _headers_suffix(embed)
    if token_url:
        from starfleetscrapers.sports import local_proxy as _lp
        return _lp.build_token_url(piped, token_url)
    if single_use:
        piped += '&X-SF-Direct=1'
    return piped


def resolve_channel(channel_id, base=DEFAULT_BASE, verify=True, prefer=None):
    """Try the channel's players in turn; first one that yields a live playlist wins. `base` may be any address of the site
    (it is followed to wherever the site lives now)."""
    with _GATE:
        return _resolve_channel(channel_id, active_base(base), verify, prefer)


def _resolve_channel(channel_id, base, verify, prefer):
    base = base.rstrip('/')
    host = urlparse(base).netloc
    watch_url = '%s/watch.php?id=%s' % (base, channel_id)
    try:
        page = _fetch(watch_url, base + '/')
    except requests.exceptions.ConnectionError:
        raise          # host down: let the caller mark it so nothing else waits on it
    except Exception as e:
        _log('watch page %s: %s' % (channel_id, e))
        return None
    found = {}
    for href, _title in re.findall(r'data-url="([^"]+)"\s+title="([^"]+)"', page):
        folder = urlparse(href).path.strip('/').split('/')[0]
        if folder in PLAYERS and folder not in found:
            found[folder] = urljoin(watch_url, _html.unescape(href).strip())
    if not found:
        found['cast'] = '%s/cast/stream-%s.php' % (base, channel_id)
    order = list(dict.fromkeys([f for f in ((prefer,) if prefer else ()) + _ORDER if f in found]))
    results = queue.Queue()

    def attempt(folder):
        # one player: decode its page, then (unless its playlist is single-use) check the playlist answers
        try:
            res = PLAYERS[folder](found[folder], watch_url)
        except Exception as e:
            _log('%s player %s: %s' % (channel_id, folder, str(e)[:100]))
            results.put((folder, None))
            return
        if not res:
            results.put((folder, None))
            return
        stream_url, embed = res[0], res[1]
        token_url = res[2] if len(res) > 2 else None
        if stream_url.startswith('//'):
            stream_url = 'https:' + stream_url
        if verify and folder not in _SINGLE_USE and not _playable(stream_url, embed, token_url):
            _log('%s player %s: playlist not live' % (channel_id, folder))
            results.put((folder, None))
            return
        results.put((folder, {'url': _final_url(stream_url, embed, token_url, folder in _SINGLE_USE),
                              'player': folder, 'embed': embed}))

    # All players are tried at once: dead player hosts used to be waited out one after the other (17-26 s).
    # The first player with a live playlist wins; a single-use (unverifiable) one is kept as the fallback and
    # only used when nothing verified turns up within a short grace.
    for folder in order:
        threading.Thread(target=attempt, args=(folder,), daemon=True).start()
    pending = len(order)
    fallback = None
    deadline = time.time() + 20
    while pending and time.time() < deadline:
        try:
            folder, res = results.get(timeout=max(0.1, deadline - time.time()))
        except queue.Empty:
            break
        pending -= 1
        if not res:
            continue
        if folder in _SINGLE_USE:
            fallback = fallback or res
            deadline = min(deadline, time.time() + 3)
            continue
        return res
    return fallback


def channel_id_from_url(url):
    """Pull the channel number out of any dlive/DLHD URL form we handle."""
    if not url:
        return None
    m = re.search(r'stream-(\d+)\.php', url) or re.search(r'[?&]id=(\d+)', url) \
        or re.search(r'channel[=/](\d+)', url)
    return m.group(1) if m else None
