WATCH = '''
query(
  $id: ID!,
  $countryCode: String!,
  $deviceType: DeviceType!,
  $tz: String!
) {
  airing(
    id: $id,
    countryCode: $countryCode,
    deviceType: $deviceType,
    tz: $tz
  ) {
    id
    name
    description
    mrss: adobeRSS
    authTypes
    requiresLinearPlayback
    allowStartOver
    interactiveModeAvailable
    status: type
    startDateTime
    endDateTime
    duration
    firstPresented

    source(authorization: SHIELD) {
      url
      authorizationType
      playbackId
      hasEspnId3Heartbeats
      hasNielsenWatermarks
      hasPassThroughAds
      commercialReplacement
      startSessionUrl
    }

    network {
      id
      type
      name
      shortName
      adobeResource
    }

    image {
      url
    }

    sport {
      name
      code
      uid
    }

    league {
      name
      uid
    }

    program {
      code
      categoryCode
      isStudio
    }

    seekInSeconds
    simulcastAiringId
    airingId

    tracking {
      nielsenCrossId1
      trackingId
    }

    eventId

    packages {
      name
    }

    isReAir
    language
    tier
    feedName
    feedType

    brands {
      id
      name
      type
    }

    multiview {
      template
      airings {
        id
        name
        shortName

        league {
          name
          uid
        }

        duration
        startDateTime

        network {
          id
          type
          name
          shortName
          adobeResource
        }

        sport {
          name
          code
          uid
        }

        status: type

        tracking {
          nielsenCrossId1
          trackingId
        }

        program {
          code
          categoryCode
          isStudio
        }
      }
    }
  }
}'''

EPG = '''query Airings ( $countryCode: String!, $deviceType: DeviceType!, $tz: String!, $type: AiringType, $categories: [String], $networks: [String], $packages: [String], $eventId: String, $packageId: String, $start: String, $end: String, $day: String, $limit: Int ) { airings( countryCode: $countryCode, deviceType: $deviceType, tz: $tz, type: $type, categories: $categories, networks: $networks, packages: $packages, eventId: $eventId, packageId: $packageId, start: $start, end: $end, day: $day, limit: $limit ) { id airingId simulcastAiringId name type startDateTime shortDate: startDate(style: SHORT) authTypes adobeRSS duration feedName purchaseImage { url } image { url } network { id type abbreviation name shortName adobeResource isIpAuth } source { url authorizationType hasPassThroughAds hasNielsenWatermarks hasEspnId3Heartbeats commercialReplacement } packages { name } category { id name } subcategory { id name } sport { id name abbreviation code } league { id name abbreviation code } franchise { id name } program { id code categoryCode isStudio } tracking { nielsenCrossId1 nielsenCrossId2 comscoreC6 trackingId } } }'''
