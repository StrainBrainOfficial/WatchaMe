# -*- coding: utf-8 -*-
"""
Fútbol Libre (futbollibretv.space) source for plugin.video.sporthdme.

Same NAME/KEY/DESC/list_events()/resolve() contract as the other extra sites.
Structure (Astro-based):

  /api/agenda            -> {events:[{id,title,time,sport,embeds:[{name,iframe}]}]}
  embed iframe           -> base64 or direct URL to player page
  player page            -> Clappr with playbackURL = "...m3u8?token="
"""

import re
import json
import base64
from datetime import datetime

from six.moves.urllib.parse import unquote, urljoin
from dateutil.parser import parse as _dtparse
from dateutil.tz import gettz

from resources.modules import econfig as _econfig

NAME = 'Futbol Libre'
KEY = 'fllibre'
DESC = ('[B]Futbol Libre[/B]\n\n'
        'Agenda de futbol en directo (futbollibretv.space), ordenada por hora, con '
        'varios canales por evento. Los eventos finalizados se ocultan.\n\n'
        '[I]Live football agenda, sorted by time, several channels per event. '
        'Finished events are hidden. Commentary in Latin American Spanish.[/I]')
BASE = 'https://futbollibretv.space'
AGENDA = BASE + '/api/agenda'
# futbollibrefullhd.org agenda (same embed family); used as the Eventos En
# Vivo fallback by default.py, not as its own menu entry.
DIARIES = 'https://api.wqxag.com/diaries.json'
DIARIES_REFERER = 'https://futbollibrefullhd.org/'
TZ = 'America/Lima'
UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
      '(KHTML, like Gecko) Chrome/120.0 Safari/537.36')


# ---- pure parsers (testable without network) -----------------------------

def _decode_embed(embed_iframe):
    """embed_iframe is /embed/eventos.html?r=<base64> -> the real player URL."""
    m = re.search(r'[?&]r=([A-Za-z0-9+/=_-]+)', embed_iframe or '')
    if not m:
        return None
    b = m.group(1).replace('-', '+').replace('_', '/')
    try:
        url = base64.b64decode(b + '=' * (-len(b) % 4)).decode('utf-8', 'replace')
        return url if url.startswith('http') else None
    except Exception:
        return None


def _start_ms(date_diary, diary_hour):
    try:
        dt = _dtparse('%s %s' % (date_diary, diary_hour)).replace(tzinfo=gettz(TZ) or gettz())
        return int(dt.timestamp() * 1000)
    except Exception:
        return 0


def _start_ms_from_time(time_str):
    """Parse 'HH:MM' into today's start_ms in Lima timezone."""
    if not time_str:
        return 0
    try:
        today = datetime.now().strftime('%Y-%m-%d')
        dt = _dtparse('%s %s' % (today, time_str)).replace(tzinfo=gettz(TZ) or gettz())
        return int(dt.timestamp() * 1000)
    except Exception:
        return 0


def _status(start_ms, duration_min=120):
    if not start_ms:
        return 'soon'
    now_ms = datetime.now().timestamp() * 1000
    if now_ms < start_ms:
        return 'soon'
    if now_ms <= start_ms + duration_min * 60 * 1000:
        return 'live'
    return 'done'


def parse_events(payload):
    """Parse /api/agenda into normalized event dicts (finished dropped)."""
    out = []
    for item in payload.get('events', []):
        title = (item.get('title') or '').strip()
        servers = []
        for emb in (item.get('embeds') or []):
            url = _decode_embed(emb.get('iframe', '')) or emb.get('iframe', '')
            if url and url.startswith('http'):
                servers.append([emb.get('name') or 'Canal', url])
        if not (title and servers):
            continue
        # Parse time "HH:MM" into start_ms
        time_str = item.get('time', '')
        start_ms = _start_ms_from_time(time_str)
        status = _status(start_ms)
        if status == 'done':
            continue
        out.append({
            'title': title,
            'code': item.get('sport', ''),
            'league': '',
            'start_ms': start_ms,
            # img.agenda18.com flag icons are unreliable (28s CCurlFile
            # timeouts -> Kodi shows a busy spinner mid-playback while it
            # waits); skip them, callers fall back to the local ICON.
            'poster': '',
            'status': status,
            'servers': servers,
        })
    out.sort(key=lambda e: e['start_ms'])
    return out


def parse_diaries(payload):
    """Parse diaries.json (Strapi: data[].attributes) into event dicts."""
    out = []
    for item in payload.get('data', []):
        a = item.get('attributes') or item
        title = ' '.join((a.get('diary_description') or '').split())
        servers = []
        for emb in (a.get('embeds') or {}).get('data', []):
            ea = emb.get('attributes') or emb
            url = _decode_embed(ea.get('embed_iframe', ''))
            if url:
                servers.append([ea.get('embed_name') or 'Canal', url])
        if not (title and servers):
            continue
        start_ms = _start_ms(a.get('date_diary', ''), a.get('diary_hour', ''))
        status = _status(start_ms)
        if status == 'done':
            continue
        out.append({'title': title, 'code': '', 'league': '', 'start_ms': start_ms,
                    'poster': '', 'status': status, 'servers': servers})
    out.sort(key=lambda e: e['start_ms'])
    return out


def extract_m3u8(html):
    """Extract m3u8 URL from Clappr player page."""
    # Clappr may use playbackURL or other patterns
    patterns = [
        r'playbackURL\s*=\s*["\']([^"\']+\.m3u8[^"\']*)["\']',
        r'["\']?source["\']?\s*:\s*["\']([^"\']+\.m3u8[^"\']*)["\']',
    ]
    for pattern in patterns:
        m = re.search(pattern, html)
        if m:
            return m.group(1)
    return None


# ---- network -------------------------------------------------------------

def _get(url, referer=None):
    import requests
    return requests.get(url, headers={'User-Agent': UA,
                                      'Referer': referer or BASE + '/'}, timeout=15).text


def list_events():
    return parse_events(json.loads(_get(AGENDA, referer=BASE + '/agenda')))


def list_diaries():
    return parse_diaries(json.loads(_get(DIARIES, referer=DIARIES_REFERER)))


def resolve(server_url, _depth=0):
    """server_url is iframe URL (base64, ?get= redirector, or plaintext
    player page); return (m3u8, player_page_url).

    Some servers (e.g. tarjetarojita.xyz) chain 2-3 hops before the real
    player: a ?get=<url> wrapper -> a page with a nested <iframe src=...>
    -> the actual player, which exposes either a plain playbackURL or an
    obfuscated window._econfig blob (same encoding as the glisco/sansat
    chain elsewhere in this addon, see econfig.py). Follow the chain
    instead of hardcoding one shape per host.
    """
    if _depth > 4:
        return None
    url = _decode_embed(server_url) or server_url
    if not url.startswith('http'):
        return None

    m = re.search(r'[?&]get=(https?[^&]+)', url)
    if m:
        return resolve(unquote(m.group(1)), _depth + 1)

    html = _get(url, referer=BASE + '/')

    # return the player page too: its host is the Referer/Origin the CDN
    # wants (quotarevival.net segments 403 with the tarjetarojita origin)
    m3u8 = extract_m3u8(html)
    if m3u8:
        return m3u8, url

    m3u8, _cfg = _econfig.extract_stream_from_html(html)
    if m3u8:
        return m3u8, url

    iframe_m = re.search(r'<iframe[^>]+src=["\']([^"\']+)["\']', html)
    if iframe_m:
        # tvf90.com uses a relative src (/6.php?stream=...)
        return resolve(urljoin(url, iframe_m.group(1)), _depth + 1)

    return None


# ---- self-check ----------------------------------------------------------

if __name__ == '__main__':
    d = _decode_embed('/embed/eventos.html?r=' + base64.b64encode(
        b'https://futbollibre.ch/canales.php?stream=sportv').decode())
    assert d == 'https://futbollibre.ch/canales.php?stream=sportv', d

    evs = parse_events(json.load(open('/tmp/fl_data.json')))
    assert evs and all(e['servers'] and e['title'] for e in evs), 'bad events'
    assert all(e['start_ms'] > 1600000000000 for e in evs), 'bad start_ms'
    assert evs == sorted(evs, key=lambda e: e['start_ms']), 'not chronological'
    print('events:', len(evs), '| sample:', evs[0]['title'], '|', evs[0]['code'],
          '|', evs[0]['status'], '|', len(evs[0]['servers']), 'servers')

    m3u8 = extract_m3u8(open('/tmp/canales.html', encoding='utf-8', errors='replace').read())
    assert m3u8 and m3u8.startswith('http') and 'm3u8' in m3u8, m3u8
    print('playback:', m3u8[:70], '...')
    print('OK')
