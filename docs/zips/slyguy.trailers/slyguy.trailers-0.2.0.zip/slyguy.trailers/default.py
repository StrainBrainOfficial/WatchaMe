import sys

# when running as script, we want to capture the listitem as quick as possible before user navigates away
if sys.argv[0].lower().endswith('.py'):
    trailer = None
    if len(sys.argv) > 1:
        # redirect scripts pass in the url as argument for fallback
        trailer = sys.argv[1]

    from resources.lib.util import info_to_data, busy
    data = info_to_data(trailer=trailer)
    if not data:
        # no media info or trailer arg, check if clicked our addon in Programs and load into the plugin (settings), otherwise ignore
        from kodi_six import xbmc, xbmcaddon
        addon_id = xbmcaddon.Addon().getAddonInfo('id')
        if addon_id in xbmc.getInfoLabel('ListItem.FolderPath'):
            xbmc.executebuiltin('ActivateWindow(Programs,{},return)'.format('plugin://{}'.format(addon_id)))
        sys.exit(0)

    if not trailer:
        # non redirect script access wont have the argument, therefore follow the same logic as the context menu item to determine if we should play or not
        from kodi_six import xbmcgui
        prop = xbmcgui.Window(10000).getProperty('_slyguy_trailer_script')
        match = (
            (data['mediatype'] == 'movie'  and "1" in prop) or
            (data['mediatype'] == 'tvshow' and "2" in prop) or
            (data['mediatype'] == 'season' and data['season_number'] < 0 and "2" in prop) or
            (data['mediatype'] == 'season' and "3" in prop)
        )
        if not match:
            sys.exit(0)

    with busy():
        sys.slyguy_extra = data
        from resources.lib.plugin import plugin
        plugin.dispatch()
else:
    from resources.lib.plugin import plugin
    plugin.dispatch()
