"""Compatibility shim for Kodi builds without real Windows registry access."""

HKEY_CLASSES_ROOT = 0
HKEY_CURRENT_USER = 1
HKEY_LOCAL_MACHINE = 2
HKEY_USERS = 3
REG_SZ = 1
REG_EXPAND_SZ = 2
IS_SUPPORTED = 0


class HKEYType(object):
    def Close(self):
        return None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return False


def OpenKey(*args, **kwargs):
    return HKEYType()


def EnumKey(*args, **kwargs):
    raise OSError("No registry data")


def QueryValueEx(*args, **kwargs):
    return ("", REG_SZ)


def EnumValue(*args, **kwargs):
    raise OSError("No registry data")


def QueryInfoKey(*args, **kwargs):
    return (0, 0, 0)


def ConnectRegistry(*args, **kwargs):
    return HKEYType()


def CloseKey(*args, **kwargs):
    return None
