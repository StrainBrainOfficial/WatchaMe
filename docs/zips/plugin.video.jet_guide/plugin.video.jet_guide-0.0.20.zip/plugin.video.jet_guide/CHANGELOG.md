# Jet Guide - Changelog




## [0.0.8] - 2026-07-19

### Added
- **Resolved URL tracking** - analytics now sends a `url_resolved` event with the actual stream URL after Kodi resolves plugin URLs (e.g., `jetproxy://`, `http://...m3u8`)
- **Android busy spinner fix** - auto-closes orphaned busy dialog on Android when playing plugin:// URLs that take time to resolve


##  - 2026-07-05

### Added
- **NBA Summer League** support (Las Vegas, Utah, California Classic) with ESPN API endpoints, sport config, and toggle settings
- **Playback analytics** system (`analytics.py`) - async device UUID tracking on every video play with daemon threading
- **Slideshow live detection fix** - now explicitly rejects `scheduled` and `pre` statuses to show only live games

### Fixed
- Android busy dialog stuck after playback - EPGGrid modal window now properly returns after `PlayMedia` or `Player.play`
- Slideshow showing scheduled events instead of only live games

---

## - 2026-05-26

### Added
- **Motorsports support** - F1, IndyCar, and NASCAR in SportsGrid with dedicated `sportsgrid_racing.py` module
  - Driver standings with points, wins, podiums
  - Race schedules with circuit info, location, and lap progress for live races
  - Constructor standings for F1
  - Enhanced slideshow showing live lap progress
  - Country flags for finishing drivers
- **Home screen redesign** - vertical left navigation with context preview panel
  - Sports Events interactive cards with live stream selection
  - Sports Stats league quick-access cards (14 leagues)
  - EPG context with Last Watched row
  - Tools context with quick actions (settings, cache, widgets, changelog)
  - Record/Players context with direct launch options (mpv, VLC, MPC-HC, Android)
  - Search quick filters (All, Live, Sports, Movies, Kids, News)
- **Team Info Window**  with comprehensive stats:
  - Season stats, point/run/goal differential
  - Last 5 games with scores
  - Next game info (opponent, time, network)
  - Top players with sport-specific leaders
  - Season rankings with team color theming
  - Sport-specific stat labels (NBA, NFL, MLB, NHL, MLS, etc.)
- **Changelog/Update Notification window**  - shows "What's New" after updates with GitHub raw file fetching
- **Saved stream features**:
  - "Save Stream to Jet Guide" from EPG context menu
  - "Save Stream to Kodi Favorites" from EPG context menu
  - Create new folders from Browse Saved Links
- **Custom Channel Groups** - create, add/remove channels, rename, delete via EPG context and Tools
- **EPG Categories settings.xml integration** - toggle categories directly in addon settings
- **EPG show spanning** - long programs span multiple time slots with continuation indicators
- **Theme support** - Dark, Light, and Custom themes with configurable accent/text/background colors

### Changed
- **Major refactoring** - split monolithic modules into focused files:
  - `addon.py`: 1542 -> 612 lines (orchestration/router)
  - `tenbuttons.py`: 3652 -> 813 lines (thin UI dispatcher)
  - `tools.py`: 1688 -> 830 lines
  - `epggrid.py`: 1806 -> 1103 lines
  - `sportsgrid.py`: 2684 -> 1610 lines
- **TenButtons decomposition** into click/stream/recording/window modules
- **EPGGrid context menu** extracted to `epggrid_context_menu.py`
- **SportsGrid data pipeline** extracted to `sportsgrid_config.py`, `sportsgrid_data_schedule.py`, `sportsgrid_data_stats.py`, `sportsgrid_data_leaders.py`
- **Tools decomposition** into `tools_links.py`, `tools_custom_groups.py`, `tools_epg_categories.py`
- **YouTube playlist playback** - fixed cancel flag removal before playback start

### Fixed
- **Multi-stream playback** issues:
  - Video track index fix for mpv lavfi filter
  - Argument order 
  - Plugin URL resolution fallback for empty 
  - JSON format support for multiple URL prefixes (ffmpegdirect, direct, jetproxy)
  - Python import scoping bug causing "referenced before assignment"
- **Android header bug** - headers were being added then immediately overwritten
- **Android settings** - uncommented mpv path and recording path settings
- **Duplicate function definitions** across tenbuttons.py and tools.py
- **Duplicate import statements** in tools.py and tenbuttons.py
- **Search window** - fixed dual-window behavior and reversed Yes/No filter
- **SportsGrid live game click** - added onclick handler for stream selection
- **Focus errors** - added try/except for SportsGrid control 100 and control 999
- **Concurrent busydialog crash** - implemented dialog lock/mutex system
- **YouTube channel playback cache** - now uses cached data before remote fetch
- **Loading progress indicators** - added staged progress for M3U8/XMLTV/Sports parsing

### Improved
- **Android optimization** - input debounce, compact EPG mode, broader back key coverage
- **Auto-recovery** for stream resolution with configurable retries
- **EPG lazy loading** - progressive channel loading for faster cold starts
- **Background refresh** - auto-refresh time slots after idle with jump-to-now
- **Multi-stream duplicate handling** - prompts user when duplicate CDN streams detected
- **Stream selection auto-resolution** - automatically fetches plugin JSON for playable URLs
- **Loop/repeat options** for multi-stream playback (No Loop, Loop Single, Loop All)

---

##  - 2026-03-25

### Fixed
- Sport-specific stats labels in team info window (was showing NBA labels for all sports)
- Team info window now correctly displays per-sport stats and leaders

---

## - 2026-03-21

### Added
- Multi-stream playback fixes for mpv (track indices, argument order, plugin URL resolution)
- Loop/repeat feature for multi-stream playback
- Stream selection auto-resolution from plugin JSON
- Team info window with season stats, recent games, leaders
- Enhanced Info Panel stats (Record, Home, Away, L10)
- Live game indicator badge in SportsGrid
- Division/conference labels in team list

### Fixed
- Python import scoping bug across tenbuttons.py and epggrid.py
- Multi-stream duplicate detection with user prompt

---

*Last updated: 2026-07-05*
