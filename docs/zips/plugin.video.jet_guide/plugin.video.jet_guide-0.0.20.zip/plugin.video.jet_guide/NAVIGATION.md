# Jet Guide - Navigation Guide

Quick-reference for navigating the addon with a remote, keyboard, or mouse.

---

## Home Screen (Ten Buttons)

The home screen uses a **vertical left nav** with a **context preview panel** on the right.

```
┌──────────────┬─────────────────────────────────┐
│              │                                 │
│  EPG Guide   │  [Context Preview Panel]        │
│  Sports Evts │  - Last Watched row             │
│  Sports Stats│  - Live game cards              │
│  Tools       │  - League cards                 │
│  Search      │  - Quick actions                │
│  Favorites   │                                 │
│  Record      │                                 │
│  Main Menu   │                                 │
│  Exit        │                                 │
│              │                                 │
└──────────────┴─────────────────────────────────┘
```

### Navigation Keys

| Key | Action |
|-----|--------|
| Up / Down | Move through left nav items |
| Right | Enter context panel / widget rows |
| Left | Return to left nav from widgets |
| OK / Enter | Activate selected item |
| Back | Return to previous screen |

### Left Nav Items & What Happens

| Item | OK Press | Right Press |
|------|----------|-------------|
| EPG Guide | Opens EPG grid | Shows Last Watched row |
| Sports Events | Opens Sports Grid | Shows live game cards (selectable) |
| Sports Stats | Opens Sports Stats | Shows league quick-access cards |
| Tools | Opens Tools window | Shows quick actions (Settings, Cache, Widgets, Changelog) |
| Search | Opens search window | Shows quick filter chips (All, Live, Sports, Movies, Kids, News) |
| Favorites | Opens Favorites window | -- |
| Record / Players | Opens record menu | Shows direct launch options (mpv, Record, VLC, etc.) |
| Main Menu | Opens Kodi main menu | -- |
| Exit | Exits addon | -- |

### Sports Events Cards (Right Panel)

When focused on Sports Events, press Right to see live/upcoming games as cards:
- Navigate cards with Up/Down/Left/Right
- Press OK on a card to open stream source selection
- Shows team logos, scores, and status (LIVE / FINAL / time)

### Sports Stats Cards (Right Panel)

When focused on Sports Stats, press Right to see league cards:
- NFL, NBA, MLB, NHL, NCAAB, WNBA, MLS, CFL
- Premier League, La Liga, Bundesliga, Serie A, Ligue 1, Champions League
- Press OK on a league card to open that league in Sports Grid

### Search Quick Filters (Right Panel)

When focused on Search, press Right to see filter chips:
- **All** - search everything
- **Live** - only live channels
- **Sports** - sports channels
- **Movies** - movie channels
- **Kids** - children's channels
- **News** - news channels
- Press OK on a chip to open search pre-filtered (no keyboard needed)

---

## EPG Grid

```
┌──────────────┬───────────────────────────────────────────────┐
│ Channel List │ Current Time ═══════════════════════════════  │
├──────────────┼───────────────────────────────────────────────┤
│ Channel 1    │ [Program 1] [Program 2] [Program 3]    →     │
│ Channel 2    │ [Program A] [Program B]              →     │
│ Channel 3    │ [Program X]                    →           │
└──────────────┴───────────────────────────────────────────────┘
```

### EPG Keys

| Key | Action |
|-----|--------|
| Up / Down | Move between channels |
| Left / Right | Move through time slots |
| Page Up / Down | Jump 10 channels |
| OK / Enter | Play highlighted channel |
| Long-press OK | Open channel context menu |
| Back | Return to home |

### EPG Context Menu (Long-Press)

Long-press on any channel to open options:

| Option | Description |
|--------|-------------|
| Add to Favorites | Bookmark this channel |
| Remove from Favorites | Remove bookmark |
| Play Channel | Play the stream |
| Play from Imported | Play saved imported link |
| Play from Folder | Play from saved folder |
| Set Reminder | Set program reminder |
| Show All Reminders | View all reminders |
| Create Custom Group | Create a new channel group |
| Manage Custom Groups | Edit existing groups |
| Search Addons | Browse addon links |
| Play in mpv | Launch stream in mpv |
| Save Stream to Jet Guide | Save currently playing stream |
| Save Stream to Kodi Favorites | Save to Kodi favorites |

### EPG Program Info

Highlight any program to see:
- Title (color-coded by category)
- Time slot
- Description in the info panel below

### Category Colors

| Color | Category |
|-------|----------|
| Blue | Sports |
| Green | Comedy |
| Pink | News |
| Red | Movies |
| Orange | Entertainment |
| Cyan | Documentary |
| Yellow | Kids |
| Purple | Music |

---

## Sports Grid

### Layout

```
┌─────────────────┬───────────────────────────────────────────┐
│ Teams List      │ Games Timeline                            │
├─────────────────┼───────────────────────────────────────────┤
│ > Team A  (1-0) │ 7:00 PM ── Game 1 ──●LIVE───>            │
│   Team B  (0-1) │ 8:00 PM ── Game 2 ──────────>            │
│   Team C        │ 9:30 PM ── Game 3 ──────────>            │
└─────────────────┴───────────────────────────────────────────┘
```

### Sports Grid Keys

| Key | Action |
|-----|--------|
| Up / Down (left panel) | Browse teams |
| Up / Down (right panel) | Browse games |
| Left / Right | Switch between panels |
| OK on team | Open Team Info window |
| OK on game | Open stream selection |
| Back | Return to home |

### Sports Grid Navigation

1. **League selection** - Use the league buttons at top (NFL, NBA, MLB, etc.) or "More" for additional sports
2. **Team list** (left) - Shows teams with records and division labels
3. **Games timeline** (right) - Shows scheduled/live games with times and LIVE badges
4. **Click live game** - Opens stream source selection dialog
5. **Click team** - Opens Team Info window with stats, recent games, leaders

### Team Info Window

From the team list, press OK to see:
- Team name, logo, and record
- Point/run/goal differential
- Last 5 games with scores
- Next game (opponent, time, network)
- Top players with stats
- Season rankings

---

## Sports Guide

A merged view of all enabled sports feeds:
- Browse by sport category
- Shows live and upcoming events
- Click any event to open stream selection

---

## Tools Window

Accessed from Home > Tools (Button 8):

| Button | Action |
|--------|--------|
| Settings | Open addon settings |
| Clear Cache | Clear cached data |
| Manage Widgets | View/refresh/clear widgets |
| What's New | Show changelog window |
| Live Score Alerts | Configure live score alerts |
| Reminders | View all reminders |
| Browse Saved Links | Browse saved streams |
| Search Kodi Addons | Browse addon plugin folders |
| Import Kodi Favourites | Import from Kodi favorites |
| Manage Custom Groups | Create/edit/delete channel groups |
| Manage EPG Categories | Toggle category visibility |

---

## Record / Players Menu

Accessed from Home > Record / Players (Button 10/199):

| Option | Description |
|--------|-------------|
| Play Stream in mpv | Launch current stream in mpv |
| Record Stream (ffmpeg) | Record to .ts file |
| Play Multiple Streams | Combine 2 streams in mpv |
| Stop Recording | Stop active recording |
| Watch Recording | Play recorded file |
| Play in VLC | Launch in VLC |
| Play in MPC-HC | Launch in MPC-HC |
| Play in Android Player | Launch Android external player |
| Directions | Show help |

---

## Search Window

| Key | Action |
|-----|--------|
| Start typing | Filter results in real-time |
| Enter | Submit search |
| OK on result | Play channel |
| Long-press | Context menu for result |
| Back | Close search |

---

## Favorites Window

| Key | Action |
|-----|--------|
| Up / Down | Browse favorite channels |
| OK | Play selected channel |
| Long-press | Remove from favorites |
| Back | Return to previous screen |

---

## Remote Control Quick Reference

### Standard Remote

| Button | Action |
|--------|--------|
| Up / Down / Left / Right | Navigate |
| OK / Enter | Select / Play |
| Back | Return to previous screen |
| Menu / Long-press | Context menu |
| Play / Pause | Toggle playback |
| Stop | Stop playback |
| Channel Up/Down | Page through EPG channels |

### Keyboard Shortcuts

| Key | Action |
|-----|--------|
| Arrow keys | Navigate |
| Enter | Select |
| Escape | Back |
| Space | Play / Pause |
| S | Open Search |
| F | Open Favorites |
| T | Open Tools |
| E | Open EPG |
| Q | Exit |

---

## Button Map (Ten Buttons)

| Button | Function |
|--------|----------|
| 1 | EPG Guide |
| 2 | Sports Guide |
| 3 | Search |
| 4 | Favorites |
| 5 | Sports Stats |
| 6 | Sports Grid |
| 7 | Main Menu |
| 8 | Tools |
| 9 | Exit |
| 10 / 199 | Record / External Player Menu |

---

*Document for plugin.video.jet_guide v0.0.7b*
