import xbmc
import xbmcaddon

ADDON_ID = "plugin.video.jet_guide"


def _get_addon():
    return xbmcaddon.Addon(id=ADDON_ID)


def debug_log(msg, prefix='JetGuide', level=xbmc.LOGINFO):
    try:
        if _get_addon().getSettingBool('debug_logging'):
            xbmc.log(f'[{prefix}] {msg}', level=level)
    except Exception:
        pass


def log(msg, prefix='JetGuide', level=xbmc.LOGINFO):
    try:
        if _get_addon().getSettingBool('debug_logging'):
            xbmc.log(f'[{prefix}] {msg}', level=level)
    except Exception:
        pass


def show_tools():
    _get_addon().openSettings()
