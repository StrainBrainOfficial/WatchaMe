SPORT_THUMBNAILS = {
    'nfl': 'nfl.png',
    'nba': 'nba.png',
    'nhl': 'nhl.png',
    'wnba': 'wnba.png',
    'mlb': 'baseball.png',
    'nba-summer-las-vegas': 'nba.png',
    'nba-summer-utah': 'nba.png',
    'nba-summer-california': 'nba.png',
    'ncaabase': 'baseball.png',
    'cfl': 'cfb.png',
    'ncaab': 'basketball.png',
    'mls': 'soccer.png',
    'premierleague': 'soccer.png',
    'laliga': 'soccer.png',
    'bundesliga': 'soccer.png',
    'seriea': 'soccer.png',
    'ligue1': 'soccer.png',
    'championsleague': 'soccer.png',
    'f1': 'racing.png',
    'irl': 'racing.png',
    'nascar': 'racing.png',
}

TEAM_COLOR_OVERRIDES = {
    'losangelesdodgers': '005A9C',
    'losangelesangels': 'BA0021',
    'newyorkyankees': '003087',
    'bostonredsox': 'BD3039',
    'losangeleslakers': '552583',
    'detroitpistons': 'C8102E',
    'chicagobulls': 'CE1141',
    'newenglandpatriots': '002244',
    'dallascowboys': '003594',
    'greenbaypackers': '203731',
    'detroitredwings': 'CE1126',
    'torontomapleleafs': '003E7E',
    'vfbstuttgart': 'E32219',
    'hamburgsv': '003D7C',
}

SPORT_STATS_CONFIG = {
    'nba': {
        'stat_labels': ['Points', 'Rebounds', 'Assists', 'FG%', '3PT%'],
        'stat_keys': ['points', 'rebounds', 'assists', 'fieldGoalPct', 'threePointPct'],
        'leader_labels': ['Points Leader', 'Rebounds Leader', 'Assists Leader'],
        'leader_keys': ['leader_points', 'leader_rebounds', 'leader_assists'],
    },
    'nba-summer-las-vegas': {
        'stat_labels': ['Points', 'Rebounds', 'Assists', 'FG%', '3PT%'],
        'stat_keys': ['points', 'rebounds', 'assists', 'fieldGoalPct', 'threePointPct'],
        'leader_labels': ['Points Leader', 'Rebounds Leader', 'Assists Leader'],
        'leader_keys': ['leader_points', 'leader_rebounds', 'leader_assists'],
    },
    'nba-summer-utah': {
        'stat_labels': ['Points', 'Rebounds', 'Assists', 'FG%', '3PT%'],
        'stat_keys': ['points', 'rebounds', 'assists', 'fieldGoalPct', 'threePointPct'],
        'leader_labels': ['Points Leader', 'Rebounds Leader', 'Assists Leader'],
        'leader_keys': ['leader_points', 'leader_rebounds', 'leader_assists'],
    },
    'nba-summer-california': {
        'stat_labels': ['Points', 'Rebounds', 'Assists', 'FG%', '3PT%'],
        'stat_keys': ['points', 'rebounds', 'assists', 'fieldGoalPct', 'threePointPct'],
        'leader_labels': ['Points Leader', 'Rebounds Leader', 'Assists Leader'],
        'leader_keys': ['leader_points', 'leader_rebounds', 'leader_assists'],
    },
    'wnba': {
        'stat_labels': ['Points', 'Rebounds', 'Assists', 'FG%', '3PT%'],
        'stat_keys': ['points', 'rebounds', 'assists', 'fieldGoalPct', 'threePointPct'],
        'leader_labels': ['Points Leader', 'Rebounds Leader', 'Assists Leader'],
        'leader_keys': ['leader_points', 'leader_rebounds', 'leader_assists'],
    },
    'nfl': {
        'stat_labels': ['Points', 'Total Yards', 'Pass Yards', 'Rush Yards', 'Turnovers'],
        'stat_keys': ['points', 'totalYards', 'passingYards', 'rushingYards', 'turnovers'],
        'leader_labels': ['Passing Leader', 'Rushing Leader', 'Receiving Leader'],
        'leader_keys': ['leader_passing', 'leader_rushing', 'leader_receiving'],
    },
    'mlb': {
        'stat_labels': ['Runs', 'Hits', 'Home Runs', 'RBI', 'ERA'],
        'stat_keys': ['runs', 'hits', 'homeRuns', 'rbi', 'era'],
        'leader_labels': ['Batting Avg Leader', 'Home Run Leader', 'RBI Leader', 'ERA Leader', 'Strikeout Leader'],
        'leader_keys': ['leader_avg', 'leader_homeRuns', 'leader_RBIs', 'leader_era', 'leader_strikeouts'],
    },
    'ncaabase': {
        'stat_labels': ['Runs', 'Hits', 'Home Runs', 'RBI', 'ERA'],
        'stat_keys': ['runs', 'hits', 'homeRuns', 'rbi', 'era'],
        'leader_labels': ['Batting Avg Leader', 'Home Run Leader', 'RBI Leader', 'ERA Leader', 'Strikeout Leader'],
        'leader_keys': ['leader_avg', 'leader_homeRuns', 'leader_RBIs', 'leader_era', 'leader_strikeouts'],
    },
    'nhl': {
        'stat_labels': ['Goals', 'Assists', 'Points', 'Shots', 'Saves'],
        'stat_keys': ['goals', 'assists', 'points', 'shotsOnGoal', 'saves'],
        'leader_labels': ['Goals Leader', 'Assists Leader', 'Points Leader'],
        'leader_keys': ['leader_goals', 'leader_assists', 'leader_points'],
    },
    'mls': {
        'stat_labels': ['Goals', 'Assists', 'Shots', 'Shots On Goal', 'Corners'],
        'stat_keys': ['goals', 'assists', 'shots', 'shotsOnGoal', 'corners'],
        'leader_labels': ['Goals Leader', 'Assists Leader', 'Points Leader'],
        'leader_keys': ['leader_goals', 'leader_assists', 'leader_points'],
    },
    'cfl': {
        'stat_labels': ['Points', 'Total Yards', 'Pass Yards', 'Rush Yards', 'Turnovers'],
        'stat_keys': ['points', 'totalYards', 'passingYards', 'rushingYards', 'turnovers'],
        'leader_labels': ['Passing Leader', 'Rushing Leader', 'Receiving Leader'],
        'leader_keys': ['leader_passing', 'leader_rushing', 'leader_receiving'],
    },
    
    'premierleague': {
        'stat_labels': ['Goals', 'Assists', 'Shots', 'Shots On Goal', 'Clean Sheets'],
        'stat_keys': ['goals', 'assists', 'shots', 'shotsOnGoal', 'cleanSheets'],
        'leader_labels': ['Goals Leader', 'Assists Leader', 'Clean Sheets Leader'],
        'leader_keys': ['leader_goals', 'leader_assists', 'leader_cleansheets'],
    },
    'laliga': {
        'stat_labels': ['Goals', 'Assists', 'Shots', 'Shots On Goal', 'Clean Sheets'],
        'stat_keys': ['goals', 'assists', 'shots', 'shotsOnGoal', 'cleanSheets'],
        'leader_labels': ['Goals Leader', 'Assists Leader', 'Clean Sheets Leader'],
        'leader_keys': ['leader_goals', 'leader_assists', 'leader_cleansheets'],
    },
    'bundesliga': {
        'stat_labels': ['Goals', 'Assists', 'Shots', 'Shots On Goal', 'Clean Sheets'],
        'stat_keys': ['goals', 'assists', 'shots', 'shotsOnGoal', 'cleanSheets'],
        'leader_labels': ['Goals Leader', 'Assists Leader', 'Clean Sheets Leader'],
        'leader_keys': ['leader_goals', 'leader_assists', 'leader_cleansheets'],
    },
    'seriea': {
        'stat_labels': ['Goals', 'Assists', 'Shots', 'Shots On Goal', 'Clean Sheets'],
        'stat_keys': ['goals', 'assists', 'shots', 'shotsOnGoal', 'cleanSheets'],
        'leader_labels': ['Goals Leader', 'Assists Leader', 'Clean Sheets Leader'],
        'leader_keys': ['leader_goals', 'leader_assists', 'leader_cleansheets'],
    },
    'ligue1': {
        'stat_labels': ['Goals', 'Assists', 'Shots', 'Shots On Goal', 'Clean Sheets'],
        'stat_keys': ['goals', 'assists', 'shots', 'shotsOnGoal', 'cleanSheets'],
        'leader_labels': ['Goals Leader', 'Assists Leader', 'Clean Sheets Leader'],
        'leader_keys': ['leader_goals', 'leader_assists', 'leader_cleansheets'],
    },
    'championsleague': {
        'stat_labels': ['Goals', 'Assists', 'Shots', 'Shots On Goal', 'Clean Sheets'],
        'stat_keys': ['goals', 'assists', 'shots', 'shotsOnGoal', 'cleanSheets'],
        'leader_labels': ['Goals Leader', 'Assists Leader', 'Clean Sheets Leader'],
        'leader_keys': ['leader_goals', 'leader_assists', 'leader_cleansheets'],
    },
    'f1': {
        'stat_labels': ['Position', 'Points', 'Wins', 'Podiums', 'Fastest Laps'],
        'stat_keys': ['position', 'points', 'wins', 'podiums', 'fastestLaps'],
        'leader_labels': ['Points Leader', 'Wins Leader', 'Poles Leader'],
        'leader_keys': ['leader_points', 'leader_wins', 'leader_poles'],
    },
    'irl': {
        'stat_labels': ['Position', 'Points', 'Wins', 'Podiums', 'Poles'],
        'stat_keys': ['position', 'points', 'wins', 'podiums', 'poles'],
        'leader_labels': ['Points Leader', 'Wins Leader', 'Poles Leader'],
        'leader_keys': ['leader_points', 'leader_wins', 'leader_poles'],
    },
    'nascar': {
        'stat_labels': ['Position', 'Points', 'Wins', 'Top 5', 'Top 10'],
        'stat_keys': ['position', 'points', 'wins', 'top5', 'top10'],
        'leader_labels': ['Points Leader', 'Wins Leader', 'Stage Wins Leader'],
        'leader_keys': ['leader_points', 'leader_wins', 'leader_stages'],
    },
}

ESPN_SITE_SPORT_MAP = {
    'mlb': 'sports/baseball/mlb',
    'nba': 'sports/basketball/nba',
    'nba-summer-las-vegas': 'sports/basketball/nba-summer-las-vegas',
    'nba-summer-utah': 'sports/basketball/nba-summer-utah',
    'nba-summer-california': 'sports/basketball/nba-summer-california',
    'ncaab': 'sports/basketball/mens-college-basketball',
    'ncaabase': 'sports/baseball/college-baseball',
    'nhl': 'sports/hockey/nhl',
    'wnba': 'sports/basketball/wnba',
    'nfl': 'sports/football/nfl',
    'mls': 'sports/soccer/usa.1',
    'premierleague': 'sports/soccer/eng.1',
    'laliga': 'sports/soccer/esp.1',
    'bundesliga': 'sports/soccer/ger.1',
    'seriea': 'sports/soccer/ita.1',
    'ligue1': 'sports/soccer/fra.1',
    'championsleague': 'sports/soccer/uefa.champions',
    'f1': 'sports/racing/f1',
    'irl': 'sports/racing/irl',
    'nascar': 'sports/racing/nascar-premier',
}

ESPN_CORE_SPORT_MAP = {
    'mlb': ('baseball', 'mlb'),
    'nba': ('basketball', 'nba'),
    'nba-summer-las-vegas': ('basketball', 'nba-summer-las-vegas'),
    'nba-summer-utah': ('basketball', 'nba-summer-utah'),
    'nba-summer-california': ('basketball', 'nba-summer-california'),
    'nhl': ('hockey', 'nhl'),
    'wnba': ('basketball', 'wnba'),
    'nfl': ('football', 'nfl'),
    'mls': ('soccer', 'usa.1'),
    'premierleague': ('soccer', 'eng.1'),
    'laliga': ('soccer', 'esp.1'),
    'bundesliga': ('soccer', 'ger.1'),
    'seriea': ('soccer', 'ita.1'),
    'ligue1': ('soccer', 'fra.1'),
    'championsleague': ('soccer', 'uefa.champions'),
    'f1': ('racing', 'f1'),
    'irl': ('racing', 'irl'),
    'nascar': ('racing', 'nascar-premier'),
}

SOCCER_LEAGUES = {'mls', 'premierleague', 'laliga', 'bundesliga', 'seriea', 'ligue1', 'championsleague'}

MORE_SPORTS = [
    ("NBA Summer League", "nba-summer-las-vegas"),
    ("NBA Utah Summer League", "nba-summer-utah"),
    ("NBA California Classic", "nba-summer-california"),
    ("F1 Racing", "f1"),
    ("IndyCar", "irl"),
    ("NASCAR Cup", "nascar"),
    ("CFL", "cfl"),
    ("NCAABASE", "ncaabase"),
    ("Bundesliga", "bundesliga"),
    ("Serie A", "seriea"),
    ("Ligue 1", "ligue1"),
    ("Champions League", "championsleague"),
]

SPORT_BUTTON_MAP = {
    900: 'mlb',
    901: 'nba',
    902: 'nhl',
    903: 'nfl',
    904: 'wnba',
    905: 'ncaab',
    906: 'mls',
    907: 'premierleague',
    908: 'laliga',
    909: 'more',
    910: 'exit',
}


def get_sport_stats_config(sport):
    return SPORT_STATS_CONFIG.get((sport or '').lower(), SPORT_STATS_CONFIG['nba'])


def get_espn_site_sport(sport):
    return ESPN_SITE_SPORT_MAP.get((sport or '').lower(), f"sports/{sport}")


def get_espn_core_sport(sport):
    return ESPN_CORE_SPORT_MAP.get((sport or '').lower())


def get_standings_years(sport, current_year):
    if (sport or '').lower() in SOCCER_LEAGUES:
        return [2025, 2024, 2026, current_year - 1]
    return [current_year, current_year - 1]
