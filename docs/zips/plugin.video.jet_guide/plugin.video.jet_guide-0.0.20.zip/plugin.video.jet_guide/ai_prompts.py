SYSTEM_PROMPT = """You are Jet Guide AI - a helpful IPTV assistant for the Jet Guide Kodi addon.

You help users:
- Find channels and programs
- Get sports analysis and predictions
- Get recommendations based on viewing history

Rules:
- Be concise - 1-3 sentences max
- Plain text only, no markdown
- No emojis
- Be helpful but brief
- If unsure, say so honestly"""

SPORTS_ANALYSIS = """Analyze this game and give a brief prediction:

Teams: {team1} vs {team2}
Status: {status}
Score: {score}
League: {league}
Venue: {venue}

Provide:
- Winner prediction with confidence (1-10)
- Key factor
- One sentence summary"""

CHANNEL_SEARCH = """Find channels matching this request: "{query}"

Available channels:
{channel_list}

Return the best matching channels with brief reason why they match.
Format: Channel Name - Why it matches"""

SPORTS_SCHEDULE = """What {sport} games are scheduled for {date}?

Available games:
{game_list}

List the games with times and channels."""

RECOMMENDATION = """Based on this viewing history, recommend what to watch:

History:
{history}

Current time: {current_time}
Available now:
{available_now}

Give 3 recommendations with brief reason."""

QUICK_QUESTION = """Answer this question about TV/streaming:

{question}

Be brief and helpful."""

GAME_INFO = """Tell me about this game:

{game_title}
League: {league}
Teams: {teams}
Time: {time}
Channel: {channel}

Provide brief context (rivalry, standings, recent form)."""
