import os
import json
from datetime import datetime, timedelta

import xbmcaddon
import xbmcvfs
import xbmc


class WatchHistoryManager:
    def __init__(self):
        self.addon = xbmcaddon.Addon()
        self.profile_path = xbmcvfs.translatePath(self.addon.getAddonInfo('profile'))
        try:
            os.makedirs(self.profile_path, exist_ok=True)
        except Exception:
            pass
        self.history_path = os.path.join(self.profile_path, 'watch_history.json')
        self.max_entries = 200

    def _is_enabled(self):
        return self.addon.getSetting('ai_history_enabled') != 'false'

    def _get_history_days(self):
        try:
            return int(self.addon.getSetting('ai_history_days') or '7')
        except ValueError:
            return 7

    def _load_history(self):
        try:
            if not os.path.exists(self.history_path):
                return []
            with open(self.history_path, 'r', encoding='utf-8') as f:
                content = f.read()
                if not content.strip():
                    return []
                data = json.loads(content)
                if not isinstance(data, list):
                    return []
                return data
        except Exception:
            return []

    def _save_history(self, history):
        try:
            temp_path = self.history_path + '.tmp'
            with open(temp_path, 'w', encoding='utf-8') as f:
                json.dump(history[-self.max_entries:], f, indent=2, ensure_ascii=False)
            if os.path.exists(self.history_path):
                os.remove(self.history_path)
            os.rename(temp_path, self.history_path)
        except Exception as e:
            xbmc.log(f"[jet_guide] Failed to save watch history: {e}", xbmc.LOGERROR)
            try:
                if os.path.exists(temp_path):
                    os.remove(temp_path)
            except Exception:
                pass

    def record_watch(self, channel, program=None):
        if not self._is_enabled():
            xbmc.log("[jet_guide] Watch history disabled in settings", xbmc.LOGINFO)
            return
        try:
            now = datetime.now()
            entry = {
                'name': channel.get('name', ''),
                'tvg_id': channel.get('tvg_id', ''),
                'group': channel.get('group', ''),
                'logo': channel.get('logo', ''),
                'timestamp': now.isoformat(),
                'hour': now.hour,
                'day': now.strftime('%A'),
                'date': now.strftime('%Y-%m-%d')
            }
            if program:
                entry['program_title'] = program.get('title', '')
                entry['program_category'] = program.get('category', '')
                entry['program_desc'] = program.get('desc', '')[:200] if program.get('desc') else ''
                entry['program_sub_title'] = program.get('sub-title', '') if program.get('sub-title') else ''
            history = self._load_history()
            history.append(entry)
            history = history[-self.max_entries:]
            self._save_history(history)
            prog_info = f" [{entry.get('program_title', '')}]" if entry.get('program_title') else ""
            xbmc.log(f"[jet_guide] Watch recorded: {entry['name']}{prog_info} at {entry['day']} {entry['hour']:02d}:00 (total: {len(history)})", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"[jet_guide] Failed to record watch: {e}", xbmc.LOGERROR)

    def get_history(self, days=None):
        if days is None:
            days = self._get_history_days()
        try:
            history = self._load_history()
            if not history:
                return []
            cutoff = datetime.now() - timedelta(days=days)
            filtered = []
            for entry in history:
                try:
                    ts = datetime.fromisoformat(entry.get('timestamp', ''))
                    if ts >= cutoff:
                        filtered.append(entry)
                except (ValueError, TypeError):
                    continue
            return filtered
        except Exception:
            return []

    def get_summary(self):
        history = self.get_history()
        if not history:
            return None

        channel_counts = {}
        group_counts = {}
        hour_counts = {}
        day_counts = {}
        program_counts = {}
        category_counts = {}

        for entry in history:
            name = entry.get('name', 'Unknown')
            group = entry.get('group', 'General')
            hour = entry.get('hour', -1)
            day = entry.get('day', 'Unknown')
            program_title = entry.get('program_title', '')
            program_category = entry.get('program_category', '')

            channel_counts[name] = channel_counts.get(name, 0) + 1
            group_counts[group] = group_counts.get(group, 0) + 1
            if 0 <= hour <= 23:
                hour_counts[hour] = hour_counts.get(hour, 0) + 1
            day_counts[day] = day_counts.get(day, 0) + 1
            if program_title:
                program_counts[program_title] = program_counts.get(program_title, 0) + 1
            if program_category:
                category_counts[program_category] = category_counts.get(program_category, 0) + 1

        top_channels = sorted(channel_counts.items(), key=lambda x: x[1], reverse=True)[:5]
        top_groups = sorted(group_counts.items(), key=lambda x: x[1], reverse=True)[:5]
        peak_hours = sorted(hour_counts.items(), key=lambda x: x[1], reverse=True)[:3]
        peak_days = sorted(day_counts.items(), key=lambda x: x[1], reverse=True)[:3]
        top_programs = sorted(program_counts.items(), key=lambda x: x[1], reverse=True)[:5]
        top_categories = sorted(category_counts.items(), key=lambda x: x[1], reverse=True)[:5]

        return {
            'total_watches': len(history),
            'top_channels': top_channels,
            'top_groups': top_groups,
            'top_programs': top_programs,
            'top_categories': top_categories,
            'peak_hours': peak_hours,
            'peak_days': peak_days,
            'days_covered': self._get_history_days()
        }

    def format_history_for_ai(self):
        history = self.get_history()
        if not history:
            return "No viewing history available yet."

        lines = []
        for entry in history[-15:]:
            name = entry.get('name', 'Unknown')
            group = entry.get('group', 'General')
            day = entry.get('day', '')
            hour = entry.get('hour', -1)
            time_str = f"{hour:02d}:00" if 0 <= hour <= 23 else "?"
            program = entry.get('program_title', '')
            category = entry.get('program_category', '')
            line = f"- {name} ({group}) - {day} {time_str}"
            if program:
                line += f' - "{program}"'
                if category:
                    line += f" [{category}]"
            lines.append(line)

        return "\n".join(lines)

    def clear_history(self):
        self._save_history([])
        xbmcgui = __import__('xbmcgui')
        xbmcgui.Dialog().notification('Watch History', 'Watch history cleared')

    def show_history(self):
        xbmcgui = __import__('xbmcgui')
        history = self.get_history()
        if not history:
            xbmcgui.Dialog().ok('Watch History', 'No watch history recorded yet.\nPlay some channels first!')
            return

        summary = self.get_summary()
        lines = []
        lines.append(f"Total watches: {summary['total_watches']}")
        if summary.get('top_channels'):
            top = ", ".join([f"{n} ({c}x)" for n, c in summary['top_channels'][:5]])
            lines.append(f"Most watched channels: {top}")
        if summary.get('top_programs'):
            progs = ", ".join([f"{n} ({c}x)" for n, c in summary['top_programs'][:5]])
            lines.append(f"Favorite shows: {progs}")
        if summary.get('top_groups'):
            groups = ", ".join([f"{g} ({c}x)" for g, c in summary['top_groups'][:5]])
            lines.append(f"Genres: {groups}")
        if summary.get('top_categories'):
            cats = ", ".join([f"{g} ({c}x)" for g, c in summary['top_categories'][:5]])
            lines.append(f"Categories: {cats}")
        if summary.get('peak_hours'):
            hours = ", ".join([f"{h}:00 ({c}x)" for h, c in summary['peak_hours'][:3]])
            lines.append(f"Peak hours: {hours}")

        lines.append("")
        lines.append("Recent history:")
        for entry in history[-10:][::-1]:
            name = entry.get('name', '?')
            group = entry.get('group', '')
            day = entry.get('day', '')
            hour = entry.get('hour', -1)
            program = entry.get('program_title', '')
            t = f"{hour:02d}:00" if 0 <= hour <= 23 else "?"
            label = f"  {name}"
            if program:
                label += f' - "{program}"'
            if group:
                label += f" ({group})"
            label += f" - {day} {t}"
            lines.append(label)

        xbmcgui.Dialog().ok('Watch History', '\n'.join(lines))
