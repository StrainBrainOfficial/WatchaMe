# Remote Scraper Hot-Updates

## Goal

Allow patched scraper `.py` files to be pushed from the server to clients **without reinstalling the addon**. Scrapers execute **locally** from disk (no runtime network latency), but the developer can fix a broken scraper remotely by uploading a new `.py` file + updating a manifest.

## Status

- **Phase 1**: Manifest + atomic file replace + in-session module reload — Complete
- **Phase 2**: Background check on Kodi startup (via MadTitanSports service) — Planned

## Design

### Architecture

```
Server hosts:
  scrapers_manifest.json          — maps {filename, version, hash, url}
  scrapers/<name>.py              — raw scraper files

Client:
  scraper_updater.py              — checks manifest, downloads, hash-verifies,
                                    atomically replaces files, clears module cache
  extractor.py:get_extractors()   — calls updater on each invocation (TTL-guarded)
  extractors/__init__.py          — unchanged; auto-discovers replaced files on next run
```

### Manifest Format

```json
{
  "version": "2026-09-05",
  "scrapers": {
    "backdoor2.py": {
      "version": "1.2.3",
      "hash": "a1b2c3d4e5f6...",
      "url": "https://magnetic.website/Jetextractor/scrapers/backdoor2.py"
    }
  }
}
```

- `version`: Semantic version string for human reference
- `hash`: SHA-256 of the file content — client verifies after download
- `url`: Direct download URL for the scraper file

### Update Flow

1. `get_extractors()` calls `check_for_updates()`
2. If manifest was checked within TTL (6 hours) → return immediately (cached)
3. Otherwise download `scrapers_manifest.json` from server
4. For each entry in manifest, compare local file's SHA-256 against manifest `hash`
5. If mismatch → download raw `.py` from `url`
6. Verify downloaded content's SHA-256 matches manifest
7. Atomically replace: write to `.tmp` → `os.replace()` to target path
8. Mark files for module reload
9. Clear `sys.modules` entries and `JetExtractor.subclasses` for updated extractors
10. Clear `_extractor_cache` in `extractor.py`

### TTL & Caching

- Check interval: **6 hours** (configurable, hardcoded to `CACHE_TTL`)
- Cache state stored in addon profile: `userdata/addon_data/script.module.jetextractors/scraper_updates.json`
- Tracks: `last_check` timestamp, per-file hashes

### Security

- Hash verification prevents corruption / partial downloads
- Server is trusted (same server already hosts `config.json`)
- Scrapers are Python code — security relies on server integrity

### Writable Directory

- Portable Kodi mode: `portable_data/addons/.../lib/jetextractors/extractors/` is writable
- Normal Kodi install: `.kodi/addons/.../` may be read-only → catch `PermissionError`, skip update
- Add-on profile dir is always writable for cache state

### Module Cache Handling

Python caches imported modules in `sys.modules`. After replacing a file:

- **Phase 1 (restart)**: Replace files on disk, notify user to restart Kodi. Auto-discovery in `extractors/__init__.py` picks up new files on next launch.
- **Phase 2 (in-session)**: Remove updated modules from `sys.modules`, remove stale classes from `JetExtractor.subclasses` (matched by `__module__`), clear `_extractor_cache` in `extractor.py`. Next `get_extractors()` call re-imports from disk.

## Files to Create/Modify

| File | Action |
|------|--------|
| `endpoints.py` | Add `SCRAPERS_MANIFEST` and `SCRAPERS_DIR` URLs |
| `lib/jetextractors/scraper_updater.py` | **NEW** — manifest check, download, hash verify, atomic replace, module cache clear |
| `lib/jetextractors/extractor.py` | Call `check_for_updates()` in `get_extractors()` after config validation |
| `lib/jetextractors/extractors/__init__.py` | No changes needed (auto-discovery handles it) |

## Server Requirements

1. Host `scrapers_manifest.json` at `https://magnetic.website/Jetextractor/scrapers_manifest.json`
2. Host individual scraper files at `https://magnetic.website/Jetextractor/scrapers/<filename>.py`
3. When a scraper is fixed:
   - Upload the new `.py` file
   - Update the manifest entry with the new version and SHA-256 hash
4. The hash must be computed on the exact file content served to clients

### Generating the manifest hash

```powershell
Get-FileHash -Algorithm SHA256 "path\to\scrapers\backdoor2.py"
# Then put that hex string in the manifest's "hash" field
```

**Important:** The hash must match the **file served by the server**, not a local file. After uploading to the server, download the URL in a browser and check its hash to verify.

### Case-Insensitive Hash Comparison

Hashes from PowerShell `Get-FileHash` are **uppercase** (e.g. `A1EBA8AE...`), while Python's `hashlib.sha256().hexdigest()` returns **lowercase** (e.g. `a1eba8ae...`). The client performs case-insensitive comparison, but the manifest hash must still match the server file's content.

## Troubleshooting

### "Not checking" — Update check not running

The updater caches its last check timestamp in a **separate** file from `config.json`:

```
userdata/addon_data/script.module.jetextractors/scraper_updates.json
```

If this file has a recent `last_check` (within 6 hours), the check is skipped. **Delete `scraper_updates.json`** (not `config.json`) to force a recheck.

### "Hash mismatch" — Manifest hash doesn't match server file

The `hash` in the manifest must match the **exact file content** served at the manifest's `url`. Common causes:

1. **Uploaded file differs from local file** — Verify by downloading the server URL in a browser and computing its hash
2. **Line ending changes** — FTP/SFTP uploads may convert CRLF to LF; compute hash of the file as served
3. **Server caching** — Old manifest or scraper file still cached on the server

### Debug logging

Ensure debug logging is enabled (`set_debug_logging(True)` in `tools.py`) to see `[ScraperUpdater]` log messages.

## Model Tracking

| Date | Model | Changes |
|------|-------|---------|
| 2026-09-05 | poolside/laguna-s-2.1:free | Created REMOTE_SCRAPER_UPDATES.md, endpoints.py, scraper_updater.py, extractor.py integration |
| 2026-09-06 | poolside/laguna-s-2.1:free | Fixed hash case-sensitivity bug: PowerShell uppercase hashes now compare correctly against Python lowercase hashes. Added troubleshooting section. |