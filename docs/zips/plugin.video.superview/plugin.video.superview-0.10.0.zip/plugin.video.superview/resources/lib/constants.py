HEADERS = {
    'User-Agent': 'okhttp/4.9.2',
}

API_KEY = 'AIzaSyD03FKEKThDFl99ffyYh1bX56VjeL9yr_c'
BRIGHTCOVE_ACCOUNT = '2178772919001'
BRIGHTCOVE_URL = 'https://edge.api.brightcove.com/playback/v1/accounts/{}/videos/{}'
BRIGHTCOVE_SEARCH_URL = 'https://edge.api.brightcove.com/playback/v1/accounts/{}/videos'
BRIGHTCOVE_PLAYLIST_URL = 'https://edge.api.brightcove.com/playback/v1/accounts/{}/playlists/{}'
BRIGHTCOVE_KEY = 'BCpkADawqM3Dyn1_vgnP05Nq8fiXYD4Pp9GKnFUihsFEkee8Hw6lMlVhBHyFj4Nuh6TjQG0cCBxx76_Rv4b-icR1VMzKV0DJNRMwwRw_hvsifuJblEHioBpWWcgVVxJQp1YzglvwNpMsRr3KP2YRPeGLfFobWOjpYGAx8XejU86a2SsFTiox1iCBsxo'
BRIGHTCOVE_HEADERS = {
    'accept': 'application/json;pk={}'.format(BRIGHTCOVE_KEY),
}

# Public delivery details used by the supercars.com SuperView videos page
CONTENTFUL_URL = 'https://graphql.contentful.com/content/v1/spaces/xd502h20t7lh/environments/master'
CONTENTFUL_TOKEN = 'YWE3dZdeYAsAN4P5tcToxIQ7tfoytqC47YBKujq2kx0'
CONTENTFUL_HEADERS = {
    'Authorization': 'Bearer {}'.format(CONTENTFUL_TOKEN),
    'Content-Type': 'application/json',
}
CONTENTFUL_QUERY = '''
query($now: DateTime!) {
    superviewVideosLandingPageCollection(limit: 1) {
        items {
            brightcoveVideo
            startingTime
            brightcovePlaylistSectionsCollection {
                items {
                    title
                    brightcovePlaylist
                }
            }
        }
    }
    eventCollection(where: {startDate_lte: $now, endDate_gte: $now}, order: startDate_DESC, limit: 1) {
        items {
            title
            internalName
            location
            slug
            startDate
            endDate
            description
            season {
                year
            }
            track {
                title
                laps
            }
            heroMedia {
                url
                width
                height
            }
            calendarPosterImage {
                url
                width
                height
            }
            raceSessionsCollection(where: {type: "Race", series: {name: "Repco Supercars Championship"}}, order: startDate_ASC, limit: 20) {
                items {
                    startDate
                    endDate
                }
            }
            liveFeed {
                entryTitle
            }
        }
    }
}
'''
CONTENTFUL_EVENTS_QUERY = '''
query($from: DateTime!, $to: DateTime!) {
    eventCollection(where: {startDate_gte: $from, startDate_lte: $to}, order: startDate_ASC, limit: 100) {
        items {
            title
            internalName
            location
            slug
            startDate
            endDate
            description
            season {
                year
            }
            track {
                title
                laps
            }
            heroMedia {
                url
                width
                height
            }
            calendarPosterImage {
                url
                width
                height
            }
            raceSessionsCollection(where: {type: "Race", series: {name: "Repco Supercars Championship"}}, order: startDate_ASC, limit: 20) {
                items {
                    startDate
                    endDate
                }
            }
        }
    }
}
'''
