import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://magnetic.website/wizard19/Text/builds.xml'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://magnetic.website/wizard19/Text/notify.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
