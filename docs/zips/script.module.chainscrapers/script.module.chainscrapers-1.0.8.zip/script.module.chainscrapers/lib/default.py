# -*- coding: utf-8 -*-
"""
	Fenomscrapers Module
"""

from sys import argv
from urllib.parse import parse_qsl
from chainscrapers import sources_chainscrapers
from chainscrapers.modules import control

params = dict(parse_qsl(argv[2].replace('?', '')))
action = params.get('action')

if action is None:
	control.openSettings('0.0', 'script.module.chainscrapers')

if action == "chainscrapersSettings":
	control.openSettings('0.0', 'script.module.chainscrapers')

elif action == 'ShowChangelog':
	from chainscrapers.modules import changelog
	changelog.get()

elif action == 'ShowHelp':
	from chainscrapers.help import help
	help.get(params.get('name'))

elif action == "Defaults":
	control.setProviderDefaults()

elif action == "toggleAll":
	sourceList = []
	sourceList = sources_chainscrapers.all_providers
	for i in sourceList:
		source_setting = 'provider.' + i
		control.setSetting(source_setting, params['setting'])

elif action == "toggleAllHosters":
	sourceList = []
	sourceList = sources_chainscrapers.hoster_providers
	for i in sourceList:
		source_setting = 'provider.' + i
		control.setSetting(source_setting, params['setting'])

elif action == "toggleAllTorrent":
	sourceList = []
	sourceList = sources_chainscrapers.torrent_providers
	for i in sourceList:
		source_setting = 'provider.' + i
		control.setSetting(source_setting, params['setting'])

elif action == "toggleAllPackTorrent":
	control.execute('RunPlugin(plugin://script.module.chainscrapers/?action=toggleAllTorrent&amp;setting=false)')
	control.sleep(500)
	sourceList = []
	from chainscrapers import pack_sources
	sourceList = pack_sources()
	for i in sourceList:
		source_setting = 'provider.' + i
		control.setSetting(source_setting, params['setting'])

elif action == 'cleanSettings':
	control.clean_settings()

elif action == 'undesirablesSelect':
	from chainscrapers.modules.undesirables import undesirablesSelect
	undesirablesSelect()

elif action == 'undesirablesInput':
	from chainscrapers.modules.undesirables import undesirablesInput
	undesirablesInput()

elif action == 'undesirablesUserRemove':
	from chainscrapers.modules.undesirables import undesirablesUserRemove
	undesirablesUserRemove()

elif action == 'undesirablesUserRemoveAll':
	from chainscrapers.modules.undesirables import undesirablesUserRemoveAll
	undesirablesUserRemoveAll()

elif action == 'tools_clearLogFile':
	from chainscrapers.modules import log_utils
	cleared = log_utils.clear_logFile()
	if cleared == 'canceled': pass
	elif cleared: control.notification(message='chainscrapers Log File Successfully Cleared')
	else: control.notification(message='Error clearing chainscrapers Log File, see kodi.log for more info')

elif action == 'tools_viewLogFile':
	from chainscrapers.modules import log_utils
	log_utils.view_LogFile(params.get('name'))

elif action == 'tools_viewTorrentStats':
	from chainscrapers.modules import log_utils
	log_utils.view_TorrentStats(params.get('name'))

elif action == 'tools_uploadLogFile':
	from chainscrapers.modules import log_utils
	log_utils.upload_LogFile()

elif action == 'plexAuth':
	from chainscrapers.modules import plex
	plex.Plex().auth()

elif action == 'plexRevoke':
	from chainscrapers.modules import plex
	plex.Plex().revoke()

elif action == 'plexSelectShare':
	from chainscrapers.modules import plex
	plex.Plex().get_plexshare_resource()

elif action == 'plexSeeShare':
	from chainscrapers.modules import plex
	plex.Plex().see_active_shares()

elif action == 'ShowOKDialog':
	control.okDialog(params.get('title', 'default'), int(params.get('message', '')))

elif action == 'TestProwlarrConnection':
	from chainscrapers.modules.prowlarr import Prowlarr
	prowlarr = Prowlarr()
	prowlarr.test()

elif action == 'ProwlarrIndexers':
	from chainscrapers.modules.prowlarr import Prowlarr
	prowlarr = Prowlarr()
	prowlarr.get_indexers()

elif action == 'mediafusionAuth':
	from chainscrapers.modules.mediafusion import MediaFusion
	mediafusion = MediaFusion()
	mediafusion.auth()

elif action == 'mediafusionReset':
	from chainscrapers.modules.mediafusion import MediaFusion
	mediafusion = MediaFusion()
	mediafusion.clear()

elif action == 'healthCheck':
	from chainscrapers.modules.health import Magneto
	Magneto().health_check()