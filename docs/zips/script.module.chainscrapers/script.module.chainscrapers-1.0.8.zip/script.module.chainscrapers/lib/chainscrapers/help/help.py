# -*- coding: utf-8 -*-
"""
	Fenomscrapers Module
"""

from chainscrapers.modules.control import addonPath, addonVersion, joinPath
from chainscrapers.windows.textviewer import TextViewerXML


def get(file):
	chainscrapers_path = addonPath()
	chainscrapers_version = addonVersion()
	helpFile = joinPath(chainscrapers_path, 'lib', 'chainscrapers', 'help', file + '.txt')
	r = open(helpFile, 'r', encoding='utf-8', errors='ignore')
	text = r.read()
	r.close()
	heading = '[B]chainscrapers -  v%s - %s[/B]' % (chainscrapers_version, file)
	windows = TextViewerXML('textviewer.xml', chainscrapers_path, heading=heading, text=text)
	windows.run()
	del windows