from time import time
from six.moves.urllib_parse import urlencode

from slyguy import userdata, mem_cache
from slyguy.log import log
from slyguy.util import jwt_data
from slyguy.session import Session
from slyguy.exceptions import Error

from .settings import HEADERS, BASE_URL, PAGE_SIZE
from .language import _


class APIError(Error):
    pass


class API(object):
    def new_session(self):
        self.logged_in = False
        self._session = Session(headers=HEADERS, base_url=BASE_URL)
        self.logged_in = userdata.get('key', None) != None

        #LEGACY
        userdata.delete('token')
        userdata.delete('user_id')

    def _set_auth(self, token):
        self._session.headers.update({'Authorization': 'Bearer {}'.format(token)})

    def login(self, username, password):
        self.logout()

        payload = {
            'email': username,
            'password': password,
        }

        data = self._session.post('https://users.api.nebula.app/api/v1/auth/login/', json=payload).json()
        if 'key' not in data or not data['key']:
            msg = data['non_field_errors'][0]
            raise APIError(msg)

        userdata.set('key', data['key'])

    def _refresh_token(self, force=False):
        token = userdata.get('auth_token')
        if token and not force and userdata.get('expires', 0) > time():
            self._set_auth(token)
            return

        log.debug('Refreshing token' if token else 'Fetching token')

        key = userdata.get('key')
        data = self._session.post('https://users.api.nebula.app/api/v1/authorization/', params={'from': 'Android'}, json={}, headers={'Authorization': 'Token {}'.format(key)}).json()

        token = data['token']
        jwt = jwt_data(token)

        userdata.set('auth_token', token)
        userdata.set('expires', jwt['exp'] - 10)

        self._set_auth(token)

    @mem_cache.cached(expires=60*5)
    def categories(self, content_type):
        self._refresh_token()
        params = {
            'type': content_type,
        }
        return self._session.get('/categories/', params=params).json()['results']

    def url(self, url):
        self._refresh_token()
        return self._session.get(url).json()

    @mem_cache.cached(expires=60*5)
    def podcast_episodes(self, category='', page=1, page_size=PAGE_SIZE):
        self._refresh_token()

        params = {
            'offset': page_size*(page-1),
            'page_size': page_size,
        }
        if category:
            params['category'] = category

        return self._session.get('/podcast_episodes/', params=params).json()

    @mem_cache.cached(expires=60*5)
    def podcast_creators(self, category='', page=1, page_size=PAGE_SIZE):
        self._refresh_token()
        params = {
            'offset': page_size*(page-1),
            'page_size': page_size,
            'ordering': 'title',
        }
        if category:
            params['category'] = category
        return self._session.get('/podcast_channels/', params=params).json()

    @mem_cache.cached(expires=60*5)
    def podcast_creator(self, id):
        self._refresh_token()
        return self._session.get('/podcast_channels/{id}'.format(id=id)).json()

    @mem_cache.cached(expires=60*5)
    def podcast_creator_episodes(self, id, page=1, page_size=PAGE_SIZE):
        self._refresh_token()
        params = {
            'offset': page_size*(page-1),
            'page_size': page_size,
        }
        return self._session.get('/podcast_channels/{id}/podcast_episodes/'.format(id=id), params=params).json()

    @mem_cache.cached(expires=60*5)
    def class_info(self, id):
        self._refresh_token()
        return self._session.get('/classes/{id}/'.format(id=id)).json()

    @mem_cache.cached(expires=60*5)
    def lessons(self, id, page=1, page_size=PAGE_SIZE):
        self._refresh_token()
        params = {
            'offset': page_size*(page-1),
            'page_size': page_size,
        }
        return self._session.get('/classes/{id}/lessons/'.format(id=id), params=params).json()

    @mem_cache.cached(expires=60*5)
    def search(self, query, page=1, page_size=PAGE_SIZE):
        self._refresh_token()

        rows = []
        params = {
            'q': query,
            'offset': page_size*(page-1),
            'page_size': 24,
        }
        if page == 1:
            rows.extend(self._session.get('/video_channels/search/', params=params).json()['results'])
            rows.extend(self._session.get('/podcast_channels/search/', params=params).json()['results'])
            rows.extend(self._session.get('/podcast_episodes/search/', params=params).json()['results'])
            rows.extend(self._session.get('/classes/search/', params=params).json()['results'])
            params['video_playlist_type'] = 'miniseries'
            rows.extend(self._session.get('/video_playlists/search/', params=params).json()['results'])

        params.pop('video_playlist_type', None)
        data = self._session.get('/video_episodes/search/', params=params).json()
        rows.extend(data['results'])
        return rows, data['next']

    @mem_cache.cached(expires=60*5)
    def featured(self):
        self._refresh_token()
        return self._session.get('/content/featured/').json()

    @mem_cache.cached(expires=60*5)
    def videos(self, category='', page=1, page_size=PAGE_SIZE):
        self._refresh_token()

        params = {
            'offset': page_size*(page-1),
            'page_size': page_size,
        }
        if category:
            params['category'] = category

        return self._session.get('/video_episodes/', params=params).json()

    def latest_videos(self, page=1, page_size=PAGE_SIZE):
        self._refresh_token()

        params = {
            'offset': page_size*(page-1),
            'page_size': page_size,
            'following': 'true',
            'ordering': '-published_at',
        }

        return self._session.get('/video_episodes/', params=params).json()

    def watch_later(self, page=1, page_size=PAGE_SIZE):
        self._refresh_token()

        params = {
            'offset': page_size*(page-1),
            'page_size': page_size,
            'ordering': '-added_to_playlist',
        }

        return self._session.get('/user_playlists/watch-later/video_episodes/', params=params).json()

    def watch_history(self, page=1, page_size=PAGE_SIZE):
        self._refresh_token()

        params = {
            'offset': page_size*(page-1),
            'page_size': page_size,
            'progress': 'any_progress',
            'ordering': '-progress',
        }

        return self._session.get('/video_episodes/', params=params).json()

    def my_creators(self, page=1, page_size=PAGE_SIZE):
        self._refresh_token()

        params = {
            'offset': page_size*(page-1),
            'page_size': page_size,
            'following': 'true',
            'ordering': '-follow',
        }

        return self._session.get('/video_channels/', params=params).json()

    @mem_cache.cached(expires=60*5)
    def creator(self, id):
        self._refresh_token()
        return self._session.get('/video_channels/{id}/'.format(id=id)).json()

    @mem_cache.cached(expires=60*5)
    def creator_videos(self, id, page=1, page_size=PAGE_SIZE):
        self._refresh_token()

        params = {
            'offset': page_size*(page-1),
            'page_size': page_size,
        }

        return self._session.get('/video_channels/{id}/video_episodes/'.format(id=id), params=params).json()

    @mem_cache.cached(expires=60*5)
    def creators(self, category='', page=1, page_size=PAGE_SIZE):
        self._refresh_token()

        params = {
            'offset': page_size*(page-1),
            'page_size': page_size,
        }
        if category:
            params['category'] = category

        return self._session.get('/video_channels/', params=params).json()

    def follow_creator(self, slug):
        self._refresh_token()

        payload = {
            'channel_slug': slug,
        }

        if not self._session.post('/engagement/video/follow/', json=payload).ok:
            raise APIError('Failed to follow creator')

    def unfollow_creator(self, slug):
        self._refresh_token()

        payload = {
            'channel_slug': slug,
        }

        if not self._session.post('/engagement/video/unfollow/', json=payload).ok:
            raise APIError('Failed to unfollow creator')

    def play(self, content_type, id):
        self._refresh_token()
        params = {
            'token': userdata.get('auth_token'),
            'app_version': '25.13.0',
            'platform': 'web',
            'compatibility': '',
            'all_manifest': 'true',
        }
        return BASE_URL.format('/{}/{}/manifest.m3u8?{}'.format(content_type, id, urlencode(params)))

    def play_podcast(self, channel, episode):
        self._refresh_token()
        return self._session.get('/content/{channel}/{episode}/'.format(channel=channel, episode=episode)).json()

    def logout(self):
        userdata.delete('key')
        userdata.delete('auth_token')
        userdata.delete('expires')
        mem_cache.empty()
        self.new_session()
