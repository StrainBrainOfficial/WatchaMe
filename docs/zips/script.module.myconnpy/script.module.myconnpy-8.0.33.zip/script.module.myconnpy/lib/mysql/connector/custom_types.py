# Copyright (c) 2014, 2022, Oracle and/or its affiliates. All rights reserved.
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License, version 2.0, as
# published by the Free Software Foundation.
#
# This program is also distributed with certain software (including
# but not limited to OpenSSL) that is licensed under separate terms,
# as designated in a particular file or component or in included license
# documentation.  The authors of MySQL hereby grant you an
# additional permission to link the program and your derivative works
# with the separately licensed software that they have included with
# MySQL.
#
# Without limiting anything contained in the foregoing, this file,
# which is part of MySQL Connector/Python, is also subject to the
# Universal FOSS Exception, version 1.0, a copy of which can be found at
# http://oss.oracle.com/licenses/universal-foss-exception.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the GNU General Public License, version 2.0, for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA

"""Custom Python types used by MySQL Connector/Python"""
from __future__ import annotations

from typing import Type


class HexLiteral(str):

    """Class holding MySQL hex literals"""

    charset: str = ""
    original: str = ""

    def __new__(cls: Type[HexLiteral], str_: str, charset: str = "utf8") -> HexLiteral:
        hexed = [f"{i:02x}" for i in str_.encode(charset)]
        obj = str.__new__(cls, "".join(hexed))
        obj.charset = charset
        obj.original = str_
        return obj

    def __str__(self) -> str:
        return "0x" + self
