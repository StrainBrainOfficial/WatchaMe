# -*- coding: utf-8 -*-
"""Debrid accounts for the Starfleet resolver: pair a service, then turn hoster links into direct links through it.

    from starfleetresolve import debrid
    debrid.pair('offcloud')                 # shows a code + address, waits for approval, stores the account
    debrid.authorized()                     # ['realdebrid', 'offcloud', ...]
    debrid.unrestrict('https://rapidgator.net/file/..')      # ('https://...direct', 'realdebrid') or None
    debrid.supports(url)                    # services (paired) whose host list covers this address
    debrid.status()                         # {'realdebrid': {'user': ..., 'premium': True, ...}, ...}

Services: Real-Debrid, AllDebrid, Premiumize, TorBox, Debrid-Link, Offcloud, Mega-Debrid."""
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

from starfleetresolve import common
from starfleetresolve.debrid import store, importer
from starfleetresolve.debrid.services import ALL, BY_ID

DEFAULT_ORDER = ['realdebrid', 'alldebrid', 'premiumize', 'torbox', 'debridlink', 'offcloud', 'megadebrid']


def service(sid):
    importer.ensure()
    return BY_ID.get(sid)


def services():
    """[(id, name, authorized)] for every supported service."""
    importer.ensure()
    return [(s.id, s.name, s.authorized()) for s in ALL]


def authorized():
    importer.ensure()
    return [s.id for s in ALL if s.authorized()]


def order():
    saved = store.get('prefs').get('order')
    base = [i for i in (saved or DEFAULT_ORDER) if i in BY_ID]
    return base + [i for i in DEFAULT_ORDER if i not in base]


def reset(sid):
    s = BY_ID.get(sid)
    if s:
        s.reset()
        store.clear(sid + '_hosts')


def status():
    importer.ensure()
    out = {}
    for s in ALL:
        if s.authorized():
            try:
                out[s.id] = s.account() or {'user': '?'}
            except Exception:
                out[s.id] = {'user': '?'}
    return out


# ── pairing ──────────────────────────────────────────────────────────────────

class _KodiUI(object):
    """Progress dialog with the address, the code and a countdown; Cancel stops the pairing."""

    def __init__(self, title):
        import xbmcgui
        self._dlg = xbmcgui.DialogProgress()
        self._title = title

    def start(self, info):
        self._dlg.create(self._title, 'Go to: %s\nEnter code: %s' % (info.get('display_url') or info['url'], info['code']))

    def update(self, pct, info, remaining):
        self._dlg.update(pct, 'Go to: %s\nEnter code: %s\nWaiting for approval... %ds' % (
            info.get('display_url') or info['url'], info['code'], remaining))

    def cancelled(self):
        return self._dlg.iscanceled()

    def close(self):
        try:
            self._dlg.close()
        except Exception:
            pass


class _TextUI(object):
    """No Kodi (tests, scripts): print the instructions."""

    def __init__(self, title):
        self._title = title

    def start(self, info):
        print('%s: open %s and enter code %s' % (self._title, info.get('display_url') or info['url'], info['code']))

    def update(self, pct, info, remaining):
        pass

    def cancelled(self):
        return False

    def close(self):
        pass


def start_pairing(sid):
    """First half of pairing for callers with their own UI: returns the dict(url, code, expires_in, interval, state)."""
    s = BY_ID.get(sid)
    return s.start_pairing() if s else None


def poll_pairing(sid, state):
    """True when paired, False while waiting, None when the code expired / was refused."""
    s = BY_ID.get(sid)
    return s.poll_pairing(state) if s else None


def _pair_credentials(s):
    """Services with a login + password (Mega-Debrid): ask for both with Kodi dialogs and check them."""
    try:
        import xbmcgui
    except Exception:
        return False
    dlg = xbmcgui.Dialog()
    user = dlg.input('%s - username or e-mail' % s.name, type=xbmcgui.INPUT_ALPHANUM)
    if not user:
        return False
    pw = dlg.input('%s - password' % s.name, type=xbmcgui.INPUT_ALPHANUM, option=xbmcgui.ALPHANUM_HIDE_INPUT)
    if not pw:
        return False
    ok = s.pair_credentials(user.strip(), pw)
    if not ok:
        dlg.ok('Starfleet Resolver', '%s did not accept that login.' % s.name)
    return ok


def pair(sid, ui=None):
    """Run the whole pairing for `sid` (device code, or login + password for Mega-Debrid). True when the account is stored."""
    s = BY_ID.get(sid)
    if s is None:
        return False
    if getattr(s, 'credentials', None):
        return _pair_credentials(s)
    info = s.start_pairing()
    if not info:
        return False
    if ui is None:
        try:
            ui = _KodiUI('Starfleet - pair %s' % s.name)
        except Exception:
            ui = _TextUI('Starfleet - pair %s' % s.name)
    total = int(info.get('expires_in', 600))
    interval = max(int(info.get('interval', 5)), 2)
    end = time.time() + total
    ok = False
    try:
        ui.start(info)
        while time.time() < end:
            if ui.cancelled():
                break
            res = s.poll_pairing(info['state'])
            if res:
                ok = True
                break
            if res is None:
                break
            for _ in range(interval * 2):
                if ui.cancelled():
                    break
                ui.update(int(100 * (end - time.time()) / total), info, int(end - time.time()))
                time.sleep(0.5)
    finally:
        ui.close()
    if ok:
        common.log('%s paired' % s.name)
        try:                                        # ResolveURL (the fallback resolver) gets the same credentials
            importer.export_to_resolveurl(sid)
        except Exception as e:
            common.log('%s: ResolveURL not updated: %s' % (s.name, e))
    return ok


# ── links ────────────────────────────────────────────────────────────────────

def master_off():
    """The viewer switched "Use my debrid services" off in the app: accounts stay paired but are not used for links."""
    try:
        import xbmcaddon
        return (xbmcaddon.Addon('plugin.video.starfleet').getSetting('use_debrid') or '').strip().lower() == 'false'
    except Exception:
        return False


def supports(url):
    """Ids of the paired services whose own host list covers this address."""
    if master_off():
        return []
    importer.ensure()
    return [i for i in order() if BY_ID[i].authorized() and BY_ID[i].supports(url)]


def unrestrict(url, ids=None, parallel=False, timeout=30):
    """Direct link for a hoster address through the first service that can do it: (link, service id) or None.
    parallel=True asks all candidates at once and takes the first answer (faster, uses every account's request)."""
    cands = [i for i in (ids or supports(url)) if i in BY_ID]
    if not cands or master_off():
        return None
    if parallel and len(cands) > 1:
        ex = ThreadPoolExecutor(max_workers=len(cands))
        futs = {ex.submit(BY_ID[i].unrestrict, url): i for i in cands}
        ex.shutdown(wait=False)
        try:
            for f in as_completed(futs, timeout=timeout):
                try:
                    link = f.result()
                except Exception:
                    link = None
                if link:
                    return link, futs[f]
        except Exception:
            pass
        return None
    for i in cands:
        try:
            link = BY_ID[i].unrestrict(url)
        except Exception as e:
            common.log('%s unrestrict failed: %s' % (i, e))
            link = None
        if not link and importer.resync(i):                  # an imported account may have been re-paired at its source
            try:
                link = BY_ID[i].unrestrict(url)
            except Exception:
                link = None
        if link:
            return link, i
    return None


def unrestrict_any(url, timeout=25):
    """Last resort for an address no host list names: ask the paired services that accept any link (TorBox takes the
    sites yt-dlp supports) to open it. (link, service id) or None."""
    if master_off():
        return None
    importer.ensure()
    for s in ALL:
        if s.any_link and s.authorized():
            try:
                link = s.unrestrict(url)
            except Exception as e:
                common.log('%s any-link failed: %s' % (s.id, e))
                link = None
            if link:
                return link, s.id
    return None
