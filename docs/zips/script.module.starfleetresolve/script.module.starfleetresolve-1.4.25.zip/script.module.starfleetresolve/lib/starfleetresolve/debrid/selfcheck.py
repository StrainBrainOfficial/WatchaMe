# -*- coding: utf-8 -*-
"""Self check of the debrid accounts, run when Kodi starts, whenever the Starfleet plugin's or ResolveURL's settings file
changes (someone paired or re-paired there), and otherwise at most every few hours on first use.

For every service: if the account we hold still works, nothing changes. If it does not (or we hold none), the accounts
found in the Starfleet plugin's settings and in ResolveURL are tried, the plugin's first; the first one the service accepts
is adopted. A candidate that the service rejects is never kept, and the account we had is put back untouched.
Nothing is ever written to the other add-ons."""
import os
import threading

from starfleetresolve import common
from starfleetresolve.debrid import store, importer

EVERY = 6 * 3600


def _candidates(sid, pv=None, rv=None):
    """[(source, {field: value})] found in the plugin and ResolveURL settings for this service, plugin first."""
    if pv is None:
        pv = importer._read(importer._settings_path(importer.PLUGIN_ID))
    if rv is None:
        rv = importer._read(importer._settings_path(importer.RU_ID))
    out = []
    if sid == 'megadebrid':
        for src, vals, uk, pk, ek in (('plugin', pv, 'md_username', 'md_password', 'md_enabled'),
                                      ('resolveurl', rv, 'MegaDebridResolver_username', 'MegaDebridResolver_password', None)):
            if vals.get(uk) and vals.get(pk) and not (ek and vals.get(ek) == 'false'):
                out.append((src, {'login': vals[uk], 'password': vals[pk]}))
        return out
    key = importer.PLUGIN_KEYS.get(sid)
    if key and pv.get(key) and pv.get(key.replace('_api_key', '_enabled')) != 'false':
        out.append(('plugin', {'token': pv[key]}))
    prefix, fields = importer.MAP.get(sid, (None, {}))
    if prefix:
        rec = {ours: rv['%s_%s' % (prefix, theirs)] for theirs, ours in fields.items() if rv.get('%s_%s' % (prefix, theirs))}
        if rec.get('token'):
            if rec.get('refresh'):
                rec['expires_at'] = store.now() + 60          # refreshed on first use
            out.append(('resolveurl', rec))
    return out


def _works(svc):
    try:
        return bool((svc.account() or {}).get('user')) and svc.authorized()
    except Exception:
        return False


def _same(sid, old, rec):
    keys = ('login', 'password') if sid == 'megadebrid' else ('token',)
    return all(old.get(k) == rec.get(k) for k in keys)


def check_service(sid, candidates=None):
    """-> 'ok' (our account works) | 'adopted:<source>' | 'stale' (ours does not work, nothing better found) | 'none'.
    `candidates` is for tests."""
    from starfleetresolve.debrid.services import BY_ID
    svc = BY_ID.get(sid)
    if svc is None:
        return 'none'
    have = svc.authorized()
    if have and _works(svc):
        return 'ok'
    old = store.get(sid)
    cands = _candidates(sid) if candidates is None else candidates
    for src, rec in cands:
        if have and _same(sid, old, rec):
            continue                                   # that is the very account that just failed
        if sid == 'megadebrid':
            if svc.pair_credentials(rec['login'], rec['password']):
                store.put(sid, imported_from=src)
                common.log('debrid self-check: %s account taken from %s' % (sid, src))
                return 'adopted:' + src
            continue
        store.clear(sid)
        store.put(sid, imported_from=src, **rec)
        if _works(svc):
            common.log('debrid self-check: %s account taken from %s' % (sid, src))
            return 'adopted:' + src
        store.clear(sid)
        if old:
            store.put(sid, **old)                      # the candidate was no good: back to exactly what we had
    return 'stale' if have else 'none'


def stamp():
    """Modification times of the two settings files that can hold accounts (cheap to poll)."""
    out = []
    for addon in (importer.PLUGIN_ID, importer.RU_ID):
        try:
            out.append(os.path.getmtime(importer._settings_path(addon)))
        except OSError:
            out.append(0)
    return out


def run(force=False):
    """Check every service (in parallel). -> {service id: result}. Runs when forced, when either add-on's settings changed
    since the last check, or when the last check is older than EVERY; otherwise returns {} at once."""
    from starfleetresolve.debrid.services import ALL
    meta = store.get('_selfcheck')
    now, st = store.now(), stamp()
    if not force and meta.get('stamp') == st and now - meta.get('at', 0) < EVERY:
        return {}
    store.put('_selfcheck', at=now, stamp=st)
    results = {}

    def one(sid):
        try:
            results[sid] = check_service(sid)
        except Exception as e:
            common.log('debrid self-check %s failed: %s' % (sid, e))
            results[sid] = 'error'

    threads = [threading.Thread(target=one, args=(s.id,)) for s in ALL]
    for t in threads:
        t.daemon = True
        t.start()
    for t in threads:
        t.join(40)
    return results


def run_in_background(force=False):
    t = threading.Thread(target=run, kwargs={'force': force})
    t.daemon = True
    t.start()
    return t
