# -*- coding: utf-8 -*-
"""StreamTape: the page rebuilds the video address in JavaScript,
    document.getElementById('robotlink').innerHTML = '//streamtape.com' + ('xcd/get_video?id=..&token=..').substring(2).substring(1);
The LAST assignment to those elements holds the working token (the text already sitting in the page is a decoy).
Only string literals, '+' and .substring(n) are used, so a tiny evaluator is enough (no JavaScript engine)."""
import re

from starfleetresolve import common
from starfleetresolve.plugins.base import Resolver

_LIT = r"""(?:'(?:[^'\\]|\\.)*'|"(?:[^"\\]|\\.)*")"""
_PART = re.compile(r"\s*(?:\(\s*(" + _LIT + r")\s*\)((?:\s*\.substring\(\d+\))*)|(" + _LIT + r"))\s*(?:\+|$)")
_SUB = re.compile(r"\.substring\((\d+)\)")


def _evaluate(expr):
    out, pos = '', 0
    while pos < len(expr):
        m = _PART.match(expr, pos)
        if not m:
            return None
        if m.group(1):
            lit = m.group(1)[1:-1]
            for n in _SUB.findall(m.group(2) or ''):
                lit = lit[int(n):]
        else:
            lit = m.group(3)[1:-1]
        out += lit
        pos = m.end()
    return out


class StreamTape(Resolver):
    name = 'streamtape'
    domains = ('streamtape.com', 'streamtape.to', 'streamtape.net', 'stape.fun', 'strtape.tech', 'streamta.pe',
               'streamtape.xyz', 'tapecontent.net', 'shavetape.cash', 'streamadblocker.xyz')
    priority = 'first'

    def resolve(self, url, referer=''):
        link = url.split('|')[0].replace('/v/', '/e/')
        r = common.get(link, referer=referer or common.origin_of(link) + '/')
        if r is None or r.status_code != 200:
            return None
        o = common.origin_of(r.url)
        found = None
        for ident in ('robotlink', 'ideoolink', 'botlink'):
            ms = re.findall(r"getElementById\('" + ident + r"'\)\.innerHTML\s*=\s*(.*?);", r.text, re.S)
            if ms:
                found = _evaluate(ms[-1].strip())
                if found:
                    break
        if not found:
            u = common.find_media_url(r.text)
            return common.with_headers(u, referer=o + '/') if u else None
        if found.startswith('//'):
            found = 'https:' + found
        elif not found.startswith('http'):
            found = 'https://' + found.lstrip('/')
        return common.with_headers(found, referer=o + '/')
