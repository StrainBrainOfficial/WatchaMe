# -*- coding: utf-8 -*-
"""File lockers and file-style players that can be played straight from their free download address.

Every resolver here returns the host's own direct media address, so no debrid account is needed (a paired debrid
service is only used for the hosts that really need one). MediaFire, Gofile, Pixeldrain, Dropbox, Sendspace,
Solidfiles and Upload.ee have no ResolveURL resolver at all."""
import re
import json
import base64
from urllib.parse import urlparse, parse_qs, unquote, quote

from starfleetresolve import common
from starfleetresolve.plugins.base import Resolver

_BS = chr(92)


def _abs(base_url, u):
    u = u.replace('&amp;', '&').replace(_BS + '/', '/')
    if u.startswith('//'):
        return 'https:' + u
    if u.startswith('/'):
        return common.origin_of(base_url) + u
    return u


class Pixeldrain(Resolver):
    """pixeldrain.com/u/<id> -> /api/file/<id> (list pages /l/<id> -> first video file of /api/list/<id>)."""
    name = 'pixeldrain'
    domains = ('pixeldrain.com', 'pixeldrain.net', 'pixeldra.in')
    priority = 'first'

    def resolve(self, url, referer=''):
        base = url.split('|')[0]
        m = re.search(r'/(?:u|api/file)/([A-Za-z0-9_-]+)', base)
        o = common.origin_of(base)
        if m:
            return o + '/api/file/' + m.group(1) + '?download'
        m = re.search(r'/(?:l|api/list)/([A-Za-z0-9_-]+)', base)
        if m:
            r = common.get(o + '/api/list/' + m.group(1))
            try:
                files = r.json().get('files') or []
            except Exception:
                return None
            vids = [f for f in files if str(f.get('mime_type', '')).startswith(('video', 'audio'))] or files
            if vids:
                return o + '/api/file/' + vids[0]['id'] + '?download'
        return None


class Gofile(Resolver):
    """gofile.io/d/<id> (an eight-character id, or a UUID such as 6285c1d9-c4d4-4b42-a20c-05f487552cc9): a guest token (account
    created on the fly) lists the folder; the file is fetched with that token sent as a cookie. The guest token is kept on disk
    for a day and shared between processes (every plugin run is a new process, and Gofile rate-limits new accounts)."""
    name = 'gofile'
    _token = ''
    domains = ('gofile.io',)
    priority = 'first'
    _TOKEN_TTL = 20 * 3600

    @staticmethod
    def _token_path():
        import os
        from starfleetresolve import resultcache
        return os.path.join(os.path.dirname(resultcache._path()), 'gofile_token.json')

    @classmethod
    def _stored_token(cls):
        import json
        import time as _t
        try:
            with open(cls._token_path(), 'r', encoding='utf-8') as fh:
                d = json.load(fh)
            if d.get('token') and _t.time() - d.get('t', 0) < cls._TOKEN_TTL:
                return d['token']
        except Exception:
            pass
        return ''

    @classmethod
    def _store_token(cls, token):
        import json
        import time as _t
        try:
            with open(cls._token_path(), 'w', encoding='utf-8') as fh:
                json.dump({'token': token, 't': _t.time()}, fh)
        except Exception:
            pass

    @classmethod
    def _guest_token(cls, fresh=False):
        if not fresh:
            token = cls._token or cls._stored_token()
            if token:
                cls._token = token
                return token
        r = common.post('https://api.gofile.io/accounts', json={})
        try:
            token = cls._token = r.json()['data']['token']
        except Exception:
            return ''
        cls._store_token(token)
        return token

    def resolve(self, url, referer=''):
        m = re.search(r'gofile\.io/d/([A-Za-z0-9-]+)', url)
        if not m:
            return None
        import hashlib
        import time as _t
        for attempt in (0, 1):
            token = self._guest_token(fresh=bool(attempt))
            if not token:
                return None
            wt = hashlib.sha256(('%s::en-US::%s::%d::5d4f7g8sd45fsd' % (common.UA, token, int(_t.time()) // 14400)).encode()).hexdigest()
            h = {'Authorization': 'Bearer ' + token, 'X-Website-Token': wt, 'X-BL': 'en-US'}
            r = common.get('https://api.gofile.io/contents/%s?contentFilter=&page=1&pageSize=1000&sortField=name&sortDirection=1' % m.group(1),
                           headers=h)
            try:
                data = r.json()
            except Exception:
                data = {}
            if data.get('status') == 'ok':
                break
            if attempt == 0 and 'token' in str(data.get('status', '')).lower():       # the stored guest token was refused: make a new one
                Gofile._token = ''
                continue
            return None
        kids = (data.get('data', {}).get('children') or {}).values()
        files = [k for k in kids if k.get('type') == 'file' and k.get('link')]
        vids = [k for k in files if str(k.get('mimetype', '')).startswith(('video', 'audio'))] or files
        if not vids:
            return None
        vids.sort(key=lambda k: -int(k.get('size') or 0))
        return common.with_headers(vids[0]['link'], referer='https://gofile.io/', extra={'Cookie': 'accountToken=' + token})


class MediaFire(Resolver):
    """mediafire.com/file/<id>/<name>: the page holds the download button (plain or base64 'data-scrambled-url')."""
    name = 'mediafire'
    domains = ('mediafire.com',)
    priority = 'first'

    def resolve(self, url, referer=''):
        link = url.split('|')[0]
        for _ in range(2):
            r = common.get(link)
            if r is None or r.status_code != 200:
                return None
            ct = r.headers.get('content-type', '')
            if 'text/html' not in ct:           # already the file
                return link
            html = r.text
            m = re.search(r'data-scrambled-url="([^"]+)"', html)
            if m:
                u = common.b64decode_text(m.group(1))
                if u.startswith('http'):
                    return u
            m = re.search(r'''id=["']downloadButton["'][^>]*href=["']([^"']+)["']''', html) or \
                re.search(r'''href=["'](https?://download[0-9]*\.mediafire\.com/[^"']+)["']''', html) or \
                re.search(r'''aria-label=["']Download file["'][^>]*href=["']([^"']+)["']''', html) or \
                re.search(r'''href=["']([^"']+)["'][^>]*aria-label=["']Download file["']''', html)
            if m and m.group(1).startswith('http'):
                return m.group(1).replace('&amp;', '&')
            m = re.search(r'''(https?://download[0-9]*\.mediafire\.com/[^"'\s<>]+)''', html)
            if m:
                return m.group(1).replace('&amp;', '&')
            break
        return None


class Dropbox(Resolver):
    """Shared dropbox links play with dl=1 (or raw=1) on the same address."""
    name = 'dropbox'
    domains = ('dropbox.com', 'dl.dropboxusercontent.com')
    priority = 'first'

    def resolve(self, url, referer=''):
        base = url.split('|')[0]
        if 'dropboxusercontent.com' in base:
            return base
        base = re.sub(r'[?&](dl|raw)=\d', '', base)
        return base + ('&' if '?' in base else '?') + 'raw=1'


class GoogleDrive(Resolver):
    """drive.google.com/file/d/<id>/view and uc?id=<id>: docs.google.com/uc?export=download, following the
    large-file confirmation form when Google shows one."""
    name = 'googledrive'
    domains = ('drive.google.com', 'docs.google.com', 'drive.usercontent.google.com')
    priority = 'last'

    def resolve(self, url, referer=''):
        base = url.split('|')[0]
        m = re.search(r'/d/([A-Za-z0-9_-]{15,})', base) or re.search(r'[?&]id=([A-Za-z0-9_-]{15,})', base)
        if not m:
            return None
        fid = m.group(1)
        dl = 'https://drive.usercontent.google.com/download?id=%s&export=download&confirm=t' % fid
        s = common.session()
        if s is None:
            return None
        try:
            r = s.get(dl, headers={'User-Agent': common.UA}, stream=True, timeout=12)
            ct = r.headers.get('content-type', '')
            if r.status_code == 200 and 'text/html' not in ct:
                r.close()
                return dl
            html = r.text if 'text/html' in ct else ''
            r.close()
        except Exception:
            return None
        fields = dict(re.findall(r'<input[^>]+name="([^"]+)"[^>]+value="([^"]*)"', html))
        if fields.get('uuid') or fields.get('confirm'):
            q = '&'.join('%s=%s' % (k, v) for k, v in fields.items())
            return 'https://drive.usercontent.google.com/download?' + q
        return None


class Sendspace(Resolver):
    name = 'sendspace'
    domains = ('sendspace.com',)
    priority = 'first'

    def resolve(self, url, referer=''):
        r = common.get(url.split('|')[0])
        if r is None or r.status_code != 200:
            return None
        m = re.search(r'''id=["']download_button["'][^>]*href=["']([^"']+)["']''', r.text) or \
            re.search(r'''href=["'](https?://[^"']*sendspace\.com/dl/[^"']+)["']''', r.text)
        return m.group(1).replace('&amp;', '&') if m else None


class Solidfiles(Resolver):
    name = 'solidfiles'
    domains = ('solidfiles.com',)
    priority = 'first'

    def resolve(self, url, referer=''):
        r = common.get(url.split('|')[0])
        if r is None or r.status_code != 200:
            return None
        m = re.search(r'"downloadUrl"\s*:\s*"([^"]+)"', r.text) or re.search(r'"streamUrl"\s*:\s*"([^"]+)"', r.text)
        return common.clean_js_url(m.group(1)) if m else None


class UploadEe(Resolver):
    name = 'uploadee'
    domains = ('upload.ee',)
    priority = 'first'

    def resolve(self, url, referer=''):
        r = common.get(url.split('|')[0])
        if r is None or r.status_code != 200:
            return None
        m = re.search(r'''<a[^>]+id=["']d_l["'][^>]+href=["']([^"']+)["']''', r.text) or \
            re.search(r'''href=["'](https?://[^"']*upload\.ee/download/[^"']+)["']''', r.text)
        return m.group(1).replace('&amp;', '&') if m else None


class FilesFm(Resolver):
    """files.fm/u/<id>: the page lists the stored files as parallel arrays (host, hash, name); a file is served from
    https://<host>/down.php?i=<hash>&n=<name>. Video files are preferred."""
    name = 'filesfm'
    domains = ('files.fm',)
    priority = 'first'

    def resolve(self, url, referer=''):
        r = common.get(url.split('|')[0])
        if r is None or r.status_code != 200:
            return None
        def arr(name):
            m = re.search(name + r'\s*=\s*(\[[^\]]*\])\s*;', r.text)
            try:
                return json.loads(m.group(1)) if m else []
            except Exception:
                return []
        hosts, hashes, names = arr('arrFileHost'), arr('arrHashes'), arr('arrDisplayNames')
        if not hashes:
            return common.find_media_url(r.text) or None
        pick = 0
        for k, n in enumerate(names):
            if str(n).lower().endswith(('.mp4', '.mkv', '.webm', '.mov', '.avi', '.m4v', '.mp3', '.flac', '.m4a')):
                pick = k
                break
        host = hosts[pick] if pick < len(hosts) else 'api.files.fm'
        return common.with_headers('https://%s/down.php?i=%s&n=%s' % (host, hashes[pick], quote(names[pick] if pick < len(names) else 'file', safe='')),
                                   referer='https://files.fm/')


class XFileSharing(Resolver):
    """XFileSharing-engine hosts (video players and file lockers): the embed page carries the file in packed
    JavaScript ('sources:[{file:...}]'); locker pages have a download2 form that is posted once."""
    name = 'xfilesharing'
    domains = ('vidoza.net', 'vidoza.org', 'uppit.com', 'up-load.io', 'uploadboy.com', 'uploadrar.com',
               'tusfiles.com', 'ddownload.com', 'ddl.to', 'dropapk.to', 'filerio.in', 'bdupload.info', 'bdupload.asia',
               'clicknupload.click', 'clicknupload.org', 'clicknupload.to', 'suprafiles.net', 'userscloud.com', 'userload.co',
               'mixloads.com', 'upstream.to', 'jetload.net', 'femax20.com', 'feurl.com')
    priority = 'last'

    def resolve(self, url, referer=''):
        link = url.split('|')[0]
        r = common.get(link, referer=referer)
        if r is None or r.status_code != 200:
            return None
        if common.is_parked(r.text):
            return None
        o = common.origin_of(r.url)
        pages = [r.text]
        unp = common.unpack_js(r.text)
        if unp:
            pages.append(unp)
        for p in pages:
            m = re.search(r'''sources(?:Code)?\s*:\s*\[\s*\{[^}]*?(?:src|file)\s*:\s*["']([^"']+)["']''', p) or \
                re.search(r'''sources(?:Code)?\s*:\s*\[\s*["']([^"']+)["']''', p)
            u = m.group(1) if m else common.find_media_url(p)
            if u:
                u = _abs(r.url, u)
                if u.startswith('http'):
                    return common.with_headers(u, referer=o + '/')
        # locker page: post the download2 form once
        form = re.search(r'<form[^>]*name=["\']?F1["\']?[^>]*>(.*?)</form>', r.text, re.S | re.I) or \
            re.search(r'<form[^>]*method=["\']?post["\']?[^>]*>((?:(?!</form>).)*name=["\']op["\'](?:(?!</form>).)*)</form>', r.text, re.S | re.I)
        if form:
            data = dict(re.findall(r'<input[^>]+name=["\']([^"\']+)["\'][^>]*value=["\']([^"\']*)["\']', form.group(1)))
            data.setdefault('op', 'download2')
            if data.get('op') == 'download1':
                data['method_free'] = 'Free Download'
            p = common.post(r.url, data=data, referer=r.url)
            if p is not None:
                m = re.search(r'''href=["'](https?://[^"']+\.(?:mp4|mkv|avi|zip|rar|m4v|webm)[^"']*)["']''', p.text, re.I) or \
                    re.search(r'''(https?://[^"'\s<>]+/d/[A-Za-z0-9]+/[^"'\s<>]+)''', p.text)
                if m:
                    return common.with_headers(m.group(1), referer=r.url)
                loc = p.headers.get('location')
                if loc:
                    return common.with_headers(loc, referer=r.url)
        return None


class Mp4upload(Resolver):
    name = 'mp4upload'
    domains = ('mp4upload.com',)
    priority = 'last'

    def resolve(self, url, referer=''):
        m = re.search(r'mp4upload\.com/(?:embed-)?([A-Za-z0-9]+)', url)
        if not m:
            return None
        e = 'https://www.mp4upload.com/embed-%s.html' % m.group(1)
        r = common.get(e, referer=referer or 'https://www.mp4upload.com/')
        if r is None or r.status_code != 200:
            return None
        html = r.text + '\n' + common.unpack_js(r.text)
        mm = re.search(r'''player\.src\(\s*\{[^}]*src\s*:\s*["']([^"']+)["']''', html) or \
            re.search(r'''src\s*:\s*["'](https?://[^"']+\.mp4[^"']*)["']''', html)
        u = mm.group(1) if mm else common.find_media_url(html)
        return common.with_headers(u, referer='https://www.mp4upload.com/') if u else None


class YourUpload(Resolver):
    name = 'yourupload'
    domains = ('yourupload.com', 'yucache.net')
    priority = 'last'

    def resolve(self, url, referer=''):
        m = re.search(r'yourupload\.com/(?:embed|watch)/([A-Za-z0-9]+)', url)
        if not m:
            return None
        e = 'https://www.yourupload.com/embed/' + m.group(1)
        r = common.get(e, referer=referer or 'https://www.yourupload.com/')
        if r is None or r.status_code != 200:
            return None
        mm = re.search(r'''file\s*:\s*['"]([^'"]+)['"]''', r.text) or re.search(r'''og:video["']\s+content=["']([^"']+)''', r.text)
        if not mm:
            return None
        u = _abs(e, mm.group(1))
        if 'novideo' in u:                       # the site's placeholder for a deleted file
            return None
        # the address answers with a redirect to the media server; keep the embed page as referer
        return common.with_headers(u, referer=e)


class Sendvid(Resolver):
    name = 'sendvid'
    domains = ('sendvid.com',)
    priority = 'last'

    def resolve(self, url, referer=''):
        r = common.get(url.split('|')[0], referer=referer)
        if r is None or r.status_code != 200:
            return None
        m = re.search(r'''<source[^>]+src=["']([^"']+)["']''', r.text) or re.search(r'''og:video(?::secure_url)?["']\s+content=["']([^"']+)''', r.text) or \
            re.search(r'''video_source\s*=\s*["']([^"']+)["']''', r.text)
        if m:
            return common.with_headers(_abs(r.url, m.group(1)), referer='https://sendvid.com/')
        return None
