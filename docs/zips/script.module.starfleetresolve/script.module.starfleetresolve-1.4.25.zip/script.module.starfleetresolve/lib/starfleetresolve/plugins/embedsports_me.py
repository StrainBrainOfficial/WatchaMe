# -*- coding: utf-8 -*-
"""embedsports.me: the page names a player host and carries one-time tokens; the player iframe it builds holds a
session request whose answer completes the (AES-128 protected) HLS master playlist address."""
import re
import json
from urllib.parse import urlencode, quote, urlparse

from starfleetresolve import common
from starfleetresolve.plugins.base import Resolver


class EmbedSportsMe(Resolver):
    name = 'embedsports.me'
    domains = ('embedsports.me',)

    def resolve(self, url, referer=''):
        link = url.split('#')[0].split('|')[0]
        s = common.session()
        if s is None:
            return None
        ref = referer or 'https://playoffsstream.com/'
        page = common.text(link, referer=ref)
        d = dict(re.findall(r'data-(pldm|pid|play|player|gc)="([^"]*)"', page))
        m = re.search(r'const siteConfig = (\{.*?\});', page, re.S)
        if not d or not m:
            return None
        cfg = json.loads(m.group(1))
        q = urlencode({'pid': d['pid'], 'v': d['play'], 'player': d['player'], 'csrf': cfg['csrf'],
                       'csrf_ip': cfg['csrf_ip'], 'expires': cfg['sec_expires'], 'sec_hash': cfg['sec_hash']})
        p = common.text('https://%s/sd0embed/%s?%s' % (d['pldm'], d['gc'], q), referer=link)
        try:
            base = common.b64decode_text(re.search(r',d=e\("([^"]+)"\)', p).group(1))
            codes = re.search(r'R=e\(String\.fromCharCode\(\.\.\.\[([\d,]+)\]\)\)', p).group(1)
            manifest = common.b64decode_text(''.join(chr(int(x)) for x in codes.split(',')))
            csrf = common.b64decode_text(re.search(r'"X-CSRF-Auth":e\("([^"]+)"\)', p).group(1))
            stream = re.search(r',E="([^"]+)"', p).group(1)
            ts = re.search(r',s=parseInt\((\d+),10\)', p).group(1)
            dev = re.search(r',_="([^"]+)"', p).group(1)
            scode = re.search(r'scode:"([^"]+)"', p).group(1)
            sess = re.search(r'session_id:"([^"]+)"', p).group(1)
            host = re.search(r'encodeURIComponent\("([^"]+)"\)', p[p.find('function u('):]).group(1)
        except (AttributeError, ValueError):
            return None
        u = '%s?scode=%s&stream=%s&expires=%s&u_id=%s&session_id=%s&host_id=%s' % (
            base, quote(scode, safe=''), quote(stream, safe=''), ts, quote(dev, safe=''), quote(sess, safe=''), quote(host, safe=''))
        origin = 'https://%s' % d['pldm']
        r = common.get(u, headers={'Accept': 'application/json', 'X-CSRF-Auth': csrf, 'Referer': origin + '/', 'Origin': origin})
        try:
            j = r.json()
        except Exception:
            return None
        if not j.get('device_id'):
            return None
        return common.with_headers(manifest.split('?')[0] + '?u_id=' + quote(j['device_id'], safe=''),
                                   referer=origin + '/', origin=origin)
