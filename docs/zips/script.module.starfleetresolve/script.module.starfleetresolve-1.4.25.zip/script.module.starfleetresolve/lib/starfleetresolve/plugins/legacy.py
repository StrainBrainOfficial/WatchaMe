# -*- coding: utf-8 -*-
"""Hosts ResolveURL also supports. These only run after ResolveURL failed (priority 'last'): a second chance."""
import re

from starfleetresolve import common
from starfleetresolve.plugins.base import Resolver


def _mp(url, referer):
    return common.with_headers(url, referer=referer)


class MixDrop(Resolver):
    name = 'mixdrop'
    domains = ('mixdrop.ag', 'mixdrop.co', 'mixdrop.to', 'mixdrop.sx', 'mixdrop.ch', 'mixdrop.bz', 'mxdrop.to', 'mixdrop.ps', 'mixdrop.is',
               'mixdrop.my', 'mixdrop.vc', 'mixdrop.cv', 'mxdrop.click', 'mixdrop.club', 'mixdrop.bz', 'mixdrop.top')
    priority = 'first'

    def resolve(self, url, referer=''):
        link = url.split('|')[0]
        html = common.text(link, referer=common.origin_of(link) + '/')
        if not html:
            return None
        m = re.search(r'MDCore\.(?:v|wurl|url)\s*=\s*["\']((?:https?:)?//[^"\']+)["\']', html, re.I)
        if m:
            u = m.group(1).replace('\\/', '/')
            return _mp(('https:' + u) if u.startswith('//') else u, common.origin_of(link) + '/')
        packed = common.unpack_js(html)
        m = re.search(r'wurl\s*=\s*"((?:https?:)?//[^"]+)"', packed)
        if m:
            u = m.group(1)
            return _mp(('https:' + u) if u.startswith('//') else u, common.origin_of(link) + '/')
        u = common.find_media_url(html)
        return _mp(u, common.origin_of(link) + '/') if u else None


class Dood(Resolver):
    """DoodStream and its clones (dood.*, d000d, myvidplay, playmogo, vide0 ...): the embed page names a /pass_md5/
    address whose answer is the CDN prefix; the stream is that prefix + ten random characters + ?token=<id>.
    The clones redirect to one real site, so the address is built on the host the page finally came from."""
    name = 'doodstream family'
    domains = ('doodstream.com', 'dood.wf', 'dood.watch', 'dood.yt', 'dood.re', 'dood.so', 'dood.to', 'dood.pm',
               'dood.la', 'dood.ws', 'dood.sh', 'dood.cx', 'd0000d.com', 'd000d.com', 'doply.net', 'd0o0d.com',
               'myvidplay.com', 'playmogo.com', 'vide0.net', 'dsvplay.com', 'ds2play.com', 'd-s.io')
    priority = 'first'

    def resolve(self, url, referer=''):
        import random
        import string
        import time as _t
        link = url.split('|')[0].replace('/d/', '/e/')
        r = common.get(link, referer=referer or common.origin_of(link) + '/')
        if r is None or r.status_code != 200:
            return None
        o = common.origin_of(r.url)
        html = r.text
        m = re.search(r"/pass_md5/([^'\"]+)", html)
        if not m:
            return None
        base = common.text(o + '/pass_md5/' + m.group(1), referer=r.url).strip()
        if not base.startswith('http'):
            return None
        tok = m.group(1).split('/')[-1]
        rnd = ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(10))
        return common.with_headers('%s%s?token=%s&expiry=%d' % (base, rnd, tok, int(_t.time() * 1000)), referer=o + '/')
