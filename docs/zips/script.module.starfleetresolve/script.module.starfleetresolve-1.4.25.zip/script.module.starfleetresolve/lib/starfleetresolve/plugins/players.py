# -*- coding: utf-8 -*-
"""Small player families: streame.center, the shared 'gooz' player, rockylive/rockystream, vidload, gbsagbo,
and sites that serve their own video."""
import re
import json
from urllib.parse import urlparse, urljoin

from starfleetresolve import common
from starfleetresolve.plugins.base import Resolver


class StreameCenter(Resolver):
    """streame.center/embed/chNN.php -> iframe hls.php?stream=ID -> const streamUrl = "...m3u8?st=..&e=..".
    The signed playlist only answers with the Referer of the page it was found on."""
    name = 'streame.center'
    domains = ('streame.center', 'streamecenter.live')

    def resolve(self, url, referer=''):
        cur, ref = url.split('|')[0], referer
        for _ in range(4):
            html = common.text(cur, referer=ref)
            if not html:
                return None
            m = re.search(r'streamUrl\s*=\s*"(https?://[^"]+)"', html)
            if m:
                stream = common.clean_js_url(m.group(1))
                o = common.origin_of(cur)
                return common.with_headers(stream, referer=o + '/', origin=o)
            im = re.search(r'<iframe[^>]+src=["\']([^"\']+)["\']', html, re.I)
            if not im:
                return None
            nxt = im.group(1)
            nxt = ('https:' + nxt) if nxt.startswith('//') else urljoin(cur, nxt)
            cur, ref = nxt, cur
        return None


class Gooz(Resolver):
    """gooz.aapmains.net/new-stream-embed/<id>: the page keeps its playlist address in an atob() / const source."""
    name = 'gooz player'
    domains = ('aapmains.net', 'hereisman.net')

    def resolve(self, url, referer=''):
        link = url.split('|')[0]
        html = common.text(link, referer=referer or common.origin_of(link) + '/')
        if not html:
            return None
        cands = []
        m = re.search(r'const\s+source\s*=\s*"(https?://[^"]+)"', html)
        if m:
            cands.append(m.group(1))
        for b in re.findall(r'atob\(["\']([A-Za-z0-9+/=]{16,})["\']\)', html):
            dec = common.b64decode_text(b)
            if dec.startswith('http'):
                cands.append(dec)
        for c in cands:
            piped = common.with_headers(common.clean_js_url(c), referer=link, origin=common.origin_of(link))
            if common.playlist_ok(piped):
                return piped
        return None


class Rocky(Resolver):
    """rockylive / rockystream 'source/fetch.php?hd=N': a page that holds one atob() address of the real player."""
    name = 'rockylive'
    domains = ('rockylive.st', 'rockystream.st', 'embedhd.st')

    def resolve(self, url, referer=''):
        from starfleetresolve import resolve as _resolve
        link = url.split('|')[0]
        html = common.text(link, referer=referer or 'https://rockylive.st/')
        for b in re.findall(r'atob\(["\']([A-Za-z0-9+/=]{16,})["\']\)', html or ''):
            dec = common.b64decode_text(b)
            if dec.startswith('http') and not common.host_matches(dec, self.domains):
                out = _resolve(dec, referer=link, _depth=1)
                if out:
                    return out
        return None


class Vidload(Resolver):
    """vidload.online/e/ID: a wrapper page that lists the real hosts in ALL_LINKS."""
    name = 'vidload'
    domains = ('vidload.online',)

    def resolve(self, url, referer=''):
        from starfleetresolve import resolve as _resolve
        link = url.split('|')[0]
        html = common.text(link, referer=referer or 'https://5moviesporn.com/')
        m = re.search(r'ALL_LINKS\s*=\s*(\[.*?\])\s*;', html or '', re.S)
        if not m:
            return None
        try:
            links = [x.get('url') for x in json.loads(m.group(1)) if x.get('url')]
        except ValueError:
            return None
        for l in links:
            out = _resolve(l, referer=link, _depth=1)
            if out:
                return out
        return None


class Gbsagbo(Resolver):
    """gbsagbo.com/e/<filecode>: the JW Player page POSTs to /api/stream and plays streaming_url."""
    name = 'gbsagbo'
    domains = ('gbsagbo.com', 'ubgaiwa.com', 'sgoabjgio.com', 'igbsa.site', 'sugbaioug.com')

    def resolve(self, url, referer=''):
        link = url.split('|')[0]
        code = urlparse(link).path.rstrip('/').split('/')[-1]
        origin = common.origin_of(link)
        r = common.post(origin + '/api/stream', json={'filecode': code, 'device': 'desktop', 'codecs': {}},
                        referer=link, headers={'Origin': origin, 'Content-Type': 'application/json', 'User-Agent': common.UA})
        try:
            u = (r.json() or {}).get('streaming_url')
        except Exception:
            u = None
        if not u:
            return None
        return common.with_headers(u, referer=origin + '/', origin=origin)


class Vidara(Resolver):
    """vidara.to / vidara.so /v/<filecode>: a wrapper page whose iframe is the JW Player embed (/e/<filecode>) of the same family as
    gbsagbo; the embed host changes, so it is read from the page."""
    name = 'vidara'
    domains = ('vidara.to', 'vidara.so')

    def resolve(self, url, referer=''):
        link = url.split('|')[0]
        r = common.get(link, referer=referer)
        if r is None or r.status_code != 200:
            return None
        m = re.search(r'<iframe[^>]+src=["\'](https?://[^"\']+/(?:e|embed)/[A-Za-z0-9_-]+)', r.text)
        if not m:
            return None
        return Gbsagbo().resolve(m.group(1), link)


class StreamWish(Resolver):
    """StreamWish / StreamHG players. Some of the hosts (streamwish.to, hgcloud.to, dhcplay.com, hlsflast.com) answer with a small loader
    page whose script only sends the browser to one of the real player hosts (the same /e/<id> path), so those are asked directly;
    the real page holds the playlists in a `links` table (hls4 / hls3 / hls2) inside a packed script."""
    name = 'streamwish'
    domains = ('streamwish.to', 'streamwish.com', 'streamwish.fun', 'streamwish.site', 'hgcloud.to', 'dhcplay.com', 'hlsflast.com',
               'medixiru.com', 'niramirus.com', 'iplayerhls.com', 'embedwish.com', 'hglink.to', 'hgbazooka.com', 'gradehgplus.com',
               'cybervynx.com', 'tryzendm.com', 'dumbalag.com', 'haxloppd.com', 'davioad.com', 'uasopt.com', 'hlswish.com', 'strwish.com',
               'wishembed.pro', 'swdyu.com')
    MIRRORS = ('medixiru.com', 'niramirus.com', 'iplayerhls.com', 'streamwish.fun', 'embedwish.com')

    @staticmethod
    def _player_page(host, code, referer):
        r = common.get('https://%s/e/%s' % (host, code), referer=referer)
        if r is None or r.status_code != 200 or len(r.text) < 3000:
            return None, None            # an error, or the loader page
        return r.text, host

    def resolve(self, url, referer=''):
        import json
        from urllib.parse import urljoin
        link = url.split('|')[0]
        code = urlparse(link).path.rstrip('/').split('/')[-1]
        if not re.match(r'^[A-Za-z0-9]{8,}$', code):
            return None
        first = urlparse(link).netloc.lower()
        html = host = None
        for h in [first] + [m for m in self.MIRRORS if m != first]:
            html, host = self._player_page(h, code, 'https://%s/' % first)
            if html:
                break
        if not html:
            return None
        text = common.unpack_js(html) or html
        origin = 'https://%s' % host
        cands = []
        m = re.search(r'links\s*=\s*(\{.*?\})\s*;', text, re.S)
        if m:
            try:
                tbl = json.loads(m.group(1))
                cands = [tbl[k] for k in ('hls4', 'hls2', 'hls3') if tbl.get(k)]
            except ValueError:
                cands = []
        if not cands:
            u = common.find_media_url(text)
            cands = [u] if u else []
        for u in cands:
            u = urljoin(origin + '/', u.replace('\\/', '/'))
            piped = common.with_headers(u, referer=origin + '/', origin=origin)
            if common.playlist_ok(piped):
                return piped
        return None


class FilecodePlayer(Resolver):
    """Any /e/<filecode> page built on the same JW Player template as gbsagbo (it POSTs to /api/stream): new clone
    domains show up every few weeks, so this recognises the page instead of the name. Only tried after the rest."""
    name = 'filecode player'
    domains = ()
    priority = 'last'

    def match(self, url):
        return bool(re.search(r'^https?://[^/]+/(?:e|embed|v)/[A-Za-z0-9_-]{8,}/?(?:\?.*)?$', url.split('|')[0]))

    def resolve(self, url, referer=''):
        link = url.split('|')[0]
        r = common.get(link, referer=referer)
        if r is None or r.status_code != 200 or '/api/stream' not in r.text or 'filecode' not in r.text:
            return None
        return Gbsagbo().resolve(link, referer)


class SiteOwn(Resolver):
    """Sites that serve the video themselves (the address needs the site as Referer, nothing to decode)."""
    name = 'site-hosted video'
    domains = ('tokyomotion.net', 'sextvx.com')

    def resolve(self, url, referer=''):
        link = url.split('|')[0]
        o = common.origin_of(link)
        return common.with_headers(link, referer=o + '/', origin=o)
