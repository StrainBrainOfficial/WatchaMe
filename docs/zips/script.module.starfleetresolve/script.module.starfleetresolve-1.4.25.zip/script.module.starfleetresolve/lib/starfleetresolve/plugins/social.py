# -*- coding: utf-8 -*-
"""Social video sites: YouTube, X (Twitter), Facebook, TikTok. One or two requests each, best quality first.

YouTube : the iOS player API hands out an HLS master (up to 2160p with audio, adaptive) when it has one; otherwise the
          Android client's muxed file (360p). The separate high-quality video / audio files are NOT used: without a PO token
          YouTube answers 403 to anything past the first ~3 MB of them, so they stop a few seconds in. The installed
          YouTube add-on is the last resort.
X       : the public tweet-result endpoint lists the video variants; the highest-bitrate MP4 (HLS if there is none).
Facebook: public video pages carry the HD / SD file addresses in their JSON.
TikTok  : the video page's embedded state lists every bitrate; the highest one, played with the page's cookies."""
import re
import json
import math

from starfleetresolve import common
from starfleetresolve.plugins.base import Resolver

_IOS = {'clientName': 'IOS', 'clientVersion': '20.10.4', 'deviceMake': 'Apple', 'deviceModel': 'iPhone16,2', 'osName': 'iPhone',
        'osVersion': '18.3.2.22D82', 'hl': 'en'}
_IOS_UA = 'com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)'
_VR = {'clientName': 'ANDROID_VR', 'clientVersion': '1.60.19', 'deviceMake': 'Oculus', 'deviceModel': 'Quest 3', 'osName': 'Android',
       'osVersion': '12L', 'androidSdkVersion': 32, 'hl': 'en'}
_ANDROID = {'clientName': 'ANDROID', 'clientVersion': '20.10.38', 'androidSdkVersion': 30, 'osName': 'Android', 'osVersion': '11', 'hl': 'en'}
_ANDROID_UA = 'com.google.android.youtube/20.10.38 (Linux; U; Android 11) gzip'
_VR_UA = 'com.google.android.apps.youtube.vr.oculus/1.60.19 (Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip'


def _json_str(s):
    try:
        return json.loads('"' + s + '"')
    except Exception:
        return s.replace('\\u0025', '%').replace('\\u0026', '&').replace('\\/', '/')


class YouTube(Resolver):
    name = 'youtube'
    domains = ('youtube.com', 'youtu.be', 'youtube-nocookie.com', 'music.youtube.com')
    priority = 'first'
    _ID = re.compile(r'(?:youtu\.be/|[?&]v=|/embed/|/shorts/|/live/|/v/)([A-Za-z0-9_-]{11})')

    def _player(self, vid, client, ua, client_id):
        body = {'context': {'client': client}, 'videoId': vid, 'contentCheckOk': True, 'racyCheckOk': True}
        r = common.post('https://www.youtube.com/youtubei/v1/player?prettyPrint=false', json=body,
                        headers={'User-Agent': ua, 'X-YouTube-Client-Name': client_id, 'X-YouTube-Client-Version': client['clientVersion']})
        try:
            return r.json()
        except Exception:
            return {}

    def resolve(self, url, referer=''):
        m = self._ID.search(url)
        if not m:
            return None
        vid = m.group(1)
        js = self._player(vid, _IOS, _IOS_UA, '5')
        sd = js.get('streamingData') or {}
        if sd.get('hlsManifestUrl'):                       # adaptive master: best quality, audio included, live too
            return common.with_headers(sd['hlsManifestUrl'], extra={'User-Agent': _IOS_UA})
        for client, ua, cid in ((_VR, _VR_UA, '28'), (_ANDROID, _ANDROID_UA, '3')):    # older videos: best muxed file
            js = self._player(vid, client, ua, cid)
            sd = js.get('streamingData') or {}
            if sd.get('hlsManifestUrl'):
                return common.with_headers(sd['hlsManifestUrl'], extra={'User-Agent': ua})
            best = sorted([f for f in sd.get('formats') or [] if f.get('url')], key=lambda f: int(f.get('height') or 0), reverse=True)
            if best:
                return common.with_headers(best[0]['url'], extra={'User-Agent': ua})
        try:                                               # age-gated / restricted: hand it to the YouTube add-on if present
            import xbmc
            if xbmc.getCondVisibility('System.HasAddon(plugin.video.youtube)'):
                return 'plugin://plugin.video.youtube/play/?video_id=' + vid
        except Exception:
            pass
        return None


class X(Resolver):
    name = 'x'
    domains = ('x.com', 'twitter.com', 'mobile.twitter.com', 'fixupx.com', 'vxtwitter.com', 'fxtwitter.com')
    priority = 'first'

    @staticmethod
    def _token(tid):
        n = (int(tid) / 1e15) * math.pi
        digits = '0123456789abcdefghijklmnopqrstuvwxyz'
        ip, fp = int(n), n - int(n)
        s = ''
        while ip:
            ip, r = divmod(ip, 36)
            s = digits[r] + s
        s = s or '0'
        frac = ''
        for _ in range(14):                                # JavaScript prints up to ~11 base-36 fraction digits
            fp *= 36
            d = int(fp)
            frac += digits[d]
            fp -= d
            if not fp:
                break
        return re.sub(r'(0+|\.)', '', s + '.' + frac)

    def resolve(self, url, referer=''):
        m = re.search(r'/status(?:es)?/(\d{5,25})', url)
        if not m:
            return None
        tid = m.group(1)
        r = common.get('https://cdn.syndication.twimg.com/tweet-result?id=%s&lang=en&token=%s' % (tid, self._token(tid)),
                       referer='https://platform.twitter.com/')
        if r is None or r.status_code != 200:
            return None
        try:
            js = r.json()
        except Exception:
            return None
        variants = []
        for md in js.get('mediaDetails') or []:
            variants += (md.get('video_info') or {}).get('variants') or []
        mp4 = sorted([v for v in variants if v.get('content_type') == 'video/mp4' and v.get('url')], key=lambda v: int(v.get('bitrate') or 0), reverse=True)
        if mp4:
            return common.with_headers(mp4[0]['url'], referer='https://x.com/')
        hls = [v for v in variants if 'mpegURL' in (v.get('content_type') or '') and v.get('url')]
        return common.with_headers(hls[0]['url'], referer='https://x.com/') if hls else None


class Facebook(Resolver):
    name = 'facebook'
    domains = ('facebook.com', 'fb.watch', 'm.facebook.com', 'fb.com')
    priority = 'first'
    _KEYS = ('hd_src_no_ratelimit', 'hd_src', 'browser_native_hd_url', 'playable_url_quality_hd', 'sd_src_no_ratelimit', 'sd_src',
             'browser_native_sd_url', 'playable_url')

    def resolve(self, url, referer=''):
        link = url.split('|')[0]
        hdr = {'User-Agent': common.UA, 'Accept-Language': 'en-US,en;q=0.9'}
        vid = None
        for pat in (r'/videos/(?:[^/]+/)?(\d{8,20})', r'[?&]v=(\d{8,20})', r'/reel/(\d{8,20})', r'/watch/?\?.*?(\d{12,20})', r'video_id=(\d{8,20})'):
            m = re.search(pat, link)
            if m:
                vid = m.group(1)
                break
        if not vid:                                         # fb.watch short links: follow the redirect once
            r = common.get(link, headers=hdr)
            if r is not None:
                m = re.search(r'/(?:videos|reel)/(?:[^/]+/)?(\d{8,20})|[?&]v=(\d{8,20})', r.url)
                vid = (m.group(1) or m.group(2)) if m else None
        if not vid:
            return None
        # the embed player page lists the files without needing a login
        r = common.get('https://www.facebook.com/video/embed?video_id=' + vid, headers=hdr)
        if r is None or r.status_code != 200:
            return None
        t = r.text
        for key in self._KEYS:
            m = re.search(r'"%s"\s*:\s*"([^"]+)"' % key, t) or re.search(r'%s\s*:\s*"([^"]+)"' % key, t)
            if m:
                u = _json_str(m.group(1)).replace('&amp;', '&')
                if u.startswith('http'):
                    return common.with_headers(u, referer='https://www.facebook.com/')
        return None


class TikTok(Resolver):
    name = 'tiktok'
    domains = ('tiktok.com', 'vm.tiktok.com', 'vt.tiktok.com')
    priority = 'first'

    def resolve(self, url, referer=''):
        link = url.split('|')[0]
        ua = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36')
        r = common.get(link, headers={'User-Agent': ua, 'Accept-Language': 'en-US,en;q=0.9'})
        if r is None or r.status_code != 200:
            return None
        m = re.search(r'<script id="__UNIVERSAL_DATA_FOR_REHYDRATION__"[^>]*>(.*?)</script>', r.text, re.S)
        if not m:
            return None
        try:
            scope = json.loads(m.group(1)).get('__DEFAULT_SCOPE__', {})
            item = scope.get('webapp.video-detail', {}).get('itemInfo', {}).get('itemStruct', {})
            video = item.get('video') or {}
        except Exception:
            return None
        cands = []
        for b in video.get('bitrateInfo') or []:
            for u in (b.get('PlayAddr') or {}).get('UrlList') or []:
                cands.append((int(b.get('Bitrate') or 0), u))
        for key in ('playAddr', 'downloadAddr'):
            if video.get(key):
                cands.append((0, video[key]))
        cands.sort(key=lambda x: -x[0])
        if not cands:
            return None
        cookie = '; '.join('%s=%s' % (c.name, c.value) for c in r.cookies)
        extra = {'Cookie': cookie} if cookie else None
        return common.with_headers(cands[0][1], referer='https://www.tiktok.com/', extra=extra)
