# -*- coding: utf-8 -*-
"""Adult tube players whose embeds changed and no longer resolve elsewhere: Eporner, Pornhub, XHamster."""
import re
import json
import time

from starfleetresolve import common
from starfleetresolve.plugins.base import Resolver


def _b36(n):
    s = ''
    chars = '0123456789abcdefghijklmnopqrstuvwxyz'
    while n:
        n, r = divmod(n, 36)
        s = chars[r] + s
    return s or '0'


class Eporner(Resolver):
    """embed page -> EP.video.player.hash (32 hex) -> /xhr/video/<id>?hash=<4 x base36> -> mp4 sources."""
    name = 'eporner'
    domains = ('eporner.com',)
    priority = 'first'

    def resolve(self, url, referer=''):
        m = re.search(r'eporner\.com/(?:embed|video-|hd-porn)/?([A-Za-z0-9]{6,})', url)
        if not m:
            return None
        vid = m.group(1)
        r = common.get('https://www.eporner.com/embed/%s/' % vid, referer=referer or 'https://www.eporner.com/')
        if r is None or r.status_code != 200:
            return None
        h = re.search(r"EP\.video\.player\.hash\s*=\s*'([0-9a-f]{32})'", r.text)
        if not h:
            return None
        hx = h.group(1)
        key = ''.join(_b36(int(hx[i:i + 8], 16)) for i in range(0, 32, 8))
        api = ('https://www.eporner.com/xhr/video/%s?hash=%s&domain=www.eporner.com&fallback=false&embed=true'
               '&supportedFormats=dash,mp4&_=%d' % (vid, key, int(time.time() * 1000)))
        a = common.get(api, referer=r.url, headers={'X-Requested-With': 'XMLHttpRequest'})
        try:
            js = a.json()
        except Exception:
            return None
        best, best_h = None, 0
        for label, info in ((js.get('sources') or {}).get('mp4') or {}).items():
            src = info.get('src') if isinstance(info, dict) else None
            hh = re.match(r'(\d+)p', label)
            hh = int(hh.group(1)) if hh else 0
            if src and hh >= best_h:
                best, best_h = src, hh
        if not best:
            return None
        return common.with_headers(best, referer='https://www.eporner.com/')


class Pornhub(Resolver):
    """embed page carries the player settings (mediaDefinitions) with ready HLS playlists per quality."""
    name = 'pornhub'
    domains = ('pornhub.com', 'pornhub.org')
    priority = 'first'

    def resolve(self, url, referer=''):
        link = url.split('|')[0]
        if '/embed/' not in link:
            m = re.search(r'viewkey=([a-z0-9]+)', link)
            if not m:
                return None
            link = 'https://www.pornhub.com/embed/' + m.group(1)
        r = common.get(link, referer=referer or 'https://www.pornhub.com/')
        if r is None or r.status_code != 200:
            return None
        i = r.text.find('"mediaDefinitions"')
        if i < 0:
            return None
        j = r.text.find('[', i)
        depth, k = 0, j
        while k < len(r.text):
            c = r.text[k]
            depth += (c == '[') - (c == ']')
            k += 1
            if depth == 0:
                break
        try:
            defs = json.loads(r.text[j:k])
        except Exception:
            return None
        hls = [d for d in defs if d.get('format') == 'hls' and d.get('videoUrl')]
        hls.sort(key=lambda d: -int(d.get('height') or 0))
        for d in hls:
            return common.with_headers(d['videoUrl'].replace('\\/', '/'), referer='https://www.pornhub.com/')
        return None


class XHamster(Resolver):
    """video / embed page -> window.initials -> xplayerSettings.sources (hls / h264 lists)."""
    name = 'xhamster'
    domains = ('xhamster.com', 'xhamster.desi', 'xhamster2.com', 'xhamster3.com', 'xhms.pro')
    priority = 'first'

    def resolve(self, url, referer=''):
        link = url.split('|')[0]
        r = common.get(link, referer=referer or 'https://xhamster.com/')
        if r is None or r.status_code != 200:
            return None
        html = r.text
        if '/embed/' in link:
            m = re.search(r'"shareLink":"([^"]+)"', html)
            if m:
                r2 = common.get(m.group(1).replace('\\/', '/'), referer=link)
                if r2 is not None and r2.status_code == 200:
                    html = r2.text
        urls = re.findall(r'"(?:url|fallback)"\s*:\s*"(https?:[^"]+?\.(?:m3u8|mp4)[^"]*)"', html.replace('\\/', '/'))
        if not urls:
            urls = re.findall(r'(https?://[^"\'\s<>\\]+\.m3u8[^"\'\s<>\\]*)', html.replace('\\/', '/'))
        if not urls:
            return None
        urls.sort(key=lambda u: ('_TPL_' in u, '.m3u8' not in u, len(u)))
        pick = urls[0]
        if '_TPL_' in pick:
            # the address is a template: the player puts the wanted quality in place of _TPL_ (one playlist per quality; 1080p at most)
            quals = sorted({int(q) for q in re.findall(r':(\d{3,4})p', pick)}, reverse=True)
            best = next((q for q in quals if q <= 1080), quals[-1] if quals else 720)
            pick = pick.replace('_TPL_', '%dp' % best)
        if '.av1.' in pick:
            # the page lists the AV1 renditions; the same quality exists as H.264, which every box and phone can play
            h264 = pick.replace('.av1.', '.h264.')
            chk = common.get(h264, referer='https://xhamster.com/')
            if chk is not None and chk.status_code == 200 and '#EXTM3U' in (chk.text or '')[:20]:
                pick = h264
        return common.with_headers(pick, referer='https://xhamster.com/')
