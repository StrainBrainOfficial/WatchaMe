# -*- coding: utf-8 -*-
"""Wrapper links the event / channel hubs hand out: they only name the real player, so the address is rebuilt from them."""
import re
from urllib.parse import parse_qs, unquote, urlparse

from starfleetresolve import common
from starfleetresolve.plugins.base import Resolver


def _resolve_inner(url, referer):
    from starfleetresolve import resolve
    return resolve(url, referer=referer, debrid_links=False)


class HesgoalPlayer(Resolver):
    """hesgoal.team/ntvtvplayer.html?id=<channel>: a page that only frames wideiptv.top/player/<channel>."""
    name = 'hesgoal'
    domains = ('hesgoal.team',)
    priority = 'first'

    def resolve(self, url, referer=''):
        m = re.search(r'[?&]id=([A-Za-z0-9_-]+)', url.split('|')[0])
        return _resolve_inner('https://wideiptv.top/player/%s' % m.group(1), 'https://hesgoal.team/') if m else None


class FrameWrapper(Resolver):
    """hitsportshdd.xyz/fr.php?src=<player url>: a frame wrapper around another player address."""
    name = 'framewrapper'
    domains = ('hitsportshdd.xyz',)
    priority = 'first'

    def resolve(self, url, referer=''):
        src = (parse_qs(urlparse(url.split('|')[0]).query).get('src') or [''])[0]
        return _resolve_inner(src, referer or url) if src.startswith('http') else None


class HitcastView(Resolver):
    """hitcast.st/totview.php?src=<player url>: the viewer of the footy4u / totalsport-ek pages; the player is in src."""
    name = 'hitcast'
    domains = ('hitcast.st',)
    priority = 'first'

    def resolve(self, url, referer=''):
        m = re.search(r'[?&]src=(.+)$', url.split('|')[0])
        if not m:
            return None
        src = unquote(m.group(1)).replace('&amp;', '&')
        return _resolve_inner(src, referer or 'https://footy4u.st/') if src.startswith('http') else None


class FreestreamsChannel(Resolver):
    """A channel page of the Free Streams live-sports site: it frames the real player (wikisport, wideiptv, embedsports ...)."""
    name = 'freestreams'
    domains = ('freestreams-live1i.pk', 'freestreams-live.my')
    priority = 'first'
    _SKIP = re.compile(r'googletagmanager|doubleclick|facebook|twitter|youtube', re.I)

    def resolve(self, url, referer=''):
        link = url.split('|')[0]
        page = common.text(link, referer=referer or common.origin_of(link) + '/')
        if not page:
            return None
        for src in re.findall(r"""(?is)<iframe[^>]+src=["']([^"']+)""", page):
            if src.startswith('//'):
                src = 'https:' + src
            if not src.startswith('http') or self._SKIP.search(src):
                continue
            stream = _resolve_inner(src, link)
            if stream:
                return stream
        return None
