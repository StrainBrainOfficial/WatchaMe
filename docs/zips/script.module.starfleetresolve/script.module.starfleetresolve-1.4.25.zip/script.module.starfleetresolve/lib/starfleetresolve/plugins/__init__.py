# -*- coding: utf-8 -*-
from starfleetresolve.plugins.goat import Goat
from starfleetresolve.plugins.embedsports_me import EmbedSportsMe
from starfleetresolve.plugins.players import StreameCenter, Gooz, Rocky, Vidload, Gbsagbo, Vidara, StreamWish, FilecodePlayer, SiteOwn
from starfleetresolve.plugins.legacy import MixDrop, Dood
from starfleetresolve.plugins.streamtape import StreamTape
from starfleetresolve.plugins.voe import Voe
from starfleetresolve.plugins.livesites import ChFamily, XyzStreams, Brightcove
from starfleetresolve.plugins.dlhd import Dlhd
from starfleetresolve.plugins.adult_sites import Eporner, Pornhub, XHamster
from starfleetresolve.plugins.sportshosts import GSports, TimEmbed, CdnLive, StrmFree, PitSport
from starfleetresolve.plugins.hubhosts import HesgoalPlayer, FrameWrapper, HitcastView, FreestreamsChannel
from starfleetresolve.plugins.providers import VixSrc, Vidbolt, Vidrift, GlobalNews
from starfleetresolve.plugins.social import YouTube, X, Facebook, TikTok
from starfleetresolve.plugins.mainstream import Dailymotion, ArchiveOrg, Rutube, PeerTube, Vimeo, XNXX, YouJizz, RedTube, Streamable
from starfleetresolve.plugins.filehosts import (Pixeldrain, Gofile, MediaFire, Dropbox, GoogleDrive, Sendspace,
                                                UploadEe, FilesFm, XFileSharing, Mp4upload, YourUpload, Sendvid)

# order matters only between resolvers that match the same address
ALL = [Goat(), EmbedSportsMe(), StreameCenter(), Gooz(), Rocky(), Vidload(), Gbsagbo(), Vidara(), StreamWish(), FilecodePlayer(), SiteOwn(),
       Voe(), ChFamily(), XyzStreams(), Brightcove(), Dlhd(), MixDrop(), Dood(), StreamTape(),
       Pixeldrain(), Gofile(), MediaFire(), Dropbox(), Sendspace(), UploadEe(), FilesFm(),
       Eporner(), Pornhub(), XHamster(),
       GoogleDrive(), XFileSharing(), Mp4upload(), YourUpload(), Sendvid(), GSports(),
       Dailymotion(), ArchiveOrg(), Rutube(), PeerTube(), Vimeo(), XNXX(), YouJizz(), RedTube(), Streamable(),
       YouTube(), X(), Facebook(), TikTok(), VixSrc(), Vidbolt(), Vidrift(), GlobalNews(), TimEmbed(), CdnLive(), StrmFree(), PitSport(), HesgoalPlayer(), FrameWrapper(), HitcastView(), FreestreamsChannel()]
