# -*- coding: utf-8 -*-
"""Voe (voe.sx and its endless mirror domains).

voe.sx/e/<id> answers with a tiny page that sends the browser to whatever mirror domain is current. The mirror's
page carries the player settings as a scrambled JSON string (<script type="application/json">["..."]</script>),
and its loader script (/js/loader.<hash>.js) carries the list of marker strings that were mixed into it:
    ROT13 the letters -> delete every marker string -> base64 -> every character minus 3 -> reverse -> base64 -> JSON
The JSON names the playlist ('source') and the plain download address ('direct_access_url')."""
import re
import json
import base64
from urllib.parse import urljoin

from starfleetresolve import common
from starfleetresolve.plugins.base import Resolver

_BS = chr(92)
_SPECIAL = '.*+?^${}()|[]' + _BS
_LUT = re.compile(r"\[(?:'\W{2}'[,\]]){3,10}")


def _b64(s):
    return base64.b64decode(s + '=' * (-len(s) % 4)).decode('latin-1')


def decode_blob(ct, lut_literal):
    markers = []
    for part in lut_literal[2:-2].split("','"):
        markers.append(''.join([(_BS + c) if c in _SPECIAL else c for c in part]))
    txt = []
    for ch in ct:
        x = ord(ch)
        if 64 < x < 91:
            x = (x - 52) % 26 + 65
        elif 96 < x < 123:
            x = (x - 84) % 26 + 97
        txt.append(chr(x))
    txt = ''.join(txt)
    for m in markers:
        txt = re.sub(m, '', txt)
    step = ''.join(chr(ord(c) - 3) for c in _b64(txt))
    return json.loads(_b64(step[::-1]))


class Voe(Resolver):
    name = 'voe'
    domains = ('voe.sx',)
    priority = 'first'

    def match(self, url):
        # voe.sx and the rotating mirrors share the /e/<id> shape; only claim voe.sx itself plus the known name patterns
        host = common.urlparse(url).netloc.lower()
        return host == 'voe.sx' or host.endswith('.voe.sx') or re.search(r'voe-?un-?bl[o0]?ck|^voe\.|\.voe\.', host) is not None

    def resolve(self, url, referer=''):
        cur = url.split('|')[0]
        r = common.get(cur, referer=referer)
        for _ in range(3):
            if r is None or r.status_code != 200:
                return None
            m = re.search(r"window\.location\.href\s*=\s*'(https?://[^']+)'", r.text)
            if m and 'application/json' not in r.text:
                cur = m.group(1)
                r = common.get(cur, referer=url)
                continue
            break
        if r is None:
            return None
        html, page_url = r.text, r.url
        ct = re.search(r'application/json">\["([^"]+)"\]</script>', html)
        if not ct:
            return None
        lut = None
        for src in re.findall(r'<script[^>]+src="([^"]+)"', html):
            if 'loader' in src or 'base' in src or src.startswith('/js/'):
                js = common.text(urljoin(page_url, src), referer=page_url)
                m = _LUT.search(js or '')
                if m:
                    lut = m.group(0)
                    break
        if not lut:
            return None
        try:
            data = decode_blob(ct.group(1), lut)
        except Exception:
            return None
        o = common.origin_of(page_url)
        for key in ('direct_access_url', 'source', 'file'):
            u = data.get(key)
            if u and u.startswith('http'):
                return common.with_headers(u, referer=o + '/', origin=o)
        return None
