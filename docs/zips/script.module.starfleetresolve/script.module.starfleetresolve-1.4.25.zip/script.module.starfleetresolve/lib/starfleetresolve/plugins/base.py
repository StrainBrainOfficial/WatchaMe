# -*- coding: utf-8 -*-
from starfleetresolve import common


class Resolver(object):
    """One host family. `domains` are registrable host names (sub-domains match too).

    priority 'first': tried before ResolveURL (for hosts ResolveURL does not have, or ones we do better).
    priority 'last' : only tried after ResolveURL failed (a second chance for hosts ResolveURL supports).
    resolve() returns a playable address ('url' or 'url|Header=value&...') or None."""
    name = ''
    domains = ()
    priority = 'first'

    def match(self, url):
        return common.host_matches(url, self.domains)

    def resolve(self, url, referer=''):
        raise NotImplementedError
