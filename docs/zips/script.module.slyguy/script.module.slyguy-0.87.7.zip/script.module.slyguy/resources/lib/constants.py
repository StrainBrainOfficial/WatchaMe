from slyguy.constants import REPO_DOMAIN

## NEWS ##
NEWS_URL = REPO_DOMAIN+'/.repo/news.json.gz'
ADDONS_URL = REPO_DOMAIN+'/.repo/addons.json.gz'
ADDONS_MD5 = REPO_DOMAIN+'/.repo/addons.json.md5'
NEWS_CHECK_TIME = 60 * 60 * 12 #12 hours
UPDATES_CHECK_TIME = 1800 #30mins - fast updates

## CONNECTION ##
OFFLINE_RETRY_TIME = 900 #15mins - how often to retry the service work while Kodi reports no internet
