import xbmc
import xbmcgui
import xbmcaddon
import time
import requests
import json
from reminders import get_upcoming_reminders, remove_reminder

def fetch_games():
    try:
        addon = xbmcaddon.Addon()
        # Map settings keys to ESPN sport endpoints (matching tenbuttons.py and sportsgrid.py)
        sports_settings = {
            "mlb": addon.getSettingBool('sport_mlb'),
            "nba": addon.getSettingBool('sport_nba'),
            "wnba": addon.getSettingBool('sport_wnba'),
            "nhl": addon.getSettingBool('sport_nhl'),
            "nfl": addon.getSettingBool('sport_nfl'),
            "ncaab": addon.getSettingBool('sport_ncaab'),
            "college-football": addon.getSettingBool('sport_college_football'),
            "mls": addon.getSettingBool('sport_mls'),
            "premier-league": addon.getSettingBool('sport_premier_league'),
            "laliga": addon.getSettingBool('sport_laliga'),
            "bundesliga": addon.getSettingBool('sport_bundesliga'),
            "seriea": addon.getSettingBool('sport_seriea'),
            "ligue1": addon.getSettingBool('sport_ligue1'),
            "championsleague": addon.getSettingBool('sport_championsleague'),
            "fifa-club-world-cup": addon.getSettingBool('sport_fifa_club_world_cup'),
            "cfl": addon.getSettingBool('sport_cfl')
        }
        enabled_sports = [sport for sport, enabled in sports_settings.items() if enabled]
        if not enabled_sports:
            xbmc.log("No sports selected for notifications", level=xbmc.LOGINFO)
            return {}

        # Map settings keys to ESPN API endpoints
        sport_map = {
            'mlb': 'sports/baseball/mlb',
            'nba': 'sports/basketball/nba',
            'wnba': 'sports/basketball/wnba',
            'nhl': 'sports/hockey/nhl',
            'nfl': 'sports/football/nfl',
            'ncaab': 'sports/basketball/mens-college-basketball',
            'college-football': 'sports/football/college-football',
            'mls': 'sports/soccer/usa.1',
            'premier-league': 'sports/soccer/eng.1',
            'laliga': 'sports/soccer/esp.1',
            'bundesliga': 'sports/soccer/ger.1',
            'seriea': 'sports/soccer/ita.1',
            'ligue1': 'sports/soccer/fra.1',
            'championsleague': 'sports/soccer/uefa.champions',
            'fifa-club-world-cup': 'sports/soccer/fifa.club-world-cup',
            'cfl': 'sports/football/nfl'  # CFL uses NFL endpoint
        }

        games = {}
        for sport in enabled_sports:
            # Get ESPN endpoint for this sport
            espn_sport = sport_map.get(sport, f'sports/{sport}')
            url = f"https://site.api.espn.com/apis/site/v2/{espn_sport}/scoreboard"
            
            xbmc.log(f"Fetching scores for {sport.upper()} from {url}", level=xbmc.LOGINFO)
            try:
                response = requests.get(
                    url,
                    headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'},
                    timeout=10
                )
                response.raise_for_status()
                data = response.json()
                
                events = data.get('events', [])
                for event in events:
                    competition = event.get('competitions', [{}])[0]
                    competitors = competition.get('competitors', [])
                    
                    if len(competitors) < 2:
                        continue
                    
                    team1 = competitors[0].get('team', {})
                    team2 = competitors[1].get('team', {})
                    
                    team1_name = team1.get('displayName', '')
                    team2_name = team2.get('displayName', '')
                    
                    if not team1_name or not team2_name:
                        continue
                    
                    score1 = str(competitors[0].get('score', ''))
                    score2 = str(competitors[1].get('score', ''))
                    
                    # Get game status
                    status_obj = competition.get('status', {})
                    status_type = status_obj.get('type', {})
                    status_text = status_type.get('description', 'Scheduled')
                    
                    # Get period and clock for live games
                    period = status_obj.get('period', '')
                    clock = status_obj.get('displayClock', '')
                    
                    # Build detailed status
                    if period and clock and status_text in ['In Progress', 'Halftime']:
                        status_text = f"Q{period} {clock}"
                    elif period and status_text in ['In Progress', 'Halftime']:
                        status_text = f"Q{period}"
                    
                    # Format sport name for display
                    sport_display = sport.upper().replace('-', ' ')
                    
                    key = f"{sport_display}: {team1_name} vs {team2_name}"
                    games[key] = {
                        'score': f"{score1} - {score2}",
                        'status': status_text,
                        'sport': sport_display
                    }
            except requests.exceptions.HTTPError as e:
                xbmc.log(f"HTTP Error fetching {sport.upper()} scores: {str(e)}", level=xbmc.LOGERROR)
                continue
            except Exception as e:
                xbmc.log(f"Error fetching {sport.upper()} scores: {str(e)}", level=xbmc.LOGERROR)
                continue
        return games
    except Exception as e:
        xbmc.log(f"Error in fetch_games: {str(e)}", level=xbmc.LOGERROR)
        return {}

def main():
    xbmc.log("LiveScore Alerts service started", level=xbmc.LOGINFO)
    addon = xbmcaddon.Addon()
    addon_id = addon.getAddonInfo('id')
    xbmcgui.Dialog().notification('Live Score Alerts', 'Service running in background.', xbmcgui.NOTIFICATION_INFO, 5000)
    last_games = {}
    was_disabled = False
    poll_interval_sports = int(addon.getSetting('poll_interval_sports'))
    poll_interval_reminders = int(addon.getSetting('poll_interval_reminders'))
    import time
    monitor = xbmc.Monitor()
    last_sports = 0
    last_reminders = 0
    while not monitor.abortRequested():
        now = time.time()
        try:
            service_enabled = addon.getSettingBool('service_enabled')
        except Exception as e:
            xbmc.log(f"Error accessing service_enabled setting: {str(e)}", level=xbmc.LOGERROR)
            service_enabled = True

        if not service_enabled:
            if not was_disabled:
                xbmc.log("LiveScore Alerts service stopped by setting", level=xbmc.LOGINFO)
                xbmcgui.Dialog().notification('Live Score Alerts', 'Service stopped by user setting.', xbmcgui.NOTIFICATION_INFO, 5000)
                was_disabled = True
            if monitor.waitForAbort(poll_interval_sports):
                return
            continue

        if was_disabled and service_enabled:
            xbmc.log("LiveScore Alerts service re-enabled, sending catch-up notifications", level=xbmc.LOGINFO)
            xbmcgui.Dialog().notification('Live Score Alerts', 'Service re-enabled, fetching current scores.', xbmcgui.NOTIFICATION_INFO, 5000)
            games = fetch_games()
            if games:
                for title, g in games.items():
                    xbmcgui.Dialog().notification('Catch-Up Score', f'{title}: {g["score"]} ({g["status"]})', xbmcgui.NOTIFICATION_INFO, 10000)
            last_games = games
            was_disabled = False

        if not xbmc.getCondVisibility(f'System.AddonIsEnabled({addon_id})'):
            xbmc.log("LiveScore Alerts service stopped due to disable", level=xbmc.LOGINFO)
            xbmcgui.Dialog().notification('Live Score Alerts', 'Service stopped due to disable.', xbmcgui.NOTIFICATION_INFO, 5000)
            return

        # Fetch sports scores if interval elapsed
        if now - last_sports >= poll_interval_sports:
            games = fetch_games()
            for title, g in games.items():
                prev = last_games.get(title, {})
                # Skip notifications if status is "Scheduled"
                if g.get('status') == "Scheduled":
                    continue
                if 'score' in prev and prev['score'] != g['score']:
                    xbmcgui.Dialog().notification('Score Update', f'{title}: {g["score"]} | {g["status"]}', xbmcgui.NOTIFICATION_INFO, 10000)
                if 'status' in prev and prev['status'] != g['status']:
                    xbmcgui.Dialog().notification('Status Update', f'{title}: {g["status"]} | {g["score"]}', xbmcgui.NOTIFICATION_INFO, 10000)
                if g['status'].lower().startswith('final') and (not prev or prev['status'] != g['status']):
                    xbmcgui.Dialog().notification('Final Score', f'{title}: {g["score"]}', xbmcgui.NOTIFICATION_INFO, 15000)
            last_games.update(games)
            last_sports = now

        # Check reminders if interval elapsed
        if now - last_reminders >= poll_interval_reminders:
            try:
                reminders = get_upcoming_reminders(within_seconds=poll_interval_reminders)
                xbmc.log(f"ReminderService: Checking for reminders, found {len(reminders)} upcoming", xbmc.LOGINFO)
                for r in reminders:
                    xbmc.log(f"ReminderService: Upcoming reminder: {r['program']} on {r['channel']} at {r['start_time']}", xbmc.LOGINFO)
                    xbmcgui.Dialog().notification(
                        'Program Reminder',
                        f"{r['program']} on {r['channel']} is starting soon!",
                        xbmcgui.NOTIFICATION_INFO,
                        5000
                    )
                    remove_reminder(r['channel'], r['program'], r['start_time'])
            except Exception as e:
                xbmc.log(f"Reminder service error: {str(e)}", level=xbmc.LOGERROR)
            last_reminders = now

        # Sleep for 1 second, check for abort
        if monitor.waitForAbort(1):
            return

if __name__ == "__main__":
    main()
