import codecs

import arrow
from slyguy import plugin, gui, signals, monitor, userdata, inputstream, log
from slyguy.constants import ROUTE_LIVE_TAG
from slyguy.util import pthms_to_seconds

from .api import API
from .constants import DAI_USER_AGENT, IMAGE_URL
from .language import _
from .settings import settings


api = API()

_SKIP_SECTION_TYPES = ('LIVE_SHELF', 'CONTINUE_WATCHING', 'FAVOURITE', 'PROMO_BLOCK')
_INLINE_SECTION_TYPES = ('PERSONALISED_COLLECTION',)


@signals.on(signals.BEFORE_DISPATCH)
def before_dispatch():
    api.new_session()
    plugin.logged_in = api.logged_in


@plugin.route('')
def home(**kwargs):
    folder = plugin.Folder(cacheToDisc=False)

    if not api.logged_in:
        folder.add_item(label=_(_.LOGIN, _bold=True), path=plugin.url_for(login), bookmark=False)
    else:
        folder.add_item(label=_(_.LIVE_TV, _bold=True), path=plugin.url_for(live_tv))
        folder.add_item(label=_(_.HOME, _bold=True), path=plugin.url_for(page, slug='home'))
        folder.add_item(label=_(_.TV_SHOWS, _bold=True), path=plugin.url_for(page, slug='tv-shows'))
        folder.add_item(label=_(_.MOVIES, _bold=True), path=plugin.url_for(page, slug='movies'))
        folder.add_item(label=_(_.NEWS, _bold=True), path=plugin.url_for(page, slug='news'))
        folder.add_item(label=_(_.SPORT, _bold=True), path=plugin.url_for(page, slug='sport'))
        folder.add_item(label=_(_.SEARCH, _bold=True), path=plugin.url_for(search))
        folder.add_item(label=_(_.WATCHLIST, _bold=True), path=plugin.url_for(watchlist))
        if settings.getBool('bookmarks', True):
            folder.add_item(label=_(_.BOOKMARKS, _bold=True), path=plugin.url_for(plugin.ROUTE_BOOKMARKS), bookmark=False)
        folder.add_item(label=_.LOGOUT, path=plugin.url_for(logout), _kiosk=False, bookmark=False)

    folder.add_item(label=_.SETTINGS, path=plugin.url_for(plugin.ROUTE_SETTINGS), _kiosk=False, bookmark=False)
    return folder


@plugin.route()
def login(**kwargs):
    options = [
        [_.DEVICE_CODE, _device_code],
        [_.EMAIL_PASSWORD, _email_password],
    ]

    index = gui.context_menu([x[0] for x in options])
    if index == -1 or not options[index][1]():
        return

    gui.refresh()


def _device_code():
    data = api.device_code()
    verify_url = 'https://' + data['verifyURI']
    with gui.progress_qr(data['qrCodeURI'], _(_.DEVICE_LINK_STEPS, code=data['userCode'], url=verify_url), heading=_.DEVICE_CODE) as progress:
        for i in range(data['expiresIn']):
            if progress.iscanceled() or monitor.waitForAbort(1):
                return

            progress.update(int((i / float(data['expiresIn'])) * 100))
            if i % data['interval'] == 0 and api.device_login(data['deviceCode']):
                return True


def _email_password():
    username = gui.input(_.ASK_EMAIL, default=userdata.get('username', '')).strip()
    if not username:
        return

    userdata.set('username', username)

    password = gui.input(_.ASK_PASSWORD, hide_input=True).strip()
    if not password:
        return

    api.login(username, password)
    return True


@plugin.route()
@plugin.login_required()
def page(slug, **kwargs):
    data = api.page(slug)
    folder = plugin.Folder(data.get('title', ''))

    for section in data.get('sections', []):
        entity_type = section.get('entityType')
        if entity_type in _SKIP_SECTION_TYPES:
            continue
        items = section.get('items', [])
        if not items:
            continue
        label = section['title'].strip()
        if entity_type in _INLINE_SECTION_TYPES:
            path = plugin.url_for(section_items, page_slug=slug, section_id=section['id'])
        else:
            section_slug = section.get('slug', '')
            if not section_slug:
                continue
            path = plugin.url_for(collection, slug=section_slug)
        folder.add_item(label=label, path=path)

    return folder


@plugin.route()
@plugin.login_required()
def section_items(page_slug, section_id, **kwargs):
    data = api.page(page_slug)
    for section in data.get('sections', []):
        if str(section.get('id')) == str(section_id):
            folder = plugin.Folder(section.get('title', ''))
            folder.add_items([_parse_row(item) for item in section.get('items', [])])
            return folder


@plugin.route()
@plugin.login_required()
@plugin.pagination(key='cursor')
def collection(slug, cursor=None, **kwargs):
    data = api.collection(slug, cursor=cursor)
    folder = plugin.Folder(data.get('title', ''))

    items = [_parse_row(item) for item in data.get('items', [])]
    folder.add_items(items)
    return folder, data.get('meta', {}).get('nextCursor')


def _plot(data):
    parts = [data.get('description', '')]
    end = data.get('availability', {}).get('end')
    if end and not data.get('liveStream'):
        end_arrow = arrow.get(end).to('local')
        if end_arrow < arrow.now().shift(days=40):
            parts.append(_(_.EXPIRES, date=end_arrow.humanize(), _bold=True, _color='yellow'))
        else:
            parts.append(_(_.EXPIRES, date=end_arrow.format('DD/MM/YY'), _bold=True))
    return u'\n\n'.join(p for p in parts if p)


def _parse_episode(data):
    images = data.get('images', [])
    media_id = data.get('mpxMediaID')
    slug = data.get('slug', '')
    genres = data.get('genres', [])
    is_live = data.get('liveStream', False)
    if media_id:
        path = plugin.url_for(play, media_id=media_id)
    else:
        path = plugin.url_for(play_tv_program, slug=slug)
    title = data.get('title', '')
    if is_live:
        path = plugin.url_for(play, media_id=media_id, _is_live=True)
        start = data.get('availability', {}).get('start')
        if start and arrow.get(start) > arrow.now():
            live_tag = _(_.LIVE_IN, when=arrow.get(start).humanize(), _bold=True, _color='yellow')
        else:
            live_tag = _(_.LIVE, _bold=True)
        label = u'{} {}'.format(title, live_tag)
    else:
        label = title
    return plugin.Item(
        label=label,
        info={
            'plot': _plot(data),
            'tvshowtitle': data.get('seriesTitle'),
            'episode': data.get('episodeNumber') if not (1900 <= (data.get('seasonNumber') or 0) <= 2100) else None,
            'season': data.get('seasonNumber') if not (1900 <= (data.get('seasonNumber') or 0) <= 2100) else None,
            'duration': pthms_to_seconds(data.get('duration')),
            'year': data.get('releaseYear'),
            'mpaa': data.get('classificationID'),
            'genre': u', '.join(genres) if genres else None,
            'mediatype': 'episode',
        },
        art={
            'thumb': _image(images),
            'fanart': _image(images, 'fanart'),
        },
        path=path,
        playable=True,
    )


def _parse_row(data, in_favourites=False):
    entity_type = data.get('entityType', '')
    entity_id = data.get('id', '')
    title = data.get('title', '')
    slug = data.get('slug', '')
    description = data.get('description', '')
    genres = data.get('genres', [])
    images = data.get('images', [])
    trailers = data.get('trailers', []) # not shown in list endpoints, only detail endpoints
    media_id = data.get('mpxMediaID')
    thumb = _image(images)
    fanart = _image(images, 'fanart')
    info = {
        'plot': _plot(data),
        'genre': u', '.join(genres) if genres else None,
        'mpaa': data.get('classificationID'),
    }
    if entity_type in ('TV_SERIES', 'SPORTS_SERIES', 'NEWS_SERIES'):
        info['mediatype'] = 'tvshow'
        item = plugin.Item(
            label=title,
            info=info,
            art={'thumb': thumb, 'fanart': fanart},
            path=plugin.url_for(show, slug=slug, entity_type=entity_type),
        )
    elif entity_type == 'MOVIE':
        info['mediatype'] = 'movie'
        info['duration'] = pthms_to_seconds(data.get('duration'))
        info['year'] = data.get('releaseYear')
        path = plugin.url_for(play, media_id=media_id) if media_id else plugin.url_for(play_movie, slug=slug)
        item = plugin.Item(
            label=title,
            info=info,
            art={'thumb': thumb, 'fanart': fanart},
            path=path,
            playable=True,
        )
    elif entity_type in ('TV_PROGRAM', 'NEWS_PROGRAM', 'SPORTS_PROGRAM', 'SPORTS_EPISODE', 'TV_EPISODE', 'NEWS_EPISODE', 'CLIP'):
        item = _parse_episode(data)
    elif entity_type in ('CURATED_COLLECTION', 'DYNAMIC_COLLECTION'):
        item = plugin.Item(
            label=title,
            info={'plot': description},
            art={'thumb': thumb, 'fanart': fanart},
            path=plugin.url_for(collection, slug=slug),
        )
    elif entity_type == 'PAGE':
        item = plugin.Item(
            label=title,
            info={'plot': description},
            art={'thumb': thumb, 'fanart': fanart},
            path=plugin.url_for(page, slug=slug),
        )
    else:
        log.warning('Unsupported entity type: {} | id: {} | title: {} | slug: {}'.format(entity_type, entity_id, title, slug))
        return None

    if trailers:
        item.info['trailer'] = plugin.url_for(play, media_id=data['trailers'][0]['mpxMediaID'])

    if entity_id and entity_type not in ('CURATED_COLLECTION', 'DYNAMIC_COLLECTION', 'PAGE'):
        if in_favourites:
            item.context.append((_(_.REMOVE_WATCHLIST), 'RunPlugin({})'.format(
                plugin.url_for(remove_watchlist, entity_id=entity_id))))
        else:
            item.context.append((_(_.ADD_WATCHLIST), 'RunPlugin({})'.format(
                plugin.url_for(add_watchlist, entity_id=entity_id, entity_type=entity_type, title=title, thumb=thumb))))

    return item


@plugin.route()
@plugin.login_required()
@plugin.search(key='cursor')
def search(query, cursor=None, **kwargs):
    data = api.search(query, cursor=cursor)
    items = []
    for item in data.get('items', []):
        parsed = _parse_row(item)
        items.append(parsed)
    return items, data.get('meta', {}).get('nextCursor')


@plugin.route()
@plugin.login_required()
def watchlist(**kwargs):
    folder = plugin.Folder(_.WATCHLIST)
    items = []
    for item in api.get_watchlist():
        parsed = _parse_row(item, in_favourites=True)
        items.append(parsed)
    folder.add_items(items)
    return folder


@plugin.route()
@plugin.login_required()
def add_watchlist(entity_id, entity_type, title=None, thumb=None, **kwargs):
    api.add_watchlist(entity_id, entity_type)
    gui.notification(_.WATCHLIST_ADDED, heading=title, icon=thumb)


@plugin.route()
@plugin.login_required()
def remove_watchlist(entity_id, **kwargs):
    api.remove_watchlist(entity_id)
    gui.refresh()


@plugin.route()
@plugin.login_required()
def show(slug, entity_type='TV_SERIES', **kwargs):
    data = api.tv_series(slug, entity_type=entity_type)
    title = data.get('title', '')
    thumb = _image(data.get('images', []))
    fanart = _image(data.get('images', []), 'fanart')
    folder = plugin.Folder(title, thumb=thumb, fanart=fanart)

    seasons = data.get('seasons', [])
    if len(seasons) > 1:
        for season in seasons:
            season_num = season.get('seasonNumber') or season.get('number', 0)
            folder.add_item(
                label=_(_.SEASON, number=season_num),
                info={'plot': _plot(data), 'mediatype': 'season'},
                path=plugin.url_for(season_episodes, series_slug=slug, season_id=season['id'], entity_type=entity_type),
            )
    elif len(seasons) == 1:
        _add_episodes(folder, seasons[0].get('episodes', []))
    else:
        _add_episodes(folder, data.get('episodes', []))

    return folder


@plugin.route()
@plugin.login_required()
def season_episodes(series_slug, season_id, entity_type='TV_SERIES', **kwargs):
    data = api.tv_series(series_slug, entity_type=entity_type)
    fanart = _image(data.get('images', []), 'fanart')
    folder = plugin.Folder(data.get('title'), fanart=fanart)

    for season in data.get('seasons', []):
        if str(season.get('id')) == str(season_id):
            _add_episodes(folder, season.get('episodes', []))
            break

    return folder


def _add_episodes(folder, episodes):
    items = []
    for data in episodes:
        parsed = _parse_row(data)
        items.append(parsed)
    folder.add_items(items)


@plugin.route()
@plugin.login_required()
def live_tv(**kwargs):
    folder = plugin.Folder(_.LIVE_TV)
    now = arrow.now()

    for item in api.live_channels():
        ch = item['channel']

        plot = u''
        for entry in item.get('entries', []):
            prog = entry['program']
            start = arrow.get(entry['availability']['start'])
            if now < start or now < arrow.get(entry['availability']['end']):
                title = prog.get('seriesTitle') or prog['title']
                plot += u'[{}] {}\n'.format(start.to('local').format('h:mma'), title)

        thumb = _image(ch['images'])
        fanart = _image(ch['images'], 'fanart')

        folder.add_item(
            label=ch['title'].replace(' NSW', '').replace(' HD', '').strip(),
            info={'plot': plot.strip() or None},
            art={'thumb': thumb, 'fanart': fanart},
            path=plugin.url_for(play, media_id=ch['mpxMediaID'], _is_live=True),
            playable=True,
        )

    return folder


@plugin.route()
@plugin.merge()
@plugin.login_required()
def playlist(output, **kwargs):
    with codecs.open(output, 'w', encoding='utf8') as f:
        f.write(u'#EXTM3U')

        for item in api.live_channels():
            ch = item['channel']
            thumb = _image(ch['images']) or ''
            f.write(u'\n#EXTINF:-1 tvg-id="{tvg_id}" tvg-logo="{logo}",{name}\n{url}'.format(
                tvg_id='mjh-sbs-{}'.format(ch['ibmsChannelCode'].lower()),
                logo=thumb,
                name=ch['title'].replace(' NSW', '').replace(' HD', '').strip(),
                url=plugin.url_for(play, media_id=ch['mpxMediaID'], _is_live=True),
            ))


@plugin.route()
@plugin.login_required()
def play(media_id, **kwargs):
    return _play(media_id, **kwargs)


@plugin.route()
@plugin.login_required()
def play_movie(slug, **kwargs):
    data = api.movie(slug)
    return _play(data['mpxMediaID'], **kwargs)


@plugin.route()
@plugin.login_required()
def play_tv_program(slug, **kwargs):
    data = api.tv_program(slug)
    return _play(data['mpxMediaID'], **kwargs)


def _play(media_id, **kwargs):
    data = api.play(media_id)

    item = plugin.Item(
        path = data['url'],
        inputstream=inputstream.HLS(live=ROUTE_LIVE_TAG in kwargs),
        headers = {'user-agent': DAI_USER_AGENT},
    )

    subs = data.get('subtitles', [])
    if subs:
        item.inputstream = None # ia has 20s offset on below subs, ffmpeg works correctly
        for row in subs:
            attribs = ','.join(row.get('attributes', [])).upper()
            item.subtitles.append([row['url'], row['lang'], 'text/vtt', True if 'FORCED' in attribs else False, False, True if 'DEFAULT' in attribs else False])

    return item


def _image(images, img_type='thumb'):
    def _get_image(ratio, img_type):
        matches = []
        for img in images:
            cat = img.get('category', '')
            parts = cat.split('|')
            if len(parts) == 4 and (not ratio or ':' in ratio):
                img_ratio, width, height, itype = parts
                if (ratio is None or img_ratio == ratio) and (img_type is None or itype == img_type):
                    matches.append((int(width) * int(height), img['id']))
            elif cat == img_type:
                matches.append((0, img['id']))
        if not matches:
            return None
        matches.sort(reverse=True)
        return IMAGE_URL + '/' + matches[0][1]

    img_url = None
    if img_type == 'thumb':
        img_url = _get_image('2:1', 'BANNER') or _get_image('2:3', 'BANNER') or _get_image(None, 'CHANNEL_LOGO_IOS_1') or _get_image(None, 'BANNER') or _get_image('2:1', 'KEY_ART') or _get_image('2:3', 'KEY_ART') or _get_image(None, 'KEY_ART')
    elif img_type == 'fanart':
        img_url = _get_image('16:9', 'BANNER') or _get_image('16:9', 'KEY_ART')

    return img_url


@plugin.route()
def logout(**kwargs):
    if not gui.yes_no(_.LOGOUT_YES_NO):
        return

    api.logout()
    gui.refresh()
