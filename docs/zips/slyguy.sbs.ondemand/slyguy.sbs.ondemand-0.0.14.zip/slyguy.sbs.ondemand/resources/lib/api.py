import time
import uuid

from six.moves.urllib.parse import parse_qsl, urlencode, urlparse, urlunparse
from slyguy import userdata, keep_alive
from slyguy.util import jwt_data
from slyguy.session import Session
from slyguy.exceptions import Error

from .constants import HEADERS, AUTH_URL, CATALOGUE_URL, SEARCH_URL, EPG_URL, PLAYBACK_URL, USER_ACTIVITY_URL, DEVICE_NAME, DEVICE_CLASS
from .language import _
from .settings import settings


class APIError(Error):
    pass


class API(object):
    def new_session(self):
        self.logged_in = False
        self._session = Session(HEADERS)
        self._set_authentication()
        keep_alive.register(self._refresh_token, hours=12, enable=self.logged_in)

    def _set_authentication(self):
        access_token = userdata.get('access_token')
        if not access_token:
            return

        self._session.headers.update({'Authorization': 'Bearer {}'.format(access_token)})
        self.logged_in = True

    def device_code(self):
        payload = {'deviceName': DEVICE_NAME}
        return self._session.post(AUTH_URL + '/device/link', json=payload).json()

    def device_login(self, device_code):
        payload = {
            'deviceCode': device_code,
            'refreshTokenInBody': True,
        }
        data = self._session.post(AUTH_URL + '/device/poll', json=payload).json()
        if data.get('accessToken'):
            return self._parse_auth(data)
        return False

    def login(self, username, password):
        self.logout()

        payload = {
            'deviceName': DEVICE_NAME,
            'email': username,
            'password': password,
            'refreshTokenInBody': True,
        }

        data = self._session.post(AUTH_URL + '/login', json=payload).json()
        if not self._parse_auth(data):
            raise APIError(_.LOGIN_ERROR)

    def _parse_auth(self, data):
        if not data.get('accessToken'):
            return False

        access_token = data['accessToken']
        jwt = jwt_data(access_token)

        userdata.set('access_token', access_token)
        userdata.set('token_expires', jwt['exp'] - 30)
        if data.get('refreshToken'):
            userdata.set('refresh_token', data['refreshToken'])

        self._set_authentication()
        return True

    def _refresh_token(self, force=False):
        if not self.logged_in or (not force and userdata.get('token_expires', 0) > time.time()):
            return

        payload = {
            'deviceName': DEVICE_NAME,
            'refreshToken': userdata.get('refresh_token'),
            'refreshTokenInBody': True,
        }

        data = self._session.post(AUTH_URL + '/refresh', json=payload).json()
        self._parse_auth(data)

    def page(self, slug):
        self._refresh_token()
        return self._session.get(CATALOGUE_URL + '/pages/{}'.format(slug)).json()

    def collection(self, slug, cursor=None):
        self._refresh_token()
        params = {}
        if cursor:
            params['cursor'] = cursor
        return self._session.get(CATALOGUE_URL + '/collections/{}'.format(slug), params=params).json()

    def tv_series(self, slug, entity_type='TV_SERIES'):
        self._refresh_token()
        if entity_type == 'SPORTS_SERIES':
            path = 'sports-series'
        elif entity_type == 'NEWS_SERIES':
            path = 'news-series'
        else:
            path = 'tv-series'
        return self._session.get(CATALOGUE_URL + '/{}/{}'.format(path, slug)).json()

    def movie(self, slug):
        self._refresh_token()
        return self._session.get(CATALOGUE_URL + '/movies/{}'.format(slug)).json()

    def tv_program(self, slug):
        self._refresh_token()
        return self._session.get(CATALOGUE_URL + '/tv-programs/{}'.format(slug)).json()

    def search(self, query, cursor=None):
        self._refresh_token()
        params = {'q': query, 'limit': 24}
        if cursor:
            params['cursor'] = cursor
        return self._session.get(SEARCH_URL + '/catalogue', params=params).json()

    def get_watchlist(self):
        self._refresh_token()
        data = self._session.get(CATALOGUE_URL + '/favourite').json()
        return data if isinstance(data, list) else []

    def add_watchlist(self, entity_id, entity_type):
        self._refresh_token()
        payload = [{'entityID': entity_id, 'entityType': entity_type.lower().replace('_', '-')}]
        self._session.post(USER_ACTIVITY_URL + '/favourite', json=payload)

    def remove_watchlist(self, entity_id):
        self._refresh_token()
        self._session.delete(USER_ACTIVITY_URL + '/favourite/{}'.format(entity_id))

    def live_channels(self):
        self._refresh_token()
        return self._session.get(EPG_URL + '/guides-v2', params={'limit': 0}).json()['items']

    def play(self, media_id):
        self._refresh_token()
        device_id = userdata.get('device_id')
        if not device_id:
            device_id = str(uuid.uuid4())
            userdata.set('device_id', device_id)

        payload = {
            'advertising': {
                'deviceID': device_id,
                'deviceTargetingOptOut': True,
                'sbsTargetingOptOut': True,
                'subtitle': 'en',
                'resume': False,
            },
            'deviceClass': DEVICE_CLASS,
            'streamOptions': {'audio': 'demuxed'},
        }

        data = self._session.post(PLAYBACK_URL + '/stream/{}'.format(media_id), json=payload).json()
        providers = data.get('streamProviders', [])

        if settings.PREFER_DAI_STREAMS.value: #and data.get('streamType','').lower() != 'live':
            provider_order = ['GoogleDAI', 'HLS']
        else:
            provider_order = ['HLS', 'GoogleDAI']

        for provider_type in provider_order:
            for provider in providers:
                if provider['type'] == provider_type:
                    if provider_type == 'GoogleDAI':
                        provider['url'] = self._dai_stream(provider)
                    else:
                        # allow 1080 and use same dai vod domain as dai / website / apps
                        provider['url'] = provider['url'].replace('master_720.m3u8', 'master.m3u8').replace('sbs-vod-prod', 'sbs-vod-dai-prod')
                    return provider

        raise APIError('No stream found')

    def _dai_stream(self, provider):
        asset_key = provider.get('assetKey')
        if asset_key:
            # live stream
            data = self._session.post('https://dai.google.com/ssai/event/{}/streams'.format(asset_key), data={}).json()
            url = data['stream_manifest']
            # remove the chapters. this removes subs on VOD so only do it for live streams
            p = urlparse(url)
            qs = [(k, v) for k, v in parse_qsl(p.query) if k != 'originpath']
            return urlunparse(p._replace(query=urlencode(qs)))
        else:
            # vod
            data = self._session.post('https://dai.google.com/ondemand/hls/content/{}/vid/{}/streams'.format(provider['contentSourceID'], provider['videoID']), data={}).json()
        return data['stream_manifest']


    def logout(self):
        refresh_token = userdata.get('refresh_token')
        if refresh_token:
            try:
                payload = {'refreshToken': refresh_token, 'refreshTokenInBody': True}
                self._session.delete(AUTH_URL + '/refresh', json=payload)
            except Exception:
                pass

        userdata.delete('access_token')
        userdata.delete('refresh_token')
        userdata.delete('token_expires')
        self.new_session()
