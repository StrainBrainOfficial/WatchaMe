HEADERS = {
    'x-api-key': 'ce3f270a-31fb-486e-855e-4f608a62640e',
    'accept-language': 'en',
    'user-agent': 'okhttp/4.10.0',
}
DAI_USER_AGENT = 'otg/1.5.1 (AppleTv Apple TV 4; tvOS16.0; appletv.client) libcurl/7.58.0 OpenSSL/1.0.2o zlib/1.2.11 clib/1.8.56'

AUTH_URL = 'https://auth.sbs.com.au'
CATALOGUE_URL = 'https://catalogue.pr.sbsod.com'
EPG_URL = 'https://tv-epg.pr.sbsod.com'
SEARCH_URL = 'https://content-search.pr.sbsod.com'
PLAYBACK_URL = 'https://playback.pr.sbsod.com'
IMAGE_URL = 'https://image.pr.sbsod.com'
DEVICE_NAME = 'NVIDIA SHIELD Android TV - SBS On Demand'
DEVICE_CLASS = 'androidtv'
USER_ACTIVITY_URL = 'https://user-activity.pr.sbsod.com'