# -*- coding: utf-8 -*-
import re
import time

global global_var,stop_all#global
global_var=[]
stop_all=0
from  resources.modules.client import get_html
 
from resources.modules.general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,all_colors,base_header,detect_quality_from_name
from  resources.modules import cache
try:
    from resources.modules.general import Addon,get_imdb
except:
  import Addon
type=['movie','tv','torrent']

import urllib,logging,base64,json

from resources.modules import log
try:
    que=urllib.quote_plus
except:
    que=urllib.parse.quote_plus

color=all_colors[112]
def get_links(tv_movie,original_title,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all
    all_links=[]
    
    # ====== PERFORMANCE: Cache settings before loops ======
    max_size = int(Addon.getSetting("size_limit"))
    
    imdb_id=cache.get(get_imdb, 999,tv_movie,id,table='pages')
        

    
    if tv_movie=='movie':
     search_url=[((clean_name(original_title,1).replace(' ','%20')+'%20'+show_original_year)).lower()]
    elif tv_movie=='tv':
    
     
        search_url=[clean_name(original_title,1).replace(' ','%20')+'%20'+'s'+season_n+'e'+episode_n]
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:75.0) Gecko/20100101 Firefox/75.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
    }

    for itt in search_url:
       
        ur='https://apibay.org/q.php?q=%s&cat=0'%(itt)
        log.warning(ur)
        y=get_html(ur,headers=headers,timeout=10).json()
    
        for results in y:
            
      
              
            if stop_all==1:
                break
            nam=results['name']
            size=(float(results['size'])/(1024*1024*1024))
            peer=results['leechers']
            seed=results['seeders']
            
            links='magnet:?xt=urn:btih:%s&dn=%s'%(results['info_hash'],que(nam))
            
            # ====== PERFORMANCE: Use helper function for quality detection ======
            res = detect_quality_from_name(nam)
            
            
            if (size)<max_size:
               
                all_links.append((nam,links,str(size),res))

                global_var=all_links
    return global_var