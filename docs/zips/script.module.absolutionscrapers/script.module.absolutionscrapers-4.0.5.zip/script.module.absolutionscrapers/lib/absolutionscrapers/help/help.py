# -*- coding: utf-8 -*-
"""
	Fenomscrapers Module
"""

from absolutionscrapers.modules.control import addonPath, addonVersion, joinPath
from absolutionscrapers.windows.textviewer import TextViewerXML


def get(file):
	absolutionscrapers_path = addonPath()
	absolutionscrapers_version = addonVersion()
	helpFile = joinPath(absolutionscrapers_path, 'lib', 'absolutionscrapers', 'help', file + '.txt')
	r = open(helpFile, 'r', encoding='utf-8', errors='ignore')
	text = r.read()
	r.close()
	heading = '[B]absolutionscrapers -  v%s - %s[/B]' % (absolutionscrapers_version, file)
	windows = TextViewerXML('textviewer.xml', absolutionscrapers_path, heading=heading, text=text)
	windows.run()
	del windows