from dataclasses import dataclass, field
from typing import Any, Dict, List


@dataclass
class TorrentStream:
    # Identification
    title: str = ""
    type: str = ""  # e.g., "torrent" or "debrid" or "direct"
    debridType: str = ""
    indexer: str = ""
    subindexer: str = ""
    addonKey: str = ""
    addonName: str = ""
    addonSourceName: str = ""
    addonInstanceLabel: str = ""
    guid: str = ""
    infoHash: str = ""

    # Stats
    size: int = 0  # in bytes
    seeders: int = 0
    peers: int = 0

    # Language info
    languages: List[str] = field(default_factory=list)
    fullLanguages: str = ""

    # Source info
    provider: str = ""
    publishDate: str = ""  # ISO format preferred

    # Quality and URLs
    quality: str = "N/A"
    url: str = ""
    streamSubtitles: List[Dict[str, Any]] = field(default_factory=list)

    # Flags
    isPack: bool = False
    isCached: bool = False
    addedToDebrid: bool = False

    # Codec & HDR
    codec: str = ""
    hdr: str = ""

    # Optional Stremio metadata.  Keep this last so old positional callers and
    # cached objects remain compatible.
    stremioMetadata: Dict[str, Any] = field(default_factory=dict)
