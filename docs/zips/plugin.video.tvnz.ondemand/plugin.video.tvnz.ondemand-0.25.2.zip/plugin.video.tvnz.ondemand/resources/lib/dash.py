import re
import struct
import threading

from kodi_six import xbmcgui

from slyguy import cache
from slyguy.log import log

from .language import _


# Some TVNZ VOD manifests declare a segment duration that does not match the
# real segment grid (eg. 3624 instead of 3600 at an ad break). With $Time$
# addressing that shifts every later segment, so the CDN 404s the whole tail of
# the episode: video freezes while audio (a separate adaptation set) keeps
# playing, and seeking forward can never work.
#
# The timeline is shared by every rendition while the packager only matched it
# to one of them, so renditions that do not follow the repaired timeline are
# dropped - inputstream.adaptive stops the stream on a 404 rather than falling
# back to another rendition.

MAX_PROBES = 200
CACHE_KEY = 'dash_timeline'
CACHE_EXPIRES = 60 * 60

# the bug is always a segment one frame too long (3624 instead of 3600 at 25fps),
# so any duration within a couple of frames of the modal one is the thing to fix
SNAP_TOLERANCE = 0.02
CONTENT_TYPES = ('video',)

# Every segment carries an ISO-BMFF 'sidx' box describing its own real timing,
# which is inside the first couple of KB - so one ranged request per segment
# tells us the truth even when the packager declared the wrong durations.
SIDX_BYTES = 2048

# segment names can be a whole frame (or many) away from the declared value, so
# a missed prediction searches this many frames either side of it
SEARCH_FRAMES = 64
# how many speculative names to read per round trip, and in parallel. Each read
# pays a round trip, so the pool matters more than the batch size
BATCH = 32
WORKERS = 32


def _pmap(func, items, workers=WORKERS):
    """Tiny thread pool - the addon has no futures module on Python 2."""
    items = list(items)
    if len(items) < 2 or workers < 2:
        return [func(item) for item in items]

    results = [None] * len(items)
    counter = [0]
    lock = threading.Lock()

    def run():
        while True:
            with lock:
                if counter[0] >= len(items):
                    return
                index = counter[0]
                counter[0] += 1
            try:
                results[index] = func(items[index])
            except Exception:
                results[index] = None

    threads = [threading.Thread(target=run) for _ in range(min(workers, len(items)))]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()

    return results

# Everything above is policy rather than algorithm, so every one of them can be
# overridden per call - that keeps the module liftable into a shared framework.
DEFAULTS = {
    'max_probes': MAX_PROBES,
    'cache_key': CACHE_KEY,
    'cache_expires': CACHE_EXPIRES,
    'tolerance': SNAP_TOLERANCE,
    # adaptation sets to repair; None means every set, which is the safest
    # default for an unknown packager
    'content_types': CONTENT_TYPES,
    # drop renditions that cannot follow the repaired timeline (inputstream
    # aborts on a 404 instead of falling back to another rendition)
    # keep renditions that were packaged against the declared timeline by giving
    # them their own template, instead of dropping the quality level
    'split_unmatched': True,
    # dialog heading; None uses this addon's string
    'label': None,
    # how many bytes of each segment to read when consulting its sidx
    'sidx_bytes': SIDX_BYTES,
    # how many frames either side of a wrong prediction to search
    'search_frames': SEARCH_FRAMES,
}


class _Incomplete(Exception):
    """Repair could not reach a conclusion - never cache that outcome."""


def _cache_lookup(url, cache_key):
    # single slot: the stored entry is only valid for the url that produced it,
    # so playing something else simply replaces it
    try:
        entry = cache.get(cache_key)
    except Exception as e:
        log.debug('DASH timeline: cache read failed - {}'.format(e))
        return False, None

    if isinstance(entry, dict) and entry.get('url') == url:
        return True, entry.get('data') or None
    return False, None


def _cache_store(url, data, cache_key, expires):
    try:
        cache.set(cache_key, {'url': url, 'data': data or ''}, expires)
    except Exception as e:
        log.debug('DASH timeline: cache write failed - {}'.format(e))

_TEMPLATE = re.compile(r'<SegmentTemplate\b[^>]*>.*?</SegmentTemplate>', re.DOTALL)
_TIMELINE = re.compile(r'<SegmentTimeline>(.*?)</SegmentTimeline>', re.DOTALL)
_SEGMENT = re.compile(r'<S\s(.*?)/>', re.DOTALL)
_ATTR = re.compile(r'([\w:.-]+)\s*=\s*"([^"]*)"')
_REPRESENTATION = re.compile(r'<Representation\b([^>]*)>(?:\s*</Representation>)?')
_BASEURL = re.compile(r'<BaseURL>([^<]*)</BaseURL>')
_DYNAMIC = re.compile(r'type\s*=\s*["\']dynamic["\']')
_PERIOD = re.compile(r'<Period\b[^>]*>')
_DURATION = re.compile(r'PT(?:(\d+)H)?(?:(\d+)M)?(?:([\d.]+)S)?')


def _duration_ticks(value, timescale=600):
    """PT41M59.340S -> ticks. Only used to know when the timeline ends."""
    if not value:
        return None

    match = _DURATION.search(value)
    if not match:
        return None

    hours, minutes, seconds = match.groups()
    total = int(hours or 0) * 3600 + int(minutes or 0) * 60 + float(seconds or 0)
    return int(round(total * timescale))


def _attrs(raw):
    return dict(_ATTR.findall(raw))


def _join(base, path):
    """Minimal urljoin - enough for relative segment templates."""
    if '://' in path:
        return path
    if not base.endswith('/'):
        base = base.rsplit('/', 1)[0] + '/'
    return base + path.lstrip('/')


def _parse_segments(timeline):
    segments = []
    tick = 0

    for raw in _SEGMENT.findall(timeline):
        attrs = _attrs(raw)
        if 't' in attrs:
            tick = int(attrs['t'])

        duration = int(attrs['d'])
        for _ in range(int(attrs.get('r', 0)) + 1):
            segments.append((tick, duration))
            tick += duration

    return segments


def _build_timeline(segments):
    rows = ['<SegmentTimeline>']
    for tick, duration in segments:
        rows.append('<S t="{}" d="{}"/>'.format(tick, duration))
    rows.append('</SegmentTimeline>')
    return ''.join(rows)


def _representations(text, pos):
    end = text.find('</AdaptationSet>', pos)
    if end == -1:
        end = len(text)

    reps = []
    for match in _REPRESENTATION.finditer(text, pos, end):
        attrs = _attrs(match.group(1))
        if 'id' not in attrs:
            continue

        # match.group(0) may already include a trailing </Representation>, so the
        # search for the real close must start from the opening tag's '>'
        start = match.start()
        open_end = start + match.group(0).find('>') + 1
        attrs['open'] = text[start:open_end]
        attrs['tail'] = ''
        if match.group(0)[:match.group(0).find('>') + 1].rstrip().endswith('/>'):
            attrs['span'] = (start, open_end)
            attrs['removable'] = True
        else:
            close = text.find('</Representation>', open_end, end)
            if close == -1:
                attrs['span'] = (start, open_end)
                attrs['removable'] = False
            else:
                # take any children with us, otherwise removing the opening tag
                # alone would leave orphaned elements behind
                attrs['span'] = (start, close + len('</Representation>'))
                attrs['tail'] = text[open_end:close + len('</Representation>')]
                attrs['removable'] = True

        reps.append(attrs)

    # the highest bandwidth rendition is the one actually used, so it decides
    # what the timeline should look like
    reps.sort(key=lambda rep: int(rep.get('bandwidth', 0) or 0), reverse=True)
    return reps


def _segment_url(base, media, rep, tick):
    path = media.replace('$RepresentationID$', rep.get('id', ''))
    path = path.replace('$Bandwidth$', rep.get('bandwidth', ''))
    path = path.replace('$Time$', str(tick))
    return _join(base, path)


def _probe(exists, url, budget):
    if budget[0] <= 0:
        return False
    budget[0] -= 1
    return exists(url)


def _rep_exists(job, rep, tick, base, exists, budget):
    return _probe(exists, _segment_url(base, job['media'], rep, tick), budget)


def _resolve_base(text, url, job, exists, budget):
    candidates = [_join(url, '')]
    for base in _BASEURL.findall(text):
        candidate = _join(url, base)
        if candidate not in candidates:
            candidates.append(candidate)

    tick = job['segments'][0][0]
    for candidate in candidates:
        if _rep_exists(job, job['reps'][0], tick, candidate, exists, budget):
            return candidate

    return None


def _verify(job, base, exists, budget):
    segments = job['segments']
    rep = job['reps'][0]
    modal = job['modal']

    ticks = []
    tick = segments[0][0]
    changed = False

    for index, (_, duration) in enumerate(segments):
        ticks.append(tick)
        tick += duration

        # only odd durations are worth checking - a wrong one shifts every
        # following $Time$ value, so the next segment is what goes missing
        if duration != modal and index + 1 < len(segments):
            if not _rep_exists(job, rep, tick, base, exists, budget):
                alt = ticks[index] + modal
                if not _rep_exists(job, rep, alt, base, exists, budget):
                    raise _Incomplete('unexpected segment durations')
                tick = alt
                changed = True

    if not changed:
        return None

    fixed = []
    for index, start in enumerate(ticks):
        duration = ticks[index + 1] - start if index + 1 < len(ticks) else segments[index][1]
        fixed.append((start, duration))
    return fixed


def _parse_sidx(data):
    """Return (timescale, earliest_presentation_time, duration) from a segment."""
    index = data.find(b'sidx')
    if index == -1:
        return None

    try:
        pos = index + 4
        version = struct.unpack('B', data[pos:pos + 1])[0]
        pos += 4  # version + flags
        pos += 4  # reference_id
        timescale = struct.unpack('>I', data[pos:pos + 4])[0]
        pos += 4

        if version == 0:
            start = struct.unpack('>I', data[pos:pos + 4])[0]
            pos += 8
        else:
            start = struct.unpack('>Q', data[pos:pos + 8])[0]
            pos += 16

        pos += 2  # reserved
        count = struct.unpack('>H', data[pos:pos + 2])[0]
        pos += 2

        duration = 0
        for _ in range(count):
            pos += 4  # reference_type + reference_size
            duration += struct.unpack('>I', data[pos:pos + 4])[0]
            pos += 8  # duration + sap
    except struct.error:
        return None

    if not timescale:
        return None

    return timescale, start, duration


def _sidx_of(fetch, url, length):
    data = fetch(url, length)
    if not data:
        return None
    return _parse_sidx(data)


def _rebuild(job, base, modal, config, fetch, exists, budget, progress, meta):
    """Rebuild the timeline from each segment's own sidx box.

    Ad breaks are where TVNZ's packager mis-declares a trimmed segment, and the
    error can be many frames in either direction - so the declared times cannot
    be corrected arithmetically. The media itself is authoritative: every
    segment is $Time$ addressed and carries a sidx box stating its real
    duration, so walking those durations (starting at a name that exists) gives
    the exact list of segment names.

    Reads are batched through a small thread pool because the walk is otherwise
    one round trip per segment; a batch speculates that the following segments
    are the modal length, and when that guess misses we search around it.
    """
    segments = job['segments']
    total = job['total']
    rep = job['reps'][0]
    size = config['sidx_bytes']
    frame = job.get('frame') or 0

    # the bar follows segments discovered, not requests made: a batch that runs
    # into a break wastes reads on names that do not exist, and counting those
    # would leave the bar short of the end
    expected = max(1, len(segments))

    def mark():
        if meta['shown']:
            progress.update(min(len(real), expected), expected)

    def read(ticks):
        ticks = list(ticks)
        datas = _pmap(lambda tick: fetch(_segment_url(base, job['media'], rep, tick), size), ticks)
        found = {}
        for tick, data in zip(ticks, datas):
            found[tick] = _parse_sidx(data) if data else None
        return found

    def search(known, wanted):
        """Find the real segment name nearest `wanted` after `known`."""
        stages = []
        if frame:
            stages.append([wanted + frame * step
                           for step in range(-config['search_frames'], config['search_frames'] + 1)])
        stages.append([wanted + step for step in range(-240, 241)])

        for candidates in stages:
            candidates = [tick for tick in sorted(set(candidates)) if tick > known]
            hits = [tick for tick, info in read(candidates).items() if info]
            if hits:
                return hits[0]
        return None

    real = []
    tick = segments[0][0]

    while tick < total and len(real) < len(segments) * 2:
        # speculate that the following segments are all the modal length; a
        # break makes a name miss and the search below re-syncs
        batch = [tick + modal * step for step in range(BATCH)]
        infos = read(batch)

        progressed = False
        for name in batch:
            info = infos.get(name)
            if not info or not info[2]:
                break
            real.append((name, info[2]))
            progressed = True
            tick = name + info[2]
            if info[2] != modal:
                break

        mark()

        if progressed:
            continue

        if real and total - tick <= modal:
            # the media ends a little before the declared Period duration
            break

        found = search(real[-1][0] if real else tick - 1,
                       real[-1][0] + real[-1][1] if real else tick)
        if not found:
            return None
        tick = found

    mark()

    if len(real) < 2:
        return None

    # the Period duration can be a frame or two off the media, so only give up
    # when a whole segment is unaccounted for
    if tick < total - modal:
        return None

    return real


def _frame_ticks(text, pos, block):
    """Ticks per frame, so a missed prediction can be searched frame by frame."""
    start = text.rfind('<AdaptationSet', 0, pos)
    if start == -1:
        return 0

    attrs = _attrs(text[start:text.find('>', start) + 1])
    rate = attrs.get('frameRate') or ''
    if '/' in rate:
        try:
            rate = float(rate.split('/')[0]) / float(rate.split('/')[1])
        except (ValueError, ZeroDivisionError):
            rate = 0
    try:
        rate = float(rate)
    except ValueError:
        return 0

    if rate <= 0:
        return 0

    timescale = int(_attrs(block[:block.index('>')]).get('timescale') or 1)
    return int(round(timescale / rate)) or 1


def _content_type(text, pos):
    start = text.rfind('<AdaptationSet', 0, pos)
    if start == -1:
        return None


    end = text.find('>', start)
    if end == -1:
        return None

    attrs = _attrs(text[start:end + 1])
    return attrs.get('contentType') or attrs.get('mimeType')


def _snap(job, tolerance):
    """Guess the repair arithmetically: a duration a frame off the modal one is
    the bug. Returns None when nothing looks that way (so it needs probing).
    """
    modal = job['modal']
    limit = modal * tolerance
    segments = job['segments']

    fixed = []
    tick = segments[0][0]
    changed = False

    for index, (_, duration) in enumerate(segments):
        if index + 1 < len(segments) and duration != modal and abs(duration - modal) <= limit:
            duration = modal
            changed = True
        fixed.append((tick, duration))
        tick += duration

    return fixed if changed else None


def _add_rep_template(rep, timeline):
    """Replace a representation's opening tag with itself plus a child
    <SegmentTemplate> holding its own timeline.

    DASHTree.cpp parses a SegmentTemplate under <Representation> and clears any
    timeline inherited from the adaptation set, so this overrides just that
    rendition. Everything else (media, timescale, initialization) is inherited.
    """
    open_tag = rep['open']
    template = '<SegmentTemplate>{}</SegmentTemplate>'.format(timeline)

    if open_tag.rstrip().endswith('/>'):
        # self-closing representation has to become a real element to hold a child
        open_tag = open_tag.rstrip()[:-2].rstrip() + '>'
        replacement = open_tag + template + '</Representation>'
    else:
        # keep whatever the element already contains (ContentProtection, etc.)
        replacement = open_tag + template + rep.get('tail', '')

    return (rep['span'][0], rep['span'][1], replacement)


def _apply(job, fixed, base, exists, budget, url, split_unmatched=True):
    job['edits'].append((
        job['match'].start() + job['timeline'].start(),
        job['match'].start() + job['timeline'].end(),
        _build_timeline(fixed),
    ))

    declared_tail = job['segments'][-1][0]
    real_tail = fixed[-1][0]

    keep = [job['reps'][0]]
    other = []
    drop = []

    for rep in job['reps'][1:]:
        if _rep_exists(job, rep, real_tail, base, exists, budget):
            keep.append(rep)
        elif not split_unmatched:
            drop.append(rep)
        elif _rep_exists(job, rep, declared_tail, base, exists, budget):
            # this rendition was packaged against the timeline as declared, so
            # give it back rather than throwing the quality level away
            other.append(rep)
        else:
            drop.append(rep)

    if drop and len(job['reps']) > 2 and len(drop) == len(job['reps']) - 1:
        # only the highest rendition follows this grid, so it is more likely
        # the odd one out - repairing to it would break every other rendition.
        # (with just two renditions we cannot tell, so trust the highest)
        raise _Incomplete('only the top rendition agrees for {}'.format(url))

    declared = _build_timeline(job['segments'])
    for rep in other:
        log.debug('DASH timeline: keeping rendition {} on the declared timeline'.format(rep['id']))
        job['edits'].append(_add_rep_template(rep, declared))

    for rep in drop:
        if not rep.get('removable'):
            log.warning('DASH timeline: cannot drop rendition {} with children'.format(rep['id']))
            continue
        log.info('DASH timeline: dropping rendition {}'.format(rep['id']))
        job['edits'].append((rep['span'][0], rep['span'][1], ''))


def _fix(data, url, exists, progress, config, fetch=None):
    text = data.decode('utf8')

    if _DYNAMIC.search(text) or '$Time$' not in text or '<SegmentTimeline>' not in text:
        return None

    period = _PERIOD.search(text)
    total = None
    if period:
        total = _duration_ticks(_attrs(period.group(0)).get('duration'))

    kinds = config['content_types']

    jobs = []
    for match in _TEMPLATE.finditer(text):
        block = match.group(0)
        timeline = _TIMELINE.search(block)
        if not timeline or '$Time$' not in block:
            continue

        content = _content_type(text, match.start())
        if kinds is not None and content is not None and not any(kind in content for kind in kinds):
            # TVNZ's audio and subtitle timelines are self-consistent and
            # cannot cause the video freeze, so skipping them here is what keeps
            # a healthy manifest at zero probes
            continue

        segments = _parse_segments(timeline.group(1))
        reps = _representations(text, match.end())
        if not segments or not reps:
            continue

        durations = [duration for _, duration in segments]
        modal = max(set(durations), key=durations.count)
        # a short tail segment is normal and cannot shift anything after it, so
        # only the body decides whether this timeline can be wrong at all
        if all(duration == modal for duration in durations[:-1]):
            continue

        jobs.append({
            'match': match,
            'timeline': timeline,
            'segments': segments,
            'modal': modal,
            'timescale': int(_attrs(block[:block.index('>')]).get('timescale') or 1),
            'frame': _frame_ticks(text, match.start(), block),
            'total': total,
            'media': _attrs(block[:block.index('>')]).get('media', ''),
            'reps': reps,
            'edits': [],
        })

    if not jobs:
        return None

    # progress is deliberately conservative: the total only grows when a set
    # actually needs work, because a healthy manifest never probes at all
    meta = {
        'done': 0,
        'total': 1,
        'shown': False,
    }

    def probe_url(_url):
        meta['done'] += 1
        ok = exists(_url)
        if meta['shown']:
            progress.update(meta['done'], meta['total'])
        return ok

    budget = [config['max_probes']]
    base = [None]

    def segment_base():
        if base[0] is None:
            base[0] = _resolve_base(text, url, jobs[0], probe_url, budget)
            if not base[0]:
                raise _Incomplete('unable to resolve segment base')
        return base[0]

    def tail_ok(job, tick):
        """Probe a rendition's last segment using the manifest's own directory
        first, so resolving a <BaseURL> never costs a probe in the normal case.
        """
        default = _join(url, '')
        if _rep_exists(job, job['reps'][0], tick, default, probe_url, budget):
            base[0] = default
            return True

        return _rep_exists(job, job['reps'][0], tick, segment_base(), probe_url, budget)

    repaired = 0
    for job in jobs:
        # the period duration is in seconds, the timeline in ticks
        job['total'] = _duration_ticks(
            _attrs(_PERIOD.search(text).group(0)).get('duration')) if period else None
        if job['total']:
            job['total'] = int(round(job['total'] * job['timescale'] / 600.0))

        snapped = _snap(job, config['tolerance'])

        if snapped is None:
            # odd durations, but nothing a frame-sized error - needs the walk
            if tail_ok(job, job['segments'][-1][0]):
                continue

            fixed = _sidx_or_walk(job, segment_base(), probe_url, budget, config,
                                  fetch, progress, meta)
            if fixed:
                repaired += 1
                _apply(job, fixed, segment_base(), probe_url, budget, url, config['split_unmatched'])
            continue

        # The guess only needs confirming once: segments are $Time$ addressed,
        # so a wrong duration shifts every later tick - meaning the final
        # segment tests the whole timeline, not just the end of it.
        if tail_ok(job, snapped[-1][0]):
            repaired += 1
            _apply(job, snapped, segment_base(), probe_url, budget, url, config['split_unmatched'])
            continue

        # the guess was wrong, so ask the media itself and fall back to probing
        fixed = _sidx_or_walk(job, segment_base(), probe_url, budget, config,
                              fetch, progress, meta)
        if fixed:
            repaired += 1
            _apply(job, fixed, segment_base(), probe_url, budget, url, config['split_unmatched'])

    if not repaired:
        return None

    edits = []
    for job in jobs:
        edits.extend(job['edits'])

    for start, end, replacement in sorted(edits, key=lambda edit: edit[0], reverse=True):
        text = text[:start] + replacement + text[end:]

    log.info('DASH timeline: repaired {} timeline(s) for {}'.format(repaired, url))
    return text.encode('utf8')


class _Progress(object):
    """Background dialog, created only once a repair is actually being attempted.

    A healthy manifest is never probed at all, so the dialog cannot appear for
    one: it starts when a frame-sized duration anomaly has been found and the
    guess is about to be confirmed against the CDN.
    """

    def __init__(self, label=None):
        self._dialog = None
        self._label = label
        self._percent = 0
        self._disabled = False

    def reset(self):
        """Restart the bar, for when the amount of work is re-estimated."""
        self._percent = 0

    def update(self, done, total):
        if self._disabled:
            return
        if self._dialog is None and not self._create():
            return
        try:
            # callers can overshoot (a probe after the work is sized), so the
            # display is clamped - "641 / 423" reads as a bug
            total = max(total, 1)
            done = min(done, total)
            percent = min(100, max(self._percent, int(100.0 * done / total)))
            self._percent = percent
            try:
                self._dialog.update(percent, self._label, '{0} / {1}'.format(done, total))
            except TypeError:
                # older builds only accept a percentage
                self._dialog.update(percent, self._label)
        except Exception:
            self._disabled = True

    def _create(self):
        try:
            self._label = self._label or _.REPAIRING_MANIFEST
            self._dialog = xbmcgui.DialogProgressBG()
            self._dialog.create(self._label)
            return True
        except Exception:
            # no GUI (eg. running outside Kodi) or unsupported - stay silent
            self._disabled = True
            return False

    def close(self):
        if self._dialog is not None:
            try:
                self._dialog.close()
            except Exception:
                pass
            self._dialog = None


def _sidx_or_walk(job, base, probe_url, budget, config, fetch, progress, meta):
    """Exact rebuild from the media when we can read it, else the probe walk."""
    if fetch and job.get('total'):
        # The rebuild dominates the repair, and its size is only known now, so
        # size the bar to it - otherwise a couple of cheap probes have already
        # used up the bar and it would sit at the cap doing nothing. The count
        # is in segments, so it finishes at the end.
        meta['done'] = 0
        meta['total'] = max(1, len(job['segments']))
        meta['shown'] = True
        progress.reset()
        progress.update(0, meta['total'])

        rebuilt = _rebuild(job, base, job['modal'], config, fetch, probe_url, budget, progress, meta)
        if rebuilt:
            log.info('DASH timeline: rebuilt {} segments from sidx'.format(len(rebuilt)))
            # the bar is full: the rendition probes that follow are not part of it
            meta['shown'] = False
            return rebuilt

    breaks = len([d for _, d in job['segments'][:-1] if d != job['modal']])
    meta['done'] = 0
    meta['total'] = 3 + 2 * breaks + len(job['reps'])
    meta['shown'] = True
    progress.reset()
    progress.update(0, meta['total'])

    return _verify(job, base, probe_url, budget)


def fix_manifest(data, url, exists, fetch=None, **kwargs):
    """Return a repaired manifest, or None when the manifest is fine.

    `exists(url)` answers whether a segment is available, and `fetch(url, n)`
    returns the first n bytes of it (used to read each segment's sidx). Both are
    injected so this module has no transport of its own. Everything else is
    policy and can be overridden by keyword - see DEFAULTS.
    """
    if not url or '.mpd' not in url.lower().split('?')[0]:
        return None

    config = dict(DEFAULTS)
    config.update(kwargs)

    log.debug('DASH timeline: inspecting {}'.format(url))

    hit, cached = _cache_lookup(url, config['cache_key'])
    if hit:
        log.debug('DASH timeline: cache hit')
        return cached

    progress = _Progress(config['label'])
    try:
        fixed = _fix(data, url, exists, progress, config, fetch)
    except _Incomplete as e:
        log.debug('DASH timeline: not repairing - {}'.format(e))
        return None
    except Exception as e:
        log.warning('DASH timeline: repair failed - {}'.format(e))
        return None
    finally:
        progress.close()

    # only a real repair is worth caching: a healthy manifest is re-checked with
    # zero probes, and caching "nothing to do" would mask a stricter config later
    if fixed is not None:
        _cache_store(url, fixed, config['cache_key'], config['cache_expires'])
    return fixed
