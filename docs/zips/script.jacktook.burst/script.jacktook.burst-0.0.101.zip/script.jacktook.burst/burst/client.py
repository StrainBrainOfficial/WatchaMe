# -*- coding: utf-8 -*-

"""
Burst web client
"""

import re
import os
import concurrent.futures
import urllib3
import traceback
import threading
import requests
import antizapret
try:
    import dns.resolver
    platform_can_resolve = True
except:
    platform_can_resolve = False

import logging
from .kodi import get_setting
from time import sleep
from urllib3.util import connection
from .utils import encode_dict, is_ipv4_address, domain_matches
from .providers.definitions import translatePath
from http.cookiejar import LWPCookieJar
from urllib.parse import urlparse, urlencode

from requests.packages.urllib3.util.retry import Retry
from requests.adapters import HTTPAdapter
from requests.cookies import create_cookie
from requests.structures import CaseInsensitiveDict

log = logging.getLogger(__name__)

USER_AGENT = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36"
if os.name == 'nt':
    USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36"

if get_setting("use_custom_user_agent", bool):
    agent = get_setting("custom_user_agent", str)
    if agent:
        USER_AGENT = agent
        log.debug("Using custom User Agent: %s" % (USER_AGENT))

PATH_TEMP = translatePath("special://temp")
# Driven by the user-configurable "timeout" setting (also used by the
# overall per-provider search deadline in burst.py) instead of a fixed
# constant.
request_timeout = get_setting("timeout", int)
# (connect, read) seconds for a single attempt. requests/urllib3's own
# `timeout` only bounds the gap between individual socket reads, not the
# request as a whole - a server that trickles data slowly enough (an
# anti-bot challenge holding the connection open, for instance) never
# trips it and can hang far past this value. `open()` below wraps the
# whole send+read in a real wall-clock deadline using the same setting,
# so a stalled tracker can't hold a provider thread forever either way.
REQUEST_TIMEOUT = (5, request_timeout)
# DNS lookups must resolve well before the overall request timeout expires
dns_timeout = min(request_timeout, 10)
max_retries = get_setting("max_retries", int)
# Cookie jar file is shared by all provider threads
cookies_lock = threading.Lock()

# Custom DNS default data
OPENNIC_API_URL = 'https://api.opennicproject.org/geoip/?bare&res=3&adm=3&rnd=true&ipv=4'
OPENNIC_DNS_FALLBACK = ['94.247.43.254', '152.53.15.127', '95.216.99.249']
dns_cache = {}
dns_public_list = ['9.9.9.9', '8.8.8.8', '8.8.4.4']
dns_opennic_list = list(OPENNIC_DNS_FALLBACK)
# Save original DNS resolver
_orig_create_connection = connection.create_connection

# Proxy types
proxy_types = ["socks4",  # socks4 (hostname resolve on client)
    "socks5",  # socks5 (hostname resolve on client)
    "http",
    "https",
    "socks4a",  # socks4 latest version with hostname resolve by proxy
    "socks5h"]  # socks5 latest version with hostname resolve by proxy
elementum_proxy_types_overrides = {'socks4': 'socks4a',
    'socks5': 'socks5h'}

# Disable warning from urllib
urllib3.disable_warnings()

# Kodi settings
proxy_enabled = get_setting("proxy_enabled", bool)
proxy_use_type = get_setting("proxy_use_type", int)
proxy_host = get_setting("proxy_host", str)
proxy_port = get_setting("proxy_port", int)
proxy_login = get_setting("proxy_login", str)
proxy_password = get_setting("proxy_password", str)
proxy_type = get_setting("proxy_type", int)
use_custom_dns = get_setting("use_custom_dns", bool)
public_dns_list = get_setting("public_dns_list", str)
use_opennic_dns = use_custom_dns and get_setting("use_opennic_dns", bool)
use_tor_dns = get_setting("use_tor_dns", bool)
# Jacktook passes its internal proxy through the search payload, so there is no addon to query here.
use_elementum_internal_proxy = False

def FetchOpenNICDnsServers():
    try:
        response = requests.get(OPENNIC_API_URL, timeout=5, headers={'User-Agent': USER_AGENT})
        response.raise_for_status()
        dns_servers = []
        for line in response.text.splitlines():
            candidate = line.strip()
            if not candidate or not is_ipv4_address(candidate):
                continue
            if candidate in dns_servers:
                continue
            dns_servers.append(candidate)

        if dns_servers:
            log.debug("Loaded %d OpenNIC DNS servers from API" % len(dns_servers))
            return dns_servers
        log.debug("OpenNIC API returned no valid IPv4 DNS servers, using fallback list")
    except Exception as e:
        log.debug("Failed to fetch OpenNIC DNS servers from API: %s" % repr(e))
    return list(OPENNIC_DNS_FALLBACK)


if use_opennic_dns:
    dns_opennic_list = FetchOpenNICDnsServers()


def MyResolver(host):
    if '.' not in host:
        return host

    try:
        return dns_cache[host]
    except KeyError:
        pass

    ip = ResolvePublic(host)
    if not ip and use_opennic_dns:
        ip = ResolveOpennic(host)

    if ip:
        log.debug("Host %s resolved to %s" % (host, ip))
        dns_cache[host] = ip
        return ip
    else:
        return host

def ResolvePublic(host):
    try:
        log.debug("Custom DNS resolving with public DNS for: %s" % host)
        resolver = dns.resolver.Resolver()
        resolver.nameservers = dns_public_list
        resolver.timeout = dns_timeout
        resolver.lifetime = dns_timeout
        answer = resolver.query(host, 'A')
        return answer.rrset.items[0].address
    except:
        return

def ResolveOpennic(host):
    try:
        log.debug("Custom DNS resolving with OpenNIC DNS for: %s" % host)
        resolver = dns.resolver.Resolver()
        resolver.nameservers = dns_opennic_list
        resolver.timeout = dns_timeout
        resolver.lifetime = dns_timeout
        answer = resolver.query(host, 'A')
        return answer.rrset.items[0].address
    except:
        return


class Client:
    """
    Web client class with automatic charset detection and decoding
    """
    def __init__(self, info=None, request_charset='utf-8', response_charset=None, is_api=False):
        self._counter = 0
        self._cookies_filename = ''
        self._cookies = LWPCookieJar()
        self.url = None
        self.user_agent = USER_AGENT
        self.content = None
        self.request_cookies = None
        self.response_cookies = None
        self.status = None
        self.username = None
        self.token = None
        self.passkey = None
        self.info = info
        self.proxy_url = None
        self.use_antizapret = False
        self.antizapret_proxy = None
        self.request_charset = request_charset
        self.response_charset = response_charset
        self.is_api = is_api

        self.use_cookie_sync = False

        self.headers = dict()
        self.request_headers = None

        self.session = requests.session()
        self.session.verify = False

        # Enabling retrying on failed requests
        retries = Retry(
            total=max_retries,
            read=max_retries,
            connect=max_retries,
            redirect=3,
            backoff_factor=0.2,
            status_forcelist=[429, 500, 502, 503, 504],
            respect_retry_after_header=False
        )

        self.session.mount('http://', HTTPAdapter(max_retries=retries))
        self.session.mount('https://', HTTPAdapter(max_retries=retries))
        # self.session = cfscrape.create_scraper()
        # self.scraper = cfscrape.create_scraper()
        # self.session = self.scraper.session()

        global dns_public_list
        dns_public_list = public_dns_list.replace(" ", "").split(",")
        # socket.setdefaulttimeout(60)

        # Parsing proxy information
        proxy = {
            'enabled': proxy_enabled,
            'use_type': proxy_use_type,
            'type': proxy_types[0],
            'host': proxy_host,
            'port': proxy_port,
            'login': proxy_login,
            'password': proxy_password,
        }

        try:
            proxy['type'] = proxy_types[proxy_type]
        except:
            pass

        if use_custom_dns and platform_can_resolve:
            connection.create_connection = patched_create_connection

        if use_elementum_internal_proxy:
            self.proxy_url = "{0}://{1}:{2}".format("http", "127.0.0.1", "65222")
            if info and "internal_proxy_url" in info:
                self.proxy_url = info["internal_proxy_url"]
        if proxy['enabled']:
            if proxy['use_type'] == 0 and info and "proxy_url" in info:
                log.debug("Setting proxy from Jacktook: %s" % (info["proxy_url"]))

                self.proxy_url = info["proxy_url"]
            elif proxy['use_type'] == 1:
                log.debug("Setting proxy with custom settings: %s" % (repr(proxy)))

                if proxy['login'] or proxy['password']:
                    self.proxy_url = "{0}://{1}:{2}@{3}:{4}".format(proxy['type'], proxy['login'], proxy['password'], proxy['host'], proxy['port'])
                else:
                    self.proxy_url = "{0}://{1}:{2}".format(proxy['type'], proxy['host'], proxy['port'])
            elif proxy['use_type'] == 2 and info and "proxy_url" in info:
                log.debug("Setting proxy with hosts resolve from Jacktook: %s" % (info["proxy_url"]))

                self.proxy_url = info["proxy_url"]
                proxy_url_scheme_separator = '://'
                elementum_proxy_url_parts = info["proxy_url"].split(proxy_url_scheme_separator)
                elementum_proxy_url_prefix = elementum_proxy_url_parts[0].lower()
                if elementum_proxy_url_prefix in elementum_proxy_types_overrides:
                    self.proxy_url = proxy_url_scheme_separator.join([elementum_proxy_types_overrides[elementum_proxy_url_prefix]] + elementum_proxy_url_parts[1:])
            elif proxy['use_type'] == 3:
                log.debug("Setting proxy to Antizapret proxy")

                self.use_antizapret = True
                self.proxy_url = None
                self.antizapret_proxy = antizapret.AntizapretProxy()
        if self.proxy_url:
            self.session.proxies = {
                'http': self.proxy_url,
                'https': self.proxy_url,
            }

    def _locate_cookies(self, url=''):
        cookies_path = os.path.join(PATH_TEMP, 'burst')
        if not os.path.exists(cookies_path):
            try:
                os.makedirs(cookies_path)
            except Exception as e:
                log.debug("Error creating cookies directory: %s" % repr(e))

        return os.path.join(cookies_path, 'common_cookies.jar')

    def _read_cookies(self, url=''):
        self._cookies_filename = self._locate_cookies(url)
        with cookies_lock:
            if os.path.exists(self._cookies_filename):
                try:
                    self._cookies.load(self._cookies_filename)
                except Exception as e:
                    log.debug("Reading cookies error: %s" % repr(e))

    def cookie_exists(self, cookie_name, domain):
        expired = False
        for cookie in self._cookies:
            if cookie.name == cookie_name and domain_matches(domain, cookie.domain):
                if cookie.is_expired():
                    expired = True
                    continue
                return True
        if expired:
            log.warning("Cookie %s for %s is expired, re-sync cookies to use them" % (cookie_name, domain))
        return False

    def add_cookie(self, cookie):
        cookie_obj = create_cookie(domain=cookie["domain"], name=cookie["name"], value=cookie["value"], path=cookie["path"], secure=cookie["secure"], expires=cookie["expirationDate"], discard=False, rest=cookie["rest"])
        self._cookies.set_cookie(cookie_obj)

    def save_cookies(self):
        self._cookies_filename = self._locate_cookies(self.url)

        with cookies_lock:
            try:
                self._cookies.save(self._cookies_filename)
            except Exception as e:
                log.debug("Saving cookies error: %s" % repr(e))

    def _good_spider(self):
        self._counter += 1
        if self._counter > 1:
            sleep(0.25)

    def open(self, url, language='en', post_data=None, get_data=None, headers=None):
        """ Opens a connection to a webpage and saves its HTML content in ``self.content``

        Args:
            url        (str): The URL to open
            language   (str): The language code for the ``Content-Language`` header
            post_data (dict): POST data for the request
            get_data  (dict): GET data for the request
        """

        if get_data:
            url += '?' + urlencode(get_data)

        if self.use_antizapret:
            parsed = urlparse(url)
            proxy = self.antizapret_proxy.detect(host=parsed.netloc)
            if proxy:
                log.debug("Detected Antizapret proxy for %s: %s" % (parsed.netloc, proxy))
            # Reset for hosts without a proxy, session keeps proxies from the previous request otherwise
            self.session.proxies = {'http': proxy, 'https': proxy} if proxy else {}

        log.debug("Opening URL: %s" % repr(url))
        if self.session.proxies:
            log.debug("Proxies: %s" % (repr(self.session.proxies)))

        self._read_cookies(url)
        self.session.cookies = self._cookies

        # log.debug("Cookies for %s: %s" % (repr(url), repr(self._cookies)))

        # Default headers for any request. Pretend like we are the usual browser.
        req_headers = CaseInsensitiveDict({
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'Accept-Language': 'ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7,uk;q=0.6,pl;q=0.5',
            'Cache-Control': 'max-age=0',
            'Content-Language': language,
            'Origin': url,
            'Referer': url,
            'User-Agent': self.user_agent
        })

        # Remove referer for API providers
        if self.is_api:
            del req_headers['Referer']

        # If headers passed to open() call - we overwrite headers.
        if headers:
            for key, value in headers.items():
                if key == ':path':
                    u = urlparse(url)
                    value = u.path
                if value:
                    req_headers[key] = value
                elif key in req_headers:
                    del req_headers[key]

        if self.token:
            req_headers["Authorization"] = self.token

        req = None
        if post_data:
            req = requests.Request('POST', url, data=post_data, headers=req_headers)
        else:
            req = requests.Request('GET', url, headers=req_headers)

        prepped = self.session.prepare_request(req)
        self.request_headers = prepped.headers

        # Do not leave previous response around if this request fails
        self.status = None
        self.content = ''
        self.headers = dict()

        try:
            self._good_spider()

            # Enforce a hard wall-clock deadline around the whole send+read,
            # on top of REQUEST_TIMEOUT's per-read bound - see its comment
            # above for why the latter alone isn't enough.
            # The send runs in a worker thread so a deadline hit frees the
            # provider even if the socket keeps trickling. shutdown(wait=False)
            # does not cancel that worker: it holds the socket until the read
            # finishes and the response it returns is never used. That is
            # deliberate, one disposable worker is cheaper than a stuck
            # provider thread, but do not assume the connection is closed here.
            executor = concurrent.futures.ThreadPoolExecutor(max_workers=1)
            future = executor.submit(self.session.send, prepped, timeout=REQUEST_TIMEOUT)
            try:
                response_ctx = future.result(timeout=request_timeout)
            except concurrent.futures.TimeoutError:
                executor.shutdown(wait=False, cancel_futures=True)
                raise requests.exceptions.Timeout(
                    "Request exceeded hard timeout of %ds (stalled response)"
                    % request_timeout
                )
            executor.shutdown(wait=False)

            with response_ctx as response:
                self.headers = response.headers
                self.status = response.status_code
                self.url = response.url

                if self.response_charset:
                    self.content = response.content.decode(self.response_charset, 'ignore')
                else:
                    self.content = response.text
                self.request_cookies = response.request.headers.get('Cookie')
                self.response_cookies = response.cookies.get_dict()

        except requests.exceptions.InvalidSchema as e:
            # If link points to a magnet: then it can be used as a content
            matches = re.findall('No connection adapters were found for \'(.*?)\'', str(e))
            if matches:
                self.content = matches[0]
                return True

            log.error("%s failed with %s:" % (repr(url), repr(e)))
            log.debug(traceback.format_exc())
        except Exception as e:
            log.error("%s failed with %s:" % (repr(url), repr(e)))
            log.debug(traceback.format_exc())

        log.debug("Status for %s : %s" % (repr(url), str(self.status)))
        if self.status != 200:
            log.debug("Failed response content for %s : %s" % (repr(url), str(self.content)))

        return self.status == 200

    def login(self, root_url, url, data, headers, fails_with, prerequest=None):
        """ Login wrapper around ``open``

        Args:
            url        (str): The URL to open
            data      (dict): POST login data
            fails_with (str): String that must **not** be included in the response's content

        Returns:
            bool: Whether or not login was successful
        """
        if not url.startswith('http'):
            url = root_url + url

        if prerequest:
            if not prerequest.startswith('http'):
                prerequest = root_url + prerequest
            log.debug("Running prerequest to %s" % (prerequest))
            self.open(prerequest, headers=headers)

        if self.open(url, post_data=encode_dict(data, self.request_charset), headers=headers):
            try:
                if fails_with and re.search(fails_with, self.content):
                    self.status = 'Wrong username or password'
                    return False
            except Exception as e:
                log.debug("Login failed with: %s" % e)
                return False

            return True

        return False

def patched_create_connection(address, *args, **kwargs):
    """Wrap urllib3's create_connection to resolve the name elsewhere"""
    # resolve hostname to an ip address; use your own
    # resolver here, as otherwise the system resolver will be used.
    host, port = address
    log.debug("Custom resolver: %s --- %s --- %s" % (host, port, repr(address)))
    hostname = MyResolver(host)

    return _orig_create_connection((hostname, port), *args, **kwargs)

def change_agent(userAgent):
    global USER_AGENT
    USER_AGENT = userAgent
